package one.two;

import java.util.*;

//On Describe Lambda 1 - starts
//https://www.tutorialspoint.com/java/java8_new_features.htm
/*public class Tester {

	public static void main(String[] args) {
		// Interface implementation using anonymous class
		Calculator sum = new Calculator() {
			@Override
			public int operate(int a, int b) {
				return a + b;
			}
		};
		int result = sum.operate(2, 3);
		System.out.println(result);

		// Interface implementation using lambda expression
		Calculator sum1 = (a, b) -> a + b;
		result = sum1.operate(2, 3);
		System.out.println(result);
	}

	interface Calculator {
		int operate(int a, int b);
	}
}*/
// On Describe Lambda 1 - Ends

//On Describe method reference 2 - starts - errored example
//https://www.tutorialspoint.com/java/java8_new_features.htm
/*public class Tester {
	   public static void main(String args[]) {
	      List<Integer> numbers = Arrays.asList(1,2,4,9,8,7,3);
	      System.out.println("Sorted using static method reference");
	      // Use static method compare
	      numbers = numbers.stream().sorted(Integer::compare).toList();
	      System.out.println(numbers);

	      numbers = Arrays.asList(1,2,4,9,8,7,3);
	      System.out.println("Sorted using instance method reference" );
	      // Use instance method compareTo
	      numbers = numbers.stream().sorted(Integer::compareTo).toList();

	      System.out.println(numbers);		
	   }
	}*/
//On Describe method reference 2 - starts

//On Describe method reference 3 - starts
public class Tester {
	public static void print(String s) {
		System.out.println("Print : " + s);	
	}
	
//	public static void print(String s) {
//		System.out.println("Print : " + s);	
//	}
	
	public static void main(String args[]) {
		String[] names = {"one", "two", "three"};
		
		Arrays.stream(names).forEach(Tester::print);
		Arrays.sort(names);
		Arrays.stream(names).forEach(Tester::print);
	}
}
//On Describe method reference 3 - ends