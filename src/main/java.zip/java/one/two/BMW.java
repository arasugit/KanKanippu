package one.two;


//parent class
class Car{    
 Car get(){
     System.out.println("This is the Car class.");
     return this;
 }    
}    

//child class 
class BMW extends Car{   
@Override  

 // overloading the get method
 BMW get(){
     System.out.println("This is the BMW class.");
     return this;
 } 
 
 public static void main(String args[]){    
     Car MyCar = new BMW();
     MyCar.get();   
 }    
}   