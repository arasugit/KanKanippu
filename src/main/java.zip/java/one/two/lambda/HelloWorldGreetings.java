package one.two.lambda;

public class HelloWorldGreetings implements Greeting {

	@Override
	public void perform() {
		System.out.println("Hello world within HelloWorldGreetings class which implement Greeting");
	}

}
