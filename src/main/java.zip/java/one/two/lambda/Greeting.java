package one.two.lambda;

public interface Greeting {
	public void perform();
	//int add(int x, int y);
}
