package one.two.lambda;

public class Greeter {
	
	public void greet(Greeting greeting) {
		//System.out.println("Hello World !");
		greeting.perform();
	}

	public static void main(String[] args) {
		Greeter greeter = new Greeter();
		HelloWorldGreetings helloWorldGreetings = new HelloWorldGreetings();
		
		helloWorldGreetings.perform();
		
		//greeter.greet(helloWorldGreetings);
		//greeter.greet();
		
		//MyLambda myLambdaFunction = () -> System.out.println("This is Lambda fn print");
		//MyAdd addFunction = (int a, int b) -> a + b;
		
		Greeting myLambdaFunction = () -> System.out.println("This is Lambda fn print - Hello World");
		myLambdaFunction.perform();
		
		Greeting innerClassGreeting = new Greeting() {
			public void perform() {
				System.out.println("This is innerClass Helloworld print");
			}
		};
		
		System.out.println("1 " + myLambdaFunction.toString());
		innerClassGreeting.perform();
	}

}

interface MyLambda {
	void foo();
}

interface MyAdd {
	int add(int x, int y);
}