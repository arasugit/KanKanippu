package one.two;

public class qqq {

	public qqq() {
		// TODO Auto-generated constructor stub
	}

}
