package one.two;

import java.util.Arrays;
import java.util.Comparator;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class TriageSteams {

	public TriageSteams() {
		// TODO Auto-generated constructor stub
	}

/*	//You have an array holding five integers. Which code increments each integer?
	public static void main(String[] args) {
		int[] numbers = {10, 20, 30, 40, 50};
		
		for (int index = 0; index < numbers.length; numbers[index++]++) {
			System.out.println("3 " + numbers[index]);
		    //numbers[index]++; // This is a shorthand for numbers[i] = numbers[i] + 1;
		}
		for (int index = 0; index < numbers.length; index++) {
			System.out.println("4 " + numbers[index]);
		}
	}*/
	
/*	//Sorting and getting unique...
	public static void main(String[] args) {
		List<String> list = Arrays.asList("Foo ", "bar ", "Foo ", "Bar ");
		Stream<String> stream = list.stream()
		                            .sorted(Comparator.reverseOrder())
		                            .distinct();
		
		stream.forEach(System.out::print);
		
		int i1 = 40_000;
		short i2 = (short) (i1 + 10);

		System.out.println("...." + i2);
		

	}*/
/*
	//Get additions...concatanations
	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(1,2,3,4,5);
		
		//Summing using reduce
		Integer sum = numbers.parallelStream().reduce(0, Integer::sum);
		
		System.out.println("Sum " + sum);
		
		List<String> textList = Arrays.asList("one", "two", "three", "four", "five").subList(0, 3);
		
		String adding = textList.parallelStream().reduce("-", String::concat);
		
		System.out.println("adding " + adding);
	}*/
	
	public static void main(String[] args) {
		//Generate 
		List<String> strings1 = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");
		List<String> filtered = strings1.stream()
				.filter(string -> !string.isEmpty()).collect(Collectors.toList());
		
		//map method
		List<Integer> numbers2 = Arrays.asList(3, 2, 2, 3, 7, 3, 5);

		//get list of unique squares
		List<Integer> squaresList = numbers2.stream().map( i -> i*i).distinct().collect(Collectors.toList());
		
		//for each method
		Random random = new Random();
		random.ints().limit(10).forEach(System.out::println);
		
		System.out.println("--------------------------------------------------------");
		
		//FILTER METHOD
		List<String>strings = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");

		//get count of empty string
		int count = (int) strings.stream().filter(string ->!string.isEmpty()).count();
		
		//limit method - what this mean ????
		Random random1 = new Random();
		random1.ints().limit(10).forEach(System.out::println);
		System.out.println("--------------------------------------------------------");
		
		//sorted method
		Random random2 = new Random();
		random2.ints().limit(10).sorted().forEach(System.out::println);
		System.out.println("--------------------------------------------------------");

		//parallel processing
		List<String> strings2 = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");

		//get count of empty string
		long count2 = strings2.parallelStream().filter(string -> string.isEmpty()).count();
		
		List<String>strings3 = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");
		List<String> filtered2 = strings3.stream().filter(string -> !string.isEmpty()).collect(Collectors.toList());
		
		System.out.println("Filtered List: " + filtered2);
		
		System.out.println("--------------------------------------------------------");

		String mergedString = strings3.stream().filter(string -> !string.isEmpty()).collect(Collectors.joining(", "));
		System.out.println("Merged String: " + mergedString);
		
		System.out.println("Statistics --------------------------------------------------------");

/*		List numbers = Arrays.asList(3, 2, 2, 3, 7, 3, 5);
		IntSummaryStatistics stats = numbers.stream().mapToInt((x) -> x).summaryStatistics();

		System.out.println("Highest number in List : " + stats.getMax());
		System.out.println("Lowest number in List : " + stats.getMin());
		System.out.println("Sum of all numbers : " + stats.getSum());
		System.out.println("Average of all numbers : " + stats.getAverage());*/

	}
}
