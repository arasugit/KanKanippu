package one.two;

import com.efunds.t21.common.util.StringUtil;

public class Testing {

	public Testing() {
	}

	public static void main(String[] args) {
		System.out.println("ONE ");
		
		String status = "N";
		status=StringUtil.isNotEmpty(status) ? (!status.equalsIgnoreCase("N"))?status.trim():"":"";
		
		System.out.println("status...$" + status + "$...");
		
	}

}
