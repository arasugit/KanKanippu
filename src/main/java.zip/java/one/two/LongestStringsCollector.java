package one.two;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;

public class LongestStringsCollector {

    public static Collector<String, ?, List<String>> toLongestStrings() {
        return Collector.of(
            // Supplier: Creates a new ArrayList
            ArrayList::new,
            
            // Accumulator: Adds strings to the list
            (list, element) -> {
                if (list.isEmpty() || element.length() > list.get(0).length()) {
                    list.clear();
                    list.add(element);
                } else if (element.length() == list.get(0).length()) {
                    list.add(element);
                }
            },
            
            // Combiner: Merges two lists
            (list1, list2) -> {
                if (list1.isEmpty()) return list2;
                if (list2.isEmpty()) return list1;
                
                if (list1.get(0).length() > list2.get(0).length()) {
                    return list1;
                } else if (list2.get(0).length() > list1.get(0).length()) {
                    return list2;
                } else {
                    list1.addAll(list2);
                    return list1;
                }
            },
            
            // Finisher: No transformation needed, so we use the identity function
            Collector.Characteristics.IDENTITY_FINISH
        );
    }

    public static void main(String[] args) {
        //List<String> strings = List.of("apple", "banana", "kiwi", "grapefruit", "orange", "pear");
        	
    	List<String> strings = Arrays.asList("apple", "banana", "kiwi", "grapefruit", "orange", "pear");
        
        List<String> longestStrings = strings.stream()
            .collect(toLongestStrings());
            
        System.out.println("The longest string(s): " + longestStrings); 
        // Output: The longest string(s): [grapefruit]
        
        //List<String> strings2 = List.of("cat", "dog", "bird", "fish", "lion");
        List<String> strings2 = Arrays.asList("cat", "dog", "bird", "fish", "lion");
        
        List<String> longestStrings2 = strings2.stream()
            .collect(toLongestStrings());
            
        System.out.println("The longest string(s): " + longestStrings2);
        // Output: The longest string(s): [bird, fish]
    }
}