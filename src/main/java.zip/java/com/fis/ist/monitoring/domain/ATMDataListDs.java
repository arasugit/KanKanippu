package com.fis.ist.monitoring.domain;


public class ATMDataListDs implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String make;
	private String instId; 
	private String grpName;
	private String ATMUnit;
	private String termId;
	private String location;
	private String geoLocation;
	private String acceptorName;
	private String currency;
	private String lastTransactionDateTime;
	private String faultStatusCode;
	private String lastStatusDate;
	private String lastStatusTime;
	private String faultStatusDesc;
	
	
	public ATMDataListDs() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getMake() {
		return make;
	}


	public void setMake(String make) {
		this.make = make;
	}


	public String getInstId() {
		return instId;
	}


	public void setInstId(String instId) {
		this.instId = instId;
	}


	public String getGrpName() {
		return grpName;
	}


	public void setGrpName(String grpName) {
		this.grpName = grpName;
	}

	public String getATMUnit() {
		return ATMUnit;
	}

	public void setATMUnit(String ATMUnit) {
		this.ATMUnit = ATMUnit;
	}
	
	public String getTermId() {
		return termId;
	}

	public void setTermId(String termId) {
		this.termId = termId;
	}

	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getGeoLocation() {
		return geoLocation;
	}


	public void setGeoLocation(String geoLocation) {
		this.geoLocation = geoLocation;
	}


	public String getAcceptorName() {
		return acceptorName;
	}


	public void setAcceptorName(String acceptorName) {
		this.acceptorName = acceptorName;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public String getLastTransactionDateTime() {
		return lastTransactionDateTime;
	}


	public void setLastTransactionDateTime(String lastTransactionDateTime) {
		this.lastTransactionDateTime = lastTransactionDateTime;
	}


	public String getFaultStatusCode() {
		return faultStatusCode;
	}


	public void setFaultStatusCode(String faultStatusCode) {
		this.faultStatusCode = faultStatusCode;
	}


	public String getLastStatusDate() {
		return lastStatusDate;
	}


	public void setLastStatusDate(String lastStatusDate) {
		this.lastStatusDate = lastStatusDate;
	}


	public String getLastStatusTime() {
		return lastStatusTime;
	}


	public void setLastStatusTime(String lastStatusTime) {
		this.lastStatusTime = lastStatusTime;
	}


	public String getFaultStatusDesc() {
		return faultStatusDesc;
	}


	public void setFaultStatusDesc(String faultStatusDesc) {
		this.faultStatusDesc = faultStatusDesc;
	}

	@Override
	public String toString() {
		return "ATMDataListDs [make=" + make + ", instId=" + instId + ", grpName=" + grpName + ", ATMUnit=" + ATMUnit
				+ ", termId=" + termId + ", location=" + location + ", geoLocation="
				+ geoLocation + ", acceptorName=" + acceptorName + ", currency=" + currency
				+ ", lastTransactionDateTime=" + lastTransactionDateTime + ", faultStatusCode=" + faultStatusCode
				+ ", lastStatusDate=" + lastStatusDate + ", lastStatusTime=" + lastStatusTime + ", faultStatusDesc="
				+ faultStatusDesc + "]";
	}

}
