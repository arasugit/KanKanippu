package com.fis.ist.monitoring.dao;

import static com.fis.ist.common.OracleDaoConstants.CASH_DECREMENT;
import static com.fis.ist.common.OracleDaoConstants.CASH_INCREMENT;
import static com.fis.ist.common.OracleDaoConstants.CASH_OUT;
import static com.fis.ist.common.OracleDaoConstants.CASSETTE_NBR;
import static com.fis.ist.common.OracleDaoConstants.COUNT;
import static com.fis.ist.common.OracleDaoConstants.CRITERIA_GROUP_NAME;
import static com.fis.ist.common.OracleDaoConstants.CRITERIA_INSTITUTION;
import static com.fis.ist.common.OracleDaoConstants.CRITERIA_UNIT;
import static com.fis.ist.common.OracleDaoConstants.CURRENT_CASH_BALANCE;
import static com.fis.ist.common.OracleDaoConstants.DEPRECATION;
import static com.fis.ist.common.OracleDaoConstants.EMPTY;
import static com.fis.ist.common.OracleDaoConstants.GROUP_NAME;
import static com.fis.ist.common.OracleDaoConstants.INSTITUTION_ID;
import static com.fis.ist.common.OracleDaoConstants.ITEMS_REJECTED;
import static com.fis.ist.common.OracleDaoConstants.PREVIOUS_CASH_BALANCE;
import static com.fis.ist.common.OracleDaoConstants.PREVIOUS_RECYCLE_COUNT;
import static com.fis.ist.common.OracleDaoConstants.RAWTYPES;
import static com.fis.ist.common.OracleDaoConstants.RECYCLE_COUNT;
import static com.fis.ist.common.OracleDaoConstants.RESET_TIME;
import static com.fis.ist.common.OracleDaoConstants.START_CASH_BALANCE;
import static com.fis.ist.common.OracleDaoConstants.UNCHECKED;
import static com.fis.ist.common.OracleDaoConstants.UNIT;

import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.ATMCassetteCounter;

@SuppressWarnings({ RAWTYPES, UNCHECKED, DEPRECATION })
public class ATMCassetteCounterDao extends MonitorBaseDAO<ATMCassetteCounter, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(ATMCassetteCounterDao.class);
	private static final String QUERY_PREFIX = "prefix";
	private static final String QUERY_SUFFIX = "suffix";
	private static final String ATMCTE_REQ_COUNT = "ATMCTE_REQ_COUNT";
	private static final String ATMCTE_REQ = "ATMCTE_REQ";

	public List<ATMCassetteCounter> getCassetteCounterBySwDB(int pageNum, String... atms) {
		log.debug("Entering getCassetteCounterBySwDB in ATMCassetteCounterDao");
		List<ATMCassetteCounter> atmCassetteCounterList = null;
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery(ATMCTE_REQ);
			StringBuilder sb = new StringBuilder(SqlQueryProvider.manipulatingPrefixSuffixforATMTabs(QUERY_PREFIX,ATMCTE_REQ));
			
			sb.append(queryString);
			if (atms[0] != null) {
				sb.append(CRITERIA_INSTITUTION);
			}
			if (!atms[1].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_GROUP_NAME);
			}
			if (!atms[2].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_UNIT);
			}			
			
			sb.append(SqlQueryProvider.manipulatingPrefixSuffixforATMTabs(QUERY_SUFFIX, ATMCTE_REQ));
			int startSize=0;
			int endSize=0;
			
			int pgsz = getDefaultPageSize();
			if(pageNum > 1){
				startSize=((pageNum*pgsz)-pgsz);
				endSize=pageNum*pgsz;	
			}else {
				startSize=1;
				endSize=pgsz;	

			}
			int paramIndex = 0;
			Query queryObject = getSession().createSQLQuery(sb.toString())
					.addScalar(INSTITUTION_ID, StandardBasicTypes.STRING)
					.addScalar(GROUP_NAME, StandardBasicTypes.STRING).addScalar(UNIT, StandardBasicTypes.LONG)
					.addScalar(CASSETTE_NBR, StandardBasicTypes.LONG).addScalar(ITEMS_REJECTED, StandardBasicTypes.LONG)
					.addScalar(CASH_INCREMENT, StandardBasicTypes.LONG)
					.addScalar(CASH_DECREMENT, StandardBasicTypes.LONG).addScalar(CASH_OUT, StandardBasicTypes.LONG)
					.addScalar(CURRENT_CASH_BALANCE, StandardBasicTypes.LONG)
					.addScalar(START_CASH_BALANCE, StandardBasicTypes.LONG)
					.addScalar(PREVIOUS_CASH_BALANCE, StandardBasicTypes.LONG)
					.addScalar(RESET_TIME, StandardBasicTypes.STRING).addScalar(RECYCLE_COUNT, StandardBasicTypes.LONG)
					.addScalar(PREVIOUS_RECYCLE_COUNT, StandardBasicTypes.LONG);
			if (atms[0] != null) {
				queryObject.setParameter(++paramIndex, atms[0]);
			}
			if (!atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, atms[1]);
			}
			if (!atms[2].equalsIgnoreCase(EMPTY) && atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));
			} else if (!atms[2].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));

			}
			queryObject.setParameter(++paramIndex, endSize);
			queryObject.setParameter(++paramIndex, startSize);
			atmCassetteCounterList = (List<ATMCassetteCounter>) queryObject
					.setResultTransformer(Transformers.aliasToBean(ATMCassetteCounter.class)).list();

		} catch (RuntimeException re) {
			log.error("Error While finding ATM Cassette Counter", re);
			throw re;
		}
		log.debug("Exiting getCassetteCounterBySwDB in ATMCassetteCounterDao");
		return atmCassetteCounterList;
	}

	public Integer getCountCassetteCounter(String... atms) {
		log.debug("Entering getCountCassetteCounter in ATMCassetteCounterDao");
		Integer count = null;
		String queryString = SqlQueryProvider.getDBSqlQuery(ATMCTE_REQ_COUNT);

		try 
		{
			StringBuilder sb = new StringBuilder(queryString);
			if (atms[0] != null) {
				sb.append(CRITERIA_INSTITUTION);
			}
			if (atms[1] != null && !atms[1].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_GROUP_NAME);
			}
			if (atms[2] != null && !atms[2].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_UNIT);
			}
			Query queryObject = getSession().createSQLQuery(sb.toString()).addScalar(COUNT, StandardBasicTypes.INTEGER);
			int paramIndex = 0;
			if (atms[0] != null) {
				queryObject.setParameter(++paramIndex, atms[0]);
			}
			if (!atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, atms[1]);
			}
			if (!atms[2].equalsIgnoreCase(EMPTY) && atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));
			} else if (!atms[2].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));
			}

			count = queryObject.uniqueResult() != null ? (Integer) queryObject.uniqueResult() : 0;

		} catch (RuntimeException re) {
			log.error("Error While finding total atms", re);
			throw re;
		}
		log.debug("Exiting getCountCassetteCounter in ATMCassetteCounterDao");
		return count;

	}

	public Class<ATMCassetteCounter> getEntityClass() {
		return ATMCassetteCounter.class;
	}

}
