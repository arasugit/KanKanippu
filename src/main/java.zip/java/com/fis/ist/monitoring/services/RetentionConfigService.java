package com.fis.ist.monitoring.services;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.audit.FormAudit;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.services.handler.RetentionConfigHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

public class RetentionConfigService extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(RetentionConfigService.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		RetentionConfigHandler handler = new RetentionConfigHandler();

		HttpServletRequest request = HTTPRequestGetter.getRequest();
		String productId = (String) request.getSession(false).getAttribute("product_id");
		requestParams.put("product", productId == null ? "" : productId);

		if (action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = handler.getList(userContext, requestParams);
		} else {
			log.error("**** Data Retention Config : getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}
		
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}

	public WorkRequest setService(UserContext userContext, String requestType, String action, WorkRequest workRequest)
			throws Exception {

		FormAuditHandler ah = new FormAuditHandler();
		FormAudit handle = ah.beginEditableListAudit(userContext, requestType, action, workRequest,
				CustomConstants.SWITCH_SUBSYSTEM);

		WorkRequest workReq = new WorkRequest();
		log.debug("Retention Config - Set Service");

		RetentionConfigHandler ddh = new RetentionConfigHandler();

		if (action.compareTo(MonitorConstants.ACTION_INSERT) == 0) {
			workReq = ddh.getDataForAdd(userContext, workRequest);
		} else if (action.compareTo(MonitorConstants.ACTION_SINGLE_BATCH_SAVE) == 0) {
			workReq = ddh.saveWorkRequest(userContext, workRequest, setPermissions());
		} else if (action.compareTo(AppConstants.MKC_ACTION_BATCH_SAVE) == 0) {
			workReq = ddh.saveBatchByChecker(userContext, workRequest, setPermissions());
		} else {
			log.error("**** Retention Config  (DATARTCONF) List: setService() inbound...unknown request type");
			throw new Exception("Unknown request type");
		}

		ah.saveEditableListAudit(handle, workReq);
		return workReq;
	}
}