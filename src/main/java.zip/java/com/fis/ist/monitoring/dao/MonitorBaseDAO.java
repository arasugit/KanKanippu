package com.fis.ist.monitoring.dao;

import static org.hibernate.criterion.Example.create;

import java.io.Serializable;
import java.util.List;

import org.hibernate.query.Query;

public abstract class MonitorBaseDAO<M, I extends Object & Serializable> extends MonitorBaseHibernateDAO {

	public void save(M transientInstance) {
		getSession().save(transientInstance);
	}

	public void delete(M persistentInstance) throws Exception {
		getSession().delete(persistentInstance);

	}

	public void attachDirty(M instance) {
		getSession().saveOrUpdate(instance);
	}

	public String getEntityName() {
		return getEntityClass().getName();
	}

	public abstract Class<M> getEntityClass();

	public M findById(I id) {
		M instance = (M) getSession().get(getEntityClass(), id);
		return instance;
	}

	public List<M> findByProperty(String propertyName, Object value) {
		String queryString = "from " + getEntityName() + " as model where model." + propertyName + "= ?";
		Query queryObject = createQuery(queryString);
		queryObject.setParameter(0, value);
		return (List<M>) queryObject.list();
	}

	public List<M> findByExample(M instance) {
		List<M> results = (List<M>) getSession().createCriteria(getEntityClass()).add(create(instance)).list();
		return results;
	}

}