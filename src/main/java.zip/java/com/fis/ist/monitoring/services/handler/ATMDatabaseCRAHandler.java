package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.ForeignKeysCheckException;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MKCHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.MonitorAtmCraDAO;
import com.fis.ist.monitoring.domain.MonitorAtmCra;
import com.fis.ist.monitoring.domain.MonitorAtmCraId;
import com.fis.ist.monitoring.dto.MonitorAtmCraDto;
import com.fis.ist.services.MenuService;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.EditableListRow;
import com.fis.ist.services.vo.WorkRequest;

public class ATMDatabaseCRAHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(ATMDatabaseCRAHandler.class);
	private static String reqTypeId = MonitorConstants.ATM_CRA_REQ;
	private static String formAuthId = MonitorConstants.ATM_CRA_REQ;

	public ATMDatabaseCRAHandler() {
		checkMKCEnabled(formAuthId);
	}

	public ATMDatabaseCRAHandler(String formAuthIdVar) {
		formAuthId = formAuthIdVar;
		reqTypeId = formAuthIdVar;
		checkMKCEnabled(formAuthIdVar);
	}

	public WorkRequest getMonAtmCra(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.ATM_CRA_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.ATM_CRA_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.ATM_CRA_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.ATM_CRA_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.ATM_CRA_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("ATMDatabaseCRAHandler - Load ATM Database CRA Details");
		String productId = params.get("productId");
		log.debug("productId " + productId);
		String siteId = params.get("siteId");
		log.debug("siteId " + siteId);
		String nodeId = params.get("nodeId");
		log.debug("nodeId " + nodeId);

		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);

		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));

		int total = 0;

		List<MonitorAtmCra> results = new ArrayList<MonitorAtmCra>();

		MonitorAtmCra findRecord = new MonitorAtmCra();

		String institutionId = params.get("institutionId");
		if (StringUtil.isNotEmpty(institutionId)) {
			try {
				// Setting ID info
				if (institutionId != null || institutionId != "") {
					institutionId = institutionId.trim();
					MonitorAtmCraId atmCraId = new MonitorAtmCraId();
					atmCraId.setInstitutionId(institutionId);
					findRecord.setId(atmCraId);
				}
			} catch (NumberFormatException nfe) {
				log.debug("Invalid Institution Id [" + institutionId + "]", nfe);
			}
		}

		if (!needs_total) {
			results = loadMonitorAtmCraListData(findRecord, pageNum);
		} else if (needs_total) {
			total = loadMonitorAtmCraListDataCount(findRecord);
			results = loadMonitorAtmCraListData(findRecord, pageNum);
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List<MonitorAtmCraDto> workRows = getNewWorkMonAtmCraRows(workRequest, uiMetaData);

		if (results == null || results.size() == 0) {
			return;
		}

		for (MonitorAtmCra monAtmCradto : results) {
			if (monAtmCradto != null) {
				MonitorAtmCraDto dto = new MonitorAtmCraDto();
				dto.load(monAtmCradto);
				dto.setDbAction('x');
				if (isMKCEnabled) {
					dto.setOriginalRow(dto);
				}
				workRows.add(dto);
				// Setting the old params here for Id...
				dto.setOldInstitutionId(dto.getInstitutionId());
				dto.setOldCraBranch(dto.getCraBranch());
			}
		}
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
			throws Exception {
		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		currentfield = fields.get("productId");
		fieldValue = params.get("productId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("siteId");
		fieldValue = params.get("siteId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	public HashMap<String,String> getDBMapping()
	{
		HashMap<String,String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product","product");
		dtoMapping.put("nodeId","nodeId");
		dtoMapping.put("taskName","taskName");
		dtoMapping.put("taskType","taskType");
		dtoMapping.put("pId","pId");
		return dtoMapping;
	}

	private List<MonitorAtmCraDto> getNewWorkMonAtmCraRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.ATM_CRA_COL);
		workCollection.setSectionId(MonitorConstants.ATM_CRA_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.ATM_CRA_TAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<MonitorAtmCraDto> workRows = new ArrayList<MonitorAtmCraDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.ATM_CRA_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<MonitorAtmCra> loadMonitorAtmCraListData(MonitorAtmCra model, int pageNum) {
		log.debug("ATMDatabaseCRAHandler - Load MonitorAtmCra records - loadMonitorAtmCraListData()");
		MonitorAtmCraDAO dao = new MonitorAtmCraDAO();
		List<MonitorAtmCra> results = dao.findByExample(model, pageNum);
		return results;
	}

	private int loadMonitorAtmCraListDataCount(MonitorAtmCra model) {
		log.debug("ATMDatabaseCRAHandler - Load Task Command records - loadMonitorAtmCraListDataCount()");
		MonitorAtmCraDAO dao = new MonitorAtmCraDAO();
		int count = dao.getTotalByExample(model);
		return count;
	}

	public WorkRequest getDataForAdd(UserContext userContext, WorkRequest workRequest) throws Exception {
		if (workRequest != null) {
			WorkCollection wc = workRequest.getCollections().get(MonitorConstants.ATM_CRA_COL);
			wc.getRows().add(0, getNewMONATMCRARowInstance());
			return workRequest;
		} else {
			WorkRequest workReq = new WorkRequest();
			UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.ATM_CRA_REQ);

			try {
				workReq.setRequestId("0");
				workReq.setRequestState("DRAFT");

				workReq.setRequestTypeId(MonitorConstants.ATM_CRA_REQ);

				Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
				workReq.setNextStates(nextStates);

				// Set values of all tabs to be modifiable
				Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
				WorkTabStatus workStatus = new WorkTabStatus();
				workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
				workStatus.setTag(MonitorConstants.ATM_CRA_TAB);
				workStatus.setModifyable("Y");
				tabStatus.put(MonitorConstants.ATM_CRA_TAB, workStatus);

				workReq.setTabStatus(tabStatus);

				addWorkFields(workReq, uiMetaData);

				workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null);

				Map<String, WorkField> fields = workReq.getFields();
				Collection<WorkField> cfields = fields.values();

				for (WorkField field : cfields) {
					field.setModifyable("Y");
					field.setVisible("Y");
				}

			} catch (Exception ex) {
				WorkRequestHelper.getInstance().reportException(log, ex, workReq);
			}
			return workReq;
		}
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data) throws Exception {
		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);

				data.setUiMetaData(uiMetaData);
				data.initLastModified();

				if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
					workRequest.setSwitchId(userContext.getSwitchID());
				}

				// Create a logical collection for add
				List<MonitorAtmCraDto> workRows = getNewWorkMONATMCRARows(workRequest, uiMetaData);
				workRows.add(getNewMONATMCRARowInstance());
			}

		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private MonitorAtmCraDto getNewMONATMCRARowInstance() {
		MonitorAtmCraDto dto = new MonitorAtmCraDto();
		dto.setDbAction('a');
		return dto;
	}

	private List<MonitorAtmCraDto> getNewWorkMONATMCRARows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.ATM_CRA_COL);
		workCollection.setSectionId(MonitorConstants.ATM_CRA_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.ATM_CRA_TAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<MonitorAtmCraDto> workRows = new ArrayList<MonitorAtmCraDto>();

		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.ATM_CRA_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	public WorkRequest saveSinglePageRecords(UserContext userContext, WorkRequest workRequest,
			HashMap<String, Boolean> permMap) {
		try {
			workRequest = saveWorkRequest(userContext, workRequest, permMap);
		} catch (Exception e) {
			log.error("Exception occured in the Save Single Pags Records" + e.getMessage());
		}
		return workRequest;
	}

	public WorkRequest saveWorkRequest(UserContext userContext, WorkRequest workRequest,
			HashMap<String, Boolean> permMap) throws Exception {
		if (validateCollectionField(workRequest, MonitorConstants.ATM_CRA_COL)) // Earlier was Referring to
																				// CustomConstants.EMPLISTSPCOL ??
			return workRequest;

		save(userContext, workRequest, permMap);
		return workRequest;
	}

	// TODO : Check the DAO n DTO classes here also create Id for MonitorAtmCraDto
	// class here...

	private void save(UserContext userContext, WorkRequest workRequest, HashMap<String, Boolean> permMap) {
		// check if contact field data is present
		try {
			Map<String, WorkField> fields = workRequest.getFields();
			if (fields == null) {
				WorkRequestHelper.getInstance().reportError("Work fields not found", workRequest);
				return;
			}
			// MonitorAtmCra MonitorAtmCraDto MonitorAtmCraDAO
			boolean isInvalidData = false;
			String value = null;
			List<MonitorAtmCraDto> corrCollection = new ArrayList<MonitorAtmCraDto>();
			List<String> duplicateCollection = new ArrayList<String>();
			MonitorAtmCraDAO dao = new MonitorAtmCraDAO();
			WorkCollection wc = workRequest.getCollections().get(MonitorConstants.ATM_CRA_COL);
			List<MonitorAtmCraDto> rows = wc.getRows();

			// Only the affected rows will be available here.

			for (int i = 0; i < rows.size(); i++) {
				MonitorAtmCraDto row = rows.get(i);
				row.setErrorFlag(false);
				String flag = row.getDbAction().toString();
				if (flag.equals("a") && !(permMap.get("I") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for adding a record");
					isInvalidData = true;
				} else if (flag.equals("c") && !(permMap.get("U") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for updating a record");
					isInvalidData = true;
				} else if (flag.equals("d") && !(permMap.get("D") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for deleting a record");
					isInvalidData = true;
				}

				MonitorAtmCraDto model = new MonitorAtmCraDto();

				MonitorAtmCraId atmCraId = new MonitorAtmCraId();

				if (!flag.equals("d")) {
					if (row.getInstitutionId() != null && !row.getInstitutionId().equalsIgnoreCase("")
							&& row.getInstitutionId().trim().length() > 0)
						atmCraId.setInstitutionId(row.getInstitutionId().trim());
					else {
						row.setErrorFlag(true);
						row.setErrorMessage("Institution Id cannot be empty");
						isInvalidData = true;
					}
					if (row.getCraBranch() != null && !row.getCraBranch().equalsIgnoreCase("")
							&& row.getCraBranch().trim().length() > 0)
						atmCraId.setCraBranch(row.getCraBranch().trim());
					else {
						row.setErrorFlag(true);
						row.setErrorMessage("CRA Branch cannot be empty");
						isInvalidData = true;
					}
					row.setId(atmCraId);

					Object object = row.getId();
					if (object == null) {
						row.setErrorFlag(true);
						row.setErrorMessage("ID cannot be empty");
						isInvalidData = true;
						continue;
					}

					String address = row.getAddress();
					if (address != null && !address.isEmpty()) {
						if (address.length() > 100) {
							row.setErrorFlag(true);
							row.setErrorMessage("Address cannot be more than 100 characters");
							isInvalidData = true;
							continue;
						}
					}
					String country = row.getCountry();
					if (country != null && !country.isEmpty()) {
						if (country.length() > 50) {
							row.setErrorFlag(true);
							row.setErrorMessage("Country cannot be more than 50 characters");
							isInvalidData = true;
							continue;
						}
						if (!country.matches("^[a-zA-Z]+(?: [a-zA-Z]+)*$")) {
							row.setErrorFlag(true);
							row.setErrorMessage("Country can contain only letters");
							isInvalidData = true;
							continue;
						}
					}
					String city = row.getCity();
					if (city != null && !city.isEmpty()) {
						if (city.length() > 50) {
							row.setErrorFlag(true);
							row.setErrorMessage("City cannot be more than 50 characters");
							isInvalidData = true;
							continue;
						}
						if (!city.matches("^[a-zA-Z]+(?: [a-zA-Z]+)*$")) {
							row.setErrorFlag(true);
							row.setErrorMessage("City can contain only letters");
							isInvalidData = true;
							continue;
						}
					}
					String pincode = row.getPincode();
					if (pincode != null && !pincode.isEmpty()) {
						if (pincode.length() > 10) {
							row.setErrorFlag(true);
							row.setErrorMessage("Pincode cannot be more than 10 characters");
							isInvalidData = true;
							continue;
						}
						if (!pincode.matches("[0-9]+")) {
							row.setErrorFlag(true);
							row.setErrorMessage("Pincode can contain only numeric characters");
							isInvalidData = true;
							continue;
						}
					}
					String name = row.getName();
					if (name != null && !name.isEmpty()) {
						if (name.length() > 50) {
							row.setErrorFlag(true);
							row.setErrorMessage("Name cannot be more than 50 characters");
							isInvalidData = true;
							continue;
						}
						if (!name.matches("^[a-zA-Z]+(?: [a-zA-Z]+)*$")) {
							row.setErrorFlag(true);
							row.setErrorMessage("Name can contain only letters");
							isInvalidData = true;
							continue;
						}
					}
					String mobile = row.getMobile();
					if (mobile != null && !mobile.isEmpty()) {
						if (mobile.length() < 10 || mobile.length() > 15) {
							row.setErrorFlag(true);
							row.setErrorMessage(
									"Mobile number cannot be more than 15 characters and less than 10 characters");
							isInvalidData = true;
							continue;
						}
						if (!mobile.matches("^\\+?\\d*-?\\d*(?: )?\\d*")) {
							row.setErrorFlag(true);
							row.setErrorMessage(
									"Mobile number can contain only numeric characters including one +, one space and one -");
							isInvalidData = true;
							continue;
						}
					}
					String designation = row.getDesignation();
					if (designation != null && !designation.isEmpty()) {
						if (designation.length() > 50) {
							row.setErrorFlag(true);
							row.setErrorMessage("Designation cannot be more than 50 characters");
							isInvalidData = true;
							continue;
						}
					}
					String telephone = row.getTelephone();
					if (telephone != null && !telephone.isEmpty()) {
						if (telephone.length() < 10 || telephone.length() > 15) {
							row.setErrorFlag(true);
							row.setErrorMessage(
									"Telephone cannot be more than 15 characters and less than 10 characters");
							isInvalidData = true;
							continue;
						}
						if (!telephone.matches("^\\+?\\d*-?\\d*(?: )?\\d*")) {
							row.setErrorFlag(true);
							row.setErrorMessage(
									"Telephone number can contain only numeric characters including one +, one space and one - ");
							isInvalidData = true;
							continue;
						}
					}
					String email = row.getEmail();
					if (email != null && !email.isEmpty()) {
						if (email.length() > 30) {
							row.setErrorFlag(true);
							row.setErrorMessage("Email cannot be more than 30 characters");
							isInvalidData = true;
							continue;
						}
						String emailRegex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+(?:\\.[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+)*@[a-zA-Z0-9-]+(?:\\.[a-zA-Z-]+)*$";
						Pattern pattern = Pattern.compile(emailRegex);
						Matcher matcher = pattern.matcher(email);

						if (!matcher.matches()) {
							row.setErrorFlag(true);
							row.setErrorMessage(
									"Email can contain only letters, numbers, periods(.), hyphens(-), @, and underscores (_). Please enter a valid email. ");
							isInvalidData = true;
							continue;
						}
					}
				}

				model.setId(row.getId());
				String key = "" + model.getId();

				if (isMKCEnabled && isCheckerAction) {
					if (duplicateCollection.contains(key + row.getMkcStatus())
							&& AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())) {
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same Institution Id and CRA Branch"); // Duplicate
																											// record
																											// with same
																											// Institution
																											// Id and
																											// CRA
																											// Branch
						isInvalidData = true;
						continue;
					} else {
						duplicateCollection.add(key + row.getMkcStatus());
					}
				} else {
					if (!flag.equals("d")) {
						if (duplicateCollection.contains(key)) {
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same Institution Id and CRA Branch");
							isInvalidData = true;
							continue;
						} else {
							duplicateCollection.add(key);
						}
					}
				}

				if (isMKCEnabled && isCheckerAction) {
					if ("a".equals(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())
							&& dao.findById(model.getId()) != null) {
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same Institution Id and CRA Branch");
						isInvalidData = true;
						continue;
					}
				} else {
					if (flag.equals("a")) {
						if (dao.findById(model.getId()) != null) {
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same Institution Id and CRA Branch");
							isInvalidData = true;
							continue;
						}
					}
				}

				if (isMKCEnabled && isCheckerAction && AppConstants.MKC_SP_ACTION_REWORK.equals(row.getMkcStatus())
						&& "d".equalsIgnoreCase(flag)) {
					row.setErrorFlag(true);
					row.setErrorMessage("Deleted record cannot be set to rework");
					isInvalidData = true;
					continue;
				}

				if (isMKCEnabled && isCheckerAction && "d".equalsIgnoreCase(flag)
						&& AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())) {
					MonitorAtmCra monATMCra = dao.findById(model.getId());
					if (monATMCra == null) {
						row.setErrorFlag(true);
						row.setErrorMessage("The record is already deleted. Please reject the record.");
						isInvalidData = true;
						continue;
					}
					dao.getSession().evict(monATMCra);
				}
				corrCollection.add(row);
			}

			if (isInvalidData) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0106");
				return;
			}

			if (isMKCEnabled && !isCheckerAction) { // maker changes should go into the queue
				// insertCollectionIntoMKC(corrCollection, workRequest.getRequestTypeId(),
				// getUserId(userContext));
				for (EditableListRow edlsrow : corrCollection) {
					if (edlsrow != null) {
						MonitorAtmCraDto dto = (MonitorAtmCraDto) edlsrow;
						MKCHandler.getInstance().insertListRowIntoMKC(dto, dto.getId().toString(),
								workRequest.getRequestTypeId(), getUserId(userContext),
								MenuService.getModuleName(reqTypeId));
					}
				}
			} else {
				for (MonitorAtmCraDto dto : corrCollection) {
					String action = dto.getDbAction().toString();
					if (!isMKCEnabled) { // non mkc
						if ("c".equalsIgnoreCase(action)) {
							MonitorAtmCra monATMCra = dao.findById(dto.getId()); // error
							if (monATMCra != null) {
								dto.store(monATMCra);
								dao.attachDirty(monATMCra);
							}
						} else if ("a".equalsIgnoreCase(action)) {
							MonitorAtmCra monATMCra = new MonitorAtmCra();
							dto.store(monATMCra);
							dao.save(monATMCra);
						} else if ("d".equalsIgnoreCase(action)) {
							MonitorAtmCra monATMCra = new MonitorAtmCra();
							dto.store(monATMCra);
							dao.delete(monATMCra);
						}
					} else if (isMKCEnabled && isCheckerAction) { // MKC Checker
						String status = dto.getMkcStatus();
						if ((AppConstants.MKC_SP_ACTION_APPROVE).equals(status)) {
							if ("c".equalsIgnoreCase(action)) {
								MonitorAtmCra monATMCra = dao.findById(dto.getId());
								if (monATMCra != null) {
									dto.store(monATMCra);
									dao.attachDirty(monATMCra);
								}
							} else if ("a".equalsIgnoreCase(action)) {
								MonitorAtmCra monATMCra = new MonitorAtmCra();
								dto.store(monATMCra);
								dao.save(monATMCra);
							} else if ("d".equalsIgnoreCase(action)) {
								MonitorAtmCra monATMCra = new MonitorAtmCra();
								dto.store(monATMCra);
								dao.delete(monATMCra);
							}
							MKCHandler.getInstance().ApproveMKCRecord(dto.getMkcId(), getUserId(userContext),
									dto.getMkcRemarks(), dto.getMkcScheduleDt());
						} else if (AppConstants.MKC_SP_ACTION_REJECT.equals(status)
								|| AppConstants.MKC_SP_ACTION_REWORK.equals(status)) {
							MKCHandler.getInstance().RejectOrReturnRecord(dto.getMkcId(), getUserId(userContext),
									dto.getMkcRemarks(), dto.getMkcScheduleDt(), status);
						} else {
						}
					}
				}
			}
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_NONE);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_SUCCESS);
			workRequest.setErrorDetail("");
			rows.clear();
		} catch (Exception e) {
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail(e.getMessage());
			if (e instanceof ForeignKeysCheckException) {
				workRequest.setMessageSubstitutions(((ForeignKeysCheckException) e).getChildTables());
			}
		}
	}
}