package com.fis.ist.monitoring.dao;

import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.ATMAvailable;

@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class DataPointsDAO extends MonitorBaseDAO<ATMAvailable, Integer> {

	private static final ISTLogger log = ISTLogger.getLogger(DataPointsDAO.class);
	public static final String PRODUCT = "product";
	public static final String SITEID = "siteId";
	public static final String NODEID = "nodeId";
	public static final String DPENCASH = "DPENCASH";
	public static final String DPENCASH_COUNT = "DPENCASH_COUNT";
	public static final String DPDBSUM = "DPDBSUM";
	public static final String DPDBSUM_COUNT = "DPDBSUM_COUNT";
	public static final String DPCDSUM = "DPCDSUM";
	public static final String DPCDSUM_COUNT = "DPCDSUM_COUNT";
	
	public Integer getEnCashListCount() {
		log.debug("Identifying count for Data Points Encash ");

		String query = SqlQueryProvider.getDBSqlQuery("DPENCASH_COUNT");
		Query queryObject = getSession().createSQLQuery(query).addScalar("count", StandardBasicTypes.INTEGER);

		log.debug("Data Points Encash List Count query: " + queryObject.getQueryString());
		return (int) queryObject.uniqueResult();
	}

	public List getDataPointsEncashList() {
		List encashList = null;

		try {
			String queryString = SqlQueryProvider.getDBSqlQuery(DPENCASH);
			System.out.println("queryString " + queryString);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("instid", StandardBasicTypes.STRING)
					.addScalar("groupname", StandardBasicTypes.STRING).addScalar("atmunit", StandardBasicTypes.STRING)
					.addScalar("termid1", StandardBasicTypes.STRING).addScalar("time", StandardBasicTypes.STRING)
					.addScalar("location", StandardBasicTypes.STRING)
					.addScalar("geoLocation", StandardBasicTypes.STRING)
					.addScalar("AcceptorName", StandardBasicTypes.STRING).addScalar("Make", StandardBasicTypes.STRING)
					.addScalar("Currency", StandardBasicTypes.STRING)
					.addScalar("Hopper1_EndCash", StandardBasicTypes.STRING)
					.addScalar("Hopper2_EndCash", StandardBasicTypes.STRING)
					.addScalar("Hopper3_EndCash", StandardBasicTypes.STRING)
					.addScalar("Hopper4_EndCash", StandardBasicTypes.STRING);

			encashList = queryObject.list();

			return encashList;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}

	public Integer getDbSumListCount(String fromDate, String toDate, String fromDateFormate, String toDateFormate) {
		log.debug("Identifying count for Data Points Dbsum ");
		StringBuffer queryBuffer = new StringBuffer("select count(1) as count from  (");
		String queryAppend = SqlQueryProvider.getDBSqlQuery("DPDBSUM");
		queryBuffer.append(queryAppend);
		if (PaymonUtils.isOracleDb())
			queryBuffer.append(
					" processor_busday between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) group by txnsrc) ");
		else if (PaymonUtils.isPostgressDb())
			queryBuffer.append(
					" processor_busday between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) group by txnsrc) as dbcount");
		Query queryObject = getSession().createSQLQuery(queryBuffer.toString()).addScalar("count",
				StandardBasicTypes.INTEGER);
		Query queryObjectUpdated = setDPDBSUMQueryParams(queryObject, fromDate, toDate, fromDateFormate, toDateFormate);

		log.debug("Data Points Dbsum List Count query: " + queryObjectUpdated.getQueryString());
		return (int) queryObjectUpdated.uniqueResult();
	}

	public List getDataPointsDbSumList(String fromDate, String toDate, String fromDateFormate, String toDateFormate) {
		List dbsumList = null;

		try {
			String queryString = SqlQueryProvider.getDBSqlQuery(DPDBSUM);
			StringBuffer queryBuffer = new StringBuffer(queryString);

			if (PaymonUtils.isOracleDb())
				queryBuffer.append(
						" processor_busday between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) group by txnsrc ");
			else if (PaymonUtils.isPostgressDb())
				queryBuffer.append(
						" processor_busday between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) group by txnsrc ");
			queryString = queryBuffer.toString();
			Query queryObject = getSession().createSQLQuery(queryString);
			Query queryObjectUpdated = setDPDBSUMQueryParams(queryObject, fromDate, toDate, fromDateFormate,
					toDateFormate);
			dbsumList = queryObjectUpdated.list();
			return dbsumList;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}

	public Integer getCdSumListCount(String fromDate, String toDate, String fromDateFormate, String toDateFormate) {

		log.debug("Identifying count for Data Points Cdsum ");
		StringBuffer queryBuffer = new StringBuffer("select count(1) as count from  (");

		String queryAppend = SqlQueryProvider.getDBSqlQuery("DPCDSUM");
		queryBuffer.append(queryAppend);
		if (PaymonUtils.isOracleDb())
			queryBuffer.append(
					" processor_busday between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) group by txndest) ");
		else if (PaymonUtils.isPostgressDb())
			queryBuffer.append(
					" processor_busday between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) group by txndest) as cdcount ");
		Query queryObject = getSession().createSQLQuery(queryBuffer.toString()).addScalar("count",
				StandardBasicTypes.INTEGER);
		Query queryObjectUpdated = setDPDBSUMQueryParams(queryObject, fromDate, toDate, fromDateFormate, toDateFormate);
		return (int) queryObjectUpdated.uniqueResult();
	}

	public List getDataPointsCdSumList(String fromDate, String toDate, String fromDateFormate, String toDateFormate) {
		List cdsumList = null;

		try {
			String queryString = SqlQueryProvider.getDBSqlQuery(DPCDSUM);
			StringBuffer queryBuffer = new StringBuffer(queryString);
			if (PaymonUtils.isOracleDb())
				queryBuffer.append(
						" processor_busday between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) group by txndest ");
			else if (PaymonUtils.isPostgressDb())
				queryBuffer.append(
						" processor_busday between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) group by txndest");
			queryString = queryBuffer.toString();
			Query queryObject = getSession().createSQLQuery(queryString);
			Query queryObjectUpdated = setDPDBSUMQueryParams(queryObject, fromDate, toDate, fromDateFormate,
					toDateFormate);
			cdsumList = queryObjectUpdated.list();
			return cdsumList;
		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}

	private static Query setDPDBSUMQueryParams(Query queryObject, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate) {
		queryObject.setParameter("fromDate", fromDate);
		queryObject.setParameter("toDate", toDate);
		queryObject.setParameter("fromDateFormate", fromDateFormate);
		queryObject.setParameter("toDateFormate", toDateFormate);
		return queryObject;
	}

	public Class<ATMAvailable> getEntityClass() {
		return ATMAvailable.class;
	}

}
