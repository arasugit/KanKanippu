package com.fis.ist.monitoring.dto;

import com.fis.ist.monitoring.domain.POSTerminals;

public class POSMakewiseTxnsDto implements java.io.Serializable {
	
private static final long serialVersionUID = 646182332543081905L;
	
	private String posTerminalType;
	private Integer successfulTxnsCount;
	private Integer failureTxnsCount;
	
	public POSMakewiseTxnsDto() {
		super();
	}
		
	public String getPosTerminalType() {
		return posTerminalType;
	}
	public void setPosTerminalType(String posTerminalType) {
		this.posTerminalType = posTerminalType;
	}

	public Integer getSuccessfulTxnsCount() {
		return successfulTxnsCount;
	}
	public void setSuccessfulTxnsCount(Integer successfulTxnsCount) {
		this.successfulTxnsCount = successfulTxnsCount;
	}

	public Integer getFailureTxnsCount() {
		return failureTxnsCount;
	}
	public void setFailureTxnsCount(Integer failureTxnsCount) {
		this.failureTxnsCount = failureTxnsCount;
	}
	
}
