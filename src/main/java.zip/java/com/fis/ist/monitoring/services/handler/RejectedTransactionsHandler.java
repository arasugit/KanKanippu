package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.DateTimeRequestDto;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class RejectedTransactionsHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(RejectedTransactionsHandler.class);
	private static String reqTypeId = MonitorConstants.TRANS_STATS_REJC_REQ;
	private static String formAuthId = "TXNSRJ_REQ";

	public RejectedTransactionsHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getRejectedTransactions(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}


	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.TRANS_STATS_REJC_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.TRANS_STATS_REJC_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.TRANS_STATS_REJC_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.TRANS_STATS_REJC_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.TRANS_STATS_REJC_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();

			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load Rejected Transactions Count screen");

		String screenType = params.get("screenType");
		TransactionsDAO dao = new TransactionsDAO();
		List recordList = null;
		List<String> acqList = null;
		List<String> txnSrcList = null;
		List terminalList = null; // SQL#1
		List<String> issList = null;
		List txnDestList = null;
		List onusInstList = null; // SQL#3

		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		DateTimeRequestDto dateTimeRequest = PaymonUtils.getRequestedDateTime(params);

		acqList = new ArrayList<>();
		txnSrcList = new ArrayList<>();
		issList = new ArrayList<>();
		txnDestList = new ArrayList<>();

		// For Onus transaction - fetch from SQL#1 & SQL#3
		if (screenType.equalsIgnoreCase("TXNSRJ_REQ")) {
			terminalList = dao.getAcquirerTxnSRC("ISTSWT", "TERMINAL_INSTITUTION");
			onusInstList = dao.getAcquirerTxnSRC("ISTSWT", "ONUS_INSTITUTION");

			// Adding the records in the acqList & txnSrcList
			for (Iterator iterator = terminalList.iterator(); iterator.hasNext();) {
				Object[] object = (Object[]) iterator.next();
				acqList.add((String) object[1]);
				txnSrcList.add((String) object[0]);
			}

			for (Iterator iterator = onusInstList.iterator(); iterator.hasNext();) {
				Object[] object = (Object[]) iterator.next();
				issList.add((String) object[1]);
				txnDestList.add((String) object[0]);
			}
		}
		// For Acquiring transaction - fetch from SQL#5
		else if (screenType.equalsIgnoreCase("ACQUIRING"))
			txnDestList = dao.getAcquirerTxnDest("ISTSWT", "ACQUIRING_LIST");

		// For Issuing transaction - fetch from SQL#2
		else if (screenType.equalsIgnoreCase("ISSUING")) {
			terminalList = dao.getAcquirerTxnSRC("ISTSWT", "ISSUING_LIST");

			for (Iterator iterator = terminalList.iterator(); iterator.hasNext();) {
				Object[] object = (Object[]) iterator.next();
				acqList.add((String) object[1]);
				txnSrcList.add((String) object[0]);
			}
		}

		if (screenType.equalsIgnoreCase("TXNSRJ_REQ")) {
			if (needs_total) {
				total = dao.getRejectedTransactionsOnusCount(txnSrcList, txnDestList, screenType,
						dateTimeRequest.getFormattedFromDate(), dateTimeRequest.getFormattedToDate(),
						dateTimeRequest.getFromDbDateFormat(), dateTimeRequest.getToDbDateFormat());

			}
			recordList = dao.getRejectedTransactionsOnus(txnSrcList, txnDestList, screenType,
					dateTimeRequest.getFormattedFromDate(), dateTimeRequest.getFormattedToDate(),
					dateTimeRequest.getFromDbDateFormat(), dateTimeRequest.getToDbDateFormat(), pageNum);
		}

		if (screenType.equalsIgnoreCase("ACQUIRING")) {
			if (needs_total) {
				total = dao.getRejectedTransactionsCount(txnDestList, screenType,
						dateTimeRequest.getFormattedFromDate(), dateTimeRequest.getFormattedToDate(),
						dateTimeRequest.getFromDbDateFormat(), dateTimeRequest.getToDbDateFormat());
			}

			recordList = dao.getRejectedTransactions(txnDestList, screenType, dateTimeRequest.getFormattedFromDate(),
					dateTimeRequest.getFormattedToDate(), dateTimeRequest.getFromDbDateFormat(),
					dateTimeRequest.getToDbDateFormat(), pageNum);
		}

		if (screenType.equalsIgnoreCase("ISSUING")) {
			if (needs_total) {
				total = dao.getRejectedTransactionsCount(txnSrcList, screenType, dateTimeRequest.getFormattedFromDate(),
						dateTimeRequest.getFormattedToDate(), dateTimeRequest.getFromDbDateFormat(),
						dateTimeRequest.getToDbDateFormat());
			}

			recordList = dao.getRejectedTransactions(txnSrcList, screenType, dateTimeRequest.getFormattedFromDate(),
					dateTimeRequest.getFormattedToDate(), dateTimeRequest.getFromDbDateFormat(),
					dateTimeRequest.getToDbDateFormat(), pageNum);
		}

		if (recordList.size() == 0)
			log.debug("No records found !!!");

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}
		TransactionListRow dto = null;
		Object[] result = null;
		List<TransactionListRow> workRows = getTransactionList(workRequest, uiMetaData);
		for (int i = 0; i < recordList.size(); i++) {
			dto = new TransactionListRow();
			result = (Object[]) recordList.get(i);
			if (screenType.equalsIgnoreCase("ISSUING"))
				dto.loadTxnsIssuer(result);
			else
				dto.loadTxns(result);
			// System.out.println("dto ::"+dto);
			workRows.add(dto);
		}
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		return validateFields(fieldDataMap);
	}

	private List<TransactionListRow> getTransactionList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TRANS_STATS_REJC_COL);
		workCollection.setSectionId(MonitorConstants.TRANS_STATS_REJC_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TRANS_STATS_REJC_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionListRow> workRows = new ArrayList<TransactionListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TRANS_STATS_REJC_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}
