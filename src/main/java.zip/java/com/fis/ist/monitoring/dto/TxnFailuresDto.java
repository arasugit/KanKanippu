package com.fis.ist.monitoring.dto;

public class TxnFailuresDto {

	private Integer failureCount;
	private Integer successCount;
	public Integer getFailureCount() {
		return failureCount;
	}
	public void setFailureCount(Integer failureCount) {
		this.failureCount = failureCount;
	}
	public Integer getSuccessCount() {
		return successCount;
	}
	public void setSuccessCount(Integer successCount) {
		this.successCount = successCount;
	}
	
	
}
