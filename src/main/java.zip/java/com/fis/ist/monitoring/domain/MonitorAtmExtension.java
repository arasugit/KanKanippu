package com.fis.ist.monitoring.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "cs_monatm_ext",uniqueConstraints = @UniqueConstraint(columnNames = {
		"INSTITUTIONID", "GROUP_NAME", "UNIT","TERMID" }) )
public class MonitorAtmExtension {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private MonitorAtmExtentionId id;
		private String  siteName;
	private String  siteDesc;
	private String  siteType;
	private String  siteLocation;
	private String  address;
	private String  branchId;
	private String  branchName;
	private String  city;
	private String  state;
	private String  country;
	private String  latitude;
	private String  logitude;
	
    public MonitorAtmExtension() {}
    public MonitorAtmExtension(MonitorAtmExtentionId id, String siteName, String siteDesc, String siteType,
			String siteLocation, String address, String branchId, String branchName, String city, String state,
			String country, String latitude, String logitude) {
		this.id = id;
		this.siteName = siteName;
		this.siteDesc = siteDesc;
		this.siteType = siteType;
		this.siteLocation = siteLocation;
		this.address = address;
		this.branchId = branchId;
		this.branchName = branchName;
		this.city = city;
		this.state = state;
		this.country = country;
		this.latitude = latitude;
		this.logitude = logitude;
	}

   
    
    @EmbeddedId
	@AttributeOverrides( {
			@AttributeOverride(name = "institutionId", column = @Column(name = "INSTITUTIONID", length = 10)),
			@AttributeOverride(name = "groupName", column = @Column(name = "GROUP_NAME", length = 10)),
			@AttributeOverride(name = "unit", column = @Column(name = "UNIT", length = 38)),
			@AttributeOverride(name = "termId", column = @Column(name = "TERMID", length = 8))})
	public MonitorAtmExtentionId getId() {
		return this.id;
	}

	public void setId(MonitorAtmExtentionId id) {
		this.id = id;
	}
	
	
	@Column(name = "SITENAME", length = 30)
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	@Column(name = "SITEDESC", length = 50)
	public String getSiteDesc() {
		return siteDesc;
	}
	public void setSiteDesc(String siteDesc) {
		this.siteDesc = siteDesc;
	}
	@Column(name = "SITETYPE",  length = 10)
	public String getSiteType() {
		return siteType;
	}
	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}
	@Column(name = "SITELOCATION", length = 25)
	public String getSiteLocation() {
		return siteLocation;
	}
	public void setSiteLocation(String siteLocation) {
		this.siteLocation = siteLocation;
	}	
	@Column(name = "ADDRESS",  length = 100)
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Column(name = "BRANCHID",  length = 10)
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	@Column(name = "BRANCHNAME", length = 30)
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	@Column(name = "CITY",  length = 50)
	public String getCity() {
		return city;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	@Column(name = "STATE", length = 50)
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Column(name = "COUNTRY", length = 25)
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	@Column(name = "LATITUDE", length = 10)
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	@Column(name = "LONGITUDE", length = 10)
	public String getLogitude() {
		return logitude;
	}
	public void setLogitude(String logitude) {
		this.logitude = logitude;
	}
	
	

}
