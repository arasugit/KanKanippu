package com.fis.ist.monitoring.cfg;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.util.Properties;
import java.util.Vector;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.util.PropertyPlaceholderHelper;
import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.log.ISTLogger;

public class PaymonConfigurer extends PropertyPlaceholderConfigurer{
	private static final ISTLogger log = ISTLogger.getLogger(PaymonConfigurer.class);
	private static final String fileName = "sql_postgress.properties";
	private PropertyPlaceholderHelper pph = new PropertyPlaceholderHelper("${","}");
	private static final String separator = "/";
	public PaymonConfigurer()
	{
		this(null);
	}
	public PaymonConfigurer(Properties init_props)
	{
		if (init_props == null)
			init_props = new Properties();
		if (log.isDebugEnabled())
			log.debug("init props:" + init_props);
		setLocalOverride(true);
		setProperties(init_props);

		Vector<Resource> resources = new Vector<Resource>();
		Resource res = new ClassPathResource(fileName);
		if (res.exists())
			resources.add(res);
		else
			log.debug("Did not find " + fileName + "in the classpath");

		String p = init_props.getProperty("ist.protected_directory_path");
		try
		{
			p = ESAPI.validator().getValidInput("protected directory", p, "DirectoryName", 255, true);
		}
		catch (ValidationException e1)
		{
			log.error(e1, e1);
		}
		catch (IntrusionException e1)
		{
			log.error(e1, e1);
		}
		res = null;
		if (p != null){
			String sdir =""; 		
			String arr[]=p.split(separator);
			for(int i=0;i<arr.length;i++){
				if((i==0 && StringUtil.isEmpty(arr[i])) || (i==arr.length-2)){
					continue;
				}
				if((i==0 && StringUtil.isNotEmpty(arr[i]))){
					sdir+=arr[i];
				}else{			
					sdir+=separator+arr[i];
				}
			}
			if(StringUtil.isNotEmpty(sdir)){
				log.debug("Looking for " + fileName + " in " + sdir);
				URI uri = (new File(sdir)).toURI();
				uri = uri.resolve(fileName);
				try{
					UrlResource ur = new UrlResource(uri);
					if (ur.exists() && ur.isReadable())
						res = ur;
				}
				catch (MalformedURLException e) { 
					log.error("Bad Shared protected directory path", e);
				}
			}
			if (res == null)
				log.debug("Did not find " + fileName + " in the Shared protected directory");
			else
				resources.add(res);    	
		}   
		res = null;
		if (p != null)
		{
			log.debug("Looking for " + fileName + " in " + p);
			URI uri = (new File(p)).toURI();
			uri = uri.resolve(fileName);
			try
			{
				UrlResource ur = new UrlResource(uri);
				if (ur.exists() && ur.isReadable())
					res = ur;
			}
			catch (MalformedURLException e)
			{ 
				log.error("Bad protected directory path", e);
			}
		}
		if (res == null)
			log.debug("Did not find " + fileName + " in the protected directory");
		else
			resources.add(res);

		if (resources.isEmpty())
			log.error("Did not find "+ fileName);
		else
			setLocations(resources.toArray(new Resource[0]));
	}

	private Properties mergedProps = null;
	protected Properties mergeProperties() throws IOException
	{
		if (mergedProps == null)
			mergedProps = super.mergeProperties();
		return (Properties)mergedProps.clone();
	}
	
	private Properties sourceProps = null;
	protected String convertPropertyValue(String originalValue)
	{
		originalValue = originalValue.trim();
		if (sourceProps == null)
			return originalValue;
		return pph.replacePlaceholders(originalValue, sourceProps);
	}
	public Properties getIstProperties() throws IOException
	{
		Properties ret = mergeProperties();
		sourceProps = ret;
		convertProperties(ret);
		sourceProps = null;
		return ret;
	}



}
