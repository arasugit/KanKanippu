package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.ForeignKeysCheckException;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MKCHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.MonATMExtDAO;
import com.fis.ist.monitoring.domain.ATMExtId;
import com.fis.ist.monitoring.domain.MonATMExt;
import com.fis.ist.monitoring.dto.MonATMExtDto;
import com.fis.ist.services.MenuService;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.EditableListRow;
import com.fis.ist.services.vo.WorkRequest;

public class MonATMExtHandler extends ISTRequestHandler implements ISimpleListHandler  {	
	
	private static final ISTLogger log = ISTLogger.getLogger(MonATMExtHandler.class);
	private static String reqTypeId = MonitorConstants.MONATMEXT;
	private static String formAuthId = "MONATMEXT";
	public MonATMExtHandler(){
		checkMKCEnabled(formAuthId);
	}

	public MonATMExtHandler(String formAuthIdVar){
		formAuthId = formAuthIdVar;
		reqTypeId = formAuthIdVar;
		checkMKCEnabled(formAuthIdVar);
	}
	
	public WorkRequest getMonAtmExt(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}
		

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData,MonitorConstants.MONATMEXTTAB);
	}
		
	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params ) throws Exception{
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.MONATMEXT);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.MONATMEXT);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.MONATMEXTTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.MONATMEXTTAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("MonAtmExtHandler - Load Mon Global Value Details");
		String productId = params.get("productId");
		log.debug("productId" + productId);
		String siteId = params.get("siteId");
		log.debug("siteId" + siteId);
		String nodeId = params.get("nodeId");
		log.debug("nodeId" + nodeId);
		
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
				
		int total = 0;

		String termId = params.get("termId");
		if(termId != null || termId != "") {
			termId = termId.trim();
		}
		
		List<MonATMExt> results = new ArrayList<MonATMExt>();

		MonATMExt findRecord = new MonATMExt();
		
		if(StringUtil.isNotEmpty(termId)){
			try{
				findRecord.setTermId(StringUtils.rightPad(termId, 16));
			}catch (NumberFormatException nfe) {
				log.debug("Invalid Product ["+termId+"]", nfe);
			}
		}
		
		if (!needs_total) {
			results = loadMonATMExtListData(findRecord, pageNum);
		} else if (needs_total) {
			total = loadMonATMExtListDataCount(findRecord);
			results = loadMonATMExtListData(findRecord, pageNum);
		}
		
		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}
		
		UIMetaData uiMetaData=null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		}
		catch (Exception e){
			log.error("unable to get the Meta data"+e.getMessage());
		}
		
		List<MonATMExtDto> workRows= getNewWorkMonATMExtRows(workRequest, uiMetaData);

		if (results == null || results.size() == 0) {
			return;
		}
		
		for (MonATMExt monAtmExtdto: results) {
			if(monAtmExtdto != null){
				MonATMExtDto dto = new MonATMExtDto();
				dto.load(monAtmExtdto);
				dto.setDbAction('x');
				if (isMKCEnabled){
					dto.setOrignalRow(dto);
				}
				workRows.add(dto);
			}
		}
  }	
	
	/**
	 *
	 * @param WorkRequest
	 * @param UserContext
	 * @param UIMetaData
	 * @param WorkRequestHandlerData
	 * @param params
	 * @return WorkRequest
	 */
	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
			throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(
						WorkRequestHandlerData.RequestMode.ADD_NEW,
						workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null
					|| workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag =validateQueryFields(params,workRequest);
			if (errFlag)
			{
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		} 
		return workRequest;
	}
	
	
	private Boolean validateQueryFields(Map<String, String> params,WorkRequest workReq) throws Exception{
		Map<String, WorkField> fields = workReq.getFields();
		Map <WorkField,String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue="";
		WorkField currentfield = null;


		currentfield = fields.get("productId");
		fieldValue = params.get("productId");
		fieldDataMap.put(currentfield,fieldValue);

		currentfield = fields.get("siteId");
		fieldValue = params.get("siteId");
		fieldDataMap.put(currentfield,fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield,fieldValue);

		return validateFields(fieldDataMap);
	}
	
		
	public HashMap<String,String> getDBMapping()
	{
		HashMap<String,String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product","product");
		dtoMapping.put("nodeId","nodeId");
		dtoMapping.put("taskName","taskName");
		dtoMapping.put("taskType","taskType");
		dtoMapping.put("pId","pId");
		return dtoMapping;
	}
	
	private List<MonATMExtDto> getNewWorkMonATMExtRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.MONATMEXTCOL);
		workCollection.setSectionId(MonitorConstants.MONATMEXTSEC);
        workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.MONATMEXTTAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<MonATMExtDto> workRows = new ArrayList<MonATMExtDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.MONATMEXTCOL);
		workCollection.setRows(workRows);
		return workRows;
	}
	
	
	private List<MonATMExt> loadMonATMExtListData(MonATMExt model, int pageNum) {
		log.debug("MonAtmExtHandler - Load MonAtmExt records - loadMonATMExtListData()");
		MonATMExtDAO dao = new MonATMExtDAO();
		List<MonATMExt> results = dao.findByExample(model, pageNum);

		return results;
	}
	
	private int loadMonATMExtListDataCount(MonATMExt model) {
		log.debug("MonAtmExtHandler - Load MonAtmExt records - loadMonATMExtListDataCount()");
		MonATMExtDAO dao = new MonATMExtDAO();
		int count = dao.getTotalByExample(model);
		return count;
	}
	
	public WorkRequest getDataForAdd(UserContext userContext,
			WorkRequest workRequest) throws Exception {
		if (workRequest != null) {
			WorkCollection wc = workRequest.getCollections().get(MonitorConstants.MONATMEXTCOL);
			wc.getRows().add(0, getNewMONATMEXTRowInstance());
			return workRequest;
		} else {
			WorkRequest workReq = new WorkRequest();
			UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.MONATMEXT);
			
			try {
				workReq.setRequestId("0");
				workReq.setRequestState("DRAFT");
				
				workReq.setRequestTypeId(MonitorConstants.MONATMEXT);
				
				Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
				workReq.setNextStates(nextStates);
				
				// Set values of all tabs to be modifiable
				Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
				WorkTabStatus workStatus = new WorkTabStatus();
				workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
				workStatus.setTag(MonitorConstants.MONATMEXTTAB);
				workStatus.setModifyable("Y");
				tabStatus.put(MonitorConstants.MONATMEXTTAB, workStatus);
				
				workReq.setTabStatus(tabStatus);
				
				addWorkFields(workReq, uiMetaData);
				
				workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null);
								
				Map<String, WorkField> fields = workReq.getFields();
				Collection<WorkField> cfields = fields.values();
				
				for (WorkField field : cfields) {
					field.setModifyable("Y");
					field.setVisible("Y");
				}
				
			} catch (Exception ex) {
		      	  WorkRequestHelper.getInstance().reportException(log, ex, workReq);
			}
			return workReq;
		}
	}
	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext,
											UIMetaData uiMetaData, WorkRequestHandlerData data) throws Exception {
		try {
			
			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW,
													workRequest, userContext);
				
				data.setUiMetaData(uiMetaData);
				data.initLastModified();
				
				if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
					workRequest.setSwitchId(userContext.getSwitchID());
				}
				
				// Create a logical collection for add
				List<MonATMExtDto> workRows = getNewWorkMONATMEXTRows(workRequest, uiMetaData);
				workRows.add(getNewMONATMEXTRowInstance());
			}
			
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}
	
	private MonATMExtDto getNewMONATMEXTRowInstance() {
		MonATMExtDto dto = new MonATMExtDto();
		dto.setDbAction('a');
		return dto;
	}
	
	private List<MonATMExtDto> getNewWorkMONATMEXTRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.MONATMEXTCOL);
		workCollection.setSectionId(MonitorConstants.MONATMEXTSEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.MONATMEXTTAB);
		
		workRequest.getCollections().put(workCollection.getTag(), workCollection);
		
		List<MonATMExtDto> workRows = new ArrayList<MonATMExtDto>();
		
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.MONATMEXTCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	
	public WorkRequest saveSinglePageRecords(UserContext userContext, WorkRequest workRequest,HashMap<String,Boolean> permMap) {
		try {
			workRequest = saveWorkRequest(userContext,workRequest,permMap);
		}catch (Exception e){
			log.error("Exception occured in the Save Single Pags Records"+e.getMessage());
		}
		return workRequest;
	}
	
	public WorkRequest saveWorkRequest(UserContext userContext,
			WorkRequest workRequest,HashMap<String, Boolean> permMap) throws Exception{
		if (validateCollectionField(workRequest,MonitorConstants.MONATMEXTCOL))
			return workRequest;

		save(userContext, workRequest,permMap);
		return workRequest;
	}
	
	private void save(UserContext userContext, WorkRequest workRequest, HashMap<String, Boolean> permMap) {
		// check if contact field data is present
		try{
			Map<String, WorkField> fields = workRequest.getFields();
			if (fields == null) {
				WorkRequestHelper.getInstance().reportError("Work fields not found", workRequest);
				return;
			}

			boolean isInvalidData = false;
			String value = null;
			List<MonATMExtDto> corrCollection = new ArrayList<MonATMExtDto>();
			List<String> duplicateCollection = new ArrayList<String>();
			MonATMExtDAO dao = new MonATMExtDAO();
			WorkCollection wc = workRequest.getCollections().get(MonitorConstants.MONATMEXTCOL);
			List<MonATMExtDto> rows = wc.getRows();

			for(int i = 0; i < rows.size();i++){
				MonATMExtDto row = rows.get(i);
				row.setErrorFlag(false);
				String flag = row.getDbAction().toString();
				if(flag.equals("a")  &&!(permMap.get("I") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for adding a record");
					isInvalidData = true;
				}else if(flag.equals("c") && !(permMap.get("U") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for updating a record");
					isInvalidData = true;
				}else if(flag.equals("d") && !(permMap.get("D") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for deleting a record");
					isInvalidData = true;
				}

				MonATMExtDto model = new MonATMExtDto();

				// Setting Id irrespective of the type flag
				ATMExtId atmExtId = new ATMExtId();
				atmExtId.setGroupName(row.getGroupName());
				atmExtId.setInstId(row.getInstId());
				atmExtId.setUnit(row.getUnit());
				row.setId(atmExtId);
				
				Object object = row.getId();
				if(object == null){
					row.setErrorFlag(true);
					row.setErrorMessage("ID cannot be empty");
					isInvalidData = true;
					continue;
				}
				model.setId(row.getId());
				String key = ""+model.getId();

				if (isMKCEnabled && isCheckerAction){
					if(duplicateCollection.contains(key+row.getMkcStatus()) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())){
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same same ID");
						isInvalidData = true;
						continue;
					}else{
						duplicateCollection.add(key+row.getMkcStatus());
					}
				}else{
					if(!flag.equals("d")){
						if(duplicateCollection.contains(key)){
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same ID");
							isInvalidData = true;
							continue;
						}else{
							duplicateCollection.add(key);
						}
					}
				}

				if (isMKCEnabled && isCheckerAction){
					if("a".equals(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus()) && dao.findById(model.getId()) != null){
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same ID");
						isInvalidData = true;
						continue;
					}
				}else{
					if(flag.equals("a")){
						if(dao.findById(model.getId()) != null){
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same ID");
							isInvalidData = true;
							continue;
						}
					}
				}

				if (isMKCEnabled && isCheckerAction && AppConstants.MKC_SP_ACTION_REWORK.equals(row.getMkcStatus()) && "d".equalsIgnoreCase(flag)){
					row.setErrorFlag(true);
					row.setErrorMessage("Deleted record cannot be set to rework");
					isInvalidData = true;
					continue;
				}

				if(isMKCEnabled && isCheckerAction && "d".equalsIgnoreCase(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())){
					MonATMExt monATMExt = dao.findById(model.getId());
					if (monATMExt == null) {
						row.setErrorFlag(true);
						row.setErrorMessage("The record is already deleted. Please reject the record.");
						isInvalidData = true;
						continue;
					}
					dao.getSession().evict(monATMExt);
				}
				corrCollection.add(row);
			}
			
			if(isInvalidData){
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0106");
				return;
			}
			
			if(isMKCEnabled && !isCheckerAction){ // maker changes should go into the queue
				for (EditableListRow edlsrow : corrCollection) {
					if (edlsrow!=null){
						MonATMExtDto dto = (MonATMExtDto)edlsrow;
						MKCHandler.getInstance().insertListRowIntoMKC(dto, dto.getId().toString(), workRequest.getRequestTypeId(), getUserId(userContext), MenuService.getModuleName(reqTypeId));
					}
				}
			}else{
				for(MonATMExtDto dto:corrCollection)
				{
					String action = dto.getDbAction().toString();
					if(!isMKCEnabled){ // non mkc
						if("c".equalsIgnoreCase(action))
						{
							MonATMExt monATMExt = dao.findById(dto.getId()); // error
							if(monATMExt != null){
								dto.store(monATMExt);
								dao.attachDirty(monATMExt);
							}
						}else if("a".equalsIgnoreCase(action)){
							MonATMExt monATMExt = new MonATMExt();
							dto.store(monATMExt);
							dao.save(monATMExt);
						}else if("d".equalsIgnoreCase(action)){
							MonATMExt monATMExt = new MonATMExt();
							dto.store(monATMExt);
							dao.delete(monATMExt);
						}
					}else if (isMKCEnabled && isCheckerAction){ // MKC Checker
						String status = dto.getMkcStatus();
						if((AppConstants.MKC_SP_ACTION_APPROVE).equals(status)){
							if ("c".equalsIgnoreCase(action)) {
								MonATMExt monATMExt = dao.findById(dto.getId());
								if(monATMExt != null){
									dto.store(monATMExt);
									dao.attachDirty(monATMExt);
								}
							} else if ("a".equalsIgnoreCase(action)) {
								MonATMExt monATMExt = new MonATMExt();
								dto.store(monATMExt);
								dao.save(monATMExt);
							} else if ("d".equalsIgnoreCase(action)) {
								MonATMExt monATMExt = new MonATMExt();
								dto.store(monATMExt);
								dao.delete(monATMExt);
							}
							MKCHandler.getInstance().ApproveMKCRecord(dto.getMkcId(),getUserId(userContext),dto.getMkcRemarks(),dto.getMkcScheduleDt());
						}else if(AppConstants.MKC_SP_ACTION_REJECT.equals(status) || AppConstants.MKC_SP_ACTION_REWORK.equals(status)){
							MKCHandler.getInstance().RejectOrReturnRecord(dto.getMkcId(),getUserId(userContext),dto.getMkcRemarks(),dto.getMkcScheduleDt(),status);
						}else{
						}
					}
				}
			}
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_NONE);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_SUCCESS);
			workRequest.setErrorDetail("");
			rows.clear();
		}catch (Exception e){
		   workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
           workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
           workRequest.setErrorDetail(e.getMessage());
   		   if(e instanceof ForeignKeysCheckException){
			   workRequest.setMessageSubstitutions(((ForeignKeysCheckException)e).getChildTables());				  
		   }
		}
	}
}
