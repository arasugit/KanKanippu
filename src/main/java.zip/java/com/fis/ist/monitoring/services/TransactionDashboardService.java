package com.fis.ist.monitoring.services;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.services.handler.TransactionDashboardHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

public class TransactionDashboardService extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(TransactionDashboardService.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		TransactionDashboardHandler aah = new TransactionDashboardHandler();

		HttpServletRequest request = HTTPRequestGetter.getRequest();
		String productId = (String) request.getSession(false).getAttribute("product_id");
		// If node name contains all manipulate the string... () & put IN clause in the
		// DAO
		String nodeName = (String) request.getSession(false).getAttribute("node_name");
		if (nodeName.contains("All Nodes")) {
			int startParentheses = nodeName.indexOf("(");
			int endParentheses = nodeName.indexOf(")");

			if (startParentheses != -1 && endParentheses != -1 && endParentheses > startParentheses) {
				String allNodeNames = nodeName.substring(startParentheses + 1, endParentheses);
				allNodeNames = allNodeNames.trim();

				requestParams.put("nodeId", nodeName == null ? "*" : allNodeNames);
			}
		} else {
			requestParams.put("nodeId", nodeName == null ? "*" : nodeName);
		}
		requestParams.put("product", productId == null ? "" : productId);

		if (action.compareTo(MonitorConstants.ACTION_QUERY) == 0) {
			workReq = aah.getDashboardWorkRequest(userContext, requestParams);
		} else {
			log.error("**** Transaction Dashboard Service: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}
		
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}
}
