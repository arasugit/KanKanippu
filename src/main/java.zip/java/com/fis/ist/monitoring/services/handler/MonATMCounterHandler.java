package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.MonAtmCounterDAO;
import com.fis.ist.monitoring.domain.MonAtmCounter;
import com.fis.ist.monitoring.dto.ATMCounterDto;
import com.fis.ist.monitoring.dto.DateTimeRequestDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class MonATMCounterHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(MonATMCounterHandler.class);
	private static String reqTypeId = MonitorConstants.ATM_COUNTER_REQ;
	private static String formAuthId = "MONATMCOUN";

	public MonATMCounterHandler() {
		checkMKCEnabled(formAuthId);
	}

	// Get ATM Transaction History
	public WorkRequest getATMCounter(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}


	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.ATM_COUNTER_TAB);
	}


	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.ATM_COUNTER_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.ATM_COUNTER_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.ATM_COUNTER_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.ATM_COUNTER_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load ATM Counter Screen");

		String institutionId = params.get("institutionId").trim();
		String groupName = params.get("groupName").trim();
		String unit = params.get("unit").trim();
		String terminalId = params.get("terminalId").trim();

		MonAtmCounterDAO dao = new MonAtmCounterDAO();

		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		// ist_page_ctrl will contain the page number and according the records
		// will be fetched based on the pagesize and sent to the client.
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		List<MonAtmCounter> recordList = null;
		DateTimeRequestDto dateTimeRequestDto = PaymonUtils.getRequestedDateTime(params);

		recordList = dao.getAtmCounterDetails(dateTimeRequestDto.getFormattedFromDate(),
				dateTimeRequestDto.getFormattedToDate(), dateTimeRequestDto.getFromDbDateFormat(),
				dateTimeRequestDto.getToDbDateFormat(), institutionId, groupName, unit, terminalId, pageNum, true);

		if (needs_total) {
			total = recordList.size();
		}

		if (recordList.size() == 0) {
			log.debug("No records found !!!");
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		ATMCounterDto totalsDto = null;
		List<ATMCounterDto> workRows = getAtmCounterList(workRequest, uiMetaData);
		if (recordList != null) {
			for (MonAtmCounter atmCounter : recordList) {
				totalsDto = new ATMCounterDto();
				totalsDto.load(atmCounter);
				workRows.add(totalsDto);
			}
		}
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {
			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);
			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		return validateFields(fieldDataMap);
	}

	private List<ATMCounterDto> getAtmCounterList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.ATM_COUNTER_COL);
		workCollection.setSectionId(MonitorConstants.ATM_COUNTER_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.ATM_COUNTER_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<ATMCounterDto> workRows = new ArrayList<ATMCounterDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.ATM_COUNTER_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}
