package com.fis.ist.monitoring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.NotificationDao;
import com.fis.ist.monitoring.domain.Notification;
import com.fis.ist.monitoring.dto.NotificationDto;
import com.fis.ist.monitoring.services.NotificationService;
import com.fis.ist.spring.HTTPRequestGetter;

@RestController
public class NotificationController {
	private static final ISTLogger log = ISTLogger.getLogger(NotificationController.class);
	@Autowired
	private NotificationService service;

	@GetMapping("/notification")
	public List<NotificationDto> getNotifications() {
		log.info(" NotificationController getNotifications ");
		Notification notification = new Notification();
		String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");
		notification.setProduct(productId);
		log.info(" NotificationController getNotifications End");
		return service.getNotifications(notification);
	}

	@PostMapping("/notification")
	public List<NotificationDto> getNotificationPost() {
		Notification notification = new Notification();
		String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");
		notification.setProduct(productId);
		return service.getNotifications(notification);
	}

}
