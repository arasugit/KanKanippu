package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.TPSTxnDTO;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class TransactionsPerSecondHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(TransactionsPerSecondHandler.class);
	private static String reqTypeId = MonitorConstants.TRANS_TPS_REQ;
	private static String formAuthId = "TXNTPS_REQ";

	public TransactionsPerSecondHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getTransactionsPerSecond(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	
	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.TRANS_TPS_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.TRANS_TPS_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.TRANS_TPS_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.TRANS_TPS_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.TRANS_TPS_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();

			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load Transactions Per Second Handler ..");
		String screenType = params.get("screenType");
		// For pagination
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		// ist_page_ctrl will contain the page number and according the records
		// will be fetched based on the pagesize and sent to the client.
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;
		List recordList = null;
		TransactionsDAO dao = new TransactionsDAO();

		if (("AVERAGE-TPS").equalsIgnoreCase(screenType)) {
			if (!needs_total) {
				recordList = dao.getAverageTPS(screenType, pageNum);
			} else if (needs_total) {
				total = dao.getAverageTPSCount(screenType, pageNum);
				recordList = dao.getAverageTPS(screenType, pageNum);
			}
		} else if (("CURRENT-TPS").equalsIgnoreCase(screenType)) {
			if (!needs_total) {
				recordList = dao.getCurrentTPSUsage(screenType, pageNum);
			} else if (needs_total) {
				total = dao.getCurrentTPSUsageCount(screenType, pageNum);
				recordList = dao.getCurrentTPSUsage(screenType, pageNum);
			}
		} else if (("TODAY-TPS").equalsIgnoreCase(screenType)) {
			if (!needs_total) {
				recordList = dao.getTodayTPSUsage(pageNum);
			} else if (needs_total) {
				total = dao.getTodayTPSUsageCount(screenType, pageNum);
				recordList = dao.getTodayTPSUsage(pageNum);
			}
		} else if (("INST-AVERAGE-TPS").equalsIgnoreCase(screenType)) {
			if (!needs_total) {
				recordList = dao.getInstAverageTPS(screenType, pageNum);
			} else if (needs_total) {
				total = dao.getInstAverageTPSCount(screenType, pageNum);
				recordList = dao.getInstAverageTPS(screenType, pageNum);
			}
		} else if (("INST-CURRENT-TPS").equalsIgnoreCase(screenType)) {
			if (!needs_total) {
				recordList = dao.getInstCurrentTPSUsage(screenType, pageNum);
			} else if (needs_total) {
				total = dao.getInstCurrentTPSUsageCount(screenType, pageNum);
				recordList = dao.getInstCurrentTPSUsage(screenType, pageNum);
			}
		} else if (("INST-TODAY-TPS").equalsIgnoreCase(screenType)) {
			if (!needs_total) {
				recordList = dao.getInstTodayTPSUsage(pageNum);
			} else if (needs_total) {
				total = dao.getInstTodayTPSUsageCount(screenType, pageNum);
				recordList = dao.getInstTodayTPSUsage(pageNum);
			}
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}
		TPSTxnDTO dto = null;
		Object[] result = null;
		List<TPSTxnDTO> workRows = getTransactionList(workRequest, uiMetaData);
		if(recordList != null) {
			for (int i = 0; i < recordList.size(); i++) {
				dto = new TPSTxnDTO();
				if(("AVERAGE-TPS").equalsIgnoreCase(screenType) || ("TODAY-TPS").equalsIgnoreCase(screenType)) {
					result = (Object[]) recordList.get(i);
					dto.loadAvgTPS(result);
				} else if (("INST-AVERAGE-TPS").equalsIgnoreCase(screenType)
						|| ("INST-TODAY-TPS").equalsIgnoreCase(screenType)
						|| ("INST-CURRENT-TPS").equalsIgnoreCase(screenType)) {
					result = (Object[]) recordList.get(i);
					dto.loadInstTPS(result);
				} else {
					String resultRow = (String) recordList.get(i);
					dto.loadCurrentTPS(resultRow);
				}
				workRows.add(dto);
				// System.out.println("workRows :: "+workRows);
			}
		} else {
			log.debug("Record List is null no records found !!!");
		}
	}

	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;
		return validateFields(fieldDataMap);
	}

	private List<TPSTxnDTO> getTransactionList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TRANS_TPS_COL);
		workCollection.setSectionId(MonitorConstants.TRANS_TPS_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TRANS_TPS_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TPSTxnDTO> workRows = new ArrayList<TPSTxnDTO>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TRANS_TPS_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}
