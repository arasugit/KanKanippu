package com.fis.ist.monitoring.domain;

public class TerminalsBySite implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private String siteType;
	private String upPercentage;
	private String downPercentage;
	
	public String getSiteType() {
		return siteType;
	}
	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}
	
	public String getUpPercentage() {
		return upPercentage;
	}
	public void setUpPercentage(String upPercentage) {
		this.upPercentage = upPercentage;
	}
	public String getDownPercentage() {
		return downPercentage;
	}
	public void setDownPercentage(String downPercentage) {
		this.downPercentage = downPercentage;
	}
	
	@Override
	public String toString() {
		return "TerminalsBySite [siteType=" + siteType + ", upPercentage=" + upPercentage + ", downPercentage="
				+ downPercentage + "]";
	}
}
