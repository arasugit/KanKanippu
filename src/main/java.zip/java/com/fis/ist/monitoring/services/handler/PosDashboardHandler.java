package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.PosTerminalDao;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.Pair;
import com.fis.ist.monitoring.dto.PosDashboardDto;
import com.fis.ist.monitoring.dto.Triplet;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class PosDashboardHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(PosDashboardHandler.class);
	private static String reqTypeId = MonitorConstants.POS_DASHBOARD_REQ;
	private static String formAuthId = "POSDASH";

	public PosDashboardHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getDashboardWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load PosDashboardHandler ....");

		TransactionsDAO dao = new TransactionsDAO();
		PosTerminalDao terminalDao = new PosTerminalDao();
		UIMetaData uiMetaData = null;

		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List<PosDashboardDto> data = new ArrayList<PosDashboardDto>();
		List<Pair<String, Integer>> merchants = dao.getMerchantCountGroupedByInstitution();
		List<Triplet<String, Integer, Integer>> terminals = terminalDao.getTermianlCountGroupedByInstitution();

		merchants.forEach(x -> {
			PosDashboardDto dto = new PosDashboardDto();
			dto.setInstitutionId(x.getKey().trim());
			dto.setMerchantCount(x.getValue());
			data.add(dto);
		});

		terminals.forEach(x -> {
			PosDashboardDto dto = data.stream().filter(r -> x.getKey().equalsIgnoreCase(r.getInstitutionId().trim()))
					.findAny().orElse(null);

			if (dto == null) {
				dto = new PosDashboardDto();
				dto.setInstitutionId(x.getKey().trim());
				data.add(dto);
			}

			dto.setFunctionalTerminalCount(x.getValue1());
			dto.setNonfunctionalTerminalCount(x.getValue2());
			dto.setTerminalCount(x.getValue1() + x.getValue2());
		});

		List<PosDashboardDto> workRows = prepareWorkCollection(workRequest, uiMetaData);

		if (data.size() == 0) {
			workRequest.setLastModified(-1L);
			return;
		}

		workRequest.setLastModified((long) data.size());
		workRows.addAll(data);
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		return validateFields(fieldDataMap);
	}

	private List<PosDashboardDto> prepareWorkCollection(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.POS_DASHBOARD_COL);
		workCollection.setSectionId(MonitorConstants.POS_DASHBOARD_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.POS_DASHBOARD_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<PosDashboardDto> workRows = new ArrayList<PosDashboardDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.POS_DASHBOARD_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.POS_DASHBOARD_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.POS_DASHBOARD_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.POS_DASHBOARD_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.POS_DASHBOARD_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.POS_DASHBOARD_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}
}
