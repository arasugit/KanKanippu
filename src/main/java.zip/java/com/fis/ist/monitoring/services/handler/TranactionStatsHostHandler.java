package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.services.MonitorConfigService;
import com.fis.ist.monitoring.dao.TransactionDetailsDAO;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.monitoring.dto.TransactionStatisticsListItem;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class TranactionStatsHostHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(TranactionStatsHostHandler.class);
	private static String reqTypeId = MonitorConstants.TRANS_STATS_HOST_REQ;
	private static String formAuthId = "TXNSHT_REQ";

	public TranactionStatsHostHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getHostTransactions(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}


	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.TRANS_STATS_HOST_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.TRANS_STATS_HOST_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.TRANS_STATS_HOST_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.TRANS_STATS_HOST_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.TRANS_STATS_HOST_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Transaction Stats Host Handler ");
		String screenType = params.get("screenType");
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		String isTxnDetailReq = params.get("isTxnDetailReq");
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		TransactionsDAO dao = new TransactionsDAO();

		List terminalList = dao.getAcquirerTxnSRC("ISTSWT", "ONUS_INSTITUTION");
		log.debug(String.format("Selected %d acquirer tranansaction sources from db", terminalList.size()));

		List<String> issList = new ArrayList<>();
		List<String> txnDestList = new ArrayList<>();

		// Adding the records in the issList & txnDestList
		for (Iterator iterator = terminalList.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();
			issList.add((String) object[1]);
			txnDestList.add((String) object[0]);
		}

		List recordList = dao.getHostTransactionStats(issList, txnDestList, screenType);
		int statisticsDataRowCount = recordList.size();
		log.debug(String.format("Selected %d host transactions statistics data from db.", statisticsDataRowCount));

		if (statisticsDataRowCount == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) statisticsDataRowCount);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		TransactionListRow dto = null;
		Object[] result = null;
		List<TransactionListRow> workRows = getTransactionList(workRequest, uiMetaData);
		for (int i = 0; i < recordList.size(); i++) {
			dto = new TransactionListRow();
			result = (Object[]) recordList.get(i);
			dto.loadHostTxns(result);
			workRows.add(dto);
		}

		// Transaction details
		TransactionDetailsDAO txnDetailDao = new TransactionDetailsDAO();
		List txnDetails = null;
		if ("true".equalsIgnoreCase(isTxnDetailReq)) {
			if (!needs_total) {
				txnDetails = txnDetailDao.getHostTransactionStatsDetails(issList, txnDestList, screenType, pageNum);
			} else if (needs_total) {
				total = txnDetailDao.getHostTransactionStatsDetailsCount(issList, txnDestList, screenType);
				txnDetails = txnDetailDao.getHostTransactionStatsDetails(issList, txnDestList, screenType, pageNum);
			}
			if (total == 0) {
				workRequest.setLastModified(-1L);
			} else {
				workRequest.setLastModified((long) total);
			}

			MonitorConfigService configService = new MonitorConfigService();
			List<String> businessDeclineList = configService.getDeclineRespCodes(dao,
					MonitorConstants.BD_RESP_CODE_LIST);
			List<String> technicalDeclineList = configService.getDeclineRespCodes(dao,
					MonitorConstants.TD_RESP_CODE_LIST);

			//TODO : Debug & check...
			TransactionStatisticsListItem txnDetailDto = null;
			Object[] result2 = null;
			List<TransactionStatisticsListItem> workRows2 = getTransactionDetail(workRequest, uiMetaData);
			List<TransactionStatisticsListItem> respCodesAndDesc = configService.getResponseCodesAndDesc(dao);

			if (null != txnDetails) {
				for (int i = 0; i < txnDetails.size(); i++) {
					txnDetailDto = new TransactionStatisticsListItem();
					result2 = (Object[]) txnDetails.get(i);
					txnDetailDto.loadTxnDetails(result2);
					setDeclineCategory(businessDeclineList, technicalDeclineList, txnDetailDto);
					setRespCodeDesc(respCodesAndDesc, txnDetailDto);
					workRows2.add(txnDetailDto);
				}
			}
		}
	}

	private void setDeclineCategory(List<String> businessDeclineList, List<String> technicalDeclineList,
			TransactionStatisticsListItem dto) {
		String declineCategory = PaymonUtils.getDeclineCategoryByRespCode(businessDeclineList, technicalDeclineList,
				dto.getRespCode());
		dto.setDeclineCategory(declineCategory);
	}

	private void setRespCodeDesc(List<TransactionStatisticsListItem> respCodesAndDesc, TransactionStatisticsListItem dto) {
		String respCodeDesc = PaymonUtils.getRespDescByCode(respCodesAndDesc, dto.getRespCode());
		dto.setRespCodeDesc(respCodeDesc);
	}

	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;
		return validateFields(fieldDataMap);
	}

	private List<TransactionListRow> getTransactionList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TRANS_STATS_HOST_COL);
		workCollection.setSectionId(MonitorConstants.TRANS_STATS_HOST_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TRANS_STATS_HOST_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionListRow> workRows = new ArrayList<TransactionListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TRANS_STATS_HOST_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<TransactionStatisticsListItem> getTransactionDetail(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TRANS_STATS_HOST_DTL_COL);
		workCollection.setSectionId(MonitorConstants.TRANS_STATS_HOST_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TRANS_STATS_HOST_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionStatisticsListItem> workRows = new ArrayList<TransactionStatisticsListItem>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TRANS_STATS_HOST_DTL_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}
