package com.fis.ist.monitoring.services.handler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.customProject.dao.IncidentActionDAO;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dto.IncidentCountByDaysDto;
import com.fis.ist.monitoring.dto.IncidentCountByHoursDto;
import com.fis.ist.monitoring.dto.IncidentCountByPriorityDto;
import com.fis.ist.monitoring.dto.IncidentCountByStatusDto;
import com.fis.ist.monitoring.dto.IncidentDashboardDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class IncidentDashboardHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(IncidentDashboardHandler.class);
	private static String reqTypeId = MonitorConstants.INC_DASHBOARD_REQ;
	private static String formAuthId = "INCDASH";

	public IncidentDashboardHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getDashboardWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load IncidentDashboardHandler ....");
		
		IncidentActionDAO dao = new IncidentActionDAO();
		UIMetaData uiMetaData = null;
		
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}
		
		String product = params.get("product") != null ? params.get("product") : "";
		String nodeId = params.get("nodeId") != null ? params.get("nodeId") : "*";
		
		if (product.equals("ISTMAS")||product.equals("ISTCLR")) {
			nodeId = "*";
		}
		
		log.debug("Site-NodeID Info : " + "nodeId = " + nodeId + " productId = " + product );
		nodeId = nodeId.contains(", ") ? nodeId.replace(", ", ",") : nodeId;
		

		//SimpleDateFormat dayDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat dayDateFormat = new SimpleDateFormat(ConfigParams.getInstance().getProperty("ist.paymon.responseDateFormat"));
		SimpleDateFormat sdf = new SimpleDateFormat(PaymonUtils.InputDateFormat);
		SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date fromDate = null, toDate = null;
		try {
			fromDate = sdf.parse(
					sdf.format(PaymonUtils.convertLocalDateTimeToDate(LocalDateTime.now())));
			toDate = sdf.parse(
					sdf.format(PaymonUtils.convertLocalDateTimeToDate(LocalDateTime.now())));
		} catch (ParseException e1) {
			log.error("Parse exception!! " + e1.getMessage());
		}
		
		IncidentDashboardDto dashboardDto = new IncidentDashboardDto();
		List<IncidentCountByStatusDto> incStatusCountList = null;
		List<IncidentCountByDaysDto> incDaysCountList = null;
		List<IncidentCountByHoursDto> incHoursCountList = null;
		List<IncidentCountByPriorityDto> incPriorityCountList = null;
		
		//Status List
		try {
		incStatusCountList = dao.getIncidentCountGroupedByStatus(inputFormat.format(fromDate), inputFormat.format(toDate), product, nodeId);
		log.debug("incStatusCountList count " + incStatusCountList.size() );
		}
		catch(Exception ex) {
			log.error("getIncidentCountGroupedByStatus exception!! " + ex.getMessage());
		}
		List<IncidentCountByStatusDto> modifiedStatusCountList = new ArrayList<>();
		final Date statusFromDate = fromDate;
		final Date statusToDate = toDate;
		
		if (incStatusCountList != null) {

			incStatusCountList.forEach(x -> {
				IncidentCountByStatusDto dto = new IncidentCountByStatusDto();
				dto.setStatus(x.getStatus());
				dto.setCount(x.getCount());
				dto.setFromDate(sdf.format(statusFromDate));
				dto.setToDate(sdf.format(statusToDate));
				modifiedStatusCountList.add(dto);
			});
		}
		dashboardDto.setStatusList(modifiedStatusCountList);

		// DayWise List
		try {
			final Date daysFromDate = sdf
					.parse(sdf.format(PaymonUtils.convertLocalDateTimeToDate(LocalDateTime.now().minusDays(7))));

			final Date daysToDate = sdf.parse(sdf.format(PaymonUtils.convertLocalDateTimeToDate(LocalDateTime.now())));

			incDaysCountList = dao.getIncidentCountGroupedByDays(inputFormat.format(daysFromDate),
					inputFormat.format(daysToDate), product, nodeId);
			List<IncidentCountByDaysDto> modifiedDaysCountList = new ArrayList<>();

			if (incDaysCountList != null) {
				incDaysCountList.forEach(x -> {
					IncidentCountByDaysDto dto = new IncidentCountByDaysDto();
					dto.setDayDate(dayDateFormat.format(x.getOpenDate()));
					dto.setOpenCount(x.getOpenCount());
					dto.setClosedCount(x.getClosedCount());
					dto.setFromDate(sdf.format(daysFromDate));
					dto.setToDate(sdf.format(daysToDate));
					dto.setRpDate(sdf.format(x.getOpenDate()));
					dto.setInprogressCount(x.getInprogressCount());
					modifiedDaysCountList.add(dto);
				});
			}

			dashboardDto.setDayList(modifiedDaysCountList);
		} catch (ParseException pe) {
			log.error("Parse exception!! " + pe.getMessage());
		}

		// Hours List
		incHoursCountList = dao.getIncidentCountGroupedByHours(inputFormat.format(fromDate), product, nodeId);
		List<IncidentCountByHoursDto> modifiedHoursCountList = new ArrayList<>();

		final Date hoursFromDate = fromDate;
		final Date hoursToDate = toDate;

		if (incHoursCountList != null) {
			incHoursCountList.forEach(x -> {
				IncidentCountByHoursDto dto = new IncidentCountByHoursDto();
				dto.setHours(x.getHours());
				dto.setOpenCount(x.getOpenCount());
				dto.setClosedCount(x.getClosedCount());
				dto.setFromDate(sdf.format(hoursFromDate));
				dto.setToDate(sdf.format(hoursToDate));
				modifiedHoursCountList.add(dto);
			});
		}
		dashboardDto.setHoursList(modifiedHoursCountList);

		// Priority List
		incPriorityCountList = dao.getIncidentCountGroupedByPriority(inputFormat.format(fromDate),
				inputFormat.format(toDate), product, nodeId);
		List<IncidentCountByPriorityDto> modifiedPriorityCountList = new ArrayList<>();
		final Date priorityFromDate = fromDate;
		final Date priorityToDate = toDate;

		if (incPriorityCountList != null) {
			incPriorityCountList.forEach(x -> {
				IncidentCountByPriorityDto dto = new IncidentCountByPriorityDto();
				dto.setPriority(x.getPriority());
				dto.setCount(x.getCount());
				dto.setFromDate(sdf.format(priorityFromDate));
				dto.setToDate(sdf.format(priorityToDate));
				modifiedPriorityCountList.add(dto);
			});
		}
		
		dashboardDto.setPriorityList(modifiedPriorityCountList);
		
		List<IncidentDashboardDto> workRows = prepareWorkCollection(workRequest, uiMetaData);
		workRows.add(dashboardDto);
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		return validateFields(fieldDataMap);
	}

	private List<IncidentDashboardDto> prepareWorkCollection(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.INC_DASHBOARD_COL);
		workCollection.setSectionId(MonitorConstants.INC_DASHBOARD_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.INC_DASHBOARD_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<IncidentDashboardDto> workRows = new ArrayList<IncidentDashboardDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.INC_DASHBOARD_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.INC_DASHBOARD_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.INC_DASHBOARD_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.INC_DASHBOARD_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.INC_DASHBOARD_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.INC_DASHBOARD_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}
}
