package com.fis.ist.monitoring.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.domain.Notification;

@Repository
public class NotificationDao extends MonitorBaseDAO<Notification, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(NotificationDao.class);

	@Override
	public Class<Notification> getEntityClass() {
		return Notification.class;
	}

	public List<Notification> findByExample(Notification instance) {
		log.debug("NotificationDAO - finding Notification instance by example");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(Notification.class);
			Map<String, Object> condition = new HashMap<String, Object>();

			Object data = null;
			data = instance.getNodeName();
			if (data != null) {
				condition.put("nodeName", data);
			}

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}

			c = c.add(Restrictions.allEq(condition));
			List<Notification> results = c.list();

			log.debug("NotificationDao - findByExample successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("NotificationDao - find by example failed", re);
			throw re;
		}
	}
}
