package com.fis.ist.monitoring.dto;

import java.io.Serializable;
//import javafx.beans.NamedArg;

public class Triplet<K,V1,V2> implements Serializable{
		
		/**
	    * Key of this <code>triplet</code>.
	    */
	   private K key;

	   	/**
	    * Gets the key for this triplet.
	    * @return key for this triplet
	    */
	   public K getKey() { return key; }

	   /**
	    * Value of this this <code>triplet</code>.
	    */
	   private V1 value1;

	   /**
	    * Gets the value1 for this triplet.
	    * @return value1 for this triplet
	    */
	   public V1 getValue1() { return value1; }
	   
	   private V2 value2;

	   /**
	    * Gets the value2 for this triplet.
	    * @return value2 for this triplet
	    */
	   public V2 getValue2() { return value2; }

	   public Triplet() {
	   }
	   
	   /**
	    * Creates a new pair
	    * @param key The key for this pair
	    * @param value The value to use for this pair
	    */
/*	   public Triplet(@NamedArg("key") K key, @NamedArg("value1") V1 value1, @NamedArg("value2") V2 value2) {
	       this.key = key;
	       this.value1 = value1;
	       this.value2 = value2;
	   }*/

	@Override
	public String toString() {
		return "Triplet [key=" + key + ", value1=" + value1 + ", value2=" + value2 + "]";
	}
	   
	/**
	    * <p>Generate a hash code for this <code>Triplet</code>.</p>
	    *
	    * <p>The hash code is calculated using both the name and
	    * the value of the <code>Triplet</code>.</p>
	    *
	    * @return hash code for this <code>Triplet</code>
	    */
	   @Override
	   public int hashCode() {
	       // name's hashCode is multiplied by an arbitrary prime number (13)
	       // in order to make sure there is a difference in the hashCode between
	       // these two parameters:
	       //  name: a  value: aa
	       //  name: aa value: a
	       return key.hashCode() * 13 + (value1 == null ? 0 : value1.hashCode()) + (value2 == null ? 0 : value2.hashCode());
	   }
}