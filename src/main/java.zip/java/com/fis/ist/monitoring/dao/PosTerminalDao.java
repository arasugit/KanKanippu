package com.fis.ist.monitoring.dao;

import static com.fis.ist.common.OracleDaoConstants.DEPRECATION;
import static com.fis.ist.common.OracleDaoConstants.RAWTYPES;
import static com.fis.ist.common.OracleDaoConstants.UNCHECKED;

import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.POSTerminals;
import com.fis.ist.monitoring.dto.Triplet;

@SuppressWarnings({ RAWTYPES, UNCHECKED, DEPRECATION })
public class PosTerminalDao extends MonitorBaseDAO<POSTerminals, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(PosTerminalDao.class);

	public List<POSTerminals> getPosTerminalDetails(String institutionId, String terminalRecord, String terminalId,
			String terminalType, String entityId, String status, int pageNum, Boolean setPaging) {

		log.debug("Entering getPosTerminalDetails in POSTerminalDAO");
		List<POSTerminals> posTerminalList = null;
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("POS_TRMNL_DETAIL");
			queryString = setPOSTerminalsQueryFilter(queryString, institutionId, terminalRecord, terminalId,
					terminalType, entityId, status);

			terminalId = convertWildSearchString(terminalId);
			entityId = convertWildSearchString(entityId);

			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("institutionId", StandardBasicTypes.STRING)
					.addScalar("termRecordSeq", StandardBasicTypes.LONG)
					.addScalar("termIdLow", StandardBasicTypes.STRING)
					.addScalar("termIdHigh", StandardBasicTypes.STRING).addScalar("allwId", StandardBasicTypes.LONG)
					.addScalar("barAccess", StandardBasicTypes.STRING).addScalar("hourId", StandardBasicTypes.LONG)
					.addScalar("actualStartDate", StandardBasicTypes.STRING)
					.addScalar("terminationDate", StandardBasicTypes.STRING)
					.addScalar("terminalIdNR", StandardBasicTypes.LONG)
					.addScalar("terminalType", StandardBasicTypes.STRING)
					.addScalar("posMsgBrand", StandardBasicTypes.LONG)
					.addScalar("ownerEntityId", StandardBasicTypes.STRING)
					.addScalar("currCd", StandardBasicTypes.STRING).addScalar("cpsEligible", StandardBasicTypes.STRING)
					.addScalar("defaultMcc", StandardBasicTypes.STRING)
					.addScalar("captureType", StandardBasicTypes.STRING)
					.addScalar("serialNumber", StandardBasicTypes.STRING)
					.addScalar("termEntityId", StandardBasicTypes.STRING);

			setPOSTerminalsQueryParams(queryObject, institutionId, terminalRecord, terminalId, terminalType, entityId,
					status);

			if (setPaging) {
				setPaging(queryObject, pageNum);
			}

			posTerminalList = (List<POSTerminals>) queryObject
					.setResultTransformer(Transformers.aliasToBean(POSTerminals.class)).list();
		} catch (RuntimeException re) {
			log.error("Error While finding List of POS Terminal Details", re);
			throw re;
		}

		log.debug("Exiting getPosTerminalDetailsBySwDB in POSTerminalDetailsDao");
		return posTerminalList;
	}

	public List<Triplet<String, Integer, Integer>> getTermianlCountGroupedByInstitution() {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TERM_CNT_BY_INST");
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("key", StandardBasicTypes.STRING)
					.addScalar("value1", StandardBasicTypes.INTEGER).addScalar("value2", StandardBasicTypes.INTEGER);

			return (List<Triplet<String, Integer, Integer>>) queryObject
					.setResultTransformer(Transformers.aliasToBean(Triplet.class)).list();

		} catch (RuntimeException re) {
			log.error("getTermianlCountGroupedByInstitution - Query Fails", re);
			throw re;
		}
	}

	private static String setPOSTerminalsQueryFilter(String query, String institutionId, String terminalRecord,
			String terminalId, String terminalType, String entityId, String status) {

		StringBuffer queryBuffer = new StringBuffer(" WHERE 1=1 ");

		if (!isEmpty(institutionId) && !institutionId.equals("*"))
			queryBuffer.append(" and INSTITUTION_ID = :institution ");

		if (!isEmpty(terminalRecord))
			queryBuffer.append(" and TERM_RECORD_SEQ = :terminalRecord ");

		if (!isEmpty(terminalId))
			queryBuffer.append(selectQueryString(terminalId, "terminal"));

		if (!isEmpty(terminalType))
			queryBuffer.append(" AND POS_TERMINAL_TYPE = :terminalType ");

		if (!isEmpty(entityId))
			queryBuffer.append(selectQueryString(entityId, "entity"));

		if (!isEmpty(status) && !status.equalsIgnoreCase("A"))
			queryBuffer.append(" AND BAR_ACCESS = :status ");

		query = query.replaceAll("FILTER_QUERY", queryBuffer.toString());
		return query;

	}

	private static String selectQueryString(String value, String type) {
		if (type.equals("terminal")) {
			if (value.indexOf("*") > -1)
				return " AND ( trim(TERMINAL_ID_LOW) like :terminalId OR trim(TERMINAL_ID_HIGH) like :terminalId ) ";
			else
				return " AND ( trim(TERMINAL_ID_LOW) = :terminalId OR trim(TERMINAL_ID_HIGH) = :terminalId ) ";
		} else {
			if (value.indexOf("*") > -1)
				return " AND trim(OWNER_ENTITY_ID) like :entityId ";
			else
				return " AND trim(OWNER_ENTITY_ID) = :entityId ";
		}
	}

	private static void setPOSTerminalsQueryParams(Query queryObject, String institutionId, String terminalRecord,
			String terminalId, String terminalType, String entityId, String status) {

		if (!isEmpty(institutionId) && !institutionId.equals("*"))
			queryObject.setParameter("institution", institutionId);

		if (!isEmpty(terminalRecord))
			queryObject.setParameter("terminalRecord", Long.parseLong(terminalRecord));

		if (!isEmpty(terminalId))
			queryObject.setParameter("terminalId", terminalId);

		if (!isEmpty(terminalType))
			queryObject.setParameter("terminalType", terminalType);

		if (!isEmpty(entityId))
			queryObject.setParameter("entityId", entityId);

		if (!isEmpty(status) && !status.equalsIgnoreCase("A"))
			queryObject.setParameter("status", status);
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}

	private static String convertWildSearchString(String value) {
		if (isEmpty(value))
			return value;

		if (hasOnlyAsterisks(value)) {
			return "";
		}

		return value.replace("*", "%");
	}

	private static boolean hasOnlyAsterisks(String input) {
		for (int i = 0; i < input.length(); i++) {
			if (input.charAt(i) != '*') {
				return false;
			}
		}
		return true;
	}

	public Integer getPOSTerminalDetailsCount(String institutionId, String terminalRecord, String terminalId,
			String terminalType, String entityId, String status) {

		log.debug("Entering getPOSTerminalDetailsCount in POSTerminalDAO");
		Integer count = null;
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("POS_TRMNL_COUNT");

			queryString = setPOSTerminalsQueryFilter(queryString, institutionId, terminalRecord, terminalId,
					terminalType, entityId, status);

			terminalId = convertWildSearchString(terminalId);
			entityId = convertWildSearchString(entityId);

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("COUNT", StandardBasicTypes.INTEGER);

			setPOSTerminalsQueryParams(queryObject, institutionId, terminalRecord, terminalId, terminalType, entityId,
					status);

			count = queryObject.uniqueResult() != null ? (Integer) queryObject.uniqueResult() : 0;

		} catch (RuntimeException re) {
			log.error("Error While finding total number of ATM Totals records", re);
			throw re;
		}
		log.debug("Exiting getPOSTerminalDetailsCount in PosTerminalDao");
		return count;
	}

	public Class<POSTerminals> getEntityClass() {
		return POSTerminals.class;
	}
}
