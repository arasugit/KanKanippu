package com.fis.ist.monitoring.dao;

import static com.fis.ist.common.OracleDaoConstants.RAWTYPES;
import static com.fis.ist.common.OracleDaoConstants.UNCHECKED;
import static com.fis.ist.common.OracleDaoConstants.DEPRECATION;

import java.util.List;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.MonAtmCounter;

@SuppressWarnings({ RAWTYPES, UNCHECKED, DEPRECATION })
public class MonAtmCounterDAO extends MonitorBaseDAO<MonAtmCounter, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(MonAtmCounterDAO.class);

	// Get ATM Transaction Details
	public List<MonAtmCounter> getAtmCounterDetails(String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, String institution, String groupName, String unit, String terminalId, int pageNum,
			Boolean setPaging) {

		List<MonAtmCounter> atmCounterList = null;
		try {
			terminalId = convertWildSearchString(terminalId);

			String query = SqlQueryProvider.getDBSqlQuery("ATM_COUNTERS_HIST");

			query = setATMCounterQueryFilter(query, institution, groupName, unit, terminalId);

			Query queryObject = getSession().createSQLQuery(query)
					.addScalar("institutionId", StandardBasicTypes.STRING)
					.addScalar("groupName", StandardBasicTypes.STRING)
					.addScalar("unit", StandardBasicTypes.LONG)
					.addScalar("terminalId", StandardBasicTypes.STRING)
					.addScalar("cardsRetain", StandardBasicTypes.LONG)
					.addScalar("filmsRetain", StandardBasicTypes.LONG)
					.addScalar("afterHoursDep", StandardBasicTypes.LONG)
					.addScalar("resetTime", StandardBasicTypes.STRING);

			setATMCounterQueryParams(queryObject, fromDate, toDate, fromDateFormate, toDateFormate, institution,
					groupName, unit, terminalId);

			if (setPaging) {
				setPaging(queryObject, pageNum);
			}

			atmCounterList = (List<MonAtmCounter>) queryObject
					.setResultTransformer(Transformers.aliasToBean(MonAtmCounter.class)).list();
		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}

		return atmCounterList;
	}

	private static String setATMCounterQueryFilter(String query, String institution, String groupName,
			String unit, String terminalId) {

		StringBuffer queryBuffer = new StringBuffer(" where ");
		
		if (!isEmpty(institution))
			queryBuffer.append(" institutionId = :institution and ");

		if (!isEmpty(groupName))
			queryBuffer.append(" group_name = :groupName and ");

		if (!isEmpty(unit)) {
			queryBuffer.append(" unit = :unit and ");
		}

		if (!isEmpty(terminalId))
			queryBuffer.append(" termid like :terminalId and ");

		if (PaymonUtils.isOracleDb())
			queryBuffer.append(
					" reset_time between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) ");
		else if (PaymonUtils.isPostgressDb())
			queryBuffer.append(
					" reset_time between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) ");
		
		query = query.replaceAll("FILTER_QUERY", queryBuffer.toString());
		return query;
	}

	private static void setATMCounterQueryParams(Query queryObject, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, String institution, String groupName, String unit,
			String terminalId) {
		queryObject.setParameter("fromDate", fromDate);
		queryObject.setParameter("toDate", toDate);
		queryObject.setParameter("fromDateFormate", fromDateFormate);
		queryObject.setParameter("toDateFormate", toDateFormate);

		if (!isEmpty(institution)) {
			queryObject.setParameter("institution", institution);
		}

		if (!isEmpty(groupName)) {
			queryObject.setParameter("groupName", groupName);
		}

		if (!isEmpty(unit)) {
			queryObject.setParameter("unit", Long.parseLong(unit));
		}

		if (!isEmpty(terminalId)) {
			queryObject.setParameter("terminalId", terminalId);
		}
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}

	private static String convertWildSearchString(String value) {
		if (isEmpty(value))
			return value;

		if (hasOnlyAsterisks(value)) {
			return "";
		}

		return value.replace("*", "%");
	}

	private static boolean hasOnlyAsterisks(String input) {
		for (int i = 0; i < input.length(); i++) {
			if (input.charAt(i) != '*') {
				return false;
			}
		}
		return true;
	}

	public Class<MonAtmCounter> getEntityClass() {
		return MonAtmCounter.class;
	}
}
