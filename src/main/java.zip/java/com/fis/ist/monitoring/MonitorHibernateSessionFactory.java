package com.fis.ist.monitoring;
import com.fis.ist.hibernate.SessionFactory;
import com.fis.ist.log.ISTLogger;


public class MonitorHibernateSessionFactory extends SessionFactory {
	
	
	private static final ISTLogger log = ISTLogger.getLogger(MonitorHibernateSessionFactory.class);
    private static String CONFIG_FILE_LOCATION = "/com/fis/ist/monitoring/config/mon-hibernate.cfg.xml";
	private static volatile MonitorHibernateSessionFactory instance = new MonitorHibernateSessionFactory();  
    public static synchronized MonitorHibernateSessionFactory getInstance()
	{
    	log.debug("SessionFactory for monitor is initialized");
		return instance;
	}
	
	private MonitorHibernateSessionFactory()
	{
		super(CONFIG_FILE_LOCATION);
		
	}


}
