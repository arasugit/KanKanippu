// Service for Successful Transactions count
package com.fis.ist.monitoring.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.services.handler.FallbackTransactionsHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class FallbackTransactions extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(FallbackTransactions.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		FallbackTransactionsHandler fbh = new FallbackTransactionsHandler();

		if (action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = fbh.getFallbackTransactions(userContext, requestParams);

		} else {
			log.error(
					"**** Transaction Monitoring Fallback Transactions single page List: getService() inbound...unknown action: "
							+ action);
			throw new Exception("Unknown action error");
		}
		
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}
}