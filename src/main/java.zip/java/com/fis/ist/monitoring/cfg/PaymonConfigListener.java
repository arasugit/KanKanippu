package com.fis.ist.monitoring.cfg;

import javax.servlet.ServletContextListener;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
//import org.apache.log4j.LogManager;
//import org.apache.log4j.Logger;
//import org.apache.log4j.MDC;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;

import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.log.ISTLogger;

public class PaymonConfigListener implements ServletContextListener {

	private static final ISTLogger log = ISTLogger.getLogger(PaymonConfigListener.class);
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.
	 * ServletContextEvent)
	 */
	private Properties oracleProperties;

	public void contextDestroyed(ServletContextEvent evt) {
		log.debug("Context Destroys... ");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.
	 * ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent evt) {
		ServletContext ctx = (ServletContext) evt.getSource();
		int major = ctx.getMajorVersion();
		int minor = ctx.getMinorVersion();
		String context_path = null;
		if (major > 2 || (major == 2 && minor >= 5)) {
			context_path = ctx.getContextPath();
		} else {
			context_path = ctx.getRealPath("/");
			if (context_path != null) {
				int end = context_path.lastIndexOf('/');
				int start = context_path.lastIndexOf('/', end);
				context_path = context_path.substring(start + 1, end);
			}
		}
		if (context_path == null)
			context_path = "";
		if (context_path.startsWith("/"))
			context_path = context_path.substring(1);
		String p = null;
		try {
			Context jndi_ctx = new InitialContext();
			p = (String) jndi_ctx.lookup("java:comp/env/ProtectedDirectoryPath");
		} catch (NamingException e) {
			log.error("Error looking up the protected directory path", e);
		}
		if (p != null) {
			try {
				p = ESAPI.validator().getValidInput("protected directory", p, "DirectoryName", 255, true);
			} catch (ValidationException e3) {
				log.error(e3, e3);
			} catch (IntrusionException e4) {
				log.error(e4, e4);
			}
		}
		Properties props = new Properties();
		if (p != null)
			props.setProperty(PaymonConfigParamNames.PROTECTED_DIRECTORY_PATH, p);
		props.setProperty(PaymonConfigParamNames.CONTEXT_ROOT, context_path);
		URL url = null;
		if (p != null) {
			try {
				URI uri = (new File(p)).toURI();
				uri = uri.resolve("log4j.ist.properties");
				File f = new File(uri);
				if (f.exists() && f.isFile())
					url = uri.toURL();
			} catch (Exception e2) {
				log.error("", e2);
			}
		}
		if (url == null) {
			try {
				url = ctx.getResource("/WEB-INF/classes/log4j.ist.properties");
			} catch (MalformedURLException e) {
				log.error("", e);
			}
		}

		String host = "";
		try {
			host = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e1) {
			log.error("Error while getting server's hostname :" + e1);
		}

		if (host != null && !host.equals("")) {
			props.setProperty(PaymonConfigParamNames.WEBAPP_HOSTNAME, host);
		}

		try {
			Manifest manifest = new Manifest(ctx.getResourceAsStream("/META-INF/MANIFEST.MF"));
			Attributes attributes = manifest.getMainAttributes();
			String version = attributes.getValue("Implementation-Version");
			version = getFormattedVersion(version);
			props.setProperty(PaymonConfigParamNames.GUI_VERSION, version);
		} catch (IOException e) {
			log.error("Error while getting the GUI version information: " + e);
		}

		log.trace("properties: " + props);

		// Setting the user name as system for logging statements of the application
		// startup
		// MDC.put("userName", "System");

		PaymonConfigurerFactory fact = PaymonConfigurerFactory.getInstance();
		fact.setProperties(props);
		try {
			PaymonConfigParams.getInstance().setProperties(fact.make().getIstProperties());
		} catch (IOException e) {
			log.error("Failed to load IST properties", e);
		}
		// load the ist.command.properties
		InputStream is = null;
		try {
			if (getClass() != null && getClass().getClassLoader() != null) {
				is = getClass().getClassLoader().getResourceAsStream("sql_oracle.properties");
				if (is != null) {
					oracleProperties = new Properties();
					oracleProperties.load(is);
					PaymonConfigParams.getInstance().setOracleProperties(oracleProperties);
					log.debug("ist.command.properties loaded successfully");
				} else {
					log.error("Failed to load ist.command.properties");
				}
			}
		} catch (IOException e) {
			log.error("Failed to load ist.command.properties", e);
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					log.error(e);
				}
			}
		}
	}

	private String getFormattedVersion(String version) {
		try {
			String reserverdChars = "[~`!@#$%^&*|\\:;\"'<,>?/(){}\\[\\]]";
			if (StringUtil.isNotEmpty(version)) {
				version = version.trim();
				int pos = version.indexOf("\\n");
				if (pos > -1) {
					version = version.substring(pos + 2);
					version = version.replaceAll(reserverdChars, "_");
					return version;
				}
			} else {
				version = "VERSION_NOT_FOUND";
			}
		} catch (Throwable t) {// In case of any errors continue loading the application, but the version will
								// be blank
			log.error("Failed to format the GUI version [" + version + "]", t);
			version = "";
		}
		return version;
	}

}