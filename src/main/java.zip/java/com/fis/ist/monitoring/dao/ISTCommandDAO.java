package com.fis.ist.monitoring.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.ISTCommand;
import com.fis.ist.monitoring.domain.MonGlobalValue;

public class ISTCommandDAO extends MonitorBaseDAO<ISTCommand, Integer> {

	private static final ISTLogger log = ISTLogger.getLogger(ISTCommandDAO.class);

	@Override
	public Class<ISTCommand> getEntityClass() {
		return ISTCommand.class;
	}

	public List<ISTCommand> findByExample(ISTCommand instance, int pageNum) {
		log.debug("finding ISTCommand instance by example");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(ISTCommand.class);
			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;
			List<String> nodeIds = null;

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}

			value = instance.getNodeId();
			if (data.equals("ISTSWT") || data.equals("CORTEX") || data.equals("ISTCLR") || data.equals("ISTMAS")) {
				if (StringUtil.isNotEmpty(value) && value.startsWith("All")) {
					nodeIds = getAllNodes(value);
					c.add(Restrictions.in("nodeId", nodeIds));
				} else if (StringUtil.isNotEmpty(value)) {
					condition.put("nodeId", value);
				}
			}

			data = instance.getIstCommand();
			if (data != null) {
				condition.put("istCommand", data);
			}

			c = c.add(Restrictions.allEq(condition));

			if (!instance.getIstCommand().equalsIgnoreCase("mbportcmd list"))
				c.addOrder(Order.desc("id"));
			setPaging(c, pageNum);
			List<ISTCommand> results = c.list();

			log.debug("findByExample successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public Integer getTotalByExample(ISTCommand instance) {
		log.debug("getTotalByExample ISTCommand");
		Integer count = null;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(ISTCommand.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;
			List<String> nodeIds = null;

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}

			value = instance.getNodeId();
			if (data.equals("ISTSWT") || data.equals("CORTEX") || data.equals("ISTCLR") || data.equals("ISTMAS")) {
				if (StringUtil.isNotEmpty(value) && value.startsWith("All")) {
					nodeIds = getAllNodes(value);
					c.add(Restrictions.in("nodeId", nodeIds));
				} else if (StringUtil.isNotEmpty(value)) {
					condition.put("nodeId", value);
				}
			}

			data = instance.getIstCommand();
			if (data != null) {
				condition.put("istCommand", data);
			}

			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;

			log.debug("getTotalByExample successful, count: " + count);
		} catch (RuntimeException re) {
			log.error("getTotalByExample Task Command failed", re);
			throw re;
		}
		return count;
	}

	public List<ISTCommand> findByExampleWithFields(ISTCommand instance, int pageNum) {
		log.debug("finding ISTCommand instance by example : findByExampleWithFields");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(ISTCommand.class);
			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;
			List<String> nodeIds = null;

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}

			value = instance.getNodeId();
			if (data.equals("ISTSWT") || data.equals("CORTEX") || data.equals("ISTCLR") || data.equals("ISTMAS")) {
				if (StringUtil.isNotEmpty(value) && value.startsWith("All")) {
					nodeIds = getAllNodes(value);
					c.add(Restrictions.in("nodeId", nodeIds));
				} else if (StringUtil.isNotEmpty(value)) {
					condition.put("nodeId", value);
				}
			}

			data = instance.getIstCommand();
			if (data != null) {
				condition.put("istCommand", data);
			}

			if (instance.getIstCommand().equalsIgnoreCase("mbportcmd list")
					|| instance.getIstCommand().equalsIgnoreCase("shccmd list")
					|| instance.getIstCommand().equalsIgnoreCase("tskcmd")) {
				data = instance.getTaskType();
				if (data != null && data != "") {
					value = (String) data;
					if (value.startsWith("*") && value.endsWith("*")) {
						value = value.substring(1, value.length() - 1);
						c.add(Restrictions.ilike("taskType", value, MatchMode.ANYWHERE));
					} else if (value.startsWith("*")) {
						value = value.substring(1);
						c.add(Restrictions.ilike("taskType", value, MatchMode.END));
					} else if (value.endsWith("*")) {
						value = value.substring(0, value.length() - 1);
						c.add(Restrictions.ilike("taskType", value, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("taskType", value, MatchMode.EXACT));
					}
				}

				if (instance.getIstCommand().equalsIgnoreCase("shccmd list")) {
					data = instance.getpId();
					if (data != null && data != "") {
						condition.put("pId", data);
					}
				}
				if (instance.getIstCommand().equalsIgnoreCase("dbconn")) {
					data = instance.getTaskType();
					if (data != null && data != "") {
						condition.put("taskName", data);
					}
				}
			}

			if (instance.getIstCommand().equalsIgnoreCase("mbportcmd list")) {
				data = instance.getFlags();
				if (data != null && data != "") {
					value = (String) data;
					if (value.startsWith("*") && value.endsWith("*")) {
						value = value.substring(1, value.length() - 1);
						c.add(Restrictions.ilike("flags", value, MatchMode.ANYWHERE));
					} else if (value.startsWith("*")) {
						value = value.substring(1);
						c.add(Restrictions.ilike("flags", value, MatchMode.END));
					} else if (value.endsWith("*")) {
						value = value.substring(0, value.length() - 1);
						c.add(Restrictions.ilike("flags", value, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("flags", value, MatchMode.EXACT));
					}
				}

				data = instance.getCount();
				if (data != null && data != "") {
					value = (String) data;
					if (value.startsWith("*") && value.endsWith("*")) {
						value = value.substring(1, value.length() - 1);
						c.add(Restrictions.ilike("count", value, MatchMode.ANYWHERE));
					} else if (value.startsWith("*")) {
						value = value.substring(1);
						c.add(Restrictions.ilike("count", value, MatchMode.END));
					} else if (value.endsWith("*")) {
						value = value.substring(0, value.length() - 1);
						c.add(Restrictions.ilike("count", value, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("count", value, MatchMode.EXACT));
					}
				}
			} else if (instance.getIstCommand().equalsIgnoreCase("dbconn")) {
				data = instance.getTaskType();
				if (data != null && data != "") {
					c.add(Restrictions.ilike("taskName", String.valueOf(data), MatchMode.EXACT));
				}
			} else if (instance.getIstCommand().equalsIgnoreCase("otracecmd list")) {
				data = instance.getTaskType();
				if (data != null && data != "") {
					c.add(Restrictions.ilike("taskType", String.valueOf(data), MatchMode.EXACT));
				}
			} else {
				data = instance.getCount();
				if (data != null && data != "") {
					value = (String) data;
					if (value.startsWith("*") && value.endsWith("*")) {
						value = value.substring(1, value.length() - 1);
						c.add(Restrictions.ilike("count", value, MatchMode.ANYWHERE));
					} else if (value.startsWith("*")) {
						value = value.substring(1);
						c.add(Restrictions.ilike("count", value, MatchMode.END));
					} else if (value.endsWith("*")) {
						value = value.substring(0, value.length() - 1);
						c.add(Restrictions.ilike("count", value, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("count", value, MatchMode.EXACT));
					}
				}

				data = instance.getLastStart();
				if (data != null && data != "") {
					value = (String) data;
					if (value.startsWith("*") && value.endsWith("*")) {
						value = value.substring(1, value.length() - 1);
						c.add(Restrictions.ilike("lastStart", value, MatchMode.ANYWHERE));
					} else if (value.startsWith("*")) {
						value = value.substring(1);
						c.add(Restrictions.ilike("lastStart", value, MatchMode.END));
					} else if (value.endsWith("*")) {
						value = value.substring(0, value.length() - 1);
						c.add(Restrictions.ilike("lastStart", value, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("lastStart", value, MatchMode.EXACT));
					}
				}
			}

			c.add(Restrictions.allEq(condition));

			// c.addOrder(Order.desc(""));
			setPaging(c, pageNum);
			List<ISTCommand> results = c.list();

			log.debug("findByExampleWithFields successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("findByExampleWithFields failed", re);
			throw re;
		}
	}

	public Integer getTotalByExampleWithFields(ISTCommand instance) {
		log.debug("get total count : getTotalByExampleWithFields");
		int count;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(ISTCommand.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;
			List<String> nodeIds = null;

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}

			value = instance.getNodeId();
			if (data.equals("ISTSWT") || data.equals("CORTEX") || data.equals("ISTCLR") || data.equals("ISTMAS")) {
				if (StringUtil.isNotEmpty(value) && value.startsWith("All")) {
					nodeIds = getAllNodes(value);
					c.add(Restrictions.in("nodeId", nodeIds));
				} else if (StringUtil.isNotEmpty(value)) {
					condition.put("nodeId", value);
				}
			}

			data = instance.getIstCommand();
			if (data != null) {
				condition.put("istCommand", data);
			}

			if (instance.getIstCommand().equalsIgnoreCase("mbportcmd list")
					|| instance.getIstCommand().equalsIgnoreCase("shccmd list")
					|| instance.getIstCommand().equalsIgnoreCase("tskcmd")) {
				data = instance.getTaskType();
				if (data != null && data != "") {
					value = (String) data;
					if (value.startsWith("*") && value.endsWith("*")) {
						value = value.substring(1, value.length() - 1);
						c.add(Restrictions.ilike("taskType", value, MatchMode.ANYWHERE));
					} else if (value.startsWith("*")) {
						value = value.substring(1);
						c.add(Restrictions.ilike("taskType", value, MatchMode.END));
					} else if (value.endsWith("*")) {
						value = value.substring(0, value.length() - 1);
						c.add(Restrictions.ilike("taskType", value, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("taskType", value, MatchMode.EXACT));
					}
				}

				if (instance.getIstCommand().equalsIgnoreCase("shccmd list")) {
					data = instance.getpId();
					if (data != null && data != "") {
						condition.put("pId", data);
					}
				}
			}

			if (instance.getIstCommand().equalsIgnoreCase("mbportcmd list")) {
				data = instance.getFlags();
				if (data != null && data != "") {
					value = (String) data;
					if (value.startsWith("*") && value.endsWith("*")) {
						value = value.substring(1, value.length() - 1);
						c.add(Restrictions.ilike("flags", value, MatchMode.ANYWHERE));
					} else if (value.startsWith("*")) {
						value = value.substring(1);
						c.add(Restrictions.ilike("flags", value, MatchMode.END));
					} else if (value.endsWith("*")) {
						value = value.substring(0, value.length() - 1);
						c.add(Restrictions.ilike("flags", value, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("flags", value, MatchMode.EXACT));
					}
				}

				data = instance.getCount();
				if (data != null && data != "") {
					value = (String) data;
					if (value.startsWith("*") && value.endsWith("*")) {
						value = value.substring(1, value.length() - 1);
						c.add(Restrictions.ilike("count", value, MatchMode.ANYWHERE));
					} else if (value.startsWith("*")) {
						value = value.substring(1);
						c.add(Restrictions.ilike("count", value, MatchMode.END));
					} else if (value.endsWith("*")) {
						value = value.substring(0, value.length() - 1);
						c.add(Restrictions.ilike("count", value, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("count", value, MatchMode.EXACT));
					}
				}
			} else if (instance.getIstCommand().equalsIgnoreCase("dbconn")) {
				data = instance.getTaskType();
				if (data != null && data != "") {
					// condition.put("taskName", data);
					c.add(Restrictions.ilike("taskName", String.valueOf(data), MatchMode.EXACT));
				}
			} else if (instance.getIstCommand().equalsIgnoreCase("otracecmd list")) {
				data = instance.getTaskType();
				if (data != null && data != "") {
					c.add(Restrictions.ilike("taskType", String.valueOf(data), MatchMode.EXACT));
				}
			} else {
				data = instance.getCount();
				if (data != null && data != "") {
					value = (String) data;
					if (value.startsWith("*") && value.endsWith("*")) {
						value = value.substring(1, value.length() - 1);
						c.add(Restrictions.ilike("count", value, MatchMode.ANYWHERE));
					} else if (value.startsWith("*")) {
						value = value.substring(1);
						c.add(Restrictions.ilike("count", value, MatchMode.END));
					} else if (value.endsWith("*")) {
						value = value.substring(0, value.length() - 1);
						c.add(Restrictions.ilike("count", value, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("count", value, MatchMode.EXACT));
					}
				}

				data = instance.getLastStart();
				if (data != null && data != "") {
					value = (String) data;
					if (value.startsWith("*") && value.endsWith("*")) {
						value = value.substring(1, value.length() - 1);
						c.add(Restrictions.ilike("lastStart", value, MatchMode.ANYWHERE));
					} else if (value.startsWith("*")) {
						value = value.substring(1);
						c.add(Restrictions.ilike("lastStart", value, MatchMode.END));
					} else if (value.endsWith("*")) {
						value = value.substring(0, value.length() - 1);
						c.add(Restrictions.ilike("lastStart", value, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("lastStart", value, MatchMode.EXACT));
					}
				}
			}

			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;

		} catch (RuntimeException re) {
			log.error("getTotalByExampleWithFields Task Command failed", re);
			throw re;
		}
		return count;
	}

	public List getStatusAfterCommandExecution(Map<String, String> params) {
		try {
			String user = params.get("user");
			String product = params.get("product");
			String nodeId = params.get("nodeId");
			String executedCommand = params.get("executedCommand");

			String queryString = "select runstatus as RUNSTATUS from CS_MONCMDIN  where " + "username = '" + user
					+ "' and " + "product = '" + product + "' and " + "nodeid = '" + nodeId + "' and " + "cmd = '"
					+ executedCommand + "' order by cmdid desc ";

			Query queryObject = createSQLQuery(queryString).addScalar("RUNSTATUS", StandardBasicTypes.STRING);

			List result = queryObject.list();

			log.debug("Success Result ISTCommandDAO - getStatusAfterCommandExecution" + result.toString());

			return result;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}

	public List<List> setCommandExecution(Map<String, String> params) {
		try {

			StringBuffer queryBuffer = new StringBuffer();

			String user = params.get("user");
			String product = params.get("product");
			String nodeId = params.get("nodeId");
			String commandToInsert = params.get("insertCommand");

			java.util.Date todayDate = new Date();
			java.sql.Date convertedTodayDate = new java.sql.Date(todayDate.getTime());
			SimpleDateFormat simpleformat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			String datePresent = simpleformat.format(convertedTodayDate);

			log.debug("ISTCommandDAO - setCommandExecutionate - Date Now " + datePresent);

			queryBuffer.append("insert into CS_MONCMDIN (username, product, nodeid, logdate, CMD, RUNSTATUS) values ("
					+ "'" + user + "', '" + product + "', '" + nodeId + "', TO_DATE('" + datePresent
					+ "', 'MM/dd/yyyy HH24:mi:ss'), '" + commandToInsert + "', ' ') ");

			String queryString = queryBuffer.toString();

			log.debug("Query ISTCommandDAO - setCommandExecution :: " + queryString);

			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("Result", StandardBasicTypes.INTEGER);
			int result = queryObject.executeUpdate();

			if (result == 1) {
				getSession().getTransaction().commit();
				log.debug("Success Result - ISTCommandDAO - setCommandExecutionData " + result);
			} else {
				log.error("Exception Occured in setCommandExecution ... failed");
			}

			List resultArrayList = new ArrayList();
			resultArrayList.add(result);

			return resultArrayList;
		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}

	// To get the Task Command List
	public List getISTCommandList() {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			queryBuffer.append("select product as PRODUCT, nodeid as NODEID, field1 as TASKNAME, field2 TASKTYPE, "
					+ "field0 as PID from CS_MONCMDOUT where cmd ='tskcmd' ");
			String queryString = queryBuffer.toString();
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("PRODUCT", StandardBasicTypes.STRING)
					.addScalar("NODEID", StandardBasicTypes.STRING).addScalar("TASKNAME", StandardBasicTypes.STRING)
					.addScalar("TASKTYPE", StandardBasicTypes.STRING).addScalar("PID", StandardBasicTypes.STRING);

			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}

	public List getISTCommandNodeId() {
		log.debug("get Task Command Node Id dropdown list..");
		try {

			String queryString = "SELECT distinct nodeid as id, nodeid as nodeId from CS_MONCMDOUT where cmd = 'tskcmd'";

			Query queryObject = createSQLQuery(queryString).addScalar("id", StandardBasicTypes.STRING)
					.addScalar("nodeId", StandardBasicTypes.STRING);

			List result = queryObject.list();

			log.debug("Result of Task Command Node Id " + result.toString());

			return result;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getDepartments dropdown list.. failed", re);
			throw re;
		}
	}

	public List getISTCommandProduct() {
		log.debug("get Task Command Product dropdown list..");
		try {

			String queryString = "SELECT distinct product as id, product as product from CS_MONCMDOUT where cmd = 'tskcmd' ";

			Query queryObject = createSQLQuery(queryString).addScalar("id", StandardBasicTypes.STRING)
					.addScalar("product", StandardBasicTypes.STRING);

			List result = queryObject.list();

			log.debug("Result of Task Command Product " + result.toString());

			return result;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getDepartments dropdown list.. failed", re);
			throw re;
		}
	}

	public List getIstCommands() {
		log.debug("get Task Command Product dropdown list..");
		try {

			String queryString = "select distinct cmd as id, cmd as istCommand from CS_MONCMDOUT";

			Query queryObject = createSQLQuery(queryString).addScalar("id", StandardBasicTypes.STRING)
					.addScalar("istCommand", StandardBasicTypes.STRING);

			List result = queryObject.list();

			log.debug("Result of Task Command Product " + result.toString());

			return result;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getDepartments dropdown list.. failed", re);
			throw re;
		}
	}

	public String getIstCommandExecutionTimer(Map<String, String> params) {
		log.debug("get Task Command Execution Timer info ..");
		String timerVal = "03";
		try {

			String product = params.get("product");

			String queryString = "select field_value0 as timer from cs_monglobalvalue where field_name = 'CMD_EXE_TIMER' ";

			if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
				queryString += "and product = '" + product + "' order by row_number() over() desc";
			} else {
				queryString += "and product = '" + product + "' order by rownum desc";
			}

			Query queryObject = createSQLQuery(queryString).addScalar("timer", StandardBasicTypes.STRING);

			List result = queryObject.list();

			if (result.size() > 0) {
				timerVal = (String) result.get(0);
			}

			log.debug("Result of Timer Value " + timerVal);

			return timerVal;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getDepartments dropdown list.. failed", re);
			throw re;
		}
	}

	private List<String> getAllNodes(String nodes) {
		List<String> allNodeIds = new ArrayList<>();

		Pattern pattern = Pattern.compile("\\((.*?)\\)");
		Matcher matcher = pattern.matcher(nodes);

		try {
			if (matcher.find()) {
				nodes = matcher.group(1);
				String[] values = nodes.split(",\\s*");
				for (String value : values) {
					allNodeIds.add(value.trim());
				}
			}
			return allNodeIds;
		} catch (RuntimeException re) {
			log.error("getAllNodes failed", re);
			throw re;
		}
	}

	// To get the Institution Id
	public List getInstitutionId() {
		try {
			StringBuffer queryBuffer = new StringBuffer();

			queryBuffer.append("select distinct field0 as instId  " + "from CS_MONCMDOUT " + "where CMD='shccmd list' "
					+ "and product = :product " + "and nodeid = :nodeId "
					+ "group by  field0, field2 order by field0 ");

			String queryString = queryBuffer.toString();
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("instId", StandardBasicTypes.STRING);

			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}

	public List getResponseCodeGroupList(String productId) {
		List<MonGlobalValue> responseCodeList = null;
		List<String> tempResponseCode1 = new ArrayList<String>();
		List<String> tempResponseCode2 = new ArrayList<String>();
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("RESPONSE_GROUP_CODE");

			// System.out.println("queryString " + queryString);

			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("fieldValue1", StandardBasicTypes.STRING)
					.addScalar("fieldValue0", StandardBasicTypes.STRING);
			queryObject.setParameter("productId", productId);

			responseCodeList = (List<MonGlobalValue>) queryObject
					.setResultTransformer(Transformers.aliasToBean(MonGlobalValue.class)).list();

			String tempKey = "";
			String tempValue = "";

			for (int count = 0; count < responseCodeList.size(); count++) {
				MonGlobalValue tempMonGlobalValue = responseCodeList.get(count);
				tempKey = tempMonGlobalValue.getFieldValue1();

				if (!tempResponseCode1.contains(tempKey)) {
					tempResponseCode1.add(tempKey);
				}
			}

			String tempField = "";
			String tempFieldToPrint = "";

			for (int count1 = 0; count1 < tempResponseCode1.size(); count1++) {
				tempField = tempResponseCode1.get(count1);
				boolean crossCheck = true;
				tempFieldToPrint = "";
				for (int count2 = 0; count2 < responseCodeList.size(); count2++) {
					MonGlobalValue tempMonGlobalValue = responseCodeList.get(count2);
					tempKey = tempMonGlobalValue.getFieldValue1();
					tempValue = tempMonGlobalValue.getFieldValue0();

					if (tempField.equals(tempKey)) {
						if (crossCheck) {
							tempFieldToPrint += tempKey + "((**&**))" + tempValue;
							crossCheck = false;
						} else {
							tempFieldToPrint += "," + tempValue;
						}
					} else {
						continue;
					}
				}
				tempResponseCode2.add(tempFieldToPrint);
			}

			System.out.println("List Print Key 222 " + tempResponseCode2.toString());
			return tempResponseCode2;
		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}

	public List getResponseCode() {
		try {

			String combinedElements = "";
			String elementCode = "";
			String elementDescription = "";
			List<String> responseCodeList = new ArrayList<String>();

			TransactionsDAO transactionsDAO = new TransactionsDAO();
			List recordList = transactionsDAO.getResponseCodesAndDesc();

			for (int count = 0; count < recordList.size(); count++) {
				Object[] tempTempKey = (Object[]) recordList.get(count);

				elementCode = (String) tempTempKey[0];
				elementDescription = (String) tempTempKey[1];

				// System.out.println("Elements " + elementCode + " : " + elementDescription);

				if (elementDescription != null && elementCode != null) {
					combinedElements = elementCode + "((**&**))" + elementDescription;
					responseCodeList.add(combinedElements);
				}
			}

			return responseCodeList;
		} catch (RuntimeException re) {
			log.error("getResponseCodesAndDesc Query Fails", re);
			throw re;
		}

	}
}
