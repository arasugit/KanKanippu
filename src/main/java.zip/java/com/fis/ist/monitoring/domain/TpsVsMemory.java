package com.fis.ist.monitoring.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CS_MONMEMTPS")
public class TpsVsMemory implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	//private Integer id;
	private String product;
	private Integer siteId;
	private Integer NodeId;
	private String NodeName;
	private String logDate;
	private String currentTps;
	private String totalMemory;
	private String usedMemory;
	private String freeMemory;
	private String cacheMemory;
	private String usedMemoryPct;
	private String swapTotal;
	private String swapFree;
	private String cpuUser;
	private String cpuSys;
	private String swapUsed;

	public TpsVsMemory() {

	}

	@Column(name = "PRODUCT", nullable = true, length = 50)
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@Column(name = "SITE_ID", nullable = true, length = 38)
	public Integer getSiteId() {
		return siteId;
	}

	public void setSiteId(Integer siteId) {
		this.siteId = siteId;
	}
	@Id
	@Column(name = "NODE_ID", nullable = true, length = 38)
	public Integer getNodeId() {
		return NodeId;
	}

	public void setNodeId(Integer nodeId) {
		NodeId = nodeId;
	}

	@Column(name = "NODE_NAME", nullable = true, length = 30)
	public String getNodeName() {
		return NodeName;
	}

	public void setNodeName(String nodeName) {
		NodeName = nodeName;
	}

	@Column(name = "LOGDATE", nullable = true)
	public String getLogDate() {
		return logDate;
	}

	public void setLogDate(String logDate) {
		this.logDate = logDate;
	}

	@Column(name = "CURRENT_TPS", nullable = true, length = 20)
	public String getCurrentTps() {
		return currentTps;
	}

	public void setCurrentTps(String currentTps) {
		this.currentTps = currentTps;
	}

	@Column(name = "MEM_TOTAL", nullable = true, length = 20)
	public String getTotalMemory() {
		return totalMemory;
	}

	public void setTotalMemory(String totalMemory) {
		this.totalMemory = totalMemory;
	}

	@Column(name = "MEM_USED", nullable = true, length = 20)
	public String getUsedMemory() {
		return usedMemory;
	}

	public void setUsedMemory(String usedMemory) {
		this.usedMemory = usedMemory;
	}

	@Column(name = "MEM_FREE", nullable = true, length = 20)
	public String getFreeMemory() {
		return freeMemory;
	}

	public void setFreeMemory(String freeMemory) {
		this.freeMemory = freeMemory;
	}

	@Column(name = "MEM_CACHE", nullable = true, length = 20)
	public String getCacheMemory() {
		return cacheMemory;
	}

	public void setCacheMemory(String cacheMemory) {
		this.cacheMemory = cacheMemory;
	}

	@Column(name = "MEM_USED_PERCENT", nullable = true, length = 20)
	public String getUsedMemoryPct() {
		return usedMemoryPct;
	}

	public void setUsedMemoryPct(String usedMemoryPct) {
		this.usedMemoryPct = usedMemoryPct;
	}

	@Column(name = "SWAP_TOTAL", nullable = true, length = 20)
	public String getSwapTotal() {
		return swapTotal;
	}

	public void setSwapTotal(String swapTotal) {
		this.swapTotal = swapTotal;
	}

	@Column(name = "SWAP_FREE", nullable = true, length = 20)
	public String getSwapFree() {
		return swapFree;
	}

	public void setSwapUsed(String swapTotal) {
		this.swapUsed = swapTotal;
	}

	@Column(name = "SWAP_USED", nullable = true, length = 20)
	public String getSwapUsed() {
		return swapUsed;
	}

	public void setSwapFree(String swapFree) {
		this.swapFree = swapFree;
	}

	@Column(name = "CPU_User", nullable = true, length = 20)
	public String getCpuUser() {
		return cpuUser;
	}

	public void setCpuUser(String cpuUser) {
		this.cpuUser = cpuUser;
	}

	@Column(name = "CPU_SYSTEM", nullable = true, length = 20)
	public String getCpuSys() {
		return cpuSys;
	}

	public void setCpuSys(String cpuSys) {
		this.cpuSys = cpuSys;
	}

}
