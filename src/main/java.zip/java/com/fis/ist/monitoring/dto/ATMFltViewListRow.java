package com.fis.ist.monitoring.dto;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class ATMFltViewListRow extends EditableListRowForSDK implements Cloneable {
	private static final ISTLogger log = ISTLogger.getLogger(ATMFltViewListRow.class);
	private String instId;
	private String groupName;
	private String atmUnit;
	private String termId;
	private String location;
	private String geoLocation;
	private String acceptorName;
	private String currency;
	private String country;
	private String branchId;
	private String branchName;
	private String siteType;
	private String siteName;
	private String lastTransactionDateTime;
	private String make;
	private String lastStatusDate;
	private String lastStatusTime;
	private String faultType;


	private ATMFltViewListRow orignalRow;
	
	public void loadISTDataFromDB(Object[] rowISTDataFromDB)
	{
		setInstId(rowISTDataFromDB[0] != null ? (String)rowISTDataFromDB[0] : "");
		setGroupName(rowISTDataFromDB[1] != null ? (String)rowISTDataFromDB[1] : "");
		setAtmUnit(rowISTDataFromDB[2] != null ? (String)rowISTDataFromDB[2] : "");
		setTermId(rowISTDataFromDB[3] != null ? (String)rowISTDataFromDB[3] : "");
		setLocation(rowISTDataFromDB[4] != null ? (String)rowISTDataFromDB[4] : "");
		setGeoLocation(rowISTDataFromDB[5] != null ? (String)rowISTDataFromDB[5] : "");
		setAcceptorName(rowISTDataFromDB[6] != null ? (String)rowISTDataFromDB[6] : "");
		setCurrency(rowISTDataFromDB[7] != null ? (String)rowISTDataFromDB[7] : "");
		setMake(rowISTDataFromDB[8] != null ? (String)rowISTDataFromDB[8] : "");
		setLastTransactionDateTime(rowISTDataFromDB[9]);
		setLastStatusDate(rowISTDataFromDB[10]);
		setLastStatusTime(rowISTDataFromDB[11]);
		setFaultType(rowISTDataFromDB[12] != null ? (String)rowISTDataFromDB[12] : "");
	}
	
	public void loadMonDBDataFromDB(Object[] rowMonDBDataFromDB)
	{
		setTermId(rowMonDBDataFromDB[0] != null ? (String)rowMonDBDataFromDB[0] : "");
		setSiteName(rowMonDBDataFromDB[1] != null ? (String)rowMonDBDataFromDB[1] : "");
		setSiteType(rowMonDBDataFromDB[2] != null ? (String)rowMonDBDataFromDB[2] : "");
		setBranchId(rowMonDBDataFromDB[3] != null ? (String)rowMonDBDataFromDB[3] : "");
		setBranchName(rowMonDBDataFromDB[4] != null ? (String)rowMonDBDataFromDB[4] : "");
		setCountry(rowMonDBDataFromDB[5] != null ? (String)rowMonDBDataFromDB[5] : "");
	}
	
	public void mergeMonDBDataWithISTDBData(ATMFltViewListRow rowMonDBData)
	{
		setSiteName(rowMonDBData.getSiteName());
		setSiteType(rowMonDBData.getSiteType());
		setBranchId(rowMonDBData.getBranchId());
		setBranchName(rowMonDBData.getBranchName());
		setCountry(rowMonDBData.getCountry());
	}

	public String getInstId() {
		return instId;
	}

	public void setInstId(String instId) {
		this.instId = instId;
	}
	
	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getAtmUnit() {
		return atmUnit;
	}

	public void setAtmUnit(String atmUnit) {
		this.atmUnit = atmUnit;
	}

	public String getTermId() {
		return termId;
	}

	public void setTermId(String termId) {
		this.termId = termId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public ATMFltViewListRow getOrignalRow() {
		return orignalRow;
	}

	public String getAcceptorName() {
		return acceptorName;
	}

	public void setAcceptorName(String acceptorName) {
		this.acceptorName = acceptorName;
	}

	public String getLastTransactionDateTime() {
		return lastTransactionDateTime;
	}

	public void setLastTransactionDateTime(Object lastTransactionDateTime) {
		this.lastTransactionDateTime = PaymonUtils.getFormattedResponseDateTime(lastTransactionDateTime);
	}
	

	public String getGeoLocation() {
		return geoLocation;
	}

	public void setGeoLocation(String geoLocation) {
		this.geoLocation = geoLocation;
	}
	
	public String getSiteType() {
		return siteType;
	}

	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getLastStatusDate() {
		return lastStatusDate;
	}

	public void setLastStatusDate(Object lastStatusDate) {
		this.lastStatusDate = PaymonUtils.getFormattedResponseDate(lastStatusDate);
	}

	public String getLastStatusTime() {
		return lastStatusTime;
	}

	public void setLastStatusTime(Object lastStatusTime) {
		this.lastStatusTime = PaymonUtils.getFormattedResponseTime(lastStatusTime);
	}
	
	public String getFaultType() {
		return faultType;
	}

	public void setFaultType(String faultType) {
		this.faultType = faultType;
	}

	@Override
	public String getFormKey() {
		return "instId";
	}

	public void setOrignalRow(ATMFltViewListRow orignalRow) {
		try {
			if (orignalRow != null)
				this.orignalRow = (ATMFltViewListRow) orignalRow.clone();
		} catch (Exception e) {
			log.error(e);
		}
	}
}
