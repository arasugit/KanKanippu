package com.fis.ist.monitoring.services.handler;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.CortexDAO;
import com.fis.ist.monitoring.dto.CortexCardDashboardDto;
import com.fis.ist.monitoring.dto.DateTimeRequestDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class CortexDashboardHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(CortexDashboardHandler.class);
	private static String reqTypeId = MonitorConstants.CTX_DASHBOARD_REQ;
	private static String formAuthId = "CTXDASH";

	public CortexDashboardHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getDashboardWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext);
		load(workReq, params);
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load CortexDashboardHandler ....");
		
		UIMetaData uiMetaData = null;
		CortexDAO dao = new CortexDAO();
		
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}
		
		DateTimeRequestDto dateRequest = getRequestDate(params);
		
		List<CortexCardDashboardDto> data = dao.getCardDashboardData(dateRequest.getFormattedFromDate(), dateRequest.getFormattedToDate(), dateRequest.getFromDbDateFormat(), dateRequest.getToDbDateFormat());		
		
		List<CortexCardDashboardDto> workRows = prepareWorkCollection(workRequest, uiMetaData);
		
		if (data.size() == 0) {
			workRequest.setLastModified(-1L);
			return;
		}
		
		workRequest.setLastModified((long) 1);
		
		for(CortexCardDashboardDto dashboardDto : data) {
			workRows.add(dashboardDto);
		}
	}
	
	private DateTimeRequestDto getRequestDate(Map<String, String> params) {
		
		DateTimeRequestDto dateRequest = PaymonUtils.getRequestedDateTime(params);
		String dateRange = params.get("dateRange");
		
		log.debug("Requested DateRange: " + dateRange);
		
		if (PaymonUtils.isNullOrEmpty(dateRange) || !dateRange.equalsIgnoreCase("1MON")) {
			return dateRequest;
		}		
			
		LocalDate fromLocalDate = LocalDate.now().minusMonths(1);
		Date fromDate = Date.from(fromLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		
		String formattedFromDate = new SimpleDateFormat(PaymonUtils.InputDateConversionFormat).format(fromDate);
		String formattedToDate = new SimpleDateFormat(PaymonUtils.InputDateTimeConversionFormat).format(new Date());
		
		log.debug("Setting date filter for 1 month. FromDate: " + formattedFromDate + ", ToDate: " + formattedToDate);
		dateRequest.setFormattedFromDate(formattedFromDate);
		dateRequest.setFormattedToDate(formattedToDate);
		
		return dateRequest;
	}
	

	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data) throws Exception {

		try {
			
			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private List<CortexCardDashboardDto> prepareWorkCollection(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.CTX_DASHBOARD_COL);
		workCollection.setSectionId(MonitorConstants.CTX_DASHBOARD_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.CTX_DASHBOARD_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<CortexCardDashboardDto> workRows = new ArrayList<CortexCardDashboardDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.CTX_DASHBOARD_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.CTX_DASHBOARD_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(reqTypeId);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.CTX_DASHBOARD_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.CTX_DASHBOARD_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}
}
