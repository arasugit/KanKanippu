package com.fis.ist.monitoring.dto;

import java.util.Date;

public class IncidentCountByDaysDto implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	private Date openDate;
	private Integer openCount;
	private Integer closedCount;
	private Integer inprogressCount;
	private String fromDate;
	private String toDate;
	private String dayDate;
	private String rpDate;
	
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public Integer getOpenCount() {
		return openCount;
	}
	public void setOpenCount(Integer openCount) {
		this.openCount = openCount;
	}
	public Integer getClosedCount() {
		return closedCount;
	}
	public void setClosedCount(Integer closedCount) {
		this.closedCount = closedCount;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getDayDate() {
		return dayDate;
	}
	public void setDayDate(String dayDate) {
		this.dayDate = dayDate;
	}
	public String getRpDate() {
		return rpDate;
	}
	public void setRpDate(String rpDate) {
		this.rpDate = rpDate;
	}
	public Integer getInprogressCount() {
		return inprogressCount;
	}
	public void setInprogressCount(Integer inprogressCount) {
		this.inprogressCount = inprogressCount;
	}
}
