package com.fis.ist.monitoring.domain;

public class RunningATMByMake implements java.io.Serializable {	
	
	private static final long serialVersionUID = 1L;
	private Integer runningATMByMake;
	private String make;
	
	public Integer getRunningATMByMake() {
		return runningATMByMake;
	}
	public void setRunningATMByMake(Integer runningATMByMake) {
		this.runningATMByMake = runningATMByMake;
	}	
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	
	@Override
	public String toString() {
		return "RunningATMByMake [runningATMByMake=" + runningATMByMake + ", make=" + make + "]";
	}

}
