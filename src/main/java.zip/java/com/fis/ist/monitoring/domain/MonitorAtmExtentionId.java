package com.fis.ist.monitoring.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


@Embeddable 
public class MonitorAtmExtentionId implements Serializable{
	
	private static final long serialVersionUID = 1L;

	public MonitorAtmExtentionId(){}
	
	public MonitorAtmExtentionId(String institutionId, String groupName, Integer unit, String termId) {		
		this.institutionId = institutionId;
		this.groupName = groupName;
		this.unit = unit;
		this.termId = termId;
	}
	
	private String  institutionId;	
	private String  groupName;
	private Integer unit;
	private String  termId;
	
	
	@Column(name = "INSTITUTIONID", nullable = false, length = 10)
	public String getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	@Column(name = "GROUP_NAME", nullable = false, length = 10)
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	@Column(name = "UNIT", nullable = false, length = 38)
	public Integer getUnit() {
		return unit;
	}
	public void setUnit(Integer unit) {
		this.unit = unit;
	}
	@Column(name = "TERMID", nullable = false, length =8)
	public String getTermId() {
		return termId;
	}
	public void setTermId(String termId) {
		this.termId = termId;
	}
}
