package com.fis.ist.monitoring.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.spring.HTTPRequestGetter;

public class AppCommonDAO extends MonitorBaseDAO<Integer, Integer> {

	@Override
	public Class<Integer> getEntityClass() {
		return null;
	}

	private String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");
	private static final ISTLogger log = ISTLogger.getLogger(AppCommonDAO.class);

	public List getNodeRecords() {
		try {
			String product = "switch";
			if ("ISTSWT".equalsIgnoreCase(productId)) {
				product = "switch";
			} else if ("ISTCLR".equalsIgnoreCase(productId)) {
				product = "clearing";
			} else if ("ISTMAS".equalsIgnoreCase(productId)) {
				product = "mas";
			} else if ("CORTEX".equalsIgnoreCase(productId)) {
				product = "cortex";
			}
			StringBuffer queryBuffer = new StringBuffer();
			queryBuffer.append(" select site_id, node_id,node_name from node_record where node_type=? ");
			String queryString = queryBuffer.toString();
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("site_id", StandardBasicTypes.STRING)
					.addScalar("node_id", StandardBasicTypes.STRING).addScalar("node_name", StandardBasicTypes.STRING);
			queryObject.setParameter(1, product);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public List<String> getDefaultSiteNodeRecord() {
		try {
			String product = "switch";
			int nodeId = 0;
			if ("ISTSWT".equalsIgnoreCase(productId)) {
				product = "switch";
			} else if ("ISTCLR".equalsIgnoreCase(productId)) {
				product = "clearing";
			} else if ("ISTMAS".equalsIgnoreCase(productId)) {
				product = "mas";
			} else if ("CORTEX".equalsIgnoreCase(productId)) {
				product = "cortex";
			}
			nodeId = getDefaultNodeId(product);
			StringBuffer queryBuffer = new StringBuffer();
			queryBuffer.append("  select site_id, node_id, node_name from node_record where node_type=? and node_id=?");

			String queryString = queryBuffer.toString();
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("site_id", StandardBasicTypes.STRING)
					.addScalar("node_id", StandardBasicTypes.STRING).addScalar("node_name", StandardBasicTypes.STRING);
			queryObject.setParameter(1, product);
			queryObject.setParameter(2, nodeId);
			List list = queryObject.list();
			List<String> siteNodeList = new ArrayList<>();
			siteNodeList.add((String) ((Object[]) list.get(0))[0]);
			siteNodeList.add((String) ((Object[]) list.get(0))[1]);
			siteNodeList.add((String) ((Object[]) list.get(0))[2]);
			return siteNodeList;
		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	private static int getDefaultNodeId(String product) {
		String defaultNodeId = "";
		if ("CORTEX".equalsIgnoreCase(product)) {
			defaultNodeId = "ist.cortex.default_node_id";
		} else if ("clearing".equalsIgnoreCase(product)) {
			defaultNodeId = "ist.clr.default_node_id";
		} else if ("mas".equalsIgnoreCase(product)) {
			defaultNodeId = "ist.mas.default_node_id";
		} else {
			defaultNodeId = "ist.switch.default_node_id";
		}

		String propNodeId = ConfigParams.getInstance().getProperty(defaultNodeId);
		return Integer.valueOf(StringUtils.isNotBlank(propNodeId) ? propNodeId : "1");
	}

}
