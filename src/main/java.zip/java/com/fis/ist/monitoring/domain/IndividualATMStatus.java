package com.fis.ist.monitoring.domain;

import java.util.List;

public class IndividualATMStatus {
	
	private String institutionId;
	private String netname;
	private String groupName;
	private Long unit;
	private Long severity;
	private Long fault;
	private String statusDescList;
	private String terminalComp;
	private String terminal;
	private String location;
	private String make;
	private String acceptorname;
	private Long siteId;
	
	public IndividualATMStatus() {}
	
	public IndividualATMStatus(String institutionId, String netname, String groupName, Long unit, Long severity,
			Long fault, String statusDescList, String terminalComp, String terminal, String location, String make, String acceptorname,
			Long siteId) {
		this.institutionId = institutionId;
		this.netname = netname;
		this.groupName = groupName;
		this.unit = unit;
		this.severity = severity;
		this.fault = fault;
		this.statusDescList = statusDescList;
		this.terminalComp = terminalComp;
		this.terminal = terminal;
		this.location = location;
		this.make = make;
		this.acceptorname = acceptorname;
		this.siteId = siteId;
	}

	
	public String getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	public String getNetname() {
		return netname;
	}
	public void setNetname(String netname) {
		this.netname = netname;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Long getUnit() {
		return unit;
	}
	public void setUnit(Long unit) {
		this.unit = unit;
	}
	public Long getSeverity() {
		return severity;
	}
	public void setSeverity(Long severity) {
		this.severity = severity;
	}
	public Long getFault() {
		return fault;
	}
	public void setFault(Long fault) {
		this.fault = fault;
	}
	public String getStatusDescList() {
		return statusDescList;
	}
	public void setStatusDescList(String statusDescList) {
		this.statusDescList = statusDescList;
	}
	public String getTerminalComp() {
		return terminalComp;
	}
	public void setTerminalComp(String terminalComp) {
		this.terminalComp = terminalComp;
	}
	public String getTerminal() {
		return terminal;
	}
	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getAcceptorname() {
		return acceptorname;
	}
	public void setAcceptorname(String acceptorname) {
		this.acceptorname = acceptorname;
	}
	public Long getSiteId() {
		return siteId;
	}
	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	@Override
	public String toString() {
		return "InDividualATMStatus [institutionId=" + institutionId + ", groupName=" + groupName + ", unit=" + unit
				+ "]";
	}
	

}
