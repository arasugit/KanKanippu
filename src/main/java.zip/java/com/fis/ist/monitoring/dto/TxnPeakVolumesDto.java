package com.fis.ist.monitoring.dto;

public class TxnPeakVolumesDto {

	private String hours;
	private Integer tranCount;
	public String getHours() {
		return hours;
	}
	public void setHours(String hours) {
		this.hours = hours;
	}
	public Integer getTranCount() {
		return tranCount;
	}
	public void setTranCount(Integer tranCount) {
		this.tranCount = tranCount;
	}
	
}
