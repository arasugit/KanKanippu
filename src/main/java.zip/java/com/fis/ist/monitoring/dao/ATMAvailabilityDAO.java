package com.fis.ist.monitoring.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.ATMAvailable;
import com.fis.ist.monitoring.domain.ATMByFaultWise;
import com.fis.ist.monitoring.domain.ATMDataListDs;
import com.fis.ist.monitoring.domain.ConguredATMByMake;
import com.fis.ist.monitoring.domain.RunningATMByMake;

@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class ATMAvailabilityDAO extends MonitorBaseDAO<ATMAvailable, Integer> {

	private static final ISTLogger log = ISTLogger.getLogger(ATMAvailabilityDAO.class);
	public static final String PRODUCT = "product";
	public static final String SITEID = "siteId";
	public static final String NODEID = "nodeId";
	public static final String MODULEFAULTVIEW = "ATMFLTVIEW";
	public static final String ATM_UP_TRMNLS = "ATM_UP_TRMNLS"; // ATMDashBoardQuery002 - ATM_UP_TRMNLS
	public static final String ATM_TOTL_BYSWTCH = "ATM_TOTL_BYSWTCH"; // ATMDashBoardQuery003 - ATM_TOTL_BYSWTCH
	public static final String ATM_UP_BYSWTCH="ATM_UP_BYSWTCH"; // ATMDashBoardQuery004 - ATM_UP_BYSWTCH
	public static final String ATM_OOS_BYSWTCH="ATM_OOS_BYSWTCH"; // ATMDashBoardQuery005 - ATM_OOS_BYSWTCH
	public static final String ATM_CNFGD_BYMAKE="ATM_CNFGD_BYMAKE"; // ATMDashBoardQuery008 - ATM_CNFGD_BYMAKE
	public static final String ATM_TOTL_RUN_BYMKE="ATM_TOTL_RUN_BYMKE"; // ATMDashBoardQuery009 - ATM_TOTL_RUN_BYMKE
	public static final String ATM_FLT_COUNT="ATM_FLT_COUNT"; // ATMDashBoardQuery010 - ATM_FLT_COUNT
	public static final String ATMDWM_REQ_GETTRMID = "ATMDWM_REQ_GETTRMID"; // Down By Make - Get ATMID
	public static final String ATMDWB_REQ_GETTRMID = "ATMDWB_REQ_GETTRMID"; // Down By Branch - Get ATMID
	public static final String ATMUPT_REQ = "ATMUPT_REQ"; //Overall Up Terminals
	public static final String ATMRTCASH = "ATMRTCASH"; // RealTimeCash - ATMRTCASH_RLTMCSH
	
	public ATMAvailable getAtmDetailsByAvailability(ATMAvailable instance,String ...atms) {
		log.debug("finding ATMAvailable List");	
		
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATM_TOTL_BYSWTCH)).addScalar("TOTAL_ATM", StandardBasicTypes.INTEGER);

			Integer totalATM = queryObject.uniqueResult() != null ? (Integer) queryObject.uniqueResult() : null;
			if (totalATM != null) {
				instance.setTotalNumOfAtm(totalATM);
			}
		} catch (RuntimeException re) {
			log.error("Error While finding total atms", re);
			throw re;
		}
		
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATM_UP_BYSWTCH)).addScalar("upAtm", StandardBasicTypes.INTEGER);
			queryObject.setParameterList("atmList", Arrays.asList(atms));
			Integer upAtm = queryObject.uniqueResult() != null ? (Integer) queryObject.uniqueResult() : null;
			if (upAtm != null) {
				instance.setNumOfUpAtm(upAtm);
			}
		} catch (RuntimeException re) {
			log.error("Error While finding running atms", re);
			throw re;
		}
	
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATM_OOS_BYSWTCH)).addScalar("downAtm", StandardBasicTypes.INTEGER);

			Integer downAtm = queryObject.uniqueResult() != null ? (Integer) queryObject.uniqueResult() : null;
			if (downAtm != null) {
				instance.setNumOfDownAtm(downAtm);
			}
		} catch (RuntimeException re) {
			log.error("Error While finding out of service atms", re);
			throw re;
		}
		return instance;
	}

	public List<String> getUpTerminals(String... connectedAtms) { // ATMDashBoardQuery002 - ATM_UP_TRMNLS
		List<String> upTerminalList = null;
		try {
		    Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery("ATM_UP_TRMNLS1")).addScalar("upterminals", StandardBasicTypes.STRING);
		    
			if(PaymonUtils.getDatabseName().equalsIgnoreCase("oracle")) {
				String ResponseDateTimeFormat = ConfigParams.getInstance().getProperty("ist.paymon.databaseDateFormat24");
				String epochUniversalTime = ConfigParams.getInstance().getProperty("ist.paymon.epochUniversalTime");
			
				queryObject.setParameter("benchMarkDate", epochUniversalTime);
				queryObject.setParameter("dateFormat", ResponseDateTimeFormat);
			}

			upTerminalList = queryObject.list();

		} catch (RuntimeException re) {
			log.error("Error While finding running ATMs", re);
			throw re;
		}
		return upTerminalList;

	}

	public List<RunningATMByMake> getTotalRunningATMByMake(String ...connectedAtms) {
		List<RunningATMByMake>  totalRunningAtmList=null;
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATM_TOTL_RUN_BYMKE)).addScalar("runningATMByMake", StandardBasicTypes.INTEGER)
		    		.addScalar("make",StandardBasicTypes.STRING);
		    queryObject.setParameterList("atmList", Arrays.asList(connectedAtms));	
		    totalRunningAtmList = (List<RunningATMByMake>)queryObject.setResultTransformer(Transformers.aliasToBean(RunningATMByMake.class)).list();
		} catch (RuntimeException re) {
			log.error("Error While finding running atms By Make", re);
			throw re;
		}	
		
		return totalRunningAtmList;		
	}
	
	public List<ConguredATMByMake> getConfiguredATMByMake() {
		List<ConguredATMByMake> configuredATMList = null;
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATM_CNFGD_BYMAKE)).addScalar("totalConfiguredATM", StandardBasicTypes.INTEGER)
		    		.addScalar("make",StandardBasicTypes.STRING);
		    configuredATMList = (List<ConguredATMByMake>)queryObject.setResultTransformer(Transformers.aliasToBean(ConguredATMByMake.class)).list();
		 } catch (RuntimeException re) {
			log.error("Error While finding total configured atms By Make", re);
			throw re;
		}
		return configuredATMList;
	}
	
	public List<ATMByFaultWise> getFaultWiseATMCount() {
		List<ATMByFaultWise> ATMFaultList = null;
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATM_FLT_COUNT)).addScalar("totalATMByFault", StandardBasicTypes.INTEGER)
		    		.addScalar("statusCode",StandardBasicTypes.INTEGER);
		    ATMFaultList = (List<ATMByFaultWise>)queryObject.setResultTransformer(Transformers.aliasToBean(ATMByFaultWise.class)).list();
		 } catch (RuntimeException re) {
			log.error("Error While finding total configured atms By FaultWise", re);
			throw re;
		}
		return ATMFaultList;

	}

	public Integer getTotalDSFaultDetailsfromISTDB(List<String> statusList, int pageNum) {
		List fltViewListRow = null;

		List<Integer> statusListInt = new ArrayList(); // Arrays.asList(-101,101);

		for (String s : statusList) {
			statusListInt.add(Integer.valueOf(s));
		}

		try {
			String queryString = SqlQueryProvider.getDBSqlQuery(MODULEFAULTVIEW);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("InstId", StandardBasicTypes.STRING)
					.addScalar("GrpName", StandardBasicTypes.STRING).addScalar("ATMUnit", StandardBasicTypes.STRING)
					.addScalar("Termid", StandardBasicTypes.STRING).addScalar("Location", StandardBasicTypes.STRING)
					.addScalar("GeoLocation", StandardBasicTypes.STRING)
					.addScalar("AcceptorName", StandardBasicTypes.STRING)
					.addScalar("Currency", StandardBasicTypes.STRING).addScalar("make", StandardBasicTypes.STRING)
					.addScalar("LastTransactionDateTime", StandardBasicTypes.STRING)
					.addScalar("lastStatusDate", StandardBasicTypes.STRING)
					.addScalar("LastStatusTime", StandardBasicTypes.STRING)
					.addScalar("FaultType", StandardBasicTypes.STRING);

			queryObject.setParameterList("status", statusListInt);
			fltViewListRow = queryObject.list();

			return fltViewListRow.size();
		} catch (RuntimeException re) {
			log.error("Error While finding running atms", re);
			throw re;
		}
	}

	public List getDSFaultDetailsfromISTDB(List<String> statusList, int pageNum) {
		List fltViewListRow = null;
		List<Integer> statusListInt = new ArrayList();
		
		for(String s : statusList) 
		{
			statusListInt.add(Integer.valueOf(s));
		}
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery(MODULEFAULTVIEW);

			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("InstId", StandardBasicTypes.STRING)
					.addScalar("GrpName", StandardBasicTypes.STRING)
					.addScalar("ATMUnit", StandardBasicTypes.STRING) //1 - this was commented why ?
					.addScalar("Termid", StandardBasicTypes.STRING)
					.addScalar("Location", StandardBasicTypes.STRING)
					.addScalar("GeoLocation", StandardBasicTypes.STRING)
					.addScalar("AcceptorName", StandardBasicTypes.STRING)
					.addScalar("Currency", StandardBasicTypes.STRING) // 2 - this was commented why ?
					.addScalar("make", StandardBasicTypes.STRING)
					.addScalar("LastTransactionDateTime", StandardBasicTypes.STRING)
					.addScalar("lastStatusDate", StandardBasicTypes.STRING)
					.addScalar("LastStatusTime", StandardBasicTypes.STRING) // 3 - this was commented why ?
					.addScalar("FaultType", StandardBasicTypes.STRING);

			queryObject.setParameterList("status", statusListInt);

			setPaging(queryObject, pageNum);
			fltViewListRow = queryObject.list();
			return fltViewListRow;
		} catch (RuntimeException re) {
			log.error("Error While finding running atms", re);
			throw re;
		}
	}

	public List getDSRltmCashfromISTDB() {
		List recordListfromISTDB = null;

		try {
			String queryString = SqlQueryProvider.getDBSqlQuery(ATMRTCASH);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("instid", StandardBasicTypes.STRING)
					.addScalar("groupname", StandardBasicTypes.STRING).addScalar("atmunit", StandardBasicTypes.STRING)
					.addScalar("termid1", StandardBasicTypes.STRING).addScalar("time", StandardBasicTypes.STRING)
					.addScalar("location", StandardBasicTypes.STRING)
					.addScalar("geoLocation", StandardBasicTypes.STRING)
					.addScalar("acceptorname", StandardBasicTypes.STRING)
					.addScalar("currency", StandardBasicTypes.STRING).addScalar("make", StandardBasicTypes.STRING)
					.addScalar("lastWithdrawaldateTime", StandardBasicTypes.STRING)
					.addScalar("Hopper1_Bill", StandardBasicTypes.STRING)
					.addScalar("Hopper2_Bill", StandardBasicTypes.STRING)
					.addScalar("Hopper3_Bill", StandardBasicTypes.STRING)
					.addScalar("Hopper4_Bill", StandardBasicTypes.STRING)
					.addScalar("Hopper1_CashDispense", StandardBasicTypes.STRING)
					.addScalar("Hopper2_CashDispense", StandardBasicTypes.STRING)
					.addScalar("Hopper3_CashDispense", StandardBasicTypes.STRING)
					.addScalar("Hopper4_CashDispense", StandardBasicTypes.STRING)
					.addScalar("Hopper1_EndCash", StandardBasicTypes.STRING)
					.addScalar("Hopper2_EndCash", StandardBasicTypes.STRING)
					.addScalar("Hopper3_EndCash", StandardBasicTypes.STRING)
					.addScalar("Hopper4_EndCash", StandardBasicTypes.STRING);

			recordListfromISTDB = queryObject.list();
			return recordListfromISTDB;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}
  	
	public List<ATMDataListDs> getATMDwnByBranchTermId(){
		List<ATMDataListDs> DwnByBranchSwDbList = null;
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATMDWB_REQ_GETTRMID))
					.addScalar("Make", StandardBasicTypes.STRING)
					.addScalar("InstId", StandardBasicTypes.STRING)
					.addScalar("GrpName", StandardBasicTypes.STRING)
					.addScalar("ATMUnit", StandardBasicTypes.STRING)
					.addScalar("TermId", StandardBasicTypes.STRING)
					.addScalar("Location", StandardBasicTypes.STRING)
					.addScalar("GeoLocation", StandardBasicTypes.STRING)
					.addScalar("AcceptorName", StandardBasicTypes.STRING)
					.addScalar("Currency", StandardBasicTypes.STRING)
					.addScalar("LastTransactionDateTime", StandardBasicTypes.STRING)
					.addScalar("FaultStatusCode", StandardBasicTypes.STRING)
					.addScalar("LastStatusDate", StandardBasicTypes.STRING)
					.addScalar("LastStatusTime", StandardBasicTypes.STRING)
					.addScalar("FaultStatusDesc", StandardBasicTypes.STRING);

			DwnByBranchSwDbList = (List<ATMDataListDs>) queryObject
					.setResultTransformer(Transformers.aliasToBean(ATMDataListDs.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#3...", re);
			throw re;
		}
		return DwnByBranchSwDbList;
	}

	// SQL#6
	public List<ATMDataListDs> getATMTermId() {
		List<ATMDataListDs> recordListSwDb = null;
		try {

			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATMDWM_REQ_GETTRMID))
					.addScalar("Make", StandardBasicTypes.STRING).addScalar("InstId", StandardBasicTypes.STRING)
					.addScalar("GrpName", StandardBasicTypes.STRING).addScalar("ATMUnit", StandardBasicTypes.STRING)
					.addScalar("TermId", StandardBasicTypes.STRING).addScalar("Location", StandardBasicTypes.STRING)
					.addScalar("GeoLocation", StandardBasicTypes.STRING)
					.addScalar("AcceptorName", StandardBasicTypes.STRING)
					.addScalar("Currency", StandardBasicTypes.STRING)
					.addScalar("LastTransactionDateTime", StandardBasicTypes.STRING)
					.addScalar("FaultStatusCode", StandardBasicTypes.STRING)
					.addScalar("LastStatusDate", StandardBasicTypes.STRING)
					.addScalar("LastStatusTime", StandardBasicTypes.STRING)
					.addScalar("FaultStatusDesc", StandardBasicTypes.STRING);

			recordListSwDb = (List<ATMDataListDs>) queryObject
					.setResultTransformer(Transformers.aliasToBean(ATMDataListDs.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#6...", re);
			throw re;
		}
		return recordListSwDb;
	}

	// SQL#8
	public List<ATMDataListDs> getATMUpTerminalsTermId(List<String> termId) {
		List<ATMDataListDs> UpTerminalsSwDbList = null;
		try {

			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATMUPT_REQ))
					.addScalar("TermId", StandardBasicTypes.STRING).addScalar("InstId", StandardBasicTypes.STRING)
					.addScalar("GrpName", StandardBasicTypes.STRING).addScalar("ATMUnit", StandardBasicTypes.STRING)
					.addScalar("Location", StandardBasicTypes.STRING)
					.addScalar("GeoLocation", StandardBasicTypes.STRING)
					.addScalar("AcceptorName", StandardBasicTypes.STRING)
					.addScalar("Currency", StandardBasicTypes.STRING)
					.addScalar("LastTransactionDateTime", StandardBasicTypes.STRING)
					.addScalar("Make", StandardBasicTypes.STRING)
					.addScalar("FaultStatusCode", StandardBasicTypes.STRING)
					.addScalar("LastStatusDate", StandardBasicTypes.STRING)
					.addScalar("LastStatusTime", StandardBasicTypes.STRING)
					.addScalar("FaultStatusDesc", StandardBasicTypes.STRING);

			queryObject.setParameterList("termid", termId);

			UpTerminalsSwDbList = (List<ATMDataListDs>) queryObject
					.setResultTransformer(Transformers.aliasToBean(ATMDataListDs.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#8...", re);
			throw re;
		}
		return UpTerminalsSwDbList;
	}

	public Class<ATMAvailable> getEntityClass() {
		return ATMAvailable.class;
	}

}

