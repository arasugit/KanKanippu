package com.fis.ist.monitoring.dao;


import com.fis.ist.monitoring.MonitorHibernateSessionFactory;
import com.fis.ist.hibernate.HibernateDAO;

public abstract class MonitorBaseHibernateDAO extends HibernateDAO
{
	public MonitorBaseHibernateDAO()
	{
		super(MonitorHibernateSessionFactory.getInstance());
	}
}