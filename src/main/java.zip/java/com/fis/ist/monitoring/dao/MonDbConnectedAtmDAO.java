package com.fis.ist.monitoring.dao;

import static com.fis.ist.common.MonitorSql.ATM_UP_TERMINALS_MONITOR_DB;

import java.util.Arrays;
import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.ATMMonDbListDs;
import com.fis.ist.monitoring.domain.MonitorAtmExtension;
import com.fis.ist.monitoring.domain.TerminalsByBranch;
import com.fis.ist.monitoring.domain.TerminalsBySite;
import com.fis.ist.monitoring.dto.ATMFltViewListRow;

@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class MonDbConnectedAtmDAO extends MonitorBaseDAO<MonitorAtmExtension, String> {
	private static final ISTLogger log = ISTLogger.getLogger(MonDbConnectedAtmDAO.class);
	private static final String ATM_CONTD_ATMLST = "ATM_CONTD_ATMLST"; // ATMDashBoardQuery001-ATM_CONTD_ATMLST
	private static final String ATM_TRMNL_PRCNT_BYSITE = "ATM_TRMNL_PRCNT_BYSITE"; // ATMDashBoardQuery006 -
																					// ATM_TRMNL_PRCNT_BYSITE
	private static final String ATM_TRMNL_PRCNT_BYBRNCH = "ATM_TRMNL_PRCNT_BYBRNCH"; // ATMDashBoardQuery007 -
																						// ATM_TRMNL_PRCNT_BYBRNCH
	private static final String ATMDWM_REQ = "ATMDWM_REQ"; // ATM Down by Make
	private static final String ATMDWB_REQ = "ATMDWB_REQ"; // ATM Down By Branch
	private static final String ATMDWS_REQ = "ATMDWS_REQ"; // ATM Down By Site
	private static final String GET_BRNCH_SITE = "GET_BRNCH_SITE"; // Real Time Cash - Get Branch Site
	private static final String ATMDWB_REQ_BRANCH = "ATMDWB_REQ_BRANCH"; // ATM Down By Branch Id

	// "ATM_CONTD_ATMLST"; //ATMDashBoardQuery001-ATM_CONTD_ATMLST
	public List<String> getMonDbConnectedATMList() {
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATM_CONTD_ATMLST))
					.addScalar("connectedTermId", StandardBasicTypes.STRING); // ATMDashBoard-Change001
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("Exception Occured while getting Connected ATM list.. failed", re);
			throw re;
		}
	}

	// ATMDashBoardQuery006 - ATM_TRMNL_PRCNT_BYSITE
	public List<TerminalsBySite> getTerminalsPercentageBySite(String... connectedTerminals) {
		List<TerminalsBySite> siteTeminalsList = null;
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATM_TRMNL_PRCNT_BYSITE))
					.addScalar("siteType", StandardBasicTypes.STRING)
					.addScalar("upPercentage", StandardBasicTypes.STRING)
					.addScalar("downPercentage", StandardBasicTypes.STRING);
			for (int i = 0; i < connectedTerminals.length; i++)
				connectedTerminals[i] = connectedTerminals[i].trim();
			queryObject.setParameterList("terminals", Arrays.asList(connectedTerminals));
			siteTeminalsList = (List<TerminalsBySite>) queryObject
					.setResultTransformer(Transformers.aliasToBean(TerminalsBySite.class)).list();

		} catch (RuntimeException re) {
			log.error("Exception Occured while getting terminals percentage by site.. failed", re);
			throw re;
		}
		return siteTeminalsList;

	}

	// ATMDashBoardQuery007 - ATM_TRMNL_PRCNT_BYBRNCH
	public List<TerminalsByBranch> getTerminalsPercentageByBranch(String... connectedTerminals) {
		List<TerminalsByBranch> branchTeminalsList = null;
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATM_TRMNL_PRCNT_BYBRNCH))
					.addScalar("branch", StandardBasicTypes.STRING).addScalar("upPercentage", StandardBasicTypes.STRING)
					.addScalar("downPercentage", StandardBasicTypes.STRING);
			queryObject.setParameterList("terminals", connectedTerminals);
			branchTeminalsList = (List<TerminalsByBranch>) queryObject
					.setResultTransformer(Transformers.aliasToBean(TerminalsByBranch.class)).list();
		} catch (RuntimeException re) {
			log.error("Exception Occured while getting terminals percentage by site.. failed", re);
			throw re;
		}

		return branchTeminalsList;
	}

	public List<ATMFltViewListRow> getDSBranchSitesFromMONDB(List<String> termId) {
		List branchSiteCountryList = null;
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(GET_BRNCH_SITE))
					.addScalar("termid", StandardBasicTypes.STRING).addScalar("sitename", StandardBasicTypes.STRING)
					.addScalar("sitetype", StandardBasicTypes.STRING).addScalar("branchid", StandardBasicTypes.STRING)
					.addScalar("branchname", StandardBasicTypes.STRING).addScalar("country", StandardBasicTypes.STRING);
			queryObject.setParameterList("termid", termId);
			branchSiteCountryList = queryObject.list();
			return branchSiteCountryList;
		} catch (RuntimeException re) {
			log.error("Error While finding running atms", re);
			throw re;
		}
	}

	// SQL#4
	public List<ATMMonDbListDs> getDownBySiteATM() {
		List<ATMMonDbListDs> DwnBySiteMonDbList = null;
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATMDWS_REQ))
					.addScalar("termId", StandardBasicTypes.STRING).addScalar("branchId", StandardBasicTypes.STRING)
					.addScalar("branchName", StandardBasicTypes.STRING).addScalar("siteName", StandardBasicTypes.STRING)
					.addScalar("siteType", StandardBasicTypes.STRING).addScalar("country", StandardBasicTypes.STRING);

			DwnBySiteMonDbList = (List<ATMMonDbListDs>) queryObject
					.setResultTransformer(Transformers.aliasToBean(ATMMonDbListDs.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed", re);
			throw re;
		}
		return DwnBySiteMonDbList;
	}

	// SQL#5
	public List<ATMMonDbListDs> getDownByBranchATM(String branchId) {
		List<ATMMonDbListDs> DwnByBranchMonDbList = null;
		try {
			String queryString = "";

			if (branchId != "") {
				queryString = SqlQueryProvider.getDBSqlQuery(ATMDWB_REQ_BRANCH);
			} else {
				queryString = SqlQueryProvider.getDBSqlQuery(ATMDWB_REQ);
			}

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("termId", StandardBasicTypes.STRING)
					.addScalar("branchId", StandardBasicTypes.STRING).addScalar("branchName", StandardBasicTypes.STRING)
					.addScalar("siteName", StandardBasicTypes.STRING).addScalar("siteType", StandardBasicTypes.STRING)
					.addScalar("country", StandardBasicTypes.STRING);

			if (branchId != "") {
				queryObject.setParameter("branchId", branchId);
			}

			DwnByBranchMonDbList = (List<ATMMonDbListDs>) queryObject
					.setResultTransformer(Transformers.aliasToBean(ATMMonDbListDs.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed", re);
			throw re;
		}
		return DwnByBranchMonDbList;
	}

	// SQL#7
	public List<ATMMonDbListDs> getDownByMakeATM(List<String> termId) {
		List<ATMMonDbListDs> recordListMonDb = null;
		try {
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(ATMDWM_REQ))
					.addScalar("termId", StandardBasicTypes.STRING).addScalar("siteName", StandardBasicTypes.STRING)
					.addScalar("siteType", StandardBasicTypes.STRING).addScalar("branchId", StandardBasicTypes.STRING)
					.addScalar("branchName", StandardBasicTypes.STRING).addScalar("country", StandardBasicTypes.STRING);

			queryObject.setParameterList("termid", termId);

			recordListMonDb = (List<ATMMonDbListDs>) queryObject
					.setResultTransformer(Transformers.aliasToBean(ATMMonDbListDs.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#7...", re);
			throw re;
		}
		return recordListMonDb;
	}

	// SQL#9
	public List<ATMMonDbListDs> getATMUpTerminals(List<String> termId) {
		List<ATMMonDbListDs> upTerminalsListMonDb = null;
		try {
			Query queryObject = getSession().createSQLQuery(ATM_UP_TERMINALS_MONITOR_DB)
					.addScalar("termId", StandardBasicTypes.STRING).addScalar("siteName", StandardBasicTypes.STRING)
					.addScalar("siteType", StandardBasicTypes.STRING).addScalar("branchId", StandardBasicTypes.STRING)
					.addScalar("branchName", StandardBasicTypes.STRING).addScalar("country", StandardBasicTypes.STRING);

			queryObject.setParameterList("termid", termId);
			upTerminalsListMonDb = (List<ATMMonDbListDs>) queryObject
					.setResultTransformer(Transformers.aliasToBean(ATMMonDbListDs.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#9...", re);
			throw re;
		}
		return upTerminalsListMonDb;
	}

	@Override
	public Class<MonitorAtmExtension> getEntityClass() {
		return MonitorAtmExtension.class;
	}

}