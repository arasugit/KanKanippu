package com.fis.ist.monitoring.dto;

import java.text.DecimalFormat;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class DPCdSumListRow extends EditableListRowForSDK implements Cloneable {
	private static final ISTLogger log = ISTLogger.getLogger(DPCdSumListRow.class);
	
	
	private static final long serialVersionUID = 6803023989652998245L;	
	
	private String txndest;
	private String sumAmount;
	
	private DPCdSumListRow orignalRow;
	DecimalFormat formatter = new DecimalFormat("#,###.00");
	
	@Override
	public String toString() {
		return "DPCdSumListRow [txndest=" + txndest + ", sumAmount=" + sumAmount + ", orignalRow=" + orignalRow + ", formatter=" + formatter
				+ "]";
	}
	
	public void loadDbSumInfo(Object[] rowISTDataFromDB) {
		settxndest(rowISTDataFromDB[0] != null ? (String)rowISTDataFromDB[0] : "");
		setsumAmount(rowISTDataFromDB[1] != null ? (String)formatter.format(rowISTDataFromDB[1]) : "0");
			
		if(getsumAmount() != null) {
			setsumAmount(convertWithProperFormat(getsumAmount()));
		}
	}
	
	
	private String convertWithProperFormat(String retrievedValue) {
		
		String valueToPrint = "0.00";
		
		if(!"0".equalsIgnoreCase(retrievedValue)) {
			valueToPrint = formatter.format(Double.parseDouble(retrievedValue.replace(",", "")));
		} 
		
		return valueToPrint;
	}
	

	public String gettxndest() {
		return txndest;
	}

	public void settxndest(String txndest) {
		this.txndest = txndest;
	}


	public String getsumAmount() {
		return sumAmount;
	}

	public void setsumAmount(String sumAmount) {
		this.sumAmount = sumAmount;
	}

	public void setOrignalRow(DPCdSumListRow orignalRow) {
		try {
			if (orignalRow != null)
				this.orignalRow = (DPCdSumListRow) orignalRow.clone();
		} catch (Exception e) {
			log.error(e);
		}
	}

	@Override
	public String getFormKey() {
		return null;
	}

}
