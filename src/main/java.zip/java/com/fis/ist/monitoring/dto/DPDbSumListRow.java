package com.fis.ist.monitoring.dto;

import java.text.DecimalFormat;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class DPDbSumListRow extends EditableListRowForSDK implements Cloneable {
	private static final ISTLogger log = ISTLogger.getLogger(DPDbSumListRow.class);
	
	
	private static final long serialVersionUID = 6803023989652998245L;	
	
	private String txnsrc;
	private String sumAmount;
	
	private DPDbSumListRow orignalRow;
	DecimalFormat formatter = new DecimalFormat("#,###.00");
	
	@Override
	public String toString() {
		return "DPDbSumListRow [txnsrc=" + txnsrc + ", sumAmount=" + sumAmount + ", orignalRow=" + orignalRow + ", formatter=" + formatter
				+ "]";
	}
	
	public void loadDbSumInfo(Object[] rowISTDataFromDB) {
		settxnsrc(rowISTDataFromDB[0] != null ? (String)rowISTDataFromDB[0] : "");
		setsumAmount(rowISTDataFromDB[1] != null ? (String)formatter.format(rowISTDataFromDB[1]) : "0");
			
		if(getsumAmount() != null) {
			setsumAmount(convertWithProperFormat(getsumAmount()));
		}
	}
	
	
	private String convertWithProperFormat(String retrievedValue) {
		
		String valueToPrint = "0.00";
		
		if(!"0".equalsIgnoreCase(retrievedValue)) {
			valueToPrint = formatter.format(Double.parseDouble(retrievedValue.replace(",", "")));
		} 
		
		return valueToPrint;
	}
	

	public String gettxnsrc() {
		return txnsrc;
	}

	public void settxnsrc(String txnsrc) {
		this.txnsrc = txnsrc;
	}


	public String getsumAmount() {
		return sumAmount;
	}

	public void setsumAmount(String sumAmount) {
		this.sumAmount = sumAmount;
	}

	public void setOrignalRow(DPDbSumListRow orignalRow) {
		try {
			if (orignalRow != null)
				this.orignalRow = (DPDbSumListRow) orignalRow.clone();
		} catch (Exception e) {
			log.error(e);
		}
	}

	@Override
	public String getFormKey() {
		return null;
	}

}
