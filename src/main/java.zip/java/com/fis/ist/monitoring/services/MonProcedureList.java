package com.fis.ist.monitoring.services;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.fis.ist.common.IListProvider;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.MonGlbValDAO;
import com.fis.ist.spring.HTTPRequestGetter;


public class MonProcedureList implements IListProvider {
	
	private static final ISTLogger log = ISTLogger.getLogger(MonProcedureList.class);
	
	@Override
	public List getList() {		
		
		HttpServletRequest request = HTTPRequestGetter.getRequest();
	 	String productId = (String) request.getSession(false).getAttribute("product_id");
	 	
	 	log.debug("insde MonProcedureList - Getting List of Procedure from MonGlobalValue ");
		List recordList = new MonGlbValDAO().getProcedureList("PCODE_LIST", productId);
		return recordList;
	}

	@Override
	public String getName() {
		return "PROC_LIST";
	}


	@Override
	public List getList(Map<String, String> arg0) {
		return null;
	}


	@Override
	public List getListByInstitution(String arg0) {
		return null;
	}
	
}
