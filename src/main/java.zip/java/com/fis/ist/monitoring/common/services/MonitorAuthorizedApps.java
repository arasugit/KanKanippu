package com.fis.ist.monitoring.common.services;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.services.vo.ApplicationInfo;

public class MonitorAuthorizedApps {
	private ServletContext context = null;
	
	protected List<ApplicationInfo> permitApps = new ArrayList<ApplicationInfo>();
	
	public void setContext(ServletContext context) {
		this.context = context;
		getPermitApps();
	}

	public ServletContext getContext() {
		return context;
	}  
	public int getPermitAppsSize() 
	{
		if (permitApps == null) {
			return 0;
		}
		return permitApps.size();
	}
	protected void getPermitApps() 
	{
		permitApps.clear();
		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(context);
		MonitorMenuService menuService = ctx.getBean(MonitorMenuService.class);
		permitApps = menuService.getApplications();
	}
	
	public String getApplicationUrl(int idx) 
	{
		ApplicationInfo app = getApp(idx);
		if (app == null)
			return "";
		return app.getUrl();
	}
	
	public String getApplicationName(int idx) {
		ApplicationInfo app = getApp(idx);
		if (app == null)
			return "";
		return app.getName();
	}
	public Boolean getSingleAppAutoPopup()
	{
		String val = ConfigParams.getInstance().getProperty("ist.single_app_auto_popup");
		if ("true".equalsIgnoreCase(val) || "y".equalsIgnoreCase(val))
			return true;
		return false;
	}
 	
	private int getSize()
	{
		return permitApps == null ? 0 : permitApps.size();
	}	
	private ApplicationInfo getApp(int idx)
	{
		if (idx < 0 || idx >= getSize())
			return null;
		return permitApps.get(idx);
	}	
	public String getApplicationId(int idx) 
	{
		ApplicationInfo app = getApp(idx);
		if (app == null)
			return "";
		return app.getId();
	}
	

}
