package com.fis.ist.monitoring.dto;

public class ATMRltmCashPosHistoryRequestDto {
	
	private DateTimeRequestDto dateTimeRequest;
	private String terminalId;
	private String institutionId;
	private Integer unit;
	private String groupName;
	private boolean totalCountRequired;
	private Integer pageNumber;
	
	public DateTimeRequestDto getDateTimeRequest() {
		return dateTimeRequest;
	}
	
	public void setDateTimeRequest(DateTimeRequestDto dateTimeRequest) {
		this.dateTimeRequest = dateTimeRequest;
	}
	
	public String getTerminalId() {
		return terminalId;
	}
	
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}
	
	public String getInstitutionId() {
		return institutionId;
	}
	
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	
	public Integer getUnit() {
		return unit;
	}
	
	public void setUnit(Integer unit) {
		this.unit = unit;
	}
	
	public String getGroupName() {
		return groupName;
	}
	
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	public boolean getTotalCountRequuired() {
		return totalCountRequired;
	}
	
	public void setTotalCountRequired(boolean totalCountRequired) {
		this.totalCountRequired = totalCountRequired;
	}
	
	public Integer getpageNumber() {
		return pageNumber;
	}
	
	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}
}
