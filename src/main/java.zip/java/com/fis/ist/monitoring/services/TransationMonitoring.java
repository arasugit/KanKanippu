package com.fis.ist.monitoring.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.customProject.services.handler.TransactionMonitoringHandler;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class TransationMonitoring extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(TransationMonitoring.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		TransactionMonitoringHandler ddh = new TransactionMonitoringHandler();
		
		if (action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = ddh.getEMPLISTSP(userContext, requestParams);
		} else if (AppConstants.MKC_ACTION_PENDING_REQ.equals(action)) {
			workReq = ddh.mkcSubmittedList(userContext, requestParams);
		} else if (AppConstants.MKC_ACTION_REWORK_REQ.equals(action)) {
			workReq = ddh.mkcReworkList(userContext, requestParams);
		} else {
			log.error("**** Transaction Monitoring single page List: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}
		
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}
}