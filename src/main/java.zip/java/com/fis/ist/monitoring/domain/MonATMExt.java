package com.fis.ist.monitoring.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CS_MONATM_EXT" )
public class MonATMExt implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String termId; // Term ID
	private String siteName; // Site Name
	private String siteDesc; // Site Description
	private String siteType; // Site Type
	private String siteLocation; // Site Location
	private String address; // Address
	private String branchId; // Branch Id
	private String branchName; // Branch Name
	private String city; // City
	private String state; // State
	private String country; // Country
	private String lattitude; // Lattitude
	private String longitude; // Longitude
	private String cra; // Cra
	private String commType; // Commtype
	private String commVendor; // Commvendor
	private String cassetteLoadType; // Cassetteloadtype

	
	private ATMExtId id;
	
	public MonATMExt() {}
	
	@EmbeddedId
	@AttributeOverrides( {
		@AttributeOverride(name = "unit", column = @Column(name = "UNIT", nullable = false, length = 38)),
		@AttributeOverride(name = "instId", column = @Column(name = "INSTITUTIONID", nullable = false, length = 10)), 
		@AttributeOverride(name = "groupName", column = @Column(name = "GROUP_NAME", nullable = false, length = 10))
	})
	public ATMExtId getId() {
		return id;
	}
		
	public void setId(ATMExtId id) {
		this.id = id;
	}

	@Column(name = "TERMID", nullable = false, length = 16)	
	public String getTermId() {
		return termId;
	}

	public void setTermId(String termId) {
		this.termId = termId;
	}

	@Column(name = "SITENAME", nullable = true, length = 30)	
	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	@Column(name = "SITEDESC", nullable = true, length = 50)
	public String getSiteDesc() {
		return siteDesc;
	}

	public void setSiteDesc(String siteDesc) {
		this.siteDesc = siteDesc;
	}

	@Column(name = "SITETYPE", nullable = true, length = 10)
	public String getSiteType() {
		return siteType;
	}

	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}

	@Column(name = "SITELOCATION", nullable = true, length = 25)
	public String getSiteLocation() {
		return siteLocation;
	}

	public void setSiteLocation(String siteLocation) {
		this.siteLocation = siteLocation;
	}

	@Column(name = "ADDRESS", nullable = true, length = 100)
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Column(name = "BRANCHID", nullable = true, length = 10)
	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	@Column(name = "BRANCHNAME", nullable = true, length = 30)
	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	@Column(name = "CITY", nullable = true, length = 50)
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name = "STATE", nullable = true, length = 50)
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Column(name = "COUNTRY", nullable = true, length = 25)
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Column(name = "LATITUDE", nullable = true, length = 10)
	public String getLattitude() {
		return lattitude;
	}

	public void setLattitude(String lattitude) {
		this.lattitude = lattitude;
	}

	@Column(name = "LONGITUDE", nullable = true, length = 10)
	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	
	@Column(name = "CRA", nullable = true, length = 50)
	public String getCra() {
		return cra;
	}

	public void setCra(String cra) {
		this.cra = cra;
	}

	@Column(name = "COMMTYPE", nullable = true, length = 50)
	public String getCommType() {
		return commType;
	}

	public void setCommType(String commType) {
		this.commType = commType;
	}

	@Column(name = "COMMVENDOR", nullable = true, length = 50)
	public String getCommVendor() {
		return commVendor;
	}

	public void setCommVendor(String commVendor) {
		this.commVendor = commVendor;
	}

	@Column(name = "CASSETTELOADTYPE", nullable = true, length = 1)
	public String getCassetteLoadType() {
		return cassetteLoadType;
	}

	public void setCassetteLoadType(String cassetteLoadType) {
		this.cassetteLoadType = cassetteLoadType;
	}

	public MonATMExt(String termId, String siteName, String siteDesc, String siteType, String siteLocation,
			String address, String branchId, String branchName, String city, String state, String country,
			String lattitude, String longitude, String cra, String commType, String commVendor, String cassetteLoadType,
			ATMExtId id) {
		
		super();
		this.termId = termId;
		this.siteName = siteName;
		this.siteDesc = siteDesc;
		this.siteType = siteType;
		this.siteLocation = siteLocation;
		this.address = address;
		this.branchId = branchId;
		this.branchName = branchName;
		this.city = city;
		this.state = state;
		this.country = country;
		this.lattitude = lattitude;
		this.longitude = longitude;
		this.cra = cra;
		this.commType = commType;
		this.commVendor = commVendor;
		this.cassetteLoadType = cassetteLoadType;
		this.id = id;
	}

	@Override
	public String toString() {
		return "MonATMExt [termId=" + termId + ", siteName=" + siteName + ", siteDesc=" + siteDesc + ", siteType="
				+ siteType + ", siteLocation=" + siteLocation + ", address=" + address + ", branchId=" + branchId
				+ ", branchName=" + branchName + ", city=" + city + ", state=" + state + ", country=" + country
				+ ", lattitude=" + lattitude + ", longitude=" + longitude + ", cra=" + cra + ", commType=" + commType
				+ ", commVendor=" + commVendor + ", cassetteLoadType=" + cassetteLoadType + ", id=" + id + "]";
	}

}
