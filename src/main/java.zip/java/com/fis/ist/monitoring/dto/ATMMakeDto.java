package com.fis.ist.monitoring.dto;

public class ATMMakeDto implements java.io.Serializable {
	
	private static final long serialVersionUID = -646182332543081904L;
	public Integer getRunningATMByMake() {
		return runningATMByMake;
	}
	public void setRunningATMByMake(Integer runningATMByMake) {
		this.runningATMByMake = runningATMByMake;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public Integer getTotalConfiguredATM() {
		return totalConfiguredATM;
	}
	public void setTotalConfiguredATM(Integer totalConfiguredATM) {
		this.totalConfiguredATM = totalConfiguredATM;
	}
	public Integer getDownATMByMake() {
		return downATMByMake;
	}
	public void setDownATMByMake(Integer downATMByMake) {
		this.downATMByMake = downATMByMake;
	}
	private Integer runningATMByMake;
	private Integer downATMByMake;	
	private String make;
	private Integer totalConfiguredATM;

}
