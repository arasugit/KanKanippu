package com.fis.ist.monitoring.controller;

public class SelectedMonitorProduct {
	
	
	private String productId;
	private String name;
	private String siteId;
	private String nodeName;
	private String nodeId;
	
	public SelectedMonitorProduct(){
		
	}
	public SelectedMonitorProduct(String productId, String name) {		
		this.productId = productId;
		this.name = name;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSiteId() {
		return siteId;
	}
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	public String getNodeName() {
		return nodeName;
	}
	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}	

}
