package com.fis.ist.monitoring.dto;

import com.fis.ist.monitoring.domain.POSTerminals;

public class POSTerminalsDto implements java.io.Serializable {
	
	private static final long serialVersionUID = 646182332543081905L;
	
	private String institutionId;
	private Long termRecordSeq;
	private String termIdLow;
	private String termIdHigh;
	private Long allwId;
	private String barAccess;
	private Long hourId;
	private String actualStartDate;
	private String terminationDate;
	private Long terminalIdNR;
	private String terminalType;
	private Long posMsgBrand;
	private String ownerEntityId;
	private String currCd;
	private String cpsEligible;
	private String defaultMcc;
	private String captureType;
	private String serialNumber;
	private String termEntityId;
	
	public POSTerminalsDto(){}
	
	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	public Long getTermRecordSeq() {
		return termRecordSeq;
	}
	
	public void setTermRecordSeq(Long termRecordSeq) {
		this.termRecordSeq = termRecordSeq;
	}

	public String getTermIdLow() {
		return termIdLow;
	}

	public void setTermIdLow(String termIdLow) {
		this.termIdLow = termIdLow;
	}

	public String getTermIdHigh() {
		return termIdHigh;
	}

	public void setTermIdHigh(String termIdHigh) {
		this.termIdHigh = termIdHigh;
	}

	public Long getAllwId() {
		return allwId;
	}

	public void setAllwId(Long allwId) {
		this.allwId = allwId;
	}

	public String getBarAccess() {
		return barAccess;
	}

	public void setBarAccess(String barAccess) {
		this.barAccess = barAccess;
	}

	public Long getHourId() {
		return hourId;
	}

	public void setHourId(Long hourId) {
		this.hourId = hourId;
	}

	public String getActualStartDate() {
		return actualStartDate;
	}

	public void setActualStartDate(String actualStartDate) {
		this.actualStartDate = actualStartDate;
	}

	public String getTerminationDate() {
		return terminationDate;
	}

	public void setTerminationDate(String terminationDate) {
		this.terminationDate = terminationDate;
	}

	public Long getTerminalIdNR() {
		return terminalIdNR;
	}

	public void setTerminalIdNR(Long terminalIdNR) {
		this.terminalIdNR = terminalIdNR;
	}

	public String getTerminalType() {
		return terminalType;
	}

	public void setTerminalType(String terminalType) {
		this.terminalType = terminalType;
	}

	public Long getPosMsgBrand() {
		return posMsgBrand;
	}

	public void setPosMsgBrand(Long posMsgBrand) {
		this.posMsgBrand = posMsgBrand;
	}

	public String getOwnerEntityId() {
		return ownerEntityId;
	}

	public void setOwnerEntityId(String ownerEntityId) {
		this.ownerEntityId = ownerEntityId;
	}

	public String getCurrCd() {
		return currCd;
	}

	public void setCurrCd(String currCd) {
		this.currCd = currCd;
	}

	public String getCpsEligible() {
		return cpsEligible;
	}

	public void setCpsEligible(String cpsEligible) {
		this.cpsEligible = cpsEligible;
	}

	public String getDefaultMcc() {
		return defaultMcc;
	}

	public void setDefaultMcc(String defaultMcc) {
		this.defaultMcc = defaultMcc;
	}

	public String getCaptureType() {
		return captureType;
	}

	public void setCaptureType(String captureType) {
		this.captureType = captureType;
	}

	
	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getTermEntityId() {
		return termEntityId;
	}

	public void setTermEntityId(String termEntityId) {
		this.termEntityId = termEntityId;
	}

	public void load(POSTerminals posTerminals) {		
		this.setInstitutionId(posTerminals.getInstitutionId());
		this.setTermRecordSeq(posTerminals.getTermRecordSeq());
		this.setTermIdLow(posTerminals.getTermIdLow());
		this.setTermIdHigh(posTerminals.getTermIdHigh());
		this.setAllwId(posTerminals.getAllwId());
		this.setBarAccess(posTerminals.getBarAccess());
		this.setHourId(posTerminals.getHourId());
		this.setActualStartDate(posTerminals.getActualStartDate());
		this.setTerminationDate(posTerminals.getTerminationDate());
		this.setTerminalIdNR(posTerminals.getTerminalIdNR());
		this.setTerminalType(posTerminals.getTerminalType());
		this.setPosMsgBrand(posTerminals.getPosMsgBrand());
		this.setOwnerEntityId(posTerminals.getOwnerEntityId());
		this.setCurrCd(posTerminals.getCurrCd());
		this.setCpsEligible(posTerminals.getCpsEligible());
		this.setDefaultMcc(posTerminals.getDefaultMcc());
		this.setCaptureType(posTerminals.getCaptureType());		
		this.setSerialNumber(posTerminals.getSerialNumber());
		this.setTermEntityId(posTerminals.getTermEntityId());
	}		
	
}
