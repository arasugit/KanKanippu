package com.fis.ist.monitoring.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.hibernate.jpa.QueryHints;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.common.services.MonitorConfigService;
import com.fis.ist.monitoring.dto.Pair;
import com.fis.ist.spring.HTTPRequestGetter;

public class ChipNonChipTransactionsDAO extends MonitorBaseDAO<Integer, Integer> {

	private static final ISTLogger log = ISTLogger.getLogger(ChipNonChipTransactionsDAO.class);
	// property constants

	@Override
	public Class<Integer> getEntityClass() {
		return Integer.class;
	}

	public List getAcquirerTxnSRC(String product, String fieldName) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");
			queryBuffer.append(
					" select distinct field_name, field_value0 as txnsrc, field_value1 as acquirer from cs_monglobalvalue where  product = ?  and  field_name=? ");

			String queryString = queryBuffer.toString();
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("txnsrc", StandardBasicTypes.STRING)
					.addScalar("acquirer", StandardBasicTypes.STRING);
			queryObject.setParameter(1, productId);
			queryObject.setParameter(2, fieldName);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Fetch the BD & TD from SQL#8 & SQL#9
	public List getTDBDRespCode(String fieldName) {
		try {
			String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");

			String queryString = SqlQueryProvider.getDBSqlQuery("CPNCPC_GBL_VAL_CTRL_RSP_CD");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString);
			queryObject.setParameter(1, productId);
			queryObject.setParameter(2, fieldName);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Successful & Rejected Combined count for onus, acquiring and issuing
	// transactions

	// Pass the businessDecline & technicalDeclineList here...
	public List getCombinedTransactions(List<String> txnSrc, List<String> txnDest, List<String> businessDecline,
			List<String> technicalDecline, String screenType, String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("CPNCPC_REQ_CMBND");
			if (screenType.equalsIgnoreCase("TXNSSC_REQ"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc in (:txnsrc) and txndest in (:txndest) ");
			else if (screenType.equalsIgnoreCase("ACQUIRING"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc in (:txnsrc) and txndest not in (:txndest) ");
			else if (screenType.equalsIgnoreCase("ISSUING"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc not in (:txnsrc) and txndest in (:txndest)  ");
			else
				queryString = queryString.replaceAll("FILTER_QUERY", "  ");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("txndest", StandardBasicTypes.STRING)
					.addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("ApprovedCount", StandardBasicTypes.STRING)
					.addScalar("DeclineCount", StandardBasicTypes.STRING)
					.addScalar("BusinessDecline", StandardBasicTypes.STRING)
					.addScalar("TechnicalDecline", StandardBasicTypes.STRING)
					.addScalar("ChipCount", StandardBasicTypes.STRING)
					.addScalar("NonChipCount", StandardBasicTypes.STRING);

			if (screenType.equalsIgnoreCase("TXNSSC_REQ") || screenType.equalsIgnoreCase("ACQUIRING")
					|| screenType.equalsIgnoreCase("ISSUING")) {
				queryObject.setParameterList("txndest", txnDest);
				queryObject.setParameterList("txnsrc", txnSrc);
			}
			queryObject.setParameterList("businessDeclineList", MonitorConfigService.convertToIntList(businessDecline));
			queryObject.setParameterList("technicalDeclineList",
					MonitorConfigService.convertToIntList(technicalDecline));
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// getCombinedTransactionsCount() for pagination : Successful & Rejected
	// Combined Count
	public int getCombinedTransactionsCount(List<String> txnSrc, List<String> txnDest, List<String> businessDecline,
			List<String> technicalDecline, String screenType, String fromDate, String toDate, String fromDateFormate,
			String toDateFormate) {
		try {
			log.debug("Getting Successful And Rejected Trans Count from db");

			String queryString = SqlQueryProvider.getDBSqlQuery("CPNCPC_REQ_CMBND_CNT");

			if (screenType.equalsIgnoreCase("TXNSSC_REQ"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc in (:txnsrc) and txndest in (:txndest) ");
			else if (screenType.equalsIgnoreCase("ACQUIRING"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc in (:txnsrc) and txndest not in (:txndest) ");
			else if (screenType.equalsIgnoreCase("ISSUING"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc not in (:txnsrc) and txndest in (:txndest)  ");
			else
				queryString = queryString.replaceAll("FILTER_QUERY", "  ");

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			if (screenType.equalsIgnoreCase("TXNSSC_REQ") || screenType.equalsIgnoreCase("ACQUIRING")
					|| screenType.equalsIgnoreCase("ISSUING")) {
				queryObject.setParameterList("txndest", txnDest);
				queryObject.setParameterList("txnsrc", txnSrc);
			}
			queryObject.setParameterList("businessDeclineList", MonitorConfigService.convertToIntList(businessDecline));
			queryObject.setParameterList("technicalDeclineList",
					MonitorConfigService.convertToIntList(technicalDecline));
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("Query Fails - getCombinedTransactionsCount", re);
			throw re;
		}
	}

	private List getFallbackTransactions(List<String> txnsrcList, List<String> acqsList, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, Integer pageNum, boolean setPaging) {

		try {
			log.debug("Getting Fallback Transactions from db");

			String queryString = SqlQueryProvider.getDBSqlQuery("CPNCPC_FBC_REQ");
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("txnsrc", StandardBasicTypes.STRING)
					.addScalar("acquirer", StandardBasicTypes.STRING).addScalar("termId", StandardBasicTypes.STRING)
					.addScalar("fallbackCount", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcList", txnsrcList);
			queryObject.setParameterList("acqsList", acqsList);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);

			if (setPaging) {
				setPaging(queryObject, pageNum);
			}

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails - getFallbackTransactions", re);
			throw re;
		}
	}

	public List getResponseCodesAndDesc() {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");

			String queryString = SqlQueryProvider.getDBSqlQuery("CPNCPC_RESPCODE_LIST");
			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("respCode", StandardBasicTypes.STRING)
					.addScalar("respCodeDesc", StandardBasicTypes.STRING);

			queryObject.setParameter(1, productId);

			Stream stream = queryObject.setHint(QueryHints.HINT_FETCH_SIZE, 100).getResultStream();

			List recordList = new ArrayList<>();
			stream.forEach(x -> {
				recordList.add(x);
			});

			return recordList;

		} catch (RuntimeException re) {
			log.error("getResponseCodesAndDesc Query Fails", re);
			throw re;
		}
	}

	public List getTxnLogsForSuccessAndRejTrans(String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, List<String> txnSrcs, boolean excludeTxnSrcs, String txndest, String issuer,
			int pageNum) {
		/*
		 * return getTransactionLogs(fromDate, toDate, fromDateFormate, toDateFormate,
		 * txnSrcs, excludeTxnSrcs, null, null, null, null, txndest, issuer, false,
		 * pageNum);
		 */
		return getTransactionLogs(fromDate, toDate, fromDateFormate, toDateFormate, null, excludeTxnSrcs, null, null,
				null, null, txndest, issuer, false, pageNum);
	}

	public int getTxnLogsCountForSuccessAndRejTrans(String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, List<String> txnSrcs, boolean excludeTxnSrcs, String txndest, String issuer) {
		return getTransactionLogsCount(fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs, excludeTxnSrcs, null,
				null, null, null, txndest, issuer, false);
	}

	public List<Pair<String, Integer>> getMerchantCountGroupedByInstitution() {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("CPNCPC_MERCH_CNT_BY_INST");
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("key", StandardBasicTypes.STRING)
					.addScalar("value", StandardBasicTypes.INTEGER);

			return (List<Pair<String, Integer>>) queryObject.setResultTransformer(Transformers.aliasToBean(Pair.class))
					.list();

		} catch (RuntimeException re) {
			log.error("getMerchantCountGroupedByInstitution - Query Fails", re);
			throw re;
		}
	}

	public List<Pair<String, Integer>> getConnectionCountGroupByServiceMail() {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("CPNCPC_CON_CNT_BY_SERVICE_MAIL");

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("key", StandardBasicTypes.STRING)
					.addScalar("value", StandardBasicTypes.INTEGER);

			return (List<Pair<String, Integer>>) queryObject.setResultTransformer(Transformers.aliasToBean(Pair.class))
					.list();

		} catch (RuntimeException re) {
			log.error("getMerchantCountGroupedByInstitution - Query Fails", re);
			throw re;
		}
	}

	// Transaction Logs
	private List getTransactionLogs(String fromDate, String toDate, String fromDateFormate, String toDateFormate,
			List<String> txnSrcs, boolean excludeTxnSrcs, List<String> acqs, String terminalId, String pCode,
			String pan, String txnDest, String issuer, boolean fallbackTxnOnly, int pageNum) {
		try {
			StringBuffer queryBuffer = new StringBuffer();

			queryBuffer.append(SqlQueryProvider.getDBSqlQuery("CPNCPC_LOG"));

			setTransactionLogsQueryFilter(queryBuffer, fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs,
					excludeTxnSrcs, acqs, terminalId, pCode, pan, txnDest, issuer, fallbackTxnOnly);

			if (pageNum > 0)
				queryBuffer.append("order by txnsrc, acquirer, chip_index, site_id");

			String queryString = queryBuffer.toString();

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chipindex", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING)
					.addScalar("istsysdate", StandardBasicTypes.TIMESTAMP)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.DATE)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("terminalId", StandardBasicTypes.STRING)
					.addScalar("pan", StandardBasicTypes.STRING);

			setTransactionLogsQueryParams(queryObject, fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs, acqs,
					terminalId, pCode, pan, txnDest, issuer);
			setPaging(queryObject, pageNum);

			Stream stream = queryObject.setHint(QueryHints.HINT_FETCH_SIZE, 500).getResultStream();

			List recordList = new ArrayList<>();
			stream.forEach(x -> {
				recordList.add(x);
			});

			return recordList;

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Transaction Logs Count
	private int getTransactionLogsCount(String fromDate, String toDate, String fromDateFormate, String toDateFormate,
			List<String> txnSrcs, boolean excludeTxnSrcs, List<String> acqs, String terminalId, String pCode,
			String pan, String txnDest, String issuer, boolean fallbackTxnOnly) {
		try {
			StringBuffer queryBuffer = new StringBuffer();

			queryBuffer.append("select count(1) as count from cs_monshclog_ext \n");
			setTransactionLogsQueryFilter(queryBuffer, fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs,
					excludeTxnSrcs, acqs, terminalId, pCode, pan, txnDest, issuer, fallbackTxnOnly);
			String queryString = queryBuffer.toString();
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			setTransactionLogsQueryParams(queryObject, fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs, acqs,
					terminalId, pCode, pan, txnDest, issuer);

			return (int) queryObject.uniqueResult();
		} catch (RuntimeException re) {
			log.error("getTransactionLogsCount Query Fails", re);
			throw re;
		}
	}

	private static void setTransactionLogsQueryFilter(StringBuffer queryBuffer, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, List<String> txnSrcs, boolean excludeTxnSrcs,
			List<String> acqs, String terminalId, String pCode, String pan, String txnDest, String issuer,
			boolean fallbackTxnOnly) {
		queryBuffer.append(" where ");

		if (!isEmpty(terminalId)) {
			queryBuffer.append(" termid = :termId and ");
		}

		if (txnSrcs != null && txnSrcs.size() > 0 && !excludeTxnSrcs) {
			queryBuffer.append(" txnsrc in (:txnsrcs) and ");
		}

		if (txnSrcs != null && txnSrcs.size() > 0 && excludeTxnSrcs) {
			queryBuffer.append(" txnsrc not in (:txnsrcs) and ");
		}

		if (acqs != null && acqs.size() > 0) {
			queryBuffer.append(" acquirer in (:acqs) and ");
		}

		if (!isEmpty(pCode)) {
			queryBuffer.append(" pcode = :pcode and ");
		}

		if (!isEmpty(pan)) {
			queryBuffer.append(" pan = :pan and ");
		}

		if (!isEmpty(txnDest)) {
			queryBuffer.append(" txndest = :txndest and ");
		}

		if (!isEmpty(issuer)) {
			queryBuffer.append(" issuer = :issuer and ");
		}

		if (PaymonUtils.isOracleDb())
			queryBuffer.append(
					" istsysdate between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) ");
		else if (PaymonUtils.isPostgressDb())
			queryBuffer.append(
					" istsysdate between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) ");

		if (fallbackTxnOnly) {
			queryBuffer.append(" and fallbackflg = 'Y' ");
		}
	}

	private static void setTransactionLogsQueryParams(Query queryObject, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, List<String> txnSrcs, List<String> acqs, String terminalId,
			String pCode, String pan, String txnDest, String issuer) {
		queryObject.setParameter("fromDate", fromDate);
		queryObject.setParameter("toDate", toDate);
		queryObject.setParameter("fromDateFormate", fromDateFormate);
		queryObject.setParameter("toDateFormate", toDateFormate);

		if (!isEmpty(terminalId)) {
			queryObject.setParameter("termId", terminalId);
		}

		if (txnSrcs != null && txnSrcs.size() > 0) {
			queryObject.setParameterList("txnsrcs", txnSrcs);
		}

		if (acqs != null && acqs.size() > 0) {
			queryObject.setParameterList("acqs", acqs);
		}

		if (!isEmpty(pCode)) {
			queryObject.setParameter("pcode", Integer.parseInt(pCode));
		}

		if (!isEmpty(pan)) {
			queryObject.setParameter("pan", pan);
		}

		if (!isEmpty(txnDest)) {
			queryObject.setParameter("txndest", txnDest);
		}

		if (!isEmpty(issuer)) {
			queryObject.setParameter("issuer", issuer);
		}
	}

	private static String setTransStatsLogsQueryFilter(String sqlQuery, String searchByFlag, String institution,
			String terminalId) {
		if (!isEmpty(institution)) {
			if ("S".equalsIgnoreCase(searchByFlag)) {
				// sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " and txnsrc = :institution
				// ");
				sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " txnsrc = :institution  ");
			} else if ("D".equalsIgnoreCase(searchByFlag)) {
				// sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " and txndest = :institution
				// ");
				sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " txndest = :institution  ");
			} else if ("B".equalsIgnoreCase(searchByFlag)) {
				// sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " and (txnsrc = :institution
				// OR txndest = :institution) ");
				sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " (txnsrc = :institution OR txndest = :institution)   ");
			} else {
				sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " ");
			}
		} else if (isEmpty(institution)) {
			sqlQuery = sqlQuery.replaceAll("FILTER_QUERY",
					" txnsrc in (select distinct txnsrc from cs_monshclog_ext)  ");
		}

		if (!isEmpty(terminalId)) {
			sqlQuery = sqlQuery.replaceAll("TERM_ID_FILTER", " and termid like :termId  ");
		} else {
			sqlQuery = sqlQuery.replaceAll("TERM_ID_FILTER", " ");
		}

		if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
			sqlQuery = sqlQuery.replaceAll("DATE_FILTER",
					" and to_char(istsysdate,:fromDateFormate) between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) ");
		} else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
			sqlQuery = sqlQuery.replaceAll("DATE_FILTER",
					" and to_timestamp(to_char(istsysdate,:fromDateFormate),:fromDateFormate) between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) ");
		}
		return sqlQuery;
	}

	private static void setTransStatsLogsQueryParams(Query queryObject, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, String institution, String terminalId) {
		queryObject.setParameter("fromDate", fromDate);
		queryObject.setParameter("toDate", toDate);
		queryObject.setParameter("fromDateFormate", fromDateFormate);
		queryObject.setParameter("toDateFormate", toDateFormate);

		if (!isEmpty(institution)) {
			queryObject.setParameter("institution", institution);
		}

		if (!isEmpty(terminalId)) {
			queryObject.setParameter("termId", terminalId);
		}
	}

	private static String convertWildSearchString(String value) {
		if (isEmpty(value))
			return value;

		if (hasOnlyAsterisks(value)) {
			return "";
		}
		return value.replace("*", "%");
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}

	private static boolean hasOnlyAsterisks(String input) {
		for (int i = 0; i < input.length(); i++) {
			if (input.charAt(i) != '*') {
				return false;
			}
		}
		return true;
	}

	private List getTransactionDashboardDetails(String currentDate, String chartType, Integer pageNum, String hour,
			Integer startTime, Integer endTime, String status) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("CPNCPC_DASH_DTL");
			queryString = SqlQueryProvider.addTransactionDashboardChartFilter(queryString, chartType, status);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chip_index", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING).addScalar("istsysdate", StandardBasicTypes.STRING)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.STRING)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("termid", StandardBasicTypes.STRING);

			if ("PEAKVOLUME".equals(chartType)) {
				queryObject.setParameter("hour", hour);
			} else if ("COMPTIME".equals(chartType)) {
				queryObject.setParameter("startTime", startTime);
				queryObject.setParameter("endTime", endTime);
			}

			queryObject.setParameter("currentDate", currentDate);

			if (pageNum != null) {
				setPaging(queryObject, pageNum.intValue());
			}

			return queryObject.list();

		} catch (Exception re) {
			log.error("getTransactionDashboardDetails Query Fails", re);
			throw re;
		}
	}

}

