package com.fis.ist.monitoring.dto;

import java.util.List;

public class IncidentDashboardDto implements java.io.Serializable {
private static final long serialVersionUID = 1L;
	
	private List<IncidentCountByStatusDto> statusList;
	private List<IncidentCountByHoursDto> hoursList;
	private List<IncidentCountByDaysDto> dayList;
	private List<IncidentCountByPriorityDto> priorityList;
	public List<IncidentCountByStatusDto> getStatusList() {
		return statusList;
	}
	public void setStatusList(List<IncidentCountByStatusDto> statusList) {
		this.statusList = statusList;
	}
	public List<IncidentCountByHoursDto> getHoursList() {
		return hoursList;
	}
	public void setHoursList(List<IncidentCountByHoursDto> hoursList) {
		this.hoursList = hoursList;
	}
	public List<IncidentCountByDaysDto> getDayList() {
		return dayList;
	}
	public void setDayList(List<IncidentCountByDaysDto> dayList) {
		this.dayList = dayList;
	}
	public List<IncidentCountByPriorityDto> getPriorityList() {
		return priorityList;
	}
	public void setPriorityList(List<IncidentCountByPriorityDto> priorityList) {
		this.priorityList = priorityList;
	}	
}
