package com.fis.ist.monitoring.common.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.cfg.XMLHelper;
import com.fis.ist.common.AppConstants;
import com.fis.ist.ent.AccessManager;
import com.fis.ist.ent.ApplicationPermission;
import com.fis.ist.ent.AtmMonNetAutoRefreshPermission;
import com.fis.ist.ent.CreatePassphraseFilePermission;
import com.fis.ist.ent.FormActionPermission;
import com.fis.ist.ent.FormButtonPermission;
import com.fis.ist.ent.FormPermission;
import com.fis.ist.ent.FormTabPermission;
import com.fis.ist.ent.GenKlcKeysPermission;
import com.fis.ist.ent.ISTMonCommandPermission;
import com.fis.ist.ent.ISTMonManagerPermission;
import com.fis.ist.ent.ISTUnixCommandPermission;
import com.fis.ist.ent.MBStartStopPermission;
import com.fis.ist.ent.MKCAccessManager;
import com.fis.ist.ent.PanMaskerPatternPermission;
import com.fis.ist.ent.VoiceAuthRefundPermission;
import com.fis.ist.ent.VolumeLicensePermission;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.controller.ControllerSupportConstants;
import com.fis.ist.services.vo.ApplicationInfo;
import com.fis.ist.services.vo.ModuleInfo;
import com.fis.ist.services.vo.RequestedPermission;
import com.fis.ist.spring.HTTPRequestGetter;

public class MonitorMenuService {
	private static final String PRODUCT_ID = "product_id";
	private static final String MENU_ITEM = "menuitem";
	private static final String APPLICATION = "application";
	private static final ISTLogger log = ISTLogger.getLogger(MonitorMenuService.class);
	private static final String TRUE = "true";
	private static boolean do_entitlement = false;
	private boolean do_trimming = false;
	static Document menuEvents = null;
	private static Document modules = null;
	private static Document applications = null;
	private static String applicationLabel = null;
	private static String mainAppImage = null;
	private static String applicationName = null;
	private static Map<String, String> imageMap = new HashMap<String, String>();

	public MonitorMenuService() {
		// super();
	}

	public MonitorMenuService(boolean do_entitlement, boolean do_trimming, boolean do_preload) throws Exception {
		// super(do_entitlement,do_trimming,do_preload);

		log.debug(
				"do_entitlement: " + do_entitlement + ", do_trimming: " + do_trimming + ", do_preload: " + do_preload);
		this.do_entitlement = do_entitlement;
		this.do_trimming = do_trimming;
		if (do_preload) {
			log.debug("preloading");
			try {
				loadMenuEvents(do_trimming, ControllerSupportConstants.SWITCH_PRODUCT_ID);
			} catch (Exception e) {
				log.error("caught an exception", e);
				throw e;
			}
			getModulesDoc();
			log.debug("done");
		}
		getMainAppList();

	}

	public Document getMenu(String productId) {
		menuEvents = null;
		return getMenuEvents(null, productId);
	}

	public List<String> getSelectedProduct() {
		List<String> productList = new ArrayList<>();
		HttpServletRequest request = HTTPRequestGetter.getRequest();
		HttpSession session = request.getSession(false);
		productList.add((String) session.getAttribute(PRODUCT_ID));
		return productList;
	}

	public Document getMenuEvents(UserContext userContext, String productId) {
		Document m2 = null;
		try {
			if (menuEvents == null)
				loadMenuEvents(do_trimming, productId);
			m2 = (Document) menuEvents.cloneNode(true);
			if (do_entitlement && do_trimming)
				trimMenu(m2, true, productId);
		} catch (Throwable e) {
			log.error("caught an exception", e);
			return null;
		}
		return m2;
	}

	synchronized private static void loadMenuEvents(boolean do_trimming, String productId) throws Exception {
		if (menuEvents != null)
			return;
		Document m = XMLHelper.loadDocument("MenuEvents.xml", "MenuEvents.xsd");
		Document apps = getApplicationsDoc();
		if (apps != null) {
			Node appsNode = null;
			NodeList nl = m.getElementsByTagName("menuitem");
			int list_len = nl.getLength();
			for (int j = 0; j < list_len; ++j) {
				Element e1 = (Element) nl.item(j);
				if (e1 == null)
					continue;
				String id = e1.getAttribute("id");
				if ("applications".equals(id)) {
					appsNode = e1;
					break;
				}
			}
			if (appsNode != null) {
				NodeList lst = apps.getElementsByTagName("application");
				int n = lst.getLength();
				log.debug("Got " + n + " application elements");
				if (n <= 1) {
					log.debug("Skipping applications submenu, only 1 element");
				} else {
					for (int i = 0; i < n; ++i) {
						Element elem = (Element) lst.item(i);
						if (elem == null)
							continue;
						Element newNode = m.createElement("menuitem");
						String name = elem.getAttribute("name");
						newNode.setAttribute("label", name);
						String url = elem.getAttribute("url");
						newNode.setAttribute("url", url);
						String id = elem.getAttribute("id");
						newNode.setAttribute("application", id);
						appsNode.appendChild(newNode);
					}
				}
			} else {
				log.debug("Missing applications node");
			}
		}
		cleanText(m);
		if (do_trimming)
			trimMenu(m, false, productId);
		menuEvents = m;
	}

	private static void cleanText(Node n) {
		Node next_n = null;
		for (Node n2 = n.getFirstChild(); n2 != null; n2 = next_n) {
			next_n = n2.getNextSibling();
			short t = n2.getNodeType();
			switch (t) {
			case Node.TEXT_NODE:
				n2.getParentNode().removeChild(n2);
				break;
			default:
				cleanText(n2);
				break;
			}
		}
	}

	private static void trimMenu(Document doc, boolean use_entitlement, String productId) {
		AccessManager am = null;
		if (use_entitlement)
			am = AccessManager.getInstance();
		NodeList nl = doc.getElementsByTagName("menuitem");
		boolean do_debug = log.isDebugEnabled();
		for (int pass = 0;; ++pass) {
			int del_cnt = 0;
			int i = 0;
			for (;;) {
				Element elem = (Element) nl.item(i);
				if (elem == null)
					break;
				String module_name = elem.getAttribute("module_name");
				String label = elem.getAttribute("label");
				String application = elem.getAttribute("application");
				String showOnlyForCLR = elem.getAttribute("ISTCLR"); //this flag is added to show the screen if clearing is installed
				String showOnlyForMAS = elem.getAttribute("ISTMAS"); //this flag is added to show the screen if mas is installed
				String showOnlyForSWITCH = elem.getAttribute("ISTSWT"); //this flag is added to show the screen is pos is installed
				String showOnlyForCortex = elem.getAttribute("CORTEX"); //this flag is added to show the screen if cortex is installed
				
				// make it visible if any one of the flag is set to true.
				Boolean isScreenVisible= false;
				Boolean isVisibleForCLR= false;
				Boolean isVisibleForMAS= false;
				Boolean isVisibleForSWITCH= false;
				Boolean isVisibleForCORTEX= false;
				//Clearing or MAS or SW 
				
				if  (showOnlyForCLR !=null && showOnlyForCLR.equalsIgnoreCase("true")==true){
					if(ControllerSupportConstants.CLEARING_PRODUCT_ID.equals(productId)){
							isVisibleForCLR = true;
					}
				}

				if  (showOnlyForMAS !=null && showOnlyForMAS.equalsIgnoreCase("true")==true){
					if(ControllerSupportConstants.MAS_PRODUCT_ID.equals(productId)){
						isVisibleForMAS = true;
					}
				}
				
				if  (showOnlyForSWITCH !=null && showOnlyForSWITCH.equalsIgnoreCase("true")==true){
					if(ControllerSupportConstants.SWITCH_PRODUCT_ID.equals(productId)){
						isVisibleForSWITCH = true;
					}
				}
				if  (showOnlyForCortex !=null && showOnlyForCortex.equalsIgnoreCase("true")==true){
					if(ControllerSupportConstants.CORTEX_PRODUCT_ID.equals(productId)){
							isVisibleForCORTEX = true;
					}
				}
		
					if ((showOnlyForCLR !=null && showOnlyForCLR.equalsIgnoreCase("true")==true) || (showOnlyForMAS !=null && showOnlyForMAS.equalsIgnoreCase("true")==true) 
							|| (showOnlyForSWITCH !=null && showOnlyForSWITCH.equalsIgnoreCase("true")==true)
							|| (showOnlyForCortex !=null && showOnlyForCortex.equalsIgnoreCase("true")==true)) {
						if (!isVisibleForMAS && !isVisibleForSWITCH && !isVisibleForCORTEX) {
							if (isVisibleForCLR)
								isScreenVisible=true;
							else
								isScreenVisible=false;
						}
						else if (!isVisibleForCLR && !isVisibleForSWITCH && !isVisibleForCORTEX)
						{
							if (isVisibleForMAS)
								isScreenVisible=true;
							else
								isScreenVisible=false;
						}
						else if (!isVisibleForCLR && !isVisibleForMAS && !isVisibleForCORTEX)
						{
							if (isVisibleForSWITCH)
								isScreenVisible=true;
							else
								isScreenVisible=false;
						}
						else if (!isVisibleForCLR && !isVisibleForMAS && !isVisibleForSWITCH)
						{
							if (isVisibleForCORTEX)
								isScreenVisible=true;
							else
								isScreenVisible=false;
						}
						else
							{isScreenVisible = true;}
						
						if(isScreenVisible==false)
						{
							if (do_debug)
								log.debug("Removing ...");
							del_cnt++;
							elem.getParentNode().removeChild(elem);
							continue;
						}
						
					}

				if (do_debug)
					log.debug("label: " + label);
				if (module_name.length() == 0 && application.length() == 0) {

					if (elem.hasChildNodes())
						i++;
					else {
						if (do_debug)
							log.debug("Removing ...");
						del_cnt++;
						elem.getParentNode().removeChild(elem);
					}
					continue;
				}
				if (do_debug) {
					log.debug("module name: " + module_name + ", application: " + application);
				}
				if (pass == 0) {
					boolean needs_delete = false;
					try {
						if (module_name.length() > 0) {
							ModuleInfo mi = getModuleInfoByName(module_name);
							needs_delete = (mi == null);
							if (!needs_delete && use_entitlement) {
								if (am != null)
									needs_delete = !am.hasPermission(new FormPermission(mi.auth_id, "A"));
							}
						} else if (application.length() > 0) {
							String url = elem.getAttribute("url");
							needs_delete = url.length() == 0;
							if (!needs_delete && use_entitlement) {
								if (am != null)
									needs_delete = !am.hasPermission(new ApplicationPermission(application, "A"));
							}
						} else {
							needs_delete = true;
						}
					} catch (Exception e) {
						log.error("Caught a permission exception", e);
						needs_delete = true;
					}
					if (needs_delete) {
						if (do_debug)
							log.debug("Removing entry");
						elem.getParentNode().removeChild(elem);
						del_cnt++;
						continue;
					}
				}
				i++;
			}
			if (del_cnt == 0)
				break;
		}
	}

	private static synchronized Document getModulesDoc() {
		if (modules != null)
			return modules;
		modules = XMLHelper.loadDocument("Modules.xml", "Modules.xsd");
		return modules;
	}

	private static void getMainAppList() {
		Document applications = XMLHelper.loadDocument("Applications.xml", "Applications.xsd");
		NodeList lst = applications.getElementsByTagName("application");
		int n = lst.getLength();
		for (int i = 0; i < n; ++i) {

			Element elem = (Element) lst.item(i);
			if (elem == null)
				continue;

			String appid = elem.getAttribute("id");
			if (appid == null || appid.isEmpty()) {
				continue;
			}
			String appname = elem.getAttribute("name");
			if (appname == null || appname.isEmpty()) {
				appname = ConfigParams.getInstance().getProperty("ist.application." + appid + ".name");
			}

			String appurl = elem.getAttribute("url");
			if (appurl == null || appurl.isEmpty()) {
				appurl = ConfigParams.getInstance().getProperty("ist.application." + appid + ".url");
			}
			if (StringUtil.isNotEmpty(appid) && StringUtil.isNotEmpty(appname) && StringUtil.isNotEmpty(appurl)) {
				if (appurl.equalsIgnoreCase("main.html") || appurl.equalsIgnoreCase("ng-main.html")) {
					applicationName = appid;
					applicationLabel = appname;
					mainAppImage = imageMap.get(appid);
					break;
				}

			}
		}
	}

	static ModuleInfo getModuleInfoByName(String module_name) {
		NodeList lst = getModulesDoc().getElementsByTagName("module");
		int n = lst.getLength();
		for (int i = 0; i < n; ++i) {
			Element elem = (Element) lst.item(i);
			if (elem == null)
				continue;
			if (module_name.equals(elem.getAttribute("name")))
				return makeModuleInfo(elem);
		}
		return null;
	}

	private static ModuleInfo makeModuleInfo(Element elem) {
		ModuleInfo mi = new ModuleInfo();
		mi.module_name = elem.getAttribute("name");
		mi.path = elem.getAttribute("path");
		mi.description = elem.getAttribute("description");
		String form_auth_id = elem.getAttribute("auth_id");
		if (form_auth_id.length() == 0)
			form_auth_id = mi.module_name;
		mi.auth_id = form_auth_id;
		return mi;
	}

	private static synchronized Document getApplicationsDoc() {
		if (applications != null)
			return applications;
		applications = XMLHelper.loadDocument("Applications.xml", "Applications.xsd");
		NodeList lst = applications.getElementsByTagName("application");
		int n = lst.getLength();
		for (int i = 0; i < n; ++i) {
			boolean skip_element = false;
			Element elem = (Element) lst.item(i);
			if (elem == null)
				continue;
			String appid = elem.getAttribute("id");
			if (appid == null || appid.isEmpty()) {
				log.error("Application id not specified");
				skip_element = true;
			}
			String appname = null;
			String appurl;
			if (!skip_element) {
				appname = elem.getAttribute("name");
				if (appname == null || appname.isEmpty()) {
					appname = ConfigParams.getInstance().getProperty("ist.application." + appid + ".name");
					if (appname == null) {
						skip_element = true;
					} else {
						// TODO: Validate name
						elem.setAttribute("name", appname);
					}
				}
			}
			if (!skip_element) {
				appurl = elem.getAttribute("url");
				if (appurl == null || appurl.isEmpty()) {
					appurl = ConfigParams.getInstance().getProperty("ist.application." + appid + ".url");
					if (appurl == null || appurl.isEmpty()) {
						skip_element = true;
					} else {
						// TODO: Validate url
						elem.setAttribute("url", appurl);
					}
				}
			}
			if (skip_element) {
				elem.getParentNode().removeChild(elem);
				i--;
				n--;
			}
		}
		return applications;
	}

	public static List<ApplicationInfo> getApplications() {
		ArrayList<ApplicationInfo> a_list = new ArrayList<ApplicationInfo>();
		AccessManager am = null;
		if (do_entitlement)
			am = AccessManager.getInstance();
		try {
			getApplicationsDoc();
			NodeList lst = applications.getElementsByTagName("application");
			int n = lst.getLength();
			for (int i = 0; i < n; ++i) {
				Element elem = (Element) lst.item(i);
				if (elem == null)
					continue;
				ApplicationInfo ai = makeApplicationInfo(elem);
				if (do_entitlement) {
					if (am != null) {
						if (am.hasPermission(new ApplicationPermission(ai.getId(), "A")))
							a_list.add(ai);
						else
							log.debug("Skipping " + ai.getName() + ", not authorized");
					}
				} else
					a_list.add(ai);
			}
		} catch (Throwable e) {
			log.error("Caught an exception: ", e);
		}
		return a_list;
	}

	private static ApplicationInfo makeApplicationInfo(Element elem) {
		ApplicationInfo ai = new ApplicationInfo(elem.getAttribute("id"), elem.getAttribute("name"),
				elem.getAttribute("url"));
		return ai;
	}

	public RequestedPermission[] checkPermissions(String moduleURL, RequestedPermission[] perms) {
		AccessManager am = null;
		// private static MKCAccessManager mkc_am =null;
		if (do_entitlement) {
			am = AccessManager.getInstance();
			// mkc_am = MKCAccessManager.getInstance();
		}
		log.debug("checkPermissions, moduleURL = " + moduleURL);
		for (RequestedPermission perm_vo : perms) {
			log.debug("perm: " + perm_vo);
			if (do_entitlement) {
				perm_vo.allowed = false;
				try {
					if (perm_vo instanceof com.fis.ist.services.vo.FormPermission) {
						if (am != null) {
							log.debug("form permission: " + perm_vo.name);
							perm_vo.allowed = am.hasPermission(new FormPermission(perm_vo.name, "A"));
						}
					} else if (perm_vo instanceof com.fis.ist.services.vo.FormTabPermission) {
						if (am != null) {
							log.debug("form tab permission: " + perm_vo.name);
							perm_vo.allowed = am.hasPermission(new FormTabPermission(perm_vo.name, "A"));
						}
					} else if (perm_vo instanceof com.fis.ist.services.vo.FormButtonPermission) {
						if (am != null) {
							log.debug("form button permission: " + perm_vo.name);
							perm_vo.allowed = am.hasPermission(new FormButtonPermission(perm_vo.name, "A"));
						}
					} else if (perm_vo instanceof com.fis.ist.services.vo.FormActionPermission) {
						com.fis.ist.services.vo.FormActionPermission perm_vo2 = (com.fis.ist.services.vo.FormActionPermission) perm_vo;
						log.debug("form action permission: " + perm_vo2.name + ", action=" + perm_vo2.action);
						if (am != null) {

							perm_vo.allowed = am
									.hasPermission(new FormActionPermission(perm_vo2.name, perm_vo2.action));

						}
					} else if (perm_vo instanceof com.fis.ist.services.vo.MKCPermission) {
						
					} else if (perm_vo instanceof com.fis.ist.services.vo.ISTMonManagerPermission) {
						log.debug("istmon monitor permission: " + perm_vo.name);
						if (am != null)
							perm_vo.allowed = am.hasPermission(new ISTMonManagerPermission(perm_vo.name, "A"));
					} else if (perm_vo instanceof com.fis.ist.services.vo.ISTMonCommandPermission) {
						log.debug("istmon command permission: " + perm_vo.name);
						if (am != null)
							perm_vo.allowed = am.hasPermission(new ISTMonCommandPermission(perm_vo.name, "A"));
					} else if (perm_vo instanceof com.fis.ist.services.vo.VolumeLicensePermission) {
						log.debug("Volume License Manager permission: " + perm_vo.name);
						if (am != null)
							perm_vo.allowed = am.hasPermission(new VolumeLicensePermission(perm_vo.name, "A"));
					} else if (perm_vo instanceof com.fis.ist.services.vo.ISTUnixCommandPermission) {
						log.debug("unix command permission: " + perm_vo.name);
						if (am != null)
							perm_vo.allowed = am.hasPermission(new ISTUnixCommandPermission(perm_vo.name, "", "A"));
					} else if (perm_vo instanceof com.fis.ist.services.vo.CreatePassphraseFilePermission) {
						log.debug("create passphrase file permission");
						if (am != null)
							perm_vo.allowed = am.hasPermission(new CreatePassphraseFilePermission());
					} else if (perm_vo instanceof com.fis.ist.services.vo.PanMaskerPatternPermission) {
						log.debug("Pan masker pattern permission");
						if (am != null)
							perm_vo.allowed = am.hasPermission(new PanMaskerPatternPermission());
					} else if (perm_vo instanceof com.fis.ist.services.vo.GenKlcKeysPermission) {
						log.debug("generate KLC keys permission");
						if (am != null)
							perm_vo.allowed = am.hasPermission(new GenKlcKeysPermission());
					} else if (perm_vo instanceof com.fis.ist.services.vo.MBStartStopPermission) {
						log.debug("MB start/stop permission");
						if (am != null)
							perm_vo.allowed = am.hasPermission(new MBStartStopPermission());
					} else if (perm_vo instanceof com.fis.ist.services.vo.AtmMonNetAutoRefreshPermission) {
						log.debug("Atm Mon Net Auto Refresh Permission");
						if (am != null)
							perm_vo.allowed = am.hasPermission(new AtmMonNetAutoRefreshPermission());
					} else if (perm_vo instanceof com.fis.ist.services.vo.VoiceAuthRefundPermission) {
						log.debug("Voice AUTH Refund permission");
						if (am != null)
							perm_vo.allowed = am.hasPermission(new VoiceAuthRefundPermission());
					} else {
						log.debug("Unrecognized permission type: " + perm_vo.getClass().getName());
					}
				} catch (Throwable e) {
					log.error("Caught an exception: ", e);
				}
			} else
				perm_vo.allowed = true;
		}
		return perms;
	}
	
	public static String getCurrentAppName() {
		return applicationName;
	}
}
