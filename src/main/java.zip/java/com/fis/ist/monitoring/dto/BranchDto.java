package com.fis.ist.monitoring.dto;

public class BranchDto implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	String branch;
	String branchUpPercentage;	
	String branchDownPercentage;

	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getBranchUpPercentage() {
		return branchUpPercentage;
	}
	public void setBranchUpPercentage(String branchUpPercentage) {
		this.branchUpPercentage = branchUpPercentage;
	}
	public String getBranchDownPercentage() {
		return branchDownPercentage;
	}
	public void setBranchDownPercentage(String branchDownPercentage) {
		this.branchDownPercentage = branchDownPercentage;
	}
	
}
