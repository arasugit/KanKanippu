package com.fis.ist.monitoring.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.services.handler.ATMAvailabilityHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class ATMDataSourceFaultDetailService extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(ATMDataSourceFaultDetailService.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		ATMAvailabilityHandler aah = new ATMAvailabilityHandler(CustomConstants.ATMFLTVIEW);

		if (action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = aah.getDSFaultDetails(userContext, requestParams);
		} else {
			log.error("**** ATM Data Source Fault Detail Service: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}

		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}
}