package com.fis.ist.monitoring.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.services.handler.TransactionStatsProcCodeHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class TransactionStatsProcCode extends CRUDSubService {

	private static final ISTLogger log = ISTLogger.getLogger(TransactionStatsProcCode.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		TransactionStatsProcCodeHandler aah = new TransactionStatsProcCodeHandler();
		
		if (action.compareTo(MonitorConstants.ACTION_QUERY) == 0) {
			workReq = aah.getTransactions(userContext, requestParams);
		} else {
			log.error("**** TransactionStatsList : " + action);
			throw new Exception("Unknown action error");
		}
		
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}

}
