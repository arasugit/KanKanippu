package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.ForeignKeysCheckException;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MKCHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.RetentionConfigDAO;
import com.fis.ist.monitoring.domain.RetentionConfig;
import com.fis.ist.monitoring.dto.RetentionConfigDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.EditableListRow;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

public class RetentionConfigHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(RetentionConfigHandler.class);
	private static String reqTypeId = MonitorConstants.DATA_RT_REQ;
	private static String formAuthId = "DATARTCONF";

	public RetentionConfigHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}


	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.DATA_RT_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.DATA_RT_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.DATA_RT_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.DATA_RT_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.DATA_RT_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("RetentionConfigHandler - Load List ");
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");
		String siteId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("site_id");
		String nodeId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("node_id");
		String nodeName = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("node_name");

		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));

		int total = 0;
		List<RetentionConfig> results = new ArrayList<RetentionConfig>();
		RetentionConfig findRecord = new RetentionConfig();

		if (StringUtil.isNotEmpty(nodeId)) {
			try {
				findRecord.setNodeId(Integer.parseInt(nodeId));
			} catch (Exception nfe) {
				log.debug("Invalid NodeId [" + nodeId + "]", nfe);
			}
		}
		if (StringUtil.isNotEmpty(siteId)) {
			try {
				findRecord.setSiteId(Integer.parseInt(siteId));
			} catch (Exception nfe) {
				log.debug("Invalid SiteId [" + siteId + "]", nfe);
			}
		}

		findRecord.setNodeName(nodeName);
		findRecord.setProduct(productId);
		String table = params.get("tableName");
		if (StringUtil.isNotEmpty(table)) {
			try {
				table = table.trim();
				findRecord.setTableName(table);
			} catch (Exception nfe) {
				log.debug("Invalid Table name [" + table + "]", nfe);
			}
		}

		String keyFields = params.get("keyFields");
		if (StringUtil.isNotEmpty(keyFields)) {
			try {

				findRecord.setKeyFields(keyFields);
			} catch (Exception nfe) {
				log.debug("Invalid keyFields [" + keyFields + "]", nfe);
			}
		}
		
		if (!needs_total) {
			results = loadListData(findRecord, pageNum);
		} else if (needs_total) {
			total = loadListDataCount(findRecord);
			results = loadListData(findRecord, pageNum);
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List<RetentionConfigDto> workRows = getNewWorkRows(workRequest, uiMetaData);

		if (results == null || results.size() == 0) {
			return;
		}

		for (RetentionConfig entity : results) {
			if (entity != null) {
				RetentionConfigDto dto = new RetentionConfigDto();
				dto.load(entity);
				dto.setDbAction('x');
				if (isMKCEnabled) {
					dto.setOrignalRow(dto);
				}
				workRows.add(dto);
			}
		}

	}

	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		currentfield = fields.get("productId");
		fieldValue = params.get("productId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("siteId");
		fieldValue = params.get("siteId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	public HashMap<String, String> getDBMapping() {
		HashMap<String, String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product", "product");

		return dtoMapping;
	}

	private List<RetentionConfigDto> getNewRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.DATA_RT_COL);
		workCollection.setSectionId(MonitorConstants.DATA_RT_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.DATA_RT_TAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<RetentionConfigDto> workRows = new ArrayList<RetentionConfigDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.DATA_RT_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<RetentionConfig> loadListData(RetentionConfig model, int pageNum) {
		log.debug("RetentionConfigHandler - Load RetentionConfig records - loadListData()");
		RetentionConfigDAO dao = new RetentionConfigDAO();
		List<RetentionConfig> results = dao.findByExample(model, pageNum);

		return results;
	}

	private int loadListDataCount(RetentionConfig model) {
		log.debug("RetentionConfigHandler - Load Task Command records - loadListDataCount()");
		RetentionConfigDAO dao = new RetentionConfigDAO();
		int count = dao.getTotalByExample(model);
		return count;
	}

	public WorkRequest getDataForAdd(UserContext userContext, WorkRequest workRequest) throws Exception {
		if (workRequest != null) {
			WorkCollection wc = workRequest.getCollections().get(MonitorConstants.DATA_RT_COL);
			wc.getRows().add(0, getNewRowInstance());
			return workRequest;
		} else {
			WorkRequest workReq = new WorkRequest();
			UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.DATA_RT_REQ);

			try {
				workReq.setRequestId("0");
				workReq.setRequestState("DRAFT");

				workReq.setRequestTypeId(MonitorConstants.DATA_RT_REQ);

				Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
				workReq.setNextStates(nextStates);

				// Set values of all tabs to be modifiable
				Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
				WorkTabStatus workStatus = new WorkTabStatus();
				workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
				workStatus.setTag(MonitorConstants.DATA_RT_TAB);
				workStatus.setModifyable("Y");
				tabStatus.put(MonitorConstants.DATA_RT_TAB, workStatus);

				workReq.setTabStatus(tabStatus);

				addWorkFields(workReq, uiMetaData);

				workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null);

				Map<String, WorkField> fields = workReq.getFields();
				Collection<WorkField> cfields = fields.values();

				for (WorkField field : cfields) {
					field.setModifyable("Y");
					field.setVisible("Y");
				}

			} catch (Exception ex) {
				WorkRequestHelper.getInstance().reportException(log, ex, workReq);
			}
			return workReq;
		}
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data) throws Exception {
		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);

				data.setUiMetaData(uiMetaData);
				data.initLastModified();

				if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
					workRequest.setSwitchId(userContext.getSwitchID());
				}

				// Create a logical collection for add
				List<RetentionConfigDto> workRows = getNewWorkRows(workRequest, uiMetaData);
				workRows.add(getNewRowInstance());
			}

		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private RetentionConfigDto getNewRowInstance() {
		RetentionConfigDto dto = new RetentionConfigDto();
		dto.setDbAction('a');
		return dto;
	}

	private List<RetentionConfigDto> getNewWorkRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.DATA_RT_COL);
		workCollection.setSectionId(MonitorConstants.DATA_RT_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.DATA_RT_TAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<RetentionConfigDto> workRows = new ArrayList<RetentionConfigDto>();

		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.DATA_RT_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	public WorkRequest saveSinglePageRecords(UserContext userContext, WorkRequest workRequest,
			HashMap<String, Boolean> permMap) {
		try {
			workRequest = saveWorkRequest(userContext, workRequest, permMap);
		} catch (Exception e) {
			log.error("Exception occured in the Save Single Pags Records" + e.getMessage());
		}
		return workRequest;
	}

	public WorkRequest saveWorkRequest(UserContext userContext, WorkRequest workRequest,
			HashMap<String, Boolean> permMap) throws Exception {
		if (validateCollectionField(workRequest, MonitorConstants.DATA_RT_COL))
			return workRequest;

		save(userContext, workRequest, permMap);
		return workRequest;
	}

	private void save(UserContext userContext, WorkRequest workRequest, HashMap<String, Boolean> permMap) {
		// check if contact field data is present
		try {
			Map<String, WorkField> fields = workRequest.getFields();
			if (fields == null) {
				WorkRequestHelper.getInstance().reportError("Work fields not found", workRequest);
				return;
			}

			boolean isInvalidData = false;
			String value = null;
			List<RetentionConfigDto> corrCollection = new ArrayList<RetentionConfigDto>();
			List<String> duplicateCollection = new ArrayList<String>();
			RetentionConfigDAO dao = new RetentionConfigDAO();
			WorkCollection wc = workRequest.getCollections().get(MonitorConstants.DATA_RT_COL);
			List<RetentionConfigDto> rows = wc.getRows();
			RetentionConfig globalValue = new RetentionConfig();
			int previousId = 0;
			// Only the affected rows will be available here.

			for (int i = 0; i < rows.size(); i++) {
				RetentionConfigDto row = rows.get(i);
				row.setErrorFlag(false);
				String flag = row.getDbAction().toString();
				if (flag.equals("a") && !(permMap.get("I") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for adding a record");
					isInvalidData = true;
				} else if (flag.equals("c") && !(permMap.get("U") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for updating a record");
					isInvalidData = true;
				} else if (flag.equals("d") && !(permMap.get("D") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for deleting a record");
					isInvalidData = true;
				}

				RetentionConfigDto model = new RetentionConfigDto();
				if (flag.equalsIgnoreCase("a")) {

					HttpServletRequest request = HTTPRequestGetter.getRequest();
					String productId = (String) request.getSession(false).getAttribute("product_id");
					String nodeId = (String) request.getSession(false).getAttribute("node_id");
					String nodeName = (String) request.getSession(false).getAttribute("node_name");
					String siteId = (String) request.getSession(false).getAttribute("site_id");
					productId = (productId == null ? "" : productId);
					row.setProduct(productId);
					row.setNodeName(nodeName);
					try {
						row.setNodeId(Integer.parseInt(nodeId));
					} catch (Exception e) {
						log.error("Error while Parsing Node Id" + e.getMessage());
					}
					try {
						row.setSiteId(Integer.parseInt(siteId));
					} catch (Exception e) {
						log.error("Error while Parsing Site Id" + e.getMessage());
					}
				}

				String data = row.getKeyFields();
				if (StringUtil.isEmpty(data)) {
					row.setErrorFlag(true);
					row.setErrorMessage("Key Fields cannot be empty");
					isInvalidData = true;
					continue;
				}

				data = row.getTableName();
				if (StringUtil.isEmpty(data)) {
					row.setErrorFlag(true);
					row.setErrorMessage("Table cannot be empty");
					isInvalidData = true;
					continue;
				}

				Integer retData = null;

				try {
					if (row.getRetentionDays() != null) {
						retData = Integer.valueOf(row.getRetentionDays());
					} else {
						row.setErrorFlag(true);
						row.setErrorMessage("Purging Days cannot be empty");
						isInvalidData = true;
						continue;
					}
				} catch (NumberFormatException ex) {
					row.setErrorFlag(true);
					row.setErrorMessage("Purging Days should be numeric");
					isInvalidData = true;
					continue;
				}

				String purgeOption = row.getPurgeOption();

				if (purgeOption == null) {
					row.setErrorFlag(true);
					row.setErrorMessage("purge Option Days cannot be empty");
					isInvalidData = true;
					continue;
				}

				if (purgeOption != null && purgeOption.length() > 2) {
					row.setErrorFlag(true);
					row.setErrorMessage("Purging Option length cannot be greater than 2");
					isInvalidData = true;
					continue;
				}

				String key = "" + row.getKeyFields() + "" + row.getTableName();

				if (isMKCEnabled && isCheckerAction) {
					if (duplicateCollection.contains(key + row.getMkcStatus())
							&& AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())) {
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same Key fields and Table name");
						isInvalidData = true;
						continue;
					} else {
						duplicateCollection.add(key + row.getMkcStatus());
					}
				} else {
					if (!flag.equals("d")) {
						if (duplicateCollection.contains(key)) {
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same Key fields and Table name");
							isInvalidData = true;
							continue;
						} else {
							duplicateCollection.add(key);
						}
					}
				}
				row.store(globalValue);
				if (isMKCEnabled && isCheckerAction) {
					if ("a".equals(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())
							&& dao.isDuplicate(globalValue)) {
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same Key fields and Table name");
						isInvalidData = true;
						continue;
					}
				} else {
					if (flag.equals("a")) {

						if (dao.isDuplicate(globalValue)) {
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same Key fields and  Table name");
							isInvalidData = true;
							continue;
						}
					}
				}

				if (isMKCEnabled && isCheckerAction && AppConstants.MKC_SP_ACTION_REWORK.equals(row.getMkcStatus())
						&& "d".equalsIgnoreCase(flag)) {
					row.setErrorFlag(true);
					row.setErrorMessage("Deleted record cannot be set to rework");
					isInvalidData = true;
					continue;
				}

				if (isMKCEnabled && isCheckerAction && "d".equalsIgnoreCase(flag)
						&& AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())) {
					RetentionConfig dbObj = dao.findById(model.getId());
					if (dbObj == null) {
						row.setErrorFlag(true);
						row.setErrorMessage("The record is already deleted. Please reject the record.");
						isInvalidData = true;
						continue;
					}
					dao.getSession().evict(dbObj);
				}
				corrCollection.add(row);
			}

			if (isInvalidData) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0106");
				return;
			}

			if (isMKCEnabled && !isCheckerAction) { // maker changes should go into the queue
				// insertCollectionIntoMKC(corrCollection, workRequest.getRequestTypeId(),
				// getUserId(userContext));
				for (EditableListRow edlsrow : corrCollection) {
					if (edlsrow != null) {
						RetentionConfigDto dto = (RetentionConfigDto) edlsrow;
					}
				}
			} else {
				for (RetentionConfigDto dto : corrCollection) {
					String action = dto.getDbAction().toString();
					if (!isMKCEnabled) { // non mkc
						if ("c".equalsIgnoreCase(action)) {
							RetentionConfig dbObj = dao.findById(dto.getId()); // error
							if (dbObj != null) {
								dto.store(dbObj);
								dao.attachDirty(dbObj);
							}
						} else if ("a".equalsIgnoreCase(action)) {
							RetentionConfig entity = new RetentionConfig();
							dto.setId(dao.getMaxId() + 1);
							dto.store(entity);
							dao.save(entity);
						} else if ("d".equalsIgnoreCase(action)) {
							RetentionConfig entity = new RetentionConfig();
							dto.store(entity);
							dao.delete(entity);
						}
					} else if (isMKCEnabled && isCheckerAction) { // MKC Checker
						String status = dto.getMkcStatus();
						if ((AppConstants.MKC_SP_ACTION_APPROVE).equals(status)) {
							if ("c".equalsIgnoreCase(action)) {
								RetentionConfig entity = dao.findById(dto.getId());
								if (entity != null) {
									dto.store(entity);
									dao.attachDirty(entity);
								}
							} else if ("a".equalsIgnoreCase(action)) {
								RetentionConfig entity = new RetentionConfig();
								dto.store(entity);
								dao.save(entity);
							} else if ("d".equalsIgnoreCase(action)) {
								RetentionConfig entity = new RetentionConfig();
								dto.store(entity);
								dao.delete(entity);
							}
							MKCHandler.getInstance().ApproveMKCRecord(dto.getMkcId(), getUserId(userContext),
									dto.getMkcRemarks(), dto.getMkcScheduleDt());
						} else if (AppConstants.MKC_SP_ACTION_REJECT.equals(status)
								|| AppConstants.MKC_SP_ACTION_REWORK.equals(status)) {
							MKCHandler.getInstance().RejectOrReturnRecord(dto.getMkcId(), getUserId(userContext),
									dto.getMkcRemarks(), dto.getMkcScheduleDt(), status);
						} else {
						}
					}
				}
			}
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_NONE);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_SUCCESS);
			workRequest.setErrorDetail("");
			rows.clear();
		} catch (Exception e) {
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail(e.getMessage());
			if (e instanceof ForeignKeysCheckException) {
				workRequest.setMessageSubstitutions(((ForeignKeysCheckException) e).getChildTables());
			}
		}
	}
}