package com.fis.ist.monitoring.dto;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.domain.MonitorAtmCra;
import com.fis.ist.monitoring.domain.MonitorAtmCraId;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class MonitorAtmCraDto extends EditableListRowForSDK implements Cloneable{
	
	
	private static final long serialVersionUID = 1L;

	private static final ISTLogger log = ISTLogger.getLogger(MonitorAtmCraDto.class);
	
	private MonitorAtmCraId id; 
	
	private String institutionId; // INSTITUTIONID
	private String craBranch; // CRA_BRANCH
	private String address; // ADDRESS
	private String country; // COUNTRY
	private String state; // STATE
	private String city; // CITY
	private String pincode; // PINCODE
	private String name; // NAME
	private String mobile; // MOBILE
	private String designation; // DESIGNATION
	private String telephone; // TELEPHONE
	private String email; // EMAIL
	
	private String oldInstitutionId; 
	private String oldCraBranch;
	private MonitorAtmCraId oldId; 
	
	
	private MonitorAtmCraDto originalRow;
	
	
	public void load(MonitorAtmCra model)
	{
		
		setInstitutionId(model.getId().getInstitutionId());
		setCraBranch(model.getId().getCraBranch());
		setAddress(model.getAddress());
		setCountry(model.getCountry());
		setState(model.getState());
		setCity(model.getCity());
		setPincode(model.getPincode());
		setName(model.getName());
		setMobile(model.getMobile());
		setDesignation(model.getDesignation());
		setTelephone(model.getTelephone());
		setEmail(model.getEmail());
	}
	
	public void store(MonitorAtmCra model){
		
		// Setting ID info
		MonitorAtmCraId atmCraId = new MonitorAtmCraId();

		atmCraId.setInstitutionId(institutionId);
		atmCraId.setCraBranch(craBranch);
				
		model.setId(atmCraId);
		model.setAddress(address);
		model.setCountry(country);
		model.setState(state);
		model.setCity(city);
		model.setPincode(pincode);
		model.setName(name);
		model.setMobile(mobile);
		model.setDesignation(designation);
		model.setTelephone(telephone);
		model.setEmail(email);
	}
	
	public MonitorAtmCraId getId() {
		return id;
	}
	
	public void setId(MonitorAtmCraId monitorAtmCraId) {
		this.id = monitorAtmCraId;
	}
	
	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}


	public String getCraBranch() {
		return craBranch;
	}

	public void setCraBranch(String craBranch) {
		this.craBranch = craBranch;
	}

	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}


	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}


	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}


	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	
	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	
	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getOldInstitutionId() {
		return oldInstitutionId;
	}

	public void setOldInstitutionId(String oldInstitutionId) {
		this.oldInstitutionId = oldInstitutionId;
	}

	public String getOldCraBranch() {
		return oldCraBranch;
	}

	public void setOldCraBranch(String oldCraBranch) {
		this.oldCraBranch = oldCraBranch;
	}
	
	public MonitorAtmCraId getOldId() {
		return oldId;
	}

	public void setOldId(MonitorAtmCraId oldId) {
		this.oldId = oldId;
	}

	public MonitorAtmCraDto getOriginalRow() {
		return originalRow;
	}
	
	
	public MonitorAtmCraDto(MonitorAtmCraId id, String institutionId, String craBranch, String address, String country,
			String state, String city, String pincode, String name, String mobile, String designation, String telephone,
			String email, MonitorAtmCraDto originalRow) {
		super();
		this.id = id;
		this.institutionId = institutionId;
		this.craBranch = craBranch;
		this.address = address;
		this.country = country;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
		this.name = name;
		this.mobile = mobile;
		this.designation = designation;
		this.telephone = telephone;
		this.email = email;
		this.originalRow = originalRow;
	}

	public MonitorAtmCraDto() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getFormKey() {
		return null;
	}
	
	public void setOriginalRow(MonitorAtmCraDto originalRow) {
		try {
			if (originalRow != null)
				this.originalRow = (MonitorAtmCraDto) originalRow.clone();
		} catch (Exception e) {
			log.error(e);
		}
	}

	@Override
	public String toString() {
		return "MonitorAtmCraDto [id=" + id + ", institutionId=" + institutionId + ", craBranch=" + craBranch
				+ ", address=" + address + ", country=" + country + ", state=" + state + ", city=" + city + ", pincode="
				+ pincode + ", name=" + name + ", mobile=" + mobile + ", designation=" + designation + ", telephone="
				+ telephone + ", email=" + email + ", oldInstitutionId=" + oldInstitutionId + ", oldCraBranch="
				+ oldCraBranch + ", oldId=" + oldId + ", originalRow=" + originalRow + "]";
	}

}
