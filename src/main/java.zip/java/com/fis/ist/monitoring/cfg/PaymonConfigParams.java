package com.fis.ist.monitoring.cfg;

import java.util.Properties;
import java.util.ResourceBundle;

import com.fis.ist.log.ISTLogger;
import com.oasis.ist.prot_props.ProtectedPropertyBundle;
import com.oasis.ist.prot_props.ProtectedPropertyException;
public class PaymonConfigParams {
	private static final ISTLogger log = ISTLogger.getLogger(PaymonConfigParams.class);

	protected PaymonConfigParams() { }

	static PaymonConfigParams instance = new PaymonConfigParams();
	protected Properties properties = null;
	protected Properties oracleProperties = null;

	public static PaymonConfigParams getInstance() {
		return instance;
	}

	public synchronized String getProperty(String name) {
		if (properties == null)
			return null;
		return properties.getProperty(name);
	}

	public synchronized Properties getProperties(String prefix) {
		if (properties == null)
			return null;
		Properties props = new Properties();
		for (Object k : properties.keySet()) {
			String ks = (String) k;
			if (ks.startsWith(prefix))
				props.setProperty(ks.substring(prefix.length()), properties.getProperty(ks));
		}
		return props;
	}

	public ResourceBundle getPropertyBundle(String name) {
		try {
			return new ProtectedPropertyBundle(name);
		} catch (ProtectedPropertyException e) {
			log.error("Can't create protected property bundle", e);
			return null;
		}
	}

	public synchronized void setProperties(Properties props) {
		if (props == null) {
			properties = null;
			return;
		}
		properties = (Properties) props.clone();
		if (log.isTraceEnabled()) {
			log.trace("setProperties");
			for (Object k : properties.keySet()) {
				String ks = (String) k;
				String val = properties.getProperty(ks);
				log.trace(ks + " = " + val);
			}
		}
	}

	public synchronized void setAdditionalProperties(Properties props) {
		if (props == null)
			return;
		if (properties == null) {
			setProperties(props);
			return;
		}
		properties.putAll(props);
		if (log.isTraceEnabled()) {
			log.trace("addProperties");
			for (Object k : props.keySet()) {
				String ks = (String) k;
				String val = props.getProperty(ks);
				log.trace(ks + " = " + val);
			}
		}
	}

	public Integer getIntProperty(String name) {
		String val = getProperty(name);
		if (val == null)
			return null;
		Integer ret = null;
		try {
			ret = Integer.valueOf(val);
		} catch (NumberFormatException e) {
			log.error("Invalid number format for " + name);
		}
		return ret;
	}

	public synchronized void setOracleProperties(Properties cmdprops) {
		if (cmdprops == null) {
			oracleProperties = null;
			return;
		}
		oracleProperties = (Properties) cmdprops.clone();
		if (log.isTraceEnabled()) {
			log.trace("setProperties");
			for (Object k : oracleProperties.keySet()) {
				String ks = (String) k;
				String val = oracleProperties.getProperty(ks);
				log.trace(ks + " = " + val);
			}
		}
	}

	public synchronized String getOracleSqlQuery(String name) {
		if (oracleProperties == null)
			return null;
		return oracleProperties.getProperty(name);
	}
	public synchronized String getPostgreSqlQuery(String name) {
		if (properties == null)
			return null;
		return properties.getProperty(name);
	}

}
