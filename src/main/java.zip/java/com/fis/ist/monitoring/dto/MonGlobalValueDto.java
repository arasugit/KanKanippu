package com.fis.ist.monitoring.dto;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.domain.MonGlobalValue;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class MonGlobalValueDto extends EditableListRowForSDK implements Cloneable {

	private static final long serialVersionUID = 1L;

	private static final ISTLogger log = ISTLogger.getLogger(MonGlobalValueDto.class);

	private String product;
	private String fieldName;
	private String fieldValue0;
	private String fieldValue1;
	private String fieldValue2;
	private String fieldValue3;
	private String fieldValue4;
	private String fieldValueDesc;
	private Integer id;
	
	private MonGlobalValueDto orignalRow;
	
	public void load(MonGlobalValue model)
	{
		setId(model.getId());
		setProduct(model.getProduct());
		setFieldName(model.getFieldName());
		setFieldValue0(model.getFieldValue0());
		setFieldValue1(model.getFieldValue1());
		setFieldValue2(model.getFieldValue2());
		setFieldValue3(model.getFieldValue3());
		setFieldValue4(model.getFieldValue4());
		setFieldValueDesc(model.getFieldValueDesc());
	}
	
	public void store(MonGlobalValue model){
		model.setId(id);
		model.setProduct(product);
		model.setFieldName(fieldName);
		model.setFieldValue0(fieldValue0);
		model.setFieldValue1(fieldValue1);
		model.setFieldValue2(fieldValue2);
		model.setFieldValue3(fieldValue3);
		model.setFieldValue4(fieldValue4);
		model.setFieldValueDesc(fieldValueDesc);
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldValue0() {
		return fieldValue0;
	}

	public void setFieldValue0(String fieldValue0) {
		this.fieldValue0 = fieldValue0;
	}

	public String getFieldValue1() {
		return fieldValue1;
	}

	public void setFieldValue1(String fieldValue1) {
		this.fieldValue1 = fieldValue1;
	}

	public String getFieldValue2() {
		return fieldValue2;
	}

	public void setFieldValue2(String fieldValue2) {
		this.fieldValue2 = fieldValue2;
	}

	public String getFieldValue3() {
		return fieldValue3;
	}

	public void setFieldValue3(String fieldValue3) {
		this.fieldValue3 = fieldValue3;
	}

	public String getFieldValue4() {
		return fieldValue4;
	}

	public void setFieldValue4(String fieldValue4) {
		this.fieldValue4 = fieldValue4;
	}

	public String getFieldValueDesc() {
		return fieldValueDesc;
	}

	public void setFieldValueDesc(String fieldValueDesc) {
		this.fieldValueDesc = fieldValueDesc;
	}

	public MonGlobalValueDto getOrignalRow() {
		return orignalRow;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	@Override
	public String getFormKey() {
		return "product";
	}

	public void setOrignalRow(MonGlobalValueDto orignalRow) {
		try {
			if (orignalRow != null)
				this.orignalRow = (MonGlobalValueDto) orignalRow.clone();
		} catch (Exception e) {
			log.error(e);
		}
	}

}
