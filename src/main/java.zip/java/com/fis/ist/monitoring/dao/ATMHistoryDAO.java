package com.fis.ist.monitoring.dao;

import static com.fis.ist.common.OracleDaoConstants.DEPRECATION;
import static com.fis.ist.common.OracleDaoConstants.RAWTYPES;
import static com.fis.ist.common.OracleDaoConstants.UNCHECKED;

import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.ATMTotals;

@SuppressWarnings({ RAWTYPES, UNCHECKED, DEPRECATION })
public class ATMHistoryDAO extends MonitorBaseDAO<ATMTotals, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(ATMHistoryDAO.class);

	// Get ATM Transaction Details
	public List<ATMTotals> getAtmTransactions(String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, String institution, String groupName, String unit, String terminalId, int pageNum,
			Boolean setPaging) {

		List<ATMTotals> atmHistoryList = null;
		try {
			String query = SqlQueryProvider.getDBSqlQuery("ATM_TOTAL_HIST");

			query = setATMHistoryQueryFilter(query, institution, groupName, unit, terminalId);

			terminalId = convertWildSearchString(terminalId);

			Query queryObject = getSession().createSQLQuery(query).addScalar("institutionId", StandardBasicTypes.STRING)
					.addScalar("groupName", StandardBasicTypes.STRING).addScalar("unit", StandardBasicTypes.LONG)
					.addScalar("terminalId", StandardBasicTypes.STRING).addScalar("type", StandardBasicTypes.STRING)
					.addScalar("currency", StandardBasicTypes.LONG).addScalar("count", StandardBasicTypes.LONG)
					.addScalar("amount", StandardBasicTypes.LONG).addScalar("resetTime", StandardBasicTypes.STRING)
					.addScalar("prevCount", StandardBasicTypes.LONG).addScalar("prevAmount", StandardBasicTypes.LONG);

			setATMHistoryQueryParams(queryObject, fromDate, toDate, fromDateFormate, toDateFormate, institution,
					groupName, unit, terminalId);

			if (setPaging) {
				setPaging(queryObject, pageNum);
			}

			atmHistoryList = (List<ATMTotals>) queryObject
					.setResultTransformer(Transformers.aliasToBean(ATMTotals.class)).list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}

		return atmHistoryList;
	}

	private static String setATMHistoryQueryFilter(String query, String institution, String groupName, String unit,
			String terminalId) {

		StringBuffer queryBuffer = new StringBuffer(" where ");

		if (!isEmpty(institution))
			queryBuffer.append(" institutionId = :institution and ");

		if (!isEmpty(groupName))
			queryBuffer.append(" group_name = :groupName and ");

		if (!isEmpty(unit)) {
			queryBuffer.append(" unit = :unit and ");
		}

		if (!isEmpty(terminalId))
			queryBuffer.append(selectQueryString(terminalId));

		if (PaymonUtils.isOracleDb())
			queryBuffer.append(
					" RESET_TIME between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) ");
		else if (PaymonUtils.isPostgressDb())
			queryBuffer.append(
					" RESET_TIME between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) ");

		query = query.replaceAll("FILTER_QUERY", queryBuffer.toString());
		return query;
	}

	private static void setATMHistoryQueryParams(Query queryObject, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, String institution, String groupName, String unit,
			String terminalId) {
		queryObject.setParameter("fromDate", fromDate);
		queryObject.setParameter("toDate", toDate);
		queryObject.setParameter("fromDateFormate", fromDateFormate);
		queryObject.setParameter("toDateFormate", toDateFormate);

		if (!isEmpty(institution)) {
			queryObject.setParameter("institution", institution);
		}

		if (!isEmpty(groupName)) {
			queryObject.setParameter("groupName", groupName);
		}

		if (!isEmpty(unit)) {
			queryObject.setParameter("unit", Long.parseLong(unit));
		}

		if (!isEmpty(terminalId)) {
			queryObject.setParameter("terminalId", terminalId);
		}
	}

	private static String selectQueryString(String value) {
		if (value.indexOf("*") > -1)
			return " trim(termid) like :terminalId and ";
		else
			return " trim(termid) = :terminalId and ";
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}

	private static String convertWildSearchString(String value) {
		if (isEmpty(value))
			return value;

		if (hasOnlyAsterisks(value)) {
			return "";
		}

		return value.replace("*", "%");
	}

	private static boolean hasOnlyAsterisks(String input) {
		for (int i = 0; i < input.length(); i++) {
			if (input.charAt(i) != '*') {
				return false;
			}
		}
		return true;
	}

	public Class<ATMTotals> getEntityClass() {
		return ATMTotals.class;
	}
}
