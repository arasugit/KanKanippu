package com.fis.ist.monitoring.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "CS_MONCRA_MASTER", uniqueConstraints = @UniqueConstraint(columnNames = { "INSTITUTIONID", "CRA_BRANCH" }))
public class MonitorAtmCra implements java.io.Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String address; // ADDRESS
	private String country; // COUNTRY
	private String state; // STATE
	private String city; // CITY
	private String pincode; // PINCODE
	private String name; // NAME
	private String mobile; // MOBILE
	private String designation; // DESIGNATION
	private String telephone; // TELEPHONE
	private String email; // EMAIL
	
//	@EmbeddedId
	private MonitorAtmCraId id;
	
	public MonitorAtmCra () {}
	
	@EmbeddedId
	@AttributeOverrides( {
		@AttributeOverride(name = "institutionId", column = @Column(name="INSTITUTIONID", nullable = false, length = 10)),
		@AttributeOverride(name = "craBranch", column = @Column(name="CRA_BRANCH", nullable = false, length = 50))
	})
	public MonitorAtmCraId getId() {
		return id;
	}
	public void setId(MonitorAtmCraId id) {
		this.id = id;
	}
	@Column(name="ADDRESS", nullable = true, length = 100)
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}


	@Column(name="COUNTRY", nullable = true, length = 50)
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}


	@Column(name="STATE", nullable = true, length = 50)
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}


	@Column(name="CITY", nullable = true, length = 50)
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}


	@Column(name="PINCODE", nullable = true, length = 50)
	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}


	@Column(name="NAME", nullable = true, length = 50)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	@Column(name="MOBILE", nullable = true, length = 50)
	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	
	@Column(name="DESIGNATION", nullable = true, length = 50)
	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	
	@Column(name="TELEPHONE", nullable = true, length = 16)
	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	
	@Column(name="EMAIL", nullable = true, length = 200)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public MonitorAtmCra(String address, String country, String state, String city, String pincode, String name,
			String mobile, String designation, String telephone, String email, MonitorAtmCraId id) {
		super();
		this.address = address;
		this.country = country;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
		this.name = name;
		this.mobile = mobile;
		this.designation = designation;
		this.telephone = telephone;
		this.email = email;
		this.id = id;
	}

	@Override
	public String toString() {
		return "MonitorAtmCra [address=" + address + ", country=" + country + ", state=" + state + ", city=" + city
				+ ", pincode=" + pincode + ", name=" + name + ", mobile=" + mobile + ", designation=" + designation
				+ ", telephone=" + telephone + ", email=" + email + ", id=" + id + "]";
	}
}
