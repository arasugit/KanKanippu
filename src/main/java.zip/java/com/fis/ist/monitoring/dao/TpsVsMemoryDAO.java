package com.fis.ist.monitoring.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.type.descriptor.sql.SmallIntTypeDescriptor;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.TpsVsMemory;
import com.fis.ist.spring.HTTPRequestGetter;

@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class TpsVsMemoryDAO extends MonitorBaseDAO<TpsVsMemory, TpsVsMemory> {
	private static final ISTLogger log = ISTLogger.getLogger(TpsVsMemoryDAO.class);

	public List<String> getList() {
		log.debug("Inside TPS Vs Memory - getList");
		return null;
	}

	public List findMemoryData(String type, String fromDate, String toDate, String dateFromate, int pageNum) {
		log.debug("TpsVsMemoryDAO - finding TpsVsMemory instance by findTpsVsMem");
		HttpServletRequest request = HTTPRequestGetter.getRequest();
		String productId = (String) request.getSession(false).getAttribute("product_id");
		String siteId = (String) request.getSession(false).getAttribute("site_id");
		String nodeId = (String) request.getSession(false).getAttribute("node_id");
		String nodeName = (String) request.getSession(false).getAttribute("node_name");
				 
		try {
			StringBuffer queryBuffer = null ;
			System.out.println("findTpsVsMem  TYPE :::" + type);
			if (type.equalsIgnoreCase("5MIN")) {
				queryBuffer = new StringBuffer(SqlQueryProvider.getDBSqlQuery("TPSMEMDATA_5MIN"));
			} else if (type.equalsIgnoreCase("CUSTOM")) {
				queryBuffer = new StringBuffer(SqlQueryProvider.getDBSqlQuery("TPSMEMDATA_CUSTOM"));
			}
			String queryString = queryBuffer.toString();
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("site_id", StandardBasicTypes.STRING)
					.addScalar("logdate", StandardBasicTypes.STRING).addScalar("mem_total", StandardBasicTypes.STRING)
					.addScalar("mem_used", StandardBasicTypes.STRING).addScalar("mem_free", StandardBasicTypes.STRING)
					.addScalar("mem_used_percent", StandardBasicTypes.STRING)
					.addScalar("swap_total", StandardBasicTypes.STRING)
					.addScalar("swap_used", StandardBasicTypes.STRING).addScalar("swap_free", StandardBasicTypes.STRING)
					.addScalar("cpu_user", StandardBasicTypes.STRING).addScalar("cpu_system", StandardBasicTypes.STRING)
					.addScalar("current_tps", StandardBasicTypes.STRING);

			if (type.equalsIgnoreCase("CUSTOM")) {
				queryObject.setParameter("fromDate", fromDate);
				queryObject.setParameter("toDate", toDate);
				queryObject.setParameter("dateFormate", dateFromate);
				// queryObject.setParameter("toDateFormate", toDateFormate);
			}
			queryObject.setParameter("productId", productId);
			queryObject.setParameter("siteId", Integer.valueOf(siteId));
			queryObject.setParameter("nodeId", Integer.valueOf(nodeId));
			if (pageNum > -1)
				setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("TpsVsMemoryDAO - findTpsVsMem failed", re);
			throw re;
		}
	}

	public List getTpsData(String type, String fromDate, String toDate, String dateFromate, int pageNum) {
		log.debug("TpsVsMemoryDAO - finding TpsVsMemory instance by findTpsVsMem");
		HttpServletRequest request = HTTPRequestGetter.getRequest();
		String productId = (String) request.getSession(false).getAttribute("product_id");
		String siteId = (String) request.getSession(false).getAttribute("site_id");
		String nodeId = (String) request.getSession(false).getAttribute("node_id");
		String nodeName = (String) request.getSession(false).getAttribute("node_name");
		try {
			StringBuffer queryBuffer = null;
			System.out.println("findTpsVsMem  TYPE :::" + type);
			if (type.equalsIgnoreCase("5MIN")) {
				queryBuffer = new StringBuffer(SqlQueryProvider.getDBSqlQuery("TPSDATA_5MIN"));
			} else if (type.equalsIgnoreCase("CUSTOM")) {
				queryBuffer = new StringBuffer(SqlQueryProvider.getDBSqlQuery("TPSDATA_CUSTOM"));
			}
			String queryString = queryBuffer.toString();
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("site_id", StandardBasicTypes.STRING)
					.addScalar("logdate", StandardBasicTypes.STRING)
					.addScalar("current_tps", StandardBasicTypes.STRING);
			if (type.equalsIgnoreCase("CUSTOM")) {
				queryObject.setParameter("fromDate", fromDate);
				queryObject.setParameter("toDate", toDate);
				queryObject.setParameter("dateFormate", dateFromate);
			}
			queryObject.setParameter("productId", productId);
			queryObject.setParameter("siteId", Integer.valueOf(siteId));
			queryObject.setParameter("nodeId", Integer.valueOf(nodeId));
			if (pageNum > -1)
				setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("TpsVsMemoryDAO - findTpsVsMem failed", re);
			throw re;
		}
	}

	public void altersession() {
		log.debug("altersession list..");
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TPSMEM_ALTERSESSION");;

			Query queryObject = createSQLQuery(queryString);

			int i = queryObject.executeUpdate();

			System.out.println("session altered :" + i);

		} catch (RuntimeException re) {
			log.error("Exception Occured in getTransactions  list.. failed", re);
			throw re;
		}
	}

	@Override
	public Class<TpsVsMemory> getEntityClass() {
		return TpsVsMemory.class;
	}

}
