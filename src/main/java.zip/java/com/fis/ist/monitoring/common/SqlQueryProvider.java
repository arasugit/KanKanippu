package com.fis.ist.monitoring.common;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.fis.ist.monitoring.cfg.PaymonConfigParams;

public class SqlQueryProvider {
	public static final List<String> fiveMintablist = Collections.unmodifiableList(
			Arrays.asList("TRANS_STATS_ISSUER", "TXNISS_REQ", "TRANSSTATS", "TXNSTS_REQ", "TXNSHT_REQ", "TXNTYPEREQ", "POSMAKE"));

	public static final List<String> atmTabList = Collections.unmodifiableList(Arrays.asList("INVATM_REQ_COUNT",
			"INVATM_REQ", "ATMCTE_REQ_COUNT", "ATMCTE_REQ", "ATMTOT_REQ_COUNT", "ATMTOT_REQ", "ATMDWM_REQ_GETTRMID",
			"ATMDWM_REQ", "ATMDWB_REQ_GETTRMID", "ATMDWB_REQ", "ATMDWS_REQ", "ATMUPT_REQ", "ATMFLTVIEW", "ATMRTCASH",
			"GET_BRNCH_SITE", "ATM_CONTD_ATMLST", "ATM_UP_TRMNLS", "ATM_UP_TRMNLS1", "ATM_TOTL_BYSWTCH",
			"ATM_UP_BYSWTCH", "ATM_OOS_BYSWTCH", "ATM_TRMNL_PRCNT_BYSITE", "ATM_TRMNL_PRCNT_BYBRNCH",
			"ATM_CNFGD_BYMAKE", "ATM_TOTL_RUN_BYMKE", "ATM_FLT_COUNT", "DPENCASH_COUNT", "DPENCASH",
			"SWITCH_COMMAND_TSKCMD_TYPE", "SWITCH_COMMAND_BINSTATUS_TYPE", "SWITCH_COMMAND_BINSTATUS_TYPE_BY_INSTID",
			"SWITCH_COMMAND_DB_DETAILS", "SWITCH_PORT_DETAILS", "SWITCH_TRACE_DETAILS", "SWITCH_DEBUGINFO_BY_FILENAME",
			"SWITCH_RESOURCES_USED", "SWITCH_ALLOCATED_BASIC_CONFIGURATIONS", "RESPONSE_GROUP_CODE"));

	public static String getDBSqlQuery(String sqlName) {

		if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
			return PaymonConfigParams.getInstance().getPostgreSqlQuery(sqlName);
		} else if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
			return PaymonConfigParams.getInstance().getOracleSqlQuery(sqlName);
		} else {
			return "NoSQL";
		}
	}
	
	public static String manipulatingPrefixSuffixforATMTabs(String prefixSuffix, String module) {
		
		String queryString = "";
		
		if (isATMTab(module)) {
			
			if(("prefix").equalsIgnoreCase(prefixSuffix)) {
				if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
					queryString = "SELECT * from (SELECT targetQuery.*,rownum as rnum from (";
				} else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
					queryString = "SELECT * from (SELECT targetQuery.*,row_number() over() as rnum from (";
				}
			}
			
			if(("suffix").equalsIgnoreCase(prefixSuffix)) {
				if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
					queryString = " )targetQuery where rownum <=?) where rnum>=? ";
				} else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
					queryString = " ) as targetQuery limit ?) as pagenationCount where rnum>=?";
				}
			}
			
		}
		
		return queryString;
	}

	// CURRENT_TIMESTAMP
	public static String appendCriteiaTrans(String sqlQuery, String type) {
		if (is5MinTab(type)) {
			if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				sqlQuery = sqlQuery.replaceAll("SCREEN_TYPE_QUERY", " and cmshclog.istsysdate >= sysdate -5/(24*60) ");
			else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				sqlQuery = sqlQuery.replaceAll("SCREEN_TYPE_QUERY",
						" and cmshclog.istsysdate>=  now()-interval '5 minutes' ");
		} else if (type.equalsIgnoreCase("HOURLY")) {
			if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				sqlQuery = sqlQuery.replaceAll("SCREEN_TYPE_QUERY", " and  cmshclog.istsysdate >= sysdate -1/24  ");
			else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				sqlQuery = sqlQuery.replaceAll("SCREEN_TYPE_QUERY",
						" and  cmshclog.istsysdate>=  now()-interval '1 hour'  ");
		} else if (type.equalsIgnoreCase("DAILY")) {
			if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				sqlQuery = sqlQuery.replaceAll("SCREEN_TYPE_QUERY",
						" and  trunc(cmshclog.istsysdate) = trunc(sysdate) ");
			else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				sqlQuery = sqlQuery.replaceAll("SCREEN_TYPE_QUERY",
						" and  DATE_TRUNC('day',cmshclog.istsysdate) >=  DATE_TRUNC('day', CURRENT_DATE) ");
		} else if (type.equalsIgnoreCase("WEEKLY")) {
			if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				sqlQuery = sqlQuery.replaceAll("SCREEN_TYPE_QUERY",
						" and trunc(cmshclog.istsysdate) >=  trunc(sysdate - to_char(sysdate,'D') +1)   and trunc(cmshclog.istsysdate) < = trunc(sysdate) ");
			else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				sqlQuery = sqlQuery.replaceAll("SCREEN_TYPE_QUERY",
						" and DATE_TRUNC('day',cmshclog.istsysdate) >=  DATE_TRUNC('week', CURRENT_DATE) and DATE_TRUNC('day',cmshclog.istsysdate) <=  DATE_TRUNC('day', CURRENT_DATE) ");
		} else if (type.equalsIgnoreCase("MONTHLY")) {
			if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				sqlQuery = sqlQuery.replaceAll("SCREEN_TYPE_QUERY",
						" and to_char(cmshclog.istsysdate,'MM/YYYY') = to_char(sysdate, 'MM/YYYY') ");
			else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				sqlQuery = sqlQuery.replaceAll("SCREEN_TYPE_QUERY",
						" and TO_CHAR(cmshclog.istsysdate, 'MM/YYYY') = TO_CHAR(CURRENT_DATE,'MM/YYYY') ");
		}
		return sqlQuery;
	}

	public static boolean is5MinTab(String type) {
		return fiveMintablist.contains(type);
	}

	public static String addTransactionStatsDetailsMsgTypeFilter(String sqlQuery, String txnStatus) {

		txnStatus = txnStatus != null ? txnStatus.toUpperCase() : "";

		switch (txnStatus) {
		case "APPROVAL":
			sqlQuery = sqlQuery.replaceAll("MSG_TYPE_FILTER", " and msgtype in (110,210) and respcode = 0  ");
			break;
		case "DECLINE":
			sqlQuery = sqlQuery.replaceAll("MSG_TYPE_FILTER", " and msgtype in (110,210) and respcode != 0   ");
			break;
		case "REVERSAL":
			sqlQuery = sqlQuery.replaceAll("MSG_TYPE_FILTER", " and msgtype in (410,430) ");
			break;
		default:
			break;
		}
		return sqlQuery;
	}
	
	public static String addTransactionDashboardChartFilter(String sqlQuery, String chartType, String status) {

		chartType = chartType != null ? chartType.toUpperCase() : "";

		switch (chartType) {
		case "PEAKVOLUME":
			sqlQuery = sqlQuery.replaceAll("CHART_TYPE_FILTER", " and cast(substring(to_char(trantime, 'fm000000'), 1, 2) as numeric) || ':00' =  :hour");
			break;
		case "AUTHDENIAL":
			sqlQuery = sqlQuery.replaceAll("CHART_TYPE_FILTER", " and msgtype = 110 and respcode != 0 ");
			break;
		case "COMPTIME":
			sqlQuery = sqlQuery.replaceAll("CHART_TYPE_FILTER", " and (txn_end_time - txn_start_time) >= cast(:startTime as integer) " + 
					" and (txn_end_time - txn_start_time) <= cast(:endTime as integer) ");
			break;
		case "FAILURECNT":
			if ("Failure".equals(status)) {
				sqlQuery = sqlQuery.replaceAll("CHART_TYPE_FILTER", " and respcode != 0 ");
			} else {
				sqlQuery = sqlQuery.replaceAll("CHART_TYPE_FILTER", " and respcode = 0 ");
			}
			
			break;
		default:
			break;
		}
		return sqlQuery;
	}

	public static boolean isATMTab(String type) {
		System.out.println("type " + type);
		return atmTabList.contains(type);
	}
}
