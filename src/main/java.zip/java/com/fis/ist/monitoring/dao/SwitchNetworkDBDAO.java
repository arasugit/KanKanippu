package com.fis.ist.monitoring.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.ATMAvailable;
import com.fis.ist.monitoring.dto.SwitchNetworkDBDto;
import com.fis.ist.spring.HTTPRequestGetter;

@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class SwitchNetworkDBDAO extends MonitorBaseDAO<ATMAvailable, Integer> {

	private static final ISTLogger log = ISTLogger.getLogger(SwitchNetworkDBDAO.class);

	private static final String SWITCH_COMMAND_TSKCMD_TYPE = "SWITCH_COMMAND_TSKCMD_TYPE";
	private static final String SWITCH_COMMAND_BINSTATUS_TYPE = "SWITCH_COMMAND_BINSTATUS_TYPE";
	private static final String SWITCH_COMMAND_BINSTATUS_TYPE_BY_INSTID = "SWITCH_COMMAND_BINSTATUS_TYPE_BY_INSTID";
	private static final String SWITCH_COMMAND_DB_DETAILS = "SWITCH_COMMAND_DB_DETAILS";
	private static final String SWITCH_PORT_DETAILS = "SWITCH_PORT_DETAILS";
	private static final String SWITCH_TRACE_DETAILS = "SWITCH_TRACE_DETAILS";
	private static final String SWITCH_DEBUGINFO_BY_FILENAME = "SWITCH_DEBUGINFO_BY_FILENAME";
	private static final String SWITCH_RESOURCES_USED = "SWITCH_RESOURCES_USED";
	private static final String SWITCH_ALLOCATED_BASIC_CONFIGURATIONS = "SWITCH_ALLOCATED_BASIC_CONFIGURATIONS";

	public List<SwitchNetworkDBDto> getTypeOfTaskCmd(Map<String, String> params) {
		List<SwitchNetworkDBDto> taskCommandTypes = null;
		try {
		 	String product = (String) params.get("product") == null ? "" : params.get("product");		 	
		 	HttpServletRequest request = HTTPRequestGetter.getRequest();
			String nodeIdValue = (String) request.getSession(false).getAttribute("node_name");
		 	List<String> nodeId = new ArrayList<>();
		 	
		 	if(StringUtil.isNotEmpty(nodeIdValue) && nodeIdValue.startsWith("All")){
		 		nodeId = getAllNodes(nodeIdValue);
		 	}else {
		 		nodeId.add(nodeIdValue);
		 	}
		 	
		 	Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(SWITCH_COMMAND_TSKCMD_TYPE))
					.addScalar("recordCount", StandardBasicTypes.INTEGER)
					.addScalar("recordTypeOf", StandardBasicTypes.STRING);

			queryObject.setParameter("product", product);
			queryObject.setParameterList("nodeId", nodeId);

			System.out.println("getTypeOfTaskCmd Query String :: " + queryObject.getQueryString());
			log.debug("Query for Task Command in SwitchNetworkDBDAO "
					+ SqlQueryProvider.getDBSqlQuery(SWITCH_COMMAND_TSKCMD_TYPE).toString());

			taskCommandTypes = (List<SwitchNetworkDBDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(SwitchNetworkDBDto.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#8...", re);
			throw re;
		}
		return taskCommandTypes;
	}

	public List<SwitchNetworkDBDto> getTypeOfBinStatus(Map<String, String> params) {
		List<SwitchNetworkDBDto> binDetails = null;
		try {
			
		 	String product = (String) params.get("product") == null ? "" : params.get("product");
		 	String nodeIdValue = (String) params.get("nodeId") == null ? "" : params.get("nodeId");
		 	List<String> nodeId = new ArrayList<>();
		 	
		 	if(StringUtil.isNotEmpty(nodeIdValue) && nodeIdValue.startsWith("All")){
		 		nodeId = getAllNodes(nodeIdValue);
		 	}else {
		 		nodeId.add(nodeIdValue);
		 	}
		 	
		 	Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(SWITCH_COMMAND_BINSTATUS_TYPE))
					.addScalar("recordCount", StandardBasicTypes.INTEGER)
					.addScalar("recordTypeOf", StandardBasicTypes.STRING);

			queryObject.setParameter("product", product);
			queryObject.setParameterList("nodeId", nodeId);

			log.debug("Query for Bin Status Type in SwitchNetworkDBDAO " + SWITCH_COMMAND_BINSTATUS_TYPE.toString());

			binDetails = (List<SwitchNetworkDBDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(SwitchNetworkDBDto.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#8...", re);
			throw re;
		}
		return binDetails;
	}

	public List<SwitchNetworkDBDto> getTypeOfBinStatusByInstId(Map<String, String> params) {
		List<SwitchNetworkDBDto> binDetails = null;
		try {
			
		 	String product = (String) params.get("product") == null ? "" : params.get("product");
		 	String nodeIdValue = (String) params.get("nodeId") == null ? "" : params.get("nodeId");
		 	List<String> nodeId = new ArrayList<>();
		 	
		 	if(StringUtil.isNotEmpty(nodeIdValue) && nodeIdValue.startsWith("All")){
		 		nodeId = getAllNodes(nodeIdValue);
		 	}else {
		 		nodeId.add(nodeIdValue);
		 	}
		 	
		 	Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(SWITCH_COMMAND_BINSTATUS_TYPE_BY_INSTID))
					.addScalar("instId", StandardBasicTypes.STRING)
					.addScalar("binId", StandardBasicTypes.INTEGER)
					.addScalar("statusByInstId", StandardBasicTypes.STRING);

			queryObject.setParameter("product", product);
			queryObject.setParameterList("nodeId", nodeId);

			log.debug("Query for Bin Status Type in SwitchNetworkDBDAO "
					+ SWITCH_COMMAND_BINSTATUS_TYPE_BY_INSTID.toString());

			binDetails = (List<SwitchNetworkDBDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(SwitchNetworkDBDto.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#8...", re);
			throw re;
		}
		return binDetails;
	}

	public List<SwitchNetworkDBDto> getPortDetails(Map<String, String> params) {
		List<SwitchNetworkDBDto> portDetailsList = null;
		try {

		 	String product = (String) params.get("product") == null ? "" : params.get("product");
		 	String nodeIdValue = (String) params.get("nodeId") == null ? "" : params.get("nodeId");
		 	List<String> nodeId = new ArrayList<>();
		 	
		 	if(StringUtil.isNotEmpty(nodeIdValue) && nodeIdValue.startsWith("All")){
		 		nodeId = getAllNodes(nodeIdValue);
		 	}else {
		 		nodeId.add(nodeIdValue);
		 	}
		 	
		 	Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(SWITCH_PORT_DETAILS))
					.addScalar("recordCount", StandardBasicTypes.INTEGER)
					.addScalar("recordTypeOf", StandardBasicTypes.STRING);

			queryObject.setParameter("product", product);
			queryObject.setParameterList("nodeId", nodeId);

			log.debug("Query for Port Details in SwitchNetworkDBDAO " + SWITCH_PORT_DETAILS.toString());

			portDetailsList = (List<SwitchNetworkDBDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(SwitchNetworkDBDto.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#8...", re);
			throw re;
		}
		return portDetailsList;
	}

	public List<SwitchNetworkDBDto> getDBDetails(Map<String, String> params) {
		List<SwitchNetworkDBDto> dbDetailsList = null;
		try {
		 	String product = (String) params.get("product") == null ? "" : params.get("product");
		 	String nodeIdValue = (String) params.get("nodeId") == null ? "" : params.get("nodeId");
		 	List<String> nodeId = new ArrayList<>();
		 	
		 	if(StringUtil.isNotEmpty(nodeIdValue) && nodeIdValue.startsWith("All")){
		 		nodeId = getAllNodes(nodeIdValue);
		 	}else {
		 		nodeId.add(nodeIdValue);
		 	}
		 	
		 	Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(SWITCH_COMMAND_DB_DETAILS))
					.addScalar("recordCount", StandardBasicTypes.INTEGER)
					.addScalar("recordTypeOf", StandardBasicTypes.STRING);

			queryObject.setParameter("product", product);
			queryObject.setParameterList("nodeId", nodeId);

			log.debug("Query for DB Details in SwitchNetworkDBDAO " + SWITCH_COMMAND_DB_DETAILS.toString());

			dbDetailsList = (List<SwitchNetworkDBDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(SwitchNetworkDBDto.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#8...", re);
			throw re;
		}
		return dbDetailsList;
	}

	public List<SwitchNetworkDBDto> getTraceLevelDetails(Map<String, String> params) {
		List<SwitchNetworkDBDto> traceLevel = null;
		try {
		 	String product = (String) params.get("product") == null ? "" : params.get("product");
		 	String nodeIdValue = (String) params.get("nodeId") == null ? "" : params.get("nodeId");
		 	List<String> nodeId = new ArrayList<>();
		 	
		 	if(StringUtil.isNotEmpty(nodeIdValue) && nodeIdValue.startsWith("All")){
		 		nodeId = getAllNodes(nodeIdValue);
		 	}else {
		 		nodeId.add(nodeIdValue);
		 	}
		 	

			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(SWITCH_TRACE_DETAILS))
					.addScalar("recordCount", StandardBasicTypes.INTEGER)
					.addScalar("recordTypeOf", StandardBasicTypes.STRING);

			queryObject.setParameter("product", product);
			queryObject.setParameterList("nodeId", nodeId);

			log.debug("Query for Trace Level Details in SwitchNetworkDBDAO " + SWITCH_COMMAND_DB_DETAILS.toString());

			traceLevel = (List<SwitchNetworkDBDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(SwitchNetworkDBDto.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#8...", re);
			throw re;
		}
		return traceLevel;
	}
	
	public List<SwitchNetworkDBDto> getDebugInfoByFileName(Map<String, String> params) {
		List<SwitchNetworkDBDto> binDetails = null;
		try {
			
		 	String product = (String) params.get("product") == null ? "" : params.get("product");
		 	String nodeIdValue = (String) params.get("nodeId") == null ? "" : params.get("nodeId");
		 	List<String> nodeId = new ArrayList<>();
		 	
		 	if(StringUtil.isNotEmpty(nodeIdValue) && nodeIdValue.startsWith("All")){
		 		nodeId = getAllNodes(nodeIdValue);
		 	}else {
		 		nodeId.add(nodeIdValue);
		 	}
		 	
		 	java.util.Date todayDate = new java.util.Date();
			java.sql.Date convertedTodayDate = new java.sql.Date(todayDate.getTime());  
			SimpleDateFormat simpleformatforToday = new SimpleDateFormat("dd-MMM-yyyy");
			String fromDateStr = simpleformatforToday.format(convertedTodayDate);
			
		 	java.util.Date tomorrowDate = new java.util.Date();
			java.sql.Date convertedTomorrowdayDate = new java.sql.Date(tomorrowDate.getTime() + (1000 * 60 * 60 * 24));  
			SimpleDateFormat simpleformatforTomorrow = new SimpleDateFormat("dd-MMM-yyyy");
			String tomorrowDateStr = simpleformatforTomorrow.format(convertedTomorrowdayDate);
			
			if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
				simpleformatforToday = new SimpleDateFormat("yyyy-MM-dd");
				fromDateStr = simpleformatforToday.format(convertedTodayDate) + " 00:00:00";;
				
				simpleformatforTomorrow = new SimpleDateFormat("yyyy-MM-dd");
				tomorrowDateStr = simpleformatforTomorrow.format(convertedTodayDate) + " 23:59:59";
			}

			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(SWITCH_DEBUGINFO_BY_FILENAME))
					.addScalar("fileName", StandardBasicTypes.STRING)
					.addScalar("fileNameCount", StandardBasicTypes.INTEGER)
					.addScalar("debugLevel", StandardBasicTypes.STRING);
			
			queryObject.setParameter("product", product);
			queryObject.setParameterList("nodeId", nodeId);
			queryObject.setParameter("fromDate", fromDateStr);
			queryObject.setParameter("toDate", tomorrowDateStr);
			
			log.debug("getDebugInfoByFileName from SwitchNetworkDBDAO " + SWITCH_DEBUGINFO_BY_FILENAME.toString());
			
			binDetails = (List<SwitchNetworkDBDto>)queryObject.setResultTransformer(Transformers.aliasToBean(SwitchNetworkDBDto.class)).list();
			
		} catch(RuntimeException re) {
			log.error("Query failed SQL#8...", re);
			throw re;
		}
		return binDetails;
	}
	
	public List<SwitchNetworkDBDto> getResourcesUsed(Map<String, String> params) {
		List<SwitchNetworkDBDto> resourceDetails = null;
		try {
			
		 	String product = (String) params.get("product") == null ? "" : params.get("product");
		 	String nodeIdValue = (String) params.get("nodeId") == null ? "" : params.get("nodeId");
		 	List<String> nodeId = new ArrayList<>();
		 	
		 	if(StringUtil.isNotEmpty(nodeIdValue) && nodeIdValue.startsWith("All")){
		 		nodeId = getAllNodes(nodeIdValue);
		 	}else {
		 		nodeId.add(nodeIdValue);
		 	}
		 	
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(SWITCH_RESOURCES_USED))
					.addScalar("resourceResult", StandardBasicTypes.STRING);

			queryObject.setParameter("product", product);
			queryObject.setParameterList("nodeId", nodeId);

			log.debug("getResourcesUsed from SwitchNetworkDBDAO " + SWITCH_RESOURCES_USED.toString());

			resourceDetails = (List<SwitchNetworkDBDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(SwitchNetworkDBDto.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed SQL#8...", re);
			throw re;
		}
		return resourceDetails;
	}

	public List<SwitchNetworkDBDto> getAllocatedBasicsConfigurations(Map<String, String> params) {
		List<SwitchNetworkDBDto> allocatedBasicConfigurations = null;
		try {
		 	String product = (String) params.get("product") == null ? "" : params.get("product");
		 	String nodeIdValue = (String) params.get("nodeId") == null ? "" : params.get("nodeId");
		 	List<String> nodeId = new ArrayList<>();
		 	
		 	if(StringUtil.isNotEmpty(nodeIdValue) && nodeIdValue.startsWith("All")){
		 		nodeId = getAllNodes(nodeIdValue);
		 	}else {
		 		nodeId.add(nodeIdValue);
		 	}
		 	
			Query queryObject = getSession().createSQLQuery(SqlQueryProvider.getDBSqlQuery(SWITCH_ALLOCATED_BASIC_CONFIGURATIONS))
					.addScalar("alloactedBasicConfigs", StandardBasicTypes.STRING);

			queryObject.setParameter("product", product);
			queryObject.setParameterList("nodeId", nodeId);

			log.debug("getResourcesUsed from SwitchNetworkDBDAO " + SWITCH_ALLOCATED_BASIC_CONFIGURATIONS.toString());

			allocatedBasicConfigurations = (List<SwitchNetworkDBDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(SwitchNetworkDBDto.class)).list();

		} catch (RuntimeException re) {
			log.error("Query failed getAllocatedBasicsConfigurations...", re);
			throw re;
		}
		return allocatedBasicConfigurations;
	}

	private List<String> getAllNodes(String nodes) {
		List<String> allNodeIds = new ArrayList<>();

		Pattern pattern = Pattern.compile("\\((.*?)\\)");
		Matcher matcher = pattern.matcher(nodes);

		try {
			if (matcher.find()) {
				nodes = matcher.group(1);
				String[] values = nodes.split(",\\s*");
				for (String value : values) {
					allNodeIds.add(value.trim());
				}
			}
			return allNodeIds;
		} catch (RuntimeException re) {
			log.error("getAllNodes failed", re);
			throw re;
		}
	}

	public Class<ATMAvailable> getEntityClass() {
		return ATMAvailable.class;
	}

}
