package com.fis.ist.monitoring.dto;

public class TxnCompletionTimeDto {

	private Integer secCount;
	private Integer min1Count;
	private Integer min2Count;
	private Integer min3Count;
	private Integer min4Count;
	private Integer min5Count;
	public Integer getSecCount() {
		return secCount;
	}
	public void setSecCount(Integer secCount) {
		this.secCount = secCount;
	}
	public Integer getMin1Count() {
		return min1Count;
	}
	public void setMin1Count(Integer min1Count) {
		this.min1Count = min1Count;
	}
	public Integer getMin2Count() {
		return min2Count;
	}
	public void setMin2Count(Integer min2Count) {
		this.min2Count = min2Count;
	}
	public Integer getMin3Count() {
		return min3Count;
	}
	public void setMin3Count(Integer min3Count) {
		this.min3Count = min3Count;
	}
	public Integer getMin4Count() {
		return min4Count;
	}
	public void setMin4Count(Integer min4Count) {
		this.min4Count = min4Count;
	}
	public Integer getMin5Count() {
		return min5Count;
	}
	public void setMin5Count(Integer min5Count) {
		this.min5Count = min5Count;
	}
}
