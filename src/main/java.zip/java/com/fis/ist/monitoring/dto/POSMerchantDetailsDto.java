package com.fis.ist.monitoring.dto;

import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.domain.POSMerchantDetails;

public class POSMerchantDetailsDto implements java.io.Serializable  {

	private static final long serialVersionUID = 1L;

	private String institutionId;
	private String entityId;
	private Long entityLevel;
	private String entityName;
	private String entityDbaName;
	private Long settlPlanId;
	private String entityStatus;
	private String parentEntityId;
	private String externalEntityId;
	private String creationDate;
	private String expStartDate;
	private String terminationDate;
	private String companyType;
	private String processingType;
	private String taxId;
	
	public POSMerchantDetailsDto() {}

	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	public String getEntityId() {
		return entityId;
	}

	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}

	public Long getEntityLevel() {
		return entityLevel;
	}

	public void setEntityLevel(Long entityLevel) {
		this.entityLevel = entityLevel;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getEntityDbaName() {
		return entityDbaName;
	}

	public void setEntityDbaName(String entityDbaName) {
		this.entityDbaName = entityDbaName;
	}

	public Long getSettlPlanId() {
		return settlPlanId;
	}

	public void setSettlPlanId(Long settlPlanId) {
		this.settlPlanId = settlPlanId;
	}

	public String getEntityStatus() {
		return entityStatus;
	}

	public void setEntityStatus(String entityStatus) {
		this.entityStatus = entityStatus;
	}

	public String getParentEntityId() {
		return parentEntityId;
	}

	public void setParentEntityId(String parentEntityId) {
		this.parentEntityId = parentEntityId;
	}

	public String getExternalEntityId() {
		return externalEntityId;
	}

	public void setExternalEntityId(String externalEntityId) {
		this.externalEntityId = externalEntityId;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = PaymonUtils.getFormattedResponseDate(creationDate);
	}

	public String getExpStartDate() {
		return expStartDate;
	}

	public void setExpStartDate(String expStartDate) {
		this.expStartDate = PaymonUtils.getFormattedResponseDate(expStartDate);
	}

	public String getTerminationDate() {
		return terminationDate;
	}

	public void setTerminationDate(String terminationDate) {
		this.terminationDate = PaymonUtils.getFormattedResponseDate(terminationDate);
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public String getProcessingType() {
		return processingType;
	}

	public void setProcessingType(String processingType) {
		this.processingType = processingType;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}
	
	public void load(POSMerchantDetails posMerchantTerminals) {		
		this.setInstitutionId(posMerchantTerminals.getInstitutionId());
		this.setEntityId(posMerchantTerminals.getEntityId());
		this.setEntityLevel(posMerchantTerminals.getEntityLevel());
		this.setEntityName(posMerchantTerminals.getEntityName());
		this.setEntityDbaName(posMerchantTerminals.getEntityDbaName());
		this.setSettlPlanId(posMerchantTerminals.getSettlPlanId());
		this.setEntityStatus(posMerchantTerminals.getEntityStatus());
		this.setParentEntityId(posMerchantTerminals.getParentEntityId());
		this.setExternalEntityId(posMerchantTerminals.getExternalEntityId());
		this.setCreationDate(posMerchantTerminals.getCreationDate());
		this.setExpStartDate(posMerchantTerminals.getExpStartDate());
		this.setTerminationDate(posMerchantTerminals.getTerminationDate());
		this.setCompanyType(posMerchantTerminals.getCompanyType());
		this.setProcessingType(posMerchantTerminals.getProcessingType());
		this.setTaxId(posMerchantTerminals.getTaxId());
	}		
}
