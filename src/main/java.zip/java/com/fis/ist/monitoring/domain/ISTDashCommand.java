package com.fis.ist.monitoring.domain;

import java.sql.Clob;
import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "CS_MONCMDOUT" )
public class ISTDashCommand implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	private String product; // PRODUCT
	private String nodeId; // NODEID
	private String taskName; // FIELD1
	private String taskType; // FIELD2
	private String pId; // FIELD0
	
	private String logdate; // LOGDATE
	private String istCommand; // CMD
	private String flags; // FIELD3
	private String count; // FIELD4
	private String lastStart; // FIELD5
	private String lastDie; // FIELD6	
	private String field7; // FIELD 7
	private String field8; // FIELD 8
	private String field9; // FIELD 9
	private Long id; //ID
	
	private String output; // CMDOUTPUT
	
	public ISTDashCommand() {
		
	}
	
	
	@Id
	@Column(name = "ID", nullable = false, length = 38)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ISTDashCommand(String pId) {
		this.pId = pId;
	}
	
	public ISTDashCommand(String product, String nodeId, String taskName, String taskType, String pId,
					   String logdate, String istCommand, String flags, String count, String lastStart,
					   String lastDie, String field7, String field8, String field9, String output, Long id ) {  //
		this.product = product;
		this.nodeId = nodeId;
		this.taskName = taskName;
		this.taskType = taskType;
		this.pId = pId;
		this.logdate = logdate;
		this.istCommand = istCommand;
		this.flags = flags;
		this.count = count;
		this.lastStart = lastStart;
		this.lastDie = lastDie;
		this.field7 = field7;
		this.field8 = field8;
		this.field9 = field9;
		this.output = output;
		this.id = id;
	}

	@Column(name = "PRODUCT", nullable = false, length = 50)
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}


	@Column(name = "NODEID", nullable = false, length = 50)
	public String getNodeId() {
		return nodeId;
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}

	@Column(name = "FIELD1", nullable = true, length = 50)
	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	@Column(name = "FIELD2", nullable = true, length = 50)
	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	@Column(name = "FIELD0", nullable = true, length = 50)
	public String getpId() {
		return pId;
	}

	public void setpId(String pId) {
		this.pId = pId;
	}

	@Column(name = "LOGDATE", nullable = true, length = 50)
	public String getLogdate() {
		return logdate;
	}

	public void setLogdate(String logdate) {
		this.logdate = logdate;
	}
	
	@Column(name = "FIELD3", nullable = true, length = 50)
	public String getFlags() {
		return flags;
	}

	public void setFlags(String flags) {
		this.flags = flags;
	}

	@Column(name = "FIELD4", nullable = true, length = 50)
	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	@Column(name = "FIELD5", nullable = true, length = 50)
	public String getLastStart() {
		return lastStart;
	}

	public void setLastStart(String lastStart) {
		this.lastStart = lastStart;
	}

	@Column(name = "FIELD6", nullable = true, length = 50)
	public String getLastDie() {
		return lastDie;
	}

	public void setLastDie(String lastDie) {
		this.lastDie = lastDie;
	}

	@Column(name = "FIELD7", nullable = true, length = 50)
	public String getField7() {
		return field7;
	}

	public void setField7(String field7) {
		this.field7 = field7;
	}

	@Column(name = "FIELD8", nullable = true, length = 50)
	public String getField8() {
		return field8;
	}

	public void setField8(String field8) {
		this.field8 = field8;
	}

	@Column(name = "FIELD9", nullable = true, length = 50)
	public String getField9() {
		return field9;
	}

	public void setField9(String field9) {
		this.field9 = field9;
	}

	@Column(name = "CMD", nullable = true, length = 50)
	public String getIstCommand() {
		return istCommand;
	}

	public void setIstCommand(String istCommand) {
		this.istCommand = istCommand;
	}

	@Column(name="CMDOUTPUT")
	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}	
	
	//To add default sorting order for port details
	public static class FlagsComparator implements Comparator<ISTDashCommand> {
		
		@Override
		public int compare(ISTDashCommand port1,ISTDashCommand port2) {
			//Custom sorting logic based on flags
			String[] flagOrder = {"Down", "Stopped" ,"Active listen", "Passive listen", "Connected|Active listen", "Connected|Passive listen"};
			
			int index1 = getIndexForFlag(port1.getFlags(), flagOrder);
			int index2 = getIndexForFlag(port2.getFlags(), flagOrder);
			
			return Integer.compare(index1, index2);
		}
		
		private int getIndexForFlag(String flag, String[] flagOrder) {
			for(int i = 0; i < flagOrder.length; i++) {
				if(flagOrder[i].equalsIgnoreCase(flag))
					return i;
			}
			return flagOrder.length;
		} 
	}
}
