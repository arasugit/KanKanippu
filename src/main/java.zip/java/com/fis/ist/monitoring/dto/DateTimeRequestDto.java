package com.fis.ist.monitoring.dto;

import java.util.Date;

public class DateTimeRequestDto {
	
	private String formattedFromDate;
	private String formattedToDate;
	private Date toDate;
	private String fromDbDateFormat;
	private String toDbDateFormat;
	
	public String getFormattedFromDate() {
		return formattedFromDate;
	}
	
	public void setFormattedFromDate(String formattedFromDate) {
		this.formattedFromDate = formattedFromDate;
	}
	
	public String getFormattedToDate() {
		return formattedToDate;
	}
	
	public void setFormattedToDate(String formattedToDate) {
		this.formattedToDate = formattedToDate;
	}
	
	public Date getToDate() {
		return toDate;
	}
	
	public void setToDateTime(Date toDate) {
		this.toDate = toDate;
	}
	
	public String getFromDbDateFormat() {
		return fromDbDateFormat;
	}
	
	public void setFromDbDateFormat(String fromDbDateFormat) {
		this.fromDbDateFormat = fromDbDateFormat;
	}
	
	public String getToDbDateFormat() {
		return toDbDateFormat;
	}
	
	public void setToDbDateFormat(String toDbDateFormat) {
		this.toDbDateFormat = toDbDateFormat;
	}
}
