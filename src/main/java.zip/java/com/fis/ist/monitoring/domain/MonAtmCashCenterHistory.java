package com.fis.ist.monitoring.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "CS_MONATMCASCNTER_HIST")
public class MonAtmCashCenterHistory implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private String institutionId;
	
	public MonAtmCashCenterHistory() {

	}

	@Column(name = "INSTITUTIONID", nullable = true, length = 10)
	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
}
