package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.services.MonitorConfigService;
import com.fis.ist.monitoring.dao.PosTransDao;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.POSMakewiseTxnsDto;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.monitoring.dto.TransactionStatisticsListItem;
import com.fis.ist.monitoring.dto.Triplet;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class POSMakewiseTxnsHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(POSMakewiseTxnsHandler.class);
	private static String reqTypeId = MonitorConstants.POSMAKE_REQ;
	private static String formAuthId = "POSMAKE";

	public POSMakewiseTxnsHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getPOSMakewiseTxnStats(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}


	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.POSMAKE_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.POSMAKE_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.POSMAKE_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.POSMAKE_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.POSMAKE_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load POSMakewiseTxnsHandler ....");
		String screenType = params.get("screenType");
		String isDetailReq = params.get("isDetailReq");
		PosTransDao posTransDao = new PosTransDao();

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List<POSMakewiseTxnsDto> posMakewiseTxndata = new ArrayList<POSMakewiseTxnsDto>();
		List<Triplet<String, Integer, Integer>> posMakewiseTxns = posTransDao.getPOSMakewiseTxns(screenType);

		posMakewiseTxns.forEach(x -> {
			POSMakewiseTxnsDto dto = new POSMakewiseTxnsDto();
			dto.setPosTerminalType(x.getKey().trim());
			dto.setSuccessfulTxnsCount(x.getValue1());
			dto.setFailureTxnsCount(x.getValue2());
			posMakewiseTxndata.add(dto);
		});

		log.debug("Prepared POS Makewise Txn Data List");

		List<POSMakewiseTxnsDto> workRows = getPOSMakewiseTxnsList(workRequest, uiMetaData);

		if (posMakewiseTxndata.size() == 0) {
			workRequest.setLastModified(-1L);
			return;
		}

		workRequest.setLastModified((long) posMakewiseTxndata.size());
		workRows.addAll(posMakewiseTxndata);
		log.debug("Workrows ::" + workRows);

		if ("true".equalsIgnoreCase(isDetailReq))
			getTransactionDetailRecord(workRequest, uiMetaData, params);
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		return validateFields(fieldDataMap);
	}

	private List<POSMakewiseTxnsDto> getPOSMakewiseTxnsList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.POSMAKE_COL);
		workCollection.setSectionId(MonitorConstants.POSMAKE_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.POSMAKE_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<POSMakewiseTxnsDto> workRows = new ArrayList<POSMakewiseTxnsDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.POSMAKE_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<TransactionStatisticsListItem> getTransactionDetail(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.POSMAKE_DTL_COL);
		workCollection.setSectionId(MonitorConstants.POSMAKE_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.POSMAKE_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionStatisticsListItem> workRows = new ArrayList<TransactionStatisticsListItem>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.POSMAKE_DTL_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private void getTransactionDetailRecord(WorkRequest workRequest, UIMetaData uiMetaData,
			Map<String, String> params) {
		String screenType = params.get("screenType");
		String isDetailReq = params.get("isDetailReq");
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);

		TransactionsDAO transDao = new TransactionsDAO();
		PosTransDao posTransDao = new PosTransDao();

		if ("true".equalsIgnoreCase(isDetailReq)) {
			String eventName = params.get("eventName");
			String posMake = params.get("txnSrcAcq");
			String txnStatus = "";

			try {
				txnStatus = eventName.split(" ")[0];
			} catch (Exception e) {
				log.debug("got exception ::" + e.getMessage());
			}
			txnStatus = txnStatus.equalsIgnoreCase("Successful") ? "APPROVAL" : "DECLINE";

			if (needs_total) {
				long total = posTransDao.getPosTxnDetailsCount(posMake, screenType, txnStatus);
				workRequest.setLastModified(total);
			}

			List posTxnDetails = posTransDao.getPosTxnDetails(posMake, screenType, txnStatus, pageNum);

			if (null == posTxnDetails) {
				return;
			}
			
			TransactionStatisticsListItem dto = null;
			Object[] result = null;
			
			List<TransactionStatisticsListItem> workRows = getTransactionDetail(workRequest, uiMetaData);

			MonitorConfigService configService = new MonitorConfigService();
			List<String> businessDeclineList = configService.getDeclineRespCodes(transDao, MonitorConstants.BD_RESP_CODE_LIST);
			List<String> technicalDeclineList = configService.getDeclineRespCodes(transDao, MonitorConstants.TD_RESP_CODE_LIST);				
			List<TransactionStatisticsListItem> respCodesAndDesc = configService.getResponseCodesAndDesc(transDao);

			for (int i = 0; i < posTxnDetails.size(); i++) {
				dto = new TransactionStatisticsListItem();
				result = (Object[]) posTxnDetails.get(i);
				dto.loadPosTxnDetails(result);
				setDeclineCategory(businessDeclineList, technicalDeclineList, dto);
				setRespCodeDesc(respCodesAndDesc, dto);
				workRows.add(dto);
			}
		}
	}
	 
	private void setDeclineCategory(List<String> businessDeclineList, List<String> technicalDeclineList, TransactionStatisticsListItem dto)
	{
		String declineCategory = PaymonUtils.getDeclineCategoryByRespCode(businessDeclineList, technicalDeclineList, dto.getRespCode());
		dto.setDeclineCategory(declineCategory);
	}
		
	private void setRespCodeDesc(List<TransactionStatisticsListItem> respCodesAndDesc, TransactionStatisticsListItem dto)
	{
		String respCodeDesc = PaymonUtils.getRespDescByCode(respCodesAndDesc, dto.getRespCode());
		dto.setRespCodeDesc(respCodeDesc);
	}
}
