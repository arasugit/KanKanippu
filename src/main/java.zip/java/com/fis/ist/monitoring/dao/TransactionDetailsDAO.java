package com.fis.ist.monitoring.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.hibernate.jpa.QueryHints;
import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;

public class TransactionDetailsDAO extends MonitorBaseDAO<Integer, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(TransactionDetailsDAO.class);
	// property constants

	@Override
	public Class<Integer> getEntityClass() {
		return Integer.class;
	}

	// Transaction details and drilldown functions

	public int getAcquirerTransactionDetailsCount(List<String> acqs, List<String> txnsrcs, String type,
			String txnStatus) {
		log.debug("Getting Acquirer Transactions count from db");
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXN_ACQ_DTL_CNT");
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, type);
			queryString = SqlQueryProvider.addTransactionStatsDetailsMsgTypeFilter(queryString, txnStatus);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);

			int count = (int) queryObject.uniqueResult();
			log.debug(String.format("Found %d Acquirer Transactions count.", count));

			return count;

		} catch (Exception re) {
			log.error("getAcquirerTransactionDetailsCount Query Fails", re);
			throw re;
		}
	}

	public List getAcquirerTransactionDetails(List<String> acqs, List<String> txnsrcs, String type, String txnStatus,
			int pageNum) {
		Integer batchSize = 500;
		log.debug(String.format("Getting Acquirer Transaction Details from db in batch of %d.", batchSize));
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXN_ACQ_DTL");
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, type);
			queryString = SqlQueryProvider.addTransactionStatsDetailsMsgTypeFilter(queryString, txnStatus);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chip_index", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING).addScalar("istsysdate", StandardBasicTypes.STRING)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.STRING)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			setPaging(queryObject, pageNum);

			Stream stream = queryObject.setHint(QueryHints.HINT_FETCH_SIZE, batchSize).getResultStream();

			List recordList = new ArrayList<>();
			stream.forEach(x -> {
				recordList.add(x);
			});

			log.debug(String.format("Found %d Acquirer Transaction Details.", recordList.size()));
			return recordList;

		} catch (Exception re) {
			log.error("getAcquirerTransactionDetails Query Fails", re);
			throw re;
		}
	}

	// Top and Least Transacting 25 Terminals and Transaction - Transaction details
	public int getTerminalTransCount(List<String> acqs, List<String> txnsrcs, String screenType, String terminalId) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSTP_REQ_25_CNT");
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("termid", terminalId);

			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("geTerminalTransCount Query Fails", re);
			throw re;
		}
	}

	public List getTerminalTrans(List<String> acqs, List<String> txnsrcs, String screenType, String terminalId,
			int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSTP_REQ_25");
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chip_index", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING).addScalar("istsysdate", StandardBasicTypes.STRING)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.STRING)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("termid", terminalId);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("geTerminalTrans Query Fails", re);
			throw re;
		}
	}

	public int getHostTransactionStatsDetailsCount(List<String> issuer, List<String> txndest, String type) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXN_HOST_DTL_CNT");
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, type);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			queryObject.setParameterList("txndest", txndest);
			queryObject.setParameterList("issuer", issuer);
			return (int) queryObject.uniqueResult();

		} catch (Exception re) {
			log.error("getHostTransactionStatsDetailsCount Query Fails", re);
			throw re;
		}
	}

	public List getHostTransactionStatsDetails(List<String> issuer, List<String> txndest, String type, int pageNum) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXN_HOST_DTL");
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, type);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chip_index", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING).addScalar("istsysdate", StandardBasicTypes.STRING)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.STRING)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			queryObject.setParameterList("txndest", txndest);
			queryObject.setParameterList("issuer", issuer);
			setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (Exception re) {
			log.error("getHostTransactionStatsDetails Query Fails", re);
			throw re;
		}
	}

	public Integer getTransactionDashboardDetailsCount(String currentDate, String chartType, String hour,
			Integer startTime, Integer endTime, String status) {
		List recordList = getTransactionDashboardDetails(currentDate, chartType, null, hour, startTime, endTime,
				status);
		if (recordList != null) {
			return recordList.size();
		} else {
			return 0;
		}
	}

	public List getTransactionDashboardDetails(String currentDate, String chartType, Integer pageNum, String hour,
			Integer startTime, Integer endTime, String status) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXN_DASH_DTL");
			queryString = SqlQueryProvider.addTransactionDashboardChartFilter(queryString, chartType, status);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chip_index", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING).addScalar("istsysdate", StandardBasicTypes.STRING)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.STRING)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			if ("PEAKVOLUME".equals(chartType)) {
				queryObject.setParameter("hour", hour);
			} else if ("COMPTIME".equals(chartType)) {
				queryObject.setParameter("startTime", startTime);
				queryObject.setParameter("endTime", endTime);
			}

			queryObject.setParameter("currentDate", currentDate);

			if (pageNum != null) {
				setPaging(queryObject, pageNum.intValue());
			}

			return queryObject.list();

		} catch (Exception re) {
			log.error("getTransactionDashboardDetails Query Fails", re);
			throw re;
		}
	}

	public int getTransStatDTLsbyTxnCodeCount(String type, String txnStatus, String pcode) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTYPEREQ_DTL_CNT");
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, type);
			queryString = SqlQueryProvider.addTransactionStatsDetailsMsgTypeFilter(queryString, txnStatus);

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			queryObject.setParameter("pcode", Integer.parseInt(pcode));
			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("getTransStatsbyTxnCode - Query Fails", re);
			throw re;
		}
	}

	public List getTransStatsDTLbyTxnCode(String type, String txnStatus, String pcode, Integer pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTYPEREQ_DTL");
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, type);
			queryString = SqlQueryProvider.addTransactionStatsDetailsMsgTypeFilter(queryString, txnStatus);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chip_index", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING).addScalar("istsysdate", StandardBasicTypes.STRING)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.DATE)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			queryObject.setParameter("pcode", Integer.parseInt(pcode));
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("getTransStatsbyTxnCode - Query Fails", re);
			throw re;
		}
	}

	// Transaction Logs Count
	private int getTransactionLogsCount(String fromDate, String toDate, String fromDateFormate, String toDateFormate,
			List<String> txnSrcs, boolean excludeTxnSrcs, List<String> acqs, String terminalId, String pCode,
			String pan, String txnDest, String issuer, boolean fallbackTxnOnly) {
		try {
			StringBuffer queryBuffer = new StringBuffer();

			queryBuffer.append("select count(1) as count from cs_monshclog_ext \n");
			setTransactionLogsQueryFilter(queryBuffer, fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs,
					excludeTxnSrcs, acqs, terminalId, pCode, pan, txnDest, issuer, fallbackTxnOnly);
			String queryString = queryBuffer.toString();
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			setTransactionLogsQueryParams(queryObject, fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs, acqs,
					terminalId, pCode, pan, txnDest, issuer);

			return (int) queryObject.uniqueResult();
		} catch (RuntimeException re) {
			log.error("getTransactionLogsCount Query Fails", re);
			throw re;
		}
	}

	// Transaction Logs
	private List getTransactionLogs(String fromDate, String toDate, String fromDateFormate, String toDateFormate,
			List<String> txnSrcs, boolean excludeTxnSrcs, List<String> acqs, String terminalId, String pCode,
			String pan, String txnDest, String issuer, boolean fallbackTxnOnly, int pageNum) {
		try {
			StringBuffer queryBuffer = new StringBuffer();

			queryBuffer.append(SqlQueryProvider.getDBSqlQuery("TXN_LOG"));

			setTransactionLogsQueryFilter(queryBuffer, fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs,
					excludeTxnSrcs, acqs, terminalId, pCode, pan, txnDest, issuer, fallbackTxnOnly);

			if (pageNum > 0)
				queryBuffer.append("order by txnsrc, acquirer, chip_index, site_id");

			String queryString = queryBuffer.toString();

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chipindex", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING)
					.addScalar("istsysdate", StandardBasicTypes.TIMESTAMP)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.DATE)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("terminalId", StandardBasicTypes.STRING)
					.addScalar("pan", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			setTransactionLogsQueryParams(queryObject, fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs, acqs,
					terminalId, pCode, pan, txnDest, issuer);
			setPaging(queryObject, pageNum);

			Stream stream = queryObject.setHint(QueryHints.HINT_FETCH_SIZE, 500).getResultStream();

			List recordList = new ArrayList<>();
			stream.forEach(x -> {
				recordList.add(x);
			});

			return recordList;

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Transaction Log utility methods for setting filter & params
	private static void setTransactionLogsQueryFilter(StringBuffer queryBuffer, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, List<String> txnSrcs, boolean excludeTxnSrcs,
			List<String> acqs, String terminalId, String pCode, String pan, String txnDest, String issuer,
			boolean fallbackTxnOnly) {
		queryBuffer.append(" where ");

		if (!isEmpty(terminalId)) {
			queryBuffer.append(" termid = :termId and ");
		}

		if (txnSrcs != null && txnSrcs.size() > 0 && !excludeTxnSrcs) {
			queryBuffer.append(" txnsrc in (:txnsrcs) and ");
		}

		if (txnSrcs != null && txnSrcs.size() > 0 && excludeTxnSrcs) {
			queryBuffer.append(" txnsrc not in (:txnsrcs) and ");
		}

		if (acqs != null && acqs.size() > 0) {
			queryBuffer.append(" acquirer in (:acqs) and ");
		}

		if (!isEmpty(pCode)) {
			queryBuffer.append(" pcode = :pcode and ");
		}

		if (!isEmpty(pan)) {
			queryBuffer.append(" pan = :pan and ");
		}

		if (!isEmpty(txnDest)) {
			queryBuffer.append(" txndest = :txndest and ");
		}

		if (!isEmpty(issuer)) {
			queryBuffer.append(" issuer = :issuer and ");
		}

		if (PaymonUtils.isOracleDb())
			queryBuffer.append(
					" istsysdate between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) ");
		else if (PaymonUtils.isPostgressDb())
			queryBuffer.append(
					" istsysdate between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) ");

		if (fallbackTxnOnly) {
			queryBuffer.append(" and fallbackflg = 'Y' ");
		}
	}

	private static void setTransactionLogsQueryParams(Query queryObject, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, List<String> txnSrcs, List<String> acqs, String terminalId,
			String pCode, String pan, String txnDest, String issuer) {
		queryObject.setParameter("fromDate", fromDate);
		queryObject.setParameter("toDate", toDate);
		queryObject.setParameter("fromDateFormate", fromDateFormate);
		queryObject.setParameter("toDateFormate", toDateFormate);

		if (!isEmpty(terminalId)) {
			queryObject.setParameter("termId", terminalId);
		}

		if (txnSrcs != null && txnSrcs.size() > 0) {
			queryObject.setParameterList("txnsrcs", txnSrcs);
		}

		if (acqs != null && acqs.size() > 0) {
			queryObject.setParameterList("acqs", acqs);
		}

		if (!isEmpty(pCode)) {
			queryObject.setParameter("pcode", Integer.parseInt(pCode));
		}

		if (!isEmpty(pan)) {
			queryObject.setParameter("pan", pan);
		}

		if (!isEmpty(txnDest)) {
			queryObject.setParameter("txndest", txnDest);
		}

		if (!isEmpty(issuer)) {
			queryObject.setParameter("issuer", issuer);
		}
	}

	public int getTxnLogsCountForTerminalTransStats(String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, List<String> txnSrcs, List<String> acqs, String terminalId, String pCode) {
		return getTransactionLogsCount(fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs, false, acqs,
				terminalId, pCode, null, null, null, false);
	}

	public List getTxnLogsForTerminalTransStats(String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, List<String> txnSrcs, List<String> acqs, String terminalId, String pCode,
			int pageNum) {
		return getTransactionLogs(fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs, false, acqs, terminalId,
				pCode, null, null, null, false, pageNum);
	}

	public int getTxnLogsCountForHighVolTrans(String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, String pan) {
		return getTransactionLogsCount(fromDate, toDate, fromDateFormate, toDateFormate, null, false, null, null, null,
				pan, null, null, false);
	}

	public List getTxnLogsForHighVolTrans(String fromDate, String toDate, String fromDateFormate, String toDateFormate,
			String pan, int pageNum) {
		return getTransactionLogs(fromDate, toDate, fromDateFormate, toDateFormate, null, false, null, null, null, pan,
				null, null, false, pageNum);
	}

	public int getTxnLogsCountForSuccessAndRejTrans(String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, List<String> txnSrcs, boolean excludeTxnSrcs, String txndest, String issuer) {
		return getTransactionLogsCount(fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs, excludeTxnSrcs, null,
				null, null, null, txndest, issuer, false);
	}

	public List getTxnLogsForSuccessAndRejTrans(String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, List<String> txnSrcs, boolean excludeTxnSrcs, String txndest, String issuer,
			int pageNum) {
		return getTransactionLogs(fromDate, toDate, fromDateFormate, toDateFormate, txnSrcs, excludeTxnSrcs, null, null,
				null, null, txndest, issuer, false, pageNum);
	}

	public int getTxnLogsCountForFallbackTrans(String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, String txnSrcs, String acquirer, String terminalId) {
		return getTransactionLogsCount(fromDate, toDate, fromDateFormate, toDateFormate, Arrays.asList(txnSrcs), false,
				Arrays.asList(acquirer), terminalId, null, null, null, null, true);
	}

	public List getTxnLogsForFallbackTrans(String fromDate, String toDate, String fromDateFormate, String toDateFormate,
			String txnSrcs, String acquirer, String terminalId, int pageNum) {
		return getTransactionLogs(fromDate, toDate, fromDateFormate, toDateFormate, Arrays.asList(txnSrcs), false,
				Arrays.asList(acquirer), terminalId, null, null, null, null, true, pageNum);
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}
}
