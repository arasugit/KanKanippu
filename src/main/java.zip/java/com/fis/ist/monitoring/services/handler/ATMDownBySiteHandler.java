package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.ATMAvailabilityDAO;
import com.fis.ist.monitoring.dao.MonDbConnectedAtmDAO;
import com.fis.ist.monitoring.domain.ATMDataListDs;
import com.fis.ist.monitoring.domain.ATMMonDbListDs;
import com.fis.ist.monitoring.dto.ATMMonitoringRowListDs;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class ATMDownBySiteHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(ATMDownBySiteHandler.class);
	private static String reqTypeId = MonitorConstants.ATM_DOWN_SITE_REQ;
	private static String formAuthId = "ATMDWS_REQ";

	public ATMDownBySiteHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getDownBySiteATM(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.ATM_DOWN_SITE_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.ATM_DOWN_SITE_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.ATM_DOWN_SITE_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.ATM_DOWN_SITE_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.ATM_DOWN_SITE_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load ATM Down By Site Details");

		ATMAvailabilityDAO $dao = new ATMAvailabilityDAO();
		List<ATMDataListDs> downBySiteTermIdsList = $dao.getATMDwnByBranchTermId();

		MonDbConnectedAtmDAO dao = new MonDbConnectedAtmDAO();
		List<ATMMonDbListDs> downBySiteListMonDb = dao.getDownBySiteATM();

		trimTerminalId(downBySiteListMonDb);

		Map<String, ATMDataListDs> map = new HashMap();
		for (ATMDataListDs atmData : downBySiteTermIdsList) {
			String termId = StringUtils.trimToNull(atmData.getTermId());
			if (termId == null)
				continue;
			map.put(termId, atmData);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List<ATMMonitoringRowListDs> workRows = getDownBySiteAtmList(workRequest, uiMetaData);
		ATMMonitoringRowListDs dto = null;

		for (ATMMonDbListDs atmDataMonDb : downBySiteListMonDb) {
			ATMDataListDs atmData = map.get(atmDataMonDb.getTermId());
			if (atmData == null)
				continue;

			dto = new ATMMonitoringRowListDs();
			dto.loadATMTerminals(atmDataMonDb, atmData);
			workRows.add(dto);
		}

		int total = workRows.size();
		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}
	}

	private void trimTerminalId(List<ATMMonDbListDs> downBySiteList) {
		for (ATMMonDbListDs atmData : downBySiteList) {
			String termId = StringUtils.trimToNull(atmData.getTermId());
			if (termId == null)
				continue;
			atmData.setTermId(termId);
		}
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {
			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		currentfield = fields.get("productId");
		fieldValue = params.get("productId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("siteId");
		fieldValue = params.get("siteId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	private List<ATMMonitoringRowListDs> getDownBySiteAtmList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.ATM_DOWN_SITE_COL);
		workCollection.setSectionId(MonitorConstants.ATM_DOWN_SITE_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.ATM_DOWN_SITE_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<ATMMonitoringRowListDs> workRows = new ArrayList<ATMMonitoringRowListDs>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.ATM_DOWN_SITE_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}