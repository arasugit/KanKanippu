package com.fis.ist.monitoring.dto;

import java.sql.Clob;
import javax.persistence.Entity;
import javax.persistence.Table;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.domain.ATMExtId;
import com.fis.ist.monitoring.domain.MonATMExt;
import com.fis.ist.services.vo.EditableListRowForSDK;

@Entity
@Table(name = "CS_MONATM_EXT" )
public class MonATMExtDto extends EditableListRowForSDK implements Cloneable {
	private static final ISTLogger log = ISTLogger.getLogger(MonATMExtDto.class);

	
	private static final long serialVersionUID = 1L;
	private ATMExtId id;
	private String termId; // Term ID
	private String siteName; // Site Name
	private String siteDesc; // Site Description
	private String siteType; // Site Type
	private String siteLocation; // Site Location
	private String address; // Address
	private String branchId; // Branch Id
	private String branchName; // Branch Name
	private String city; // City
	private String state; // State
	private String country; // Country
	private String lattitude; // Lattitude
	private String longitude; // Longitude
	private String unit; // Unit
	private String instId; // Institution Id
	private String groupName; // Group Name
	private String cra; // Cra
	private String commType; // Commtype
	private String commVendor; // Commvendor
	private String cassetteLoadType; // Cassetteloadtype
	
	
	private MonATMExtDto orignalRow;
	
	public MonATMExtDto() {	}
		
	@Override
	public String toString() {
		return "MonATMExtDto [id=" + id + ", termId=" + termId + ", siteName=" + siteName + ", siteDesc=" + siteDesc
				+ ", siteType=" + siteType + ", siteLocation=" + siteLocation + ", address=" + address + ", branchId="
				+ branchId + ", branchName=" + branchName + ", city=" + city + ", state=" + state + ", country="
				+ country + ", lattitude=" + lattitude + ", longitude=" + longitude + ", unit=" + unit + ", instId="
				+ instId + ", groupName=" + groupName + ", cra=" + cra + ", commType=" + commType + ", commVendor="
				+ commVendor + ", cassetteLoadType=" + cassetteLoadType + ", orignalRow=" + orignalRow + "]";
	}

	
	public ATMExtId getId() {
		return id;
	}

	public void setId(ATMExtId id) {
		this.id = id;
	}

	
	public void load(MonATMExt model)
	{				
		setTermId(model.getTermId());
		setSiteName(model.getSiteName());
		setSiteDesc(model.getSiteDesc());
		setSiteType(model.getSiteType());
		setSiteLocation(model.getSiteLocation());
		setAddress(model.getAddress());
		setBranchId(model.getBranchId());
		setBranchName(model.getBranchName());
		setCity(model.getCity());
		setState(model.getState());
		setCountry(model.getCountry());
		setLattitude(model.getLattitude());
		setLongitude(model.getLongitude());
		setUnit(model.getId().getUnit());
		setInstId(model.getId().getInstId());
		setGroupName(model.getId().getGroupName());
		setCra(model.getCra());
		setCommType(model.getCommType());
		setCommVendor(model.getCommVendor());
		setCassetteLoadType(model.getCassetteLoadType());
	}
	
	public void store(MonATMExt model){

		// Setting ID info
		ATMExtId atmExtId = new ATMExtId();

		atmExtId.setUnit(unit);
		atmExtId.setInstId(instId);
		atmExtId.setGroupName(groupName);			
		
		model.setId(atmExtId);
		
		model.setTermId(termId);
		model.setSiteName(siteName);
		model.setSiteDesc(siteDesc);
		model.setSiteType(siteType);
		model.setSiteLocation(siteLocation);
		model.setAddress(address);
		model.setBranchId(branchId);
		model.setBranchName(branchName);
		model.setCity(city);
		model.setState(state);
		model.setCountry(country);
		model.setLattitude(lattitude);
		model.setLongitude(longitude);
		model.setCra(cra);
		model.setCommType(commType);
		model.setCommVendor(commVendor);
		model.setCassetteLoadType(cassetteLoadType);
		
	}
	
	public String getTermId() {
		return termId;
	}

	public void setTermId(String termId) {
		this.termId = termId;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getSiteDesc() {
		return siteDesc;
	}

	public void setSiteDesc(String siteDesc) {
		this.siteDesc = siteDesc;
	}

	public String getSiteType() {
		return siteType;
	}

	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}

	public String getSiteLocation() {
		return siteLocation;
	}

	public void setSiteLocation(String siteLocation) {
		this.siteLocation = siteLocation;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLattitude() {
		return lattitude;
	}

	public void setLattitude(String lattitude) {
		this.lattitude = lattitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getInstId() {
		return instId;
	}

	public void setInstId(String instId) {
		this.instId = instId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	public String getCra() {
		return cra;
	}

	public void setCra(String cra) {
		this.cra = cra;
	}

	public String getCommType() {
		return commType;
	}

	public void setCommType(String commType) {
		this.commType = commType;
	}

	public String getCommVendor() {
		return commVendor;
	}

	public void setCommVendor(String commVendor) {
		this.commVendor = commVendor;
	}

	public String getCassetteLoadType() {
		return cassetteLoadType;
	}

	public void setCassetteLoadType(String cassetteLoadType) {
		this.cassetteLoadType = cassetteLoadType;
	}

	public MonATMExtDto getOrignalRow() {
		return orignalRow;
	}
	

	public MonATMExtDto(ATMExtId id, String termId, String siteName, String siteDesc, String siteType,
			String siteLocation, String address, String branchId, String branchName, String city, String state,
			String country, String lattitude, String longitude, String unit, String instId, String groupName,
			String cra, String commType, String commVendor, String cassetteLoadType, MonATMExtDto orignalRow) {
		super();
		this.id = id;
		this.termId = termId;
		this.siteName = siteName;
		this.siteDesc = siteDesc;
		this.siteType = siteType;
		this.siteLocation = siteLocation;
		this.address = address;
		this.branchId = branchId;
		this.branchName = branchName;
		this.city = city;
		this.state = state;
		this.country = country;
		this.lattitude = lattitude;
		this.longitude = longitude;
		this.unit = unit;
		this.instId = instId;
		this.groupName = groupName;
		this.cra = cra;
		this.commType = commType;
		this.commVendor = commVendor;
		this.cassetteLoadType = cassetteLoadType;
		this.orignalRow = orignalRow;
	}

	@Override
	public String getFormKey() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void setOrignalRow(MonATMExtDto orignalRow) {
		try {
			if (orignalRow != null)
				this.orignalRow = (MonATMExtDto) orignalRow.clone();
		} catch (Exception e) {
			log.error(e);
		}
	}

}
