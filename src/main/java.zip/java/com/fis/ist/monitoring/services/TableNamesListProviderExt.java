package com.fis.ist.monitoring.services;

import java.util.List;
import java.util.Map;
import com.fis.ist.common.IListProvider;
import com.fis.ist.monitoring.dao.RetentionConfigDAO;;

public class TableNamesListProviderExt implements IListProvider {
	
	//Data Retention Config : Table Names List provider dropdown
	
	@Override
	public List getList() {
		List recordList = null;
		recordList = new RetentionConfigDAO().getTableNamesList();
		return recordList;	
	}
	
	@Override
	public String getName() {
		return "TABLE_NAMES_LIST";
	}

	@Override
	public List getList(Map<String, String> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getListByInstitution(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}
}