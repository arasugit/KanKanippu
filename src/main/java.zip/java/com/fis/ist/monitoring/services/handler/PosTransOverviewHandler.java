package com.fis.ist.monitoring.services.handler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.services.MonitorConfigService;
import com.fis.ist.monitoring.dao.PosTransDao;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.DateTimeRequestDto;
import com.fis.ist.monitoring.dto.PosTransCountDto;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.monitoring.dto.TransactionStatisticsListItem;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class PosTransOverviewHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(PosTransOverviewHandler.class);
	private static String reqTypeId = MonitorConstants.POS_TRANSOVERVIEW_REQ;
	private static String formAuthId = "POSTRANVW";

	public PosTransOverviewHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getTransOverviewWorkRequest(UserContext userContext, Map<String, String> params)
			throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext);
		load(workReq, params);
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) throws Exception {
		log.debug("Load PosTransOverviewHandler ....");

		PosTransDao dao = new PosTransDao();
		String tranRange = params.get("tranRange");
		String tranType = params.get("tranType");
		String isTxnDetailReq = params.get("isTxnDetailReq");

		Integer salesTranPCode = null;
		List<Integer> tranMsgTypes = new ArrayList<>();
		Integer tranRevCode = null;
		Integer tranRespCode = null;
		boolean isSalesTranType = (tranType.contains("Sales") || tranType.contains("Purchase"));
		boolean isChargebackTranType = ("Chargeback".equalsIgnoreCase(tranType));
		boolean loadDetails = "true".equalsIgnoreCase(isTxnDetailReq);

		UIMetaData uiMetaData = getUiMetaData();

		if (isSalesTranType) {
			tranMsgTypes.addAll(Arrays.asList(110, 210, 410, 430));
			salesTranPCode = 0;
			tranType = "Sales";
		} else if (isChargebackTranType)
			tranMsgTypes.add(432);
		else if (tranType.equalsIgnoreCase("Fraudulent"))
			tranRevCode = 3;
		else if (tranType.equalsIgnoreCase("Rejection")) {
			tranRespCode = 903;
			tranRevCode = 92;
		}

		if (loadDetails) {
			String tranStatus = params.get("tranStatus");
			boolean isApprovedTranStatus = ("Approved".equalsIgnoreCase(tranStatus));
			boolean isDeclinedTranStatus = ("Declined".equalsIgnoreCase(tranStatus));
			boolean isReversedTranStatus = ("Reversed".equalsIgnoreCase(tranStatus));

			if (isSalesTranType && isApprovedTranStatus) {
				tranRespCode = 0;
				tranMsgTypes = Arrays.asList(110, 210);
			} else if (isSalesTranType && isDeclinedTranStatus) {
				tranRespCode = -1;
				tranMsgTypes = Arrays.asList(110, 210);
			} else if (isSalesTranType && isReversedTranStatus) {
				tranMsgTypes = Arrays.asList(410, 430);
			} else if (isChargebackTranType && isApprovedTranStatus) {
				tranRespCode = 0;
			} else if (isChargebackTranType && isDeclinedTranStatus) {
				tranRespCode = -1;
			}

			loadTransactionDetails(dao, workRequest, params, uiMetaData, tranType, tranRange, salesTranPCode,
					tranMsgTypes, tranRevCode, tranRespCode);
			return;
		}

		DateTimeRequestDto dateRequest = PaymonUtils.getRequestedDateTime(params);

		List<PosTransCountDto> data = dao.getPosTransCounts(dateRequest.getFormattedFromDate(),
				dateRequest.getFormattedToDate(), dateRequest.getFromDbDateFormat(), dateRequest.getToDbDateFormat(),
				tranRange, salesTranPCode, tranMsgTypes, tranRevCode, tranRespCode, tranType);
		List<PosTransCountDto> workRows = prepareWorkCollection(workRequest, uiMetaData,
				MonitorConstants.POS_TRANSOVERVIEW_COL);

		if (data.size() == 0) {
			workRequest.setLastModified(-1L);
			return;
		}

		workRequest.setLastModified((long) 1);

		for (PosTransCountDto transCountDto : data) {
			workRows.add(transCountDto);
		}
	}

	private void loadTransactionDetails(PosTransDao posTransDao, WorkRequest workRequest, Map<String, String> params,
			UIMetaData uiMetaData, String tranType, String tranRange, Integer salesTranPCode,
			List<Integer> tranMsgTypes, Integer tranRevCode, Integer tranRespCode) throws Exception {
		String tranPeriod = params.get("tranPeriod");
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		TransactionsDAO transDao = new TransactionsDAO();

		DateTimeRequestDto dateRequest = setTransPeriod(tranRange, tranPeriod);
		Integer weekNumber = getTransWeekNumber(tranRange, tranPeriod);
		Integer quarterNumber = getTransQuarterNumber(tranRange, tranPeriod);
		String monthAndYear = getTransMonthAndYear(tranRange, tranPeriod);

		if (needs_total) {
			long total = posTransDao.getPosTransactionLogsCount(dateRequest.getFormattedFromDate(),
					dateRequest.getFormattedToDate(), dateRequest.getFromDbDateFormat(),
					dateRequest.getToDbDateFormat(), salesTranPCode, tranMsgTypes, tranRevCode, tranRespCode, tranType,
					weekNumber, quarterNumber, monthAndYear);

			workRequest.setLastModified(total);
		}

		List txnDetails = posTransDao.getPosTransactionLogs(dateRequest.getFormattedFromDate(),
				dateRequest.getFormattedToDate(), dateRequest.getFromDbDateFormat(), dateRequest.getToDbDateFormat(),
				tranRange, salesTranPCode, tranMsgTypes, tranRevCode, tranRespCode, tranType, weekNumber, quarterNumber,
				monthAndYear, pageNum);
		if (txnDetails == null || txnDetails.size() == 0) {
			return;
		}
		
		TransactionStatisticsListItem dto = null; 
		Object[] result = null;
		MonitorConfigService configService = new MonitorConfigService();
		
		List<TransactionStatisticsListItem> respCodesAndDesc = configService.getResponseCodesAndDesc(transDao);
		List<String> businessDeclineList = configService.getDeclineRespCodes(transDao, MonitorConstants.BD_RESP_CODE_LIST);
		List<String> technicalDeclineList = configService.getDeclineRespCodes(transDao, MonitorConstants.TD_RESP_CODE_LIST);
		List<TransactionStatisticsListItem> workRows = prepareWorkCollection(workRequest, uiMetaData, MonitorConstants.POS_TRANSOVERVIEW_DTL_COL);
		
		for (int i = 0; i < txnDetails.size(); i++) {
			dto = new TransactionStatisticsListItem();
			result = (Object[]) txnDetails.get(i);
			dto.loadTxnLogDetails(result);
			dto.setPosTerminalType((String) result[23]);
			setRespCodeDesc(respCodesAndDesc, dto);
			setDeclineCategory(businessDeclineList, technicalDeclineList, dto);
			workRows.add(dto);
		}
	}

	private DateTimeRequestDto setTransPeriod(String tranRange, String tranPeriod) throws ParseException {
		DateTimeRequestDto dateRequest = new DateTimeRequestDto();

		if (PaymonUtils.isNullOrEmpty(tranPeriod))
			return dateRequest;

		if ("1HR".equalsIgnoreCase(tranRange) || "TODAY".equalsIgnoreCase(tranRange)) {
			String[] tranPeriods = tranPeriod.trim().split("-");
			String currentDate = new SimpleDateFormat(PaymonUtils.InputDateConversionFormat).format(new Date());

			String fromDateTime = currentDate + " " + tranPeriods[0];
			String toDateTime = currentDate + " " + tranPeriods[1];

			setStartAndEndDate(dateRequest, fromDateTime, toDateTime);
		}
		if ("YESTERDAY".equalsIgnoreCase(tranRange)) {
			String[] tranPeriods = tranPeriod.trim().split("-");
			Date yesterdayDate = Date
					.from(LocalDate.now().minusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant());
			String yesterdayDateFormatted = new SimpleDateFormat(PaymonUtils.InputDateConversionFormat)
					.format(yesterdayDate);

			String fromDateTime = yesterdayDateFormatted + " " + tranPeriods[0];
			String toDateTime = yesterdayDateFormatted + " " + tranPeriods[1];

			if ("00:00:00".equals(tranPeriods[1])) {
				String currentDate = new SimpleDateFormat(PaymonUtils.InputDateConversionFormat).format(new Date());
				toDateTime = currentDate + " " + tranPeriods[1];
			}

			setStartAndEndDate(dateRequest, fromDateTime, toDateTime);
		} else if ("CUSTOM".equalsIgnoreCase(tranRange)) {
			String searchDate = tranPeriod.trim();
			Date formattedInputDate = new SimpleDateFormat(PaymonUtils.InputDateFormat).parse(searchDate);
			String formattedOutputDate = new SimpleDateFormat(PaymonUtils.InputDateConversionFormat)
					.format(formattedInputDate);

			String toDateTime = formattedOutputDate + " 23:59:59";
			setStartAndEndDate(dateRequest, formattedOutputDate, toDateTime);
		}

		return dateRequest;
	}

	private Integer getTransWeekNumber(String tranRange, String tranPeriod) {
		if (PaymonUtils.isNullOrEmpty(tranPeriod))
			return null;

		if ("Weekly".equalsIgnoreCase(tranRange)) {
			tranPeriod = tranPeriod.trim().replace("W", "");
			return Integer.parseInt(tranPeriod);
		}

		return null;
	}

	private Integer getTransQuarterNumber(String tranRange, String tranPeriod) {
		if (PaymonUtils.isNullOrEmpty(tranPeriod))
			return null;

		if ("Quartely".equalsIgnoreCase(tranRange)) {
			String[] tranPeriods = tranPeriod.trim().split("-");
			tranPeriod = tranPeriods[0].replace("Q", "");
			return Integer.parseInt(tranPeriod);
		}

		return null;
	}

	private String getTransMonthAndYear(String tranRange, String tranPeriod) {
		return "Monthly".equalsIgnoreCase(tranRange) ? tranPeriod.trim() : null;
	}

	private void setStartAndEndDate(DateTimeRequestDto dateRequest, String fromDateTime, String toDateTime) {
		dateRequest.setFormattedFromDate(fromDateTime);
		dateRequest.setFormattedToDate(toDateTime);
		dateRequest.setFromDbDateFormat(PaymonUtils.DatabaseDateTimeConversionFormat);
		dateRequest.setToDbDateFormat(PaymonUtils.DatabaseDateTimeConversionFormat);
	}
	
	private void setDeclineCategory(List<String> businessDeclineList, List<String> technicalDeclineList, TransactionStatisticsListItem dto)
	{
		String declineCategory = PaymonUtils.getDeclineCategoryByRespCode(businessDeclineList, technicalDeclineList, dto.getRespCode());
		dto.setDeclineCategory(declineCategory);
	}
	
	private void setRespCodeDesc(List<TransactionStatisticsListItem> respCodesAndDesc, TransactionStatisticsListItem dto)
	{
		String respCodeDesc = PaymonUtils.getRespDescByCode(respCodesAndDesc, dto.getRespCode());
		dto.setRespCodeDesc(respCodeDesc);
	}

	private UIMetaData getUiMetaData() {
		UIMetaData uiMetaData = null;

		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		return uiMetaData;
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private <T> List<T> prepareWorkCollection(WorkRequest workRequest, UIMetaData uiMetaData, String collectionName) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(collectionName);
		workCollection.setSectionId(MonitorConstants.POS_TRANSOVERVIEW_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.POS_TRANSOVERVIEW_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<T> workRows = new ArrayList<T>();
		updateWorkCollectionFields(workRequest, uiMetaData, collectionName);
		workCollection.setRows(workRows);
		return workRows;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.POS_TRANSOVERVIEW_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext) throws Exception {
		WorkRequest workReq = new WorkRequest();
		try {
			UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(reqTypeId);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.POS_TRANSOVERVIEW_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.POS_TRANSOVERVIEW_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}
}
