package com.fis.ist.monitoring.domain;

public class ConguredATMByMake implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	private Integer totalConfiguredATM;
	private String make;
	public Integer getTotalConfiguredATM() {
		return totalConfiguredATM;
	}
	public void setTotalConfiguredATM(Integer totalConfiguredATM) {
		this.totalConfiguredATM = totalConfiguredATM;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}

}
