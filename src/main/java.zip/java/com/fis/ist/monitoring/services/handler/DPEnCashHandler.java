package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.DataPointsDAO;
import com.fis.ist.monitoring.dto.DPEnCashListRow;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class DPEnCashHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(DPEnCashHandler.class);
	private static String reqTypeId = MonitorConstants.DPENCASH;
	private static String formAuthId = "DPENCASH";

	public DPEnCashHandler() {
		checkMKCEnabled(formAuthId);
	}

	public DPEnCashHandler(String formAuthIdVar) {
		formAuthId = formAuthIdVar;
		reqTypeId = formAuthIdVar;
		checkMKCEnabled(formAuthIdVar);
	}

	public WorkRequest getDataPointsEnCash(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequestDPEncash(userContext, params);
		loadDataPointsEncash(workReq, params);
		return workReq;
	}

	private void addWorkFieldsDataPointsEncash(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.DPENCASHTAB);
	}

	private WorkRequest prepareWorkRequestDPEncash(UserContext userContext, Map<String, String> params)
			throws Exception {
		log.debug("Prepareing WorkRequest for Data Points Encash");
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.DPENCASH);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.DPENCASH);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.DPENCASHTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.DPENCASHTAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFieldsDataPointsEncash(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private void loadDataPointsEncash(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Loading Data Points EnCash");

		workRequest.setLastModified(1L);
		UIMetaData uiMetaData = null;

		try {
			uiMetaData = CacheFactory.getInstance().getMetaData("DPENCASH");
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		DataPointsDAO dataPointsDAO = new DataPointsDAO();

		int total = dataPointsDAO.getEnCashListCount();

		List encashListResult = dataPointsDAO.getDataPointsEncashList();
		List<DPEnCashListRow> workRows = getDataPointsEnCashWorkRows(workRequest, uiMetaData);

		Iterator rltmCashPosHistoryIterator = encashListResult.iterator();
		while (rltmCashPosHistoryIterator.hasNext()) {
			Object[] rowISTDataFromDB = (Object[]) rltmCashPosHistoryIterator.next();

			DPEnCashListRow rltCashPosListRow = new DPEnCashListRow();
			rltCashPosListRow.loadEnCashInfo(rowISTDataFromDB);

			workRows.add(rltCashPosListRow);
		}

		if (total != 0) {
			workRequest.setLastModified((long) total);
		} else {
			workRequest.setLastModified(-1L);
		}
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
			throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		currentfield = fields.get("productId");
		fieldValue = params.get("productId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("siteId");
		fieldValue = params.get("siteId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	private List<DPEnCashListRow> getDataPointsEnCashWorkRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		log.debug("Prepareing WorkCollection for ATM Real Time Cash Position History");

		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.DPENCASHCOL);
		workCollection.setSectionId(MonitorConstants.DPENCASHSEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.DPENCASHTAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<DPEnCashListRow> workRows = new ArrayList<DPEnCashListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.DPENCASHCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	public HashMap<String, String> getDBMapping() {
		HashMap<String, String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product", "product");
		dtoMapping.put("nodeId", "nodeId");
		dtoMapping.put("taskName", "taskName");
		dtoMapping.put("taskType", "taskType");
		dtoMapping.put("pId", "pId");
		return dtoMapping;
	}

}
