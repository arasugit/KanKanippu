package com.fis.ist.monitoring.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CS_MONPURGE")
public class RetentionConfig implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;  		// ID
	private String product;   	// PRODUCT
	private Integer siteId;   	// SITE_ID
	private Integer nodeId;   	// NODE_ID
	private String nodeName;  	// NODE_NAME
	private String tableName; 	// TABLE_NAME
	private String keyFields; 	// KEY_FIELDS
	private Integer retentionDays;  // RETENTION_DAYS
	private String purgeOption;    	// PURGE_OPTION
	
	
	public RetentionConfig() {}

	public RetentionConfig(Integer id, String product, Integer siteId, Integer nodeId, String nodeName,
			String tableName, String keyFields, Integer retentionDays, String purgeOption) {
		super();
		this.id = id;
		this.product = product;
		this.siteId = siteId;
		this.nodeId = nodeId;
		this.nodeName = nodeName;
		this.tableName = tableName;
		this.keyFields = keyFields;
		this.retentionDays = retentionDays;
		this.purgeOption = purgeOption;
	}

	@Id
	@Column(name = "ID", nullable = true, length = 38)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "NODE_NAME", nullable = true, length = 50)
	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	
	@Column(name = "RETENTION_DAYS", nullable = false, length = 38)
	public Integer getRetentionDays() {
		return retentionDays;
	}
	
	public void setRetentionDays(Integer retentionDays) {
		this.retentionDays = retentionDays;
	}
	
	@Column(name = "PURGE_OPTION", nullable = false, length = 2)
	public String getPurgeOption() {
		return purgeOption;
	}

	public void setPurgeOption(String purgeOption) {
		this.purgeOption = purgeOption;
	}
	
	@Column(name = "PRODUCT", nullable = false, length = 20)
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@Column(name = "SITE_ID", nullable = false, length = 38)
	public Integer getSiteId() {
		return siteId;
	}

	public void setSiteId(Integer siteId) {
		this.siteId = siteId;
	}

	@Column(name = "NODE_ID", nullable = false, length = 38)
	public Integer getNodeId() {
		return nodeId;
	}

	public void setNodeId(Integer nodeId) {
		this.nodeId = nodeId;
	}
	
	@Column(name = "TABLE_NAME", nullable = false, length = 100)
	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	@Column(name = "KEY_FIELDS", nullable = false, length = 100)
	public String getKeyFields() {
		return keyFields;
	}

	public void setKeyFields(String keyFields) {
		this.keyFields = keyFields;
	}

	@Override
	public String toString() {
		return "RetentionConfig [id=" + id + ", product=" + product + ", siteId=" + siteId + ", nodeId=" + nodeId
				+ ", nodeName=" + nodeName + ", tableName=" + tableName + ", keyFields=" + keyFields
				+ ", retentionDays=" + retentionDays + ", purgeOption=" + purgeOption + "]";
	}

}
