package com.fis.ist.monitoring.common.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.ChipNonChipTransactionsDAO;
import com.fis.ist.monitoring.dao.MonGlbValDAO;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.ChipNonChipListRow;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.monitoring.dto.TransactionStatisticsListItem;
import com.fis.ist.spring.HTTPRequestGetter;

public class MonitorConfigService {

	private static final ISTLogger log = ISTLogger.getLogger(MonitorConfigService.class);

	public String getMonGlobalFieldValueList2(String fieldName) {
		MonGlbValDAO dao = new MonGlbValDAO();
		ObjectMapper objectMapper = new ObjectMapper();
		String result = null;
		try {
			result = objectMapper.writeValueAsString(dao.getMonGlobalFieldValueList(fieldName));
		} catch (JsonProcessingException e) {
			log.error("Error while processing json response: " + e.getMessage());
		}
		return result;
	}

	public List<String> getMonGlobalFieldValueList(String fieldName) {
		String product = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");
		MonGlbValDAO dao = new MonGlbValDAO();
		ObjectMapper objectMapper = new ObjectMapper();
		List<String> result = null;
		try {
			result = dao.getListByFieldName(fieldName, product);
		} catch (Exception e) {
			log.error("Error while processing json response: " + e.getMessage());
		}
		return result;
	}
	
	public List<TransactionStatisticsListItem> getResponseCodesAndDesc(TransactionsDAO dao) {
		List<TransactionStatisticsListItem> respCodeList = new ArrayList<>();
		TransactionStatisticsListItem row = null;

		List respCodesAndDesc = dao.getResponseCodesAndDesc();

		for (Iterator iterator = respCodesAndDesc.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();
			row = new TransactionStatisticsListItem();
			row.setRespCode((String) object[0]);
			row.setRespCodeDesc((String) object[1]);
			respCodeList.add(row);
		}

		return respCodeList;
	}

	public List<String> getDeclineRespCodes(TransactionsDAO dao, String declineCategoryListName) {
		List<String> declineList = new ArrayList<>();

		List terminalList = dao.getTDBDRespCode(declineCategoryListName);
		log.debug(String.format("Selected %d TD and BD response code list from db.", terminalList.size()));

		for (Iterator iterator = terminalList.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();

			declineList.add((String) object[1]);
			declineList.add((String) object[2]);
			declineList.add((String) object[3]);
			declineList.add((String) object[4]);
			declineList.add((String) object[5]);
		}

		return declineList.stream().filter(str -> str != null).flatMap(str -> Arrays.stream(str.split(",")))
				.map(String::trim)
				.map(str -> str.length() > 1 && str.startsWith("0") ? str.replaceFirst("^0+", "") : str)
				.collect(Collectors.toList());
	}

	public List<String> getChipNonChipDeclineRespCodes(ChipNonChipTransactionsDAO dao, String declineCategoryListName) {
		List<String> declineList = new ArrayList<>();

		List terminalList = dao.getTDBDRespCode(declineCategoryListName);

		for (Iterator iterator = terminalList.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();

			declineList.add((String) object[1]);
			declineList.add((String) object[2]);
			declineList.add((String) object[3]);
			declineList.add((String) object[4]);
			declineList.add((String) object[5]);
		}

		return declineList.stream().filter(str -> str != null).flatMap(str -> Arrays.stream(str.split(",")))
				.map(String::trim)
				.map(str -> str.length() > 1 && str.startsWith("0") ? str.replaceFirst("^0+", "") : str)
				.collect(Collectors.toList());
	}

	public List<ChipNonChipListRow> getChipNonChipResponseCodesAndDesc(ChipNonChipTransactionsDAO dao) {
		List<ChipNonChipListRow> respCodeList = new ArrayList<>();
		ChipNonChipListRow row = null;

		List respCodesAndDesc = dao.getResponseCodesAndDesc();

		for (Iterator iterator = respCodesAndDesc.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();
			row = new ChipNonChipListRow();
			row.setRespCode((String) object[0]);
			row.setRespCodeDesc((String) object[1]);
			respCodeList.add(row);
		}

		return respCodeList;
	}

	public static List<Integer> convertToIntList(List<String> list) {
		return list.stream().map(Integer::parseInt).collect(Collectors.toList());
	}

}
