package com.fis.ist.monitoring.controller;

public class ControllerSupportConstants {
	
    public static final String PRODUCT_OPERATION_ONE="/set";
    public static final String PRODUCT_OPERATION_TWO="/fetch";
    public static final String CONTENT_TYPE="application/json";
    public static final String PRODUCT_ID="product_id";
    public static final String PRODUCT_NAME="product_name";
    public static final String RAW_TYPES="rawtypes";
    public static final String SITE_ID="site_id";
    public static final String NODE_NAME="node_name";
    public static final String NODE_ID="node_id";
    public static final String PRODUCT_UPDATE_SITENODES="/updateSiteNode";
    public static final String SWITCH_PRODUCT_ID="ISTSWT";
    public static final String CLEARING_PRODUCT_ID="ISTCLR";
    public static final String MAS_PRODUCT_ID="ISTMAS";
    public static final String CORTEX_PRODUCT_ID="CORTEX";

}
