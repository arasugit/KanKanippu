package com.fis.ist.monitoring.dto;

import java.util.List;

public class TransactionDashboardDto implements java.io.Serializable {
private static final long serialVersionUID = 1L;
	
	private List<TxnAuthDenialDto> authDenialList;
	private List<TxnPeakVolumesDto> peakVolumesList;
	private List<TxnCompletionTimeDto> completionTimeList;
	private List<TxnFailuresDto> failureList;
	
	public List<TxnAuthDenialDto> getAuthDenialList() {
		return authDenialList;
	}
	public void setAuthDenialList(List<TxnAuthDenialDto> authDenialList) {
		this.authDenialList = authDenialList;
	}
	public List<TxnPeakVolumesDto> getPeakVolumesList() {
		return peakVolumesList;
	}
	public void setPeakVolumesList(List<TxnPeakVolumesDto> peakVolumesList) {
		this.peakVolumesList = peakVolumesList;
	}
	public List<TxnCompletionTimeDto> getCompletionTimeList() {
		return completionTimeList;
	}
	public void setCompletionTimeList(List<TxnCompletionTimeDto> completionTimeList) {
		this.completionTimeList = completionTimeList;
	}
	public List<TxnFailuresDto> getFailureList() {
		return failureList;
	}
	public void setFailureList(List<TxnFailuresDto> failureList) {
		this.failureList = failureList;
	}	
}
