package com.fis.ist.monitoring.dao;

import java.util.List;
import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.MonAtmCashCenterHistory;
import com.fis.ist.monitoring.dto.ATMRltmCashPosHistoryRequestDto;

@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class MonAtmCashCounterHistoryDAO extends MonitorBaseDAO<MonAtmCashCenterHistory, MonAtmCashCenterHistory> {
	private static final ISTLogger log = ISTLogger.getLogger(MonAtmCashCounterHistoryDAO.class);

	public List getRltmCashHistory(ATMRltmCashPosHistoryRequestDto atmRltmCashPosHistoryRequestDto) {
		log.debug("Preparing ATM Real Time cash position history query");

		atmRltmCashPosHistoryRequestDto
				.setInstitutionId(convertWildSearchString(atmRltmCashPosHistoryRequestDto.getInstitutionId()));
		atmRltmCashPosHistoryRequestDto
				.setTerminalId(convertWildSearchString(atmRltmCashPosHistoryRequestDto.getTerminalId()));
		atmRltmCashPosHistoryRequestDto
				.setGroupName(convertWildSearchString(atmRltmCashPosHistoryRequestDto.getGroupName()));
		
		String query = SqlQueryProvider.getDBSqlQuery("ATM_REAL_CASH_HIST");
		query = setRltmCashHistoryQueryFilter(query, atmRltmCashPosHistoryRequestDto);
		Query queryObject = getSession().createSQLQuery(query).addScalar("instid", StandardBasicTypes.STRING)
				.addScalar("groupname", StandardBasicTypes.STRING).addScalar("atmunit", StandardBasicTypes.STRING)
				.addScalar("termid", StandardBasicTypes.STRING).addScalar("time", StandardBasicTypes.STRING)
				.addScalar("location", StandardBasicTypes.STRING).addScalar("geoLocation", StandardBasicTypes.STRING)
				.addScalar("acceptorname", StandardBasicTypes.STRING).addScalar("currency", StandardBasicTypes.STRING)
				.addScalar("make", StandardBasicTypes.STRING)
				.addScalar("lastWithdrawaldateTime", StandardBasicTypes.STRING)
				.addScalar("Hopper1_Bill", StandardBasicTypes.STRING)
				.addScalar("Hopper2_Bill", StandardBasicTypes.STRING)
				.addScalar("Hopper3_Bill", StandardBasicTypes.STRING)
				.addScalar("Hopper4_Bill", StandardBasicTypes.STRING)
				.addScalar("Hopper1_CashDispense", StandardBasicTypes.STRING)
				.addScalar("Hopper2_CashDispense", StandardBasicTypes.STRING)
				.addScalar("Hopper3_CashDispense", StandardBasicTypes.STRING)
				.addScalar("Hopper4_CashDispense", StandardBasicTypes.STRING)
				.addScalar("Hopper1_EndCash", StandardBasicTypes.STRING)
				.addScalar("Hopper2_EndCash", StandardBasicTypes.STRING)
				.addScalar("Hopper3_EndCash", StandardBasicTypes.STRING)
				.addScalar("Hopper4_EndCash", StandardBasicTypes.STRING);

		setRltmCashHistoryQueryParams(queryObject, atmRltmCashPosHistoryRequestDto);

		if (atmRltmCashPosHistoryRequestDto.getpageNumber() > -1)
			setPaging(queryObject, atmRltmCashPosHistoryRequestDto.getpageNumber());

		log.debug("Executing ATM Real Time cash position history query: " + queryObject.getQueryString());
		return queryObject.list();
	}

	public Integer getRltmCashHistoryCount(ATMRltmCashPosHistoryRequestDto atmRltmCashPosHistoryRequestDto) {
		log.debug("Preparing ATM Real Time cash position history count query");

		atmRltmCashPosHistoryRequestDto
				.setInstitutionId(convertWildSearchString(atmRltmCashPosHistoryRequestDto.getInstitutionId()));
		atmRltmCashPosHistoryRequestDto
				.setTerminalId(convertWildSearchString(atmRltmCashPosHistoryRequestDto.getTerminalId()));
		atmRltmCashPosHistoryRequestDto
				.setGroupName(convertWildSearchString(atmRltmCashPosHistoryRequestDto.getGroupName()));

		String query = SqlQueryProvider.getDBSqlQuery("ATM_REAL_CASH_HIST_CNT");
		query = setRltmCashHistoryQueryFilter(query, atmRltmCashPosHistoryRequestDto);
		Query queryObject = getSession().createSQLQuery(query).addScalar("count",
				StandardBasicTypes.INTEGER);

		setRltmCashHistoryQueryParams(queryObject, atmRltmCashPosHistoryRequestDto);

		log.debug("Executing ATM Real Time cash position history count query: " + queryObject.getQueryString());
		return (int) queryObject.uniqueResult();
	}

	private static void setRltmCashHistoryQueryParams(Query queryObject,
		ATMRltmCashPosHistoryRequestDto atmRltmCashPosHistoryRequestDto) {
		queryObject.setParameter("fromDate", atmRltmCashPosHistoryRequestDto.getDateTimeRequest().getFormattedFromDate());
		queryObject.setParameter("toDate", atmRltmCashPosHistoryRequestDto.getDateTimeRequest().getFormattedToDate());
		queryObject.setParameter("fromDateFormate", atmRltmCashPosHistoryRequestDto.getDateTimeRequest().getFromDbDateFormat());
		queryObject.setParameter("toDateFormate", atmRltmCashPosHistoryRequestDto.getDateTimeRequest().getToDbDateFormat());

		if (!isEmpty(atmRltmCashPosHistoryRequestDto.getInstitutionId())) {
			queryObject.setParameter("institutionid", atmRltmCashPosHistoryRequestDto.getInstitutionId());
		}

		if (!isEmpty(atmRltmCashPosHistoryRequestDto.getTerminalId())) {
			queryObject.setParameter("termId", atmRltmCashPosHistoryRequestDto.getTerminalId());
		}

		if (!isEmpty(atmRltmCashPosHistoryRequestDto.getGroupName())) {
			queryObject.setParameter("groupName", atmRltmCashPosHistoryRequestDto.getGroupName());
		}

		if (atmRltmCashPosHistoryRequestDto.getUnit() > 0) {
			queryObject.setParameter("unit", atmRltmCashPosHistoryRequestDto.getUnit());
		}
	}
	
	private static String setRltmCashHistoryQueryFilter(String query,
		ATMRltmCashPosHistoryRequestDto atmRltmCashPosHistoryRequestDto) {

		StringBuffer queryBuffer = new StringBuffer(" where ");

		if (!isEmpty(atmRltmCashPosHistoryRequestDto.getInstitutionId())) {
			queryBuffer.append(" a.institutionid = :institutionid and ");
		}

		if (!isEmpty(atmRltmCashPosHistoryRequestDto.getTerminalId())) {
			queryBuffer.append(" TRIM(a.termid) like :termId and ");
		}

		if (!isEmpty(atmRltmCashPosHistoryRequestDto.getGroupName())) {
			queryBuffer.append(" a.group_name like :groupName and ");
		}

		if (atmRltmCashPosHistoryRequestDto.getUnit() > 0) {
			queryBuffer.append(" a.unit = :unit and ");
		}
		
		if (PaymonUtils.isOracleDb())
			queryBuffer.append(
					" atmcctr.reset_time between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) ");
		else if (PaymonUtils.isPostgressDb())
			queryBuffer.append(
					" atmcctr.reset_time between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) ");

		query = query.replaceAll("FILTER_QUERY", queryBuffer.toString());
		return query;
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}

	@Override
	public Class<MonAtmCashCenterHistory> getEntityClass() {
		return MonAtmCashCenterHistory.class;
	}

	private static String convertWildSearchString(String value) {
		if (isEmpty(value))
			return value;

		if (hasOnlyAsterisks(value)) {
			return "";
		}

		return value.replace("*", "%");
	}

	private static boolean hasOnlyAsterisks(String input) {
		for (int i = 0; i < input.length(); i++) {
			if (input.charAt(i) != '*') {
				return false;
			}
		}
		return true;
	}
}
