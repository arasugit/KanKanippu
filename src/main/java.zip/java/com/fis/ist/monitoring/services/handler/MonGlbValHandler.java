package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.ForeignKeysCheckException;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MKCHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.customProject.dto.EmpListSPRow;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.MonGlbValDAO;
import com.fis.ist.monitoring.domain.MonGlobalValue;
import com.fis.ist.monitoring.dto.MonGlobalValueDto;
import com.fis.ist.services.MenuService;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.EditableListRow;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

public class MonGlbValHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(MonGlbValHandler.class);
	private static String reqTypeId = MonitorConstants.MONGLBVAL;
	private static String formAuthId = "MONGLBVAL";

	public MonGlbValHandler() {
		checkMKCEnabled(formAuthId);
	}

	public MonGlbValHandler(String formAuthIdVar) {
		formAuthId = formAuthIdVar;
		reqTypeId = formAuthIdVar;
		checkMKCEnabled(formAuthIdVar);
	}

	public WorkRequest getMonGlbVal(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.MONGLBVALTAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.MONGLBVAL);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.MONGLBVAL);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.MONGLBVALTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.MONGLBVALTAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("MonGlbValHandler - Load Mon Global Value Details");
		String productId = params.get("productId");
		log.debug("productId" + productId);
		String siteId = params.get("siteId");
		log.debug("siteId" + siteId);
		String nodeId = params.get("nodeId");
		log.debug("nodeId" + nodeId);

		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);

		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));

		int total = 0;

		String product = params.get("product");

		List<MonGlobalValue> results = new ArrayList<MonGlobalValue>();

		MonGlobalValue findRecord = new MonGlobalValue();

		if (StringUtil.isNotEmpty(product)) {
			try {
				findRecord.setProduct(product);
			} catch (NumberFormatException nfe) {
				log.debug("Invalid Product [" + product + "]", nfe);
			}
		}

		String fieldName = params.get("fieldName");
		if (StringUtil.isNotEmpty(fieldName)) {
			try {
				fieldName = fieldName.trim();
				findRecord.setFieldName(fieldName);
			} catch (NumberFormatException nfe) {
				log.debug("Invalid Product [" + fieldName + "]", nfe);
			}
		}

		if (!needs_total) {
			results = loadMonGlbValListData(findRecord, pageNum);
		} else if (needs_total) {
			total = loadMonGlbValListDataCount(findRecord);
			results = loadMonGlbValListData(findRecord, pageNum);
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List<MonGlobalValueDto> workRows = getNewWorkMonGlbValRows(workRequest, uiMetaData);

		if (results == null || results.size() == 0) {
			return;
		}

		for (MonGlobalValue monGlbValdto : results) {
			if (monGlbValdto != null) {
				MonGlobalValueDto dto = new MonGlobalValueDto();
				dto.load(monGlbValdto);
				dto.setDbAction('x');
				if (isMKCEnabled) {
					dto.setOrignalRow(dto);
				}
				workRows.add(dto);
			}
		}
	}

	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
			throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		currentfield = fields.get("productId");
		fieldValue = params.get("productId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("siteId");
		fieldValue = params.get("siteId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	public HashMap<String, String> getDBMapping() {
		HashMap<String, String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product", "product");
		dtoMapping.put("fieldName", "fieldName");
		dtoMapping.put("fieldValue0", "fieldValue0");
		dtoMapping.put("fieldValue1", "fieldValue1");
		dtoMapping.put("fieldValue2", "fieldValue2");
		dtoMapping.put("fieldValue3", "fieldValue3");
		dtoMapping.put("fieldValue4", "fieldValue4");
		dtoMapping.put("fieldValueDesc", "fieldValueDesc");
		return dtoMapping;
	}

	private List<MonGlobalValueDto> getNewWorkMonGlbValRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.MONGLBVALCOL);
		workCollection.setSectionId(MonitorConstants.MONGLBVALSEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.MONGLBVALTAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<MonGlobalValueDto> workRows = new ArrayList<MonGlobalValueDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.MONGLBVALCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<MonGlobalValue> loadMonGlbValListData(MonGlobalValue model, int pageNum) {
		log.debug("MonGlbValHandler - Load MonGlobalValue records - loadMonGlbValListData()");
		MonGlbValDAO dao = new MonGlbValDAO();
		List<MonGlobalValue> results = dao.findByExample(model, pageNum);

		return results;
	}

	private int loadMonGlbValListDataCount(MonGlobalValue model) {
		log.debug("MonGlbValHandler - Load Task Command records - loadMonGlbValListDataCount()");
		MonGlbValDAO dao = new MonGlbValDAO();
		int count = dao.getTotalByExample(model);
		return count;
	}

	public WorkRequest getDataForAdd(UserContext userContext, WorkRequest workRequest) throws Exception {
		if (workRequest != null) {
			WorkCollection wc = workRequest.getCollections().get(MonitorConstants.MONGLBVALCOL);
			wc.getRows().add(0, getNewMONGLBVALRowInstance());
			return workRequest;
		} else {
			WorkRequest workReq = new WorkRequest();
			UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.MONGLBVAL);

			try {
				workReq.setRequestId("0");
				workReq.setRequestState("DRAFT");

				workReq.setRequestTypeId(MonitorConstants.MONGLBVAL);

				Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
				workReq.setNextStates(nextStates);
				Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
				WorkTabStatus workStatus = new WorkTabStatus();
				workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
				workStatus.setTag(MonitorConstants.MONGLBVALTAB);
				workStatus.setModifyable("Y");
				tabStatus.put(MonitorConstants.MONGLBVALTAB, workStatus);

				workReq.setTabStatus(tabStatus);

				addWorkFields(workReq, uiMetaData);

				workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null);
				Map<String, WorkField> fields = workReq.getFields();
				Collection<WorkField> cfields = fields.values();

				for (WorkField field : cfields) {
					field.setModifyable("Y");
					field.setVisible("Y");
				}

			} catch (Exception ex) {
				WorkRequestHelper.getInstance().reportException(log, ex, workReq);
			}
			return workReq;
		}
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data) throws Exception {
		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);

				data.setUiMetaData(uiMetaData);
				data.initLastModified();

				if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
					workRequest.setSwitchId(userContext.getSwitchID());
				}

				List<MonGlobalValueDto> workRows = getNewWorkMONGLBVALRows(workRequest, uiMetaData);
				workRows.add(getNewMONGLBVALRowInstance());
			}

		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private MonGlobalValueDto getNewMONGLBVALRowInstance() {
		MonGlobalValueDto dto = new MonGlobalValueDto();
		dto.setDbAction('a');
		return dto;
	}

	private List<MonGlobalValueDto> getNewWorkMONGLBVALRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.MONGLBVALCOL);
		workCollection.setSectionId(MonitorConstants.MONGLBVALSEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(CustomConstants.EMPLISTSPTAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<MonGlobalValueDto> workRows = new ArrayList<MonGlobalValueDto>();

		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.MONGLBVALCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	public WorkRequest saveSinglePageRecords(UserContext userContext, WorkRequest workRequest,
			HashMap<String, Boolean> permMap) {
		try {
			workRequest = saveWorkRequest(userContext, workRequest, permMap);
		} catch (Exception e) {
			log.error("Exception occured in the Save Single Pags Records" + e.getMessage());
		}
		return workRequest;
	}

	public WorkRequest saveWorkRequest(UserContext userContext, WorkRequest workRequest,
			HashMap<String, Boolean> permMap) throws Exception {
		if (validateCollectionField(workRequest, CustomConstants.EMPLISTSPCOL))
			return workRequest;

		save(userContext, workRequest, permMap);
		return workRequest;
	}

	private void save(UserContext userContext, WorkRequest workRequest, HashMap<String, Boolean> permMap) {
		// check if contact field data is present
		try {
			Map<String, WorkField> fields = workRequest.getFields();
			if (fields == null) {
				WorkRequestHelper.getInstance().reportError("Work fields not found", workRequest);
				return;
			}

			boolean isInvalidData = false;
			String value = null;
			List<MonGlobalValueDto> corrCollection = new ArrayList<MonGlobalValueDto>();
			List<String> duplicateCollection = new ArrayList<String>();
			MonGlbValDAO dao = new MonGlbValDAO();
			WorkCollection wc = workRequest.getCollections().get(MonitorConstants.MONGLBVALCOL);
			List<MonGlobalValueDto> rows = wc.getRows();
			MonGlobalValue globalValue = new MonGlobalValue();
			int previousId = 0;
			// Only the affected rows will be available here.

			for (int i = 0; i < rows.size(); i++) {
				MonGlobalValueDto row = rows.get(i);
				row.setErrorFlag(false);
				String flag = row.getDbAction().toString();
				if (flag.equals("a") && !(permMap.get("I") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for adding a record");
					isInvalidData = true;
				} else if (flag.equals("c") && !(permMap.get("U") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for updating a record");
					isInvalidData = true;
				} else if (flag.equals("d") && !(permMap.get("D") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for deleting a record");
					isInvalidData = true;
				}

				MonGlobalValueDto model = new MonGlobalValueDto();
				int idVal = 0;
				if (flag.equalsIgnoreCase("a")) {

					HttpServletRequest request = HTTPRequestGetter.getRequest();
					String productId = (String) request.getSession(false).getAttribute("product_id");
					productId = (productId == null ? "" : productId);
					List maxId;
					if (i == 0) {
						maxId = dao.getMaxId();
						idVal = Integer.parseInt(maxId.get(0).toString());
					} else {
						idVal = previousId;
					}
					idVal++;
					previousId = idVal;
					row.setId(new Integer(idVal));
					row.setProduct(productId);
				}

				Object object = row.getId();
				if (object == null) {
					row.setErrorFlag(true);
					row.setErrorMessage("ID cannot be empty");
					isInvalidData = true;
					continue;
				}
				String fieldName = row.getFieldName();
				if (StringUtil.isEmpty(fieldName)) {
					row.setErrorFlag(true);
					row.setErrorMessage("Field name cannot be empty");
					isInvalidData = true;
					continue;
				}
				String fieldValue0 = row.getFieldValue0();
				if (StringUtil.isEmpty(fieldValue0)) {
					row.setErrorFlag(true);
					row.setErrorMessage("Field value0 cannot be empty");
					isInvalidData = true;
					continue;
				}
				model.setId(row.getId());
				String key = "" + fieldName + "" + fieldValue0;

				/*
				 * value = row.getHireDateAsString(); if(StringUtil.isEmpty(value)){
				 * row.setErrorFlag(true); row.setErrorMessage("Hire date cannot be empty");
				 * isInvalidData = true; continue; }
				 */

				if (isMKCEnabled && isCheckerAction) {
					if (duplicateCollection.contains(key + row.getMkcStatus())
							&& AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())) {
						/*
						 * row.setErrorFlag(true);
						 * row.setErrorMessage("Duplicate record with same field name and field value0"
						 * ); isInvalidData = true; continue;
						 */
					} else {
						duplicateCollection.add(key + row.getMkcStatus());
					}
				} else {
					if (!flag.equals("d")) {
						if (duplicateCollection.contains(key)) {
							/*
							 * row.setErrorFlag(true);
							 * row.setErrorMessage("Duplicate record with same field name and field value0"
							 * ); isInvalidData = true; continue;
							 */
						} else {
							duplicateCollection.add(key);
						}
					}
				}
				row.store(globalValue);

				if (isMKCEnabled && isCheckerAction){
					if("a".equals(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus()) && dao.isDuplicate(globalValue)){
						
					}
				}else{
					if(flag.equals("a")){
						
					}
				}

				if (isMKCEnabled && isCheckerAction && AppConstants.MKC_SP_ACTION_REWORK.equals(row.getMkcStatus())
						&& "d".equalsIgnoreCase(flag)) {
					row.setErrorFlag(true);
					row.setErrorMessage("Deleted record cannot be set to rework");
					isInvalidData = true;
					continue;
				}

				if (isMKCEnabled && isCheckerAction && "d".equalsIgnoreCase(flag)
						&& AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())) {
					MonGlobalValue monGlbVal = dao.findById(model.getId());
					if (monGlbVal == null) {
						row.setErrorFlag(true);
						row.setErrorMessage("The record is already deleted. Please reject the record.");
						isInvalidData = true;
						continue;
					}
					dao.getSession().evict(monGlbVal);
				}
				corrCollection.add(row);
			}

			if (isInvalidData) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0106");
				return;
			}

			if (isMKCEnabled && !isCheckerAction) { // maker changes should go into the queue
				// insertCollectionIntoMKC(corrCollection, workRequest.getRequestTypeId(),
				// getUserId(userContext));
				for (EditableListRow edlsrow : corrCollection) {
					if (edlsrow != null) {
						EmpListSPRow dto = (EmpListSPRow) edlsrow;
						MKCHandler.getInstance().insertListRowIntoMKC(dto, dto.getEmployeeId().toString(),
								workRequest.getRequestTypeId(), getUserId(userContext),
								MenuService.getModuleName(reqTypeId));
					}
				}
			} else {
				for (MonGlobalValueDto dto : corrCollection) {
					String action = dto.getDbAction().toString();
					if (!isMKCEnabled) { // non mkc
						if ("c".equalsIgnoreCase(action)) {
							MonGlobalValue monGlbVal = dao.findById(dto.getId()); // error
							if (monGlbVal != null) {
								dto.store(monGlbVal);
								dao.attachDirty(monGlbVal);
							}
						} else if ("a".equalsIgnoreCase(action)) {
							MonGlobalValue monGlbVal = new MonGlobalValue();
							dto.store(monGlbVal);
							dao.save(monGlbVal);
						} else if ("d".equalsIgnoreCase(action)) {
							MonGlobalValue monGlbVal = new MonGlobalValue();
							dto.store(monGlbVal);
							dao.delete(monGlbVal);
						}
					} else if (isMKCEnabled && isCheckerAction) { // MKC Checker
						String status = dto.getMkcStatus();
						if ((AppConstants.MKC_SP_ACTION_APPROVE).equals(status)) {
							if ("c".equalsIgnoreCase(action)) {
								MonGlobalValue monGlbVal = dao.findById(dto.getId());
								if (monGlbVal != null) {
									dto.store(monGlbVal);
									dao.attachDirty(monGlbVal);
								}
							} else if ("a".equalsIgnoreCase(action)) {
								MonGlobalValue monGlbVal = new MonGlobalValue();
								dto.store(monGlbVal);
								dao.save(monGlbVal);
							} else if ("d".equalsIgnoreCase(action)) {
								MonGlobalValue monGlbVal = new MonGlobalValue();
								dto.store(monGlbVal);
								dao.delete(monGlbVal);
							}
							MKCHandler.getInstance().ApproveMKCRecord(dto.getMkcId(), getUserId(userContext),
									dto.getMkcRemarks(), dto.getMkcScheduleDt());
						} else if (AppConstants.MKC_SP_ACTION_REJECT.equals(status)
								|| AppConstants.MKC_SP_ACTION_REWORK.equals(status)) {
							MKCHandler.getInstance().RejectOrReturnRecord(dto.getMkcId(), getUserId(userContext),
									dto.getMkcRemarks(), dto.getMkcScheduleDt(), status);
						} else {
						}
					}
				}
			}
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_NONE);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_SUCCESS);
			workRequest.setErrorDetail("");
			rows.clear();
		} catch (Exception e) {
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail(e.getMessage());
			if (e instanceof ForeignKeysCheckException) {
				workRequest.setMessageSubstitutions(((ForeignKeysCheckException) e).getChildTables());
			}
		}
	}
}