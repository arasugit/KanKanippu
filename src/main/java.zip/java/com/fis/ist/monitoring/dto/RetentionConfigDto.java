package com.fis.ist.monitoring.dto;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.domain.RetentionConfig;
import com.fis.ist.monitoring.domain.RetentionConfigId;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class RetentionConfigDto extends EditableListRowForSDK implements Cloneable {
	
	private static final long serialVersionUID = 1L;

	private static final ISTLogger log = ISTLogger.getLogger(RetentionConfigDto.class);

	private RetentionConfigId retId;

	private Integer id;
	private String product;
	private Integer siteId;
	private Integer nodeId;
	private String nodeName;
	private String tableName;
	private String keyFields;
	private String retentionDays;
	private String purgeOption;

	private RetentionConfigDto orignalRow;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public Integer getSiteId() {
		return siteId;
	}

	public void setSiteId(Integer siteId) {
		this.siteId = siteId;
	}

	public Integer getNodeId() {
		return nodeId;
	}

	public void setNodeId(Integer nodeId) {
		this.nodeId = nodeId;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getKeyFields() {
		return keyFields;
	}

	public void setKeyFields(String keyFields) {
		this.keyFields = keyFields;
	}

	public String getRetentionDays() {
		return retentionDays;
	}

	public void setRetentionDays(String retentionDays) {
		this.retentionDays = retentionDays;
	}

	public String getPurgeOption() {
		return purgeOption;
	}

	public void setPurgeOption(String purgeOption) {
		this.purgeOption = purgeOption;
	}

	public RetentionConfigDto getOrignalRow() {
		return orignalRow;
	}

	public void setOrignalRow(RetentionConfigDto orignalRow) {
		this.orignalRow = orignalRow;
	}

	public void load(RetentionConfig model) {
		setId(model.getId());
		setProduct(model.getProduct());
		setSiteId(model.getSiteId());
		setNodeId(model.getNodeId());
		setNodeName(model.getNodeName());
		setTableName(model.getTableName());
		setKeyFields(model.getKeyFields());
		setRetentionDays(String.valueOf(model.getRetentionDays()));
		setPurgeOption(model.getPurgeOption());
	}

	public void store(RetentionConfig model) {

		model.setId(getId());
		model.setProduct(product);
		model.setSiteId(siteId);
		model.setNodeId(nodeId);
		model.setTableName(tableName);
		model.setKeyFields(keyFields);
		model.setNodeName(nodeName);
		model.setRetentionDays(Integer.valueOf(retentionDays));
		model.setPurgeOption(purgeOption);
	}

	@Override
	public String getFormKey() {
		return null;
	}

	public RetentionConfigDto() {
	}

	public RetentionConfigDto(RetentionConfigId retId, Integer id, String product, Integer siteId, Integer nodeId,
			String nodeName, String tableName, String keyFields, String retentionDays, String purgeOption,
			RetentionConfigDto orignalRow) {
		super();

		this.id = id;
		this.product = product;
		this.siteId = siteId;
		this.nodeId = nodeId;
		this.nodeName = nodeName;
		this.tableName = tableName;
		this.keyFields = keyFields;
		this.retentionDays = retentionDays;
		this.purgeOption = purgeOption;
		this.orignalRow = orignalRow;
	}

	@Override
	public String toString() {
		return "RetentionConfigDto [retId=" + retId + ", id=" + id + ", product=" + product + ", siteId=" + siteId
				+ ", nodeId=" + nodeId + ", nodeName=" + nodeName + ", tableName=" + tableName + ", keyFields="
				+ keyFields + ", retentionDays=" + retentionDays + ", purgeOption=" + purgeOption + "]";
	}
}
