package com.fis.ist.monitoring.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.services.handler.TpsVsMemoryHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class TpsVsMemoryService extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(TpsVsMemoryService.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		TpsVsMemoryHandler handler = new TpsVsMemoryHandler();
		
		if (action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = handler.getList(userContext, requestParams);
		} else {
			log.error("**** TPS Vs Memory : getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}
		
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}
}