package com.fis.ist.monitoring.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CS_MONALERT")
public class Notification {

	private Integer id;
	private String logDate;
	private String message;
	private String serverity;
	private String product;
	private String nodeName;

	@Id
	@Column(name = "ID", nullable = false, length = 100)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "LOGDATE", nullable = true)
	public String getLogDate() {
		return logDate;
	}

	public void setLogDate(String logDate) {
		this.logDate = logDate;
	}

	@Column(name = "ALERTMSG", nullable = true, length = 250)
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Column(name = "ALERTSEVERITY", nullable = true, length = 50)
	public String getServerity() {
		return serverity;
	}

	public void setServerity(String serverity) {
		this.serverity = serverity;
	}

	@Column(name = "PRODUCT", nullable = true, length = 50)
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@Column(name = "NODE_NAME", nullable = true, length = 30)
	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

}
