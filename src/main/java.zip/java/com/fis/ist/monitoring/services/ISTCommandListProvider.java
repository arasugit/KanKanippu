package com.fis.ist.monitoring.services;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.fis.ist.common.IListProvider;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.ISTCommandDAO;
import com.fis.ist.spring.HTTPRequestGetter;

public class ISTCommandListProvider implements IListProvider {

	private String searchListType = "";

	public List getList(Map<String, String> params) {
		final ISTLogger log = ISTLogger.getLogger(ISTCommandListProvider.class);

		ISTCommandDAO tcmdDao = new ISTCommandDAO();

		List recordList = null;
		searchListType = params.get("type");

		HttpServletRequest request = HTTPRequestGetter.getRequest();
		String productId = (String) request.getSession(false).getAttribute("product_id");
		String nodeName = (String) request.getSession(false).getAttribute("node_name");

		params.put("product", productId == null ? "" : productId);
		params.put("nodeId", nodeName == null ? "*" : nodeName);

		log.debug("Product Id" + " : " + productId + " & By Loading ISTCommandListProvider - getList() " + params);

		if (searchListType.compareToIgnoreCase("ISTCommandList") == 0) {
			recordList = tcmdDao.getISTCommandList();
		} else if (searchListType.compareToIgnoreCase("SucRejTxnCntResponseCodeGroup") == 0) {
			recordList = tcmdDao.getResponseCodeGroupList(productId);
		} else if (searchListType.compareToIgnoreCase("SucRejTxnCntResponseCode") == 0) {
			recordList = tcmdDao.getResponseCode();
		} else if (searchListType.compareToIgnoreCase("TSKCMDCommandExecutionInsert") == 0
				|| searchListType.compareToIgnoreCase("ATMCMDCommandExecutionInsert") == 0) {
			recordList = tcmdDao.setCommandExecution(params);
			String commandExecutionTimer = tcmdDao.getIstCommandExecutionTimer(params);
			recordList.add(commandExecutionTimer); // Fetched from cs_monglobalvalue FIELD NAME : CMD_EXE_TIMER.
		} else if (searchListType.compareToIgnoreCase("TSKCMDCommandExecutionFetchAfterInsert") == 0
				|| searchListType.compareToIgnoreCase("ATMCMDCommandExecutionFetchAfterInsert") == 0) {
			recordList = tcmdDao.getStatusAfterCommandExecution(params);

		}

		return recordList;
	}

	@Override
	public List getList() {
		List recordList = new ISTCommandDAO().getISTCommandNodeId();
		return recordList;
	}

	@Override
	public List getListByInstitution(String arg0) {
		return null;
	}

	@Override
	public String getName() {
		return "IST_COMMANDLIST_PROVIDER";
	}

}
