package com.fis.ist.monitoring.dto;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class ChipNonChipListRow extends EditableListRowForSDK implements Cloneable  {

	private static final long serialVersionUID = 1L;
	private static final ISTLogger log = ISTLogger.getLogger(ChipNonChipListRow.class);

	@Override
	public String getFormKey() {
		return null;
	}
	
	private String txnsrc;
	private String acquirer;
	private String totalChipCnt;
	private String totalNonChipCnt;
	private String totalApprovalCnt;
	private String totalDeclineCnt;
	private String totalReversalCnt;
	private String approvalPercentage;
	private String declinePercentage;
	private String reversalPercentage;
	private String totalTranssaction;
	private String terminalId;
	private String transactionDate;
	private String msgType;
	private String txnDest;
	private String issuer;
	private String respCode;
	private String respCodeDesc;
	private String processingCode;
	private String processingCodeDesc;
	private String istSysDate;
	private String currCode;
	private String pan;
	private String approvedTransactionCount;
	private String rejectedTransactionCount;
	private String chipIndex;
	private String trace;
	private String refNum;
	private String amount;
	private String localDate;
	private String localTime;
	private String transDate;
	private String transTime;
	private String txnMonth;
	private String numTxnsPerMonth;
	private String tps;
	private String businessDecline;
	private String technicalDecline;
	private String declineCategory;
	private String origDate;
	private String origTrace;
	private String origTime;
	private String origMsg;
	private String txnType;
	private String authNum;
	private String approvedCashWdCnt;
	private String approvedBalInqCnt;
	private String approvedPurchaseCnt; 
	private String approvedDepositCnt;
	private String approvedTransferCnt;
	private String approvedOthersCnt;
	private String declinedCashWdCnt;
	private String declinedBalInqCnt;
	private String declinedPurchaseCnt;
	private String declinedDepositCnt;
	private String declinedTransferCnt;
	private String declinedOthersCnt;
	private String posTerminalType;
	
	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTxnsrc() {
		return txnsrc;
	}

	public void setTxnsrc(String txnsrc) {
		this.txnsrc = txnsrc;
	}

	public String getAcquirer() {
		return acquirer;
	}

	public void setAcquirer(String acquirer) {
		this.acquirer = acquirer;
	}

	public String getTotalApprovalCnt() {
		return totalApprovalCnt;
	}

	public void setTotalApprovalCnt(String totalApprovalCnt) {
		this.totalApprovalCnt = totalApprovalCnt;
	}

	public String getTotalDeclineCnt() {
		return totalDeclineCnt;
	}

	public void setTotalDeclineCnt(String totalDeclineCnt) {
		this.totalDeclineCnt = totalDeclineCnt;
	}

	public String getTotalReversalCnt() {
		return totalReversalCnt;
	}

	public void setTotalReversalCnt(String totalReversalCnt) {
		this.totalReversalCnt = totalReversalCnt;
	}

	public String getApprovalPercentage() {
		return approvalPercentage;
	}

	public void setApprovalPercentage(String approvalPercentage) {
		this.approvalPercentage = approvalPercentage;
	}

	public String getDeclinePercentage() {
		return declinePercentage;
	}

	public void setDeclinePercentage(String declinePercentage) {
		this.declinePercentage = declinePercentage;
	}

	public String getReversalPercentage() {
		return reversalPercentage;
	}

	public void setReversalPercentage(String reversalPercentage) {
		this.reversalPercentage = reversalPercentage;
	}

	public String getTotalTranssaction() {
		return totalTranssaction;
	}

	public void setTotalTranssaction(String totalTranssaction) {
		this.totalTranssaction = totalTranssaction;
	}

	public String getMsgType() {
		return msgType;
	}

	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

	public String getTxnDest() {
		return txnDest;
	}

	public void setTxnDest(String txnDest) {
		this.txnDest = txnDest;
	}

	public String getIssuer() {
		return issuer;
	}

	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}
	
	public String getRespCodeDesc() {
		return respCodeDesc;
	}

	public void setRespCodeDesc(String respCodeDesc) {
		this.respCodeDesc = respCodeDesc;
	}

	public String getProcessingCode() {
		return processingCode;
	}

	public void setProcessingCode(String processingCode) {
		this.processingCode = processingCode;
	}

	public String getProcessingCodeDesc() {
		return processingCodeDesc;
	}

	public void setProcessingCodeDesc(String processingCodeDesc) {
		this.processingCodeDesc = processingCodeDesc;
	}

	public String getIstSysDate() {
		return istSysDate;
	}

	public void setIstSysDate(String istSysDate) {
		this.istSysDate = istSysDate;
	}

	public String getCurrCode() {
		return currCode;
	}

	public void setCurrCode(String currCode) {
		this.currCode = currCode;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getApprovedTransactionCount() {
		return approvedTransactionCount;
	}

	public void setApprovedTransactionCount(String approvedTransactionCount) {
		this.approvedTransactionCount = approvedTransactionCount;
	}

	public String getRejectedTransactionCount() {
		return rejectedTransactionCount;
	}

	public void setRejectedTransactionCount(String rejectedTransactionCount) {
		this.rejectedTransactionCount = rejectedTransactionCount;
	}

	public String getChipIndex() {
		return chipIndex;
	}

	public void setChipIndex(String chipIndex) {
		this.chipIndex = chipIndex;
	}

	public String getTrace() {
		return trace;
	}

	public void setTrace(String trace) {
		this.trace = trace;
	}

	public String getRefNum() {
		return refNum;
	}

	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getLocalDate() {
		return localDate;
	}

	public void setLocalDate(String localDate) {
		this.localDate = localDate;
	}

	public String getLocalTime() {
		return localTime;
	}

	public void setLocalTime(String localTime) {
		this.localTime = localTime;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}
	public String getTxnMonth() {
		return txnMonth;
	}

	public void setTxnMonth(String txnMonth) {
		this.txnMonth = txnMonth;
	}

	public String getNumTxnsPerMonth() {
		return numTxnsPerMonth;
	}

	public void setNumTxnsPerMonth(String numTxnsPerMonth) {
		this.numTxnsPerMonth = numTxnsPerMonth;
	}

	public String getTps() {
		return tps;
	}

	public void setTps(String tps) {
		this.tps = tps;
	}
	
	public String getBusinessDecline() {
		return businessDecline;
	}

	public void setBusinessDecline(String businessDecline) {
		this.businessDecline = businessDecline;
	}

	public String getTechnicalDecline() {
		return technicalDecline;
	}

	public void setTechnicalDecline(String technicalDecline) {
		this.technicalDecline = technicalDecline;
	}
	
	public String getDeclineCategory() {
		return declineCategory;
	}

	public void setDeclineCategory(String declineCategory) {
		this.declineCategory = declineCategory;
	}
	
	public String getOrigDate() {
		return origDate;
	}

	public void setOrigDate(String origDate) {
		this.origDate = origDate;
	}

	public String getOrigTrace() {
		return origTrace;
	}

	public void setOrigTrace(String origTrace) {
		this.origTrace = origTrace;
	}

	public String getOrigTime() {
		return origTime;
	}

	public void setOrigTime(String origTime) {
		this.origTime = origTime;
	}
	
	public String getOrigMsg() {
		return origMsg;
	}

	public void setOrigMsg(String origMsg) {
		this.origMsg = origMsg;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getAuthNum() {
		return authNum;
	}

	public void setAuthNum(String authNum) {
		this.authNum = authNum;
	}
	
	public String getApprovedCashWdCnt() {
		return approvedCashWdCnt;
	}

	public void setApprovedCashWdCnt(String approvedCashWdCnt) {
		this.approvedCashWdCnt = approvedCashWdCnt;
	}

	public String getApprovedBalInqCnt() {
		return approvedBalInqCnt;
	}

	public void setApprovedBalInqCnt(String approvedBalInqCnt) {
		this.approvedBalInqCnt = approvedBalInqCnt;
	}

	public String getApprovedPurchaseCnt() {
		return approvedPurchaseCnt;
	}

	public void setApprovedPurchaseCnt(String approvedPurchaseCnt) {
		this.approvedPurchaseCnt = approvedPurchaseCnt;
	}

	public String getApprovedDepositCnt() {
		return approvedDepositCnt;
	}

	public void setApprovedDepositCnt(String approvedDepositCnt) {
		this.approvedDepositCnt = approvedDepositCnt;
	}

	public String getApprovedTransferCnt() {
		return approvedTransferCnt;
	}

	public void setApprovedTransferCnt(String approvedTransferCnt) {
		this.approvedTransferCnt = approvedTransferCnt;
	}

	public String getApprovedOthersCnt() {
		return approvedOthersCnt;
	}

	public void setApprovedOthersCnt(String approvedOthersCnt) {
		this.approvedOthersCnt = approvedOthersCnt;
	}

	public String getDeclinedCashWdCnt() {
		return declinedCashWdCnt;
	}

	public void setDeclinedCashWdCnt(String declinedCashWdCnt) {
		this.declinedCashWdCnt = declinedCashWdCnt;
	}

	public String getDeclinedBalInqCnt() {
		return declinedBalInqCnt;
	}

	public void setDeclinedBalInqCnt(String declinedBalInqCnt) {
		this.declinedBalInqCnt = declinedBalInqCnt;
	}

	public String getDeclinedPurchaseCnt() {
		return declinedPurchaseCnt;
	}

	public void setDeclinedPurchaseCnt(String declinedPurchaseCnt) {
		this.declinedPurchaseCnt = declinedPurchaseCnt;
	}

	public String getDeclinedDepositCnt() {
		return declinedDepositCnt;
	}

	public void setDeclinedDepositCnt(String declinedDepositCnt) {
		this.declinedDepositCnt = declinedDepositCnt;
	}

	public String getDeclinedTransferCnt() {
		return declinedTransferCnt;
	}

	public void setDeclinedTransferCnt(String declinedTransferCnt) {
		this.declinedTransferCnt = declinedTransferCnt;
	}

	public String getDeclinedOthersCnt() {
		return declinedOthersCnt;
	}

	public void setDeclinedOthersCnt(String declinedOthersCnt) {
		this.declinedOthersCnt = declinedOthersCnt;
	}
	
	public String getPosTerminalType() {
		return posTerminalType;
	}

	public void setPosTerminalType(String posTerminalType) {
		this.posTerminalType = posTerminalType;
	}

	public void load(Object[] model) {
		setTxnsrc((String) model[0]);
		setAcquirer((String) model[1]);
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
		setTotalTranssaction((String) model[5]);
		setApprovalPercentage((String) model[6]);
		setDeclinePercentage((String) model[7]);
		setReversalPercentage((String) model[8]);
		
		setTotalChipCnt((String) model[9]);
		setTotalNonChipCnt((String) model[10]);
	}

	public void loadByRespCode(Object[] model) {
		setTxnsrc((String) model[0]);
		setAcquirer((String) model[1]);
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
		setTotalTranssaction((String) model[5]);
		setApprovalPercentage((String) model[6]);
		setDeclinePercentage((String) model[7]);
		setReversalPercentage((String) model[8]);
		
		setTotalChipCnt((String) model[9]);
		setTotalNonChipCnt((String) model[10]);
	}

	public void loadTerminalTopComp(Object[] model) {
		setTerminalId((String) model[0]);
		setTotalTranssaction((String) model[1]);
		setTransactionDate((String) model[2]);
	}

	public void loadTxnStsAcqComp(Object[] model) {
		// setTerminalId((String) model[0]);
		setTotalTranssaction((String) model[0]);
		setTransactionDate((String) model[1]);
	}

	public void loadTxnStsAcqRejection(Object[] model) {
		setMsgType((String) model[0]);
		setTxnsrc((String) model[1]);
		setAcquirer((String) model[2]);
		setProcessingCode((String) model[3]);
		setTxnType((String) model[4]);
		setTxnDest((String) model[5]);
		setIssuer((String) model[6]);
		setChipIndex((String) model[7]);
		setTrace((String) model[8]);
		setRefNum((String) model[9]);
		setAmount((String) model[10]);
		setLocalDate(getFormattedDate(model[11].toString()));
		setLocalTime((String) model[12]);
		setTransDate(getFormattedDate(model[13].toString()));
		setTransTime((String) model[14]);
		setRespCode((String) model[15]);
		setTransactionDate(getFormattedDateWithTime(model[16].toString()));
		setOrigMsg((String) model[17]);
		setOrigDate((getFormattedDate(model[18].toString())));
		setOrigTrace((String) model[19]);
		setOrigTime((String) model[20]); 
		setAuthNum((String) model[21]);
		setTerminalId((String) model[22]);
	}

	public void loadTxnStsByProcCode(Object[] model) {
		setProcessingCode((String) model[0]);
		setTotalTranssaction((String) model[1]);

	}

	public void loadTxnStsATMPOS(Object[] model) {
		setMsgType((String) model[0]);
		setTxnsrc((String) model[1]);
		setAcquirer((String) model[2]);
		setProcessingCode((String) model[3]);
		setTxnType((String) model[4]);
		setTxnDest((String) model[5]);
		setIssuer((String) model[6]);
		setChipIndex((String) model[7]);
		setTrace((String) model[8]);
		setRefNum((String) model[9]);
		setAmount((String) model[10]);
		setLocalDate(getFormattedDate(model[11].toString()));
		setLocalTime((String) model[12]);
		setTransDate(getFormattedDate(model[13].toString()));
		setTransTime((String) model[14]);
		setRespCode((String) model[15]);
		setIstSysDate(getFormattedDateWithTime(model[16].toString()));
		setOrigMsg((String) model[17]);
		setOrigDate(getFormattedDate(model[18].toString()));
		setOrigTrace((String) model[19]);
		setOrigTime((String) model[20]);
		setAuthNum((String) model[21]);
		setTerminalId((String) model[22]);	}
	
	public void loadTxnStsLog(Object[] model) {
		setMsgType((String) model[0]);
		setTxnsrc((String) model[1]);
		setAcquirer((String) model[2]);
		setProcessingCode((String) model[3]);
		setTxnDest((String) model[4]);
		setIssuer((String) model[5]);
		setChipIndex((String) model[6]);
		setTrace((String) model[7]);
		setRefNum((String) model[8]);
		setAmount((String) model[9]);
		setLocalDate(getFormattedDate(model[10].toString()));
		setLocalTime((String) model[11]);
		setTransDate(getFormattedDate(model[12].toString()));
		setTransTime((String) model[13]);
		setRespCode((String) model[14]);
		setIstSysDate(getFormattedDateWithTime(model[15].toString()));
		setTerminalId((String) model[16]);
	}

	public void loadTxnStsOverseas(Object[] model) {
		//msgtype, txnsrc, acquirer,txndest,issuer, chip_index as chipindex, trace, refnum, amount, local_date, local_time, 
		//trandate, trantime,acq_currency_code ,respcode, istsysdate
		setMsgType((String) model[0]);
		setTxnsrc((String) model[1]);
		setAcquirer((String) model[2]);
		setTxnDest((String) model[3]);
		setIssuer((String) model[4]);
		setChipIndex((String) model[5]);
		setTrace((String) model[6]);
		setRefNum((String) model[7]);
		setAmount((String) model[8]);
		setLocalDate(getFormattedDate(model[9].toString()));
		setLocalTime((String) model[10]);
		setTransDate(getFormattedDate(model[11].toString()));   
		setTransTime((String) model[12]);
		setCurrCode((String) model[13]);
		setRespCode((String) model[14]);
		setIstSysDate(getFormattedDateWithTime(model[15].toString()));   
		setProcessingCode((String) model[16]);
		setTxnType((String) model[17]);
		setOrigMsg((String) model[18]);
		setOrigDate(getFormattedDate(model[19].toString()));
		setOrigTrace((String) model[20]);
		setOrigTime((String) model[21]); 
		setAuthNum((String) model[22]);
		setTerminalId((String) model[23]);
	}

	public void loadTxnStsTerminal(Object[] model) {
		setTerminalId((String) model[0]);
		setProcessingCode((String) model[1]);
		setTotalTranssaction((String) model[2]);
	}

	public void loadTxnStsHighVol(Object[] model) {
		setPan((String) model[0]);
		setTotalTranssaction((String) model[1]);
	}

	// To load Top and Least 25 Transacting Terminals
	public void loadTxnTerminals(Object[] model) {
		setTerminalId((String) model[0]);
		setTotalTranssaction((String) model[1]);
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
	}

	// To load Host Transaction Statistics
	public void loadHostTxns(Object[] model) {
		setTxnDest((String) model[0]);
		setIssuer((String) model[1]);
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
		setTotalTranssaction((String) model[5]);
		setApprovalPercentage((String) model[6].toString().replace("%", ""));
		setDeclinePercentage((String) model[7].toString().replace("%", ""));
		setReversalPercentage((String) model[8].toString().replace("%", ""));
		
		setTotalChipCnt((String) model[9]);
		setTotalNonChipCnt((String) model[10]);
	}

	// To load Successful/ Rejected Transactions Count
	public void loadTxns(Object[] model) {
		setTxnDest((String) model[0]);
		setIssuer((String) model[1]);
		setApprovedTransactionCount((String) model[2]);
		setRejectedTransactionCount((String) model[3]);
		setBusinessDecline((String) model[4]);
		setTechnicalDecline((String) model[5]);
		
		setTotalChipCnt((String) model[6]);
		setTotalNonChipCnt((String) model[7]);
	}
	
	public void loadTxnsIssuer(Object[] model) {
		setTxnsrc((String) model[0]);
		setAcquirer((String) model[1]);
		setTxnDest((String) model[2]);
		setApprovedTransactionCount((String) model[3]);
	}
	
	public void loadFallbackTxns(Object[] model) {
		setTxnsrc((String) model[0]);
		setAcquirer((String) model[1]);
		setTerminalId((String) model[2]);
		setApprovedTransactionCount((String) model[3]);
	}

	public void loadAvgTPS(Object[] model) {
		setTxnMonth((String) model[0]);
		setNumTxnsPerMonth((String) model[1]);
		setTps((String) model[2]);
	}
	
	public void loadCurrentTPS(String model) {
		setTps((String) model);
	}
	
	public void loadTxnDetails(Object[] model) {
		loadTxnDetails(model, null);
	}
	
	public void loadTxnDetails(Object[] model, Boolean customDateTimeFormat) {
		setMsgType((String) model[0]);
		setProcessingCode((String) model[1]);
		setTxnType((String) model[2]);
		setTxnsrc((String) model[3]);
		setAcquirer((String) model[4]);
		setTxnDest((String) model[5]);
		setIssuer((String) model[6]);
		setChipIndex((String) model[7]);
		setTrace((String) model[8]);
		setRefNum((String) model[9]);
		setAmount((String) model[10]);
		setLocalDate(getFormattedDate(model[11].toString()));
		setLocalTime((String) model[12]);
		setTransDate(getFormattedDate(model[13].toString()));
		setTransTime((String) model[14]);
		setRespCode((String) model[15]);
		
		if (customDateTimeFormat != null && customDateTimeFormat == true) {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			setIstSysDate(getFormattedDateWithTime(model[16].toString(), inputFormat, null));
		} else {
			setIstSysDate(getFormattedDateWithTime(model[16].toString()));
		}
		
		setOrigMsg((String) model[17]);
		setOrigDate(getFormattedDate(model[18].toString()));
		setOrigTrace((String) model[19]);
		setOrigTime((String) model[20]);
		setAuthNum((String) model[21]);
		setTerminalId((String) model[22]);
	}
	
	public void loadTxnLogDetails(Object[] model) {
		setMsgType((String) model[0]);
		setProcessingCode((String) model[1]);
		setTxnType((String) model[2]);
		setTxnsrc((String) model[3]);
		setAcquirer((String) model[4]);
		setTxnDest((String) model[5]);
		setIssuer((String) model[6]);
		setChipIndex((String) model[7]);
		setTrace((String) model[8]);
		setRefNum((String) model[9]);
		setAmount((String) model[10]);
		setLocalDate(getFormattedDate(model[11].toString()));
		setLocalTime((String) model[12]);
		setTransDate(getFormattedDate(model[13].toString()));
		setTransTime((String) model[14]);
		setRespCode((String) model[15]);
		setIstSysDate(getFormattedDateWithTime(model[16].toString()));
		setOrigMsg((String) model[17]);
		setOrigDate(getFormattedDate((String) model[18].toString()));
		setOrigTrace((String) model[19]);
		setOrigTime((String) model[20]); 
		setAuthNum((String) model[21]);
		setTerminalId((String) model[22]);
		setPan((String) model[23]);
	}
	
	public void loadTxnType(Object[] model) {
		setProcessingCode((String) model[0]);
		setTotalTranssaction(((String) model[1]));
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
	 
	}

	public void loadTransTrendData(Object[] model) {
		setTxnsrc((String) model[0]);
		setTerminalId((String) model[1]);
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
		setTotalTranssaction((String) model[5]);
		setApprovalPercentage((String) model[6].toString().replace("%", ""));
		setDeclinePercentage((String) model[7].toString().replace("%", ""));
		setReversalPercentage((String) model[8].toString().replace("%", ""));
		setApprovedCashWdCnt((String) model[9]);
		setApprovedBalInqCnt((String) model[10]);
		setApprovedPurchaseCnt((String) model[11]);
		setApprovedDepositCnt((String) model[12]);
		setApprovedTransferCnt((String) model[13]);
		setApprovedOthersCnt((String) model[14]);
		setDeclinedCashWdCnt((String) model[15]);
		setDeclinedBalInqCnt((String) model[16]);
		setDeclinedPurchaseCnt((String) model[17]);
		setDeclinedDepositCnt((String) model[18]);
		setDeclinedTransferCnt((String) model[19]);
		setDeclinedOthersCnt((String) model[20]);
	}
	
	public void loadPosTxnDetails(Object[] model) {
		setMsgType((String) model[0]);
		setProcessingCode((String) model[1]);
		setTxnType((String) model[2]);
		setTxnsrc((String) model[3]);
		setAcquirer((String) model[4]);
		setTxnDest((String) model[5]);
		setIssuer((String) model[6]);
		setChipIndex((String) model[7]);
		setTrace((String) model[8]);
		setRefNum((String) model[9]);
		setAmount((String) model[10]);
		setLocalDate(getFormattedDate(model[11].toString()));
		setLocalTime((String) model[12]);
		setTransDate(getFormattedDate(model[13].toString()));
		setTransTime((String) model[14]);
		setRespCode((String) model[15]);
		setIstSysDate(getFormattedDateWithTime(model[16].toString()));
		setOrigMsg((String) model[17]);
		setOrigDate(getFormattedDate(model[18].toString()));
		setOrigTrace((String) model[19]);
		setOrigTime((String) model[20]);
		setAuthNum((String) model[21]);
		setTerminalId((String) model[22]);
		setPosTerminalType((String) model[23]);
	}
	
	@Override
	public String toString() {
		return "TransactionListRow [txnsrc=" + txnsrc + ", acquirer=" + acquirer + ", totalApprovalCnt="
				+ totalApprovalCnt + ", totalDeclineCnt=" + totalDeclineCnt + ", totalReversalCnt=" + totalReversalCnt
				+ ", approvalPercentage=" + approvalPercentage + ", declinePercentage=" + declinePercentage
				+ ", reversalPercentage=" + reversalPercentage + ", totalTranssaction=" + totalTranssaction
				+ ", terminalId=" + terminalId + ", transactionDate=" + transactionDate + ", msgType=" + msgType
				+ ", txnDest=" + txnDest + ", issuer=" + issuer + ", respCode=" + respCode + ", respCodeDesc="
				+ respCodeDesc + ", processingCode=" + processingCode + ", processingCodeDesc=" + processingCodeDesc
				+ ", istSysDate=" + istSysDate + ", currCode=" + currCode + ", pan=" + pan
				+ ", approvedTransactionCount=" + approvedTransactionCount + ", rejectedTransactionCount="
				+ rejectedTransactionCount + ", chipIndex=" + chipIndex + ", trace=" + trace + ", refNum=" + refNum
				+ ", amount=" + amount + ", localDate=" + localDate + ", localTime=" + localTime + ", transDate="
				+ transDate + ", transTime=" + transTime + ", txnMonth=" + txnMonth + ", numTxnsPerMonth="
				+ numTxnsPerMonth + ", tps=" + tps + ", businessDecline=" + businessDecline + ", technicalDecline="
				+ technicalDecline + ", declineCategory=" + declineCategory + ", origDate=" + origDate + ", origTrace="
				+ origTrace + ", origTime=" + origTime + ", origMsg=" + origMsg + ", txnType=" + txnType + ", authNum="
				+ authNum + ", approvedCashWdCnt=" + approvedCashWdCnt + ", approvedBalInqCnt=" + approvedBalInqCnt
				+ ", approvedPurchaseCnt=" + approvedPurchaseCnt + ", approvedDepositCnt=" + approvedDepositCnt
				+ ", approvedTransferCnt=" + approvedTransferCnt + ", approvedOthersCnt=" + approvedOthersCnt
				+ ", declinedCashWdCnt=" + declinedCashWdCnt + ", declinedBalInqCnt=" + declinedBalInqCnt
				+ ", declinedPurchaseCnt=" + declinedPurchaseCnt + ", declinedDepositCnt=" + declinedDepositCnt
				+ ", declinedTransferCnt=" + declinedTransferCnt + ", declinedOthersCnt=" + declinedOthersCnt + "]";
	}

	private String getFormattedDate(String dateString) {
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date = inputFormat.parse(dateString);
			
			SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
			return outputFormat.format(date);
			
		} catch(java.text.ParseException e) {
			log.error(e);
			return null;
		}
	}
	
	private String getFormattedDateWithTime(String dateString) {
		return getFormattedDateWithTime(dateString, null, null);
	}
	
	private String getFormattedDateWithTime(String dateString, SimpleDateFormat inputFormat1, SimpleDateFormat outputFormat1) {
		try {
			SimpleDateFormat inputFormat = inputFormat1 != null ? inputFormat1 : new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
			Date date = inputFormat.parse(dateString);
			
			SimpleDateFormat outputFormat = outputFormat1 != null ? outputFormat1 : new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			return outputFormat.format(date);
			
		} catch(java.text.ParseException e) {
			log.error(e);
			return null;
		}
	}

	public String getTotalChipCnt() {
		return totalChipCnt;
	}

	public void setTotalChipCnt(String totalChipCnt) {
		this.totalChipCnt = totalChipCnt;
	}

	public String getTotalNonChipCnt() {
		return totalNonChipCnt;
	}

	public void setTotalNonChipCnt(String totalNonChipCnt) {
		this.totalNonChipCnt = totalNonChipCnt;
	}
	
}
