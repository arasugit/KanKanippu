package com.fis.ist.monitoring.services;

import java.util.List;
import java.util.Map;

import com.fis.ist.common.IListProvider;
import com.fis.ist.monitoring.dao.ISTCommandDAO;

public class ISTInstitutionProvider implements IListProvider {
	
	private String searchListType = "";

	@Override
	public List getList() {
		System.out.println("222 Fetch Institution Id ");
		List recordList = new ISTCommandDAO().getInstitutionId();
		return recordList;
	}

	@Override
	public String getName() {
		return "IST_INSTID_POPUP";
	}

	@Override
	public List getList(Map<String, String> arg0) {
		return null;
	}

	@Override
	public List getListByInstitution(String arg0) {
		return null;
	}

}
