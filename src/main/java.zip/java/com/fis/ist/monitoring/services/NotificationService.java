package com.fis.ist.monitoring.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.NotificationDao;
import com.fis.ist.monitoring.domain.Notification;
import com.fis.ist.monitoring.dto.NotificationDto;

@Service
public class NotificationService {
	@Autowired
	private NotificationDao dao;
	private static final ISTLogger log = ISTLogger.getLogger(NotificationService.class);

	public List<NotificationDto> getNotifications(Notification instance) {
		log.info(" NotificationService getNotifications ");
		List<NotificationDto> list = new ArrayList<>();
		NotificationDto dto = null;
		List<Notification> notifications = dao.findByExample(instance);
		for (Notification notification : notifications) {
			dto = new NotificationDto();
			dto.load(notification);
			list.add(dto);
		}
		log.info(" NotificationService getNotifications Notification List Size :" + list.size());
		return list;
	}
}
