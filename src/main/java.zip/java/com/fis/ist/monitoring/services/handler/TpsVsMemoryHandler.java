package com.fis.ist.monitoring.services.handler;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.TpsVsMemoryDAO;
import com.fis.ist.monitoring.domain.TpsVsMemory;
import com.fis.ist.monitoring.dto.TpsVsMemoryDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class TpsVsMemoryHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(TpsVsMemoryHandler.class);
	private static String reqTypeId = MonitorConstants.TPS_VS_MEM_REQ;
	private static String formAuthId = "TPSVSMEM";
	private int pgsz = -1;

	public TpsVsMemoryHandler() {
		checkMKCEnabled(formAuthId);
	}

	public TpsVsMemoryHandler(String formAuthIdVar) {
		formAuthId = formAuthIdVar;
		reqTypeId = formAuthIdVar;
		checkMKCEnabled(formAuthIdVar);
	}

	public WorkRequest getList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}


	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.TPS_VS_MEM_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.TPS_VS_MEM_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.TPS_VS_MEM_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.TPS_VS_MEM_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.TPS_VS_MEM_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("TpsVsMemoryHandler - Load List ");
		String type = params.get("type");
		if (type.equalsIgnoreCase("CUSTOM")) {
			loadMemory(workRequest, params);

			int customRowsSize = workRequest.getCollections().get(MonitorConstants.TPS_VS_MEM_COL).getRows().size();

			if (customRowsSize == 0)
				workRequest.setLastModified(-4l);

		} else {
			loadMemory(workRequest, params);
			loadTPS(workRequest, params);
			int rowsSize = workRequest.getCollections().get(MonitorConstants.TPS_VS_MEM_COL).getRows().size();
			int rowsTPSSize = workRequest.getCollections().get(MonitorConstants.TPS_COL).getRows().size();
			if (rowsSize == 0 && rowsTPSSize == 0) {
				workRequest.setLastModified(-1l);
			} else if (rowsSize == 0) {
				workRequest.setLastModified(-2l);
			} else if (rowsTPSSize == 0) {
				workRequest.setLastModified(-3l);
			}
		}
	}

	private void loadMemory(WorkRequest workRequest, Map<String, String> params) {
		String fromDate = "";
		String toDate = "";
		String dateFormate = "";
		String type = params.get("type");
		int total = 0;
		boolean ist_export_mem = "Y".equalsIgnoreCase(params.get("ist_export_detail"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}
		List results = new ArrayList();
		if (type.equalsIgnoreCase("CUSTOM")) {
			String fromDateImput = params.get("fromDate");
			String fromDateImput2 = params.get("fromDate");
			String fromTime = params.get("fromTime");
			String toDateImput = params.get("toDate");
			String toTime = params.get("toTime");
			DateFormat outputFormat = null;
			DateFormat inputFormat = null;
			dateFormate = PaymonUtils.DatabaseDateTimeConversionFormat;
			outputFormat = new SimpleDateFormat(PaymonUtils.InputDateTimeConversionFormat);
			inputFormat = new SimpleDateFormat(PaymonUtils.InputDateTimeFormat);
			if (StringUtil.isEmpty(fromTime)) {
				fromDateImput = fromDateImput + " " + "00:00:00";
			} else {
				fromDateImput = fromDateImput + " " + fromTime;
			}

			Date fromDateObj = null;
			Date toDateObj = null;
			try {
				fromDateObj = inputFormat.parse(fromDateImput);
				if (StringUtil.isEmpty(toDateImput)) {
					toDateImput = fromDateImput2;
				}
				if (StringUtil.isEmpty(toTime)) {
					toDateImput = toDateImput + " " + "23:59:59";
				} else
					toDateImput = toDateImput + " " + toTime;

				toDateObj = inputFormat.parse(toDateImput);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				log.error(e);
			}
			fromDate = outputFormat.format(fromDateObj);
			toDate = outputFormat.format(toDateObj);
			long minutes = (toDateObj.getTime() - fromDateObj.getTime()) / 1000;
			if (minutes < 0) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("'Date to & time ' must greater than 'Date from & time'");
				return;
			}
		}

		results = loadMemoryData(type, fromDate, toDate, dateFormate);

		List<TpsVsMemoryDto> workRows = getNewWorkRows(workRequest, uiMetaData);
		TpsVsMemoryDto dto = null;
		Object[] result = null;
		for (int i = 0; i < results.size(); i++) {
			dto = new TpsVsMemoryDto();
			result = (Object[]) results.get(i);
			dto.loadDTO(result, type);
			workRows.add(dto);
		}

		total = results.size();
		if (total == 0) {
			if (type.equalsIgnoreCase("CUSTOM")) {
				workRequest.setLastModified(0L);
			} else {
				workRequest.setLastModified(-2L);
			}
		} else {
			workRequest.setLastModified((long) total);
			if (!ist_export_mem) {
				int defaultPageSize = getDefaultPageSize();
				List<TpsVsMemoryDto> workRowsPage = getNewWorkRowsDTL(workRequest, uiMetaData);
				TpsVsMemoryDto dtoPage = null;
				Object[] resultPage = null;
				for (int i = 0; i < results.size(); i++) {
					if (i >= pageNum * defaultPageSize - defaultPageSize && i < pageNum * defaultPageSize) {

						dtoPage = new TpsVsMemoryDto();
						resultPage = (Object[]) results.get(i);
						dtoPage.loadDTO(resultPage, type);
						workRowsPage.add(dtoPage);
					}
				}
			}
		}
	}

	private void loadTPS(WorkRequest workRequest, Map<String, String> params) {
		List resultsTps = new ArrayList();
		String fromDate = "";
		String toDate = "";
		String dateFormate = "";
		String type = params.get("type");
		if (type.equalsIgnoreCase("CUSTOM")) {

			String fromDateImput = params.get("fromDate");
			String fromDateImput2 = params.get("fromDate");
			String fromTime = params.get("fromTime");
			String toDateImput = params.get("toDate");
			String toTime = params.get("toTime");
			DateFormat outputFormat = null;
			DateFormat inputFormat = null;
			dateFormate = PaymonUtils.DatabaseDateTimeConversionFormat;
			outputFormat = new SimpleDateFormat(PaymonUtils.InputDateTimeConversionFormat);
			inputFormat = new SimpleDateFormat(PaymonUtils.InputDateTimeFormat);
			if (StringUtil.isEmpty(fromTime)) {
				fromDateImput = fromDateImput + " " + "00:00:00";
			} else {
				fromDateImput = fromDateImput + " " + fromTime;
			}

			Date fromDateObj = null;
			Date toDateObj = null;
			try {
				fromDateObj = inputFormat.parse(fromDateImput);
				if (StringUtil.isEmpty(toDateImput)) {
					toDateImput = fromDateImput2;
				}
				if (StringUtil.isEmpty(toTime)) {
					toDateImput = toDateImput + " " + "23:59:59";
				} else
					toDateImput = toDateImput + " " + toTime;

				toDateObj = inputFormat.parse(toDateImput);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				log.error(e);
			}
			fromDate = outputFormat.format(fromDateObj);
			toDate = outputFormat.format(toDateObj);
			long minutes = (toDateObj.getTime() - fromDateObj.getTime()) / 1000;
			if (minutes < 0) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("'Date to & time ' must greater than 'Date from & time'");
				return;
			}
			resultsTps = loadListTPSData(type, fromDate, toDate, dateFormate);

		} else {
			resultsTps = loadListTPSData(type, "", "", "");
		}
		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}
		List<TpsVsMemoryDto> workRowsTps = getNewWorkRowsTPS(workRequest, uiMetaData);
		TpsVsMemoryDto dtoTps = null;
		Object[] resultTps = null;
		for (int i = 0; i < resultsTps.size(); i++) {
			dtoTps = new TpsVsMemoryDto();
			resultTps = (Object[]) resultsTps.get(i);

			dtoTps.loadTPSDTO(resultTps, type);
			workRowsTps.add(dtoTps);
		}
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	public HashMap<String, String> getDBMapping() {
		HashMap<String, String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product", "product");
		return dtoMapping;
	}

	private List<TpsVsMemory> loadMemoryData(String type, String fromDate, String toDate, String dateFromate) {
		log.debug("TpsVsMemoryHandler - Load TpsVsMemory records - loadListData()");

		TpsVsMemoryDAO dao = new TpsVsMemoryDAO();
		if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName()))
			dao.altersession();

		List results = dao.findMemoryData(type, fromDate, toDate, dateFromate, -1);

		return results;
	}

	private List<TpsVsMemory> loadListTPSData(String type, String fromDate, String toDate, String dateFromate) {
		log.debug("TpsVsMemoryHandler - Load TpsVsMemory records - loadListData()");
		TpsVsMemoryDAO dao = new TpsVsMemoryDAO();
		List results = dao.getTpsData(type, fromDate, toDate, dateFromate, -1);

		return results;
	}

	private List<TpsVsMemory> loadMemorytData(String type, String fromDate, String toDate, String dateFromate,
			int pageNum) {
		log.debug("TpsVsMemoryHandler - Load TpsVsMemory records - loadListData()");

		TpsVsMemoryDAO dao = new TpsVsMemoryDAO();
		dao.altersession();
		List results = dao.findMemoryData(type, fromDate, toDate, dateFromate, pageNum);

		return results;
	}

	private List<TpsVsMemoryDto> getNewWorkRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TPS_VS_MEM_COL);
		workCollection.setSectionId(MonitorConstants.TPS_VS_MEM_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TPS_VS_MEM_TAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TpsVsMemoryDto> workRows = new ArrayList<TpsVsMemoryDto>();

		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TPS_VS_MEM_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<TpsVsMemoryDto> getNewWorkRowsTPS(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TPS_COL);
		workCollection.setSectionId(MonitorConstants.TPS_VS_MEM_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TPS_VS_MEM_TAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TpsVsMemoryDto> workRows = new ArrayList<TpsVsMemoryDto>();

		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TPS_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<TpsVsMemoryDto> getNewWorkRowsDTL(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TPS_VS_MEM_DTL_COL);
		workCollection.setSectionId(MonitorConstants.TPS_VS_MEM_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TPS_VS_MEM_TAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TpsVsMemoryDto> workRows = new ArrayList<TpsVsMemoryDto>();

		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TPS_VS_MEM_DTL_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	protected int getDefaultPageSize() {
		if (pgsz != -1)
			return pgsz;
		Integer val = ConfigParams.getInstance().getIntProperty("ist.default_page_size");
		if (val == null || val <= 0)
			val = AppConstants.Default_PageSize;
		pgsz = val;
		return pgsz;
	}
}