package com.fis.ist.monitoring.dto;

public class ATMFaultWiseDto implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Integer count;
	private String statusDescription;
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
}
