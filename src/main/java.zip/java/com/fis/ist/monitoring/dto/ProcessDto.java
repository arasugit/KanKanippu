package com.fis.ist.monitoring.dto;

public class ProcessDto implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
		
	private String processId;
	private String user;
	private String processPriority;
	private String niceValue;
	private String virtualMemorySize;
	private String residentMemorySize;	
	private String sharedMemorySize;
	private String processStatus;
	private String cpuUsagePercent;
	private String memoryUsagePercent;
	private String cpuTimeUsed;
	private String command;
	
	public String getProcessId() {
		return processId;
	}
	
	public void setProcessId(String processId) {
		this.processId = processId;
	}
	
	public String getUser() {
		return user;
	}
	
	public void setUser(String user) {
		this.user = user;
	}
	
	public String getProcessPriority() {
		return processPriority;
	}
	
	public void setProcessPriority(String processPriority) {
		this.processPriority = processPriority;
	}
	
	public String getNiceValue() {
		return niceValue;
	}
	
	public void setNiceValue(String niceValue) {
		this.niceValue = niceValue;
	}
	
	public String getVirtualMemorySize() {
		return virtualMemorySize;
	}
	
	public void setVirtualMemorySize(String virtualMemorySize) {
		this.virtualMemorySize = virtualMemorySize;
	}
	
	public String getResidentMemorySize() {
		return residentMemorySize;
	}
	
	public void setResidentMemorySize(String residentMemorySize) {
		this.residentMemorySize = residentMemorySize;
	}
	
	public String getSharedMemorySize() {
		return sharedMemorySize;
	}
	
	public void setSharedMemorySize(String sharedMemorySize) {
		this.sharedMemorySize = sharedMemorySize;
	}
	
	public String getProcessStatus() {
		return processStatus;
	}
	
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}
	
	public String getCpuUsagePercent() {
		return cpuUsagePercent;
	}
	
	public void setCpuUsagePercent(String cpuUsagePercent) {
		this.cpuUsagePercent = cpuUsagePercent;
	}
	
	public String getMemoryUsagePercent() {
		return memoryUsagePercent;
	}
	
	public void setMemoryUsagePercent(String memoryUsagePercent) {
		this.memoryUsagePercent = memoryUsagePercent;
	}
	
	public String getCpuTimeUsed() {
		return cpuTimeUsed;
	}
	
	public void setCpuTimeUsed(String cpuTimeUsed) {
		this.cpuTimeUsed = cpuTimeUsed;
	}
	
	public String getCommand() {
		return command;
	}
	
	public void setCommand(String command) {
		this.command = command;
	}
}
