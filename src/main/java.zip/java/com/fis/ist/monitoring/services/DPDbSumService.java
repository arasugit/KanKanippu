package com.fis.ist.monitoring.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.services.handler.ATMAvailabilityHandler;
import com.fis.ist.monitoring.services.handler.DPDbSumHandler;
import com.fis.ist.monitoring.services.handler.DPEnCashHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class DPDbSumService extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(DPDbSumService.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;

		DPDbSumHandler dpDbSumHandler = new DPDbSumHandler(MonitorConstants.DPDBSUM);
		
		if (action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = dpDbSumHandler.getDataPointsEnCash(userContext, requestParams);	
		} else {
			log.error("**** DP dbSum : getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}
		return workReq;
	}
}