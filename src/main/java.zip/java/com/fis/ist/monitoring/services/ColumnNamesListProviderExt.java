package com.fis.ist.monitoring.services;

import java.util.List;
import java.util.Map;
import com.fis.ist.common.IListProvider;
import com.fis.ist.monitoring.dao.RetentionConfigDAO;


public class ColumnNamesListProviderExt implements IListProvider {
	
	//Data Retention Config : Column Names List dropdown
	
	@Override
	public List getList(Map<String, String> params){
		List recordList = null;
		String selectedTableName = params.get("selectedTableNameValue");
		
		recordList = new RetentionConfigDAO().getColumnNames(selectedTableName);
		return recordList;
	}
	
	@Override
	public String getName() {
		return "COLUMN_NAMES_LIST";
	}

	@Override
	public List getListByInstitution(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getList() {
		// TODO Auto-generated method stub
		return null;
	}
}