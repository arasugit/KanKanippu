package com.fis.ist.monitoring.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class MonitorAtmCraId implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	private String institutionId; // INSTITUTIONID
	private String craBranch; // CRA_BRANCH
	
	public MonitorAtmCraId() {}
	
	public MonitorAtmCraId (String institutionId, String craBranch) {
		this.institutionId = institutionId;
		this.craBranch = craBranch;
	}
	
	@Column(name="INSTITUTIONID", nullable = false, length = 10)
	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	@Column(name="CRA_BRANCH", nullable = false, length = 50)
	public String getCraBranch() {
		return craBranch;
	}

	public void setCraBranch(String craBranch) {
		this.craBranch = craBranch;
	}
	
	@Override
	public String toString() {
		return "MonitorAtmCraId [institutionId=" + institutionId + ", craBranch=" + craBranch + "]";
	}
}
