package com.fis.ist.monitoring.services.handler;

import static com.fis.ist.common.OracleDaoConstants.EMPTY;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.ATMCassetteCounterDao;
import com.fis.ist.monitoring.domain.ATMCassetteCounter;
import com.fis.ist.monitoring.dto.ATMCassetteCounterDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class ATMCassetteCounterHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(ATMCassetteCounterHandler.class);
	private static String reqTypeId = MonitorConstants.ATM_CASSETTE_COUNTER_REQ;
	private static String formAuthId = MonitorConstants.ATM_CASSETTE_COUNTER_REQ;

	public ATMCassetteCounterHandler() {
		checkMKCEnabled(formAuthId);
	}

	public ATMCassetteCounterHandler(String formAuthIdVar) {
		formAuthId = formAuthIdVar;
		reqTypeId = formAuthIdVar;
		checkMKCEnabled(formAuthIdVar);
	}

	public WorkRequest getATMCassetteCounter(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.ATM_CASSETTE_COUNTER_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.ATM_CASSETTE_COUNTER_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.ATM_CASSETTE_COUNTER_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.ATM_CASSETTE_COUNTER_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.ATM_CASSETTE_COUNTER_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Individual ATM Status  Details");
		String productId = params.get("productId");
		log.debug("productId" + productId);
		String siteId = params.get("siteId");
		log.debug("siteId" + siteId);
		String instId = StringUtils.isNotEmpty(params.get("mon_inst_id"))?params.get("mon_inst_id"):null;
		log.debug("nodinstIdeId" + instId);
		String grpname = StringUtils.isNotEmpty(params.get("mon_atm_grp_name")) ? params.get("mon_atm_grp_name")
				: EMPTY;
		if (grpname != null || grpname != "") {
			grpname = grpname.trim();
		}
		log.debug("grpname" + grpname);
		String unit = StringUtils.isNotEmpty(params.get("mon_atm_unit")) ? params.get("mon_atm_unit") : EMPTY;
		log.debug("unit" + unit);
		String totalReg = params.get("ist_total");
		String pageNum = params.get("pageNum");
		int pNumber = StringUtils.isNotEmpty(pageNum) ? Integer.parseInt(pageNum) : 1;
		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}
		List<String> criteriaList = new ArrayList<>();
		criteriaList.add(instId);
		criteriaList.add(grpname);
		criteriaList.add(unit);
		ATMCassetteCounterDao dao = new ATMCassetteCounterDao();
		Integer total = null;
		List<ATMCassetteCounter> results = null;
		if ("Y".equalsIgnoreCase(totalReg)) {
			total = dao.getCountCassetteCounter(criteriaList.toArray(new String[] {}));
		}
		results = dao.getCassetteCounterBySwDB(pNumber, criteriaList.toArray(new String[] {}));
		if (total != null) {
			total = total != null ? total.intValue() : 0;
			if (total == 0) {
				workRequest.setLastModified((long) -1);
			} else {
				workRequest.setLastModified((long) total);
			}
		}

		ATMCassetteCounterDto cassetteCounterDto = null;
		List<ATMCassetteCounterDto> workRows = getCassetteCounterList(workRequest, uiMetaData);
		if (results != null) {
			for (ATMCassetteCounter cassetteCounter : results) {
				cassetteCounterDto = new ATMCassetteCounterDto();
				cassetteCounterDto.load(cassetteCounter);
				workRows.add(cassetteCounterDto);				
			}			
		}		
		
  }	

	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {
		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();
		String fieldValue = null;
		WorkField currentfield = null;
		currentfield = fields.get("productId");
		fieldValue = params.get("productId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("siteId");
		fieldValue = params.get("siteId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	private List<ATMCassetteCounterDto> getCassetteCounterList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.ATM_CASSETTE_COUNTER_TAB);
		workCollection.setSectionId(MonitorConstants.INDVL_ATM_STATUS_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.ATM_CASSETTE_COUNTER_TAB);
		workRequest.getCollections().put(MonitorConstants.ATM_CASSETTE_COUNTER_COL, workCollection);
		List<ATMCassetteCounterDto> workRows = new ArrayList<ATMCassetteCounterDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.ATM_CASSETTE_COUNTER_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	public HashMap<String, String> getDBMapping() {
		HashMap<String, String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product", "product");
		dtoMapping.put("nodeId", "nodeId");
		return dtoMapping;
	}

}
