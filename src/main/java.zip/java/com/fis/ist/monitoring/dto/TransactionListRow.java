package com.fis.ist.monitoring.dto;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.vo.EditableListRowForSDK;
 

public class TransactionListRow extends EditableListRowForSDK implements Cloneable {

	private static final long serialVersionUID = 1L;

	@Override
	public String getFormKey() {
		// TODO Auto-generated method stub
		return null;
	}
	
	private String txnsrc;
	private String acquirer;
	private String totalApprovalCnt;
	private String totalDeclineCnt;
	private String totalReversalCnt;
	private String approvalPercentage;
	private String declinePercentage;
	private String reversalPercentage;
	private String totalTranssaction;
	private String terminalId;
	private String transactionDate;
	private String txnDest;
	private String issuer;
	private String processingCode;
	private String processingCodeDesc;
	private String pan;
	private String approvedTransactionCount;
	private String rejectedTransactionCount;
	private String businessDecline;
	private String technicalDecline;
	private String approvedCashWdCnt;
	private String approvedBalInqCnt;
	private String approvedPurchaseCnt; 
	private String approvedDepositCnt;
	private String approvedTransferCnt;
	private String approvedOthersCnt;
	private String declinedCashWdCnt;
	private String declinedBalInqCnt;
	private String declinedPurchaseCnt;
	private String declinedDepositCnt;
	private String declinedTransferCnt;
	private String declinedOthersCnt;
	private String posTerminalType;
	
	
	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Object transactionDate) {
		this.transactionDate = PaymonUtils.getFormattedResponseDate(transactionDate);
	}

	public String getTxnsrc() {
		return txnsrc;
	}

	public void setTxnsrc(String txnsrc) {
		this.txnsrc = txnsrc;
	}

	public String getAcquirer() {
		return acquirer;
	}

	public void setAcquirer(String acquirer) {
		this.acquirer = acquirer;
	}

	public String getTotalApprovalCnt() {
		return totalApprovalCnt;
	}

	public void setTotalApprovalCnt(String totalApprovalCnt) {
		this.totalApprovalCnt = totalApprovalCnt;
	}

	public String getTotalDeclineCnt() {
		return totalDeclineCnt;
	}

	public void setTotalDeclineCnt(String totalDeclineCnt) {
		this.totalDeclineCnt = totalDeclineCnt;
	}

	public String getTotalReversalCnt() {
		return totalReversalCnt;
	}

	public void setTotalReversalCnt(String totalReversalCnt) {
		this.totalReversalCnt = totalReversalCnt;
	}

	public String getApprovalPercentage() {
		return approvalPercentage;
	}

	public void setApprovalPercentage(String approvalPercentage) {
		this.approvalPercentage = approvalPercentage;
	}

	public String getDeclinePercentage() {
		return declinePercentage;
	}

	public void setDeclinePercentage(String declinePercentage) {
		this.declinePercentage = declinePercentage;
	}

	public String getReversalPercentage() {
		return reversalPercentage;
	}

	public void setReversalPercentage(String reversalPercentage) {
		this.reversalPercentage = reversalPercentage;
	}

	public String getTotalTranssaction() {
		return totalTranssaction;
	}

	public void setTotalTranssaction(String totalTranssaction) {
		this.totalTranssaction = totalTranssaction;
	}

	public String getTxnDest() {
		return txnDest;
	}

	public void setTxnDest(String txnDest) {
		this.txnDest = txnDest;
	}

	public String getIssuer() {
		return issuer;
	}

	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}

	public String getProcessingCode() {
		return processingCode;
	}

	public void setProcessingCode(String processingCode) {
		this.processingCode = processingCode;
	}

	public String getProcessingCodeDesc() {
		return processingCodeDesc;
	}

	public void setProcessingCodeDesc(String processingCodeDesc) {
		this.processingCodeDesc = processingCodeDesc;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getApprovedTransactionCount() {
		return approvedTransactionCount;
	}

	public void setApprovedTransactionCount(String approvedTransactionCount) {
		this.approvedTransactionCount = approvedTransactionCount;
	}

	public String getRejectedTransactionCount() {
		return rejectedTransactionCount;
	}

	public void setRejectedTransactionCount(String rejectedTransactionCount) {
		this.rejectedTransactionCount = rejectedTransactionCount;
	}
		
	public String getBusinessDecline() {
		return businessDecline;
	}

	public void setBusinessDecline(String businessDecline) {
		this.businessDecline = businessDecline;
	}

	public String getTechnicalDecline() {
		return technicalDecline;
	}

	public void setTechnicalDecline(String technicalDecline) {
		this.technicalDecline = technicalDecline;
	}
	
	public String getApprovedCashWdCnt() {
		return approvedCashWdCnt;
	}

	public void setApprovedCashWdCnt(String approvedCashWdCnt) {
		this.approvedCashWdCnt = approvedCashWdCnt;
	}

	public String getApprovedBalInqCnt() {
		return approvedBalInqCnt;
	}

	public void setApprovedBalInqCnt(String approvedBalInqCnt) {
		this.approvedBalInqCnt = approvedBalInqCnt;
	}

	public String getApprovedPurchaseCnt() {
		return approvedPurchaseCnt;
	}

	public void setApprovedPurchaseCnt(String approvedPurchaseCnt) {
		this.approvedPurchaseCnt = approvedPurchaseCnt;
	}

	public String getApprovedDepositCnt() {
		return approvedDepositCnt;
	}

	public void setApprovedDepositCnt(String approvedDepositCnt) {
		this.approvedDepositCnt = approvedDepositCnt;
	}

	public String getApprovedTransferCnt() {
		return approvedTransferCnt;
	}

	public void setApprovedTransferCnt(String approvedTransferCnt) {
		this.approvedTransferCnt = approvedTransferCnt;
	}

	public String getApprovedOthersCnt() {
		return approvedOthersCnt;
	}

	public void setApprovedOthersCnt(String approvedOthersCnt) {
		this.approvedOthersCnt = approvedOthersCnt;
	}

	public String getDeclinedCashWdCnt() {
		return declinedCashWdCnt;
	}

	public void setDeclinedCashWdCnt(String declinedCashWdCnt) {
		this.declinedCashWdCnt = declinedCashWdCnt;
	}

	public String getDeclinedBalInqCnt() {
		return declinedBalInqCnt;
	}

	public void setDeclinedBalInqCnt(String declinedBalInqCnt) {
		this.declinedBalInqCnt = declinedBalInqCnt;
	}

	public String getDeclinedPurchaseCnt() {
		return declinedPurchaseCnt;
	}

	public void setDeclinedPurchaseCnt(String declinedPurchaseCnt) {
		this.declinedPurchaseCnt = declinedPurchaseCnt;
	}

	public String getDeclinedDepositCnt() {
		return declinedDepositCnt;
	}

	public void setDeclinedDepositCnt(String declinedDepositCnt) {
		this.declinedDepositCnt = declinedDepositCnt;
	}

	public String getDeclinedTransferCnt() {
		return declinedTransferCnt;
	}

	public void setDeclinedTransferCnt(String declinedTransferCnt) {
		this.declinedTransferCnt = declinedTransferCnt;
	}

	public String getDeclinedOthersCnt() {
		return declinedOthersCnt;
	}

	public void setDeclinedOthersCnt(String declinedOthersCnt) {
		this.declinedOthersCnt = declinedOthersCnt;
	}
	
	public String getPosTerminalType() {
		return posTerminalType;
	}

	public void setPosTerminalType(String posTerminalType) {
		this.posTerminalType = posTerminalType;
	}

	public void load(Object[] model) {
		setTxnsrc((String) model[0]);
		setAcquirer((String) model[1]);
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
		setTotalTranssaction((String) model[5]);
		setApprovalPercentage((String) model[6]);
		setDeclinePercentage((String) model[7]);
		setReversalPercentage((String) model[8]);
	}

	public void loadByRespCode(Object[] model) {
		setTxnsrc((String) model[0]);
		setAcquirer((String) model[1]);
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
		setTotalTranssaction((String) model[5]);
		setApprovalPercentage((String) model[6]);
		setDeclinePercentage((String) model[7]);
		setReversalPercentage((String) model[8]);
	}

	public void loadTerminalTopComp(Object[] model) {
		setTerminalId((String) model[0]);
		setTotalTranssaction((String) model[1]);
		setTransactionDate(model[2]);
	}

	public void loadTxnStsAcqComp(Object[] model) {
		setTotalTranssaction((String) model[0]);
		setTransactionDate(model[1]);
	}
	
	public void loadTxnStsByProcCode(Object[] model) {
		setProcessingCode((String) model[0]);
		setTotalTranssaction((String) model[1]);

	}
	
	public void loadTxnStsTerminal(Object[] model) {
		setTerminalId((String) model[0]);
		setProcessingCode((String) model[1]);
		setTotalTranssaction((String) model[2]);
	}

	public void loadTxnStsHighVol(Object[] model) {
		setPan((String) model[0]);
		setTotalTranssaction((String) model[1]);
	}

	// To load Top and Least 25 Transacting Terminals
	public void loadTxnTerminals(Object[] model) {
		setTerminalId((String) model[0]);
		setTotalTranssaction((String) model[1]);
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
	}

	// To load Host Transaction Statistics
	public void loadHostTxns(Object[] model) {
		setTxnDest((String) model[0]);
		setIssuer((String) model[1]);
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
		setTotalTranssaction((String) model[5]);
		setApprovalPercentage((String) model[6].toString().replace("%", ""));
		setDeclinePercentage((String) model[7].toString().replace("%", ""));
		setReversalPercentage((String) model[8].toString().replace("%", ""));
	}

	// To load Successful/ Rejected Transactions Count
	public void loadTxns(Object[] model) {
		setTxnDest((String) model[0]);
		setIssuer((String) model[1]);
		setApprovedTransactionCount((String) model[2]);
		setRejectedTransactionCount((String) model[3]);
		setBusinessDecline((String) model[4]);
		setTechnicalDecline((String) model[5]);
	}
	
	public void loadTxnsIssuer(Object[] model) {
		setTxnsrc((String) model[0]);
		setAcquirer((String) model[1]);
		setTxnDest((String) model[2]);
		setApprovedTransactionCount((String) model[3]);
	}
	
	public void loadFallbackTxns(Object[] model) {
		setTxnsrc((String) model[0]);
		setAcquirer((String) model[1]);
		setTerminalId((String) model[2]);
		setApprovedTransactionCount((String) model[3]);
	}

	public void loadTxnType(Object[] model) {
		setProcessingCode((String) model[0]);
		setTotalTranssaction(((String) model[1]));
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
	 
	}

	public void loadTransTrendData(Object[] model) {
		setTxnsrc((String) model[0]);
		setTerminalId((String) model[1]);
		setTotalApprovalCnt((String) model[2]);
		setTotalDeclineCnt((String) model[3]);
		setTotalReversalCnt((String) model[4]);
		setTotalTranssaction((String) model[5]);
		setApprovalPercentage((String) model[6].toString().replace("%", ""));
		setDeclinePercentage((String) model[7].toString().replace("%", ""));
		setReversalPercentage((String) model[8].toString().replace("%", ""));
		setApprovedCashWdCnt((String) model[9]);
		setApprovedBalInqCnt((String) model[10]);
		setApprovedPurchaseCnt((String) model[11]);
		setApprovedDepositCnt((String) model[12]);
		setApprovedTransferCnt((String) model[13]);
		setApprovedOthersCnt((String) model[14]);
		setDeclinedCashWdCnt((String) model[15]);
		setDeclinedBalInqCnt((String) model[16]);
		setDeclinedPurchaseCnt((String) model[17]);
		setDeclinedDepositCnt((String) model[18]);
		setDeclinedTransferCnt((String) model[19]);
		setDeclinedOthersCnt((String) model[20]);
	}
}
