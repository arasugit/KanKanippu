package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.services.MonitorConfigService;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.DateTimeRequestDto;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.monitoring.dto.TransactionStatisticsListItem;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class TransactionStatsLogsHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(TransactionStatsLogsHandler.class);
	private static String reqTypeId = MonitorConstants.TRANS_STATS_LOGS_REQ;
	private static String formAuthId = "TXNSTSLOG";

	public TransactionStatsLogsHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getTransactions(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}


	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.TRANS_STATS_LOGS_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.TRANS_STATS_LOGS_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.TRANS_STATS_LOGS_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.TRANS_STATS_LOGS_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.TRANS_STATS_LOGS_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}


	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load TransactionStatsProcCodeHandler ....");

		String screenType = params.get("screenType");
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		String terminalId = params.get("termId");
		String ist_inst_Id = params.get("ist_inst_Id");
		String ist_search_by = params.get("ist_search_by");

		TransactionsDAO dao = new TransactionsDAO();

		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;
		List results = null;

		DateTimeRequestDto dateTimeRequest = PaymonUtils.getRequestedDateTime(params);
		Map<String, String> procCodes = dao.getProcessingCode("", "PCODE_LIST");

		if (needs_total) {
			total = dao.getTransStatsLogsCount(screenType, dateTimeRequest.getFormattedFromDate(),
					dateTimeRequest.getFormattedToDate(), dateTimeRequest.getFromDbDateFormat(),
					dateTimeRequest.getToDbDateFormat(), ist_search_by, ist_inst_Id, terminalId);
		}

		results = dao.getTransStatsLogs(screenType, dateTimeRequest.getFormattedFromDate(),
				dateTimeRequest.getFormattedToDate(), dateTimeRequest.getFromDbDateFormat(),
				dateTimeRequest.getToDbDateFormat(), ist_search_by, ist_inst_Id, terminalId, pageNum);

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		MonitorConfigService configService = new MonitorConfigService();
		List<String> businessDeclineList = configService.getDeclineRespCodes(dao, MonitorConstants.BD_RESP_CODE_LIST);
		List<String> technicalDeclineList = configService.getDeclineRespCodes(dao, MonitorConstants.TD_RESP_CODE_LIST);
		
		TransactionStatisticsListItem dto = null;
		Object[] result = null;
		String pcode="";
		List<TransactionStatisticsListItem> workRows = getTransactionList(workRequest, uiMetaData);
		List<TransactionStatisticsListItem> respCodesAndDesc = configService.getResponseCodesAndDesc(dao);
		
		for (int i = 0; i < results.size(); i++) {
			dto = new TransactionStatisticsListItem();
			result = (Object[]) results.get(i);
			dto.loadTxnStsATMPOS(result);
			setDeclineCategory(businessDeclineList, technicalDeclineList, dto);
			setRespCodeDesc(respCodesAndDesc, dto);
			try {
				if (dto.getProcessingCode().length() < 6)
					dto.setProcessingCode(
							("000000" + dto.getProcessingCode()).substring(dto.getProcessingCode().length()));
				pcode = String.valueOf((Integer.parseInt(dto.getProcessingCode()) / 10000));
				dto.setProcessingCodeDesc(procCodes.get(pcode));
			} catch (Exception e) {
				dto.setProcessingCodeDesc("");
			}
			workRows.add(dto);
		}
	}
	
	private void setDeclineCategory(List<String> businessDeclineList, List<String> technicalDeclineList, TransactionStatisticsListItem dto)
	{
		String declineCategory = PaymonUtils.getDeclineCategoryByRespCode(businessDeclineList, technicalDeclineList, dto.getRespCode());
		dto.setDeclineCategory(declineCategory);
	}
	
	private void setRespCodeDesc(List<TransactionStatisticsListItem> respCodesAndDesc, TransactionStatisticsListItem dto)
	{
		String respCodeDesc = PaymonUtils.getRespDescByCode(respCodesAndDesc, dto.getRespCode());
		dto.setRespCodeDesc(respCodeDesc);
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		return validateFields(fieldDataMap);
	}

	private List<TransactionStatisticsListItem> getTransactionList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TRANS_STATS_LOGS_COL);
		workCollection.setSectionId(MonitorConstants.TRANS_STATS_LOGS_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TRANS_STATS_LOGS_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionStatisticsListItem> workRows = new ArrayList<TransactionStatisticsListItem>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TRANS_STATS_LOGS_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}
