package com.fis.ist.monitoring.dto;

import java.util.Date;

public class TxnAuthDenialDto {

	private Date tranDate;
	private String txnDate;
	private Integer denialCount;
	public Date getTranDate() {
		return tranDate;
	}
	public void setTranDate(Date tranDate) {
		this.tranDate = tranDate;
	}
	public String getTxnDate() {
		return txnDate;
	}
	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}
	public Integer getDenialCount() {
		return denialCount;
	}
	public void setDenialCount(Integer denialCount) {
		this.denialCount = denialCount;
	}
	
	
}
