package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.services.MonitorConfigService;
import com.fis.ist.monitoring.dao.TransactionDetailsDAO;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.monitoring.dto.TransactionStatisticsListItem;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class TransactionStatsIssuerHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(TransactionStatsIssuerHandler.class);
	private static String reqTypeId = MonitorConstants.TRANS_STATS_ISSUER_REQ;
	private static String formAuthId = "TXNISS_REQ";

	public TransactionStatsIssuerHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getTrasactionStats(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	
	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.TRANS_STATS_ISSUER_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.TRANS_STATS_ISSUER_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.TRANS_STATS_ISSUER_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.TRANS_STATS_ISSUER_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.TRANS_STATS_ISSUER_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load TransactionStatsIssuerHandler ...");
		TransactionsDAO dao = new TransactionsDAO();
		UIMetaData uiMetaData = null;
		String tabType = params.get("screenType");
		String isDetailReq = params.get("isDetailReq");

		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List terminalList = dao.getAcquirerTxnSRC("ISTSWT", "ISSUING_LIST");
		List<String> acqList = new ArrayList<>();
		List<String> txnSrcList = new ArrayList<>();
		final int defaultPageNum = -1;

		for (Iterator iterator = terminalList.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();
			acqList.add((String) object[1]);
			txnSrcList.add((String) object[0]);
		}

		List recordList = dao.getIssuerTransactionStats(acqList, txnSrcList, tabType, defaultPageNum);

		if (recordList.size() == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) recordList.size());
		}

		TransactionListRow dto = null;
		Object[] result = null;
		List<TransactionListRow> workRows = getTransactionList(workRequest, uiMetaData);
		for (int i = 0; i < recordList.size(); i++) {
			dto = new TransactionListRow();
			result = (Object[]) recordList.get(i);
			dto.load(result);
			workRows.add(dto);
		}

		if ("true".equalsIgnoreCase(isDetailReq)) {
			log.debug("Calling getTransactionDetailRecord ...");
			getTransactionDetailRecord(workRequest, uiMetaData, params);
		}
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();
		return validateFields(fieldDataMap);
	}

	private List<TransactionListRow> getTransactionList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TRANS_STATS_ISSUER_COL);
		workCollection.setSectionId(MonitorConstants.TRANS_STATS_ISSUER_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TRANS_STATS_ISSUER_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionListRow> workRows = new ArrayList<TransactionListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TRANS_STATS_ISSUER_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<TransactionStatisticsListItem> getTransactionDetail(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TRANS_DTL_COL);
		workCollection.setSectionId(MonitorConstants.TRANS_STATS_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TRANS_STATS_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionStatisticsListItem> workRows = new ArrayList<TransactionStatisticsListItem>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TRANS_DTL_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private void getTransactionDetailRecord(WorkRequest workRequest, UIMetaData uiMetaData,
			Map<String, String> params) {

		String isDetailReq = params.get("isDetailReq");
		if (!"true".equalsIgnoreCase(isDetailReq))
			return;

		String screenType = params.get("screenType");
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		boolean ist_export_detail = "Y".equalsIgnoreCase(params.get("ist_export_detail"));
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;
		TransactionsDAO dao = new TransactionsDAO();
		TransactionDetailsDAO txnDetailDao = new TransactionDetailsDAO();
		String eventName = params.get("eventName");
		String txnSrcIss = params.get("txnSrcIss");
		String txnStatus = "";
		String txnSrc = "";
		String txnAcq = "";
		try {
			txnStatus = eventName.split(" ")[0];
			txnSrc = txnSrcIss.split("-")[0];
			txnAcq = txnSrcIss.split("-")[1];
		} catch (Exception e) {
		}

		List<String> acqListDTL = new ArrayList<>();
		acqListDTL.add(txnAcq);
		List<String> txnSrcListDTL = new ArrayList<>();
		txnSrcListDTL.add(txnSrc);
		List txnDetails = null;

		if (!ist_export_detail) {
			if (!needs_total) {
				txnDetails = txnDetailDao.getAcquirerTransactionDetails(acqListDTL, txnSrcListDTL, screenType,
						txnStatus, pageNum);
			} else if (needs_total) {
				total = txnDetailDao.getAcquirerTransactionDetailsCount(acqListDTL, txnSrcListDTL, screenType,
						txnStatus);
				txnDetails = txnDetailDao.getAcquirerTransactionDetails(acqListDTL, txnSrcListDTL, screenType,
						txnStatus, pageNum);
			}
		} else {
			txnDetails = txnDetailDao.getAcquirerTransactionDetails(acqListDTL, txnSrcListDTL, screenType, txnStatus,
					pageNum);
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		TransactionStatisticsListItem dto = null;
		Object[] result = null;

		List<TransactionStatisticsListItem> workRows = getTransactionDetail(workRequest, uiMetaData);

		if (null != txnDetails) {
			MonitorConfigService configService = new MonitorConfigService();
			log.debug("Getting business decline list from db");
			List<String> businessDeclineList = configService.getDeclineRespCodes(dao,
					MonitorConstants.BD_RESP_CODE_LIST);

			log.debug("Getting technical decline list from db");
			List<String> technicalDeclineList = configService.getDeclineRespCodes(dao,
					MonitorConstants.TD_RESP_CODE_LIST);

			log.debug("Getting response code and desc from db");
			List<TransactionStatisticsListItem> respCodesAndDesc = configService.getResponseCodesAndDesc(dao);
			
			for (int i = 0; i < txnDetails.size(); i++) {
				dto = new TransactionStatisticsListItem();
				result = (Object[]) txnDetails.get(i);
				dto.loadTxnDetails(result);
				setDeclineCategory(businessDeclineList, technicalDeclineList, dto);
				setRespCodeDesc(respCodesAndDesc, dto);
				workRows.add(dto);
			}
		}

		log.debug("Setting Issuer Transaction Details is completed.");
	}

	private void setDeclineCategory(List<String> businessDeclineList, List<String> technicalDeclineList,
			TransactionStatisticsListItem dto) {
		String declineCategory = PaymonUtils.getDeclineCategoryByRespCode(businessDeclineList, technicalDeclineList,
				dto.getRespCode());
		dto.setDeclineCategory(declineCategory);
	}
	
	private void setRespCodeDesc(List<TransactionStatisticsListItem> respCodesAndDesc, TransactionStatisticsListItem dto)
	{
		String respCodeDesc = PaymonUtils.getRespDescByCode(respCodesAndDesc, dto.getRespCode());
		dto.setRespCodeDesc(respCodeDesc);
	}
}
