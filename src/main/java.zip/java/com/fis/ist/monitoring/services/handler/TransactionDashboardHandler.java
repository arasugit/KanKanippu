package com.fis.ist.monitoring.services.handler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.TransactionDetailsDAO;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.TransactionDashboardDto;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.monitoring.dto.TransactionStatisticsListItem;
import com.fis.ist.monitoring.dto.TxnAuthDenialDto;
import com.fis.ist.monitoring.dto.TxnCompletionTimeDto;
import com.fis.ist.monitoring.dto.TxnFailuresDto;
import com.fis.ist.monitoring.dto.TxnPeakVolumesDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class TransactionDashboardHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(TransactionDashboardHandler.class);
	private static String reqTypeId = MonitorConstants.TXN_DASHBOARD_REQ;
	private static String formAuthId = "TXNDASH";

	public TransactionDashboardHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getDashboardWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load TransactionDashboardHandler ....");

		TransactionsDAO dao = new TransactionsDAO();
		UIMetaData uiMetaData = null;

		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		String product = params.get("product") != null ? params.get("product") : "";
		String nodeId = params.get("nodeId") != null ? params.get("nodeId") : "*";
		log.debug("Site-NodeID Info : " + "nodeId = " + nodeId + " productId = " + product);
		String isDetailReq = params.get("isDetailReq");
		String chartType = params.get("chartType");
		String status = params.get("status");
		String txnDate = params.get("txnDate");
		String hour = params.get("hour");
		String compTime = params.get("compTime");
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));

		SimpleDateFormat dayDateFormat = new SimpleDateFormat("dd-MMM");
		SimpleDateFormat sdf = new SimpleDateFormat(PaymonUtils.InputDateFormat);
		SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat txnDateFormat = new SimpleDateFormat(PaymonUtils.InputDateConversionFormat);
		Date fromDate = null;
		String currentDate = null;
		try {
			fromDate = sdf.parse(sdf.format(PaymonUtils.convertLocalDateTimeToDate(LocalDateTime.now())));
			currentDate = inputFormat.format(PaymonUtils.convertLocalDateTimeToDate(LocalDateTime.now()));
		} catch (ParseException e1) {
			log.error("Parse exception!! " + e1.getMessage());
		}

		if ("AUTHDENIAL".equals(chartType) && StringUtils.isNotEmpty(txnDate)) {
			int currentYear = LocalDateTime.now().getYear();
			txnDate = txnDate + "-" + currentYear;
			try {
				currentDate = inputFormat.format(txnDateFormat.parse(txnDate));
			} catch (ParseException e) {
				log.error("Parse exception!! " + e.getMessage());
			}
		}

		if ("true".equals(isDetailReq)) {
			Integer startTime = null, endTime = null;

			if ("COMPTIME".equals(chartType) && StringUtils.isNotEmpty(compTime)) {
				if ("1 Sec".equals(compTime)) {
					startTime = 0;
					endTime = 1000;
				} else if ("1 Min".equals(compTime)) {
					startTime = 1000;
					endTime = 60000;
				} else if ("2 Min".equals(compTime)) {
					startTime = 60000;
					endTime = 60000 * 2;
				} else if ("3 Min".equals(compTime)) {
					startTime = 60000 * 2;
					endTime = 60000 * 3;
				} else if ("4 Min".equals(compTime)) {
					startTime = 60000 * 3;
					endTime = 60000 * 4;
				} else if ("5 Min".equals(compTime)) {
					startTime = 60000 * 4;
					endTime = 60000 * 5;
				}
			}

			TransactionDetailsDAO txnDetailDao = new TransactionDetailsDAO();
			List recordList = null;
			int total = 0;
			if (!needs_total) {
				recordList = txnDetailDao.getTransactionDashboardDetails(currentDate, chartType, pageNum, hour,
						startTime, endTime, status);
			} else {
				total = txnDetailDao.getTransactionDashboardDetailsCount(currentDate, chartType, hour, startTime,
						endTime, status);
				recordList = txnDetailDao.getTransactionDashboardDetails(currentDate, chartType, pageNum, hour,
						startTime, endTime, status);
			}
			
			TransactionStatisticsListItem dto = null;
			Object[] result = null;
			List<TransactionStatisticsListItem> workRows = getTransactionDetailList(workRequest, uiMetaData);
			for (int i = 0; i < recordList.size(); i++) {
				dto = new TransactionStatisticsListItem();
				result = (Object[]) recordList.get(i);
				dto.loadTxnDetails(result, true);
				workRows.add(dto);
			}
			if (total == 0) {
				workRequest.setLastModified(-1L);
			} else {
				workRequest.setLastModified((long) total);
			}
		} else {

			TransactionDashboardDto dashboardDto = new TransactionDashboardDto();
			List<TxnAuthDenialDto> authDenialList = null;
			List<TxnPeakVolumesDto> peakVolumesList = null;
			List<TxnCompletionTimeDto> completionTimeList = null;
			List<TxnFailuresDto> failureList = null;

			// Auth Denial List
			authDenialList = dao.getAuthDenialList(inputFormat.format(fromDate));
			List<TxnAuthDenialDto> modifiedAuthDenialCountList = new ArrayList<>();

			authDenialList.forEach(x -> {
				TxnAuthDenialDto dto = new TxnAuthDenialDto();
				dto.setTxnDate(dayDateFormat.format(x.getTranDate()));
				dto.setDenialCount(x.getDenialCount());
				modifiedAuthDenialCountList.add(dto);
			});

			dashboardDto.setAuthDenialList(modifiedAuthDenialCountList);

			// Peak Volumes List
			peakVolumesList = dao.getPeakVolumesList(inputFormat.format(fromDate));
			List<TxnPeakVolumesDto> modifiedPeakVolCountList = new ArrayList<>();

			peakVolumesList.forEach(x -> {
				TxnPeakVolumesDto dto = new TxnPeakVolumesDto();
				dto.setHours(x.getHours());
				dto.setTranCount(x.getTranCount());
				modifiedPeakVolCountList.add(dto);
			});

			dashboardDto.setPeakVolumesList(modifiedPeakVolCountList);

			// Transaction Failures List
			failureList = dao.getTxnFailuresList(inputFormat.format(fromDate));
			List<TxnFailuresDto> modifiedFailureCountList = new ArrayList<>();

			failureList.forEach(x -> {
				TxnFailuresDto dto = new TxnFailuresDto();
				dto.setSuccessCount(x.getSuccessCount());
				dto.setFailureCount(x.getFailureCount());
				modifiedFailureCountList.add(dto);
			});

			dashboardDto.setFailureList(modifiedFailureCountList);

			// Transaction Completion time List
			completionTimeList = dao.getTxnCompletionTimeList(inputFormat.format(fromDate));
			List<TxnCompletionTimeDto> modifiedCompletionCountList = new ArrayList<>();

			completionTimeList.forEach(x -> {
				TxnCompletionTimeDto dto = new TxnCompletionTimeDto();
				dto.setSecCount(x.getSecCount());
				dto.setMin1Count(x.getMin1Count());
				dto.setMin2Count(x.getMin2Count());
				dto.setMin3Count(x.getMin3Count());
				dto.setMin4Count(x.getMin4Count());
				dto.setMin5Count(x.getMin5Count());
				modifiedCompletionCountList.add(dto);
			});

			dashboardDto.setCompletionTimeList(modifiedCompletionCountList);

			List<TransactionDashboardDto> workRows = prepareWorkCollection(workRequest, uiMetaData);
			workRows.add(dashboardDto);
		}
	}

	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		return validateFields(fieldDataMap);
	}

	private List<TransactionDashboardDto> prepareWorkCollection(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TXN_DASHBOARD_COL);
		workCollection.setSectionId(MonitorConstants.TXN_DASHBOARD_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TXN_DASHBOARD_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionDashboardDto> workRows = new ArrayList<TransactionDashboardDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TXN_DASHBOARD_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.TXN_DASHBOARD_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.TXN_DASHBOARD_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.TXN_DASHBOARD_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.TXN_DASHBOARD_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.TXN_DASHBOARD_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}
	
	private List<TransactionStatisticsListItem> getTransactionDetailList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TXNDASH_DTL_COL);
		workCollection.setSectionId(MonitorConstants.TXN_DASHBOARD_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TXN_DASHBOARD_SEC);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionStatisticsListItem> workRows = new ArrayList<TransactionStatisticsListItem>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TXNDASH_DTL_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}
