package com.fis.ist.monitoring.cfg;

public class PaymonConfigParamNames {
	public static final String PROTECTED_DIRECTORY_PATH = "ist.protected_directory_path";
	public static final String CONTEXT_ROOT = "ist.context_root";
	public static final String WEBAPP_HOSTNAME = "ist.webapp_hostname";
	public static final String GUI_VERSION = "ist.gui_version";
}
