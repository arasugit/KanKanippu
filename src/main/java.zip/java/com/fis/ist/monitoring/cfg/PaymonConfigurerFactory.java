package com.fis.ist.monitoring.cfg;

import com.fis.ist.log.ISTLogger;
import java.util.Properties;

public class PaymonConfigurerFactory {

	private static final ISTLogger log = ISTLogger.getLogger(PaymonConfigurerFactory.class);
	private Properties props = null;
	private PaymonConfigurerFactory()	{}
	private static volatile PaymonConfigurerFactory instance = new PaymonConfigurerFactory();
	private PaymonConfigurer cfg = null;
	public static synchronized PaymonConfigurerFactory getInstance()
	{
		return instance;
	}
	public void setProperties(Properties p) 
	{
		props = (Properties)p.clone();
		log.trace("got properties: " + props);
	}
	public synchronized PaymonConfigurer make()
	{
		if (cfg == null)
		{
			log.trace("creating configurer");
			cfg = new PaymonConfigurer(props);
		}
		return cfg;
	}


}
