package com.fis.ist.monitoring.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.dto.CortexCardDashboardDto;
import com.fis.ist.spring.HTTPRequestGetter;

public class CortexDAO extends MonitorBaseDAO<Integer, Integer> {

	private static final ISTLogger log = ISTLogger.getLogger(CortexDAO.class);

	public List<CortexCardDashboardDto> getCardDashboardData(String fromDate, String toDate, String fromDateFromate,
			String toDateFromate) {

		log.debug("CortexDAO - selecting Card Dashboard Data from db");

		try {
			String query = SqlQueryProvider.getDBSqlQuery("CTX_CARD_DASH");

			query = setCardDashboardQueryFilter(query);

			Query queryObject = getSession().createSQLQuery(query).addScalar("LogDate", StandardBasicTypes.STRING)
					.addScalar("ActiveCount", StandardBasicTypes.INTEGER)
					.addScalar("InactiveCount", StandardBasicTypes.INTEGER);

			setCardDashboardQueryParams(queryObject, fromDate, toDate, fromDateFromate, toDateFromate);

			return (List<CortexCardDashboardDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(CortexCardDashboardDto.class)).list();
		} catch (RuntimeException re) {
			log.error("getCardDashboardData - Query Fails", re);
			throw re;
		}
	}

	private static String setCardDashboardQueryFilter(String query) {
		StringBuffer queryBuffer = new StringBuffer(" where ");
		queryBuffer.append(" product = :productId and ");
		queryBuffer.append(" site_id = :siteId and ");
		queryBuffer.append(" node_name = :nodeName and ");

		if (PaymonUtils.isOracleDb())
			queryBuffer.append(
					" logdate between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) ");
		else if (PaymonUtils.isPostgressDb())
			queryBuffer.append(
					" logdate between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) ");

		query = query.replaceAll("FILTER_QUERY", queryBuffer.toString());
		return query;
	}

	private static void setCardDashboardQueryParams(Query queryObject, String fromDate, String toDate,
			String fromDateFromate, String toDateFromate) {

		HttpServletRequest request = HTTPRequestGetter.getRequest();
		String productId = (String) request.getSession(false).getAttribute("product_id");
		String siteId = (String) request.getSession(false).getAttribute("site_id");
		String nodeName = (String) request.getSession(false).getAttribute("node_name");

		if (PaymonUtils.isNullOrEmpty(siteId)) {
			log.warn("Request is missing site_id value.");
			siteId = "0";
		}

		queryObject.setParameter("productId", productId);
		queryObject.setParameter("siteId", Integer.valueOf(siteId));
		queryObject.setParameter("nodeName", nodeName);
		queryObject.setParameter("fromDate", fromDate);
		queryObject.setParameter("toDate", toDate);
		queryObject.setParameter("fromDateFormate", fromDateFromate);
		queryObject.setParameter("toDateFormate", toDateFromate);
	}

	@Override
	public Class<Integer> getEntityClass() {
		return null;
	}
}
