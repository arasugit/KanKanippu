package com.fis.ist.monitoring.dto;

import java.io.Serializable;

//import javafx.beans.NamedArg;

/**
 * <p>A convenience class to represent name-value pairs.</p>
 */
public class Pair<K,V> implements Serializable{

	/**
    * Key of this <code>Pair</code>.
    */
   private K key;

   /**
    * Gets the key for this pair.
    * @return key for this pair
    */
   public K getKey() { return key; }

   /**
    * Value of this this <code>Pair</code>.
    */
   private V value;

   /**
    * Gets the value for this pair.
    * @return value for this pair
    */
   public V getValue() { return value; }

   public Pair() {
   }
   
   /**
    * Creates a new pair
    * @param key The key for this pair
    * @param value The value to use for this pair
    */
/*   public Pair(@NamedArg("key") K key, @NamedArg("value") V value) {
       this.key = key;
       this.value = value;
   }*/

   /**
    * <p><code>String</code> representation of this
    * <code>Pair</code>.</p>
    *
    * <p>The default name/value delimiter '=' is always used.</p>
    *
    *  @return <code>String</code> representation of this <code>Pair</code>
    */
   @Override
   public String toString() {
       return key + "=" + value;
   }

   /**
    * <p>Generate a hash code for this <code>Pair</code>.</p>
    *
    * <p>The hash code is calculated using both the name and
    * the value of the <code>Pair</code>.</p>
    *
    * @return hash code for this <code>Pair</code>
    */
   @Override
   public int hashCode() {
       // name's hashCode is multiplied by an arbitrary prime number (13)
       // in order to make sure there is a difference in the hashCode between
       // these two parameters:
       //  name: a  value: aa
       //  name: aa value: a
       return key.hashCode() * 13 + (value == null ? 0 : value.hashCode());
   }
}