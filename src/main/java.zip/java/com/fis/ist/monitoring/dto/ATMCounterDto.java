package com.fis.ist.monitoring.dto;

import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.domain.MonAtmCounter;

public class ATMCounterDto implements java.io.Serializable {
	
	private static final long serialVersionUID = 646182332543081904L;
	
	
	private String institutionId;
	private String groupName;
	private Long unit;
	private String terminalId;
	private Long cardsRetain;
	private Long filmsRetain;
	private Long afterHoursDep;
	private String resetTime;
	
	public ATMCounterDto(){}
	
	public String getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Long getUnit() {
		return unit;
	}
	public void setUnit(Long unit) {
		this.unit = unit;
	}
	public String getTerminalId() {
		return terminalId;
	}
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}
	public Long getCardsRetain() {
		return cardsRetain;
	}
	public void setCardsRetain(Long cardsRetain) {
		this.cardsRetain = cardsRetain;
	}
	public Long getFilmsRetain() {
		return filmsRetain;
	}
	public void setFilmsRetain(Long filmsRetain) {
		this.filmsRetain = filmsRetain;
	}
	public Long getAfterHoursDept() {
		return afterHoursDep;
	}
	public void setAfterHoursDep(Long afterHoursDep) {
		this.afterHoursDep = afterHoursDep;
	}
	
	public String getResetTime() {
		return resetTime;
	}
	public void setResetTime(String resetTime) {
		this.resetTime = PaymonUtils.getFormattedResponseDateTime(resetTime);
	}
	
	public void load(MonAtmCounter atmCounter){
		setInstitutionId(atmCounter.getInstitutionId());
		setGroupName(atmCounter.getGroupName());
		setUnit(atmCounter.getUnit());
		setTerminalId(atmCounter.getTerminalId());
		setCardsRetain(atmCounter.getCardsRetain());
		setFilmsRetain(atmCounter.getFilmsRetain());
		setAfterHoursDep(atmCounter.getAfterHoursDept());
		setResetTime(atmCounter.getResetTime());		
	}
}
