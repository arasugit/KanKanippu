package com.fis.ist.monitoring.domain;

public class TerminalsByBranch implements java.io.Serializable {
   
	private static final long serialVersionUID = 3257073331899229475L;
	private String branch;	
	private String upPercentage;
	private String downPercentage;
	
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getUpPercentage() {
		return upPercentage;
	}
	public void setUpPercentage(String upPercentage) {
		this.upPercentage = upPercentage;
	}
	public String getDownPercentage() {
		return downPercentage;
	}
	public void setDownPercentage(String downPercentage) {
		this.downPercentage = downPercentage;
	}
	@Override
	public String toString() {
		return "TerminalsByBranch [branch=" + branch + ", upPercentage=" + upPercentage + ", downPercentage="
				+ downPercentage + "]";
	}	
}
