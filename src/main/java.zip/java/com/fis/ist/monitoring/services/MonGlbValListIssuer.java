package com.fis.ist.monitoring.services;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.fis.ist.common.IListProvider;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.ISTCommandDAO;
import com.fis.ist.monitoring.dao.MonGlbValDAO;
import com.fis.ist.spring.HTTPRequestGetter;


public class MonGlbValListIssuer implements IListProvider {
	
	private static final ISTLogger log = ISTLogger.getLogger(MonGlbValListIssuer.class);

	
	@Override
	public List getList() {		
		
		HttpServletRequest request = HTTPRequestGetter.getRequest();
	 	String productId = (String) request.getSession(false).getAttribute("product_id");
	 	
	 	log.debug("insde MonGlbValListAcquirer - Getting List of Issuer from MonGlobalValue ");
		List recordList = new MonGlbValDAO().getAcquirIssuerList("ISSUING_LIST", productId);
		return recordList;
	}

	@Override
	public String getName() {
		return "GLBVALUE_ISSUER_LIST";
	}


	@Override
	public List getList(Map<String, String> arg0) {
		return null;
	}


	@Override
	public List getListByInstitution(String arg0) {
		return null;
	}
	
}
