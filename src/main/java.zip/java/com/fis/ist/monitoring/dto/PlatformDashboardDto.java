package com.fis.ist.monitoring.dto;

import java.util.List;

public class PlatformDashboardDto implements java.io.Serializable {
private static final long serialVersionUID = 1L;
	
	private List<FileSystemUsageDto> fileSystemUsages;
	private List<ProcessDto> runningProcesses;
	private String fileSystemUsageLogDate;
	private String runningProcessLogDate;
	private MemoryStatusDto memoryStatus;
	private MemoryStatusDto swapSpaceStatus;

	public List<FileSystemUsageDto> getFileSystemUsages() {
		return fileSystemUsages;
	}
	
	public void setFileSystemUsages(List<FileSystemUsageDto> fileSystemUsages) {
		this.fileSystemUsages = fileSystemUsages;
	}
	
	public List<ProcessDto> getRunningProcesses() {
		return runningProcesses;
	}
	
	public void setRunningProcesses(List<ProcessDto> runningProcesses) {
		this.runningProcesses = runningProcesses;
	}
	
	public String getFileSystemUsageLogDate() {
		return fileSystemUsageLogDate;
	}
	
	public void setFileSystemUsageLogDate(String fileSystemUsageLogDate) {
		this.fileSystemUsageLogDate = fileSystemUsageLogDate;
	}
	
	public String getRunningProcessLogDate() {
		return runningProcessLogDate;
	}
	
	public void setRunningProcessLogDate(String runningProcessLogDate) {
		this.runningProcessLogDate = runningProcessLogDate;
	}
	
	public MemoryStatusDto getMemoryStatus() {
		return memoryStatus;
	}
	
	public void setMemoryStatus(MemoryStatusDto memoryStatus) {
		this.memoryStatus = memoryStatus;
	}
	
	public MemoryStatusDto getSwapSpaceStatus() {
		return swapSpaceStatus;
	}
	
	public void setSwapSpaceStatus(MemoryStatusDto swapSpaceStatus) {
		this.swapSpaceStatus = swapSpaceStatus;
	}
}
