package com.fis.ist.monitoring.dto;

import com.fis.ist.monitoring.common.PaymonUtils;

public class CortexCardDashboardDto implements java.io.Serializable {
private static final long serialVersionUID = 1L;
	
	private String logDate;
	private Integer activeCount;
	private Integer inactiveCount;

	public String getLogDate() {
		return logDate;
	}
	
	public void setLogDate(Object logDate) {
		this.logDate = PaymonUtils.getFormattedResponseDateTime(logDate);
	}
	
	public Integer getActiveCount() {
		return activeCount;
	}
	
	public void setActiveCount(Integer activeCount) {
		this.activeCount = activeCount;
	}
	
	public Integer getInactiveCount() {
		return inactiveCount;
	}
	
	public void setInactiveCount(Integer inactiveCount) {
		this.inactiveCount = inactiveCount;
	}
}
