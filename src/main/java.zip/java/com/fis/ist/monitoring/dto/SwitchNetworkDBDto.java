package com.fis.ist.monitoring.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SwitchNetworkDBDto implements java.io.Serializable {
	
	private static final long serialVersionUID = 6803023989652998245L;	
	
	private Integer recordCount;
	private String recordTypeOf;
	
	private String tskCmdPermanent;
	private String tskCmdTemp;
	private Integer countPerm;
	private Integer countTemp;
	private String tskCmdPermanentShortDesc;
	private String tskCmdTempShortDesc;
	
	private String binStatusUp;
	private String binStatusDown;
	private Integer binStatusUpCount;
	private Integer binStatusDownCount;
	
	private String instId;
	private Integer binId;
	private String statusByInstId;
	
	private String dbUp;
	private String dbDown;
	private Integer dbUpCount;
	private Integer dbDownCount;
	
	private String traceDebug;
	private String traceInfo;
	private String traceFatal;
	private String traceError;
	private Integer traceDebugCount;
	private Integer traceInfoCount;
	private Integer traceFatalCount;
	private Integer traceErrorCount;
	
	private String[] portField3Array;
	private Integer[] portField3ArrayCount;
	
	private String[] traceLevelArray;
	private Integer[] traceLevelArrayCount;
	
	private String[] binStateInstId;
	private Integer[] binStateBinId;
	private String[] binStateStatus;
	
	private String fileName;
	private Integer fileNameCount;
	private String debugLevel;
	
	private String[] fileNameArr;
	private Integer[] fileNameCountArr;
	private String[] debugLevelArr;
	
	private String resourceResult;
	private String[] resourcesArray;
	private Integer[] resourcesArrayCount;
	
	private String alloactedBasicConfigs;
	private String[] alloactedBasicConfigsArray;
	private Integer[] alloactedBasicConfigsArrayCount;
	
	public Integer getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}
	public String getRecordTypeOf() {
		return recordTypeOf;
	}
	public void setRecordTypeOf(String recordTypeOf) {
		this.recordTypeOf = recordTypeOf;
	}
	public Integer getCountPerm() {
		return countPerm;
	}
	public void setCountPerm(Integer countPerm) {
		this.countPerm = countPerm;
	}
	public Integer getCountTemp() {
		return countTemp;
	}
	public void setCountTemp(Integer countTemp) {
		this.countTemp = countTemp;
	}
	public String getTskCmdPermanent() {
		return tskCmdPermanent;
	}
	public void setTskCmdPermanent(String tskCmdPermanent) {
		this.tskCmdPermanent = tskCmdPermanent;
	}
	public String getTskCmdTemp() {
		return tskCmdTemp;
	}
	public void setTskCmdTemp(String tskCmdTemp) {
		this.tskCmdTemp = tskCmdTemp;
	}
	public String getTskCmdPermanentShortDesc() {
		return tskCmdPermanentShortDesc;
	}
	public void setTskCmdPermanentShortDesc(String tskCmdPermanentShortDesc) {
		this.tskCmdPermanentShortDesc = tskCmdPermanentShortDesc;
	}
	public String getTskCmdTempShortDesc() {
		return tskCmdTempShortDesc;
	}
	public void setTskCmdTempShortDesc(String tskCmdTempShortDesc) {
		this.tskCmdTempShortDesc = tskCmdTempShortDesc;
	}
	public String getBinStatusUp() {
		return binStatusUp;
	}
	public void setBinStatusUp(String binStatusUp) {
		this.binStatusUp = binStatusUp;
	}
	public String getBinStatusDown() {
		return binStatusDown;
	}
	public void setBinStatusDown(String binStatusDown) {
		this.binStatusDown = binStatusDown;
	}
	public Integer getBinStatusUpCount() {
		return binStatusUpCount;
	}
	public void setBinStatusUpCount(Integer binStatusUpCount) {
		this.binStatusUpCount = binStatusUpCount;
	}
	public Integer getBinStatusDownCount() {
		return binStatusDownCount;
	}
	public void setBinStatusDownCount(Integer binStatusDownCount) {
		this.binStatusDownCount = binStatusDownCount;
	}
	public String getTraceDebug() {
		return traceDebug;
	}
	public void setTraceDebug(String traceDebug) {
		this.traceDebug = traceDebug;
	}
	public String getTraceInfo() {
		return traceInfo;
	}
	public void setTraceInfo(String traceInfo) {
		this.traceInfo = traceInfo;
	}
	public String getTraceFatal() {
		return traceFatal;
	}
	public void setTraceFatal(String traceFatal) {
		this.traceFatal = traceFatal;
	}
	public String getTraceError() {
		return traceError;
	}
	public void setTraceError(String traceError) {
		this.traceError = traceError;
	}
	public Integer getTraceDebugCount() {
		return traceDebugCount;
	}
	public void setTraceDebugCount(Integer traceDebugCount) {
		this.traceDebugCount = traceDebugCount;
	}
	public Integer getTraceInfoCount() {
		return traceInfoCount;
	}
	public void setTraceInfoCount(Integer traceInfoCount) {
		this.traceInfoCount = traceInfoCount;
	}
	public Integer getTraceFatalCount() {
		return traceFatalCount;
	}
	public void setTraceFatalCount(Integer traceFatalCount) {
		this.traceFatalCount = traceFatalCount;
	}
	public Integer getTraceErrorCount() {
		return traceErrorCount;
	}
	public void setTraceErrorCount(Integer traceErrorCount) {
		this.traceErrorCount = traceErrorCount;
	}
	public String getDbUp() {
		return dbUp;
	}
	public void setDbUp(String dbUp) {
		this.dbUp = dbUp;
	}
	public String getDbDown() {
		return dbDown;
	}
	public void setDbDown(String dbDown) {
		this.dbDown = dbDown;
	}
	public Integer getDbUpCount() {
		return dbUpCount;
	}
	public void setDbUpCount(Integer dbUpCount) {
		this.dbUpCount = dbUpCount;
	}
	public Integer getDbDownCount() {
		return dbDownCount;
	}
	public void setDbDownCount(Integer dbDownCount) {
		this.dbDownCount = dbDownCount;
	}	
	public String[] getPortField3Array() {
		return portField3Array;
	}
	public void setPortField3Array(String[] portField3Array) {
		this.portField3Array = portField3Array;
	}
	public Integer[] getPortField3ArrayCount() {
		return portField3ArrayCount;
	}
	public void setPortField3ArrayCount(Integer[] portField3ArrayCount) {
		this.portField3ArrayCount = portField3ArrayCount;
	}
	public String[] getTraceLevelArray() {
		return traceLevelArray;
	}
	public void setTraceLevelArray(String[] traceLevelArray) {
		this.traceLevelArray = traceLevelArray;
	}
	public Integer[] getTraceLevelArrayCount() {
		return traceLevelArrayCount;
	}
	public void setTraceLevelArrayCount(Integer[] traceLevelArrayCount) {
		this.traceLevelArrayCount = traceLevelArrayCount;
	}
	public String getInstId() {
		return instId;
	}
	public void setInstId(String instId) {
		this.instId = instId;
	}
	public Integer getBinId() {
		return binId;
	}
	public void setBinId(Integer binId) {
		this.binId = binId;
	}
	public String getStatusByInstId() {
		return statusByInstId;
	}
	public void setStatusByInstId(String statusByInstId) {
		this.statusByInstId = statusByInstId;
	}	
	public String[] getBinStateInstId() {
		return binStateInstId;
	}
	public void setBinStateInstId(String[] binStateInstId) {
		this.binStateInstId = binStateInstId;
	}
	public Integer[] getBinStateBinId() {
		return binStateBinId;
	}
	public void setBinStateBinId(Integer[] binStateBinId) {
		this.binStateBinId = binStateBinId;
	}
	public String[] getBinStateStatus() {
		return binStateStatus;
	}
	public void setBinStateStatus(String[] binStateStatus) {
		this.binStateStatus = binStateStatus;
	}
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Integer getFileNameCount() {
		return fileNameCount;
	}
	public void setFileNameCount(Integer fileNameCount) {
		this.fileNameCount = fileNameCount;
	}
	public String getDebugLevel() {
		return debugLevel;
	}
	public void setDebugLevel(String debugLevel) {
		this.debugLevel = debugLevel;
	}
	public String[] getFileNameArr() {
		return fileNameArr;
	}
	public void setFileNameArr(String[] fileNameArr) {
		this.fileNameArr = fileNameArr;
	}
	public Integer[] getFileNameCountArr() {
		return fileNameCountArr;
	}
	public void setFileNameCountArr(Integer[] fileNameCountArr) {
		this.fileNameCountArr = fileNameCountArr;
	}
	public String[] getDebugLevelArr() {
		return debugLevelArr;
	}
	public void setDebugLevelArr(String[] debugLevelArr) {
		this.debugLevelArr = debugLevelArr;
	}
	public String getResourceResult() {
		return resourceResult;
	}
	public void setResourceResult(String resourceResult) {
		this.resourceResult = resourceResult;
	}
	public String[] getResourcesArray() {
		return resourcesArray;
	}
	public void setResourcesArray(String[] resourcesArray) {
		this.resourcesArray = resourcesArray;
	}
	public Integer[] getResourcesArrayCount() {
		return resourcesArrayCount;
	}
	public void setResourcesArrayCount(Integer[] resourcesArrayCount) {
		this.resourcesArrayCount = resourcesArrayCount;
	}
	public String getAlloactedBasicConfigs() {
		return alloactedBasicConfigs;
	}
	public void setAlloactedBasicConfigs(String alloactedBasicConfigs) {
		this.alloactedBasicConfigs = alloactedBasicConfigs;
	}
	public String[] getAlloactedBasicConfigsArray() {
		return alloactedBasicConfigsArray;
	}
	public void setAlloactedBasicConfigsArray(String[] alloactedBasicConfigsArray) {
		this.alloactedBasicConfigsArray = alloactedBasicConfigsArray;
	}
	public Integer[] getAlloactedBasicConfigsArrayCount() {
		return alloactedBasicConfigsArrayCount;
	}
	public void setAlloactedBasicConfigsArrayCoujt(Integer[] alloactedBasicConfigsArrayCount) {
		this.alloactedBasicConfigsArrayCount = alloactedBasicConfigsArrayCount;
	}
	public void loadTaskCommandTypes(List<SwitchNetworkDBDto> siteDetails) {
		
		setTskCmdPermanent("");
		setCountPerm(0);
		setTskCmdPermanentShortDesc("");
		setTskCmdTemp("");
		setCountTemp(0);
		setTskCmdTempShortDesc("");
		
		for (SwitchNetworkDBDto row : siteDetails) {
			
			if(row.getRecordTypeOf().equalsIgnoreCase("permanent")) {
				setTskCmdPermanent("Permanent");
				setCountPerm(row.getRecordCount());
				setTskCmdPermanentShortDesc("Perm ");
			}
			
			if(row.getRecordTypeOf().equalsIgnoreCase("temporary")) {
				setTskCmdTemp("Temporary");
				setCountTemp(row.getRecordCount());
				setTskCmdTempShortDesc("Temp ");
			}
		}
	}
	
	public void loadBinStatusTypes(List<SwitchNetworkDBDto> siteDetails) {
			
		setBinStatusUp("");
		setBinStatusDown("");
		setBinStatusUpCount(0);
		setBinStatusDownCount(0);
		
		for (SwitchNetworkDBDto row : siteDetails) {
			
			if(row.getRecordTypeOf().equalsIgnoreCase("up")) {
				setBinStatusUp("Up");
				setBinStatusUpCount(row.getRecordCount());
			}
			
			if(row.getRecordTypeOf().equalsIgnoreCase("down")) {
				setBinStatusDown("Down");
				setBinStatusDownCount(row.getRecordCount());
			}
		}
	}
	
	public void loadDBDetails(List<SwitchNetworkDBDto> siteDetails) {
		setDbUp("");
		setDbDown("");
		
		int upCount = 0;
		int downCount = 0;
		
		setDbUpCount(upCount);
		setDbDownCount(downCount);
		
		for (SwitchNetworkDBDto row : siteDetails) {
			
			if(row.getRecordTypeOf().equalsIgnoreCase("up")) {
				setDbUp("Up");
				upCount += row.getRecordCount();
			} else if(row.getRecordTypeOf().contains("up")) {
				setDbUp("Up");
				//setDbUpCount(row.getRecordCount());
				upCount += row.getRecordCount();
			}
			
			if(row.getRecordTypeOf().equalsIgnoreCase("down")) {
				setDbDown("Down");
				downCount += row.getRecordCount();
			} else if(row.getRecordTypeOf().contains("down")) {
				setDbDown("Down");
				downCount += row.getRecordCount();
			}
		}
		
		setDbUpCount(upCount);
		setDbDownCount(downCount);
	}
	
	public void loadPortDetails(List<SwitchNetworkDBDto> siteDetails) {
		portField3Array = new String[8];
		portField3ArrayCount = new Integer[8];
		int recordCount = 0;
		
		for(int count=0; count<siteDetails.size(); count++) {
			SwitchNetworkDBDto listOne = siteDetails.get(count);
			
			if(listOne.getRecordTypeOf() != null ) {
				if(count < siteDetails.size()) {
					portField3Array[recordCount] = listOne.getRecordTypeOf();
					portField3ArrayCount[recordCount] = listOne.getRecordCount(); 	
					recordCount++;
				}
			}
		}		
	}
	
	public void loadTraceLevelDetails(List<SwitchNetworkDBDto> siteDetails) {
		traceLevelArray = new String[4];
		traceLevelArrayCount = new Integer[4];
		int recordCount = 0;
		
		for(int count=0; count<siteDetails.size(); count++) {
			SwitchNetworkDBDto listOne = siteDetails.get(count);
			
			if(listOne.getRecordTypeOf() != null ) {
				if(count < siteDetails.size()) {
					traceLevelArray[recordCount] = listOne.getRecordTypeOf();
					traceLevelArrayCount[recordCount] = listOne.getRecordCount(); 	
					recordCount++;
				}
			}
		}	
	} 
	
	public void loadBinStatusTypesByInstId(List<SwitchNetworkDBDto> siteDetails) {
		
		int recordCount = 0;
		
		binStateInstId = new String[siteDetails.size()];
		binStateBinId = new Integer[siteDetails.size()];
		binStateStatus = new String[siteDetails.size()];
		
		for(int count=0; count<siteDetails.size(); count++) {
			SwitchNetworkDBDto listOne = siteDetails.get(count);
			
			binStateInstId[recordCount] = listOne.getInstId();
			binStateBinId[recordCount] = listOne.getBinId();
			binStateStatus[recordCount] = listOne.getStatusByInstId();
			recordCount++;
		}
	}
	
	public void debugLevelByFileNames(List<SwitchNetworkDBDto> siteDetails) {
		int recordCount = 0;
		
		fileNameArr = new String[siteDetails.size()];
		fileNameCountArr = new Integer[siteDetails.size()];
		debugLevelArr = new String[siteDetails.size()];
		
		for(int count=0; count<siteDetails.size(); count++) {
			SwitchNetworkDBDto listOne = siteDetails.get(count);
		
			fileNameArr[recordCount] = listOne.getFileName();
			fileNameCountArr[recordCount] = listOne.getFileNameCount();
			debugLevelArr[recordCount] = listOne.getDebugLevel();
			recordCount++;
		}
	}
	
	public void resourceUsedInfo(List<SwitchNetworkDBDto> siteDetails) {
		try {
			
			SwitchNetworkDBDto listOne = null;
			String commandOutput = "";
			
			List<Integer> listOfInt = new ArrayList<Integer>();
			List<String> listOfChars = new ArrayList<String>();
			listOfChars.add("Mail Boxes");
			listOfChars.add("Ports");
			listOfChars.add("Memory Buffers");
			listOfChars.add("System Queues (x25)");
			listOfChars.add("Events");
			listOfChars.add("Dropped Messages");
			
			for(int count=0; count<siteDetails.size(); count++) {
				if(siteDetails.get(count) != null) {
					listOne = new SwitchNetworkDBDto();
					listOne = siteDetails.get(count);
					
					if(listOne != null && listOne.getResourceResult() != null) {
						commandOutput = listOne.getResourceResult();
						break;
					}
				}
			}

			if(commandOutput != null || !commandOutput.equalsIgnoreCase("")) {
				Scanner scanner1 = new Scanner(commandOutput); 
				
				int needed = 0;
				int wordCount = 0;
				String wordOne = "";
				
				for(int count=0; count<listOfChars.size(); count++) {
					String word1 = (String) listOfChars.get(count);
					String word2 = "";
					
					if(commandOutput.indexOf(word1) > 0) {
						wordCount = commandOutput.indexOf(word1);
						wordOne = commandOutput.substring(wordCount, (wordCount+25));
						
						scanner1 = new Scanner(wordOne); 
						scanner1.useDelimiter(" ");
						
						while (scanner1.hasNext()) {
							word2 = scanner1.next();
							if(!word2.equalsIgnoreCase("")) {}
								
							if(!word2.equals("")) {
								try {
									needed = Integer.parseInt(word2); 
									listOfInt.add(needed);
									break;
								} catch (NumberFormatException e) {
									continue;
								}
							}
						}
					}
				}
				
				resourcesArray = new String[listOfChars.size()];
				resourcesArrayCount = new Integer[listOfChars.size()];
				
				if(listOfChars.size() > 0) {
					for(int count=0; count<listOfChars.size(); count++) {
						resourcesArray[count] = (String)listOfChars.get(count);
					}
				}
				
				if(listOfInt.size() > 0) {
					for(int count=0; count<listOfInt.size(); count++) {
						resourcesArrayCount[count] = (Integer) listOfInt.get(count);
					}
				}				
			} 		
			
		} catch(Exception exe) {
			System.out.println("Issues " + exe.getMessage());
		}
	}
	
	public void allocatedBasicsConfigurations(List<SwitchNetworkDBDto> siteDetails) {
		try {
			
			String commandOutput = "";
			SwitchNetworkDBDto listOne = null;
			List<String> alloactedBasicConfigsArrayList = new ArrayList<String>();
			List<Integer> alloactedBasicConfigsArrayCountList = new ArrayList<Integer>();
			
			for(int count=0; count<siteDetails.size(); count++) {
				if(siteDetails.get(count) != null) {
					listOne = new SwitchNetworkDBDto();
					listOne = siteDetails.get(count);
					
					if(listOne != null && listOne.getAlloactedBasicConfigs() != null) {
						commandOutput = listOne.getAlloactedBasicConfigs();
						break;
					}
				}
			}
			
			Scanner scanner1 = new Scanner(commandOutput); 
			scanner1.useDelimiter("\n");
			
			String word1 = "";
			String word2 = "";
			String word3 = "";
			String keyString = "";
				
			int counting = 0;
			int valueInt = 0;
			
			while (scanner1.hasNext()) {
				word1 = scanner1.next();
				
				Scanner scanner2 =  new Scanner(word1); 
				scanner2.useDelimiter(":");
								
				while (scanner2.hasNext()) {
					word2 = scanner2.next();
					if(word2.startsWith("Allocated")) {
						keyString = word2;
						word3 = scanner2.next();
						valueInt = Integer.parseInt(word3.trim());
						//System.out.println(keyString + " ==> " + word3 );
						if(keyString.contains("Allocated ")) {
							keyString = keyString.replace("Allocated ", "");
						} 
						// System.out.println(keyString + " ==> " + word3 );
						
						alloactedBasicConfigsArrayList.add(keyString);
						alloactedBasicConfigsArrayCountList.add(valueInt);
						
					}
				}
				counting++;
			}
			
			alloactedBasicConfigsArray = new String[alloactedBasicConfigsArrayList.size()];
			alloactedBasicConfigsArrayCount = new Integer[alloactedBasicConfigsArrayCountList.size()];
			
			for(int count=0; count<alloactedBasicConfigsArrayList.size(); count++) {
				keyString = alloactedBasicConfigsArrayList.get(count);
				alloactedBasicConfigsArray[count] = keyString;
				
				valueInt = alloactedBasicConfigsArrayCountList.get(count);
				alloactedBasicConfigsArrayCount[count] = valueInt;
			}			
		} catch(Exception exe) {
			System.out.println("Issues " + exe.getMessage());
		}
	}
		
		
}
