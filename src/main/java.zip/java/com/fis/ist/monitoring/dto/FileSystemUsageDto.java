package com.fis.ist.monitoring.dto;

public class FileSystemUsageDto implements java.io.Serializable {
private static final long serialVersionUID = 1L;
	
	private String fileSystem;
	private String size;
	private String usedSize;
	private String availableSize;
	private String usedPercent;
	private String mountedOn;

	public String getFileSystem() {
		return fileSystem;
	}
	
	public void setFileSystem(String fileSystem) {
		this.fileSystem = fileSystem;
	}
	
	public String getSize() {
		return size;
	}
	
	public void setSize(String size) {
		this.size = size;
	}
	
	public String getUsedSize() {
		return usedSize;
	}
	
	public void setUsedSize(String usedSize) {
		this.usedSize = usedSize;
	}
	
	public String getAvailableSize() {
		return availableSize;
	}
	
	public void setAvailableSize(String availableSize) {
		this.availableSize = availableSize;
	}
	
	public String getUsedPercent() {
		return usedPercent;
	}
	
	public void setUsedPercent(String usedPercent) {
		this.usedPercent = usedPercent;
	}
	
	public String getMountedOn() {
		return mountedOn;
	}
	
	public void setMountedOn(String mountedOn) {
		this.mountedOn = mountedOn;
	}
}
