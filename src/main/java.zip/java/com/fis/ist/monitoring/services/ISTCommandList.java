package com.fis.ist.monitoring.services;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.audit.FormAudit;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.customProject.services.handler.ISTCommandListHandler;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

public class ISTCommandList extends CRUDSubService
{
    private static final ISTLogger log = ISTLogger.getLogger(ISTCommandList.class);
   	public WorkRequest getService
		(
			UserContext userContext,
			String requestType,
			String action,	
		   	Map<String, String>requestParams
		) throws Exception
	{
   		
   		String searchListType = requestParams.get("type"); 
   		
   		HttpServletRequest request = HTTPRequestGetter.getRequest();
	 	String productId = (String) request.getSession(false).getAttribute("product_id");
	 	String nodeName = (String) request.getSession(false).getAttribute("node_name");
	 		 	
   		requestParams.put("product", productId == null ? "" : productId);
   		requestParams.put("nodeId", nodeName == null ? "*" : nodeName);
   		
   		if(productId.equals("ISTCLR") || productId.equals("ISTMAS")) {
   			requestParams.put("nodeId", "*");
   		}
   		   		   		
   		log.debug("Product Id" + " : " + productId + ", Node Id/Name" + " : " + nodeName + " & By Loading ISTCommandList - getService() : " + requestType + " :" + action + " : " +  requestParams); 
   		
		WorkRequest workReq = null; 
		ISTCommandListHandler ddh = new ISTCommandListHandler();

		if (action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = ddh.getTSKCMD(userContext, requestParams);
		} else if (AppConstants.MKC_ACTION_PENDING_REQ.equals(action)) {
			workReq = ddh.mkcSubmittedList(userContext, requestParams);
		} else if (AppConstants.MKC_ACTION_REWORK_REQ.equals(action)) {
			workReq = ddh.mkcReworkList(userContext, requestParams);
		} else {
			log.error("**** Task Command List Page (TSKCMD) List: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}

	public WorkRequest setService(UserContext userContext, String requestType, String action, WorkRequest workRequest)
			throws Exception {
		FormAuditHandler ah = new FormAuditHandler();
		FormAudit handle = ah.beginEditableListAudit(userContext, requestType, action, workRequest,CustomConstants.SWITCH_SUBSYSTEM);
   		WorkRequest workReq = new WorkRequest();
   		ISTCommandListHandler ddh = new ISTCommandListHandler();
   		if(action.compareTo(CustomConstants.ACTION_INSERT) == 0){
   			workReq = ddh.getDataForAdd(userContext,workRequest);
   		}else if(action.compareTo(CustomConstants.ACTION_SINGLE_BATCH_SAVE) == 0){   				
   			workReq = null;
   		}else if(action.compareTo(AppConstants.MKC_ACTION_BATCH_SAVE) == 0){   				
   			workReq = ddh.saveBatchByChecker(userContext,workRequest,setPermissions());
   		}else{
   			log.error("**** Task Command List (TSKCMD) List: setService() inbound...unknown request type");
   			throw new Exception("Unknown request type");
   		}
        ah.saveEditableListAudit(handle, workReq);
   		return workReq;
	}
}