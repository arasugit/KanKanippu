package com.fis.ist.monitoring.dto;

import java.util.Date;

public class IncidentCountByPriorityDto implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	private String priority;
	private Integer count;
	private String fromDate;
	private String toDate;
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
}
