package com.fis.ist.monitoring.dao;

import static com.fis.ist.common.OracleDaoConstants.AMOUNT;
import static com.fis.ist.common.OracleDaoConstants.COUNT;
import static com.fis.ist.common.OracleDaoConstants.CRITERIA_GROUP_NAME;
import static com.fis.ist.common.OracleDaoConstants.CRITERIA_INSTITUTION;
import static com.fis.ist.common.OracleDaoConstants.CRITERIA_UNIT;
import static com.fis.ist.common.OracleDaoConstants.CURRENCY;
import static com.fis.ist.common.OracleDaoConstants.DEPRECATION;
import static com.fis.ist.common.OracleDaoConstants.EMPTY;
import static com.fis.ist.common.OracleDaoConstants.GROUP_NAME;
import static com.fis.ist.common.OracleDaoConstants.INSTITUTION_ID;
import static com.fis.ist.common.OracleDaoConstants.PREVIOUS_AMOUNT;
import static com.fis.ist.common.OracleDaoConstants.PREVIOUS_COUNT;
import static com.fis.ist.common.OracleDaoConstants.RAWTYPES;
import static com.fis.ist.common.OracleDaoConstants.RESET_TIME;
import static com.fis.ist.common.OracleDaoConstants.TYPE;
import static com.fis.ist.common.OracleDaoConstants.UNCHECKED;
import static com.fis.ist.common.OracleDaoConstants.UNIT;

import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.ATMTotals;

@SuppressWarnings({ RAWTYPES, UNCHECKED, DEPRECATION })
public class ATMTotalsDao extends MonitorBaseDAO<ATMTotals, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(ATMTotalsDao.class);
	private static final String QUERY_PREFIX = "prefix";
	private static final String QUERY_SUFFIX = "suffix";
	private static final String ATMTOT_REQ_COUNT = "ATMTOT_REQ_COUNT";
	private static final String ATMTOT_REQ = "ATMTOT_REQ";

	public List<ATMTotals> getATMTotalsBySwDB(int pageNum, String... atms) {
		log.debug("Entering getATMTotalsBySwDB in ATMTotalsDao");
		List<ATMTotals> atmTotalsList = null;
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery(ATMTOT_REQ);
			StringBuilder sb = new StringBuilder(queryString);	
			if(atms[0]!=null) {
				sb.append(CRITERIA_INSTITUTION);
			}
			if (!atms[1].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_GROUP_NAME);
			}
			if (!atms[2].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_UNIT);
			}
			String actualBaseQuery = sb.toString();
			sb.setLength(0);

			sb.append(SqlQueryProvider.manipulatingPrefixSuffixforATMTabs(QUERY_PREFIX, ATMTOT_REQ))
					.append(actualBaseQuery)
					.append(SqlQueryProvider.manipulatingPrefixSuffixforATMTabs(QUERY_SUFFIX, ATMTOT_REQ));

			int startSize = 0;
			int endSize = 0;

			int pgsz = getDefaultPageSize();
			if (pageNum > 1) {
				startSize = ((pageNum * pgsz) - pgsz);
				endSize = pageNum * pgsz;
			} else {
				startSize = 1;
				endSize = pgsz;
			}
			int paramIndex = 0;

			Query queryObject = getSession().createSQLQuery(sb.toString())
					.addScalar(INSTITUTION_ID, StandardBasicTypes.STRING)
					.addScalar(GROUP_NAME, StandardBasicTypes.STRING).addScalar(UNIT, StandardBasicTypes.LONG)
					.addScalar(TYPE, StandardBasicTypes.STRING).addScalar(CURRENCY, StandardBasicTypes.LONG)
					.addScalar(COUNT, StandardBasicTypes.LONG).addScalar(AMOUNT, StandardBasicTypes.LONG)
					.addScalar(RESET_TIME, StandardBasicTypes.STRING).addScalar(PREVIOUS_COUNT, StandardBasicTypes.LONG)
					.addScalar(PREVIOUS_AMOUNT, StandardBasicTypes.LONG);
			if (atms[0] != null) {
				queryObject.setParameter(++paramIndex, atms[0]);
			}
			if (!atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, atms[1]);
			}
			if (!atms[2].equalsIgnoreCase(EMPTY) && atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));
			} else if (!atms[2].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));

			}
			queryObject.setParameter(++paramIndex, endSize);
			queryObject.setParameter(++paramIndex, startSize);
			atmTotalsList = (List<ATMTotals>) queryObject
					.setResultTransformer(Transformers.aliasToBean(ATMTotals.class)).list();
		} catch (RuntimeException re) {
			log.error("Error While finding List of ATM Totals", re);
			throw re;
		}
		log.debug("Exiting getATMTotalsBySwDB in ATMTotalsDao");
		return atmTotalsList;

	}

	public Integer getATMTotalsCount(String... atms) {
		log.debug("Entering getATMTotalsCount in ATMTotalsDao");

		Integer count=null;
		try 
		{			
			StringBuilder sb = new StringBuilder(SqlQueryProvider.getDBSqlQuery(ATMTOT_REQ_COUNT));
			if (atms[0] != null) {
				sb.append(CRITERIA_INSTITUTION);
			}
			if (atms[1] != null && !atms[1].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_GROUP_NAME);
			}
			if (atms[2] != null && !atms[2].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_UNIT);
			}
			Query queryObject = getSession().createSQLQuery(sb.toString()).addScalar(COUNT, StandardBasicTypes.INTEGER);
			int paramIndex = 0;
			if (atms[0] != null) {
				queryObject.setParameter(++paramIndex, atms[0]);
			}
			if (!atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, atms[1]);
			}
			if (!atms[2].equalsIgnoreCase(EMPTY) && atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));
			} else if (!atms[2].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));
			}
			count = queryObject.uniqueResult() != null ? (Integer) queryObject.uniqueResult() : 0;

		} catch (RuntimeException re) {
			log.error("Error While finding total number of ATM Totals records", re);
			throw re;
		}
		log.debug("Exiting getATMTotalsCount in ATMTotalsDao");
		return count;

	}

	public Class<ATMTotals> getEntityClass() {
		return ATMTotals.class;
	}

}
