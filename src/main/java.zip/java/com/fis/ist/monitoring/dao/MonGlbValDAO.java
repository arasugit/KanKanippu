package com.fis.ist.monitoring.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.MonGlobalValue;
import com.fis.ist.spring.HTTPRequestGetter;

@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class MonGlbValDAO extends MonitorBaseDAO<MonGlobalValue, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(MonGlbValDAO.class);

	public List<String> getMonGlobValueList() {
		log.debug("Inside MonGlValDAO - getMonGlobValueList");
		return null;
	}

	public Integer getTotalByExample(MonGlobalValue instance) {
		log.debug("MonGlbValDAO - getTotalByExample - MonGlobalValue ");
		Integer count = null;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(MonGlobalValue.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}

			data = instance.getFieldName();
			if (data != null) {
				String searchTerm = (String) data;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(1, searchTerm.length() - 1);
					c.add(Restrictions.ilike("fieldName", searchTerm, MatchMode.ANYWHERE));
				} else if (searchTerm.startsWith("*")) {
					searchTerm = searchTerm.substring(1);
					c.add(Restrictions.ilike("fieldName", searchTerm, MatchMode.END));
				} else if (searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(0, searchTerm.length() - 1);
					c.add(Restrictions.ilike("fieldName", searchTerm, MatchMode.START));
				} else {
					c.add(Restrictions.ilike("fieldName", searchTerm, MatchMode.EXACT));
				}
			}

			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;

		} catch (RuntimeException re) {
			log.error("MonGlbValDAO - getTotalByExample Task Command failed", re);
			throw re;
		}
		return count;
	}

	public List<MonGlobalValue> findByExample(MonGlobalValue instance, int pageNum) {
		log.debug("MonGlbValDAO - finding MonGlobalValue instance by example");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(MonGlobalValue.class);
			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}

			data = instance.getFieldName();
			if (data != null) {
				if (data != null) {
					String searchTerm = (String) data;
					if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
						searchTerm = searchTerm.substring(1, searchTerm.length() - 1);
						c.add(Restrictions.ilike("fieldName", searchTerm, MatchMode.ANYWHERE));
					} else if (searchTerm.startsWith("*")) {
						searchTerm = searchTerm.substring(1);
						c.add(Restrictions.ilike("fieldName", searchTerm, MatchMode.END));
					} else if (searchTerm.endsWith("*")) {
						searchTerm = searchTerm.substring(0, searchTerm.length() - 1);
						c.add(Restrictions.ilike("fieldName", searchTerm, MatchMode.START));
					} else {
						c.add(Restrictions.ilike("fieldName", searchTerm, MatchMode.EXACT));
					}
				}
			}

			c = c.add(Restrictions.allEq(condition));
			c.addOrder(Order.asc("fieldName"));
			setPaging(c, pageNum);
			List<MonGlobalValue> results = c.list();

			log.debug("MonGlbValDAO - findByExample successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("MonGlbValDAO - find by example failed", re);
			throw re;
		}
	}

	public List getMaxId() {
		try {

			String queryString = "select max(id) as maxId from CS_MONGLOBALVALUE";

			Query queryObject = createSQLQuery(queryString).addScalar("maxId", StandardBasicTypes.INTEGER);

			List result = queryObject.list();

			log.debug("Success Result MonGlbValDAO - getMaxId" + result.toString());

			return result;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}

	public boolean isDuplicate(MonGlobalValue instance) {
		log.debug("MonGlbValDAO - isDuplicate - MonGlobalValue ");
		boolean flag = false;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(MonGlobalValue.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}

			data = instance.getFieldName();
			if (data != null) {
				condition.put("fieldName", data);
			}
			data = instance.getFieldValue0();
			if (data != null) {
				condition.put("fieldValue0", data);
			}

			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null && sLong > 0)
				flag = true;
			else
				flag = false;

		} catch (RuntimeException re) {
			log.error("MonGlbValDAO - isDuplicate Task Command failed", re);
			throw re;
		}
		return flag;
	}

	public List<List<String>> getMonGlobalFieldValueList(String fieldName) {
		log.debug("MonGlbValDAO - fetching mon global value field list");
		try {
			String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");

			StringBuffer queryBuffer = new StringBuffer();

			queryBuffer.append("select product, field_name as fieldName, field_value0 as fieldValue0, ")
					.append(" field_value1 as fieldValue1, field_value2 as fieldValue2, field_value3 as fieldValue3,")
					.append(" field_value4 as fieldValue4, field_value_desc as fieldValueDesc")
					.append(" from cs_monglobalvalue where field_name  = :fieldName and product = :productId");

			String queryString = queryBuffer.toString();
			Query queryObject = getSession().createSQLQuery(queryString);

			queryObject.setParameter("productId", productId);
			queryObject.setParameter("fieldName", fieldName);
			queryObject.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			List<Map<String, Object>> dataList = queryObject.list();
			List<List<String>> resultList = new ArrayList<>();

			if (dataList != null && !dataList.isEmpty()) {
				Map<String, Object> map = dataList.get(0);

				map.forEach((k, v) -> {
					List<String> list = new ArrayList<>();
					list.add(k);
					list.add((String) v);
					resultList.add(list);
				});
			}

			log.debug("MonGlbValDAO - getMonGlobalFieldValueList successful, result size: " + resultList.size());
			return resultList;
		} catch (RuntimeException re) {
			log.error("MonGlbValDAO - getMonGlobalFieldValueList failed", re);
			throw re;
		}
	}

	@Override
	public Class<MonGlobalValue> getEntityClass() {
		return MonGlobalValue.class;
	}

	public List getAcquirIssuerList(String userType, String productId) {
		try {

			String queryString = "select distinct field_value0 as id, field_value0 as product "
					+ "from cs_monglobalvalue " + "where field_name = '" + userType + "' " + "and product = '"
					+ productId + "' " + "order by field_value0 ";

			Query queryObject = createSQLQuery(queryString).addScalar("id", StandardBasicTypes.STRING)
					.addScalar("product", StandardBasicTypes.STRING);

			List result = queryObject.list();

			log.debug("Result of Task Command Product " + result.toString());

			return result;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getDepartments dropdown list.. failed", re);
			throw re;
		}
	}

	public List getListByFieldName(String fileName, String productId) {
		try {

			String queryString = "select distinct field_value0 as id, field_value0 as product from cs_monglobalvalue where field_name=? and product =? order by field_value0 ";

			Query queryObject = createSQLQuery(queryString).addScalar("id", StandardBasicTypes.STRING)
					.addScalar("product", StandardBasicTypes.STRING);
			queryObject.setParameter(0, fileName);
			queryObject.setParameter(1, productId);
			List result = queryObject.list();

			log.debug("Result of Task Command Product " + result.toString());

			return result;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getDepartments dropdown list.. failed", re);
			throw re;
		}
	}

	// Get collection to fill procedure drop down
	public List getProcedureList(String fieldName, String product) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("PROC_LIST");

			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("id", StandardBasicTypes.STRING)
					.addScalar("procCode", StandardBasicTypes.STRING);

			queryObject.setParameter(1, fieldName);
			queryObject.setParameter(2, product);

			List result = queryObject.list();

			log.debug("Result of Task Command Product " + result.toString());
			return result;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getProcedureList dropdown list.. failed", re);
			throw re;
		}
	}
}
