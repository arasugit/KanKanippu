package com.fis.ist.monitoring.dto;

import java.io.Serializable;
import java.util.Date;

import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.domain.Notification;

public class NotificationDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer id;
	private String type;
	private String desc;
	private String date;
	private String time;
	private String logDate;
	private String product;
	private String nodeName;

	public NotificationDto() {}

	public NotificationDto(int id, String type, String desc) {
		super();
		this.id = id;
		this.type = type;
		this.desc = desc;
	}

	public NotificationDto(int id, String type, String desc, String date, String time) {
		super();
		this.id = id;
		this.type = type;
		this.desc = desc;
		this.date = date;
		this.time = time;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getLogDate() {
		return logDate;
	}

	public void setLogDate(String logDate) {
		this.logDate = PaymonUtils.getFormattedResponseDateTime(logDate);

	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public void load(Notification model) {
		setId(model.getId());
		setLogDate(model.getLogDate());
		setDesc(model.getMessage());
		setType(model.getServerity());
	}

}
