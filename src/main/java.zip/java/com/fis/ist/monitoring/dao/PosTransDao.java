package com.fis.ist.monitoring.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.hibernate.jpa.QueryHints;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.dto.PosTransCountDto;
import com.fis.ist.monitoring.dto.Triplet;

public class PosTransDao extends MonitorBaseDAO<Integer, Integer> {

	private static final ISTLogger log = ISTLogger.getLogger(PosTransDao.class);

	public List<PosTransCountDto> getPosTransCounts(String fromDate, String toDate, String fromDateFormat,
			String toDateFormat, String tranRange, Integer salesTranPCode, List<Integer> tranMsgTypes,
			Integer tranRevCode, Integer tranRespCode, String tranType) {

		log.debug(String.format(
				"PosTransDao - selecting POS Trans count from db. pCode: %s, TransRange: %s, FromDate: %s, ToDate: %s., TranType: %s, RespCode: %s, RevCode: %s",
				salesTranPCode, tranRange, fromDate, toDate, tranType, tranRespCode, tranRevCode));

		try {
			String queryKey = "POS_TRANS_OVERVIEW";

			if ("Fraudulent".equalsIgnoreCase(tranType) || "Rejection".equalsIgnoreCase(tranType))
				queryKey = String.format("%s_%s", queryKey, tranRange.toUpperCase());
			else
				queryKey = String.format("%s_%s_%s", queryKey, tranType.toUpperCase(), tranRange.toUpperCase());

			String query = SqlQueryProvider.getDBSqlQuery(queryKey);

			query = setPosTransCountsQueryFilter(query, salesTranPCode, tranMsgTypes, tranRevCode, tranRespCode,
					tranType);

			Query queryObject = getSession().createSQLQuery(query)
					.addScalar("TransactionDate", StandardBasicTypes.STRING)
					.addScalar("ApprovedTrans", StandardBasicTypes.INTEGER)
					.addScalar("DeclinedTrans", StandardBasicTypes.INTEGER)
					.addScalar("ReversedTrans", StandardBasicTypes.INTEGER)
					.addScalar("TotalTrans", StandardBasicTypes.INTEGER);

			setPosTransCountsQueryParams(queryObject, fromDate, toDate, fromDateFormat, toDateFormat, salesTranPCode,
					tranMsgTypes, tranRevCode, tranRespCode);

			return (List<PosTransCountDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(PosTransCountDto.class)).list();
		} catch (RuntimeException re) {
			log.error("Query Fails - getPosTransCounts", re);
			throw re;
		}
	}

	public List getPosTransactionLogs(String fromDate, String toDate, String fromDateFormat, String toDateFormat,
			String tranRange, Integer salesTranPCode, List<Integer> tranMsgTypes, Integer tranRevCode,
			Integer tranRespCode, String tranType, Integer weekNumber, Integer quarterNumber, String monthAndYear,
			int pageNum) {
		try {
			StringBuffer queryBuffer = new StringBuffer();

			queryBuffer.append(SqlQueryProvider.getDBSqlQuery("POS_TXN_LOG"));

			setTransactionLogsQueryFilter(queryBuffer, fromDate, toDate, salesTranPCode, tranMsgTypes, tranRevCode,
					tranRespCode, tranType, weekNumber, quarterNumber, monthAndYear);

			if (pageNum > 0)
				queryBuffer.append("order by chip_index, site_id");

			String queryString = queryBuffer.toString();

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chipindex", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING)
					.addScalar("istsysdate", StandardBasicTypes.TIMESTAMP)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.DATE)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("terminalId", StandardBasicTypes.STRING)
					.addScalar("make", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			setTransactionLogsQueryParams(queryObject, fromDate, toDate, fromDateFormat, toDateFormat, salesTranPCode,
					tranMsgTypes, tranRevCode, tranRespCode, weekNumber, quarterNumber, monthAndYear);
			setPaging(queryObject, pageNum);

			Stream stream = queryObject.setHint(QueryHints.HINT_FETCH_SIZE, 500).getResultStream();

			List recordList = new ArrayList<>();
			stream.forEach(x -> {
				recordList.add(x);
			});

			return recordList;

		} catch (RuntimeException re) {
			log.error("Query Fails - getPosTransactionLogs", re);
			throw re;
		}
	}

	public int getPosTransactionLogsCount(String fromDate, String toDate, String fromDateFormat, String toDateFormat,
			Integer salesTranPCode, List<Integer> tranMsgTypes, Integer tranRevCode, Integer tranRespCode,
			String tranType, Integer weekNumber, Integer quarterNumber, String monthAndYear) {
		try {
			StringBuffer queryBuffer = new StringBuffer(SqlQueryProvider.getDBSqlQuery("POS_TXN_LOG_CNT"));

			setTransactionLogsQueryFilter(queryBuffer, fromDate, toDate, salesTranPCode, tranMsgTypes, tranRevCode,
					tranRespCode, tranType, weekNumber, quarterNumber, monthAndYear);
			String queryString = queryBuffer.toString();
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			setTransactionLogsQueryParams(queryObject, fromDate, toDate, fromDateFormat, toDateFormat, salesTranPCode,
					tranMsgTypes, tranRevCode, tranRespCode, weekNumber, quarterNumber, monthAndYear);

			return (int) queryObject.uniqueResult();
		} catch (RuntimeException re) {
			log.error("Query Fails - getPosTransactionLogsCount", re);
			throw re;
		}
	}

	private static void setTransactionLogsQueryFilter(StringBuffer queryBuffer, String fromDate, String toDate,
			Integer salesTranPCode, List<Integer> tranMsgTypes, Integer tranRevCode, Integer tranRespCode,
			String tranType, Integer weekNumber, Integer quarterNumber, String monthAndYear) {

		queryBuffer.append(getPosTransQueryFilter(salesTranPCode, tranMsgTypes, tranRevCode, tranRespCode, tranType));

		if (weekNumber != null) {
			queryBuffer.append(" AND TO_CHAR(istsysdate, 'WW') = :weekNumber ");
			addCurrentYearFilter(queryBuffer);
		}

		if (quarterNumber != null) {
			queryBuffer.append(" AND TO_CHAR(istsysdate, 'Q') = :quarterNumber ");
			addCurrentYearFilter(queryBuffer);
		}

		if (!PaymonUtils.isNullOrEmpty(monthAndYear))
			queryBuffer.append(" AND TO_CHAR(istsysdate, 'MON-YY') = :monthAndYear ");

		if (!PaymonUtils.isNullOrEmpty(fromDate) && !PaymonUtils.isNullOrEmpty(toDate)) {
			if (PaymonUtils.isOracleDb())
				queryBuffer.append(
						" AND istsysdate between to_date(:fromDate, :fromDateFormat) and to_date(:toDate, :toDateFormat) ");
			else if (PaymonUtils.isPostgressDb())
				queryBuffer.append(
						" AND istsysdate between to_timestamp(:fromDate, :fromDateFormat) and to_timestamp(:toDate, :toDateFormat) ");
		}
	}

	private static void addCurrentYearFilter(StringBuffer queryBuffer) {
		if (PaymonUtils.isPostgressDb()) {
			queryBuffer.append(" AND istsysdate >= DATE_TRUNC('year', CURRENT_DATE) ");
			return;
		}

		queryBuffer.append(" AND istsysdate >= TRUNC(SYSDATE, 'Y') ");
	}

	private static void setTransactionLogsQueryParams(Query queryObject, String fromDate, String toDate,
			String fromDateFormat, String toDateFormat, Integer salesTranPCode, List<Integer> tranMsgTypes,
			Integer tranRevCode, Integer tranRespCode, Integer weekNumber, Integer quarterNumber, String monthAndYear) {

		setPosTransCountsQueryParams(queryObject, fromDate, toDate, fromDateFormat, toDateFormat, salesTranPCode,
				tranMsgTypes, tranRevCode, tranRespCode);

		if (weekNumber != null)
			queryObject.setParameter("weekNumber", weekNumber.toString());

		if (!PaymonUtils.isNullOrEmpty(monthAndYear))
			queryObject.setParameter("monthAndYear", monthAndYear);

		if (quarterNumber != null)
			queryObject.setParameter("quarterNumber", quarterNumber.toString());
	}

	private static String setPosTransCountsQueryFilter(String query, Integer salesTranPCode, List<Integer> tranMsgTypes,
			Integer tranRevCode, Integer tranRespCode, String tranType) {
		String queryFilter = getPosTransQueryFilter(salesTranPCode, tranMsgTypes, tranRevCode, tranRespCode, tranType);
		return query.replaceAll("FILTER_QUERY", queryFilter);
	}

	private static String getPosTransQueryFilter(Integer salesTranPCode, List<Integer> tranMsgTypes,
			Integer tranRevCode, Integer tranRespCode, String tranType) {
		StringBuffer queryBuffer = new StringBuffer();

		if (salesTranPCode != null)
			queryBuffer.append(" AND pCode = :pCode ");

		if (tranMsgTypes.size() > 0)
			queryBuffer.append(" AND msgType IN (:msgType) ");

		if ("Rejection".equalsIgnoreCase(tranType)) {
			queryBuffer.append(" AND (respCode = :respCode or revCode = :revCode) ");
		} else {
			if (tranRespCode != null && tranRespCode >= 0)
				queryBuffer.append(" AND respCode = :respCode ");
			else if (tranRespCode != null && tranRespCode < 0)
				queryBuffer.append(" AND respCode != :respCode ");

			if (tranRevCode != null)
				queryBuffer.append(" AND revCode = :revCode ");
		}
		return queryBuffer.toString();
	}

	private static void setPosTransCountsQueryParams(Query queryObject, String fromDate, String toDate,
			String fromDateFormat, String toDateFormat, Integer salesTranPCode, List<Integer> tranMsgTypes,
			Integer tranRevCode, Integer tranRespCode) {

		if (queryObject.getQueryString().contains("fromDate")) {
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("fromDateFormat", fromDateFormat);
		}

		if (queryObject.getQueryString().contains("toDate")) {
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("toDateFormat", toDateFormat);
		}

		if (salesTranPCode != null)
			queryObject.setParameter("pCode", salesTranPCode);

		if (tranMsgTypes.size() > 0)
			queryObject.setParameterList("msgType", tranMsgTypes);

		if (tranRevCode != null)
			queryObject.setParameter("revCode", tranRevCode);

		if (tranRespCode != null)
			queryObject.setParameter("respCode", tranRespCode < 0 ? 0 : tranRespCode);
	}

	// -- POS Txn Make wise Success & Failure Txns
	public List<Triplet<String, Integer, Integer>> getPOSMakewiseTxns(String Screentype) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("POS_MAKEWISE_TXNS");

			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, Screentype);

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("key", StandardBasicTypes.STRING)
					.addScalar("value1", StandardBasicTypes.INTEGER).addScalar("value2", StandardBasicTypes.INTEGER);

			return (List<Triplet<String, Integer, Integer>>) queryObject
					.setResultTransformer(Transformers.aliasToBean(Triplet.class)).list();

		} catch (RuntimeException re) {
			log.error("Query Fails getPOSMakewiseTxns()", re);
			throw re;
		}
	}

	// POS Txn Drilldown Data
	public int getPosTxnDetailsCount(String posMake, String screentype, String txnStatus) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("POS_TXN_DTL_CNT");
			queryString = queryString.replaceAll("MAKE_WISE_FILETR", posMake);
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, screentype);
			queryString = SqlQueryProvider.addTransactionStatsDetailsMsgTypeFilter(queryString, txnStatus);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			return (int) queryObject.uniqueResult();

		} catch (Exception re) {
			log.error("getPosTxnDetailsCount Query Fails", re);
			throw re;
		}
	}

	public List getPosTxnDetails(String posMake, String screentype, String txnStatus, int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("POS_TXN_DTL");
			queryString = queryString.replaceAll("MAKE_WISE_FILETR", posMake);
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, screentype);
			queryString = SqlQueryProvider.addTransactionStatsDetailsMsgTypeFilter(queryString, txnStatus);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chip_index", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING).addScalar("istsysdate", StandardBasicTypes.STRING)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.STRING)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("pos_terminal_type", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (Exception re) {
			log.error("getAcquirerTransactionDetails Query Fails", re);
			throw re;
		}
	}

	@Override
	public Class<Integer> getEntityClass() {
		return null;
	}
}
