package com.fis.ist.monitoring.dto;

public interface FaultType {
	
	Integer CASSETTE_FATAL_FAULT =1;
	String  CASSETTE_FAULT_DESC="All Cassette Fatal Faults";
	Integer CARD_READER_PROBLEM =2;	
	String  CARD_READER_PROBLEM_DESC="Card Reader Problems";
	Integer CARD_HANDLER_PROBLEM =3;
	String  CARD_HANDLER_PROBLEM_DESC="Cash Handler Problems";
	Integer CASH_OUT_PROBLEM =4;
	String  CASH_OUT_PROBLEM_DESC="Cashout Problems";
	Integer COMMUNICATION_PROBLEM =5;
	String  COMMUNICATION_PROBLEM_DESC ="Communication Problems";
	Integer IN_SUPERVISORY =6;
	String  IN_SUPERVISORY_DESC ="In Supervisory";
	Integer REJECT_BILL_OVER_FILL =7;
	String  REJECT_BILL_OVER_FILL_DESC="Reject Bill OverFill";
	Integer ENCRYPTOR_PROBLEM =8;
	String  ENCRYPTOR_PROBLEM_DESC="Encryptor Problem\n(Encryptor/PinPad)";
	Integer JOUNRNAL_PRINTER_PROBLEM =9;
	String  JOUNRNAL_PRINTER_PROBLEM_DESC="Journal Printer Problem";
	Integer RECEIPT_PRINTER_PROBLEM =10;
	String  RECEIPT_PRINTER_PROBLEM_DESC="Receipt Printer Problem";
	Integer RECEIPT_PRINTER_PAPER_OUT =11;
	String  RECEIPT_PRINTER_PAPER_OUT_DESC="Receipt Printer Paper Out";
	Integer JOURNAL_PRINTER_PAPER_OUT =12;
	String  JOURNAL_PRINTER_PAPER_OUT_DESC="Journal Printer Paper Out";
	Integer IN_SERVICE_ATM =13;
	String  IN_SERVICE_ATM_DESC="In-Service ATM";
	Integer OUT_OF_SERVICE_ATM =14;
	String  OUT_OF_SERVICE_ATM_DESC="Out-Of-Service ATM";
}
