package com.fis.ist.monitoring.dto;


public class TPSTxnDTO implements Cloneable {

	private String txnMonth;
	private String numTxnsPerMonth;
	private String tps;
	private String txnDest;
	
	
	public String getTxnMonth() {
	return txnMonth;
	}
	public void setTxnMonth(String txnMonth) {
		this.txnMonth = txnMonth;
	}
	
	public String getNumTxnsPerMonth() {
		return numTxnsPerMonth;
	}
	public void setNumTxnsPerMonth(String numTxnsPerMonth) {
		this.numTxnsPerMonth = numTxnsPerMonth;
	}
	
	public String getTps() {
		return tps;
	}
	public void setTps(String tps) {
		this.tps = tps;
	}
	
	public String getTxnDest() {
		return txnDest;
	}
	public void setTxnDest(String txnDest) {
		this.txnDest = txnDest;
	}
	
	public void loadAvgTPS(Object[] model) {
		setTxnMonth((String) model[0]);
		//setNumTxnsPerMonth((String) model[1]);
		setTps((String) model[1]);
	}
	
	public void loadInstTPS(Object[] model) {
		setTxnMonth((String) model[0]);
		setTps((String) model[1]);
		setTxnDest((String) model[2]);
	}
	
	public void loadCurrentTPS(String model) {
		setTps((String) model);
	}
	
}
