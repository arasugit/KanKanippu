package com.fis.ist.monitoring.dto;
import com.fis.ist.monitoring.common.PaymonUtils;
 

public class TransactionStatisticsListItem implements Cloneable {

// Transaction Details DTO
	
	private String msgType;
	private String processingCode;
	private String txnType;	
	private String txnsrc;	
	private String acquirer;
	private String txnDest;
	private String issuer;
	private String amount;
	private String respCode;
	private String respCodeDesc;
	private String alphaRespCode;
	private String declineCategory;
	private String chipIndex;
	private String trace;
	private String refNum;
	private String localDate;
	private String localTime;
	private String transDate;
	private String transTime;
	private String istSysDate;
	private String origDate;
	private String origTrace;
	private String origTime;
	private String origMsg;
	private String authNum;
	private String terminalId;
	private String pan;
	private String processingCodeDesc;
	private String currCode;
	private String posTerminalType;
	
	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getTxnsrc() {
		return txnsrc;
	}

	public void setTxnsrc(String txnsrc) {
		this.txnsrc = txnsrc;
	}

	public String getAcquirer() {
		return acquirer;
	}

	public void setAcquirer(String acquirer) {
		this.acquirer = acquirer;
	}

	public String getMsgType() {
		return msgType;
	}

	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

	public String getTxnDest() {
		return txnDest;
	}

	public void setTxnDest(String txnDest) {
		this.txnDest = txnDest;
	}

	public String getIssuer() {
		return issuer;
	}

	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}
	
	public String getRespCodeDesc() {
		return respCodeDesc;
	}

	public void setRespCodeDesc(String respCodeDesc) {
		this.respCodeDesc = respCodeDesc;
	}
	
	public String getAlphaRespCode() {
		return alphaRespCode;
	}

	public void setAlphaRespCode(String alphaRespCode) {
		this.alphaRespCode = alphaRespCode;
	}

	public String getProcessingCode() {
		return processingCode;
	}

	public void setProcessingCode(String processingCode) {
		this.processingCode = processingCode;
	}

	public String getIstSysDate() {
		return istSysDate;
	}

	public void setIstSysDate(Object istSysDate) {
		this.istSysDate = PaymonUtils.getFormattedResponseDateTime(istSysDate);
	}

	public String getChipIndex() {
		return chipIndex;
	}

	public void setChipIndex(String chipIndex) {
		this.chipIndex = chipIndex;
	}

	public String getTrace() {
		return trace;
	}

	public void setTrace(String trace) {
		this.trace = trace;
	}

	public String getRefNum() {
		return refNum;
	}

	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getLocalDate() {
		return localDate;
	}

	public void setLocalDate(Object localDate) {
		this.localDate = PaymonUtils.getFormattedResponseDate(localDate);
	}

	public String getLocalTime() {
		return localTime;
	}

	public void setLocalTime(Object localTime) {
		this.localTime = PaymonUtils.getFormattedResponseTime(localTime);
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(Object transDate) {
		this.transDate = PaymonUtils.getFormattedResponseDate(transDate);
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(Object transTime) {
		this.transTime = PaymonUtils.getFormattedResponseTime(transTime);
	}
	
	public String getDeclineCategory() {
		return declineCategory;
	}

	public void setDeclineCategory(String declineCategory) {
		this.declineCategory = declineCategory;
	}
	
	public String getOrigDate() {
		return origDate;
	}

	public void setOrigDate(Object origDate) {
		this.origDate = PaymonUtils.getFormattedResponseDate(origDate);
	}

	public String getOrigTrace() {
		return origTrace;
	}

	public void setOrigTrace(String origTrace) {
		this.origTrace = origTrace;
	}

	public String getOrigTime() {
		return origTime;
	}

	public void setOrigTime(Object origTime) {
		this.origTime = PaymonUtils.getFormattedResponseTime(origTime);
	}
	
	public String getOrigMsg() {
		return origMsg;
	}

	public void setOrigMsg(String origMsg) {
		this.origMsg = origMsg;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getAuthNum() {
		return authNum;
	}

	public void setAuthNum(String authNum) {
		this.authNum = authNum;
	}
	
	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}
	
	public String getProcessingCodeDesc() {
		return processingCodeDesc;
	}

	public void setProcessingCodeDesc(String processingCodeDesc) {
		this.processingCodeDesc = processingCodeDesc;
	}
	
	public String getCurrCode() {
		return currCode;
	}

	public void setCurrCode(String currCode) {
		this.currCode = currCode;
	}
	
	public String getPosTerminalType() {
		return posTerminalType;
	}

	public void setPosTerminalType(String posTerminalType) {
		this.posTerminalType = posTerminalType;
	}

	
	public void loadTxnDetails(Object[] model) {
		loadTxnDetails(model, null);
	}
	
	public void loadTxnDetails(Object[] model, Boolean customDateTimeFormat) {
		setMsgType((String) model[0]);
		setProcessingCode((String) model[1]);
		setTxnType((String) model[2]);
		setTxnsrc((String) model[3]);
		setAcquirer((String) model[4]);
		setTxnDest((String) model[5]);
		setIssuer((String) model[6]);
		setChipIndex((String) model[7]);
		setTrace((String) model[8]);
		setRefNum((String) model[9]);
		setAmount((String) model[10]);
		setLocalDate(model[11]);
		setLocalTime((String) model[12]);
		setTransDate(model[13]);
		setTransTime((String) model[14]);
		setRespCode((String) model[15]);
		setIstSysDate(model[16]);
		setOrigMsg((String) model[17]);
		setOrigDate(model[18]);
		setOrigTrace((String) model[19]);
		setOrigTime((String) model[20]);
		setAuthNum((String) model[21]);
		setTerminalId((String) model[22]);
		setAlphaRespCode((String) model[23]);
	}
	
	
	public void loadTxnStsAcqRejection(Object[] model) {
		setMsgType((String) model[0]);
		setTxnsrc((String) model[1]);
		setAcquirer((String) model[2]);
		setProcessingCode((String) model[3]);
		setTxnType((String) model[4]);
		setTxnDest((String) model[5]);
		setIssuer((String) model[6]);
		setChipIndex((String) model[7]);
		setTrace((String) model[8]);
		setRefNum((String) model[9]);
		setAmount((String) model[10]);
		setLocalDate(model[11].toString());
		setLocalTime((String) model[12]);
		setTransDate(model[13].toString());
		setTransTime((String) model[14]);
		setRespCode((String) model[15]);
		setTransDate(model[16]);
		setOrigMsg((String) model[17]);
		setOrigDate((model[18].toString()));
		setOrigTrace((String) model[19]);
		setOrigTime((String) model[20]); 
		setAuthNum((String) model[21]);
		setTerminalId((String) model[22]);
		setAlphaRespCode((String) model[23]);
	}
	
	public void loadTxnLogDetails(Object[] model) {
		setMsgType((String) model[0]);
		setProcessingCode((String) model[1]);
		setTxnType((String) model[2]);
		setTxnsrc((String) model[3]);
		setAcquirer((String) model[4]);
		setTxnDest((String) model[5]);
		setIssuer((String) model[6]);
		setChipIndex((String) model[7]);
		setTrace((String) model[8]);
		setRefNum((String) model[9]);
		setAmount((String) model[10]);
		setLocalDate(model[11]);
		setLocalTime((String) model[12]);
		setTransDate(model[13]);
		setTransTime((String) model[14]);
		setRespCode((String) model[15]);
		setIstSysDate(model[16]);
		setOrigMsg((String) model[17]);
		setOrigDate(model[18]);
		setOrigTrace((String) model[19]);
		setOrigTime((String) model[20]); 
		setAuthNum((String) model[21]);
		setTerminalId((String) model[22]);
		setPan((String) model[23]);
		setAlphaRespCode((String) model[24]);
	}
	
	//TODO : Check and refactor this function params are same as loadTxnDetails() just order is different... 
	public void loadTxnStsATMPOS(Object[] model) {
		setMsgType((String) model[0]);
		setTxnsrc((String) model[1]);
		setAcquirer((String) model[2]);
		setProcessingCode((String) model[3]);
		setTxnType((String) model[4]);
		setTxnDest((String) model[5]);
		setIssuer((String) model[6]);
		setChipIndex((String) model[7]);
		setTrace((String) model[8]);
		setRefNum((String) model[9]);
		setAmount((String) model[10]);
		setLocalDate(model[11].toString());
		setLocalTime((String) model[12]);
		setTransDate(model[13].toString());
		setTransTime((String) model[14]);
		setRespCode((String) model[15]);
		setIstSysDate(model[16].toString());
		setOrigMsg((String) model[17]);
		setOrigDate(model[18].toString());
		setOrigTrace((String) model[19]);
		setOrigTime((String) model[20]);
		setAuthNum((String) model[21]);
		setTerminalId((String) model[22]);	
		setAlphaRespCode((String) model[23]);
	}
	
	public void loadTxnStsOverseas(Object[] model) {
		setMsgType((String) model[0]);
		setTxnsrc((String) model[1]);
		setAcquirer((String) model[2]);
		setTxnDest((String) model[3]);
		setIssuer((String) model[4]);
		setChipIndex((String) model[5]);
		setTrace((String) model[6]);
		setRefNum((String) model[7]);
		setAmount((String) model[8]);
		setLocalDate(model[9].toString());
		setLocalTime((String) model[10]);
		setTransDate(model[11].toString());   
		setTransTime((String) model[12]);
		setCurrCode((String) model[13]);
		setRespCode((String) model[14]);
		setIstSysDate(model[15].toString());   
		setProcessingCode((String) model[16]);
		setTxnType((String) model[17]);
		setOrigMsg((String) model[18]);
		setOrigDate(model[19].toString());
		setOrigTrace((String) model[20]);
		setOrigTime((String) model[21]); 
		setAuthNum((String) model[22]);
		setTerminalId((String) model[23]);
		setAlphaRespCode((String) model[24]);
	}
	
	public void loadPosTxnDetails(Object[] model) {
		setMsgType((String) model[0]);
		setProcessingCode((String) model[1]);
		setTxnType((String) model[2]);
		setTxnsrc((String) model[3]);
		setAcquirer((String) model[4]);
		setTxnDest((String) model[5]);
		setIssuer((String) model[6]);
		setChipIndex((String) model[7]);
		setTrace((String) model[8]);
		setRefNum((String) model[9]);
		setAmount((String) model[10]);
		setLocalDate(model[11]);
		setLocalTime((String) model[12]);
		setTransDate(model[13]);
		setTransTime((String) model[14]);
		setRespCode((String) model[15]);
		setIstSysDate(model[16]);
		setOrigMsg((String) model[17]);
		setOrigDate(model[18]);
		setOrigTrace((String) model[19]);
		setOrigTime((String) model[20]);
		setAuthNum((String) model[21]);
		setTerminalId((String) model[22]);
		setPosTerminalType((String) model[23]);
	}
	
	@Override
	public String toString() {
		return "TransactionStatisticsListItem [txnsrc=" + txnsrc + ", acquirer=" + acquirer 
				+ ", terminalId=" + terminalId + ", msgType=" + msgType
				+ ", txnDest=" + txnDest + ", issuer=" + issuer + ", respCode=" + respCode + ", respCodeDesc="
				+ respCodeDesc + ", processingCode=" + processingCode 
				+ ", istSysDate=" + istSysDate + ", chipIndex=" + chipIndex + ", trace=" + trace + ", refNum=" + refNum
				+ ", amount=" + amount + ", localDate=" + localDate + ", localTime=" + localTime + ", transDate="
				+ transDate + ", transTime=" + transTime + ", numTxnsPerMonth="
				+ ", declineCategory=" + declineCategory + ", origDate=" + origDate + ", origTrace="
				+ origTrace + ", origTime=" + origTime + ", origMsg=" + origMsg + ", txnType=" + txnType + ", authNum="
				+ authNum + "]";
	}
	
}