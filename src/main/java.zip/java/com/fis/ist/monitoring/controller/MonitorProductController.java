package com.fis.ist.monitoring.controller;

import static com.fis.ist.monitoring.controller.ControllerSupportConstants.CONTENT_TYPE;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.PRODUCT_ID;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.PRODUCT_NAME;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.PRODUCT_OPERATION_ONE;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.PRODUCT_OPERATION_TWO;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.RAW_TYPES;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.SITE_ID;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.NODE_NAME;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.NODE_ID;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.PRODUCT_UPDATE_SITENODES;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.SWITCH_PRODUCT_ID;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.CLEARING_PRODUCT_ID;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.MAS_PRODUCT_ID;
import static com.fis.ist.monitoring.controller.ControllerSupportConstants.CORTEX_PRODUCT_ID;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fis.ist.monitoring.dao.AppCommonDAO;

@SuppressWarnings({ RAW_TYPES })
@Controller
@RequestMapping(method = RequestMethod.POST)
public class MonitorProductController {

	@RequestMapping(value = PRODUCT_OPERATION_ONE, produces = CONTENT_TYPE, consumes = CONTENT_TYPE)
	@ResponseBody
	public ResponseEntity updateSelectedProduct(HttpServletRequest request, HttpServletResponse response,
			@RequestBody SelectedMonitorProduct selectedProduct) throws Exception {
		if (request.getSession(false).getAttribute(PRODUCT_ID) != null) {
			request.getSession(false).removeAttribute(PRODUCT_ID);
		}
		if (null != request.getSession(false).getAttribute(SITE_ID)) {
			request.getSession(false).removeAttribute(SITE_ID);
		}
		if (null != request.getSession(false).getAttribute(NODE_ID)) {
			request.getSession(false).removeAttribute(NODE_ID);
		}
		if (null != request.getSession(false).getAttribute(NODE_NAME)) {
			request.getSession(false).removeAttribute(NODE_NAME);
		}

		String productId = selectedProduct.getProductId();
		String productName = selectedProduct.getName();
		if(productId != null && productId.length() > 0) {
			productId = StringEscapeUtils.escapeHtml(productId);
			request.getSession(false).setAttribute(PRODUCT_ID, productId);
		}
		
		if(productName != null && productName.length() >0) {
			productName = StringEscapeUtils.escapeHtml(productName);
			request.getSession(false).setAttribute(PRODUCT_NAME, productName);
		}
		
		if (SWITCH_PRODUCT_ID.equalsIgnoreCase(selectedProduct.getProductId())
				|| CLEARING_PRODUCT_ID.equalsIgnoreCase(selectedProduct.getProductId())
				|| MAS_PRODUCT_ID.equalsIgnoreCase(selectedProduct.getProductId())
				|| CORTEX_PRODUCT_ID.equalsIgnoreCase(selectedProduct.getProductId())) {
			List<String> defaultSiteNode = new AppCommonDAO().getDefaultSiteNodeRecord();
			request.getSession(false).setAttribute(SITE_ID, defaultSiteNode.get(0));
			request.getSession(false).setAttribute(NODE_ID, defaultSiteNode.get(1));
			request.getSession(false).setAttribute(NODE_NAME, defaultSiteNode.get(2));
		}
		return ResponseEntity.ok(HttpStatus.OK);
	}

	@RequestMapping(value = PRODUCT_OPERATION_TWO, produces = CONTENT_TYPE, consumes = CONTENT_TYPE)
	@ResponseBody
	public List<String> getSelectedProduct(HttpServletRequest request, HttpServletResponse response) {
		List<String> productList = new ArrayList<>();
		HttpSession session = request.getSession(false);
		productList.add((String) session.getAttribute(PRODUCT_ID));
		productList.add((String) session.getAttribute(PRODUCT_NAME));
		if (SWITCH_PRODUCT_ID.equals((String) session.getAttribute(PRODUCT_ID))
				|| CORTEX_PRODUCT_ID.equals((String) session.getAttribute(PRODUCT_ID))) {
			productList.add((String) session.getAttribute(SITE_ID));
			productList.add((String) session.getAttribute(NODE_ID));
			productList.add((String) session.getAttribute(NODE_NAME));
		}
		return productList;
	}

	@RequestMapping(value = PRODUCT_UPDATE_SITENODES, produces = CONTENT_TYPE, consumes = CONTENT_TYPE)
	@ResponseBody
	public List<String> updateSelectedSiteNode(HttpServletRequest request, HttpServletResponse response,
			@RequestBody SelectedMonitorProduct selectedProduct) throws Exception {
		if (request.getSession(false).getAttribute(SITE_ID) != null) {
			request.getSession(false).removeAttribute(SITE_ID);
		}
		if (request.getSession(false).getAttribute(NODE_NAME) != null) {
			request.getSession(false).removeAttribute(NODE_NAME);
		}
		if (request.getSession(false).getAttribute(NODE_ID) != null) {
			request.getSession(false).removeAttribute(NODE_ID);
		}
		
		String siteId = selectedProduct.getSiteId();
		String nodeName = selectedProduct.getNodeName();
		String nodeId = selectedProduct.getNodeId();
		if(siteId != null && siteId.length() > 0) {
			siteId = StringEscapeUtils.escapeHtml(siteId);
			request.getSession(false).setAttribute(SITE_ID, siteId);
		}
		if(nodeName != null && nodeName.length() > 0) {
			nodeName = StringEscapeUtils.escapeHtml(nodeName);
			request.getSession(false).setAttribute(NODE_NAME, nodeName);
		}
		if(nodeId != null && nodeId.length() > 0) {
			nodeId = StringEscapeUtils.escapeHtml(nodeId);
			request.getSession(false).setAttribute(NODE_ID, nodeId);
		}
		List<String> productList = new ArrayList<>();
		HttpSession session = request.getSession(false);
		productList.add((String) session.getAttribute(SITE_ID));
		productList.add((String) session.getAttribute(NODE_ID));
		productList.add((String) session.getAttribute(NODE_NAME));
		return productList;
	}
}
