package com.fis.ist.monitoring.dao;

import static com.fis.ist.common.OracleDaoConstants.ACCEPTOR_NAME;
import static com.fis.ist.common.OracleDaoConstants.COUNT;
import static com.fis.ist.common.OracleDaoConstants.CRITERIA_ATM_GROUP_NAME;
import static com.fis.ist.common.OracleDaoConstants.CRITERIA_ATM_INSTITUTION;
import static com.fis.ist.common.OracleDaoConstants.CRITERIA_ATM_UNIT;
import static com.fis.ist.common.OracleDaoConstants.DEPRECATION;
import static com.fis.ist.common.OracleDaoConstants.EMPTY;
import static com.fis.ist.common.OracleDaoConstants.FAULT;
import static com.fis.ist.common.OracleDaoConstants.GROUP_NAME;
import static com.fis.ist.common.OracleDaoConstants.INSTITUTION_ID;
import static com.fis.ist.common.OracleDaoConstants.LOCATION;
import static com.fis.ist.common.OracleDaoConstants.MAKE;
import static com.fis.ist.common.OracleDaoConstants.NETWORK_NAME;
import static com.fis.ist.common.OracleDaoConstants.RAWTYPES;
import static com.fis.ist.common.OracleDaoConstants.SEVERITY;
import static com.fis.ist.common.OracleDaoConstants.SITE_ID;
import static com.fis.ist.common.OracleDaoConstants.STATUS_DESCRIPTION_LIST;
import static com.fis.ist.common.OracleDaoConstants.TERMINAL;
import static com.fis.ist.common.OracleDaoConstants.TERMINAL_COMP;
import static com.fis.ist.common.OracleDaoConstants.UNCHECKED;
import static com.fis.ist.common.OracleDaoConstants.UNIT;

import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.IndividualATMStatus;

@SuppressWarnings({ RAWTYPES, UNCHECKED, DEPRECATION })
public class IndividualATMStatusDao extends MonitorBaseDAO<IndividualATMStatus, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(IndividualATMStatusDao.class);
	private static final String INVATM_REQ_COUNT = "INVATM_REQ_COUNT";
	private static final String INVATM_REQ = "INVATM_REQ";
	private static final String QUERY_PREFIX = "prefix";
	private static final String QUERY_SUFFIX = "suffix";

	public List<IndividualATMStatus> getIndividualATMStatusBySwDB(int pageNum, String... atms) {
		log.debug("Entering getIndividualATMStatusBySwDB in IndividualATMStatusDao");
		List<IndividualATMStatus> individualATMList = null;
		try {
			int startSize=0;
			int endSize=0;
			
			StringBuilder sb=new StringBuilder(manipulatingPrefixSuffixforATMTabs(QUERY_PREFIX,INVATM_REQ));

			sb.append(SqlQueryProvider.getDBSqlQuery(INVATM_REQ));
			if (atms[0] != null) {
				sb.append(CRITERIA_ATM_INSTITUTION);
			}
			if (!atms[1].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_ATM_GROUP_NAME);
			}
			if (!atms[2].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_ATM_UNIT);
			}
			sb.append(") ");
			sb.append(manipulatingPrefixSuffixforATMTabs(QUERY_SUFFIX, INVATM_REQ));
			Query queryObject = getSession().createSQLQuery(sb.toString())
					.addScalar(INSTITUTION_ID, StandardBasicTypes.STRING)
					.addScalar(NETWORK_NAME, StandardBasicTypes.STRING).addScalar(GROUP_NAME, StandardBasicTypes.STRING)
					.addScalar(UNIT, StandardBasicTypes.LONG).addScalar(SEVERITY, StandardBasicTypes.LONG)
					.addScalar(FAULT, StandardBasicTypes.LONG)
					.addScalar(STATUS_DESCRIPTION_LIST, StandardBasicTypes.STRING)
					.addScalar(TERMINAL_COMP, StandardBasicTypes.STRING).addScalar(TERMINAL, StandardBasicTypes.STRING)
					.addScalar(LOCATION, StandardBasicTypes.STRING).addScalar(MAKE, StandardBasicTypes.STRING)
					.addScalar(ACCEPTOR_NAME, StandardBasicTypes.STRING).addScalar(SITE_ID, StandardBasicTypes.LONG);
			int pgsz = getDefaultPageSize();
			if (pageNum > 1) {
				startSize = ((pageNum * pgsz) - pgsz);
				endSize = pageNum * pgsz;
			} else {
				startSize = 1;
				endSize = pgsz;
			}
			int paramIndex = 0;
			if (atms[0] != null) {
				queryObject.setParameter(++paramIndex, atms[0]);
			}
			if (!atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, atms[1]);
			}
			if (!atms[2].equalsIgnoreCase(EMPTY) && atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));
			} else if (!atms[2].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));

			}
			queryObject.setParameter(++paramIndex, endSize);
			queryObject.setParameter(++paramIndex, startSize);
			individualATMList = (List<IndividualATMStatus>) queryObject
					.setResultTransformer(Transformers.aliasToBean(IndividualATMStatus.class)).list();

		} catch (RuntimeException re) {
			log.error("Error While finding total atms", re);
			throw re;
		}
		log.debug("Exiting getIndividualATMStatusBySwDB in IndividualATMStatusDao");
		return individualATMList;

	}

	public Integer getCountByInvdividualATMStatus(String... atms) {
		Integer count = null;
		log.debug("Entering getCountByInvdividualATMStatus in IndividualATMStatusDao");

		try 
		{
			StringBuilder sb = new StringBuilder(SqlQueryProvider.getDBSqlQuery(INVATM_REQ_COUNT));
			if (atms[0] != null) {
				sb.append(CRITERIA_ATM_INSTITUTION);
			}
			if (atms[1] != null && !atms[1].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_ATM_GROUP_NAME);
			}
			if (atms[2] != null && !atms[2].equalsIgnoreCase(EMPTY)) {
				sb.append(CRITERIA_ATM_UNIT);
			}
			Query queryObject = getSession().createSQLQuery(sb.toString()).addScalar(COUNT, StandardBasicTypes.INTEGER);
			int paramIndex = 0;
			if (atms[0] != null) {
				queryObject.setParameter(++paramIndex, atms[0]);
			}
			if (!atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, atms[1]);
			}
			if (!atms[2].equalsIgnoreCase(EMPTY) && atms[1].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));
			} else if (!atms[2].equalsIgnoreCase(EMPTY)) {
				queryObject.setParameter(++paramIndex, Integer.parseInt(atms[2]));
			}
			count = queryObject.uniqueResult() != null ? (Integer) queryObject.uniqueResult() : 0;

		} catch (RuntimeException re) {
			log.error("Error While finding total atms", re);
			throw re;
		}
		log.debug("Exiting getCountByInvdividualATMStatus in IndividualATMStatusDao");
		return count;

	}

	private static String manipulatingPrefixSuffixforATMTabs(String prefixSuffix, String module) {

		String queryString = "";

		if (SqlQueryProvider.isATMTab(module)) {

			if (("prefix").equalsIgnoreCase(prefixSuffix)) {
				if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
					queryString = "SELECT * from (SELECT targetQuery.*,rownum as rnum from (";
				} else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
					queryString = "SELECT * from (SELECT targetQuery.*,row_number() over() as rnum from (";
				}
			}

			if (("suffix").equalsIgnoreCase(prefixSuffix)) {
				if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
					queryString = " )targetQuery where rownum <=?) where rnum>=? ";
				} else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
					queryString = " as innerQuery ) as targetQuery limit ?) as pagenationCount where rnum>=?";
				}
			}
			
		}
		return queryString;
	}

	public Class<IndividualATMStatus> getEntityClass() {
		return IndividualATMStatus.class;
	}

}
