package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.PosTerminalDao;
import com.fis.ist.monitoring.domain.POSTerminals;
import com.fis.ist.monitoring.dto.POSTerminalsDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class POSTerminalDetailsHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(POSTerminalDetailsHandler.class);
	private static String reqTypeId = MonitorConstants.POS_DETAILS_REQ;
	private static String formAuthId = MonitorConstants.POS_DETAILS_REQ;

	public POSTerminalDetailsHandler() {
		checkMKCEnabled(formAuthId);
	}

	// Get POS Terminal Details
	public WorkRequest getPOSTerminalDetails(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}


	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.POS_DETAILS_TAB);
	}


	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.POS_DETAILS_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.POS_DETAILS_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.POS_DETAILS_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.POS_DETAILS_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load POS Terminal Details Screen");

		String institutionId = params.get("ist_inst_Id").trim();
		String terminalRecord = params.get("terminalRecord").trim();
		String terminalId = params.get("terminalId").trim();
		String terminalType = params.get("terminalType").trim();
		String entityId = params.get("entityId").trim();
		String status = params.get("ist_status").trim();

		PosTerminalDao dao = new PosTerminalDao();
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));	
		
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		List<POSTerminals> recordList = null;
		if (needs_total) {
			total = dao.getPOSTerminalDetailsCount(institutionId, terminalRecord, terminalId, terminalType, entityId,
					status);
		}
		recordList = dao.getPosTerminalDetails(institutionId, terminalRecord, terminalId, terminalType, entityId,
				status, pageNum, true);

		if (recordList.size() == 0) {
			log.debug("No records found !!!");
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		POSTerminalsDto totalsDto = null;
		List<POSTerminalsDto> workRows = getPOSDetailsList(workRequest, uiMetaData);
		if (recordList != null) {
			for (POSTerminals posTerminal : recordList) {
				totalsDto = new POSTerminalsDto();
				totalsDto.load(posTerminal);
				workRows.add(totalsDto);
			}
		}
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {
			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);
			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		return validateFields(fieldDataMap);
	}

	private List<POSTerminalsDto> getPOSDetailsList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.POS_DETAILS_TAB);
		workCollection.setSectionId(MonitorConstants.POS_DETAILS_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.POS_DETAILS_TAB);
		workRequest.getCollections().put(MonitorConstants.POS_DETAILS_COL, workCollection);

		List<POSTerminalsDto> workRows = new ArrayList<POSTerminalsDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.POS_DETAILS_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}
