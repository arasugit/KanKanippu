package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.ATMAvailabilityDAO;
import com.fis.ist.monitoring.dao.MonAtmCashCounterHistoryDAO;
import com.fis.ist.monitoring.dao.MonDbConnectedAtmDAO;
import com.fis.ist.monitoring.domain.ATMAvailable;
import com.fis.ist.monitoring.domain.ATMByFaultWise;
import com.fis.ist.monitoring.domain.ConguredATMByMake;
import com.fis.ist.monitoring.domain.RunningATMByMake;
import com.fis.ist.monitoring.domain.TerminalsByBranch;
import com.fis.ist.monitoring.domain.TerminalsBySite;
import com.fis.ist.monitoring.dto.ATMAvailabilityDto;
import com.fis.ist.monitoring.dto.ATMFltViewListRow;
import com.fis.ist.monitoring.dto.ATMRTCashPosListRow;
import com.fis.ist.monitoring.dto.ATMRltmCashPosHistoryRequestDto;
import com.fis.ist.monitoring.dto.DateTimeRequestDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class ATMAvailabilityHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(ATMAvailabilityHandler.class);
	private static String reqTypeId = MonitorConstants.ATM_AVAILABILITY_REQ;
	private static String formAuthId = "ATMAVL_REQ";

	public ATMAvailabilityHandler() {
		checkMKCEnabled(formAuthId);
	}

	public ATMAvailabilityHandler(String formAuthIdVar) {
		formAuthId = formAuthIdVar;
		reqTypeId = formAuthIdVar;
		checkMKCEnabled(formAuthIdVar);
	}

	public WorkRequest getATMAvailability(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	public WorkRequest getDSFaultDetails(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequestATMDataSourceFaultView(userContext, params);
		loadATMDSFaultStatusView(workReq, params);
		return workReq;
	}

	public WorkRequest getDSRltmCash(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequestATMDataSourceRltmCash(userContext, params);
		loadATMDSRltmCash(workReq, params);
		return workReq;
	}

	public WorkRequest getRltmCashHistory(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequestATMRltmCashHistory(userContext, params);
		loadATMRltmCashHistory(workReq, params);
		return workReq;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.ATM_AVAILABILITY_TAB);
	}

	private void addWorkFieldsFaultDetails(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, CustomConstants.ATMFLTVIEWTAB);
	}

	private void addWorkFieldsRltmCash(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, CustomConstants.ATMRTCASHTAB);
	}

	private void addWorkFieldsRltmCashHistory(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, CustomConstants.ATMRTCASHHISTAB);
	}

	private WorkRequest prepareWorkRequestATMDataSourceRltmCash(UserContext userContext, Map<String, String> params)
			throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.ATMRTCASH);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(CustomConstants.ATMRTCASH);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(CustomConstants.ATMRTCASHTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(CustomConstants.ATMRTCASHTAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFieldsRltmCash(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private WorkRequest prepareWorkRequestATMRltmCashHistory(UserContext userContext, Map<String, String> params)
			throws Exception {
		log.debug("Prepareing WorkRequest for ATM Real Time Cash Position History");
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.ATMRTCASHHIS);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(CustomConstants.ATMRTCASHHIS);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(CustomConstants.ATMRTCASHHISTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(CustomConstants.ATMRTCASHHISTAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFieldsRltmCashHistory(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private WorkRequest prepareWorkRequestATMDataSourceFaultView(UserContext userContext, Map<String, String> params)
			throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.ATMFLTVIEW);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(CustomConstants.ATMFLTVIEW);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(CustomConstants.ATMFLTVIEWTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(CustomConstants.ATMFLTVIEWTAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFieldsFaultDetails(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.ATM_AVAILABILITY_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.ATM_AVAILABILITY_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.ATM_AVAILABILITY_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.ATM_AVAILABILITY_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private void loadATMDSFaultStatusView(WorkRequest workRequest, Map<String, String> params) {
		log.debug("ATM Data Source Fault Detail Service Handler ");
		UIMetaData uiMetaData = null;

		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		List recordListfromISTDB = null;
		List recordListfromMONDB = null;
		List<ATMFltViewListRow> faultStatusViewListOnISTDB = new ArrayList<ATMFltViewListRow>();
		List<ATMFltViewListRow> faultStatusViewListMonDB = new ArrayList<ATMFltViewListRow>();
		List<String> termId = new ArrayList<String>();
		List<String> statusList = null;

		String statusCode = params.get("statusCode");

		List<ATMFltViewListRow> workRows = getAtmAvailabilityList1(workRequest, uiMetaData);

		log.debug("Status Code from user selection  " + statusCode);

		// Status code for various problems
		if (statusCode == null || statusCode.equalsIgnoreCase("")
				|| statusCode.equalsIgnoreCase("allCassetteFatalFaults")) {
			statusList = Arrays.asList("604", "607", "614", "615");
		} else if (statusCode.equalsIgnoreCase("cardReaderProblems")) {
			statusList = Arrays.asList("200", "202", "201", "203");
		} else if (statusCode.equalsIgnoreCase("cashHandlerProblems")) {
			statusList = Arrays.asList("608", "613");
		} else if (statusCode.equalsIgnoreCase("cashOutProblems")) {
			statusList = Arrays.asList("740", "741", "742", "743", "744", "745", "746", "750", "751", "755", "756",
					"757", "758", "759");
		} else if (statusCode.equalsIgnoreCase("communicationProblems")) {
			statusList = Arrays.asList("9717");
		} else if (statusCode.equalsIgnoreCase("inSupervisory")) {
			statusList = Arrays.asList("7");
		} else if (statusCode.equalsIgnoreCase("rejectBillOverFill")) {
			statusList = Arrays.asList("600", "605");
		} else if (statusCode.equalsIgnoreCase("encryptorProblem")) {
			statusList = Arrays.asList("999", "717");
		} else if (statusCode.equalsIgnoreCase("journalPrinterProblem")) {
			statusList = Arrays.asList("500", "503");
		} else if (statusCode.equalsIgnoreCase("receiptPrinterProblem")) {
			statusList = Arrays.asList("510");
		} else if (statusCode.equalsIgnoreCase("receiptPrinterPaperOut")) {
			statusList = Arrays.asList("512");
		} else if (statusCode.equalsIgnoreCase("journalPrinterPaperOut")) {
			statusList = Arrays.asList("502");
		} else if (statusCode.equalsIgnoreCase("inServiceATM")) {
			statusList = Arrays.asList("-101");
		} else if (statusCode.equalsIgnoreCase("outOfServiceATM")) {
			statusList = Arrays.asList("101");
		} else if (statusCode.equalsIgnoreCase("all")) {
			statusList = Arrays.asList("604", "607", "614", "615", "200", "202", "201", "203", "608", "613", "740",
					"741", "742", "743", "744", "745", "746", "750", "751", "755", "756", "757", "758", "759", "9717",
					"7", "600", "605", "999", "717", "500", "503", "510", "512", "502", "-101", "101");
		}

		try {

			ATMAvailabilityDAO istATMDAO = new ATMAvailabilityDAO();

			if (!needs_total) {
				recordListfromISTDB = istATMDAO.getDSFaultDetailsfromISTDB(statusList, pageNum);
			} else if (needs_total) {
				total = istATMDAO.getTotalDSFaultDetailsfromISTDB(statusList, pageNum);
				recordListfromISTDB = istATMDAO.getDSFaultDetailsfromISTDB(statusList, pageNum);
			}

			ATMFltViewListRow fltStatusViewITSDBDTO = new ATMFltViewListRow();

			String tempTermId = "";

			// Iterating and set values from IST DB, set it in List1 -
			// faultStatusViewListOnISTDB
			Iterator recordListfromISTIterator = recordListfromISTDB.iterator();
			while (recordListfromISTIterator.hasNext()) {
				Object[] rowISTDataFromDB = (Object[]) recordListfromISTIterator.next();
				fltStatusViewITSDBDTO = new ATMFltViewListRow();

				tempTermId = (String) rowISTDataFromDB[3];
				tempTermId = StringUtils.rightPad(tempTermId, 16);
				termId.add(tempTermId);

				fltStatusViewITSDBDTO.loadISTDataFromDB(rowISTDataFromDB);
				faultStatusViewListOnISTDB.add(fltStatusViewITSDBDTO);
			}

			MonDbConnectedAtmDAO monDBATMDAO = new MonDbConnectedAtmDAO();
			recordListfromMONDB = monDBATMDAO.getDSBranchSitesFromMONDB(termId);

			Iterator recordListfromMonDBIterator = recordListfromMONDB.iterator();
			ATMFltViewListRow fltStatusViewMONDBDTO = new ATMFltViewListRow();

			while (recordListfromMonDBIterator.hasNext()) {
				Object[] rowMonDBDataFromDB = (Object[]) recordListfromMonDBIterator.next();
				fltStatusViewMONDBDTO = new ATMFltViewListRow();
				fltStatusViewMONDBDTO.loadMonDBDataFromDB(rowMonDBDataFromDB);
				faultStatusViewListMonDB.add(fltStatusViewMONDBDTO);
			}

			// Iterating List 1, compare with List 2 for Term Id and set Branch, Site and
			// Country
			ATMFltViewListRow fltStatusViewPrimaryDTO = new ATMFltViewListRow();
			ATMFltViewListRow fltStatusViewSecondaryDTO = null;

			for (int count = 0; count < faultStatusViewListOnISTDB.size(); count++) {
				fltStatusViewPrimaryDTO = faultStatusViewListOnISTDB.get(count);
				fltStatusViewSecondaryDTO = new ATMFltViewListRow();
				for (int count1 = 0; count1 < faultStatusViewListMonDB.size(); count1++) {
					fltStatusViewSecondaryDTO = faultStatusViewListMonDB.get(count1);
					if (fltStatusViewPrimaryDTO.getTermId()
							.equalsIgnoreCase(fltStatusViewSecondaryDTO.getTermId().trim())) {
						fltStatusViewPrimaryDTO.mergeMonDBDataWithISTDBData(fltStatusViewSecondaryDTO);
						break;
					}
				}
				workRows.add(fltStatusViewPrimaryDTO);
			}

			// int total = workRows.size();
			if (total != 0) {
				workRequest.setLastModified((long) total);
			} else {
				workRequest.setLastModified(-1L);
			}

		} catch (RuntimeException re) {
			log.error("Error While finding running atms", re);
			throw re;
		} catch (Exception re) {
			log.error("Error While finding running atms", re);
			throw re;
		}

	}

	private void loadATMDSRltmCash(WorkRequest workRequest, Map<String, String> params) {
		log.debug("ATM Data Source Real Time cash  Service Handler ");
		workRequest.setLastModified(1L);
		UIMetaData uiMetaData = null;

		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List recordListfromISTDB = null;
		List recordListfromMONDB = null;

		List<ATMRTCashPosListRow> rltmCashListOnISTDB = new ArrayList<ATMRTCashPosListRow>();
		List<ATMRTCashPosListRow> rltmCashListOnMonDB = new ArrayList<ATMRTCashPosListRow>();

		List<String> termId = new ArrayList<String>();

		List<ATMRTCashPosListRow> workRows = getAtmAvailabilityRltmCash(workRequest, uiMetaData);

		// Iterating and set values from IST DB.
		try {
			ATMAvailabilityDAO istATMDAO = new ATMAvailabilityDAO();
			recordListfromISTDB = istATMDAO.getDSRltmCashfromISTDB();

			String tempTermId = "";

			// Iteratring and set values from IST DB, set it in List1 - rltmCashListOnISTDB
			Iterator recordListfromISTIterator = recordListfromISTDB.iterator();
			while (recordListfromISTIterator.hasNext()) {
				Object[] rowISTDataFromDB = (Object[]) recordListfromISTIterator.next();

				ATMRTCashPosListRow rltCashISTDBDTO = new ATMRTCashPosListRow();

				tempTermId = (String) rowISTDataFromDB[3];
				tempTermId = StringUtils.rightPad(tempTermId, 16);
				termId.add(tempTermId);

				rltCashISTDBDTO.loadISTDataFromDB(rowISTDataFromDB);
				rltmCashListOnISTDB.add(rltCashISTDBDTO);
			}

			MonDbConnectedAtmDAO dao = new MonDbConnectedAtmDAO();
			recordListfromMONDB = dao.getDSBranchSitesFromMONDB(termId);

			Iterator recordListfromMonDBIterator = recordListfromMONDB.iterator();

			// Iterating and set values from MON DB - Set it in List2 - rltmCashListOnMonDB
			while (recordListfromMonDBIterator.hasNext()) {
				Object[] rowMonDBDataFromDB = (Object[]) recordListfromMonDBIterator.next();
				ATMRTCashPosListRow rltCashMONDBDTO = new ATMRTCashPosListRow();
				rltCashMONDBDTO.loadMonDBDataFromDB(rowMonDBDataFromDB);
				rltmCashListOnMonDB.add(rltCashMONDBDTO);
			}

			// Iterating List 1, compare with List 2 for Term Id and set Branch, Site and
			// Country
			ATMRTCashPosListRow rltCashPrimaryDTO = new ATMRTCashPosListRow();
			ATMRTCashPosListRow rltCashSecondaryDTO = null;

			for (int count = 0; count < rltmCashListOnISTDB.size(); count++) {
				rltCashPrimaryDTO = rltmCashListOnISTDB.get(count);
				rltCashSecondaryDTO = new ATMRTCashPosListRow();
				for (int count1 = 0; count1 < rltmCashListOnMonDB.size(); count1++) {
					rltCashSecondaryDTO = rltmCashListOnMonDB.get(count1);
					if (rltCashPrimaryDTO.getTermId().equalsIgnoreCase(rltCashSecondaryDTO.getTermId().trim())) {
						rltCashPrimaryDTO.mergeMonDBDataWithISTDBData(rltCashSecondaryDTO);
						break;
					}
				}
				workRows.add(rltCashPrimaryDTO);
			}

			int total = workRows.size();
			if (total != 0) {
				workRequest.setLastModified((long) total);
			} else {
				workRequest.setLastModified(-1L);
			}

		} catch (RuntimeException re) {
			log.error("Error While finding running atms", re);
			throw re;
		} catch (Exception re) {
			log.error("Error While finding running atms", re);
			throw re;
		}

	}

	private void loadATMRltmCashHistory(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Loading ATM Real Time cash position history");

		workRequest.setLastModified(1L);
		UIMetaData uiMetaData = null;

		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		ATMRltmCashPosHistoryRequestDto atmRltmCashPosHistoryRequestDto = getAtmRltmCashPosHistoryReqDto(params);
		List<ATMRTCashPosListRow> rltmCashPosList = new ArrayList<ATMRTCashPosListRow>();
		List<ATMRTCashPosListRow> rltmCashListOnMonDB = new ArrayList<ATMRTCashPosListRow>();
		List<String> termIds = new ArrayList<String>();

		List<ATMRTCashPosListRow> workRows = getAtmRltmCashHistoryWorkRows(workRequest, uiMetaData);

		try {
			MonAtmCashCounterHistoryDAO atmCashCounterHistoryDAO = new MonAtmCashCounterHistoryDAO();
			List rltmCashPosHistory = atmCashCounterHistoryDAO.getRltmCashHistory(atmRltmCashPosHistoryRequestDto);

			String tempTermId = "";

			Iterator rltmCashPosHistoryIterator = rltmCashPosHistory.iterator();
			while (rltmCashPosHistoryIterator.hasNext()) {
				Object[] rowISTDataFromDB = (Object[]) rltmCashPosHistoryIterator.next();

				ATMRTCashPosListRow rltCashPosListRow = new ATMRTCashPosListRow();

				tempTermId = (String) rowISTDataFromDB[3];
				tempTermId = StringUtils.rightPad(tempTermId, 16);
				termIds.add(tempTermId);

				rltCashPosListRow.loadISTDataFromDB(rowISTDataFromDB);
				rltmCashPosList.add(rltCashPosListRow);
			}

			MonDbConnectedAtmDAO connectedAtmDAO = new MonDbConnectedAtmDAO();
			List branchSites = connectedAtmDAO.getDSBranchSitesFromMONDB(termIds);

			Iterator branchSitesIterator = branchSites.iterator();

			while (branchSitesIterator.hasNext()) {
				Object[] rowMonDBDataFromDB = (Object[]) branchSitesIterator.next();
				ATMRTCashPosListRow rltCashMONDBDTO = new ATMRTCashPosListRow();
				rltCashMONDBDTO.loadMonDBDataFromDB(rowMonDBDataFromDB);
				rltmCashListOnMonDB.add(rltCashMONDBDTO);
			}

			ATMRTCashPosListRow rltCashPrimaryDTO = new ATMRTCashPosListRow();
			ATMRTCashPosListRow rltCashSecondaryDTO = null;

			for (int count = 0; count < rltmCashPosList.size(); count++) {
				rltCashPrimaryDTO = rltmCashPosList.get(count);
				rltCashSecondaryDTO = new ATMRTCashPosListRow();
				for (int count1 = 0; count1 < rltmCashListOnMonDB.size(); count1++) {
					rltCashSecondaryDTO = rltmCashListOnMonDB.get(count1);
					if (rltCashPrimaryDTO.getTermId().equalsIgnoreCase(rltCashSecondaryDTO.getTermId().trim())) {
						rltCashPrimaryDTO.mergeMonDBDataWithISTDBData(rltCashSecondaryDTO);
						break;
					}
				}
				workRows.add(rltCashPrimaryDTO);
			}

			int total = 0;
			if (atmRltmCashPosHistoryRequestDto.getTotalCountRequuired()) {
				total = atmCashCounterHistoryDAO.getRltmCashHistoryCount(atmRltmCashPosHistoryRequestDto);
			}

			if (total != 0) {
				workRequest.setLastModified((long) total);
			} else {
				workRequest.setLastModified(-1L);
			}

		} catch (RuntimeException re) {
			log.error("Error loading real time cash position history", re);
			throw re;
		} catch (Exception re) {
			log.error("Error loading real time cash position history", re);
			throw re;
		}
	}
	
	public void load(WorkRequest workRequest, Map<String, String> params) {

		log.debug("Load ATM Availability Details");
		String productId = params.get("productId");
		log.debug("productId" + productId);
		String siteId = params.get("siteId");
		log.debug("siteId" + siteId);
		MonDbConnectedAtmDAO dao =new MonDbConnectedAtmDAO();
		List<String> connectedAtms = dao.getMonDbConnectedATMList(); //ATMDashBoardQuery001-ATM_CONTD_ATMLST
		workRequest.setLastModified(1L);			
		UIMetaData uiMetaData=null;

		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		ATMAvailabilityDAO $dao = new ATMAvailabilityDAO();
		
		ATMAvailable atmAvailable = new  ATMAvailable();		
		List<String> atmSummaryList=!connectedAtms.isEmpty()?connectedAtms.stream().map(atm -> atm.trim()).collect(Collectors.toList()):connectedAtms;
		
		List<String> upATMTerminals = $dao.getUpTerminals(atmSummaryList.toArray(new String[0])); //ATMDashBoardQuery002 - ATM_UP_TRMNLS
		
		upATMTerminals = !upATMTerminals.isEmpty() ? upATMTerminals.stream().map(upAtm -> StringUtils.rightPad(upAtm, 16)).collect(Collectors.toList()):upATMTerminals;
		$dao.getAtmDetailsByAvailability(atmAvailable,atmSummaryList.toArray(new String[0])); //ATMDashBoardQuery003 & 004 & 005 - ATM_TOTL_BYSWTCH &ATM_UP_BYSWTCH & ATM_OOS_BYSWTCH
		List<TerminalsBySite> terminalListBySite = dao.getTerminalsPercentageBySite(upATMTerminals.toArray(new String[0])); //ATMDashBoardQuery006 - ATM_TRMNL_PRCNT_BYSITE
		List<TerminalsByBranch> terminalListByBranch = dao.getTerminalsPercentageByBranch(upATMTerminals.toArray(new String[0])); //ATMDashBoardQuery007 - ATM_TRMNL_PRCNT_BYBRNCH
		List<ConguredATMByMake> configuredATMList=$dao.getConfiguredATMByMake(); //ATMDashBoardQuery008 - ATM_CNFGD_BYMAKE - ATM_TOTL_RUN_BYMKE
		List<RunningATMByMake> runningATMByMakeList = $dao.getTotalRunningATMByMake(atmSummaryList.toArray(new String[0])); //ATMDashBoardQuery009 - ATM_FLT_COUNT
		List<ATMByFaultWise> atmByFaultList = $dao.getFaultWiseATMCount(); //ATMDashBoardQuery010
		ATMAvailabilityDto dto = new ATMAvailabilityDto();
		dto.load(atmAvailable);
		dto.loadBySite(terminalListBySite);
		dto.loadByBranch(terminalListByBranch);
		dto.loadByMake(runningATMByMakeList, configuredATMList);
		dto.loadATMByFaultWise(atmByFaultList);
		List<ATMAvailabilityDto> workRows = getAtmAvailabilityList(workRequest, uiMetaData);
		workRows.add(dto);
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
			throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		currentfield = fields.get("productId");
		fieldValue = params.get("productId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("siteId");
		fieldValue = params.get("siteId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	private List<ATMAvailabilityDto> getAtmAvailabilityList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.ATM_AVAILABILITY_COL);
		workCollection.setSectionId(MonitorConstants.ATM_AVAILABILITY_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.ATM_AVAILABILITY_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<ATMAvailabilityDto> workRows = new ArrayList<ATMAvailabilityDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.ATM_AVAILABILITY_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<ATMFltViewListRow> getAtmAvailabilityList1(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(CustomConstants.ATMFLTVIEWCOL);
		workCollection.setSectionId(CustomConstants.ATMFLTVIEWSEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(CustomConstants.ATMFLTVIEWTAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<ATMFltViewListRow> workRows = new ArrayList<ATMFltViewListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, CustomConstants.ATMFLTVIEWCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<ATMRTCashPosListRow> getAtmAvailabilityRltmCash(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(CustomConstants.ATMRTCASHCOL);
		workCollection.setSectionId(CustomConstants.ATMRTCASHSEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(CustomConstants.ATMRTCASHTAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<ATMRTCashPosListRow> workRows = new ArrayList<ATMRTCashPosListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, CustomConstants.ATMRTCASHCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private List<ATMRTCashPosListRow> getAtmRltmCashHistoryWorkRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		log.debug("Prepareing WorkCollection for ATM Real Time Cash Position History");

		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(CustomConstants.ATMRTCASHHISCOL);
		workCollection.setSectionId(CustomConstants.ATMRTCASHHISSEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(CustomConstants.ATMRTCASHHISTAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<ATMRTCashPosListRow> workRows = new ArrayList<ATMRTCashPosListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, CustomConstants.ATMRTCASHHISCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	public HashMap<String, String> getDBMapping() {
		HashMap<String, String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product", "product");
		dtoMapping.put("nodeId", "nodeId");
		dtoMapping.put("taskName", "taskName");
		dtoMapping.put("taskType", "taskType");
		dtoMapping.put("pId", "pId");
		return dtoMapping;
	}

	private ATMRltmCashPosHistoryRequestDto getAtmRltmCashPosHistoryReqDto(Map<String, String> params) {

		String terminalId = params.get("terminalId").trim();
		String instId = params.get("instId").trim();
		String unit = params.get("unit").trim();
		String groupName = params.get("grpName").trim();
		boolean totalCountRequired = "Y".equalsIgnoreCase(params.get("ist_total"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNumber = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		Integer atmUnit = isEmpty(unit) ? 0 : Integer.valueOf(unit);

		ATMRltmCashPosHistoryRequestDto atmRltmCashPosHistoryRequestDto = new ATMRltmCashPosHistoryRequestDto();
		DateTimeRequestDto dateTimeRequestDto = PaymonUtils.getRequestedDateTime(params);

		atmRltmCashPosHistoryRequestDto.setDateTimeRequest(dateTimeRequestDto);
		atmRltmCashPosHistoryRequestDto.setInstitutionId(instId);
		atmRltmCashPosHistoryRequestDto.setTerminalId(terminalId);
		atmRltmCashPosHistoryRequestDto.setGroupName(groupName);
		atmRltmCashPosHistoryRequestDto.setUnit(atmUnit);
		atmRltmCashPosHistoryRequestDto.setPageNumber(pageNumber);
		atmRltmCashPosHistoryRequestDto.setTotalCountRequired(totalCountRequired);
		return atmRltmCashPosHistoryRequestDto;
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}
}