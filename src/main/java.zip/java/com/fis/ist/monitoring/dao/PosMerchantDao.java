package com.fis.ist.monitoring.dao;

import static com.fis.ist.common.OracleDaoConstants.DEPRECATION;
import static com.fis.ist.common.OracleDaoConstants.RAWTYPES;
import static com.fis.ist.common.OracleDaoConstants.UNCHECKED;

import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.POSMerchantDetails;


@SuppressWarnings({RAWTYPES,UNCHECKED,DEPRECATION})
public class PosMerchantDao extends MonitorBaseDAO<POSMerchantDetails, Integer> {	
	private static final ISTLogger log = ISTLogger.getLogger(PosMerchantDao.class);
	
	//Get POS Merchant Details
	public List<POSMerchantDetails> getPOSMerchantsDetails(String institutionId, String parentEntityId, String entityLevel, String entityId, String dbaName, String creationDateFrom, 
			String creationDateTo, String terminationDateFrom, String terminationDateTo, String externalEntityId, String entityStatus, String fromDateFormat, String toDateFormat, int pageNum, Boolean setPaging) {
		log.debug("Entering getPOSMerchantsDetails in PosMerchantDao");
		List<POSMerchantDetails> posMerchantDetailsList = null;
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("POS_MERCH_DETAIL");
	
			queryString = setQueryFilter(queryString, institutionId, entityId, parentEntityId, externalEntityId, entityLevel, 
					dbaName, entityStatus, creationDateFrom, creationDateTo, terminationDateFrom, terminationDateTo, fromDateFormat, toDateFormat);	
			
			parentEntityId = convertWildSearchString(parentEntityId);
			entityId = convertWildSearchString(entityId);
			externalEntityId = convertWildSearchString(externalEntityId);
			
			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("institutionId", StandardBasicTypes.STRING)
					.addScalar("entityId", StandardBasicTypes.STRING)
					.addScalar("entityLevel", StandardBasicTypes.LONG)
					.addScalar("entityName", StandardBasicTypes.STRING)
					.addScalar("entityDbaName", StandardBasicTypes.STRING)
					.addScalar("settlPlanId", StandardBasicTypes.LONG)
					.addScalar("entityStatus", StandardBasicTypes.STRING)
					.addScalar("parentEntityId", StandardBasicTypes.STRING)
					.addScalar("externalEntityId", StandardBasicTypes.STRING)
					.addScalar("creationDate", StandardBasicTypes.STRING)
					.addScalar("expStartDate", StandardBasicTypes.STRING)
					.addScalar("terminationDate", StandardBasicTypes.STRING)
					.addScalar("companyType", StandardBasicTypes.STRING)
					.addScalar("processingType", StandardBasicTypes.STRING)
					.addScalar("taxId", StandardBasicTypes.STRING);
			
			setQueryParams(queryObject, institutionId, entityId, parentEntityId, externalEntityId, entityLevel, 
					dbaName, entityStatus, creationDateFrom, creationDateTo, terminationDateFrom, terminationDateTo, fromDateFormat, toDateFormat);

			if (setPaging) {
				setPaging(queryObject, pageNum);
			}
			
			posMerchantDetailsList = (List<POSMerchantDetails>) queryObject.setResultTransformer(Transformers.aliasToBean(POSMerchantDetails.class)).list();
		} catch (RuntimeException re) {
			log.error("Error While finding List of POS Merchant Details", re);
			throw re;
		}
		
		return posMerchantDetailsList;
	}
	
	
	
	public Integer getPosMerchantsDetailsCount(String institutionId, String parentEntityId, String entityLevel, String entityId, String dbaName, String creationDateFrom, 
			String creationDateTo, String terminationDateFrom, String terminationDateTo, String externalEntityId, String entityStatus, String fromDateFormat, String toDateFormat) {

		log.debug("Entering getPosMerchantsDetailsCount in PosMerchantDao");
		Integer count=null;
		try 
		{
			String queryString = SqlQueryProvider.getDBSqlQuery("POS_MERCH_COUNT");
			
			queryString = setQueryFilter(queryString, institutionId, entityId, parentEntityId, externalEntityId, entityLevel, 
					dbaName, entityStatus, creationDateFrom, creationDateTo, terminationDateFrom, terminationDateTo, fromDateFormat, toDateFormat);
			
			parentEntityId = convertWildSearchString(parentEntityId);
			entityId = convertWildSearchString(entityId);
			externalEntityId = convertWildSearchString(externalEntityId);
						
			Query queryObject = getSession().createSQLQuery(queryString)
									.addScalar("COUNT", StandardBasicTypes.INTEGER);
			
			setQueryParams(queryObject, institutionId, entityId, parentEntityId, externalEntityId, entityLevel, 
					dbaName, entityStatus, creationDateFrom, creationDateTo, terminationDateFrom, terminationDateTo, fromDateFormat, toDateFormat);
			
			count = queryObject.uniqueResult() != null?(Integer)queryObject.uniqueResult():0;			

		} catch (RuntimeException re) {
			log.error("Error While finding total number of POS Merchant Details Count", re);
			throw re;
		}
		log.debug("Exiting getPosMerchantsDetailsCount in PosMerchantDao");
		return count;
	}
	
	
	private static String setQueryFilter(String queryString, String institutionId, String entityId, String parentEntityId, String externalEntityId, String entityLevel,  
			String dbaName, String entityStatus, String creationDateFrom, String creationDateTo, String terminationDateFrom, String terminationDateTo, String fromDateFormat, String toDateFormat) {
		
		StringBuffer queryBuffer = new StringBuffer(" WHERE 1= 1 ");
						
		if (!isEmpty(institutionId) && !institutionId.equals("*")) {
            queryBuffer.append(" and institution_Id = :institutionId ");  
        }
		
		if (!isEmpty(parentEntityId)) {
            queryBuffer.append(selectQueryString(parentEntityId, "ParentEntity"));  
        }
		
		if (!isEmpty(entityId)) {
			queryBuffer.append(selectQueryString(entityId, "EntityId")); 
        }	
		
		if (!isEmpty(externalEntityId)) {
            queryBuffer.append(selectQueryString(externalEntityId, "ExternalEntity")); 
        }
		
		if (!isEmpty(entityLevel)) 
			queryBuffer.append(" AND entity_Level = :entityLevel ");
		
		if(!isEmpty(dbaName))
			queryBuffer.append(" AND entity_dba_Name = :dbaName ");
		
		if(!isEmpty(entityStatus))
			queryBuffer.append(" AND entity_Status = :entityStatus ");
		
		if (PaymonUtils.isOracleDb()) {
			if(!isEmpty(creationDateFrom) && !isEmpty(creationDateTo)) 
				queryBuffer.append(" AND ( creation_Date between to_date(:creationDateFrom, :fromDateFormate) and to_date(:creationDateTo, :toDateFormate) ) ");
			
			if(!isEmpty(terminationDateFrom) && !isEmpty(terminationDateTo))
				queryBuffer.append(" AND ( termination_Date between to_date(:terminationDateFrom, :fromDateFormate) and to_date(:terminationDateTo, :toDateFormate) ) ");
		}
		else if (PaymonUtils.isPostgressDb()) {
			if(!isEmpty(creationDateFrom) && !isEmpty(creationDateTo))
				queryBuffer.append(" AND ( creation_date between to_timestamp(:creationDateFrom, :fromDateFormate) and to_timestamp(:creationDateTo, :toDateFormate) ) ");
						
			if(!isEmpty(terminationDateFrom) && !isEmpty(terminationDateTo)) 
				queryBuffer.append(" AND ( termination_Date between to_timestamp(:terminationDateFrom, :fromDateFormate) and to_timestamp(:terminationDateTo, :toDateFormate) ) ");
			
		}
		queryString = queryString.replaceAll("FILTER_QUERY", queryBuffer.toString());
		return queryString;
		
	}
	
	
	private static void setQueryParams(Query queryObject, String institutionId, String entityId, String parentEntityId, String externalEntityId, String entityLevel,  
			String dbaName, String entityStatus, String creationDateFrom, String creationDateTo, String terminationDateFrom, String terminationDateTo, String fromDateFormate, String toDateFormate ) {

		if (!isEmpty(institutionId) && !institutionId.equals("*") ) {
			queryObject.setParameter("institutionId", institutionId); 
        }
						
		if (!isEmpty(parentEntityId)) {
			queryObject.setParameter("parentEntityId", parentEntityId);  
        }
		
		if (!isEmpty(entityId)) {
			queryObject.setParameter("entityId", entityId); 
        }	
		
		if (!isEmpty(externalEntityId)) {
			queryObject.setParameter("externalEntityId", externalEntityId); 
        }
		
		if (!isEmpty(entityLevel)) 
			queryObject.setParameter("entityLevel", Long.parseLong(entityLevel));
		
		if(!isEmpty(dbaName))
			queryObject.setParameter("dbaName", dbaName);
		
		if(!isEmpty(entityStatus))
			queryObject.setParameter("entityStatus", entityStatus);
		
		if(!isEmpty(creationDateFrom) && !isEmpty(creationDateTo)) {
			queryObject.setParameter("creationDateFrom", creationDateFrom);
			queryObject.setParameter("creationDateTo", creationDateTo);			
			
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
		}
		if(!isEmpty(terminationDateFrom) && !isEmpty(terminationDateTo)) {
			queryObject.setParameter("terminationDateFrom", terminationDateFrom);
			queryObject.setParameter("terminationDateTo", terminationDateTo);
			
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
		}
		
	}
	
	private static String selectQueryString(String value, String type) {
		if(type.equals("ParentEntity")) {
			//parent_entity_id
			if (value.indexOf("*") > -1) 
	        	return " AND parent_entity_id like :parentEntityId ";        	
	        else 
	        	return " AND parent_entity_id = :parentEntityId "; 
		}
		else if(type.equals("EntityId")) {
			//entity_id
			if (value.indexOf("*") > -1) 
	        	return " AND entity_id like :entityId ";        	
	        else 
	        	return " AND entity_id = :entityId "; 
		}
		else if (type.equals("ExternalEntity")) {
			if (value.indexOf("*") > -1) 
	        	return " AND external_entity_id like :externalEntityId ";        	
	        else 
	        	return " AND external_entity_id = :externalEntityId "; 
		}
		
		return "";
	}	

	
	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}

	private static String convertWildSearchString(String value) {
		if (isEmpty(value))
			return value;
		
		if (hasOnlyAsterisks(value)) {
			return "";
		}
		
		return value.replace("*", "%");
	}
	
	private static boolean hasOnlyAsterisks(String input) {
		for(int i = 0; i < input.length(); i++) {
			if (input.charAt(i) != '*') {
				return false;
			}
		}
		return true;
	}
		
	public Class<POSMerchantDetails> getEntityClass() {
		return POSMerchantDetails.class;
	}

}
