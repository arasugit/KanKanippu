package com.fis.ist.monitoring.dto;

public class PosTransCountDto implements java.io.Serializable {
private static final long serialVersionUID = 1L;
	
	private String transactionDate;
	private Integer approvedTrans;
	private Integer declinedTrans;
	private Integer reversedTrans;
	private Integer totalTrans;

	public String getTransactionDate() {
		return transactionDate;
	}
	
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	public Integer getApprovedTrans() {
		return approvedTrans;
	}
	
	public void setApprovedTrans(Integer approvedTrans) {
		this.approvedTrans = approvedTrans;
	}
	
	public Integer getDeclinedTrans() {
		return declinedTrans;
	}
	
	public void setDeclinedTrans(Integer declinedTrans) {
		this.declinedTrans = declinedTrans;
	}
	
	public Integer getReversedTrans() {
		return reversedTrans;
	}
	
	public void setReversedTrans(Integer reversedTrans) {
		this.reversedTrans = reversedTrans;
	}
	
	public Integer getTotalTrans() {
		return totalTrans;
	}
	
	public void setTotalTrans(Integer totalTrans) {
		this.totalTrans = totalTrans;
	}
}
