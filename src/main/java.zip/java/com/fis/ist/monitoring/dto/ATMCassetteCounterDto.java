package com.fis.ist.monitoring.dto;

import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.domain.ATMCassetteCounter;

public class ATMCassetteCounterDto implements java.io.Serializable {
	
	private static final long serialVersionUID = 6803023989652998245L;
	
	private String institutionId;
	private String groupName;
	private Long unit;
	private Long cassetteNbr;
	private Long itemsRejected;
	private Long cashIncrement;
	private Long cashDecrement;
	private Long cashOut;
	private Long currentCashBalance;
	private Long startCashBalance;
	private Long previousCashBalance;
	private String resetTime;
	private Long recycleCount;
	private Long previousRecycleCount;
	
	public ATMCassetteCounterDto() {}
	
	
	public String getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Long getUnit() {
		return unit;
	}
	public void setUnit(Long unit) {
		this.unit = unit;
	}
	public Long getCassetteNbr() {
		return cassetteNbr;
	}
	public void setCassetteNbr(Long cassetteNbr) {
		this.cassetteNbr = cassetteNbr;
	}
	public Long getItemsRejected() {
		return itemsRejected;
	}
	public void setItemsRejected(Long itemsRejected) {
		this.itemsRejected = itemsRejected;
	}
	public Long getCashIncrement() {
		return cashIncrement;
	}
	public void setCashIncrement(Long cashIncrement) {
		this.cashIncrement = cashIncrement;
	}
	public Long getCashDecrement() {
		return cashDecrement;
	}
	public void setCashDecrement(Long cashDecrement) {
		this.cashDecrement = cashDecrement;
	}
	public Long getCashOut() {
		return cashOut;
	}
	public void setCashOut(Long cashOut) {
		this.cashOut = cashOut;
	}
	public Long getCurrentCashBalance() {
		return currentCashBalance;
	}
	public void setCurrentCashBalance(Long currentCashBalance) {
		this.currentCashBalance = currentCashBalance;
	}
	public Long getStartCashBalance() {
		return startCashBalance;
	}
	public void setStartCashBalance(Long startCashBalance) {
		this.startCashBalance = startCashBalance;
	}
	public Long getPreviousCashBalance() {
		return previousCashBalance;
	}
	public void setPreviousCashBalance(Long previousCashBalance) {
		this.previousCashBalance = previousCashBalance;
	}
	public String getResetTime() {
		return resetTime;
	}
	public void setResetTime(String resetTime) {
		this.resetTime = PaymonUtils.getFormattedResponseDateTime(resetTime);
	}
	public Long getRecycleCount() {
		return recycleCount;
	}
	public void setRecycleCount(Long recycleCount) {
		this.recycleCount = recycleCount;
	}
	public Long getPreviousRecycleCount() {
		return previousRecycleCount;
	}
	public void setPreviousRecycleCount(Long previousRecycleCount) {
		this.previousRecycleCount = previousRecycleCount;
	}
	
	public void load(ATMCassetteCounter atmCassetteCounter){
		setInstitutionId(atmCassetteCounter.getInstitutionId());
		setGroupName(atmCassetteCounter.getGroupName());
		setUnit(atmCassetteCounter.getUnit());
		setCassetteNbr(atmCassetteCounter.getCassetteNbr());
		setItemsRejected(atmCassetteCounter.getItemsRejected());
		setCashIncrement(atmCassetteCounter.getCashIncrement());
		setCashDecrement(atmCassetteCounter.getCashDecrement());
		setCashOut(atmCassetteCounter.getCashOut());
		setCurrentCashBalance(atmCassetteCounter.getCurrentCashBalance());
		setPreviousCashBalance(atmCassetteCounter.getPreviousCashBalance());
		setStartCashBalance(atmCassetteCounter.getStartCashBalance());
		setResetTime(atmCassetteCounter.getResetTime());
		setRecycleCount(atmCassetteCounter.getRecycleCount());
		setPreviousRecycleCount(atmCassetteCounter.getPreviousRecycleCount());
		
	}

}
