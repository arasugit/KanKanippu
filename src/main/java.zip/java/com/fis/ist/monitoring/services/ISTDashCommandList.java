package com.fis.ist.monitoring.services;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.customProject.services.handler.ISTDashCommandListHandler;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

public class ISTDashCommandList extends CRUDSubService
{
    private static final ISTLogger log = ISTLogger.getLogger(ISTDashCommandList.class);
   	public WorkRequest getService (	UserContext userContext, String requestType, String action,	Map<String, String>requestParams ) throws Exception
	{
   		
   		String searchListType = requestParams.get("type"); 
   		
   		HttpServletRequest request = HTTPRequestGetter.getRequest();
	 	String productId = (String) request.getSession(false).getAttribute("product_id");
	 	String nodeName = (String) request.getSession(false).getAttribute("node_name");
	 		 	
   		requestParams.put("product", productId == null ? "" : productId);
   		requestParams.put("nodeId", nodeName == null ? "*" : nodeName);
   		   		   		
   		log.debug("Product Id" + " : " + productId + ", Node Id/Name" + " : " + nodeName + " & By Loading ISTDashCommandList - getService() : " + requestType + " :" + action + " : " +  requestParams); 
   		
   		if(productId.equals("ISTCLR") || productId.equals("ISTMAS")) {
   			requestParams.put("nodeId", "*");
   		}
   		
		WorkRequest workReq = null; 
		ISTDashCommandListHandler ddh = new ISTDashCommandListHandler();

		if (action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = ddh.getServerMailList(userContext, requestParams);
		} else {
			log.error("**** ISTDashCommandList Page List: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}
		
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}
}