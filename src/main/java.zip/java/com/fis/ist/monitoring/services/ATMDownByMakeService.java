package com.fis.ist.monitoring.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.services.handler.ATMDownByMakeHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class ATMDownByMakeService extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(ATMDownByMakeService.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		ATMDownByMakeHandler ath = new ATMDownByMakeHandler();

		if (action.compareTo(MonitorConstants.ACTION_QUERY) == 0) {
			workReq = ath.getDownByMakeATM(userContext, requestParams);
		} else {
			log.error("**** ATM DOwn By Make Service: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}

		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}
}