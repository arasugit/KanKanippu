package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.services.MonitorConfigService;
import com.fis.ist.monitoring.dao.TransactionDetailsDAO;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.DateTimeRequestDto;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.monitoring.dto.TransactionStatisticsListItem;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class SuccessfulTransactionsHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(SuccessfulTransactionsHandler.class);
	private static String reqTypeId = MonitorConstants.TRANS_STATS_SUC_REQ;
	private static String formAuthId = "TXNSSC_REQ";

	public SuccessfulTransactionsHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getSuccessfulTransactions(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	
	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.TRANS_STATS_SUC_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.TRANS_STATS_SUC_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.TRANS_STATS_SUC_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.TRANS_STATS_SUC_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.TRANS_STATS_SUC_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map params) {
		log.debug("Load Successful And Rejected Transactions Count");

		String screenType = (String) params.get("screenType");
		TransactionsDAO dao = new TransactionsDAO();

		boolean needs_total = "Y".equalsIgnoreCase((String) params.get("ist_total"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		List<String> txnSrcList = new ArrayList<>();
		List<String> txnDestList = new ArrayList<>();
		List<String> respCodeList = new ArrayList<>();
		List<String> responseCodeList = null;

		Object responseCodeGroup = params.get("responseCodeGroup");
		Object responseCode = params.get("responseCode");

		if (responseCodeGroup.toString().equals("")) {
			responseCodeList = new ArrayList<String>();
		} else {
			responseCodeList = (List<String>) params.get("responseCodeGroup");
		}

		if (responseCodeList.size() == 0) {
			if (responseCode.toString().equals("")) {
				responseCodeList = new ArrayList<String>();
			} else {
				responseCodeList = (List<String>) params.get("responseCode");
			}
		}

		List terminalList = dao.getAcquirerTxnSRC("ISTSWT", "TERMINAL_INSTITUTION");
		List onusInstList = dao.getAcquirerTxnSRC("ISTSWT", "ONUS_INSTITUTION");

		// Adding the records in the acqList & txnSrcList
		for (Iterator iterator = terminalList.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();
			txnSrcList.add((String) object[0]);
		}

		for (Iterator iterator = onusInstList.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();
			txnDestList.add((String) object[0]);
		}

		String tempText = "";
		String[] res = null;

		for (int i = 0; i < responseCodeList.size(); i++) {
			tempText = responseCodeList.get(i);
			if (tempText != null) {
				res = tempText.split("[,]", 0);

				for (String myStr : res) {
					respCodeList.add(myStr);
				}
			}
		}

		MonitorConfigService configService = new MonitorConfigService();
		List<String> businessDeclineList = configService.getDeclineRespCodes(dao, MonitorConstants.BD_RESP_CODE_LIST);
		List<String> technicalDeclineList = configService.getDeclineRespCodes(dao, MonitorConstants.TD_RESP_CODE_LIST);

		UIMetaData uiMetaData = getUiMetaData();
		String isTxnDetailReq = (String) params.get("isTxnDetailReq");
		boolean loadDetails = "true".equalsIgnoreCase(isTxnDetailReq);

		DateTimeRequestDto dateTimeRequest = PaymonUtils.getRequestedDateTime(params);

		if (loadDetails) {
			loadTransactionDetails(dao, workRequest, params, uiMetaData, businessDeclineList, technicalDeclineList,
					txnSrcList, screenType, dateTimeRequest.getFormattedFromDate(),
					dateTimeRequest.getFormattedToDate(), dateTimeRequest.getFromDbDateFormat(),
					dateTimeRequest.getToDbDateFormat());
		}

		if (loadDetails && !dateTimeRequest.getToDate().after(new Date())) {
			return;
		}

		if (needs_total) {
			total = dao.getCombinedTransactionsCount(txnSrcList, txnDestList, businessDeclineList, technicalDeclineList,
					respCodeList, screenType, dateTimeRequest.getFormattedFromDate(),
					dateTimeRequest.getFormattedToDate(), dateTimeRequest.getFromDbDateFormat(),
					dateTimeRequest.getToDbDateFormat());
		}

		List recordList = dao.getCombinedTransactions(txnSrcList, txnDestList, businessDeclineList,
				technicalDeclineList, respCodeList, screenType, dateTimeRequest.getFormattedFromDate(),
				dateTimeRequest.getFormattedToDate(), dateTimeRequest.getFromDbDateFormat(),
				dateTimeRequest.getToDbDateFormat(), pageNum);

		if (recordList.size() == 0)
			log.debug("No records found !!!");

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		TransactionListRow dto = null;
		Object[] result = null;
		List<TransactionListRow> workRows = getTransactionList(workRequest, uiMetaData,
				MonitorConstants.TRANS_STATS_SUC_COL);

		for (int i = 0; i < recordList.size(); i++) {
			dto = new TransactionListRow();
			result = (Object[]) recordList.get(i);
			dto.loadTxns(result);
			workRows.add(dto);
		}
	}

	private void loadTransactionDetails(TransactionsDAO dao, WorkRequest workRequest, Map<String, String> params,
			UIMetaData uiMetaData, List<String> businessDeclineList, List<String> technicalDeclineList,
			List<String> txnSrcList, String screenType, String fromDate, String toDate, String fromDateFormate,
			String toDateFormate) {
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		String txndest = params.get("txndest");
		String issuer = params.get("issuer");
		boolean excludeTxnSrcs = screenType.equalsIgnoreCase("ISSUING");
		int total = 0;
		TransactionDetailsDAO txnDetailDao = new TransactionDetailsDAO();

		if (needs_total) {
			total = txnDetailDao.getTxnLogsCountForSuccessAndRejTrans(fromDate, toDate, fromDateFormate, toDateFormate,
					txnSrcList, excludeTxnSrcs, txndest, issuer);
		}

		workRequest.setMessageId(String.valueOf(total));

		List txnDetails = txnDetailDao.getTxnLogsForSuccessAndRejTrans(fromDate, toDate, fromDateFormate, toDateFormate,
				txnSrcList, excludeTxnSrcs, txndest, issuer, pageNum);
		if (txnDetails == null || txnDetails.size() == 0) {
			return;
		}
		
		TransactionStatisticsListItem dto = null; 
		Object[] result = null;
		MonitorConfigService configService = new MonitorConfigService();
		List<TransactionStatisticsListItem> workRows = getTransactionDetail(workRequest, uiMetaData);
		List<TransactionStatisticsListItem> respCodesAndDesc = configService.getResponseCodesAndDesc(dao);
		
		for (int i = 0; i < txnDetails.size(); i++) {
			dto = new TransactionStatisticsListItem();
			result = (Object[]) txnDetails.get(i);
			dto.loadTxnLogDetails(result);
			setDeclineCategory(businessDeclineList, technicalDeclineList, dto);
			setRespCodeDesc(respCodesAndDesc, dto);
			workRows.add(dto);
		}
	}
	
	private void setDeclineCategory(List<String> businessDeclineList, List<String> technicalDeclineList, TransactionStatisticsListItem dto)
	{
		String declineCategory = PaymonUtils.getDeclineCategoryByRespCode(businessDeclineList, technicalDeclineList, dto.getRespCode());
		dto.setDeclineCategory(declineCategory);
	}
	
	private void setRespCodeDesc(List<TransactionStatisticsListItem> respCodesAndDesc, TransactionStatisticsListItem dto)
	{
		String respCodeDesc = PaymonUtils.getRespDescByCode(respCodesAndDesc, dto.getRespCode());
		dto.setRespCodeDesc(respCodeDesc);
	}

	private UIMetaData getUiMetaData() {
		UIMetaData uiMetaData = null;

		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		return uiMetaData;
	}

	private String If(boolean b) {
		// TODO Auto-generated method stub
		return null;
	}

	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		return validateFields(fieldDataMap);
	}

	private List<TransactionListRow> getTransactionList(WorkRequest workRequest, UIMetaData uiMetaData,
			String collectionName) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(collectionName);
		workCollection.setSectionId(MonitorConstants.TRANS_STATS_SUC_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TRANS_STATS_SUC_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionListRow> workRows = new ArrayList<TransactionListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, collectionName);
		workCollection.setRows(workRows);
		return workRows;
	}
	
	private List<TransactionStatisticsListItem> getTransactionDetail(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.TRANS_STATS_SUC_DTL_COL);
		workCollection.setSectionId(MonitorConstants.TRANS_STATS_SUC_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TRANS_STATS_SUC_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionStatisticsListItem> workRows = new ArrayList<TransactionStatisticsListItem>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.TRANS_STATS_SUC_DTL_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}
