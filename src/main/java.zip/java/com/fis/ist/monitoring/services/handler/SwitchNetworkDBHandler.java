package com.fis.ist.monitoring.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.MonDbConnectedAtmDAO;
import com.fis.ist.monitoring.dao.SwitchNetworkDBDAO;
import com.fis.ist.monitoring.dto.SwitchNetworkDBDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class SwitchNetworkDBHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(SwitchNetworkDBHandler.class);
	private static String reqTypeId = MonitorConstants.ATMNTWRKDS;
	private static String formAuthId = "ATMNTWRKDS";

	public SwitchNetworkDBHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getSwitchNetworkDBAvailability(UserContext userContext, Map<String, String> params)
			throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.ATMNTWRKDS_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.ATMNTWRKDS);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.ATMNTWRKDS);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.ATMNTWRKDS_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.ATMNTWRKDS_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load ATM Availability Details");
		String productId = params.get("productId");
		log.debug("productId" + productId);
		String siteId = params.get("siteId");
		log.debug("siteId" + siteId);
		MonDbConnectedAtmDAO dao = new MonDbConnectedAtmDAO();
		List<String> connectedAtms = dao.getMonDbConnectedATMList();
		workRequest.setLastModified(1L);
		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List<SwitchNetworkDBDto> workRows = getSwitchNetworkAvailabilityList(workRequest, uiMetaData);

		SwitchNetworkDBDAO switchNetworkDBDAO = new SwitchNetworkDBDAO();
		SwitchNetworkDBDto switchNetworkDBDto = new SwitchNetworkDBDto();

		List<SwitchNetworkDBDto> taskCommandTypes = switchNetworkDBDAO.getTypeOfTaskCmd(params); // Query -
																									// SWITCH_COMMAND_TSKCMD_TYPE
		List<SwitchNetworkDBDto> binStatusUpDown = switchNetworkDBDAO.getTypeOfBinStatus(params); // Query -
																									// SWITCH_COMMAND_BINSTATUS_TYPE
		List<SwitchNetworkDBDto> dbDetails = switchNetworkDBDAO.getDBDetails(params); // Query -
																						// SWITCH_COMMAND_DB_DETAILS
		List<SwitchNetworkDBDto> portDetails = switchNetworkDBDAO.getPortDetails(params); // Query - SWITCH_PORT_DETAILS
		List<SwitchNetworkDBDto> traceDetails = switchNetworkDBDAO.getTraceLevelDetails(params); // Query
																									// -SWITCH_TRACE_DETAILS
		List<SwitchNetworkDBDto> binStatusUpDownByInstId = switchNetworkDBDAO.getTypeOfBinStatusByInstId(params); // Query
																													// -
																													// SWITCH_COMMAND_BINSTATUS_TYPE_BY_INSTID
		// Commented as db script is running for more than 2 minutes.
		// List<SwitchNetworkDBDto> debugByFileName =
		// switchNetworkDBDAO.getDebugInfoByFileName(params); //Query -
		// SWITCH_DEBUGINFO_BY_FILENAME
		List<SwitchNetworkDBDto> resourcesUsed = switchNetworkDBDAO.getResourcesUsed(params); // Query -
																								// SWITCH_RESOURCES_USED
		List<SwitchNetworkDBDto> allocatedBasics = switchNetworkDBDAO.getAllocatedBasicsConfigurations(params); // Query
																												// -
																												// SWITCH_ALLOCATED_BASIC_CONFIGURATIONS

		switchNetworkDBDto.loadTaskCommandTypes(taskCommandTypes);
		switchNetworkDBDto.loadBinStatusTypes(binStatusUpDown);
		switchNetworkDBDto.loadBinStatusTypesByInstId(binStatusUpDownByInstId);
		switchNetworkDBDto.loadDBDetails(dbDetails);
		switchNetworkDBDto.loadPortDetails(portDetails);
		switchNetworkDBDto.loadTraceLevelDetails(traceDetails);
		switchNetworkDBDto.resourceUsedInfo(resourcesUsed);
		switchNetworkDBDto.allocatedBasicsConfigurations(allocatedBasics);
		
		workRows.add(switchNetworkDBDto);
	}

	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
			throws Exception {
		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		currentfield = fields.get("productId");
		fieldValue = params.get("productId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("siteId");
		fieldValue = params.get("siteId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	private List<SwitchNetworkDBDto> getSwitchNetworkAvailabilityList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.ATMNTWRKDSTAB_COL);
		workCollection.setSectionId(MonitorConstants.ATMNTWRKDSTAB_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.ATMNTWRKDS_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<SwitchNetworkDBDto> workRows = new ArrayList<SwitchNetworkDBDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.ATMNTWRKDSTAB_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	public HashMap<String, String> getDBMapping() {
		HashMap<String, String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product", "product");
		dtoMapping.put("nodeId", "nodeId");
		dtoMapping.put("taskName", "taskName");
		dtoMapping.put("taskType", "taskType");
		dtoMapping.put("pId", "pId");
		return dtoMapping;
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}
}
