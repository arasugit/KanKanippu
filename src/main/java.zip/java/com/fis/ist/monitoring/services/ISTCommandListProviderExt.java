package com.fis.ist.monitoring.services;

import java.util.List;
import java.util.Map;

import com.fis.ist.common.IListProvider;
import com.fis.ist.monitoring.dao.ISTCommandDAO;


public class ISTCommandListProviderExt implements IListProvider {
	
	private String searchListType = "";

	@Override
	public List getList() {		
		List recordList = new ISTCommandDAO().getISTCommandProduct();
		return recordList;
	}

	@Override
	public String getName() {
		return "TSKCMD_PRODUCT_POPUP";
	}


	@Override
	public List getList(Map<String, String> arg0) {
		return null;
	}


	@Override
	public List getListByInstitution(String arg0) {
		return null;
	}
	
}
