package com.fis.ist.monitoring.domain;

import java.sql.Clob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "CS_MONGLOBALVALUE" )
public class MonGlobalValue implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String product; // PRODUCT
	private String fieldName; // FIELD_NAME
	private String fieldValue0; // FIELD_VALUE0
	private String fieldValue1; // FIELD_VALUE1
	private String fieldValue2; // FIELD_VALUE2
	private String fieldValue3; // FIELD_VALUE3
	private String fieldValue4; // FIELD_VALUE4
	private String fieldValueDesc; // FIELD_VALUE_DESC
	private Integer id; //ID
	
	public MonGlobalValue() {
		
	}
	
	@Override
	public String toString() {
		return "MonGlobalValue [product=" + product + ", fieldName=" + fieldName + ", fieldValue0=" + fieldValue0
				+ ", fieldValue1=" + fieldValue1 + ", fieldValue2=" + fieldValue2 + ", fieldValue3=" + fieldValue3
				+ ", fieldValue4=" + fieldValue4 + ", fieldValueDesc=" + fieldValueDesc + ", id=" + id + "]";
	}
	
	@Id
	@Column(name = "ID", nullable = false, length = 38)
	//@GeneratedValue(strategy = GenerationType.SEQUENCE)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "PRODUCT", nullable = false, length = 50)
	public String getProduct() {
		return product;
	}


	public void setProduct(String product) {
		this.product = product;
	}

	@Column(name = "FIELD_NAME", nullable = false, length = 50)
	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	@Column(name = "FIELD_VALUE0", nullable = true, length = 200)
	public String getFieldValue0() {
		return fieldValue0;
	}

	public void setFieldValue0(String fieldValue0) {
		this.fieldValue0 = fieldValue0;
	}

	@Column(name = "FIELD_VALUE1", nullable = true, length = 200)
	public String getFieldValue1() {
		return fieldValue1;
	}

	public void setFieldValue1(String fieldValue1) {
		this.fieldValue1 = fieldValue1;
	}

	@Column(name = "FIELD_VALUE2", nullable = true, length = 200)
	public String getFieldValue2() {
		return fieldValue2;
	}

	public void setFieldValue2(String fieldValue2) {
		this.fieldValue2 = fieldValue2;
	}

	@Column(name = "FIELD_VALUE3", nullable = true, length = 200)
	public String getFieldValue3() {
		return fieldValue3;
	}

	public void setFieldValue3(String fieldValue3) {
		this.fieldValue3 = fieldValue3;
	}

	@Column(name = "FIELD_VALUE4", nullable = true, length = 200)
	public String getFieldValue4() {
		return fieldValue4;
	}

	public void setFieldValue4(String fieldValue4) {
		this.fieldValue4 = fieldValue4;
	}

	@Column(name = "FIELD_VALUE_DESC", nullable = true, length = 200)
	public String getFieldValueDesc() {
		return fieldValueDesc;
	}

	public void setFieldValueDesc(String fieldValueDesc) {
		this.fieldValueDesc = fieldValueDesc;
	}

	public MonGlobalValue(String product) {
		this.product = product;
	}
	
	public MonGlobalValue(String product, String fieldName, String fieldValue0, String fieldValue1, String fieldValue2,
					   String fieldValue3, String fieldValue4, String fieldValueDesc, Integer id ) {  
		this.product = product;
		this.fieldName = fieldName;
		this.fieldValue0 = fieldValue0;
		this.fieldValue1 = fieldValue1;
		this.fieldValue2 = fieldValue2;
		this.fieldValue3 = fieldValue3;
		this.fieldValue4 = fieldValue4;
		this.fieldValueDesc = fieldValueDesc;
		this.id = id;
	}

}
