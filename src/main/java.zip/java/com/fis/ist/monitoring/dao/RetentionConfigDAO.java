package com.fis.ist.monitoring.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.domain.RetentionConfig;
import com.fis.ist.monitoring.domain.RetentionConfigId;

@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class RetentionConfigDAO extends MonitorBaseDAO<RetentionConfig, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(RetentionConfigDAO.class);

	public List<String> getList() {
		log.debug("Inside RetentionDao - getList");
		return null;
	}

	public Integer getTotalByExample(RetentionConfig instance) {
		log.debug("RetentionConfigDAO - getTotalByExample - RetentionConfig ");
		Integer count = null;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(RetentionConfig.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();

			Object data = null;

			data = instance.getNodeName();
			if (data != null) {
				condition.put("nodeName", data);
			}

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}
			data = instance.getSiteId();
			if (data != null) {
				condition.put("siteId", data);
			}
			data = instance.getNodeId();
			if (data != null) {
				condition.put("nodeId", data);
			}

			data = instance.getKeyFields();
			if (data != null) {
				String searchTerm = (String) data;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(1, searchTerm.length() - 1);
					c.add(Restrictions.ilike("keyFields", searchTerm, MatchMode.ANYWHERE));
				} else if (searchTerm.startsWith("*")) {
					searchTerm = searchTerm.substring(1);
					c.add(Restrictions.ilike("keyFields", searchTerm, MatchMode.END));
				} else if (searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(0, searchTerm.length() - 1);
					c.add(Restrictions.ilike("keyFields", searchTerm, MatchMode.START));
				} else {
					c.add(Restrictions.ilike("keyFields", searchTerm, MatchMode.EXACT));
				}
			}

			data = instance.getTableName();
			if (data != null) {
				String searchTerm = (String) data;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(1, searchTerm.length() - 1);
					c.add(Restrictions.ilike("tableName", searchTerm, MatchMode.ANYWHERE));
				} else if (searchTerm.startsWith("*")) {
					searchTerm = searchTerm.substring(1);
					c.add(Restrictions.ilike("tableName", searchTerm, MatchMode.END));
				} else if (searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(0, searchTerm.length() - 1);
					c.add(Restrictions.ilike("tableName", searchTerm, MatchMode.START));
				} else {
					c.add(Restrictions.ilike("tableName", searchTerm, MatchMode.EXACT));
				}
			}

			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;

		} catch (RuntimeException re) {
			log.error("RetentionConfigDAO - getTotalByExample Task Command failed", re);
			throw re;
		}
		return count;
	}

	public List<RetentionConfig> findByExample(RetentionConfig instance, int pageNum) {
		log.debug("RetentionConfigDAO - finding RetentionConfig instance by example");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(RetentionConfig.class);
			Map<String, Object> condition = new HashMap<String, Object>();

			Object data = null;
			data = instance.getNodeName();
			if (data != null) {
				condition.put("nodeName", data);
			}

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}
			data = instance.getSiteId();
			if (data != null) {
				condition.put("siteId", data);
			}
			data = instance.getNodeId();
			if (data != null) {
				condition.put("nodeId", data);
			}

			data = instance.getKeyFields();
			if (data != null) {
				String searchTerm = (String) data;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(1, searchTerm.length() - 1);
					c.add(Restrictions.ilike("keyFields", searchTerm, MatchMode.ANYWHERE));
				} else if (searchTerm.startsWith("*")) {
					searchTerm = searchTerm.substring(1);
					c.add(Restrictions.ilike("keyFields", searchTerm, MatchMode.END));
				} else if (searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(0, searchTerm.length() - 1);
					c.add(Restrictions.ilike("keyFields", searchTerm, MatchMode.START));
				} else {
					c.add(Restrictions.ilike("keyFields", searchTerm, MatchMode.EXACT));
				}
			}

			data = instance.getTableName();
			if (data != null) {
				String searchTerm = (String) data;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(1, searchTerm.length() - 1);
					c.add(Restrictions.ilike("tableName", searchTerm, MatchMode.ANYWHERE));
				} else if (searchTerm.startsWith("*")) {
					searchTerm = searchTerm.substring(1);
					c.add(Restrictions.ilike("tableName", searchTerm, MatchMode.END));
				} else if (searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(0, searchTerm.length() - 1);
					c.add(Restrictions.ilike("tableName", searchTerm, MatchMode.START));
				} else {
					c.add(Restrictions.ilike("tableName", searchTerm, MatchMode.EXACT));
				}
			}

			c = c.add(Restrictions.allEq(condition));
			// c.addOrder(Order.asc("fieldName"));
			setPaging(c, pageNum);
			List<RetentionConfig> results = c.list();

			log.debug("RetentionConfigDAO - findByExample successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("RetentionConfigDAO - find by example failed", re);
			throw re;
		}
	}

	public Integer getMaxId() {
		try {

			String queryString = "select max(id) as maxId from CS_MONPURGE";

			Query queryObject = createSQLQuery(queryString).addScalar("maxId", StandardBasicTypes.INTEGER);

			Integer maxId= (Integer) queryObject.uniqueResult();

			log.debug("Success Result RetentionConfigDAO - getMaxId" + maxId);

			return maxId;

		} catch (RuntimeException re) {
			log.error("Exception Occured in getTask Commands list.. failed", re);
			throw re;
		}
	}

	public boolean isDuplicate(RetentionConfig instance) {
		log.debug("RetentionConfigDAO - isDuplicate - RetentionConfig ");
		boolean flag = false;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(RetentionConfig.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}
			data = instance.getSiteId();
			if (data != null) {
				condition.put("siteId", data);
			}
			data = instance.getNodeId();
			if (data != null) {
				condition.put("nodeId", data);
			}
			data = instance.getTableName();
			if (data != null) {
				condition.put("tableName", data);
			}
			data = instance.getKeyFields();
			if (data != null) {
				condition.put("keyFields", data);
			}

			data = instance.getId();
			if (data != null) {
				condition.put("id", data);
			}
			// data = instance.getSchema();
			// if(data != null){
			// condition.put("schema", data);
			// }

			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null && sLong > 0)
				flag = true;
			else
				flag = false;

		} catch (RuntimeException re) {
			log.error("RetentionConfigDAO - isDuplicate Task Command failed", re);
			throw re;
		}
		return flag;
	}

	@Override
	public Class<RetentionConfig> getEntityClass() {
		return RetentionConfig.class;
	}
	
	// To fetch the Table names list for dropdown 
	public List getTableNamesList() {
		log.debug("get RetentionConfigDAO - Table Names List dropdown ");
		try {
			String queryString = "";
			queryString = SqlQueryProvider.getDBSqlQuery("GET_TABLE_NAMES");
			//String queryString = "SELECT TABLE_NAME FROM ALL_TABLES where OWNER='PSD_MONUSER'";
			Query queryObject = createSQLQuery(queryString);
			
			if (PaymonUtils.isOracleDb())
				queryObject.setParameter("owner_group", ConfigParams.getInstance().getProperty("ist.monDb.user") );
	
			List result = queryObject.list();
	
			log.debug("Result of RetentionConfigDAO - getTableNames() " + result.toString());
			return result;
		} catch (RuntimeException re) {
			log.error("Exception Occured in RetentionConfigDAO - getTableNames().. failed", re);
			throw re;
		}
	}
	
	// To fetch the column names from the table
	public List getColumnNames(String tableName) {
		log.debug("get RetentionConfigDAO - Column Names List dropdown ");
		try {

			String queryString = "";
			queryString = SqlQueryProvider.getDBSqlQuery("GET_COL_NAMES");
//			String queryString = "SELECT COLUMN_NAME FROM USER_TAB_COLUMNS WHERE TABLE_NAME= :tableName'";
			Query queryObject = createSQLQuery(queryString);
			
			queryObject.setParameter("tableName", tableName);

			List result = queryObject.list();	
			log.debug("Result of RetentionConfigDAO - getColumnNames() " + result.toString());
			return result;
		} catch (RuntimeException re) {
			log.error("Exception Occured in RetentionConfigDAO - getColumnNames().. failed", re);
			throw re;
		}
	}
	
	
}