package com.fis.ist.monitoring.services.handler;

import static com.fis.ist.common.OracleDaoConstants.EMPTY;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.IndividualATMStatusDao;
import com.fis.ist.monitoring.domain.IndividualATMStatus;
import com.fis.ist.monitoring.dto.IndividualATMStatusDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class IndividualATMStatusHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(IndividualATMStatusHandler.class);
	private static String reqTypeId = MonitorConstants.INDVL_ATM_STATUS_REQ;
	private static String formAuthId = "INVATM_REQ";

	public IndividualATMStatusHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getIndividualATMStatus(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.INDVL_ATM_STATUS_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.INDVL_ATM_STATUS_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.INDVL_ATM_STATUS_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.INDVL_ATM_STATUS_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.INDVL_ATM_STATUS_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("productId".equals(field.getTag())) {
					String value = (String) params.get("productId");
					field.setValue(value);
				}
				if ("siteId".equals(field.getTag())) {
					String value = (String) params.get("siteId");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Individual ATM Status  Details");
		String productId = params.get("productId");
		log.debug("productId" + productId);
		String siteId = params.get("siteId");
		log.debug("siteId" + siteId);
		String nodeId = params.get("nodeId");
		log.debug("nodeId" + nodeId);
		String instId = StringUtils.isNotEmpty(params.get("mon_inst_id")) ? params.get("mon_inst_id") : null;
		log.debug("nodinstIdeId" + instId);
		String grpname = StringUtils.isNotEmpty(params.get("mon_atm_grp_name")) ? params.get("mon_atm_grp_name")
				: EMPTY;
		if (grpname != null || grpname != "") {
			grpname = grpname.trim();
		}
		log.debug("grpname" + grpname);
		String unit = StringUtils.isNotEmpty(params.get("mon_atm_unit")) ? params.get("mon_atm_unit") : EMPTY;
		log.debug("unit" + unit);
		String totalReg = params.get("ist_total");
		String pageNum = params.get("pageNum");
		int pNumber = StringUtils.isNotEmpty(pageNum) ? Integer.parseInt(pageNum) : 1;
		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}
		List<String> criteriaList = new ArrayList<>();
		criteriaList.add(instId);
		criteriaList.add(grpname);
		criteriaList.add(unit);
		IndividualATMStatusDao dao = new IndividualATMStatusDao();
		Integer total = null;
		List<IndividualATMStatus> results = null;

		if ("Y".equalsIgnoreCase(totalReg)) {
			total = dao.getCountByInvdividualATMStatus(criteriaList.toArray(new String[] {}));
		}
		if (total != null) {
			total = total != null ? total.intValue() : 0;
			if (total == 0) {
				workRequest.setLastModified((long) -1);
			} else {
				workRequest.setLastModified((long) total);
			}
		}
		results = dao.getIndividualATMStatusBySwDB(pNumber, criteriaList.toArray(new String[] {}));

		IndividualATMStatusDto atmStatusDto = null;
		List<IndividualATMStatusDto> workRows = getIndividualATMStatusList(workRequest, uiMetaData);
		if (results != null) {
			for (IndividualATMStatus status : results) {
				atmStatusDto = new IndividualATMStatusDto();
				atmStatusDto.load(status);
				workRows.add(atmStatusDto);
				
			}			
		}		
	}	
	

	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
			throws Exception {


		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		currentfield = fields.get("productId");
		fieldValue = params.get("productId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("siteId");
		fieldValue = params.get("siteId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	private List<IndividualATMStatusDto> getIndividualATMStatusList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.INDVL_ATM_STATUS_TAB);
		workCollection.setSectionId(MonitorConstants.INDVL_ATM_STATUS_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.INDVL_ATM_STATUS_TAB);
		workRequest.getCollections().put(MonitorConstants.INDVL_ATM_STATUS_COL, workCollection);
		List<IndividualATMStatusDto> workRows = new ArrayList<IndividualATMStatusDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.INDVL_ATM_STATUS_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	public HashMap<String, String> getDBMapping() {
		HashMap<String, String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product", "product");
		dtoMapping.put("nodeId", "nodeId");
		return dtoMapping;
	}

}
