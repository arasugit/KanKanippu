package com.fis.ist.monitoring.dto;

import static com.fis.ist.monitoring.dto.FaultType.CASSETTE_FATAL_FAULT;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import com.fis.ist.monitoring.domain.ATMAvailable;
import com.fis.ist.monitoring.domain.ATMByFaultWise;
import com.fis.ist.monitoring.domain.ConguredATMByMake;
import com.fis.ist.monitoring.domain.RunningATMByMake;
import com.fis.ist.monitoring.domain.TerminalsByBranch;
import com.fis.ist.monitoring.domain.TerminalsBySite;

public class ATMAvailabilityDto implements java.io.Serializable {

	private static final long serialVersionUID = 6803023989652998245L;	
	
	private int totalATM;
	private int atmInService;
	private int atmOutOfService;
	private int connectedAtm;	
	private String statusUp;
	private String statusDown;
	private String offSite;
	private String onSite;
	private String percentageUpOnSite;
	private String percentageDownOnSite;
	private String percentageUpOffSite;
	private String percentageDownOffSite;
	List<BranchDto> branchTermStatusList;
	List<ATMMakeDto> atmByMakeList;
	List<ATMFaultWiseDto> atmByFaultWiseList;
	
	
	public List<ATMMakeDto> getAtmByMakeList() {
		return atmByMakeList;
	}
	public void setAtmByMakeList(List<ATMMakeDto> atmByMakeList) {
		this.atmByMakeList = atmByMakeList;
	}
	public String getStatusUp() {
		return statusUp;
	}
	public void setStatusUp(String statusUp) {
		this.statusUp = statusUp;
	}
	public String getStatusDown() {
		return statusDown;
	}
	public void setStatusDown(String statusDown) {
		this.statusDown = statusDown;
	}	
	public int getConnectedAtm() {
		return connectedAtm;
	}
	public void setConnectedAtm(int connectedAtm) {
		this.connectedAtm = connectedAtm;
	}
	public int getAtmInService() {
		return atmInService;
	}
	public void setAtmInService(int atmInService) {
		this.atmInService = atmInService;
	}
	
	public int getAtmOutOfService() {
		return atmOutOfService;
	}
	public void setAtmOutOfService(int atmOutOfService) {
		this.atmOutOfService = atmOutOfService;
	}	
	public String getOffSite() {
		return offSite;
	}
	public void setOffSite(String offSite) {
		this.offSite = offSite;
	}
	public String getOnSite() {
		return onSite;
	}
	public void setOnSite(String onSite) {
		this.onSite = onSite;
	}

	public String getPercentageUpOnSite() {
		return percentageUpOnSite;
	}
	public void setPercentageUpOnSite(String percentageUpOnSite) {
		this.percentageUpOnSite = percentageUpOnSite;
	}
	public String getPercentageDownOnSite() {
		return percentageDownOnSite;
	}
	public void setPercentageDownOnSite(String percentageDownOnSite) {
		this.percentageDownOnSite = percentageDownOnSite;
	}
	public String getPercentageUpOffSite() {
		return percentageUpOffSite;
	}
	public void setPercentageUpOffSite(String percentageUpOffSite) {
		this.percentageUpOffSite = percentageUpOffSite;
	}
	public String getPercentageDownOffSite() {
		return percentageDownOffSite;
	}
	public void setPercentageDownOffSite(String percentageDownOffSite) {
		this.percentageDownOffSite = percentageDownOffSite;
	}	
	public List<BranchDto> getBranchTermStatusList() {
		return branchTermStatusList;
	}
	public void setBranchTermStatusList(List<BranchDto> branchTermStatusList) {
		this.branchTermStatusList = branchTermStatusList;
	}
	public int getTotalATM() {
		return totalATM;
	}
	public void setTotalATM(int totalATM) {
		this.totalATM = totalATM;
	}
	public List<ATMFaultWiseDto> getAtmByFaultWiseList() {
		return atmByFaultWiseList;
	}
	public void setAtmByFaultWiseList(List<ATMFaultWiseDto> atmByFaultWiseList) {
		this.atmByFaultWiseList = atmByFaultWiseList;
	}
	public void load(ATMAvailable instance) {
		this.setStatusUp("Up");
		this.setAtmInService(instance.getNumOfUpAtm());
		this.setStatusDown("Down");
		this.setAtmOutOfService(instance.getNumOfDownAtm());
		this.setTotalATM(instance.getTotalNumOfAtm());
	}
	
	public void loadBySite(List<TerminalsBySite> siteDetails) 
	{
		for(TerminalsBySite site :siteDetails) {
			if(site.getSiteType().equalsIgnoreCase("O")) 
			{
				this.setOffSite("Onsite");
				this.setPercentageDownOffSite(site.getDownPercentage()!=null?site.getDownPercentage():"0");
				this.setPercentageUpOffSite(site.getUpPercentage()!=null?site.getUpPercentage():"0");
				
			}else {
				this.setOnSite("Offsite");
				this.setPercentageDownOnSite(site.getDownPercentage()!=null?site.getDownPercentage():"0");
				this.setPercentageUpOnSite(site.getUpPercentage()!=null?site.getUpPercentage():"0");
			}
		}
		
	}
	
	public void loadByBranch(List<TerminalsByBranch> branchDetails) 
	{
		List<BranchDto>  branchDtoList = new ArrayList<>();
		for(TerminalsByBranch branchTerminal :branchDetails) {
			if(!branchTerminal.getDownPercentage().equals("100")) {
				BranchDto  bt= new BranchDto();
				bt.setBranch(branchTerminal.getBranch());
				bt.setBranchUpPercentage(branchTerminal.getUpPercentage());
				bt.setBranchDownPercentage(branchTerminal.getDownPercentage());
				branchDtoList.add(bt);
			}
		}
		this.setBranchTermStatusList(branchDtoList);
		
	}
	
	public void loadByMake(List<RunningATMByMake> runningATMList,List<ConguredATMByMake>  configuredATMList) 
	{	
		List<ATMMakeDto> makeList = new ArrayList<>();
		for(ConguredATMByMake atm :configuredATMList) 
		{			
			ATMMakeDto makeDto = new  ATMMakeDto();
			makeDto.setMake(atm.getMake());
			makeDto.setTotalConfiguredATM(atm.getTotalConfiguredATM());
			makeDto.setRunningATMByMake(this.getRunningATMByMake(makeDto.getMake(),runningATMList));
			makeDto.setDownATMByMake(makeDto.getTotalConfiguredATM()-makeDto.getRunningATMByMake());
			makeList.add(makeDto);
		}
		this.setAtmByMakeList(makeList);		
	}
	
	public void loadATMByFaultWise(List<ATMByFaultWise> atmByFaultWiseList) 
	{	
		List<ATMFaultWiseDto> faultWiseAtmList = new ArrayList<>();		
		ATMFaultWiseDto cassetteFaultDto = new ATMFaultWiseDto();
		Integer cassetteFaultCount=getFaultWiseATMCount(FaultType.CASSETTE_FATAL_FAULT,atmByFaultWiseList);
		cassetteFaultDto.setCount(cassetteFaultCount);
		cassetteFaultDto.setStatusDescription(FaultType.CASSETTE_FAULT_DESC);
		faultWiseAtmList.add(cassetteFaultDto);
		ATMFaultWiseDto cardReaderPrbDto = new ATMFaultWiseDto();
		Integer cardReaderPrbCount=getFaultWiseATMCount(FaultType.CARD_READER_PROBLEM,atmByFaultWiseList);
		cardReaderPrbDto.setCount(cardReaderPrbCount);
		cardReaderPrbDto.setStatusDescription(FaultType.CARD_READER_PROBLEM_DESC);
		faultWiseAtmList.add(cardReaderPrbDto);
		ATMFaultWiseDto cardHandlerPrbDto = new ATMFaultWiseDto();
		Integer cardHandlerPrbCount=getFaultWiseATMCount(FaultType.CARD_HANDLER_PROBLEM,atmByFaultWiseList);
		cardHandlerPrbDto.setCount(cardHandlerPrbCount);
		cardHandlerPrbDto.setStatusDescription(FaultType.CARD_HANDLER_PROBLEM_DESC);
		faultWiseAtmList.add(cardHandlerPrbDto);
		ATMFaultWiseDto cashOutDto = new ATMFaultWiseDto();
		Integer cashOutCount=getFaultWiseATMCount(FaultType.CASH_OUT_PROBLEM,atmByFaultWiseList);
		cashOutDto.setCount(cashOutCount);
		cashOutDto.setStatusDescription(FaultType.CASH_OUT_PROBLEM_DESC);
		faultWiseAtmList.add(cashOutDto);
		ATMFaultWiseDto commPrbDto = new ATMFaultWiseDto();
		Integer commPrbCount=getFaultWiseATMCount(FaultType.COMMUNICATION_PROBLEM,atmByFaultWiseList);
		commPrbDto.setCount(commPrbCount);
		commPrbDto.setStatusDescription(FaultType.COMMUNICATION_PROBLEM_DESC);
		faultWiseAtmList.add(commPrbDto);
		ATMFaultWiseDto inSupervisorDto = new ATMFaultWiseDto();
		Integer supervisorCount=getFaultWiseATMCount(FaultType.IN_SUPERVISORY,atmByFaultWiseList);
		inSupervisorDto.setCount(supervisorCount);
		inSupervisorDto.setStatusDescription(FaultType.IN_SUPERVISORY_DESC);
		faultWiseAtmList.add(inSupervisorDto);
		ATMFaultWiseDto rejectBillOverFillDto = new ATMFaultWiseDto();
		Integer rejectBillOverFillCount=getFaultWiseATMCount(FaultType.REJECT_BILL_OVER_FILL,atmByFaultWiseList);
		rejectBillOverFillDto.setCount(rejectBillOverFillCount);
		rejectBillOverFillDto.setStatusDescription(FaultType.REJECT_BILL_OVER_FILL_DESC);
		faultWiseAtmList.add(rejectBillOverFillDto);
		ATMFaultWiseDto encryptorPrbDto = new ATMFaultWiseDto();
		Integer encryptorPrbCount=getFaultWiseATMCount(FaultType.ENCRYPTOR_PROBLEM,atmByFaultWiseList);
		encryptorPrbDto.setCount(encryptorPrbCount);
		encryptorPrbDto.setStatusDescription(FaultType.ENCRYPTOR_PROBLEM_DESC);
		faultWiseAtmList.add(encryptorPrbDto);		
		ATMFaultWiseDto journalPrinterPrbDto = new ATMFaultWiseDto();
		Integer journalPrinterPrbCount=getFaultWiseATMCount(FaultType.JOUNRNAL_PRINTER_PROBLEM,atmByFaultWiseList);
		journalPrinterPrbDto.setCount(journalPrinterPrbCount);
		journalPrinterPrbDto.setStatusDescription(FaultType.JOUNRNAL_PRINTER_PROBLEM_DESC);
		faultWiseAtmList.add(journalPrinterPrbDto);
		ATMFaultWiseDto receiptPrinterPrbDto = new ATMFaultWiseDto();
		Integer receiptPrinterPrbCount=getFaultWiseATMCount(FaultType.RECEIPT_PRINTER_PROBLEM,atmByFaultWiseList);
		receiptPrinterPrbDto.setCount(receiptPrinterPrbCount);
		receiptPrinterPrbDto.setStatusDescription(FaultType.RECEIPT_PRINTER_PROBLEM_DESC);
		faultWiseAtmList.add(receiptPrinterPrbDto);
		ATMFaultWiseDto receiptPrinterPaperOutDto = new ATMFaultWiseDto();
		Integer receiptPrinterPaperOutCount=getFaultWiseATMCount(FaultType.RECEIPT_PRINTER_PAPER_OUT,atmByFaultWiseList);
		receiptPrinterPaperOutDto.setCount(receiptPrinterPaperOutCount);
		receiptPrinterPaperOutDto.setStatusDescription(FaultType.RECEIPT_PRINTER_PAPER_OUT_DESC);
		faultWiseAtmList.add(receiptPrinterPaperOutDto);		
		ATMFaultWiseDto journalPrinterPaperOutDto = new ATMFaultWiseDto();
		Integer journalPrinterPaperOutCount=getFaultWiseATMCount(FaultType.JOURNAL_PRINTER_PAPER_OUT,atmByFaultWiseList);
		journalPrinterPaperOutDto.setCount(journalPrinterPaperOutCount);
		journalPrinterPaperOutDto.setStatusDescription(FaultType.JOURNAL_PRINTER_PAPER_OUT_DESC);
		faultWiseAtmList.add(journalPrinterPaperOutDto);
		
		ATMFaultWiseDto inServiceATMDto = new ATMFaultWiseDto();
		Integer inServiceCount=getFaultWiseATMCount(FaultType.IN_SERVICE_ATM,atmByFaultWiseList);
		inServiceATMDto.setCount(inServiceCount);
		inServiceATMDto.setStatusDescription(FaultType.IN_SERVICE_ATM_DESC);
		faultWiseAtmList.add(inServiceATMDto);
		
		ATMFaultWiseDto outOfServiceATMDto = new ATMFaultWiseDto();
		Integer outOfServiceCount=getFaultWiseATMCount(FaultType.OUT_OF_SERVICE_ATM,atmByFaultWiseList);
		outOfServiceATMDto.setCount(outOfServiceCount);
		outOfServiceATMDto.setStatusDescription(FaultType.OUT_OF_SERVICE_ATM_DESC);
		faultWiseAtmList.add(outOfServiceATMDto);
		
		this.setAtmByFaultWiseList(faultWiseAtmList);
	}
	
	private Integer getRunningATMByMake(String makename,List<RunningATMByMake> runningATMList) {
		IntStream intStream=null;
		if(runningATMList!=null) {
	      intStream =runningATMList.stream().filter(c -> c.getMake().equals(makename)).mapToInt(atm ->atm.getRunningATMByMake());
	      return intStream!=null?intStream.sum():0;
		}else {
		  return 0;
		}
	}
	
	private Integer getFaultWiseATMCount(Integer expressionValue,List<ATMByFaultWise> atmByFaultWiseList) {
		IntStream intStream=null;		
		switch(expressionValue) {
		  case 1:
		      intStream =atmByFaultWiseList.stream().filter(faultType -> (faultType.getStatusCode()==604||
		                                                              faultType.getStatusCode()==607||
		                                                              faultType.getStatusCode()==614||
		                                                              faultType.getStatusCode()==615)).mapToInt(faultType ->faultType.getTotalATMByFault());
		     break;
		  case 2:
			  intStream =atmByFaultWiseList.stream().filter(faultType -> (faultType.getStatusCode()==200||
              faultType.getStatusCode()==201||
              faultType.getStatusCode()==202||
              faultType.getStatusCode()==203)).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;
		  case 3:
			  intStream =atmByFaultWiseList.stream().filter(faultType -> (faultType.getStatusCode()==608||faultType.getStatusCode()==613)).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;		
		  case 4:
			  intStream =atmByFaultWiseList.stream().filter(faultType -> (faultType.getStatusCode()==740||
              faultType.getStatusCode()==741||
              faultType.getStatusCode()==742||
              faultType.getStatusCode()==743||
              faultType.getStatusCode()==743||
              faultType.getStatusCode()==744||
              faultType.getStatusCode()==745||
              faultType.getStatusCode()==746||
              faultType.getStatusCode()==750||
              faultType.getStatusCode()==751||
              faultType.getStatusCode()==755||
              faultType.getStatusCode()==756||
              faultType.getStatusCode()==757||
              faultType.getStatusCode()==758||
              faultType.getStatusCode()==759)).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;			
		  case 5:
			  intStream =atmByFaultWiseList.stream().filter(faultType ->faultType.getStatusCode()==9717).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;
		  case 6:
			  intStream =atmByFaultWiseList.stream().filter(faultType ->faultType.getStatusCode()==7).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;
		  case 7:
			  intStream =atmByFaultWiseList.stream().filter(faultType ->(faultType.getStatusCode()==600||faultType.getStatusCode()==605)).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;
		  case 8:
			  intStream =atmByFaultWiseList.stream().filter(faultType ->(faultType.getStatusCode()==999||faultType.getStatusCode()==717)).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;			
		  case 9:
			  intStream =atmByFaultWiseList.stream().filter(faultType ->(faultType.getStatusCode()==500||faultType.getStatusCode()==503)).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;
		  case 10:
			  intStream =atmByFaultWiseList.stream().filter(faultType ->faultType.getStatusCode()==510).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;			
		  case 11:
			  intStream =atmByFaultWiseList.stream().filter(faultType ->faultType.getStatusCode()==512).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;
		  case 12:
			  intStream =atmByFaultWiseList.stream().filter(faultType ->faultType.getStatusCode()==502).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;
		  case 13:
			  intStream =atmByFaultWiseList.stream().filter(faultType ->faultType.getStatusCode()== -101).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;
		  case 14:
			  intStream =atmByFaultWiseList.stream().filter(faultType ->faultType.getStatusCode()==101).mapToInt(faultType ->faultType.getTotalATMByFault());
			break;
		  default :
			  intStream =null;
			break;
		}		
		return intStream!=null?intStream.sum():0;
	}


}
