package com.fis.ist.monitoring.dto;

import java.text.DecimalFormat;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class DPEnCashListRow extends EditableListRowForSDK implements Cloneable {
	private static final ISTLogger log = ISTLogger.getLogger(DPEnCashListRow.class);
	
	private static final long serialVersionUID = 6803023989652998245L;	
	
	private String instid;
	private String groupname;
	private String atmunit;
	private String termId1;
	private String time;
	private String location;
	private String geoLocation;
	private String AcceptorName;
	private String Currency;
	private String Make;
	private String Hopper1_EndCash;
	private String Hopper2_EndCash;
	private String Hopper3_EndCash;
	private String Hopper4_EndCash;
	
	private DPEnCashListRow orignalRow;
	DecimalFormat formatter = new DecimalFormat("#,###.00");
	
	@Override
	public String toString() {
		return "DPEnCashListRow [instId=" + instid + ", groupname=" + groupname + ", atmUnit=" + atmunit + ", termId="
				+ termId1 + ", time=" + time + ", location=" + location + ", geoLocation=" + geoLocation
				+ ", acceptorName=" + AcceptorName + ", currency=" + Currency + ", make=" + Make + ", Hopper1_EndCash="
				+ Hopper1_EndCash + ", Hopper2_EndCash=" + Hopper2_EndCash + ", Hopper3_EndCash=" + Hopper3_EndCash
				+ ", Hopper4_EndCash=" + Hopper4_EndCash + ", orignalRow=" + orignalRow + ", formatter=" + formatter
				+ "]";
	}
	
	public void loadEnCashInfo(Object[] rowISTDataFromDB) {
		setInstid(rowISTDataFromDB[0] != null ? (String)rowISTDataFromDB[0] : "");
		setGroupname(rowISTDataFromDB[1] != null ? (String)rowISTDataFromDB[1] : "");
		setAtmunit(rowISTDataFromDB[2] != null ? (String)rowISTDataFromDB[2] : "");
		setTermId1(rowISTDataFromDB[3] != null ? (String)rowISTDataFromDB[3] : "");
		setTime(rowISTDataFromDB[4]);
		setLocation(rowISTDataFromDB[5] != null ? (String)rowISTDataFromDB[5] : "");
		setGeoLocation(rowISTDataFromDB[6] != null ? (String)rowISTDataFromDB[6] : "");
		setAcceptorName(rowISTDataFromDB[7] != null ? (String)rowISTDataFromDB[7] : "");
		setCurrency(rowISTDataFromDB[8] != null ? (String)rowISTDataFromDB[8] : "");
		setMake(rowISTDataFromDB[9] != null ? (String)rowISTDataFromDB[9] : "");
		setHopper1_EndCash(rowISTDataFromDB[10] != null ? (String)rowISTDataFromDB[10] : "0");
		setHopper2_EndCash(rowISTDataFromDB[11] != null ? (String)rowISTDataFromDB[11] : "0");
		setHopper3_EndCash(rowISTDataFromDB[12] != null ? (String)rowISTDataFromDB[12] : "0");
		setHopper4_EndCash(rowISTDataFromDB[13] != null ? (String)rowISTDataFromDB[13] : "0");
		
		if(getHopper1_EndCash() != null) {
			setHopper1_EndCash(convertWithProperFormat(getHopper1_EndCash()));
		}
		
		if(getHopper2_EndCash() != null) {
			setHopper2_EndCash(convertWithProperFormat(getHopper2_EndCash()));
		}
		
		if(getHopper3_EndCash() != null) {
			setHopper3_EndCash(convertWithProperFormat(getHopper3_EndCash()));
		}
		
		if(getHopper4_EndCash() != null) {
			setHopper4_EndCash(convertWithProperFormat(getHopper4_EndCash()));
		}
	}
	
	
	private String convertWithProperFormat(String retrievedValue) {
		
		String valueToPrint = "0.00";
		
		if(!"0".equalsIgnoreCase(retrievedValue)) {
			valueToPrint = formatter.format(Double.parseDouble(retrievedValue));
		} 
		
		return valueToPrint;
	}
	
	public String getAtmunit() {
		return atmunit;
	}

	public String getInstid() {
		return instid;
	}

	public void setInstid(String instid) {
		this.instid = instid;
	}

	public void setAtmunit(String atmUnit) {
		this.atmunit = atmUnit;
	}

	public String getTermId1() {
		return termId1;
	}

	public void setTermId1(String termId1) {
		this.termId1 = termId1;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCurrency() {
		return Currency;
	}

	public void setCurrency(String currency) {
		Currency = currency;
	}

	public String getMake() {
		return Make;
	}

	public void setMake(String make) {
		Make = make;
	}

	public DPEnCashListRow getOrignalRow() {
		return orignalRow;
	}

	public String getAcceptorName() {
		return AcceptorName;
	}

	public void setAcceptorName(String acceptorName) {
		AcceptorName = acceptorName;
	}

	public String getGeoLocation() {
		return geoLocation;
	}

	public void setGeoLocation(String geoLocation) {
		this.geoLocation = geoLocation;
	}
	

	public String getTime() {
		return time;
	}

	public void setTime(Object time) {
		this.time = PaymonUtils.getFormattedResponseDateTime(time);
	}


	public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public String getHopper1_EndCash() {
		return Hopper1_EndCash;
	}

	public void setHopper1_EndCash(String hopper1_EndCash) {
		Hopper1_EndCash = hopper1_EndCash;
	}

	public String getHopper2_EndCash() {
		return Hopper2_EndCash;
	}

	public void setHopper2_EndCash(String hopper2_EndCash) {
		Hopper2_EndCash = hopper2_EndCash;
	}

	public String getHopper3_EndCash() {
		return Hopper3_EndCash;
	}

	public void setHopper3_EndCash(String hopper3_EndCash) {
		Hopper3_EndCash = hopper3_EndCash;
	}

	public String getHopper4_EndCash() {
		return Hopper4_EndCash;
	}

	public void setHopper4_EndCash(String hopper4_EndCash) {
		Hopper4_EndCash = hopper4_EndCash;
	}

	public void setOrignalRow(DPEnCashListRow orignalRow) {
		try {
			if (orignalRow != null)
				this.orignalRow = (DPEnCashListRow) orignalRow.clone();
		} catch (Exception e) {
			log.error(e);
		}
	}

	@Override
	public String getFormKey() {
		return null;
	}

}
