package com.fis.ist.monitoring.domain;

import java.io.Serializable;

public class ATMAvailable implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int numOfUpAtm;
	private int numOfDownAtm;
	private int totalNumOfAtm;
	private String onSite;	
	private String offSite;
	private String percentageUpOnSite;
	private String percentageDownOnSite;
	private String percentageUpOffSite;
	private String percentageDownOffSite;
	
	public int getNumOfUpAtm() {
		return numOfUpAtm;
	}
	public void setNumOfUpAtm(int numOfUpAtm) {
		this.numOfUpAtm = numOfUpAtm;
	}
	public int getNumOfDownAtm() {
		return numOfDownAtm;
	}
	public void setNumOfDownAtm(int numOfDownAtm) {
		this.numOfDownAtm = numOfDownAtm;
	}
	public int getTotalNumOfAtm() {
		return totalNumOfAtm;
	}
	public void setTotalNumOfAtm(int totalNumOfAtm) {
		this.totalNumOfAtm = totalNumOfAtm;
	}
	
	public String getOnSite() {
		return onSite;
	}
	public void setOnSite(String onSite) {
		this.onSite = onSite;
	}
	public String getOffSite() {
		return offSite;
	}
	public void setOffSite(String offSite) {
		this.offSite = offSite;
	}
	public String getPercentageUpOnSite() {
		return percentageUpOnSite;
	}
	public void setPercentageUpOnSite(String percentageUpOnSite) {
		this.percentageUpOnSite = percentageUpOnSite;
	}
	public String getPercentageDownOnSite() {
		return percentageDownOnSite;
	}
	public void setPercentageDownOnSite(String percentageDownOnSite) {
		this.percentageDownOnSite = percentageDownOnSite;
	}
	public String getPercentageUpOffSite() {
		return percentageUpOffSite;
	}
	public void setPercentageUpOffSite(String percentageUpOffSite) {
		this.percentageUpOffSite = percentageUpOffSite;
	}
	public String getPercentageDownOffSite() {
		return percentageDownOffSite;
	}
	public void setPercentageDownOffSite(String percentageDownOffSite) {
		this.percentageDownOffSite = percentageDownOffSite;
	}
}
