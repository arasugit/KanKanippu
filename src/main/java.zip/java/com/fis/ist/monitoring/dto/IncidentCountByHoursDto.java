package com.fis.ist.monitoring.dto;

import java.util.Date;

public class IncidentCountByHoursDto implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	private String hours;
	private Integer openCount;
	private Integer closedCount;
	private String fromDate;
	private String toDate;
	public String getHours() {
		return hours;
	}
	public void setHours(String hours) {
		this.hours = hours;
	}
	public Integer getOpenCount() {
		return openCount;
	}
	public void setOpenCount(Integer openCount) {
		this.openCount = openCount;
	}
	public Integer getClosedCount() {
		return closedCount;
	}
	public void setClosedCount(Integer closedCount) {
		this.closedCount = closedCount;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
}
