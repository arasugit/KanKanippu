package com.fis.ist.monitoring.dto;

import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.domain.ATMTotals;

public class ATMTotalsDto {

	private String institutionId;
	private String groupName;
	private Long unit;
	private String type;
	private Long currency;
	private Long count;
	private Long amount;
	private String resetTime;
	private Long prevCount;
	private Long prevAmount;
	private String terminalId;
	
	public ATMTotalsDto(){
		
	}
	
	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Long getUnit() {
		return unit;
	}

	public void setUnit(Long unit) {
		this.unit = unit;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getCurrency() {
		return currency;
	}

	public void setCurrency(Long currency) {
		this.currency = currency;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public String getResetTime() {
		return resetTime;
	}

	public void setResetTime(String resetTime) {
		this.resetTime = PaymonUtils.getFormattedResponseDateTime(resetTime);
	}

	public Long getPrevCount() {
		return prevCount;
	}

	public void setPrevCount(Long prevCount) {
		this.prevCount = prevCount;
	}

	public Long getPrevAmount() {
		return prevAmount;
	}

	public void setPrevAmount(Long prevAmount) {
		this.prevAmount = prevAmount;
	}
	
	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public void load(ATMTotals atmTotal) {		
		this.setAmount(atmTotal.getAmount());
		this.setCount(atmTotal.getCount());
		this.setCurrency(atmTotal.getCurrency());
		this.setGroupName(atmTotal.getGroupName());
		this.setInstitutionId(atmTotal.getInstitutionId());
		this.setPrevAmount(atmTotal.getPrevAmount());
		this.setPrevCount(atmTotal.getPrevCount());
		this.setType(atmTotal.getType());
		this.setUnit(atmTotal.getUnit());
		this.setResetTime(atmTotal.getResetTime());
		this.setTerminalId(atmTotal.getTerminalId());
	}	
}
