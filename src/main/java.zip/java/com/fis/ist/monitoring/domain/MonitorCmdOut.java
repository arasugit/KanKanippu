package com.fis.ist.monitoring.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CS_MONCMDOUT")
public class MonitorCmdOut implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	private Long id;
	private String  product;	
	private String  nodeId;
	private Date    logDate;
	private String  cmd;
	private String taskName;//FIELD1
	private String taskType; // FIELD2
	private String pId; // FIELD0
	private String flags; // FIELD3
	private String count; // FIELD4
	private String lastStart; // FIELD5
	private String lastDie; // FIELD6	
	private String field7; // FIELD 7
	private String field8; // FIELD 8
	private String field9; // FIELD 9	
	private String output; // CMDOUTPUT
	
	public MonitorCmdOut(){}
	
	@Id
	@Column(name = "ID", nullable = false, length = 38)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(name = "PRODUCT", nullable = false, length = 50)
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	@Column(name = "NODEID", nullable = false, length = 50)
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LOGDATE", nullable = false)
	public Date getLogDate() {
		return logDate;
	}
	public void setLogDate(Date logDate) {
		this.logDate = logDate;
	}
	@Column(name = "CMD", nullable = false, length = 50)
	public String getCmd() {
		return cmd;
	}
	public void setCmd(String cmd) {
		this.cmd = cmd;
	}
	
	@Column(name = "FIELD1", nullable = true, length = 50)
	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	@Column(name = "FIELD2", nullable = true, length = 50)
	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	@Column(name = "FIELD0", nullable = true, length = 50)
	public String getpId() {
		return pId;
	}

	public void setpId(String pId) {
		this.pId = pId;
	}
	
	@Column(name = "FIELD3", nullable = true, length = 50)
	public String getFlags() {
		return flags;
	}

	public void setFlags(String flags) {
		this.flags = flags;
	}

	@Column(name = "FIELD4", nullable = true, length = 50)
	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	@Column(name = "FIELD5", nullable = true, length = 50)
	public String getLastStart() {
		return lastStart;
	}

	public void setLastStart(String lastStart) {
		this.lastStart = lastStart;
	}

	@Column(name = "FIELD6", nullable = true, length = 50)
	public String getLastDie() {
		return lastDie;
	}

	public void setLastDie(String lastDie) {
		this.lastDie = lastDie;
	}

	@Column(name = "FIELD7", nullable = true, length = 50)
	public String getField7() {
		return field7;
	}

	public void setField7(String field7) {
		this.field7 = field7;
	}

	@Column(name = "FIELD8", nullable = true, length = 50)
	public String getField8() {
		return field8;
	}

	public void setField8(String field8) {
		this.field8 = field8;
	}

	@Column(name = "FIELD9", nullable = true, length = 50)
	public String getField9() {
		return field9;
	}

	public void setField9(String field9) {
		this.field9 = field9;
	}

	@Column(name="CMDOUTPUT")
	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}
}
