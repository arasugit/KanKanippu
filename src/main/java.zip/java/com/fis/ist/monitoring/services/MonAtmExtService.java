package com.fis.ist.monitoring.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.audit.FormAudit;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.services.handler.MonATMExtHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class MonAtmExtService extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(MonAtmExtService.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		MonATMExtHandler monAtmExt = new MonATMExtHandler(MonitorConstants.MONATMEXT);
		
		if (action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = monAtmExt.getMonAtmExt(userContext, requestParams);
		} else {
			log.error("**** Mon ATM Ext: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}
		
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}

	public WorkRequest setService(UserContext userContext, String requestType, String action, WorkRequest workRequest)
			throws Exception {
		FormAuditHandler ah = new FormAuditHandler();
		FormAudit handle = ah.beginEditableListAudit(userContext, requestType, action, workRequest,
				CustomConstants.SWITCH_SUBSYSTEM);

		WorkRequest workReq = new WorkRequest();
		log.debug("MonAtmExtService - Set Service");

		MonATMExtHandler ddh = new MonATMExtHandler();

		if (action.compareTo(MonitorConstants.ACTION_INSERT) == 0) {
			workReq = ddh.getDataForAdd(userContext, workRequest);
		} else if (action.compareTo(MonitorConstants.ACTION_SINGLE_BATCH_SAVE) == 0) {
			workReq = ddh.saveWorkRequest(userContext, workRequest, setPermissions());
		} else if (action.compareTo(AppConstants.MKC_ACTION_BATCH_SAVE) == 0) {
			workReq = ddh.saveBatchByChecker(userContext, workRequest, setPermissions());
		} else {
			log.error("**** MonAtmExtService - setService() inbound...unknown request type");
			throw new Exception("Unknown request type");
		}

		ah.saveEditableListAudit(handle, workReq);
		return workReq;
	}
}