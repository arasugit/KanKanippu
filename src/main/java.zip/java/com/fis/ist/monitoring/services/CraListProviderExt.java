package com.fis.ist.monitoring.services;

import java.util.List;
import java.util.Map;

import com.fis.ist.common.IListProvider;
import com.fis.ist.monitoring.dao.MonitorAtmCraDAO;

public class CraListProviderExt implements IListProvider {
	
	@Override
	public List getList() {
		List recordList = null;
		recordList = new MonitorAtmCraDAO().getCraList();
		return recordList;	
	}
	
	@Override
	public String getName() {
		return "CRA_LIST_DROPDOWN";
	}

	@Override
	public List getList(Map<String, String> arg0) {
		return null;
	}

	@Override
	public List getListByInstitution(String arg0) {
		return null;
	}
}