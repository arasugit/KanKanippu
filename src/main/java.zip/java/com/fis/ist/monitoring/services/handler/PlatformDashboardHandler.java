package com.fis.ist.monitoring.services.handler;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.ISTCommandDAO;
import com.fis.ist.monitoring.domain.ISTCommand;
import com.fis.ist.monitoring.dto.FileSystemUsageDto;
import com.fis.ist.monitoring.dto.MemoryStatusDto;
import com.fis.ist.monitoring.dto.PlatformDashboardDto;
import com.fis.ist.monitoring.dto.ProcessDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

public class PlatformDashboardHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(PlatformDashboardHandler.class);
	private static String reqTypeId = MonitorConstants.PLTF_DASHBOARD_REQ;
	private static String formAuthId = "PLTFDASH";

	public PlatformDashboardHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getDashboardWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext);
		load(workReq, params);
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load PlatformDashboardHandler ....");
		
		UIMetaData uiMetaData = null;
		ISTCommandDAO dao = new ISTCommandDAO();
		PlatformDashboardDto dashboardDto = new PlatformDashboardDto();
		HttpServletRequest request = HTTPRequestGetter.getRequest();
		
		String product = (String) request.getSession(false).getAttribute("product_id");
		String nodeName = (String) request.getSession(false).getAttribute("node_name");		
		
   		// Actual value for nodeId/nodeName for "ISTMAS" is "psdmas"
   		// Actual value for nodeId/nodeName for "ISTCLR" is "psdclr"
   		if(product.equals("ISTCLR") || product.equals("ISTMAS")) {
   			nodeName = "*";
   		}
		
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}		
		
		setFileSystemUsages(product, nodeName, dao, dashboardDto);
		setRunningProcess(product, nodeName, dao, dashboardDto);
		
		List<PlatformDashboardDto> workRows = prepareWorkCollection(workRequest, uiMetaData);
		workRows.add(dashboardDto);
		
		if (dashboardDto.getFileSystemUsages() == null && dashboardDto.getRunningProcesses() == null) {
			workRequest.setLastModified(-1L);
			return;
		}
		
		workRequest.setLastModified((long) 1);
	}
	
	private void setFileSystemUsages(String product, String nodeName, ISTCommandDAO dao, PlatformDashboardDto dashboardDto) {
		ISTCommand findRecord = new ISTCommand();	
		final String command = "df -h";

		findRecord.setProduct(product);
		findRecord.setNodeId(nodeName);
		findRecord.setIstCommand(command);
		
		List<ISTCommand> results = dao.findByExample(findRecord, 1);
		
		if (results.size() == 0) {
			log.debug("No file system usage data found for Product: " + product + ", Node: " + nodeName + ", Command: " + command);
			return;
		}
		
		ISTCommand commandResult = results.get(0);
		List<FileSystemUsageDto> fileSystemUsages = parseFileSystemUsageData(commandResult.getOutput());
		
		if (fileSystemUsages == null) {
			return;
		}
		
		dashboardDto.setFileSystemUsages(fileSystemUsages);
		dashboardDto.setFileSystemUsageLogDate(PaymonUtils.getFormattedResponseDateTime(commandResult.getLogdate()));
	}
	
	private void setRunningProcess(String product, String nodeName, ISTCommandDAO dao, PlatformDashboardDto dashboardDto) {
		ISTCommand findRecord = new ISTCommand();	
		String command = "top -b -n1 -u `whoami`";

		findRecord.setProduct(product);
		findRecord.setNodeId(nodeName);
		findRecord.setIstCommand(command);
		
		List<ISTCommand> results = dao.findByExample(findRecord, 1);
		
		if (results.size() == 0) {
			log.debug("No running process data found for Product: " + product + ", Node: " + nodeName + ", Command: " + command);
			return;
		}
		
		ISTCommand commandResult = results.get(0);
		List<ProcessDto> processes = parseRunningProcessData(commandResult.getOutput());
		
		if (processes == null) return;
		
		dashboardDto.setRunningProcesses(processes);
		dashboardDto.setRunningProcessLogDate(PaymonUtils.getFormattedResponseDateTime(commandResult.getLogdate()));
		
		//Set memory status
		MemoryStatusDto memoryStatus = getMemoryStatus(commandResult.getOutput(), false);
		dashboardDto.setMemoryStatus(memoryStatus);
		
		//Set swap space status
		MemoryStatusDto swapSpaceStatus = getMemoryStatus(commandResult.getOutput(), true);
		dashboardDto.setSwapSpaceStatus(swapSpaceStatus);
		
		//Add process for root user
		command = "top -b -n1 -u root | head -200";
		findRecord.setIstCommand(command);
		results = dao.findByExample(findRecord, 1);
		if (results.size() == 0) return;
		commandResult = results.get(0);
		List<ProcessDto> rootProcesses = parseRunningProcessData(commandResult.getOutput());
		if (rootProcesses == null) return;
		processes.addAll(rootProcesses);
		dashboardDto.setRunningProcesses(processes);
	}
	
	private List<FileSystemUsageDto> parseFileSystemUsageData(String commandOutput)
	{
		if (PaymonUtils.isNullOrEmpty(commandOutput))
		{
			log.warn("Empty file System usage command result..");
			return null;
		}
		
		String unixLineSeparator = "\n";
		List<FileSystemUsageDto> fileSystemUsages = new ArrayList<>();
		
		log.debug("Parsing file System usage data..");
		
		String[] lines = commandOutput.split(unixLineSeparator);
		
		for (int i = 1; i < lines.length; i++) {
			String[] parts = lines[i].trim().replaceAll(" +", " ").split(" ");
			
			FileSystemUsageDto fileSystemUsage = new FileSystemUsageDto();
			fileSystemUsage.setFileSystem(parts[0]);
			fileSystemUsage.setSize(parts[1]);
			fileSystemUsage.setUsedSize(parts[2]);
			fileSystemUsage.setAvailableSize(parts[3]);
			fileSystemUsage.setUsedPercent(parts[4]);
			fileSystemUsage.setMountedOn(parts[5]);
			fileSystemUsages.add(fileSystemUsage);
		}
		
		return fileSystemUsages;
	}
	
	private MemoryStatusDto getMemoryStatus(String commandOutput, Boolean swapSpace) {
		MemoryStatusDto memoryStatusDto = new MemoryStatusDto();
		int commandOutputLineNumber = 4;		
		if (PaymonUtils.isNullOrEmpty(commandOutput))
		{
			log.warn("Empty running process command result..");
			return memoryStatusDto;
		}
		
		log.debug("Parsing memory status data..");
		
		String unixLineSeparator = "\n";
		String[] lines = commandOutput.split(unixLineSeparator);
		
		if (swapSpace)
			commandOutputLineNumber = 5;
		
		String memoryStatusCommandData = lines[commandOutputLineNumber - 1];
		Boolean isSizeInKb = memoryStatusCommandData.startsWith("KiB") ? true : false;
		Boolean isSizeInMb = memoryStatusCommandData.startsWith("MiB") ? true : false;
		
		String linePrefix = memoryStatusCommandData.split(":")[0];
		String[] parts = memoryStatusCommandData.replace(linePrefix + ":", "").trim().split(",\\s+");
		
		double total = Double.parseDouble(parts[0].split("\\s+")[0]);
		double free = Double.parseDouble(parts[1].split("\\s+")[0]);
		double used = Double.parseDouble(parts[2].split("\\s+")[0]);
		double buffer = 0;
		
		if (!swapSpace)
			buffer = Double.parseDouble(parts[3].split("\\s+")[0]);
		
		double usedAndCached = 0;
		DecimalFormat df = new DecimalFormat("#.##");
		
		double usedAndCachePercent = (used + buffer) * 100 / total;
		double freePercent = free * 100 / total;
		double usedPercent = used * 100 / total;
		double usedForCachePercent = buffer * 100 / total;
		
		if (isSizeInKb) {
			total = total / (1024 * 1024);
			usedAndCached = (used + buffer) / (1024 * 1024);
			used = used / (1024 * 1024);
			free = free / (1024 * 1024);
			buffer = buffer / (1024 * 1024);			
		}
		else if (isSizeInMb) {
			usedAndCached = (used + buffer) / 1024;
			total = total / 1024;
			used = used / 1024;
			free = free / 1024;
			buffer = buffer / 1024;			
		}
		
		memoryStatusDto.setTotalSize(df.format(total));
		memoryStatusDto.setUsed(df.format(used));
		memoryStatusDto.setFree(df.format(free));
		memoryStatusDto.setUsedForCache(df.format(buffer));
		memoryStatusDto.setUsedAndCache(df.format(usedAndCached));
		memoryStatusDto.setUsedAndCachePercent(df.format(usedAndCachePercent));
		memoryStatusDto.setFreePercent(df.format(freePercent));
		memoryStatusDto.setUsedPercent(df.format(usedPercent));
		memoryStatusDto.setUsedForCachePercent(df.format(usedForCachePercent));
		
		return memoryStatusDto;
	}
	
	private List<ProcessDto> parseRunningProcessData(String commandOutput)
	{
		if (PaymonUtils.isNullOrEmpty(commandOutput))
		{
			log.warn("Empty running process command result..");
			return null;
		}
		
		String unixLineSeparator = "\n";
		List<ProcessDto> processes = new ArrayList<>();
		
		log.debug("Parsing running process data..");
		
		String[] lines = commandOutput.split(unixLineSeparator);
		
		Boolean isSizeInKb = lines[3].startsWith("KiB Mem") ? true : false;
		Boolean isSizeInMb = lines[3].startsWith("MiB Mem") ? true : false;
		
		for (int i = 7; i < lines.length; i++) {
			String[] parts = lines[i].trim().replaceAll(" +", " ").split(" ");
			
			ProcessDto process = new ProcessDto();
			process.setProcessId(parts[0]);
			process.setUser(parts[1]);
			process.setProcessPriority(parts[2]);
			process.setNiceValue(parts[3]);
			process.setVirtualMemorySize(convertToMb(parts[4], isSizeInKb, isSizeInMb));
			process.setResidentMemorySize(convertToMb(parts[5], isSizeInKb, isSizeInMb));
			process.setSharedMemorySize(convertToMb(parts[6], isSizeInKb, isSizeInMb));
			process.setProcessStatus(parts[7]);
			process.setCpuUsagePercent(parts[8]);
			process.setMemoryUsagePercent(parts[9]);
			process.setCpuTimeUsed(parts[10]);
			process.setCommand(parts[11]);
			processes.add(process);
		}
		
		return processes;
	}
	
	private String convertToMb(String size, Boolean isSizeInKb, Boolean isSizeInMb) {
		if (isSizeInMb)
			return size + "MB";
		
		if(isSizeInKb && !size.isEmpty()) {
			int value = Integer.parseInt(size);
			value = value / 1024;
			return String.valueOf(value) + "MB";
		}
		return size;
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data) throws Exception {

		try {
			
			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private List<PlatformDashboardDto> prepareWorkCollection(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.PLTF_DASHBOARD_COL);
		workCollection.setSectionId(MonitorConstants.PLTF_DASHBOARD_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.PLTF_DASHBOARD_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<PlatformDashboardDto> workRows = new ArrayList<PlatformDashboardDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.PLTF_DASHBOARD_COL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.PLTF_DASHBOARD_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(reqTypeId);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.PLTF_DASHBOARD_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.PLTF_DASHBOARD_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}
}
