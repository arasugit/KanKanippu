package com.fis.ist.monitoring.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class ATMExtId implements java.io.Serializable {

	public ATMExtId() {

	}	
	
	public ATMExtId(String unit, String instId, String groupName) {
		this.unit = unit;
		this.instId = instId;
		this.groupName = groupName;
	}

	@Override
	public String toString() {
		return "monExtId [unit=" + unit + ", instId=" + instId + ", groupName=" + groupName + "]";
	}

	private String unit;
	private String instId;
	private String groupName;
	
	@Column(name = "UNIT", nullable = false, length = 38)
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	
	@Column(name = "INSTITUTIONID", nullable = false, length = 10)
	public String getInstId() {
		return instId;
	}
	public void setInstId(String instId) {
		this.instId = instId;
	}
	
	@Column(name = "GROUP_NAME", nullable = false, length = 10)
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	

}
