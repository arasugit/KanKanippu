package com.fis.ist.monitoring.common;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dto.ChipNonChipListRow;
import com.fis.ist.monitoring.dto.DateTimeRequestDto;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.monitoring.dto.TransactionStatisticsListItem;
import com.fis.ist.services.vo.WorkRequest;

public class PaymonUtils {
	private static FormAuditHandler auditHandler = new FormAuditHandler();

	// Database value Date/DateTime format.
	private static final String DatabaseDateFormat = ConfigParams.getInstance()
			.getProperty("ist.paymon.databaseDateFormat");
	private static final String DatabaseDateTimeFormat = ConfigParams.getInstance()
			.getProperty("ist.paymon.databaseDateTimeFormat");

	// Response (to GUI) Date/DateTime format.
	private static final String ResponseDateFormat = ConfigParams.getInstance()
			.getProperty("ist.paymon.responseDateFormat");
	private static final String ResponseDateTimeFormat = ConfigParams.getInstance()
			.getProperty("ist.paymon.responseDateTimeFormat");

	// Input (from GUI) Date/DateTime format.

	public static final String InputDateFormat = ConfigParams.getInstance().getProperty("ist.paymon.responseDateFormat");
	public static final String InputDateTimeFormat = ConfigParams.getInstance().getProperty("ist.paymon.responseDateTimeFormat");
	
	public static final String DateFormatMonthlyMMM = ConfigParams.getInstance().getProperty("ist.paymon.resposneDateFormatMonthly");
	
	public static final String InputDateConversionFormat = "dd-MMM-yyyy";
	
	public static final String InputDateTimeConversionFormat = "dd-MMM-yyyy HH:mm:ss";
	
	public static final String DatabaseDateConversionFormat = "DD-MON-YYYY";
	
	public static final String DatabaseDateTimeConversionFormat = "DD-MON-YYYY HH24:MI:SS";

	private static final ISTLogger log = ISTLogger.getLogger(PaymonUtils.class);

	public static String getRespDescByCode(List<TransactionStatisticsListItem> respCodesAndDesc, String respCode) {
		TransactionStatisticsListItem row = respCodesAndDesc.stream().filter(r -> respCode.trim().equals(r.getRespCode().trim()))
				.findAny().orElse(null);

		return row == null ? "-" : row.getRespCodeDesc();
	}

	public static String getDeclineCategoryByRespCode(List<String> businessDeclineList,
			List<String> technicalDeclineList, String respCode) {
		if (businessDeclineList.contains(respCode))
			return "Business Decline";

		if (technicalDeclineList.contains(respCode))
			return "Technical Decline";

		return "-";
	}

	public static DateTimeRequestDto getRequestedDateTime(Map<String, String> params) {
		String fromDate = params.get("fromDate");
		String fromTime = params.get("fromTime");
		String toDate = params.get("toDate");
		String toTime = params.get("toTime");

		String fromDbDateFormat = DatabaseDateConversionFormat;
		DateFormat fromOutputFormat = new SimpleDateFormat(InputDateConversionFormat);
		DateFormat fromInputFormat = new SimpleDateFormat(InputDateFormat);
		Date toDateObj = null;
		String formattedFromDate = "";
		String formattedToDate = "";

		if (!isNullOrEmpty(fromTime)) {
			fromDate = fromDate + " " + fromTime;
			fromDbDateFormat = DatabaseDateTimeConversionFormat;
			fromOutputFormat = new SimpleDateFormat(InputDateTimeConversionFormat);
			fromInputFormat = new SimpleDateFormat(InputDateTimeFormat);
		}

		if (!isNullOrEmpty(toDate)) {
			toDate = toDate + " " + (isNullOrEmpty(toTime) ? "23:59:59" : toTime);
		}

		if (!isNullOrEmpty(fromDate) && !isNullOrEmpty(toDate)) {
			try {
				Date fromDateObj = fromInputFormat.parse(fromDate);
				toDateObj = new SimpleDateFormat(InputDateTimeFormat).parse(toDate);
				formattedFromDate = fromOutputFormat.format(fromDateObj);
				formattedToDate = new SimpleDateFormat(InputDateTimeConversionFormat).format(toDateObj);

			} catch (ParseException pe) {
				log.error(pe);
			}
		}

		DateTimeRequestDto dto = new DateTimeRequestDto();
		dto.setFormattedFromDate(formattedFromDate);
		dto.setFormattedToDate(formattedToDate);
		dto.setToDateTime(toDateObj);
		dto.setFromDbDateFormat(fromDbDateFormat);
		dto.setToDbDateFormat(DatabaseDateTimeConversionFormat);

		return dto;
	}

	public static String getDatabseName() {
		return ConfigParams.getInstance().getProperty("ist.database");
	}

	public static boolean isOracleDb() {
		return "oracle".equalsIgnoreCase(getDatabseName());
	}

	public static boolean isPostgressDb() {
		return "PostgreSQL".equalsIgnoreCase(getDatabseName());
	}

	public static boolean isNullOrEmpty(String value) {
		return value == null || value.isEmpty();
	}

	public static String getFormattedResponseDate(Object date) {
		if (date == null) {
			return "";
		}

		String dateString = date.toString();
		if (dateString.isEmpty()) {
			return dateString;
		}

		if (dateString.contains(":")) {
			dateString = dateString.substring(0, dateString.indexOf(' '));
		}

		if (dateString.contains("-") && Character.isAlphabetic(dateString.charAt(0))) {
			return getFormattedDate(dateString, DateFormatMonthlyMMM, DateFormatMonthlyMMM);
		}

		return getFormattedDate(dateString, DatabaseDateFormat, ResponseDateFormat);
	}

	public static String getFormattedResponseDateTime(Object dateTime) {
		if (dateTime == null) {
			return "";
		}

		String dateTimeString = dateTime.toString();
		if (dateTimeString.isEmpty()) {
			return dateTimeString;
		}

		if (!dateTimeString.contains(":")) {
			return getFormattedResponseDate(dateTimeString);
		}

		String inputFormat = getInputDateTimeFormat(dateTimeString);

		return getFormattedDate(dateTimeString, inputFormat, ResponseDateTimeFormat);
	}

	public static Date convertLocalDateTimeToDate(LocalDateTime localDateTime) {
		return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
	}

	public static String getTimeFromDateTime(Object dateTime) {
		if (dateTime == null) {
			return "";
		}

		String dateTimeString = dateTime.toString();
		if (dateTimeString.isEmpty()) {
			return dateTimeString;
		}

		if (!dateTimeString.contains(":")) {
			return dateTimeString;
		}

		return getFormattedDate(dateTimeString, DatabaseDateTimeFormat, "HH:mm:ss");
	}

	public static String getFormattedResponseTime(Object timeNumber) {
		if (timeNumber == null) {
			return "";
		}

		String timeString = timeNumber.toString();
		if (timeString.isEmpty()) {
			return timeString;
		}

		try {
			int time = Integer.parseInt(timeString);
			int hours = time / 10000;
			int minutes = (time / 100) % 100;
			int seconds = time % 100;

			return String.format("%02d:%02d:%02d", hours, minutes, seconds);

		} catch (NumberFormatException nfEx) {
			log.error(String.format("Failed to format time %s to HH:mm:ss format. Exception: %s", timeString,
					nfEx.getMessage()));
		}
		return timeString;
	}

	public static boolean isValidDate(String dateString) {
		// Regular expression for DD/MM/YYYY format with optional leading zeros
		final String ddmmyyyyPattern = "^(0?[1-9]|[12][0-9]|3[01])(\\/|-)(0?[1-9]|1[0-2])\\2(19|20)\\d\\d$";

		// Regular expression for MM/DD/YYYY format with optional leading zeros
		final String mmddyyyyPattern = "^(0?[1-9]|1[0-2])(\\/|-)(0?[1-9]|[12][0-9]|3[01])\\2(19|20)\\d\\d$";

		if (InputDateFormat.equalsIgnoreCase("DD/MM/YYYY") || InputDateFormat.equalsIgnoreCase("DD-MM-YYYY"))
			return dateString.matches(ddmmyyyyPattern);

		if (InputDateFormat.equalsIgnoreCase("MM/DD/YYYY") || InputDateFormat.equalsIgnoreCase("MM-DD-YYYY"))
			return dateString.matches(mmddyyyyPattern);

		return false;
	}

	public static String getChipNonChipRespDescByCode(List<ChipNonChipListRow> respCodesAndDesc, String respCode) {
		ChipNonChipListRow row = respCodesAndDesc.stream().filter(r -> respCode.trim().equals(r.getRespCode().trim()))
				.findAny().orElse(null);

		return row == null ? "-" : row.getRespCodeDesc();
	}

	public static void saveAuditLog(UserContext userContext, String requestType, String action, WorkRequest workReq) {
		final String IstPaymonAuditLogPropertyKey = "ist.paymon.audit.log";
		boolean writeAuditLog = Boolean
				.parseBoolean(ConfigParams.getInstance().getProperty(IstPaymonAuditLogPropertyKey));

		if (!writeAuditLog) {
			log.debug(String.format("Skipping audit log entry as %s property value is set to false",
					IstPaymonAuditLogPropertyKey));
			return;
		}

		log.debug(String.format("Started saving audit log for RequestType: %s, Action: %s", requestType, action));
		auditHandler.saveFormAudit(userContext, requestType, action, workReq, CustomConstants.SWITCH_SUBSYSTEM);
	}

	private static String getFormattedDate(String dateString, String inputFormat, String outputFormat) {
		dateString = dateString.replace(".0", "");
		if (dateString.length() < 8)
			return dateString;

		try {
			SimpleDateFormat inputDateFormat = new SimpleDateFormat(inputFormat);
			Date date = inputDateFormat.parse(dateString);

			SimpleDateFormat outputDateFormat = new SimpleDateFormat(outputFormat);
			return outputDateFormat.format(date);

		} catch (DateTimeParseException | ParseException parseEx) {
			log.error(String.format("Failed to format date %s from format %s to %s. Exception: %s", dateString,
					inputFormat, outputFormat, parseEx.getMessage()));
			return dateString;
		}
	}

	private static String getInputDateTimeFormat(String dateTime) {
		String inputFormat = DatabaseDateTimeFormat;
		if (dateTime.contains(", ") && Character.isAlphabetic(dateTime.charAt(0))) {
			return "MMM dd, yyyy HH:mm:ss";
		}
		if (dateTime.contains(",") && Character.isAlphabetic(dateTime.charAt(0))) {
			return "MMM dd,yyyy HH:mm:ss";
		}
		if (dateTime.subSequence(2, 2).equals("-") && Integer.parseInt(dateTime.subSequence(3, 4).toString()) <= 12) {
			return "dd-MM-yyyy HH:mm:ss";
		}
		return inputFormat;
	}
}
