package com.fis.ist.monitoring.domain;

public class ATMByFaultWise implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer totalATMByFault;
	private Integer statusCode;
	private String statusDescription;
	
	public Integer getTotalATMByFault() {
		return totalATMByFault;
	}
	public void setTotalATMByFault(Integer totalATMByFault) {
		this.totalATMByFault = totalATMByFault;
	}
	public Integer getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
}
