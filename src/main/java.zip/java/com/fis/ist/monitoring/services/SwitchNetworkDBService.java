package com.fis.ist.monitoring.services;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.services.handler.SwitchNetworkDBHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

public class SwitchNetworkDBService extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(SwitchNetworkDBService.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		SwitchNetworkDBHandler switchNetworkDBHandler = new SwitchNetworkDBHandler();

		HttpServletRequest request = HTTPRequestGetter.getRequest();
		String productId = (String) request.getSession(false).getAttribute("product_id");
		String nodeName = (String) request.getSession(false).getAttribute("node_name");

		requestParams.put("product", productId == null ? "" : productId);
		requestParams.put("nodeId", nodeName == null ? "*" : nodeName);

		if (action.compareTo(MonitorConstants.ACTION_QUERY) == 0) {
			workReq = switchNetworkDBHandler.getSwitchNetworkDBAvailability(userContext, requestParams);
		} else {
			log.error("**** ATM NetworkDashBoard Service: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}
		
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}
}