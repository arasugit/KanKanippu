package com.fis.ist.monitoring.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.domain.MonitorAtmCra;
import com.fis.ist.monitoring.domain.MonitorAtmCraId;

@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class MonitorAtmCraDAO extends MonitorBaseDAO<MonitorAtmCra, MonitorAtmCraId> {
	private static final ISTLogger log = ISTLogger.getLogger(MonitorAtmCraDAO.class);

	public Integer getTotalByExample(MonitorAtmCra instance) {
		log.debug("MonitorAtmCraDAO - getTotalByExample - MonitorAtmCra ");
		Integer count = null;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(MonitorAtmCra.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;

			if (instance.getId() != null) {
				data = instance.getId().getInstitutionId();
				if (data != null) {
					c.add(Restrictions.eq("id.institutionId", data).ignoreCase());
				}
			}

			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;

		} catch (RuntimeException re) {
			log.error("MonitorAtmCraDAO - getTotalByExample Task Command failed", re);
			throw re;
		}
		return count;
	}

	public List<MonitorAtmCra> findByExample(MonitorAtmCra instance, int pageNum) {
		log.debug("MonitorAtmCraDAO - finding MonitorAtmCra instance by example");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(MonitorAtmCra.class);
			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;

			if (instance.getId() != null) {
				data = instance.getId().getInstitutionId();
				if (data != null) {
					c.add(Restrictions.eq("id.institutionId", data).ignoreCase());
				}
			}

			c = c.add(Restrictions.allEq(condition));
			c.addOrder(Order.asc("id.institutionId"));
			setPaging(c, pageNum);
			List<MonitorAtmCra> results = c.list();

			log.debug("MonitorAtmCraDAO - findByExample successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("MonitorAtmCraDAO - find by example failed", re);
			throw re;
		}
	}

	@Override
	public Class<MonitorAtmCra> getEntityClass() {
		return MonitorAtmCra.class;
	}

	// To fetch the CRA list for dropdown
	public List getCraList() {
		log.debug("get MonitorAtmCraDAO - CRA List dropdown list");
		try {

			String queryString = "select distinct CRA_BRANCH as CRA from CS_MONCRA_MASTER";
			Query queryObject = createSQLQuery(queryString).addScalar("CRA", StandardBasicTypes.STRING);

			List result = queryObject.list();

			log.debug("Result of MonitorAtmCraDAO - CRA List " + result.toString());
			return result;
		} catch (RuntimeException re) {
			log.error("Exception Occured in MonitorAtmCraDAO - getCraList dropdown.. failed", re);
			throw re;
		}
	}
}
