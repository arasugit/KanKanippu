// ATM Monitoring DTO
package com.fis.ist.monitoring.dto;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.domain.ATMDataListDs;
import com.fis.ist.monitoring.domain.ATMMonDbListDs;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class ATMMonitoringRowListDs extends EditableListRowForSDK implements Cloneable {

	private static final long serialVersionUID = 1L;
	private static final ISTLogger log = ISTLogger.getLogger(ATMMonitoringRowListDs.class);
	
	private String instId; 
	private String grpName;
	private String atmUnit;
	private String termId;
	private String location;
	private String geoLocation;
	private String acceptorName;
	private String currency;
	private String country;
	private String branchId;
	private String branchName;
	private String siteType;
	private String siteName;
	private String lastTransactionDateTime;
	private String make;
	private String lastStatusDate;
	private String lastStatusTime;
	private String faultStatusCode;
	private String faultStatusDesc;
	
	
	public String getInstId() {
		return instId;
	}

	public void setInstId(String instId) {
		this.instId = instId;
	}

	public String getGrpName() {
		return grpName;
	}

	public void setGrpName(String grpName) {
		this.grpName = grpName;
	}

	public String getAtmUnit() {
		return atmUnit;
	}

	public void setAtmUnit(String atmUnit) {
		this.atmUnit = atmUnit;
	}

	public String getTermId() {
		return termId;
	}

	public void setTermId(String termId) {
		this.termId = termId;
	}
	
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getGeoLocation() {
		return geoLocation;
	}

	public void setGeoLocation(String geoLocation) {
		this.geoLocation = geoLocation;
	}

	public String getAcceptorName() {
		return acceptorName;
	}

	public void setAcceptorName(String acceptorName) {
		this.acceptorName = acceptorName;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getSiteType() {
		return siteType;
	}

	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getLastTransactionDateTime() {
		return lastTransactionDateTime;
	}

	public void setLastTransactionDateTime(String lastTransactionDateTime) {
		this.lastTransactionDateTime = PaymonUtils.getFormattedResponseDateTime(lastTransactionDateTime);
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getLastStatusDate() {
		return lastStatusDate;
	}

	public void setLastStatusDate(String lastStatusDate) {
		this.lastStatusDate = PaymonUtils.getFormattedResponseDate(lastStatusDate);
	}

	public String getLastStatusTime() {
		return lastStatusTime;
	}

	public void setLastStatusTime(String lastStatusTime) {
		this.lastStatusTime = PaymonUtils.getFormattedResponseTime(lastStatusTime);
	}

	public String getFaultStatusCode() {
		return faultStatusCode;
	}

	public void setFaultStatusCode(String faultStatusCode) {
		this.faultStatusCode = faultStatusCode;
	}

	public String getFaultStatusDesc() {
		return faultStatusDesc;
	}

	public void setFaultStatusDesc(String faultStatusDesc) {
		this.faultStatusDesc = faultStatusDesc;
	}

	@Override
	public String getFormKey() {
		return null;
	}
	
	
	public void loadATMTerminals(ATMMonDbListDs monDbList, ATMDataListDs atmData){
		
		setTermId(atmData.getTermId());
		setInstId(atmData.getInstId());
		setGrpName(atmData.getGrpName());
		setAtmUnit(atmData.getATMUnit());
		setLocation(atmData.getLocation());
		setGeoLocation(atmData.getGeoLocation().trim());
		setAcceptorName(atmData.getAcceptorName());
		setCurrency(atmData.getCurrency());
		setLastTransactionDateTime(atmData.getLastTransactionDateTime());
		setMake(atmData.getMake());
		setFaultStatusCode(atmData.getFaultStatusCode());
		setLastStatusDate(atmData.getLastStatusDate());
		setLastStatusTime(atmData.getLastStatusTime());
		setFaultStatusDesc(atmData.getFaultStatusDesc());		
		
		setSiteName(monDbList.getSiteName());
		setSiteType(monDbList.getSiteType());
		setBranchId(monDbList.getBranchId());
		setBranchName(monDbList.getBranchName());
		setCountry(monDbList.getCountry());
	}


	@Override
	public String toString() {
		return "ATMMonitoringRowListDs [instId=" + instId + ", grpName=" + grpName + ", atmUnit=" + atmUnit
				+ ", termId=" + termId + ",  location=" + location + ", geoLocation="
				+ geoLocation + ", acceptorName=" + acceptorName + ", currency=" + currency + ", country=" + country
				+ ", branchId=" + branchId + ", branchName=" + branchName + ", siteType=" + siteType + ", siteName="
				+ siteName + ", lastTransactionDateTime=" + lastTransactionDateTime + ", make=" + make
				+ ", lastStatusDate=" + lastStatusDate + ", lastStatusTime=" + lastStatusTime + ", faultStatusCode="
				+ faultStatusCode + ", faultStatusDesc=" + faultStatusDesc + "]";
	}
}

