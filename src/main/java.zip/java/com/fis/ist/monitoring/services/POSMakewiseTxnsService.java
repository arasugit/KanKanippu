package com.fis.ist.monitoring.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.services.handler.POSMakewiseTxnsHandler;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class POSMakewiseTxnsService extends CRUDSubService {

	private static final ISTLogger log = ISTLogger.getLogger(POSMakewiseTxnsService.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		POSMakewiseTxnsHandler aah = new POSMakewiseTxnsHandler();
		
		if (action.compareTo(MonitorConstants.ACTION_QUERY) == 0) {
			workReq = aah.getPOSMakewiseTxnStats(userContext, requestParams);
		} else {
			log.error("**** POSMakewiseTxnsService : " + action);
			throw new Exception("Unknown action error");
		}
		
		PaymonUtils.saveAuditLog(userContext, requestType, action, workReq);
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}
}
