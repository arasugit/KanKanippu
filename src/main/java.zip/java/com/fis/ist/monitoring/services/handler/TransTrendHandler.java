package com.fis.ist.monitoring.services.handler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.DateTimeRequestDto;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class TransTrendHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(TransTrendHandler.class);
	private static String reqTypeId = MonitorConstants.TXN_TREND_REQ;
	private static String formAuthId = "TXNTREND";
	private int pgsz = -1;

	public TransTrendHandler() {
		checkMKCEnabled(formAuthId);
	}

	public TransTrendHandler(String formAuthIdVar) {
		formAuthId = formAuthIdVar;
		reqTypeId = formAuthIdVar;
		checkMKCEnabled(formAuthIdVar);
	}

	public WorkRequest getList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}


	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.TXN_TREND_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.TXN_TREND_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.TXN_TREND_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.TXN_TREND_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.TXN_TREND_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("TransTrebdHandler - Load List ");

		String type = params.get("type");
		loadTxntrend(workRequest, params);
	}

	private void loadTxntrend(WorkRequest workRequest, Map<String, String> params) {
		String fromDate = "";
		String toDate = "";
		String dateFormate = "";
		String type = params.get("type");
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		String ist_inst_Id = params.get("ist_inst_Id");
		String terminalId = params.get("termId");

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}
		List results = new ArrayList();

		if ("MONTH".equalsIgnoreCase(type)) {
			fromDate = params.get("fromDate");
			dateFormate = PaymonUtils.InputDateFormat;
		} else if ("YEAR".equalsIgnoreCase(type)) {
			fromDate = params.get("year");
			dateFormate = PaymonUtils.InputDateFormat;
		} else if (type.equalsIgnoreCase("CUSTOM")) {
			String fromTime = params.get("fromTime");
			dateFormate = PaymonUtils.DatabaseDateTimeConversionFormat;
			if (StringUtil.isEmpty(fromTime)) {
				params.put("fromTime", "00:00:00");
			}
			DateTimeRequestDto dateTimeRequestDto = PaymonUtils.getRequestedDateTime(params);
			fromDate = dateTimeRequestDto.getFormattedFromDate();
			toDate = dateTimeRequestDto.getFormattedToDate();
			try {
				Date fromDateObj = new SimpleDateFormat(PaymonUtils.InputDateTimeConversionFormat).parse(fromDate);
				Date toDateObj = new SimpleDateFormat(PaymonUtils.InputDateTimeConversionFormat).parse(toDate);
				long minutes = (toDateObj.getTime() - fromDateObj.getTime()) / 1000;
				if (minutes < 0) {
					workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
					workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
					workRequest.setErrorDetail("'Date to & time ' must greater than 'Date from & time'");
					return;
				}
			} catch (ParseException e) {
				log.error(e);
			}
		}

		if (!needs_total) {
			results = loadTransTrendData(type, fromDate, toDate, dateFormate, ist_inst_Id, terminalId, pageNum);
		} else if (needs_total) {
			total = loadTransTrendCount(type, fromDate, toDate, dateFormate, ist_inst_Id, terminalId);
			results = loadTransTrendData(type, fromDate, toDate, dateFormate, ist_inst_Id, terminalId, pageNum);
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		List<TransactionListRow> workRows = getTransactionList(workRequest, uiMetaData, MonitorConstants.TXN_TREND_COL);
		TransactionListRow dto = null;
		Object[] result = null;
		for (int i = 0; i < results.size(); i++) {
			dto = new TransactionListRow();
			result = (Object[]) results.get(i);
			dto.loadTransTrendData(result);
			workRows.add(dto);
		}
		log.debug("Work rows :: " + workRows);
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	public HashMap<String, String> getDBMapping() {
		HashMap<String, String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product", "product");
		return dtoMapping;
	}

	private List loadTransTrendData(String type, String fromDate, String toDate, String dateFromate, String ist_inst_Id,
			String terminalId, int pageNum) {
		log.debug("TransTrendHandler - Load Transaction Trend records - loadListData()");

		TransactionsDAO dao = new TransactionsDAO();
		List results = dao.getTransTrendData(type, fromDate, toDate, dateFromate, ist_inst_Id, terminalId, pageNum);

		return results;
	}

	private int loadTransTrendCount(String type, String fromDate, String toDate, String dateFromate, String ist_inst_Id,
			String terminalId) {
		log.debug("TransTrendHandler - Load Transaction Trend records - loadListData()");

		TransactionsDAO dao = new TransactionsDAO();
		int count = dao.getTransTrendDataCount(type, fromDate, toDate, dateFromate, ist_inst_Id, terminalId);

		return count;
	}

	private List<TransactionListRow> getTransactionList(WorkRequest workRequest, UIMetaData uiMetaData,
			String collectionName) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(collectionName);
		workCollection.setSectionId(MonitorConstants.TXN_TREND_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.TXN_TREND_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<TransactionListRow> workRows = new ArrayList<TransactionListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, collectionName);
		workCollection.setRows(workRows);
		return workRows;
	}

	protected int getDefaultPageSize() {
		if (pgsz != -1)
			return pgsz;
		Integer val = ConfigParams.getInstance().getIntProperty("ist.default_page_size");
		if (val == null || val <= 0)
			val = AppConstants.Default_PageSize;
		pgsz = val;
		return pgsz;
	}
}