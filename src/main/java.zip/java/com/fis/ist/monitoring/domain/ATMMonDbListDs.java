package com.fis.ist.monitoring.domain;

public class ATMMonDbListDs implements java.io.Serializable{
	
private static final long serialVersionUID = 1L;
	
	private String termId;
	private String siteName;
	private String siteType;
	private String branchId;
	private String branchName;
	private String country;
	public String getTermId() {
		return termId;
	}
	public void setTermId(String termId) {
		this.termId = termId;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getSiteType() {
		return siteType;
	}
	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	@Override
	public String toString() {
		return "ATMDownBranchNSite [termId=" + termId + ", siteName=" + siteName + ", siteType=" + siteType
				+ ", branchId=" + branchId + ", branchName=" + branchName + ", country=" + country + "]";
	}
	
}
