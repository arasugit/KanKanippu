package com.fis.ist.monitoring.dto;

public class MonDbConnectedATM {
	
	private String connectedTerminals;

	public String getConnectedTerminals() {
		return connectedTerminals;
	}

	public void setConnectedTerminals(String connectedTerminals) {
		this.connectedTerminals = connectedTerminals;
	}
}
