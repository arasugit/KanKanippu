package com.fis.ist.monitoring.domain;

public class Transaction {

}
