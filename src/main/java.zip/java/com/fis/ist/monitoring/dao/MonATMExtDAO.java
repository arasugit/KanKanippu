package com.fis.ist.monitoring.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.domain.ATMExtId;
import com.fis.ist.monitoring.domain.MonATMExt;

@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
public class MonATMExtDAO extends MonitorBaseDAO<MonATMExt, ATMExtId> {
	private static final ISTLogger log = ISTLogger.getLogger(MonATMExtDAO.class);

	public Integer getTotalByExample(MonATMExt instance) {
		log.debug("MonATMExtDAO - getTotalByExample - MonATMExt ");
		Integer count = null;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(MonATMExt.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;

			data = instance.getTermId();
			if (data != null) {
				c.add(Restrictions.eq("termId", data).ignoreCase());
			}

			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;

		} catch (RuntimeException re) {
			log.error("MonAtmExtDAO - getTotalByExample Task Command failed", re);
			throw re;
		}
		return count;
	}

	public List<MonATMExt> findByExample(MonATMExt instance, int pageNum) {
		log.debug("MonAtmExtDAO - finding MonAtmExt instance by example");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(MonATMExt.class);
			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;

			data = instance.getTermId();
			if (data != null) {
				c.add(Restrictions.eq("termId", data).ignoreCase());
			}

			c = c.add(Restrictions.allEq(condition));
			c.addOrder(Order.asc("termId"));
			setPaging(c, pageNum);
			List<MonATMExt> results = c.list();

			log.debug("MonAtmExtDAO - findByExample successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("MonAtmExtDAO - find by example failed", re);
			throw re;
		}
	}

	@Override
	public Class<MonATMExt> getEntityClass() {
		return MonATMExt.class;
	}

}
