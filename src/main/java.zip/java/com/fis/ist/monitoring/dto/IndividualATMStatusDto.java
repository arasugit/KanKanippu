package com.fis.ist.monitoring.dto;
import com.fis.ist.monitoring.domain.IndividualATMStatus;

public class IndividualATMStatusDto implements java.io.Serializable {

	private static final long serialVersionUID = 6803023989652998245L;
	private String institutionId;
	private String netname;
	private String groupName;
	private Long unit;
	private Long severity;
	private Long fault;
	private String statusDescList;
	private String terminalComp;
	private String terminal;
	private String location;
	private String make;
	private String acceptorname;
	private Long siteId;
	
	public String getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	public String getNetname() {
		return netname;
	}
	public void setNetname(String netname) {
		this.netname = netname;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Long getUnit() {
		return unit;
	}
	public void setUnit(Long unit) {
		this.unit = unit;
	}
	public Long getSeverity() {
		return severity;
	}
	public void setSeverity(Long severity) {
		this.severity = severity;
	}
	public Long getFault() {
		return fault;
	}
	public void setFault(Long fault) {
		this.fault = fault;
	}
	public String getStatusDescList() {
		return statusDescList;
	}
	public void setStatusDescList(String statusDescList) {
		this.statusDescList = statusDescList;
	}
	public String getTerminalComp() {
		return terminalComp;
	}
	public void setTerminalComp(String terminalComp) {
		this.terminalComp = terminalComp;
	}
	public String getTerminal() {
		return terminal;
	}
	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getAcceptorname() {
		return acceptorname;
	}
	public void setAcceptorname(String acceptorname) {
		this.acceptorname = acceptorname;
	}
	public Long getSiteId() {
		return siteId;
	}
	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}
	
	public void load(IndividualATMStatus  domain) {
		setInstitutionId(domain.getInstitutionId());
		setNetname(domain.getNetname());
		setGroupName(domain.getGroupName());
		setUnit(domain.getUnit());
		setSeverity(domain.getSeverity());
		setFault(domain.getFault());
		setStatusDescList(domain.getStatusDescList());
		if (domain.getTerminalComp() != null) {
			setTerminal(domain.getTerminal() + domain.getTerminalComp());
		} else {
			setTerminal(domain.getTerminal());
		}
		
		setLocation(domain.getLocation());
		setMake(domain.getMake());
		setAcceptorname(domain.getAcceptorname());
		setSiteId(domain.getSiteId());	
		
	}	

}
