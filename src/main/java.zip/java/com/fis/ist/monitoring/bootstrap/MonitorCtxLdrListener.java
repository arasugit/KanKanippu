package com.fis.ist.monitoring.bootstrap;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.web.context.ConfigurableWebApplicationContext;

import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.log.ISTLogger;

public class MonitorCtxLdrListener extends org.springframework.web.context.ContextLoaderListener  {
	private static final ISTLogger log = ISTLogger.getLogger(MonitorCtxLdrListener.class);

	
	protected void customizeContext(ServletContext servletContext,
			ConfigurableWebApplicationContext applicationContext)
	{
		log.debug("customizeContext");
		String [] locations = applicationContext.getConfigLocations();
		ConfigParams cfg = ConfigParams.getInstance();
		String authentication = cfg.getProperty("ist.authentication");
		log.debug("ist.authentication:"+authentication);
		List<String> new_locs = new ArrayList<String>();
		for (String s: locations)
			new_locs.add(s);
		if ("cas".equalsIgnoreCase(authentication)){
			new_locs.add("/WEB-INF/applicationContext-security-cas.xml");
		}else if ("ldap".equalsIgnoreCase(authentication)){
			new_locs.add("/WEB-INF/applicationContext-security-ldap.xml");
		}else if ("ad".equalsIgnoreCase(authentication)){
			new_locs.add("/WEB-INF/applicationContext-security-ad.xml");
		}
		else if ("authenticator".equalsIgnoreCase(authentication) || 
				"oassrv".equalsIgnoreCase(authentication) ||
				"oas".equalsIgnoreCase(authentication)){			
			new_locs.add("/WEB-INF/applicationContext-security-oassrv.xml");
		}
		else if ("siteminder".equalsIgnoreCase(authentication))
		{
			new_locs.add("/WEB-INF/applicationContext-security-siteminder.xml");
		}
		else
		{
			log.error("Not configuring spring security, please configure ist.authentication");
		}
		  
		applicationContext.setConfigLocations(new_locs.toArray(locations));
		if (log.isDebugEnabled())
		{
			log.debug("locations:");
			for (String s: new_locs){
				log.debug(s);
			}
			log.debug("locations end");
		}
	}

	protected void customizeContext11(ServletContext servletContext,
			ConfigurableWebApplicationContext applicationContext) {
		super.customizeContext(servletContext, applicationContext);
		boolean added = false;
		List<String> addList = new ArrayList<String>();
		String[] temp = applicationContext.getConfigLocations();
		for (String loc : temp) {
			addList.add(loc);
			if (loc.indexOf("applicationContext-Custom-Report.xml") > -1) {
				added = true;
				break;
			}
		}

		if (!added) {
			addList.add("/WEB-INF/applicationContext-Custom-Report.xml");
			applicationContext.setConfigLocations(addList.toArray(temp));
			if (log.isDebugEnabled()) {
				log.debug("locations:");
				for (String s : addList) {
					log.debug(s);
				}
				log.debug("locations end");
			}
		}
	}
}
