package com.fis.ist.monitoring.dto;

import java.text.DecimalFormat;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class ATMRTCashPosListRow extends EditableListRowForSDK implements Cloneable {
	private static final ISTLogger log = ISTLogger.getLogger(ATMRTCashPosListRow.class);
	private String instId;
	private String groupname;
	private String atmUnit;
	private String termId;
	private String location;
	private String geoLocation;
	private String acceptorName;
	private String currency;
	private String country;
	private String branchId;
	private String branchName;
	private String siteType;
	private String siteName;
	private String make;
	private String time;
	private String endCash;
	private String cashOut;
	private String lastMsg;
	private String Hopper1_Bill;
	private String Hopper2_Bill;
	private String Hopper3_Bill;
	private String Hopper4_Bill;
	private String Hopper1_CashDispense;
	private String Hopper2_CashDispense;
	private String Hopper3_CashDispense;
	private String Hopper4_CashDispense;
	private String Hopper1_EndCash;
	private String Hopper2_EndCash;
	private String Hopper3_EndCash;
	private String Hopper4_EndCash;
	
	private ATMRTCashPosListRow orignalRow;
	DecimalFormat formatter = new DecimalFormat("#,###.00");
	
	@Override
	public String toString() {
		return "ATMRTCashPosListRow [instId=" + instId + ", groupname=" + groupname + ", atmUnit=" + atmUnit
				+ ", termId=" + termId + ", location=" + location + ", geoLocation=" + geoLocation + ", acceptorName="
				+ acceptorName + ", currency=" + currency + ", country=" + country + ", branchId=" + branchId
				+ ", branchName=" + branchName + ", siteType=" + siteType + ", siteName=" + siteName + ", make=" + make
				+ ", time=" + time + ", endCash=" + endCash + ", cashOut=" + cashOut + ", lastMsg=" + lastMsg
				+ ", Hopper1_Bill=" + Hopper1_Bill + ", Hopper2_Bill=" + Hopper2_Bill + ", Hopper3_Bill=" + Hopper3_Bill
				+ ", Hopper4_Bill=" + Hopper4_Bill + ", Hopper1_CashDispense=" + Hopper1_CashDispense
				+ ", Hopper2_CashDispense=" + Hopper2_CashDispense + ", Hopper3_CashDispense=" + Hopper3_CashDispense
				+ ", Hopper4_CashDispense=" + Hopper4_CashDispense + ", Hopper1_EndCash=" + Hopper1_EndCash
				+ ", Hopper2_EndCash=" + Hopper2_EndCash + ", Hopper3_EndCash=" + Hopper3_EndCash + ", Hopper4_EndCash="
				+ Hopper4_EndCash + "]";
	}

	public void loadISTDataFromDB(Object[] rowISTDataFromDB)
	{
		setInstId(rowISTDataFromDB[0] != null ? (String)rowISTDataFromDB[0] : "");
		setGroupname(rowISTDataFromDB[1] != null ? (String)rowISTDataFromDB[1] : "");
		setAtmUnit(rowISTDataFromDB[2] != null ? (String)rowISTDataFromDB[2] : "");
		setTermId(rowISTDataFromDB[3] != null ? (String)rowISTDataFromDB[3] : "");
		setTime(rowISTDataFromDB[4]);
		setLocation(rowISTDataFromDB[5] != null ? (String)rowISTDataFromDB[5] : "");
		setGeoLocation(rowISTDataFromDB[6] != null ? (String)rowISTDataFromDB[6] : "");
		setAcceptorName(rowISTDataFromDB[7] != null ? (String)rowISTDataFromDB[7] : "");
		setCurrency(rowISTDataFromDB[8] != null ? (String)rowISTDataFromDB[8] : "");
		setMake(rowISTDataFromDB[9] != null ? (String)rowISTDataFromDB[9] : "");
		setLastMsg(rowISTDataFromDB[10]);
		setHopper1_Bill(rowISTDataFromDB[11] != null ? (String)rowISTDataFromDB[11] : "0");
		setHopper2_Bill(rowISTDataFromDB[12] != null ? (String)rowISTDataFromDB[12] : "0");
		setHopper3_Bill(rowISTDataFromDB[13] != null ? (String)rowISTDataFromDB[13] : "0");
		setHopper4_Bill(rowISTDataFromDB[14] != null ? (String)rowISTDataFromDB[14] : "0");
		setHopper1_CashDispense(rowISTDataFromDB[15] != null ? (String)rowISTDataFromDB[15] : "0");
		setHopper2_CashDispense(rowISTDataFromDB[16] != null ? (String)rowISTDataFromDB[16] : "0");
		setHopper3_CashDispense(rowISTDataFromDB[17] != null ? (String)rowISTDataFromDB[17] : "0");
		setHopper4_CashDispense(rowISTDataFromDB[18] != null ? (String)rowISTDataFromDB[18] : "0");
		setHopper1_EndCash(rowISTDataFromDB[19] != null ? (String)rowISTDataFromDB[19] : "0");
		setHopper2_EndCash(rowISTDataFromDB[20] != null ? (String)rowISTDataFromDB[20] : "0");
		setHopper3_EndCash(rowISTDataFromDB[21] != null ? (String)rowISTDataFromDB[21] : "0");
		setHopper4_EndCash(rowISTDataFromDB[22] != null ? (String)rowISTDataFromDB[22] : "0");
				
		double endCash = Double.parseDouble(getHopper1_EndCash()) + 
				Double.parseDouble(getHopper2_EndCash()) +
				Double.parseDouble(getHopper3_EndCash()) +
				Double.parseDouble(getHopper4_EndCash());
		
		if(endCash == 0) {
			setEndCash("0.00");
		} else {
			setEndCash(formatter.format(endCash));
		}
		
		double cashOut = Double.parseDouble(getHopper1_CashDispense()) + 
				Double.parseDouble(getHopper2_CashDispense()) + 
				Double.parseDouble(getHopper3_CashDispense()) + 
				Double.parseDouble(getHopper4_CashDispense());
			
		if(cashOut == 0) {
			setCashOut("0.00");
		} else {
			setCashOut(formatter.format(cashOut));
		}
		
		setHopper1_Bill(convertWithProperFormat(getHopper1_Bill()));
		setHopper2_Bill(convertWithProperFormat(getHopper2_Bill()));
		setHopper3_Bill(convertWithProperFormat(getHopper3_Bill()));
		setHopper4_Bill(convertWithProperFormat(getHopper4_Bill()));
		
		setHopper1_CashDispense(convertWithProperFormat(getHopper1_CashDispense()));
		setHopper2_CashDispense(convertWithProperFormat(getHopper2_CashDispense()));
		setHopper3_CashDispense(convertWithProperFormat(getHopper3_CashDispense()));
		setHopper4_CashDispense(convertWithProperFormat(getHopper4_CashDispense()));
		
		setHopper1_EndCash(convertWithProperFormat(getHopper1_EndCash()));
		setHopper2_EndCash(convertWithProperFormat(getHopper2_EndCash()));
		setHopper3_EndCash(convertWithProperFormat(getHopper3_EndCash()));
		setHopper4_EndCash(convertWithProperFormat(getHopper4_EndCash()));
	}
	
	private String convertWithProperFormat(String retrievedValue) {
		
		String valueToPrint = "0.00";
		
		if(!"0".equalsIgnoreCase(retrievedValue)) {
			valueToPrint = formatter.format(Double.parseDouble(retrievedValue));
		} 
		
		return valueToPrint;
	}
	
	public void loadMonDBDataFromDB(Object[] rowMonDBDataFromDB)
	{
		setTermId(rowMonDBDataFromDB[0] != null ? (String)rowMonDBDataFromDB[0] : "");
		setSiteName(rowMonDBDataFromDB[1] != null ? (String)rowMonDBDataFromDB[1] : "");
		setSiteType(rowMonDBDataFromDB[2] != null ? (String)rowMonDBDataFromDB[2] : "");
		setBranchId(rowMonDBDataFromDB[3] != null ? (String)rowMonDBDataFromDB[3] : "");
		setBranchName(rowMonDBDataFromDB[4] != null ? (String)rowMonDBDataFromDB[4] : "");
		setCountry(rowMonDBDataFromDB[5] != null ? (String)rowMonDBDataFromDB[5] : "");
	} 
	
	public void mergeMonDBDataWithISTDBData(ATMRTCashPosListRow rowMonDBData)
	{
		setSiteName(rowMonDBData.getSiteName());
		setSiteType(rowMonDBData.getSiteType());
		setBranchId(rowMonDBData.getBranchId());
		setBranchName(rowMonDBData.getBranchName());
		setCountry(rowMonDBData.getCountry());
	}
	

	public String getInstId() {
		return instId;
	}

	public void setInstId(String instId) {
		this.instId = instId;
	}

	public String getAtmUnit() {
		return atmUnit;
	}

	public void setAtmUnit(String atmUnit) {
		this.atmUnit = atmUnit;
	}

	public String getTermId() {
		return termId;
	}

	public void setTermId(String termId) {
		this.termId = termId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public ATMRTCashPosListRow getOrignalRow() {
		return orignalRow;
	}

	public String getAcceptorName() {
		return acceptorName;
	}

	public void setAcceptorName(String acceptorName) {
		this.acceptorName = acceptorName;
	}

	public String getGeoLocation() {
		return geoLocation;
	}

	public void setGeoLocation(String geoLocation) {
		this.geoLocation = geoLocation;
	}
	
	public String getSiteType() {
		return siteType;
	}

	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getTime() {
		return time;
	}

	public void setTime(Object time) {
		this.time = PaymonUtils.getFormattedResponseDateTime(time);
	}

	public String getEndCash() {
		return endCash;
	}

	public void setEndCash(String endCash) {
		this.endCash = endCash;
	}

	public String getCashOut() {
		return cashOut;
	}

	public void setCashOut(String cashOut) {
		this.cashOut = cashOut;
	}
	

	public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public String getLastMsg() {
		return lastMsg;
	}

	public void setLastMsg(Object lastMsg) {
		this.lastMsg = PaymonUtils.getFormattedResponseDateTime(lastMsg);
	}

	public String getHopper1_Bill() {
		return Hopper1_Bill;
	}

	public void setHopper1_Bill(String hopper1_Bill) {
		Hopper1_Bill = hopper1_Bill;
	}

	public String getHopper2_Bill() {
		return Hopper2_Bill;
	}

	public void setHopper2_Bill(String hopper2_Bill) {
		Hopper2_Bill = hopper2_Bill;
	}

	public String getHopper3_Bill() {
		return Hopper3_Bill;
	}

	public void setHopper3_Bill(String hopper3_Bill) {
		Hopper3_Bill = hopper3_Bill;
	}

	public String getHopper4_Bill() {
		return Hopper4_Bill;
	}

	public void setHopper4_Bill(String hopper4_Bill) {
		Hopper4_Bill = hopper4_Bill;
	}

	public String getHopper1_CashDispense() {
		return Hopper1_CashDispense;
	}

	public void setHopper1_CashDispense(String hopper1_CashDispense) {
		Hopper1_CashDispense = hopper1_CashDispense;
	}

	public String getHopper2_CashDispense() {
		return Hopper2_CashDispense;
	}

	public void setHopper2_CashDispense(String hopper2_CashDispense) {
		Hopper2_CashDispense = hopper2_CashDispense;
	}

	public String getHopper3_CashDispense() {
		return Hopper3_CashDispense;
	}

	public void setHopper3_CashDispense(String hopper3_CashDispense) {
		Hopper3_CashDispense = hopper3_CashDispense;
	}

	public String getHopper4_CashDispense() {
		return Hopper4_CashDispense;
	}

	public void setHopper4_CashDispense(String hopper4_CashDispense) {
		Hopper4_CashDispense = hopper4_CashDispense;
	}

	public String getHopper1_EndCash() {
		return Hopper1_EndCash;
	}

	public void setHopper1_EndCash(String hopper1_EndCash) {
		Hopper1_EndCash = hopper1_EndCash;
	}

	public String getHopper2_EndCash() {
		return Hopper2_EndCash;
	}

	public void setHopper2_EndCash(String hopper2_EndCash) {
		Hopper2_EndCash = hopper2_EndCash;
	}

	public String getHopper3_EndCash() {
		return Hopper3_EndCash;
	}

	public void setHopper3_EndCash(String hopper3_EndCash) {
		Hopper3_EndCash = hopper3_EndCash;
	}

	public String getHopper4_EndCash() {
		return Hopper4_EndCash;
	}

	public void setHopper4_EndCash(String hopper4_EndCash) {
		Hopper4_EndCash = hopper4_EndCash;
	}

	@Override
	public String getFormKey() {
		return "instId";
	}

	public void setOrignalRow(ATMRTCashPosListRow orignalRow) {
		try {
			if (orignalRow != null)
				this.orignalRow = (ATMRTCashPosListRow) orignalRow.clone();
		} catch (Exception e) {
			log.error(e);
		}
	}

}
