package com.fis.ist.monitoring.dto;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.domain.TpsVsMemory;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class TpsVsMemoryDto extends EditableListRowForSDK implements Cloneable {
	private static final long serialVersionUID = 1L;

	private static final ISTLogger log = ISTLogger.getLogger(TpsVsMemoryDto.class);

	private Integer id;
	private String product;
	private Integer siteId;
	private Integer NodeId;
	private String NodeName;
	private String logDate;
	private String currentTps;
	private String totalMemory;
	private String usedMemory;
	private String freeMemory;
	private String cacheMemory;
	private String usedMemoryPct;
	private String swapTotal;
	private String swapFree;
	private String cpuUser;
	private String cpuSys;
	private String swapUsed;
	private String specialStr;
	private TpsVsMemoryDto orignalRow;
	
	public String getSpecialStr() {
		return specialStr;
	}

	public void setSpecialStr(Object specialStr) {
		this.specialStr = PaymonUtils.getFormattedResponseDate(specialStr);
	}	

	public void loadDTO(Object[] model, String type) {

		if (null != model[2])
			setTotalMemory((String) model[2]);
		else
			setTotalMemory("0");
		if (null != model[3])
			setUsedMemory((String) model[3]);
		else
			setUsedMemory("0");

		setFreeMemory((String) model[4]);
		setUsedMemoryPct((String) model[5]);
		setSwapTotal((String) model[6]);
		setSwapUsed((String) model[7]);
		setSwapFree((String) model[8]);

		if (null != model[9])
			setCpuUser((String) model[9]);
		else
			setCpuUser("0");

		if (null != model[10])
			setCpuSys((String) model[10]);
		else
			setCpuSys("0");

		setLogDate(model[1]);
		setSpecialStr(model[1]);
		
		if (null != model[11])
			setCurrentTps((String) model[11]);
		else
			setCurrentTps("0");
	}

	// site_id, logdate, current_tps
	public void loadTPSDTO(Object[] model, String type) {
		if (null != model[2])
			setCurrentTps((String) model[2]);
		else
			setCurrentTps("0");
		
		setLogDate(model[1]);
		setSpecialStr(model[1]);
	}

	public TpsVsMemoryDto getOrignalRow() {
		return orignalRow;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String getFormKey() {
		return "product";
	}

	public void setOrignalRow(TpsVsMemoryDto orignalRow) {
		try {
			if (orignalRow != null)
				this.orignalRow = (TpsVsMemoryDto) orignalRow.clone();
		} catch (Exception e) {
			log.error(e);
		}
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public Integer getSiteId() {
		return siteId;
	}

	public void setSiteId(Integer siteId) {
		this.siteId = siteId;
	}

	public Integer getNodeId() {
		return NodeId;
	}

	public void setNodeId(Integer nodeId) {
		NodeId = nodeId;
	}

	public String getNodeName() {
		return NodeName;
	}

	public void setNodeName(String nodeName) {
		NodeName = nodeName;
	}

	public String getLogDate() {
		return logDate;
	}

	public void setLogDate(Object logDate) {
		this.logDate = PaymonUtils.getTimeFromDateTime(logDate);
	}

	public String getCurrentTps() {
		return currentTps;
	}

	public void setCurrentTps(String currentTps) {
		this.currentTps = currentTps;
	}

	public String getTotalMemory() {
		return totalMemory;
	}

	public void setTotalMemory(String totalMemory) {
		this.totalMemory = totalMemory;
	}

	public String getUsedMemory() {
		return usedMemory;
	}

	public void setUsedMemory(String usedMemory) {
		this.usedMemory = usedMemory;
	}

	public String getFreeMemory() {
		return freeMemory;
	}

	public void setFreeMemory(String freeMemory) {
		this.freeMemory = freeMemory;
	}

	public String getCacheMemory() {
		return cacheMemory;
	}

	public void setCacheMemory(String cacheMemory) {
		this.cacheMemory = cacheMemory;
	}

	public String getUsedMemoryPct() {
		return usedMemoryPct;
	}

	public void setUsedMemoryPct(String usedMemoryPct) {
		this.usedMemoryPct = usedMemoryPct;
	}

	public String getSwapTotal() {
		return swapTotal;
	}

	public void setSwapTotal(String swapTotal) {
		this.swapTotal = swapTotal;
	}

	public String getSwapFree() {
		return swapFree;
	}

	public void setSwapFree(String swapFree) {
		this.swapFree = swapFree;
	}

	public String getCpuUser() {
		return cpuUser;
	}

	public void setCpuUser(String cpuUser) {
		this.cpuUser = cpuUser;
	}

	public String getCpuSys() {
		return cpuSys;
	}

	public void setCpuSys(String cpuSys) {
		this.cpuSys = cpuSys;
	}

	public String getSwapUsed() {
		return swapUsed;
	}

	public void setSwapUsed(String swapUsed) {
		this.swapUsed = swapUsed;
	}

	public void store(TpsVsMemory model) {
		model.setProduct(product);

	}

}
