package com.fis.ist.monitoring.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RetentionConfigId implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String product;   // PRODUCT
	private Integer siteId;   // SITE_ID
	private Integer nodeId;   // NODE_ID
	private String tableName; // TABLE_NAME
	private String keyFields; // KEY_FIELDS
	
	public RetentionConfigId() {}
	
	
	public RetentionConfigId(String product, Integer siteId, Integer nodeId, String tableName, String keyFields) {
		super();
		this.product = product;
		this.siteId = siteId;
		this.nodeId = nodeId;
		this.tableName = tableName;
		this.keyFields = keyFields;
	}

	@Column(name = "PRODUCT", nullable = false, length = 20)
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@Column(name = "SITE_ID", nullable = false, length = 38)
	public Integer getSiteId() {
		return siteId;
	}

	public void setSiteId(Integer siteId) {
		this.siteId = siteId;
	}

	@Column(name = "NODE_ID", nullable = false, length = 38)
	public Integer getNodeId() {
		return nodeId;
	}

	public void setNodeId(Integer nodeId) {
		this.nodeId = nodeId;
	}
	
	@Column(name = "TABLE_NAME", nullable = false, length = 100)
	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	@Column(name = "KEY_FIELDS", nullable = false, length = 100)
	public String getKeyFields() {
		return keyFields;
	}

	public void setKeyFields(String keyFields) {
		this.keyFields = keyFields;
	}

	@Override
	public String toString() {
		return "RetentionConfigId [product=" + product + ", siteId=" + siteId + ", nodeId=" + nodeId + ", tableName="
				+ tableName + ", keyFields=" + keyFields + "]";
	}
	
}
