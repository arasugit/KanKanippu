package com.fis.ist.monitoring.dto;

public class ATMByMake implements java.io.Serializable{
	
	String make;
	Integer totalConfiguredATMByMake;
	Integer totalRunningATMByMake;
	Integer totalDownATMByMake;
	
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public Integer getTotalConfiguredATMByMake() {
		return totalConfiguredATMByMake;
	}
	public void setTotalConfiguredATMByMake(Integer totalConfiguredATMByMake) {
		this.totalConfiguredATMByMake = totalConfiguredATMByMake;
	}
	public Integer getTotalRunningATMByMake() {
		return totalRunningATMByMake;
	}
	public void setTotalRunningATMByMake(Integer totalRunningATMByMake) {
		this.totalRunningATMByMake = totalRunningATMByMake;
	}
	public Integer getTotalDownATMByMake() {
		return totalDownATMByMake;
	}
	public void setTotalDownATMByMake(Integer totalDownATMByMake) {
		this.totalDownATMByMake = totalDownATMByMake;
	}
}
