package com.fis.ist.monitoring.dto;

public class PosDashboardDto implements java.io.Serializable {
private static final long serialVersionUID = 1L;
	
	private String institutionId;
	private Integer merchantCount;
	private Integer terminalCount;
	private Integer functionalTerminalCount;
	private Integer nonfunctionalTerminalCount;

	public String getInstitutionId() {
		return institutionId;
	}
	
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	
	public Integer getMerchantCount() {
		return merchantCount;
	}
	
	public void setMerchantCount(Integer merchantCount) {
		this.merchantCount = merchantCount;
	}
	
	public Integer getTerminalCount() {
		return terminalCount;
	}
	
	public void setTerminalCount(Integer terminalCount) {
		this.terminalCount = terminalCount;
	}
	
	public Integer getFunctionalTerminalCount() {
		return functionalTerminalCount;
	}
	
	public void setFunctionalTerminalCount(Integer functionalTerminalCount) {
		this.functionalTerminalCount = functionalTerminalCount;
	}
	
	public Integer getNonfunctionalTerminalCount() {
		return nonfunctionalTerminalCount;
	}
	
	public void setNonfunctionalTerminalCount(Integer nonfunctionalTerminalCount) {
		this.nonfunctionalTerminalCount = nonfunctionalTerminalCount;
	}
}
