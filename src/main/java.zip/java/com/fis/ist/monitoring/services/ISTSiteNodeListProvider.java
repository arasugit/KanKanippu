package com.fis.ist.monitoring.services;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fis.ist.common.IListProvider;
import com.fis.ist.monitoring.dao.AppCommonDAO;

public class ISTSiteNodeListProvider implements IListProvider {

	private String searchListType = "";

	@Override
	public List getList() {
		List recordList = new AppCommonDAO().getNodeRecords();
		Object arr;
		Set<String> sitesSet = new HashSet<>();
		Set<String> nodesSet = new HashSet<>();
		Map<String, Set<String>> map = new HashMap<>();
		String site = "";
		String noedeName = "";
		for (int i = 0; i < recordList.size(); i++) {
			if (recordList.size() > 1) {
				arr = recordList.get(i);
				site = (String) ((Object[]) arr)[0];
				noedeName = (String) ((Object[]) arr)[2];
				sitesSet.add(site);
				if (map.get(site) != null) {
					map.get(site).add(noedeName);
				} else {
					nodesSet = new HashSet<>();
					nodesSet.add(noedeName);
					map.put(site, nodesSet);
				}
			}
		}
		String siteId = "";
		String nodeIds = "";
		String nodeNames = "";
		String[] nodeAll;
		Object[] sites = (Object[]) sitesSet.toArray();
		String str;
		for (int i = 0; i < sites.length; i++) {
			str = (String) sites[i];
			if (map.get(str).size() > 1) {
				nodeAll = new String[3];
				for (int j = 0; j < recordList.size(); j++) {
					arr = recordList.get(j);
					siteId = (String) ((Object[]) arr)[0];
					if (str.equals(siteId)) {
						if (j < recordList.size() - 1) {
							nodeIds = nodeIds + "" + (String) ((Object[]) arr)[1] + ", ";
							nodeNames = nodeNames + "" + (String) ((Object[]) arr)[2] + ", ";

						} else {
							nodeIds = nodeIds + "" + (String) ((Object[]) arr)[1];
							nodeNames = nodeNames + "" + (String) ((Object[]) arr)[2];
						}
					}
				}

				nodeAll[0] = siteId;
				nodeAll[1] = nodeIds;
				nodeAll[2] = "All Nodes ("+nodeNames + " )";
				recordList.add(nodeAll);
			}
		}
		return recordList;
	}

	@Override
	public String getName() {
		return "IST_SITE_NODE_LIST";
	}

	@Override
	public List getList(Map<String, String> arg0) {
		return null;
	}

	@Override
	public List getListByInstitution(String arg0) {
		return null;
	}

}
