package com.fis.ist.monitoring.dto;

public class MemoryStatusDto implements java.io.Serializable {
private static final long serialVersionUID = 1L;
	
	private String totalSize;
	private String used;
	private String usedForCache;
	private String usedAndCache;
	private String free;
	private String usedAndCachePercent;
	private String usedForCachePercent;
	private String freePercent;
	private String usedPercent;

	public String getTotalSize() {
		return totalSize;
	}
	
	public void setTotalSize(String totalSize) {
		this.totalSize = totalSize;
	}
	
	public String getUsed() {
		return used;
	}
	
	public void setUsed(String used) {
		this.used = used;
	}
	
	public String getUsedForCache() {
		return usedForCache;
	}
	
	public void setUsedForCache(String usedForCache) {
		this.usedForCache = usedForCache;
	}
	
	public String getUsedAndCache() {
		return usedAndCache;
	}
	
	public void setUsedAndCache(String usedAndCache) {
		this.usedAndCache = usedAndCache;
	}
	
	public String getFree() {
		return free;
	}
	
	public void setFree(String free) {
		this.free = free;
	}
	
	public String getUsedAndCachePercent() {
		return usedAndCachePercent;
	}
	
	public void setUsedAndCachePercent(String usedAndCachePercent) {
		this.usedAndCachePercent = usedAndCachePercent;
	}
	
	public String getUsedForCachePercent() {
		return usedForCachePercent;
	}
	
	public void setUsedForCachePercent(String usedForCachePercent) {
		this.usedForCachePercent = usedForCachePercent;
	}
	
	public String getFreePercent() {
		return freePercent;
	}
	
	public void setFreePercent(String freePercent) {
		this.freePercent = freePercent;
	}
	
	public String getUsedPercent() {
		return usedPercent;
	}
	
	public void setUsedPercent(String usedPercent) {
		this.usedPercent = usedPercent;
	}
}
