package com.fis.ist.monitoring.services.handler;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.PosMerchantDao;
import com.fis.ist.monitoring.domain.POSMerchantDetails;
import com.fis.ist.monitoring.dto.POSMerchantDetailsDto;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class POSMerchantDetailsHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(POSMerchantDetailsHandler.class);
	private static String reqTypeId = MonitorConstants.POSMERCHNT_REQ;
	private static String formAuthId = "POSMERCHNT";

	public POSMerchantDetailsHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getPOSMerchants(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}


	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, MonitorConstants.POSMERCHNT_TAB);
	}


	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(MonitorConstants.POSMERCHNT_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(MonitorConstants.POSMERCHNT_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(MonitorConstants.POSMERCHNT_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(MonitorConstants.POSMERCHNT_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load POS Merchant Details Screen");

		// remove above -- our code --
		String institutionId = params.get("ist_inst_Id").trim();
		String parentEntityId = params.get("parentEntityId").trim();
		String entityLevel = params.get("entityLevel").trim();
		String entityId = params.get("entityId").trim();
		String dbaName = params.get("dbaName").trim();
		String entityStatus = params.get("entityStatus").trim();
		String externalEntityId = params.get("externalEntityId").trim();
		String creationDateFrom = params.get("creationDateFrom");
		String creationDateTo = params.get("creationDateTo");
		String terminationDateFrom = params.get("terminationDateFrom");
		String terminationDateTo = params.get("terminationDateTo");

		PosMerchantDao dao = new PosMerchantDao();
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));

		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		DateFormat outputFormat = new SimpleDateFormat(PaymonUtils.InputDateConversionFormat);
		DateFormat inputFormat = new SimpleDateFormat(PaymonUtils.InputDateFormat);
		String fromDateFormat = PaymonUtils.DatabaseDateConversionFormat;
		String toDateFormat = PaymonUtils.DatabaseDateConversionFormat;

		try {
			creationDateFrom = StringUtil.isNotEmpty(creationDateFrom)
					? outputFormat.format(inputFormat.parse(creationDateFrom))
					: null;
			creationDateTo = StringUtil.isNotEmpty(creationDateTo)
					? outputFormat.format(inputFormat.parse(creationDateTo))
					: null;
			terminationDateFrom = StringUtil.isNotEmpty(terminationDateFrom)
					? outputFormat.format(inputFormat.parse(terminationDateFrom))
					: null;
			terminationDateTo = StringUtil.isNotEmpty(terminationDateTo)
					? outputFormat.format(inputFormat.parse(terminationDateTo))
					: null;
		} catch (ParseException e1) {
			log.error(e1);
		}

		List<POSMerchantDetails> recordList = null;

		if (needs_total) {
			total = dao.getPosMerchantsDetailsCount(institutionId, parentEntityId, entityLevel, entityId, dbaName,
					creationDateFrom, creationDateTo, terminationDateFrom, terminationDateTo, externalEntityId,
					entityStatus, fromDateFormat, toDateFormat);
		}

		recordList = dao.getPOSMerchantsDetails(institutionId, parentEntityId, entityLevel, entityId, dbaName,
				creationDateFrom, creationDateTo, terminationDateFrom, terminationDateTo, externalEntityId,
				entityStatus, fromDateFormat, toDateFormat, pageNum, true);

		if (recordList.size() == 0) {
			log.debug("No records found !!!");
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		POSMerchantDetailsDto totalsDto = null;
		List<POSMerchantDetailsDto> workRows = getPOSMerchantList(workRequest, uiMetaData);
		if (recordList != null) {
			for (POSMerchantDetails posMerchant : recordList) {
				totalsDto = new POSMerchantDetailsDto();
				totalsDto.load(posMerchant);
				workRows.add(totalsDto);
			}
		}

	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {
			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);
			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();
		return validateFields(fieldDataMap);
	}

	private List<POSMerchantDetailsDto> getPOSMerchantList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(MonitorConstants.POSMERCHNT_COL);
		workCollection.setSectionId(MonitorConstants.POSMERCHNT_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(MonitorConstants.POSMERCHNT_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<POSMerchantDetailsDto> workRows = new ArrayList<POSMerchantDetailsDto>();
		updateWorkCollectionFields(workRequest, uiMetaData, MonitorConstants.POSMERCHNT_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}
