package com.fis.ist.monitoring.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.hibernate.jpa.QueryHints;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.common.services.MonitorConfigService;
import com.fis.ist.monitoring.dto.Pair;
import com.fis.ist.monitoring.dto.TxnAuthDenialDto;
import com.fis.ist.monitoring.dto.TxnCompletionTimeDto;
import com.fis.ist.monitoring.dto.TxnFailuresDto;
import com.fis.ist.monitoring.dto.TxnPeakVolumesDto;
import com.fis.ist.spring.HTTPRequestGetter;

public class TransactionsDAO extends MonitorBaseDAO<Integer, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(TransactionsDAO.class);
	
	public static final String transType = "transType";

	@Override
	public Class<Integer> getEntityClass() {
		return Integer.class;
	}

	public List getAcquirerTxnSRC(String product, String fieldName) {
		log.debug(String.format("Selecting acquirer tranansaction source from db for Product: %s, FieldName: %s",
				product, fieldName));
		try {
			StringBuffer queryBuffer = new StringBuffer();
			String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");
			queryBuffer.append(
					" select distinct field_name, field_value0 as txnsrc, field_value1 as acquirer from cs_monglobalvalue where  product = ?  and  field_name=? ");

			String queryString = queryBuffer.toString();
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("txnsrc", StandardBasicTypes.STRING)
					.addScalar("acquirer", StandardBasicTypes.STRING);
			queryObject.setParameter(1, productId);
			queryObject.setParameter(2, fieldName);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// SQL#5 Fetch TxnDest
	public List getAcquirerTxnDest(String product, String fieldName) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");
			queryBuffer.append(
					"select distinct field_value0 from CS_MONGLOBALVALUE where product = ? and field_name = ? ");

			String queryString = queryBuffer.toString();
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString);

			queryObject.setParameter(1, productId);
			queryObject.setParameter(2, fieldName);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Req#R0008
	public List getAcquirerTransactionStats(List<String> acqs, List<String> txnsrcs, String type, int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSTS_REQ");
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, type);

			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("txnsrc", StandardBasicTypes.STRING)
					.addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("TotalApprovalCnt", StandardBasicTypes.STRING)
					.addScalar("TotalDeclineCnt", StandardBasicTypes.STRING)
					.addScalar("TotalReversalCnt", StandardBasicTypes.STRING)
					.addScalar("TotalCount", StandardBasicTypes.STRING)
					.addScalar("ApprovalPercentage", StandardBasicTypes.STRING)
					.addScalar("DeclinePercentage", StandardBasicTypes.STRING)
					.addScalar("ReversalPercentage", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			List<Integer> msgTypes = new ArrayList<>();
			// 110,210,410,430
			msgTypes.addAll(Arrays.asList(110, 210, 410, 430));
			queryObject.setParameterList("msgTypes", msgTypes);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public List getIssuerTransactionStats(List<String> acqs, List<String> txnsrcs, String type, int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNISS_REQ");
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, type);
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("txnsrc", StandardBasicTypes.STRING)
					.addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("TotalApprovalCnt", StandardBasicTypes.STRING)
					.addScalar("TotalDeclineCnt", StandardBasicTypes.STRING)
					.addScalar("TotalReversalCnt", StandardBasicTypes.STRING)
					.addScalar("TotalCount", StandardBasicTypes.STRING)
					.addScalar("ApprovalPercentage", StandardBasicTypes.STRING)
					.addScalar("DeclinePercentage", StandardBasicTypes.STRING)
					.addScalar("ReversalPercentage", StandardBasicTypes.STRING);
			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public List getTransactionStatsByRespCode(List<String> acqs, List<String> txnsrcs, String type, String startDate,
			String starTime, String endDate, String endTime) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNRC_REQ");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("acq_currency_code", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public List getTopTerminalCompTransactions(List<String> acqs, List<String> txnsrcs, String screenType,
			int pageNum) {
		try {
			String queryString = "";
			if (screenType.equalsIgnoreCase("TXNTC_REQ")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTC_REQ_DAILY");
			} else if (screenType.equalsIgnoreCase("WEEKLY")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTC_REQ_WEEKLY");
			} else if (screenType.equalsIgnoreCase("MONTHLY")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTC_REQ_MONTHLY");
			}

			Query queryObject = null;
			if (screenType.equalsIgnoreCase("TXNTC_REQ")) {
				queryObject = getSession().createSQLQuery(queryString).addScalar("termid", StandardBasicTypes.STRING)
						.addScalar("TotalTransactions", StandardBasicTypes.STRING)
						.addScalar("TransactionDate", StandardBasicTypes.STRING);
			} else if (screenType.equalsIgnoreCase("WEEKLY")) {
				queryObject = getSession().createSQLQuery(queryString).addScalar("termid", StandardBasicTypes.STRING)
						.addScalar("TotalTransactions", StandardBasicTypes.STRING)
						.addScalar("WeekStartDate", StandardBasicTypes.STRING);
			} else if (screenType.equalsIgnoreCase("MONTHLY")) {
				queryObject = getSession().createSQLQuery(queryString).addScalar("termid", StandardBasicTypes.STRING)
						.addScalar("TotalTransactions", StandardBasicTypes.STRING)
						.addScalar("TransactionMonth", StandardBasicTypes.STRING);
			}
			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public int getTopTerminalCompTransactionsCount(List<String> acqs, List<String> txnsrcs, String screenType) {
		try {
			String queryString = "";
			if (screenType.equalsIgnoreCase("TXNTC_REQ")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTC_REQ_DAILY_CNT");
			} else if (screenType.equalsIgnoreCase("WEEKLY")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTC_REQ_WEEKLY_CNT");
			} else if (screenType.equalsIgnoreCase("MONTHLY")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTC_REQ_MONTHLY_CNT");
			}

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public List getLeastTerminalCompTransactions(List<String> acqs, List<String> txnsrcs, String screenType,
			int pageNum) {
		try {
			String queryString = "";
			if (screenType.equalsIgnoreCase("TXNTL_REQ") || screenType.equalsIgnoreCase("LEASTDAILY")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTL_REQ_DAILY");
			} else if (screenType.equalsIgnoreCase("LEASTWEEKLY")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTL_REQ_WEEKLY");

			} else if (screenType.equalsIgnoreCase("MONTHLY") || screenType.equalsIgnoreCase("LEASTMONTHLY")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTL_REQ_MONTHLY");
			}

			Query queryObject = null;
			if (screenType.equalsIgnoreCase("TXNTL_REQ") || screenType.equalsIgnoreCase("LEASTDAILY")) {
				queryObject = getSession().createSQLQuery(queryString).addScalar("termid", StandardBasicTypes.STRING)
						.addScalar("TotalTransactions", StandardBasicTypes.STRING)
						.addScalar("TransactionDate", StandardBasicTypes.STRING);
			} else if (screenType.equalsIgnoreCase("LEASTWEEKLY")) {
				queryObject = getSession().createSQLQuery(queryString).addScalar("termid", StandardBasicTypes.STRING)
						.addScalar("TotalTransactions", StandardBasicTypes.STRING)
						.addScalar("WeekStartDate", StandardBasicTypes.STRING);
			} else if (screenType.equalsIgnoreCase("MONTHLY") || screenType.equalsIgnoreCase("LEASTMONTHLY")) {
				queryObject = getSession().createSQLQuery(queryString).addScalar("termid", StandardBasicTypes.STRING)
						.addScalar("TotalTransactions", StandardBasicTypes.STRING)
						.addScalar("TransactionMonth", StandardBasicTypes.STRING);
			}
			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);

			setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public int getLeastTerminalCompTransactionsCount(List<String> acqs, List<String> txnsrcs, String screenType) {
		try {
			String queryString = "";
			if (screenType.equalsIgnoreCase("TXNTL_REQ") || screenType.equalsIgnoreCase("LEASTDAILY")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTL_REQ_DAILY_CNT");
			} else if (screenType.equalsIgnoreCase("LEASTWEEKLY")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTL_REQ_WEEKLY_CNT");

			} else if (screenType.equalsIgnoreCase("MONTHLY") || screenType.equalsIgnoreCase("LEASTMONTHLY"))
				queryString = SqlQueryProvider.getDBSqlQuery("TXNTL_REQ_MONTHLY_CNT");

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Req R0008 Sql R0008f1
	public List getTransStatsAcqComp(List<String> acqs, List<String> txnsrcs, String screenType) {
		try {
			String queryString = "";
			if (screenType.equalsIgnoreCase("TXNSTS_ACQ") || screenType.equalsIgnoreCase("TXNSTS_ISS")
					|| screenType.equalsIgnoreCase("DAILY")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNSTS_ACQ_DAILY");
			} else if (screenType.equalsIgnoreCase("WEEKLY"))
				queryString = SqlQueryProvider.getDBSqlQuery("TXNSTS_ACQ_WEEKLY");
			else if (screenType.equalsIgnoreCase("MONTHLY"))
				queryString = SqlQueryProvider.getDBSqlQuery("TXNSTS_ACQ_MONTHLY");

			Query queryObject = null;
			if (screenType.equalsIgnoreCase("TXNSTS_ACQ") || screenType.equalsIgnoreCase("DAILY")
					|| screenType.equalsIgnoreCase("TXNSTS_ISS") || screenType.equalsIgnoreCase("MONTHLY")) {
				queryObject = getSession().createSQLQuery(queryString)
						.addScalar("TotalTransactions", StandardBasicTypes.STRING)
						.addScalar("TransactionDate", StandardBasicTypes.STRING);
			} else if (screenType.equalsIgnoreCase("WEEKLY")) {
				queryObject = getSession().createSQLQuery(queryString)
						.addScalar("TotalTransactions", StandardBasicTypes.STRING)
						.addScalar("WeekStartDate", StandardBasicTypes.STRING);
			}
			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// R0011
	public List getTransAcqT5Rjection(List<String> acqs, List<String> txnsrcs, List<String> declineRespCodeList,
			String fromDate, String toDate, String fromDateFormate, String toDateFormate, int pageNum) {
		try {
			String queryString = "";
			queryString = SqlQueryProvider.getDBSqlQuery("TXNRJACQ");
			if (declineRespCodeList != null && declineRespCodeList.size() > 0) {
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and CAST(respcode as VARCHAR(10)) in (:declineRespCodes)  ");
			} else {
				queryString = queryString.replaceAll("FILTER_QUERY", " and respcode != 0 ");
			}
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chipindex", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING)
					.addScalar("istsysdate", StandardBasicTypes.TIMESTAMP)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.STRING)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);

			if (declineRespCodeList != null && declineRespCodeList.size() > 0) {
				queryObject.setParameter("declineRespCodes", declineRespCodeList);
			}

			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("getTransAcqT5Rjection db Query Fails", re);
			throw re;
		}
	}

	// R0011
	public int getTransAcqT5RjectionCount(List<String> acqs, List<String> txnsrcs, List<String> declineRespCodeList,
			String fromDate, String toDate, String fromDateFormate, String toDateFormate) {
		try {
			String queryString = "";
			queryString = SqlQueryProvider.getDBSqlQuery("TXNRJACQ_CNT");
			if (declineRespCodeList != null && declineRespCodeList.size() > 0) {
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and CAST(respcode as VARCHAR(10)) in (:declineRespCodes)  ");
			} else {
				queryString = queryString.replaceAll("FILTER_QUERY", " and respcode != 0 ");
			}
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);

			if (declineRespCodeList != null && declineRespCodeList.size() > 0) {
				queryObject.setParameter("declineRespCodes", declineRespCodeList);
			}

			return (int) queryObject.getSingleResult();

		} catch (RuntimeException re) {
			log.error("getTransAcqT5RjectionCount db Query Fails", re);
			throw re;
		}
	}

	public List getTransStatsbyProcCode(String screenType, String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, String procCode, int pageNum) {
		try {
			String queryString = "";

			queryString = SqlQueryProvider.getDBSqlQuery("TXNPROCCD");
			if (StringUtil.isNotEmpty(procCode)) {
				queryString = queryString.replaceAll("FILTER_QUERY", " and ProcessingCode LIKE  :pcode ");
			} else {
				queryString = queryString.replaceAll("FILTER_QUERY", " ");
			}
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString)
					.addScalar("ProcessingCode", StandardBasicTypes.STRING)
					.addScalar("NumTxnsPerPCode", StandardBasicTypes.STRING);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			if (StringUtil.isNotEmpty(procCode)) {
				queryObject.setParameter("pcode", procCode + "%");
			}

			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails - getTransStatsbyProcCode", re);
			throw re;
		}
	}

	public int getTransStatsbyProcCodeCount(String screenType, String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, String procCode) {
		try {

			String queryString = "";
			queryString = SqlQueryProvider.getDBSqlQuery("TXNPROCCD_CNT");
			if (StringUtil.isNotEmpty(procCode)) {
				queryString = queryString.replaceAll("FILTER_QUERY", " and ProcessingCode LIKE  :pcode ");
			} else {
				queryString = queryString.replaceAll("FILTER_QUERY", " ");
			}
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			if (StringUtil.isNotEmpty(procCode)) {
				queryObject.setParameter("pcode", procCode + "%");
			}
			return (int) queryObject.uniqueResult();
		} catch (RuntimeException re) {
			log.error("Query Fails - getTransStatsbyProcCodeCount", re);
			throw re;
		}
	}

	public Map<String, String> getProcessingCode(String product, String fieldName) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");
			String queryString = "";
			queryString = SqlQueryProvider.getDBSqlQuery("GBL_VAL_CTRL");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("pcode", StandardBasicTypes.STRING)
					.addScalar("pdesc", StandardBasicTypes.STRING);

			queryObject.setParameter(1, productId);
			queryObject.setParameter(2, fieldName);
			List list = queryObject.list();
			Map<String, String> map = new HashMap<>();

			for (Iterator iterator = list.iterator(); iterator.hasNext();) {
				Object[] object = (Object[]) iterator.next();
				map.put((String) object[0], (String) object[1]);
			}
			return map;

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// R0014 SQL#R0014a
	public List getATMTransStats(List<String> acqs, List<String> txnsrcs, String screenType, String fromDate,
			String toDate, String fromDateFormate, String toDateFormate, int pageNum) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNATMPOS");
			queryString = queryString.replaceAll("FILTER_QUERY", " and merchant_type = 6011 ");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chipindex", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING)
					.addScalar("istsysdate", StandardBasicTypes.TIMESTAMP)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.STRING)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);

			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// R0014 SQL#R0014a
	public int getATMTransStatsCount(List<String> acqs, List<String> txnsrcs, String screenType, String fromDate,
			String toDate, String fromDateFormate, String toDateFormate) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNATMPOS_CNT");
			queryString = queryString.replaceAll("FILTER_QUERY", " and merchant_type = 6011 ");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// R0014 SQL#R0014c
	public List getPOSTransStats(List<String> acqs, List<String> txnsrcs, String screenType, String fromDate,
			String toDate, String fromDateFormate, String toDateFormate, int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNATMPOS");
			queryString = queryString.replaceAll("FILTER_QUERY", " and merchant_type != 6011 ");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chipindex", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING)
					.addScalar("istsysdate", StandardBasicTypes.TIMESTAMP)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.STRING)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);

			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// R0014 SQL#R0014c
	public int getPOSTransStatsCount(List<String> acqs, List<String> txnsrcs, String screenType, String fromDate,
			String toDate, String fromDateFormate, String toDateFormate) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNATMPOS_CNT");
			queryString = queryString.replaceAll("FILTER_QUERY", " and merchant_type != 6011 ");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// R0015 SQL#R0015a
	public List getTransStatsOS(List<String> acqs, List<String> txnsrcs, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, int pageNum) {
		try {
			log.debug(String.format("Selecting Trans Statistics Overseas data From: %s To: %s", fromDate, toDate));
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSTSOS");

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chipindex", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("acq_currency_code", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING)
					.addScalar("istsysdate", StandardBasicTypes.TIMESTAMP).addScalar("pcode", StandardBasicTypes.STRING)
					.addScalar("txntype", StandardBasicTypes.STRING).addScalar("origmsg", StandardBasicTypes.STRING)
					.addScalar("origdate", StandardBasicTypes.STRING).addScalar("origtrace", StandardBasicTypes.STRING)
					.addScalar("origtime", StandardBasicTypes.STRING).addScalar("authnum", StandardBasicTypes.STRING)
					.addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails - getTransStatsOS", re);
			throw re;
		}
	}

	public int getTransStatsOSCount(List<String> acqs, List<String> txnsrcs, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate) {
		try {
			log.debug(
					String.format("Selecting Trans Statistics Overseas data count From: %s To: %s", fromDate, toDate));
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSTSOS_CNT");

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);

			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("Query Fails - getTransStatsOSCount", re);
			throw re;
		}
	}

	public List getTransStatsTerminal(List<String> acqs, List<String> txnsrcs, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, int pageNum) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTERC");
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("transactions", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails - getTransStatsTerminal", re);
			throw re;
		}
	}

	public int getTransStatsTerminalCount(List<String> acqs, List<String> txnsrcs, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTERC_CNT");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("Query Fails - getTransStatsTerminalCount", re);
			throw re;
		}
	}

	public List getTransStatsHighVol(String fromDate, String toDate, String fromDateFormate, String toDateFormate,
			int pageNum) {
		try {
			log.debug(String.format("Selecting High Volume Trans data From: %s To: %s", fromDate, toDate));
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNHVOL");

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("pan", StandardBasicTypes.STRING)
					.addScalar("TotalTransactions", StandardBasicTypes.STRING);

			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails - getTransStatsHighVol", re);
			throw re;
		}
	}

	public int getTransStatsHighVolCount(String fromDate, String toDate, String fromDateFormate, String toDateFormate) {
		try {
			log.debug(String.format("Selecting High Volume Trans data count From: %s To: %s", fromDate, toDate));
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNHVOL_CNT");

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("Query Fails - getTransStatsHighVolCount", re);
			throw re;
		}
	}

	// Top and Least Transacting 25 Terminals and Transaction Count For Acquiring
	// Transactions
	public List getTransactingTerminalsAcq(List<String> acqs, List<String> txnsrcs, String screenType) {
		try {

			String queryString = "";
			if (screenType.equalsIgnoreCase("TOP")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNSTP_REQ_TOP");
			} else if (screenType.equalsIgnoreCase("BOTTOM")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNSTP_REQ_BOTTOM");
			}

			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("TotalTransactions", StandardBasicTypes.STRING)
					.addScalar("TotalApprovalCnt", StandardBasicTypes.STRING)
					.addScalar("TotalDeclineCnt", StandardBasicTypes.STRING)
					.addScalar("TotalReversalCnt", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcs", txnsrcs);
			queryObject.setParameterList("acqs", acqs);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Transaction Statistics for Host Transactions
	public List getHostTransactionStats(List<String> iss, List<String> txnDest, String screenType) {

		log.debug("Selecting host transactions statistics data from db.");
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSHT_REQ");
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, screenType);
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("txndest", StandardBasicTypes.STRING)
					.addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("TotalApprovalCnt", StandardBasicTypes.STRING)
					.addScalar("TotalDeclineCnt", StandardBasicTypes.STRING)
					.addScalar("TotalReversalCnt", StandardBasicTypes.STRING)
					.addScalar("TotalCount", StandardBasicTypes.STRING)
					.addScalar("ApprovalPercentage", StandardBasicTypes.STRING)
					.addScalar("DeclinePercentage", StandardBasicTypes.STRING)
					.addScalar("ReversalPercentage", StandardBasicTypes.STRING);

			// FRS datas

			queryObject.setParameterList("txndest", txnDest);
			queryObject.setParameterList("iss", iss);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Transactions Per Second : Average TPS SQL#R0012a
	public List getAverageTPS(String screenType, int pageNum) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTPS_REQ");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString)
					.addScalar("TransactionMonth", StandardBasicTypes.STRING)
					.addScalar("TPS", StandardBasicTypes.STRING);

			setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public int getAverageTPSCount(String screenType, int pageNum) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTPS_REQ_CNT");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Transactions Per Second : Current TPS usage #R0012b
	public List getCurrentTPSUsage(String screenType, int pageNum) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTPS_REQ_CURR_TPS");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString)
					.addScalar("TPS", StandardBasicTypes.STRING);
			setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public int getCurrentTPSUsageCount(String screenType, int pageNum) {
		return 1;
	}

	// Transactions Per Second : Today average TPS usage #R0012b
	public List getTodayTPSUsage(int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTPS_REQ_TODAY_TPS");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString)
					.addScalar("TransactionDate", StandardBasicTypes.STRING)
					.addScalar("TPS", StandardBasicTypes.STRING);
			setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public int getTodayTPSUsageCount(String screenType, int pageNum) {
		return 1;
	}

	// Transactions Per Second : Average TPS - by Institution
	public List getInstAverageTPS(String screenType, int pageNum) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTPS_REQ_INST");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString)
					.addScalar("TransactionMonth", StandardBasicTypes.STRING)
					.addScalar("tps", StandardBasicTypes.STRING).addScalar("txndest", StandardBasicTypes.STRING);

			setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("InstAverageTPS Query Fails", re);
			throw re;
		}
	}

	public int getInstAverageTPSCount(String screenType, int pageNum) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTPS_REQ_INST");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString)
					.addScalar("TransactionMonth", StandardBasicTypes.STRING)
					.addScalar("tps", StandardBasicTypes.STRING).addScalar("txndest", StandardBasicTypes.STRING);
			return (int) queryObject.list().size();

		} catch (RuntimeException re) {
			log.error("InstAverageTPSCount Query Fails", re);
			throw re;
		}
	}

	// Transactions Per Second : Current TPS usage - by Institution
	public List getInstCurrentTPSUsage(String screenType, int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTPS_REQ_CURR_TPS_INST");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("sysdate", StandardBasicTypes.STRING)
					.addScalar("tps", StandardBasicTypes.STRING).addScalar("txndest", StandardBasicTypes.STRING);
			setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("InstCurrentTPSUsage Query Fails", re);
			throw re;
		}
	}

	public int getInstCurrentTPSUsageCount(String screenType, int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTPS_REQ_CURR_TPS_INST");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("sysdate", StandardBasicTypes.STRING)
					.addScalar("tps", StandardBasicTypes.STRING).addScalar("txndest", StandardBasicTypes.STRING);
			setPaging(queryObject, pageNum);
			return queryObject.list().size();

		} catch (RuntimeException re) {
			log.error("InstCurrentTPSUsageCount Query Fails", re);
			throw re;
		}
	}

	// Transactions Per Second : Today average TPS usage - by Institution
	public List getInstTodayTPSUsage(int pageNum) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTPS_REQ_TODAY_TPS_INST");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString)
					.addScalar("TransactionDate", StandardBasicTypes.STRING).addScalar("tps", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING);
			setPaging(queryObject, pageNum);
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("InstTodayTPSUsage Query Fails", re);
			throw re;
		}
	}


	public int getInstTodayTPSUsageCount(String screenType, int pageNum) {
		try {

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTPS_REQ_TODAY_TPS_INST");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString)
					.addScalar("TransactionDate", StandardBasicTypes.STRING).addScalar("tps", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING);
			setPaging(queryObject, pageNum);
			return queryObject.list().size();
		} catch (RuntimeException re) {
			log.error("InstTodayTPSUsageCount Query Fails", re);
			throw re;
		}
	}


	// Method for two lists txnSrc & tsnDest - To fetch Onus transactions count
	public List getRejectedTransactionsOnus(List<String> txnSrc, List<String> txnDest, String screenType,
			String fromDate, String toDate, String fromDateFormate, String toDateFormate, int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSSC_REQ");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("txndest", StandardBasicTypes.STRING)
					.addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("RejectedCount", StandardBasicTypes.STRING);

			queryObject.setParameterList("txndest", txnDest);
			queryObject.setParameterList("txnsrc", txnSrc);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// getRejectedTransactionsOnusCount() method for pagination.
	public int getRejectedTransactionsOnusCount(List<String> txnSrc, List<String> txnDest, String screenType,
			String fromDate, String toDate, String fromDateFormate, String toDateFormate) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSSC_REQ");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("txndest", StandardBasicTypes.STRING)
					.addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("RejectedCount", StandardBasicTypes.STRING);

			queryObject.setParameterList("txndest", txnDest);
			queryObject.setParameterList("txnsrc", txnSrc);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			return queryObject.list().size();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Method for single list: txnSrc or txnDest - To fetch the Acquiring
	// transactions or Issuing transactions count
	public List getRejectedTransactions(List<String> inputList, String screenType, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, int pageNum) {

		try {
			String queryString = "";
			if (screenType.equalsIgnoreCase("ACQUIRING")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNSSC_REQ_ACQ");

			} else if (screenType.equalsIgnoreCase("ISSUING")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNSSC_REQ_ISS");
			}

			Query queryObject = null;

			if (screenType.equalsIgnoreCase("ACQUIRING")) {
				queryObject = getSession().createSQLQuery(queryString).addScalar("txndest", StandardBasicTypes.STRING)
						.addScalar("issuer", StandardBasicTypes.STRING)
						.addScalar("RejectedCount", StandardBasicTypes.STRING);

				queryObject.setParameterList("txndest", inputList);
			} else {
				queryObject = getSession().createSQLQuery(queryString).addScalar("txnsrc", StandardBasicTypes.STRING)
						.addScalar("acquirer", StandardBasicTypes.STRING)
						.addScalar("txndest", StandardBasicTypes.STRING)
						.addScalar("RejectedCount", StandardBasicTypes.STRING);

				queryObject.setParameterList("txnsrc", inputList);
			}

			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// getRejectedTransactionsCount() method for pagination.
	public int getRejectedTransactionsCount(List<String> inputList, String screenType, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate) {

		try {
			String queryString = "";
			if (screenType.equalsIgnoreCase("ACQUIRING")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNSSC_REQ_ACQ");

			} else if (screenType.equalsIgnoreCase("ISSUING")) {
				queryString = SqlQueryProvider.getDBSqlQuery("TXNSSC_REQ_ISS");
			}
			Query queryObject = null;

			if (screenType.equalsIgnoreCase("ACQUIRING")) {
				queryObject = getSession().createSQLQuery(queryString).addScalar("txndest", StandardBasicTypes.STRING)
						.addScalar("issuer", StandardBasicTypes.STRING)
						.addScalar("RejectedCount", StandardBasicTypes.STRING);

				queryObject.setParameterList("txndest", inputList);
			} else {
				queryObject = getSession().createSQLQuery(queryString).addScalar("txnsrc", StandardBasicTypes.STRING)
						.addScalar("acquirer", StandardBasicTypes.STRING)
						.addScalar("txndest", StandardBasicTypes.STRING)
						.addScalar("RejectedCount", StandardBasicTypes.STRING);

				queryObject.setParameterList("txnsrc", inputList);
			}

			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			return queryObject.list().size();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Fetch the BD & TD from SQL#8 & SQL#9
	public List getTDBDRespCode(String fieldName) {
		log.debug("Selecting TD and BD response codes from db");
		try {
			String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");

			String queryString = SqlQueryProvider.getDBSqlQuery("GBL_VAL_CTRL_RSP_CD");
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString);
			queryObject.setParameter(1, productId);
			queryObject.setParameter(2, fieldName);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// Successful & Rejected Combined count for onus, acquiring and issuing transactions
	// Pass the businessDecline & technicalDeclineList here...
	// ResponseCodeList is added by Thiru on BancNet suggestions
	public List getCombinedTransactions(List<String> txnSrc, List<String> txnDest, List<String> businessDecline,
			List<String> technicalDecline, List responseCodeList, String screenType, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, int pageNum) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSSC_REQ_CMBND");

			if (responseCodeList != null && responseCodeList.size() > 0) {
				queryString = queryString.replaceAll("FILTER_QUERY",
						"FILTER_QUERY and  respcode in (:responseCodeList) ");
			}

			if (screenType.equalsIgnoreCase("TXNSSC_REQ"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc in (:txnsrc) and txndest in (:txndest) ");
			else if (screenType.equalsIgnoreCase("ACQUIRING"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc in (:txnsrc) and txndest not in (:txndest) ");
			else if (screenType.equalsIgnoreCase("ISSUING"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc not in (:txnsrc) and txndest in (:txndest)  ");
			else
				queryString = queryString.replaceAll("FILTER_QUERY", "  ");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("txndest", StandardBasicTypes.STRING)
					.addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("ApprovedCount", StandardBasicTypes.STRING)
					.addScalar("DeclineCount", StandardBasicTypes.STRING)
					.addScalar("BusinessDecline", StandardBasicTypes.STRING)
					.addScalar("TechnicalDecline", StandardBasicTypes.STRING);

			if (responseCodeList != null && responseCodeList.size() > 0) {
				queryObject.setParameterList("responseCodeList",
						MonitorConfigService.convertToIntList(responseCodeList));
			}

			if (screenType.equalsIgnoreCase("TXNSSC_REQ") || screenType.equalsIgnoreCase("ACQUIRING")
					|| screenType.equalsIgnoreCase("ISSUING")) {
				queryObject.setParameterList("txndest", txnDest);
				queryObject.setParameterList("txnsrc", txnSrc);
			}
			queryObject.setParameterList("businessDeclineList", MonitorConfigService.convertToIntList(businessDecline));
			queryObject.setParameterList("technicalDeclineList",
					MonitorConfigService.convertToIntList(technicalDecline));
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	// getCombinedTransactionsCount() for pagination : Successful & Rejected
	// Combined Count -
	// ResponseCodeList is added by Thiru on BancNet suggestions
	public int getCombinedTransactionsCount(List<String> txnSrc, List<String> txnDest, List<String> businessDecline,
			List<String> technicalDecline, List<String> responseCodeList, String screenType, String fromDate,
			String toDate, String fromDateFormate, String toDateFormate) {
		try {
			log.debug("Getting Successful And Rejected Trans Count from db");

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSSC_REQ_CMBND_CNT");

			if (responseCodeList != null && responseCodeList.size() > 0) {
				queryString = queryString.replaceAll("FILTER_QUERY",
						"FILTER_QUERY and  respcode in (:responseCodeList) ");
			}

			if (screenType.equalsIgnoreCase("TXNSSC_REQ"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc in (:txnsrc) and txndest in (:txndest) ");
			else if (screenType.equalsIgnoreCase("ACQUIRING"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc in (:txnsrc) and txndest not in (:txndest) ");
			else if (screenType.equalsIgnoreCase("ISSUING"))
				queryString = queryString.replaceAll("FILTER_QUERY",
						" and txnsrc not in (:txnsrc) and txndest in (:txndest)  ");
			else
				queryString = queryString.replaceAll("FILTER_QUERY", "  ");

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			if (screenType.equalsIgnoreCase("TXNSSC_REQ") || screenType.equalsIgnoreCase("ACQUIRING")
					|| screenType.equalsIgnoreCase("ISSUING")) {
				queryObject.setParameterList("txndest", txnDest);
				queryObject.setParameterList("txnsrc", txnSrc);
			}

			if (responseCodeList != null && responseCodeList.size() > 0) {
				queryObject.setParameterList("responseCodeList",
						MonitorConfigService.convertToIntList(responseCodeList));
			}
			queryObject.setParameterList("txndest", txnDest);
			queryObject.setParameterList("txnsrc", txnSrc);
			queryObject.setParameterList("businessDeclineList", MonitorConfigService.convertToIntList(businessDecline));
			queryObject.setParameterList("technicalDeclineList",
					MonitorConfigService.convertToIntList(technicalDecline));
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);
			return (int) queryObject.uniqueResult();

		} catch (RuntimeException re) {
			log.error("Query Fails - getCombinedTransactionsCount", re);
			throw re;
		}
	}

	public List getFallbackTransactions(List<String> txnsrcList, List<String> acqsList, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, Integer pageNum, boolean setPaging) {

		try {
			log.debug("Getting Fallback Transactions from db");

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNFBC_REQ");
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("txnsrc", StandardBasicTypes.STRING)
					.addScalar("acquirer", StandardBasicTypes.STRING).addScalar("termId", StandardBasicTypes.STRING)
					.addScalar("fallbackCount", StandardBasicTypes.STRING);

			queryObject.setParameterList("txnsrcList", txnsrcList);
			queryObject.setParameterList("acqsList", acqsList);
			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("fromDateFormate", fromDateFormate);
			queryObject.setParameter("toDateFormate", toDateFormate);

			if (setPaging) {
				setPaging(queryObject, pageNum);
			}

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails - getFallbackTransactions", re);
			throw re;
		}
	}

	public int getFallbackTransactionsCount(List<String> txnsrcList, List<String> acqsList, String fromDate,
			String toDate, String fromDateFormate, String toDateFormate) {
		List recordList = this.getFallbackTransactions(txnsrcList, acqsList, fromDate, toDate, fromDateFormate,
				toDateFormate, null, false);
		return recordList.size();
	}

	// Transaction Statistics Logs
	public List getTransStatsLogs(String screenType, String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, String searchByFlag, String institution, String terminalId, int pageNum) {
		try {
			terminalId = convertWildSearchString(terminalId);
			institution = convertWildSearchString(institution);

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSTSLOG");
			queryString = setTransStatsLogsQueryFilter(queryString, searchByFlag, institution, terminalId);

			Query queryObject = getSession().createSQLQuery(queryString).addScalar("msgtype", StandardBasicTypes.STRING)
					.addScalar("txnsrc", StandardBasicTypes.STRING).addScalar("acquirer", StandardBasicTypes.STRING)
					.addScalar("pcode", StandardBasicTypes.STRING).addScalar("txntype", StandardBasicTypes.STRING)
					.addScalar("txndest", StandardBasicTypes.STRING).addScalar("issuer", StandardBasicTypes.STRING)
					.addScalar("chipindex", StandardBasicTypes.STRING).addScalar("trace", StandardBasicTypes.STRING)
					.addScalar("refnum", StandardBasicTypes.STRING).addScalar("amount", StandardBasicTypes.STRING)
					.addScalar("local_date", StandardBasicTypes.DATE).addScalar("local_time", StandardBasicTypes.STRING)
					.addScalar("trandate", StandardBasicTypes.DATE).addScalar("trantime", StandardBasicTypes.STRING)
					.addScalar("respcode", StandardBasicTypes.STRING)
					.addScalar("istsysdate", StandardBasicTypes.TIMESTAMP)
					.addScalar("origmsg", StandardBasicTypes.STRING).addScalar("origdate", StandardBasicTypes.DATE)
					.addScalar("origtrace", StandardBasicTypes.STRING).addScalar("origtime", StandardBasicTypes.STRING)
					.addScalar("authnum", StandardBasicTypes.STRING).addScalar("terminalId", StandardBasicTypes.STRING)
					.addScalar("alpharesponsecode", StandardBasicTypes.STRING);

			setTransStatsLogsQueryParams(queryObject, fromDate, toDate, fromDateFormate, toDateFormate, institution,
					terminalId);
			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("getTransStatsLogs Query Fails", re);
			throw re;
		}
	}

	public List getResponseCodesAndDesc() {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			String productId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id");

			String queryString = SqlQueryProvider.getDBSqlQuery("RESPCODE_LIST");
			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("respCode", StandardBasicTypes.STRING)
					.addScalar("respCodeDesc", StandardBasicTypes.STRING);

			queryObject.setParameter(1, productId);

			Stream stream = queryObject.setHint(QueryHints.HINT_FETCH_SIZE, 100).getResultStream();

			List recordList = new ArrayList<>();
			stream.forEach(x -> {
				recordList.add(x);
			});

			return recordList;

		} catch (RuntimeException re) {
			log.error("getResponseCodesAndDesc Query Fails", re);
			throw re;
		}
	}

	// Transaction Statistics Logs Count
	public int getTransStatsLogsCount(String screenType, String fromDate, String toDate, String fromDateFormate,
			String toDateFormate, String searchByFlag, String institution, String terminalId) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			terminalId = convertWildSearchString(terminalId);
			institution = convertWildSearchString(institution);

			String queryString = SqlQueryProvider.getDBSqlQuery("TXNSTSLOG_CNT");
			queryString = setTransStatsLogsQueryFilter(queryString, searchByFlag, institution, terminalId);
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
			setTransStatsLogsQueryParams(queryObject, fromDate, toDate, fromDateFormate, toDateFormate, institution,
					terminalId);

			return (int) queryObject.uniqueResult();
		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public List getTransStatsbyTxnCode(String type) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXNTYPEREQ");
			queryString = SqlQueryProvider.appendCriteiaTrans(queryString, type);
			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("ProcessingCode", StandardBasicTypes.STRING)
					.addScalar("NumTxnsPerPCode", StandardBasicTypes.STRING)
					.addScalar("TotalApprovalCnt", StandardBasicTypes.STRING)
					.addScalar("TotalDeclineCnt", StandardBasicTypes.STRING)
					.addScalar("TotalReversalCnt", StandardBasicTypes.STRING);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("getTransStatsbyTxnCode - Query Fails", re);
			throw re;
		}
	}

	public List<Pair<String, Integer>> getMerchantCountGroupedByInstitution() {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("MERCH_CNT_BY_INST");
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("key", StandardBasicTypes.STRING)
					.addScalar("value", StandardBasicTypes.INTEGER);

			return (List<Pair<String, Integer>>) queryObject.setResultTransformer(Transformers.aliasToBean(Pair.class))
					.list();

		} catch (RuntimeException re) {
			log.error("getMerchantCountGroupedByInstitution - Query Fails", re);
			throw re;
		}
	}

	private List<String> getAllNodes(String nodes) {
		List<String> allNodeIds = new ArrayList<>();

		Pattern pattern = Pattern.compile("\\((.*?)\\)");
		Matcher matcher = pattern.matcher(nodes);

		try {
			if (matcher.find()) {
				nodes = matcher.group(1);
				String[] values = nodes.split(",\\s*");
				for (String value : values) {
					allNodeIds.add(value.trim());
				}
			}
			return allNodeIds;
		} catch (RuntimeException re) {
			log.error("getAllNodes failed", re);
			throw re;
		}
	}

	public List<Pair<String, Integer>> getConnectionCountGroupByServiceMail(Map<String, String> params) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			queryBuffer.append(SqlQueryProvider.getDBSqlQuery("CON_CNT_BY_SERVICE_MAIL"));
			if(StringUtil.isNotEmpty(params.get("product"))) {

				queryBuffer.append(" and product = :product ");
			}
			if (StringUtil.isNotEmpty(params.get("nodeId"))) {
				queryBuffer.append(" and nodeId in (:nodeId) ");
			}

			queryBuffer.append(" GROUP BY field4");

			Query queryObject = getSession().createSQLQuery(queryBuffer.toString())
					.addScalar("key", StandardBasicTypes.STRING).addScalar("value", StandardBasicTypes.INTEGER);

			if (StringUtil.isNotEmpty(params.get("product"))) {
				queryObject.setParameter("product", params.get("product"));
			}

			if (StringUtil.isNotEmpty(params.get("nodeId")) && params.get("nodeId").startsWith("All")) {
				queryObject.setParameterList("nodeId", getAllNodes(params.get("nodeId")));
			} else if (StringUtil.isNotEmpty(params.get("nodeId"))) {
				String nodeId = params.get("nodeId");
				nodeId = nodeId.trim();
				nodeId = nodeId.contains(", ") ? nodeId.replace(", ", ",") : nodeId;
				queryObject.setParameterList("nodeId",
						Arrays.asList(nodeId.contains(",") ? nodeId.split(",") : new String[] { nodeId }));
			}

			return (List<Pair<String, Integer>>) queryObject.setResultTransformer(Transformers.aliasToBean(Pair.class))
					.list();

		} catch (RuntimeException re) {
			log.error("getMerchantCountGroupedByInstitution - Query Fails", re);
			throw re;
		}
	}

	private static String setTransStatsLogsQueryFilter(String sqlQuery, String searchByFlag, String institution,
			String terminalId) {
		if (!isEmpty(institution)) {
			if ("S".equalsIgnoreCase(searchByFlag)) {
				sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " txnsrc = :institution  ");
			} else if ("D".equalsIgnoreCase(searchByFlag)) {
				sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " txndest = :institution  ");
			} else if ("B".equalsIgnoreCase(searchByFlag)) {
				sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " (txnsrc = :institution OR txndest = :institution)   ");
			} else {
				sqlQuery = sqlQuery.replaceAll("FILTER_QUERY", " ");
			}
		} else if (isEmpty(institution)) {
			sqlQuery = sqlQuery.replaceAll("FILTER_QUERY",
					" txnsrc in (select distinct txnsrc from cs_monshclog_ext)  ");
		}

		if (!isEmpty(terminalId)) {
			sqlQuery = sqlQuery.replaceAll("TERM_ID_FILTER", " and termid like :termId  ");
		} else {
			sqlQuery = sqlQuery.replaceAll("TERM_ID_FILTER", " ");
		}

		if ("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
			sqlQuery = sqlQuery.replaceAll("DATE_FILTER",
					" and to_char(istsysdate,:fromDateFormate) between to_date(:fromDate, :fromDateFormate) and to_date(:toDate, :toDateFormate) ");
		} else if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
			sqlQuery = sqlQuery.replaceAll("DATE_FILTER",
					" and to_timestamp(to_char(istsysdate,:fromDateFormate),:fromDateFormate) between to_timestamp(:fromDate, :fromDateFormate) and to_timestamp(:toDate, :toDateFormate) ");
		}
		return sqlQuery;
	}

	private static void setTransStatsLogsQueryParams(Query queryObject, String fromDate, String toDate,
			String fromDateFormate, String toDateFormate, String institution, String terminalId) {
		queryObject.setParameter("fromDate", fromDate);
		queryObject.setParameter("toDate", toDate);
		queryObject.setParameter("fromDateFormate", fromDateFormate);
		queryObject.setParameter("toDateFormate", toDateFormate);

		if (!isEmpty(institution)) {
			queryObject.setParameter("institution", institution);
		}

		if (!isEmpty(terminalId)) {
			queryObject.setParameter("termId", terminalId);
		}
	}

	public List getTransTrendData(String screenType, String fromDate, String toDate, String DateFormat,
			String institution, String termid, int pageNum) {
		try {
			String[] dateParts = null;
			String month = "";
			String year = "";
			String queryString = "";

			termid = convertWildSearchString(termid);
			institution = convertWildSearchString(institution);

			queryString = SqlQueryProvider.getDBSqlQuery("TXNTREND");

			if (screenType.equalsIgnoreCase("Month") && !isEmpty(fromDate)) {
				dateParts = fromDate.split("/");
				month = dateParts[0];
				year = dateParts[2];
				queryString = queryString.replaceAll("DATE_FILTER",
						" extract(MONTH from istsysdate) = :MONTH and extract(YEAR from istsysdate) = :YEAR ");
			} else if (screenType.equalsIgnoreCase("Year") && !isEmpty(fromDate)) {
				year = fromDate;
				queryString = queryString.replaceAll("DATE_FILTER", " extract(YEAR from istsysdate) = :YEAR ");
			} else {
				queryString = queryString.replaceAll("DATE_FILTER",
						" istsysdate between to_date(:fromDate, :DateFormat) and to_date(:toDate, :DateFormat) ");
			}

			// INST_ID_FILETR
			queryString = !isEmpty(institution) ? queryString.replaceAll("INST_ID_FILETR", " txnsrc= :institution ")
					: queryString.replaceAll("INST_ID_FILETR",
							" txnsrc in (select distinct txnsrc from cs_monshclog_ext) ");

			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("txnsrc", StandardBasicTypes.STRING)
					.addScalar("termid", StandardBasicTypes.STRING)
					.addScalar("TotalApprovalCnt", StandardBasicTypes.STRING)
					.addScalar("TotalDeclineCnt", StandardBasicTypes.STRING)
					.addScalar("TotalReversalCnt", StandardBasicTypes.STRING)
					.addScalar("TotalCount", StandardBasicTypes.STRING)
					.addScalar("ApprovalPercentage", StandardBasicTypes.STRING)
					.addScalar("DeclinePercentage", StandardBasicTypes.STRING)
					.addScalar("ReversalPercentage", StandardBasicTypes.STRING)
					.addScalar("ApprovedCashWdCnt", StandardBasicTypes.STRING)
					.addScalar("ApprovedBalInqCnt", StandardBasicTypes.STRING)
					.addScalar("ApprovedPurchaseCnt", StandardBasicTypes.STRING)
					.addScalar("ApprovedDepositCnt", StandardBasicTypes.STRING)
					.addScalar("ApprovedTransferCnt", StandardBasicTypes.STRING)
					.addScalar("ApprovedOthersCnt", StandardBasicTypes.STRING)
					.addScalar("DeclinedCashWdCnt", StandardBasicTypes.STRING)
					.addScalar("DeclinedBalInqCnt", StandardBasicTypes.STRING)
					.addScalar("DeclinedPurchaseCnt", StandardBasicTypes.STRING)
					.addScalar("DeclinedDepositCnt", StandardBasicTypes.STRING)
					.addScalar("DeclinedTransferCnt", StandardBasicTypes.STRING)
					.addScalar("DeclinedOthersCnt", StandardBasicTypes.STRING);

			if (screenType.equalsIgnoreCase("Month")) {
				queryObject.setInteger("MONTH", Integer.parseInt(month));
				queryObject.setInteger("YEAR", Integer.parseInt(year));
			} else if (screenType.equalsIgnoreCase("Year")) {
				queryObject.setInteger("YEAR", Integer.parseInt(year));
			} else {
				queryObject.setParameter("fromDate", fromDate);
				queryObject.setParameter("toDate", toDate);
				queryObject.setParameter("DateFormat", DateFormat);
				queryObject.setParameter("DateFormat", DateFormat);
			}

			if (!isEmpty(institution))
				queryObject.setParameter("institution", institution);
			queryObject.setParameter("termid", termid);

			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public int getTransTrendDataCount(String screenType, String fromDate, String toDate, String DateFormat,
			String institution, String termid) {
		try {
			String[] dateParts = null;
			String month = "";
			String year = "";
			String queryString = "";
			queryString = SqlQueryProvider.getDBSqlQuery("TXNTREND_CNT");

			termid = convertWildSearchString(termid);
			institution = convertWildSearchString(institution);

			if (screenType.equalsIgnoreCase("Month") && !isEmpty(fromDate)) {
				dateParts = fromDate.split("/");
				month = dateParts[0];
				year = dateParts[2];
				queryString = queryString.replaceAll("DATE_FILTER",
						" extract(MONTH from istsysdate) = :MONTH and extract(YEAR from istsysdate) = :YEAR ");
			} else if (screenType.equalsIgnoreCase("Year") && !isEmpty(fromDate)) {
				year = fromDate;
				queryString = queryString.replaceAll("DATE_FILTER", " extract(YEAR from istsysdate) = :YEAR ");
			} else {
				queryString = queryString.replaceAll("DATE_FILTER",
						" istsysdate between to_date(:fromDate, :DateFormat) and to_date(:toDate, :DateFormat) ");
			}

			// INST_ID_FILETR
			queryString = !isEmpty(institution) ? queryString.replaceAll("INST_ID_FILETR", " txnsrc= :institution ")
					: queryString.replaceAll("INST_ID_FILETR",
							" txnsrc in (select distinct txnsrc from cs_monshclog_ext) ");

			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);

			if (screenType.equalsIgnoreCase("Month")) {
				queryObject.setInteger("MONTH", Integer.parseInt(month));
				queryObject.setInteger("YEAR", Integer.parseInt(year));
			} else if (screenType.equalsIgnoreCase("Year")) {
				queryObject.setInteger("YEAR", Integer.parseInt(year));
			} else {
				queryObject.setParameter("fromDate", fromDate);
				queryObject.setParameter("toDate", toDate);
				queryObject.setParameter("DateFormat", DateFormat);
				queryObject.setParameter("DateFormat", DateFormat);
			}
			if (!isEmpty(institution))
				queryObject.setParameter("institution", institution);
			queryObject.setParameter("termid", termid);

			return (int) queryObject.uniqueResult();
		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	private static String convertWildSearchString(String value) {
		if (isEmpty(value))
			return value;

		if (hasOnlyAsterisks(value)) {
			return "";
		}
		return value.replace("*", "%");
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}

	private static boolean hasOnlyAsterisks(String input) {
		for (int i = 0; i < input.length(); i++) {
			if (input.charAt(i) != '*') {
				return false;
			}
		}
		return true;
	}

	public List<TxnAuthDenialDto> getAuthDenialList(String currentDate) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXN_AUTH_DENIAL_CNT");
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("tranDate", StandardBasicTypes.DATE)
					.addScalar("denialCount", StandardBasicTypes.INTEGER);

			queryObject.setParameter("currentDate", currentDate);

			log.debug("Query[" + queryString + "]");

			return (List<TxnAuthDenialDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(TxnAuthDenialDto.class)).list();

		} catch (RuntimeException re) {
			log.error("getAuthDenialList - Query Fails", re);
			throw re;
		}
	}

	public List<TxnPeakVolumesDto> getPeakVolumesList(String currentDate) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXN_PEAK_VOLUMES_CNT");
			Query queryObject = getSession().createSQLQuery(queryString).addScalar("hours", StandardBasicTypes.STRING)
					.addScalar("tranCount", StandardBasicTypes.INTEGER);

			queryObject.setParameter("currentDate", currentDate);

			log.debug("Query[" + queryString + "]");

			return (List<TxnPeakVolumesDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(TxnPeakVolumesDto.class)).list();

		} catch (RuntimeException re) {
			log.error("getPeakVolumesList - Query Fails", re);
			throw re;
		}
	}

	public List<TxnCompletionTimeDto> getTxnCompletionTimeList(String currentDate) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXN_COMPTIME_CNT");
			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("secCount", StandardBasicTypes.INTEGER)
					.addScalar("min1Count", StandardBasicTypes.INTEGER)
					.addScalar("min2Count", StandardBasicTypes.INTEGER)
					.addScalar("min3Count", StandardBasicTypes.INTEGER)
					.addScalar("min4Count", StandardBasicTypes.INTEGER)
					.addScalar("min5Count", StandardBasicTypes.INTEGER);

			queryObject.setParameter("currentDate", currentDate);

			log.debug("Query[" + queryString + "]");

			return (List<TxnCompletionTimeDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(TxnCompletionTimeDto.class)).list();

		} catch (RuntimeException re) {
			log.error("getTxnCompletionTimeList - Query Fails", re);
			throw re;
		}
	}

	public List<TxnFailuresDto> getTxnFailuresList(String currentDate) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("TXN_FAILURES_CNT");
			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("failureCount", StandardBasicTypes.INTEGER)
					.addScalar("successCount", StandardBasicTypes.INTEGER);

			queryObject.setParameter("currentDate", currentDate);

			log.debug("Query[" + queryString + "]");

			return (List<TxnFailuresDto>) queryObject
					.setResultTransformer(Transformers.aliasToBean(TxnFailuresDto.class)).list();

		} catch (RuntimeException re) {
			log.error("getTxnFailuresList - Query Fails", re);
			throw re;
		}
	}
}