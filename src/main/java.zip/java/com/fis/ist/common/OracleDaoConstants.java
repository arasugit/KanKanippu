package com.fis.ist.common;


public class OracleDaoConstants {
	public static final String EMPTY ="empty";	
	public static final String COUNT ="count";	
	public static final String CRITERIA_INSTITUTION=" and institutionid=?";
	public static final String CRITERIA_GROUP_NAME=" and UPPER(group_name)=UPPER(?)";
	public static final String CRITERIA_UNIT=" and unit=?";
	public static final String CRITERIA_ATM_INSTITUTION=" and atm.institutionid=?";
	public static final String CRITERIA_ATM_GROUP_NAME=" and UPPER(atm.group_name)=UPPER(?)";
	public static final String CRITERIA_ATM_UNIT=" and atm.unit=?";
	public static final String RAWTYPES ="rawtypes";
	public static final String UNCHECKED ="unchecked";
	public static final String DEPRECATION ="deprecation";
	public static final String INSTITUTION_ID ="institutionId";
	public static final String GROUP_NAME ="groupName";
	public static final String UNIT ="unit";
	public static final String NETWORK_NAME ="netname";
	public static final String SEVERITY ="severity";
	public static final String FAULT ="fault";
	public static final String STATUS_DESCRIPTION_LIST ="statusDescList";
	public static final String TERMINAL_COMP ="terminalComp";
	public static final String TERMINAL ="terminal";
	public static final String LOCATION ="location";
	public static final String MAKE ="make";
	public static final String ACCEPTOR_NAME ="acceptorname";
	public static final String SITE_ID ="siteId";	
	public static final String TYPE ="type";
	public static final String CURRENCY ="currency";
	public static final String AMOUNT ="amount";
	public static final String RESET_TIME ="resetTime";
	public static final String PREVIOUS_COUNT ="prevCount";
	public static final String PREVIOUS_AMOUNT ="prevAmount";
	public static final String PAGINATION_HEADER_QRY="SELECT * from (SELECT targetQuery.*,rownum as rnum from (";
	public static final String PAGINATION_TAIL_QRY=" )targetQuery where rownum <=?) where rnum>=? ";
	public static final String CASSETTE_NBR="cassetteNbr";
	public static final String ITEMS_REJECTED="itemsRejected";
	public static final String CASH_INCREMENT="cashIncrement";
	public static final String CASH_DECREMENT="cashDecrement";
	public static final String CASH_OUT="cashOut";
	public static final String CURRENT_CASH_BALANCE="currentCashBalance";
	public static final String START_CASH_BALANCE="startCashBalance";
	public static final String PREVIOUS_CASH_BALANCE="previousCashBalance";
	public static final String RECYCLE_COUNT="recycleCount";
	public static final String PREVIOUS_RECYCLE_COUNT="previousRecycleCount";
	public static final String CORTEX_COMMAND_CAPCP="ca pcp";
	
}
