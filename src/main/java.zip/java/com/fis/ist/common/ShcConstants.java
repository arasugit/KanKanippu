package com.fis.ist.common;

public class ShcConstants extends CommonConstants{

	public static final String ACTION_INSERT = "insert";
	public static final String ACTION_UPDATE = "update";
	public static final String ACTION_QUERY = "query";
	public static final String ACTION_DELETE = "delete";
	public static final String ACTION_QUERY_DETAIL = "detail";  
	public static final String ACTION_SINGLE_BATCH_SAVE = "save";
	public static final String ACTION_EMV_DELETE = "emvdelete";

	public static final String SINGLEPAGE_ADD = "I";
	public static final String SINGLEPAGE_UPDATE = "U";
	public static final String SINGLEPAGE_ADD_DELETE = "ID";
	public static final String SINGLEPAGE_DELETE = "D";	
	public static final String ACTION_SEARCHLIST = "searchlist";

	public static final String CARDPRODUCT_LIST_REQ = "CARDPRDQRY";
	public static final String CARDPRODUCT_LIST_TAB = "CARDPRDQRYTAB";
	public static final String CARDPRODUCT_LIST_COL = "CARDPRDLISTCOL";
	public static final String CARDPRODUCT_LIST_SEC = "CARDPRDQRYSEC";
	

	//----------BIN Range Routing (SHCEXTBINDB)FORM--------------------
	public static final String SHCEXBNLST = "SHCEXBNLST";
	public static final String SHCEXBNLSTTAB = "SHCEXBNLSTTAB";
	public static final String SHCEXBNLSTCOL = "SHCEXBNLSTCOL";
	public static final String SHCEXBNDTL = "SHCEXBNDTL";
	public static final String SHCEXBNDTLTAB = "SHCEXBNDTLTAB";

	//-------BLOCK-BY-BRAND-----------------
	public static final String BLOCKBYBRAND_REQ = "BLCBYBRQRY";
	public static final String BLOCKBYBRAND_TAB = "BLCBYBRQRYTAB";
	public static final String BLOCKBYBRAND_LIST = "BLCBYBRANDLISTCOL";
	public static final String BLOCKBYBRAND_DETAIL_REQ = "BLCBYBRDET";
	public static final String BLOCKBYBRAND_DETAIL_TAB = "BLCBYBRDETAILTAB";

	public static final String SHCEXTBINDB_LIST_REQ = "SHCEXBNQRY";
	public static final String SHCEXTBINDB_LIST_TAB = "SHCEXBNQRYTAB";
	public static final String SHCEXTBINDB_LIST_COL = "SHCDESTLISTCOL";

	//-----HOT CARDS-RANGES ----------------------------------------
	public static final String HOTCARDSRANGE_LIST_REQ = "HTCDRANQRY";	
	public static final String HOTCARDSRANGE_LIST_TAB = "HTCDRANQRYTAB";
	public static final String HOTCARDSRANGE_LIST_COL = "HOTCARDRANGELISTCOL";	
	public static final String HOTCARDSRANGE_LIST_SEC = "HTCDRANQRYSEC";	
	
	//-----ISSUER PROFILE ----------------------------------------
	public static final String ISSPROF_LIST_REQ = "ISSPROFQRY";	
	public static final String ISSPROF_LIST_TAB = "ISSPROFQRYTAB";
	public static final String ISSPROF_LIST_COL = "ISSPROFLISTCOL";	
	public static final String ISSPROF_DETAIL_REQ = "ISSPROFDET";	
	public static final String ISSPROF_DETAIL_TAB = "ISSPROFDETTAB";
	public static final String ISSPROF_DETAIL_SEC = "ISSPROFDETAILSEC";

	//----------SHC600 LOG LIST-----------------
	public static final String SHC600LOGL   = "SHC600LOGL";
	public static final String SHC600LOGLTAB = "SHC600LOGLTAB";
	public static final String SHC600LOGLCOL = "SHC600LOGLCOL";

	//-----SHC600 LOG DETAIL ----------------------------------------
	public static final String SHC600LOGD = "SHC600LOGD";	
	public static final String SHC600LOGDTAB = "SHC600LOGDTAB";

	//-----HOT -CARDS ----------------------------------------
	public static final String HOTCARDS_LIST_REQ = "HOTCARDQRY";	
	public static final String HOTCARDS_LIST_TAB = "HOTCARDQRYTAB";
	public static final String HOTCARDS_LIST_COL = "HOTCARDLISTCOL";	
	public static final String HOTCARDS_DETAIL_REQ = "HOTCARDDET";	
	public static final String HOTCARDS_DETAIL_TAB = "HOTCARDDETTAB";

	//----------TRANSACTION LOGS-----------------
	public static final String TRANLOGQR   = "TRANLOGQR";
	public static final String TRANSLOGTAB = "TRANSLOGTAB";
	public static final String TRANSLOGCOL = "TRANSLOGCOL";

	//-----TRANSACTION  LOGS DETAIL ----------------------------------------
	public static final String TRANLOGDET = "TRANLOGDET";	
	public static final String TRANSLOGDETTAB = "TRANSLOGDETTAB";

	public static final String ACQPROFQRY="ACQPROFQRY";
	public static final String ACQPROFQRYTAB="ACQPROFQRYTAB";
	public static final String ACQPROFDETTAB="ACQPROFDETTAB";

	//----------PINVERPARM FORM--------------------
	public static final String PINVPLIST = "PINVPLIST";
	public static final String PINVPLISTTAB = "PINVPLISTTAB";
	public static final String PINVPLISTCOL = "PINVPLISTCOL";
	public static final String PINVPDTL = "PINVPDTL";
	public static final String PINVPDTLTAB = "PINVPDTLTAB";
	public static final String PINVPDTLCOL = "PINVPDTLCOL";

	//-----------BIN Setup Query-----------------
	public static final String BINSTUPQRY_REQ = "BINSTUPQRY";
	public static final String BINSTUPQRYLISTTAB = "BINSTUPQRYTAB";
	public static final String BINSTUPQRYLISTCOL = "BINSTUPQRYCOL";

	//-----------BIN Setup Detail-----------------
	public static final String BINSTUPDET_REQ = "BINSTUPDET";
	public static final String BINSTUPDETTAB = "BINSTUPDETTAB";

	public static final String BINSTUPDETSEC = "BINSTUPDETSEC";
	public static final String BINSTUPDETCOL = "BINSTUPDETCOL";
	public static final String PIN_VER_PARAM_POPUP = "PIN_VER_PARAM_POPUP";

	public static final String MERCHCOL = "MERCHCOL";
	public static final String MERCHTYPE_LIST_REQ = "MRCHTYPQRY";	
	public static final String MERCHTYPE_LIST_TAB = "MERCHTYPEQRYTAB";
	public static final String MERCHTYPE_LIST_COL = "MERCHTYPELISTCOL";
	public static final String INST_DETAIL_TAB = "INSTDETAILTAB";

	//-----------BIN ROUTE-----------------
	public static final String BINROUTQRY = "BINROUTQRY";
	public static final String BINTROUTAB = "BINTROUTAB";
	public static final String BINTROCOL = "BINTROCOL";
	public static final String BIN_ROUTE_GROUP_POPUP = "BIN_ROUTE_GROUP_POPUP";

	//-----------BIN ROUTE DETAIL-----------------
	public static final String BINROUTDET = "BINROUTDET";
	public static final String BINTABDET = "BINTABDET";

	/*PinVerParm Popup Form*/
	public static final String PINVPMLIST = "PINVPMLIST";
	public static final String PINVPMLISTTAB = "PINVPMLISTTAB";
	public static final String PINVPMLISTCOL = "PINVPMLISTCOL";

	//-----------EMV Keys Query-----------------
	public static final String EMVKEYLIST_REQ = "EMVKEYLIST";
	public static final String EMVKEYLISTTAB = "EMVKEYLISTTAB";
	public static final String EMVKEYLISTCOL = "EMVKEYLISTCOL";

	//-----------EMV Keys Detail-----------------
	public static final String EMVKEYSDET_REQ = "EMVKEYSDET";
	public static final String EMVKEYSDETTAB = "EMVKEYSDETTAB";

	public static final String EMVKEYSDETSEC = "EMVKEYSDETSEC";
	public static final String EMVKEYSDETCOL = "EMVKEYSDETCOL";

	//----------INST PROFILE ID POPUP-----------------
	public static final String INSTPROPOP    = "INSTPROPOP";
	public static final String INSTPROPOPTAB = "INSTPROPOPTAB";
	public static final String INSTPROPOPCOL = "INSTPROPOPCOL";

	//----------NETWORK SEC KEYS POPUP-----------------
	public static final String NETKEYRPOP    = "NETKEYRPOP";
	public static final String NETKEYPOPTAB = "NETKEYPOPTAB";
	public static final String NETKEYPOPCOL = "NETKEYPOPCOL";

	//-----INSTUSERBIN PROFILE ----------------------------------------
	public static final String INSTPROQRY = "INSTPROQRY";	
	public static final String INSTPROAB = "INSTPROAB";
	public static final String INSTPROCOL = "INSTPROCOL";	

	//-----INSTUSERBIN DETAIL ----------------------------------------
	public static final String INSTPRODET = "INSTPRODET";	
	public static final String INSTDETTAB = "INSTDETTAB";

	//----------INSTUSERBIN POPUP-----------------
	public static final String INSTBINPOP = "INSTBINPOP";
	public static final String INSTBINTAB = "INSTBINTAB";
	public static final String INSTBINCOL = "INSTBINCOL";

	public static final String VISAACQBIN_SHC300 = "VISAACQBIN_SHC300";
	public static final String VISAACQBIN_COMBO = "VISAACQBIN";
	public static final String VISAISSBIN_COMBO = "VISAISSBIN";
	public static final String CARD_PRO_LIST="CARD_PRO_LIST";
	public static final String CARD_PRO_NAME_LIST="CARD_PRO_NAME_LIST";
	public static final String INST_PROF_KEYPARAM_LIST="INST_PROF_KEYPARAM_LIST";

	//IST Advice Notification Query
	public static final String ISTADVLST = "ISTADVLST";
	public static final String ISTADVLSTTAB = "ISTADVLSTTAB";
	public static final String ISTADVLSTSEC = "ISTADVLSTSEC";
	public static final String ISTADVLSTCOL = "ISTADVLSTCOL";

	//IST Advice Notification Detail
	public static final String ISTADVDTL = "ISTADVDTL";
	public static final String ISTADVDTLTAB = "ISTADVDTLTAB";
	public static final String ISTADVDTLSEC = "ISTADVDTLSEC";	

	//AKB KEYS
	public static final String AKBKEYSLST = "AKBKEYSLST";
	public static final String AKBKEYSLSTTAB = "AKBKEYSLSTTAB";
	public static final String AKBKEYSLSTSEC = "AKBKEYSLSTSEC";
	public static final String AKBKEYSLSTCOL = "AKBKEYSLSTCOL";

	//Rejected Log Query
	public static final String REJECTLOGL = "REJECTLOGL";
	public static final String REJECTLOGLTAB = "REJECTLOGLTAB";
	public static final String REJECTLOGLSEC = "REJECTLOGLSEC";
	public static final String REJECTLOGLCOL = "REJECTLOGLCOL";

	//Rev Log List
	public static final String REVLOGL= "REVLOGL";
	public static final String REVLOGLSEC= "REVLOGLSEC";
	public static final String REVLOGLCOL= "REVLOGLCOL";
	public static final String REVLOGLTAB= "REVLOGLTAB";

	//Rev Log DETAIL
	public static final String REVLOGD= "REVLOGD";
	public static final String REVLOGDSEC= "REVLOGDSEC";	
	public static final String REVLOGDTAB= "REVLOGDTAB";

	// Key Store Query 
	public static final String KEYSTRLST = "KEYSTRLST";
	public static final String KEYSTRLSTTAB = "KEYSTRLSTTAB";
	public static final String KEYSTRLSTSEC = "KEYSTRLSTSEC";
	public static final String KEYSTRLSTCOL = "KEYSTRLSTCOL";

	// Key Store Detail
	public static final String KEYSTRDTL = "KEYSTRDTL";
	public static final String KEYSTRDTLTAB = "KEYSTRDTLTAB";
	public static final String KEYSTRDTLSEC = "KEYSTRDTLSEC";

	// Card Status Change Allowed Detail 
	public static final String CHGALWDET = "CHGALWDET";
	public static final String CHGALWDETTAB = "CHGALWDETTAB";
	public static final String CHGALWDETSEC = "CHGALWDETSEC";
	public static final String CHGALWDETCOL = "CHGALWDETCOL";

	// Card Status History Query 
	public static final String CRDSTATLST = "CRDSTATLST";
	public static final String CRDSTATLSTTAB = "CRDSTATLSTTAB";
	public static final String CRDSTATLSTSEC = "CRDSTATLSTSEC";
	public static final String CRDSTATLSTCOL = "CRDSTATLSTCOL";
	public static final String CRDSTATHISTCOL = "CRDSTATHISTCOL";

	// PIN Try Counter Query 
	public static final String PINTRYCTL = "PINTRYCTL";
	public static final String PINTRYCTLISTTAB = "PINTRYCTLISTTAB";
	public static final String PINTRYCTLISTSEC = "PINTRYCTLISTSEC";
	public static final String PINTRYCTLISTCOL = "PINTRYCTLISTCOL";

	// Card Status Map 
	public static final String CRDSTATMAP = "CRDSTATMAP";
	public static final String CRDSTATMAPTAB = "CRDSTATMAPTAB";
	public static final String CRDSTATMAPSEC = "CRDSTATMAPSEC";
	public static final String CRDSTATMAPCOL = "CRDSTATMAPCOL";
	public static final String SHC_CARD_STATUS = "shc_crd_status";
	public static final String SHC_CARD_NEW_STATUS = "shc_crd_new_status";

	//SHC800Log Query
	public static final String SHC800LOGQ = "SHC800LOGQ";
	public static final String SHC800LOGQTAB = "SHC800LOGQTAB";
	public static final String SHC800LOGQSEC = "SHC800LOGQSEC";
	public static final String SHC800LOGQCOL = "SHC800LOGQCOL";

	//SHC800Log Detail
	public static final String SHC800LOGD = "SHC800LOGD";
	public static final String SHC800LOGDTAB = "SHC800LOGDTAB";
	public static final String SHC800LOGDSEC = "SHC800LOGDSEC";


	//SHC Negative Auth
	public static final String SHCNAVAUTH = "SHCNAVAUTH";
	public static final String SHCNAVAUTHTAB = "SHCNAVAUTHTAB";
	public static final String SHCNAVAUTHSEC = "SHCNAVAUTHSEC";
	public static final String SHCNAVAUTHCOL = "SHCNAVAUTHCOL";

}

