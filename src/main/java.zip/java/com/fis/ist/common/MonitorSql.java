package com.fis.ist.common;
public class MonitorSql {
	
	public static final String CONNECTED_ATM_FROM_MONITOR_DB=getConnectedATMFromMonDb();
	
	public static final String UP_ATM_BY_SWITCH_DB=getRunningATMBySwDb();
	
	public static final String OUT_OF_SERVICE_ATM_BY_SWITCH_DB=getOutOfServiceATMBySwDb();	
	
	public static final String UP_TEMINAL_BY_SITE_BY_SWITCH_DB=getUpTerminalsBySiteSwDb();
	
	public static final String PERCENTAGE_OF_UP_DOWN_TERMINAL_BY_SITE_MONITOR_DB=getUpAndDownPercentageBySiteMonDb();
	
	public static final String PERCENTAGE_OF_UP_DOWN_TERMINAL_BY_BRANCH_MONITOR_DB=getUpAndDownPercentageByBranchMonDb();
	
	public static final String TOTAL_RUNNING_ATM_BY_MAKE_BY_SWITCH_DB = getTotalRunningATMByMakeSwDb();
	
	public static final String TOTAL_CONFIGURED_ATM_BY_SWITCH_DB=getTotalConfiguredATMByMakeSwDb();
	
	public static final String TOTAL_ATMS_BY_SWITCH_DB =getTotalATMBySwDb();
	
	public static final String FAULT_WISE_COUNT_BY_SWITCH_DB=getFaultWiseCountBySwDb();
	
	public static final String ATM_DATASOURE_FAULT_DETAILS_IST_DB = getDataSourceFaultDetailsfromISTDB();
	
	public static final String ATM_DATASOURE_BRANCHSITE_CNTRY_DETAILS_MON_DB = getDataSourceBranchSiteCntryDetailsfromMONDB();
	
	public static final String ATM_DATASOURE_RLTM_CASH_IST_DB = getDataSourceRltmCashfromISTDB();
	
	public static final String ATM_DOWN_BY_BRANCH_TERM_ID_SWITCH_DB = getATMDownByBranchSwDb();
	
	public static final String ATM_DOWN_BY_BRANCH_TERM_ID_MONITOR_DB = getATMDownByBranchMonDb();
	
	public static final String ATM_DOWN_BY_SITE_TERM_ID_MONITOR_DB = getATMDownBySiteMonDb();
	
	public static final String ATM_DOWN_BY_MAKE_TERM_ID_SWITCH_DB=getATMTermIdSwDb();
	
	public static final String ATM_DOWN_BY_MAKE_MONITOR_DB= getATMDownByMakeMonDb();
	
	public static final String ATM_UP_TERMINALS_SWITCH_DB = getUpTerminalsSwDb();
	
	public static final String ATM_UP_TERMINALS_MONITOR_DB = getUpTerminalsMonDb();
	
	public static final String INDIVIDUAL_ATM_STATUS_BY_SW_DB=getIndividualAtmStatus();
	
	public static final String INDIVIDUAL_ATM_STATUS_COUNT_BY_SW_DB=getCountByIndividualAtmStatus();
	
	public static final String ATM_CASSETTE_COUNTER_STATUS_BY_SW_DB=getCassetteCounterBySwDB();
	
	public static final String ATM_CASSETTE_COUNTER_STATUS_COUNT_BY_SW_DB=getCountByCassetteCounterBySwDB();
	
    public static final String ATM_TOTALS_BY_SW_DB=getATMTotalsBySwDB();
	
	public static final String ATM_TOTALS_COUNT_BY_SW_DB=getATMTotalsCountBySwDB();
	
	public static final String SWITCH_COMMAND_TSKCMD_TYPE = getTypeOfTaskCmd();
	
	public static final String SWITCH_COMMAND_BINSTATUS_TYPE = getTypeOfBinStatus();
	
	public static final String SWITCH_COMMAND_DB_DETAILS = getDataBaseDetails();
	
	public static final String SWITCH_PORT_DETAILS = getPortDetails();
	
	public static final String SWITCH_TRACE_DETAILS = getTraceDetails();
	
	public static final String SWITCH_COMMAND_BINSTATUS_TYPE_BY_INSTID = getTypeOfBinStatusByInstId();
	
	public static final String SWITCH_DEBUGINFO_BY_FILENAME = getDebugInfoByFileName();
	
	public static final String SWITCH_RESOURCES_USED = getResourcesUsed();

	public static final String SWITCH_ALLOCATED_BASIC_CONFIGURATIONS = getAlloctedBasicConfigurations();

				
	private static String getConnectedATMFromMonDb() {
		StringBuilder  qryBuilder = new StringBuilder();		
		qryBuilder.append("select b.termid  as connectedTermId from cs_moncmdout a,cs_monatm_ext b ").
		append(" where  a.cmd='mbportcmd list' and a.field2 like 'atm.%' and a.field2 = 'atm.'|| b.institutionid || '.' || b.group_name || '.' || lpad(b.unit,3,0)").
		append( " and  substr(a.field9,1,1) ='+' ");
		return qryBuilder.toString();
	}
	
	private static String getRunningATMBySwDb() {
		StringBuilder  qryBuilder = new StringBuilder();		
		qryBuilder.append("select count(1) as upAtm from (select  atmss.status as status , rank() over ( partition by instid, grpname, atmunit, atmss.status_date order by status_time desc) as sortbyrank  from ").
		append("  (select max(status_date) as maxdate , atmstatus.institutionid as instid, atmstatus.group_name as grpname, atmstatus.unit as atmunit  ").
		append( " from CS_MONATMSTATUS atmstatus, CS_MONATM atm where concat(atm.termid,trim(atm.term_comp)) in (:atmList) and atm.institutionid = atmstatus.institutionid and atm.group_name = atmstatus.group_name and atm.unit = atmstatus.unit ").
		append( " group by atmstatus.institutionid, atmstatus.group_name , atmstatus.unit)  inner join CS_MONATMSTATUS atmss   on atmss.institutionid = instid and  atmss.group_name = grpname and atmss.unit =atmunit and  atmss.status_date = maxdate) where sortbyrank = 1 and status = -101 group by status");
		return qryBuilder.toString();
	}
	
	private static String getOutOfServiceATMBySwDb() {
		StringBuilder  qryBuilder = new StringBuilder();		
		qryBuilder.append("select COUNT(1) AS downAtm,status  from (SELECT atmss.status AS status, RANK() OVER(PARTITION BY instid, grpname, atmunit, atmss.status_date order by status_time desc) as sortbyrank  from ").
		append("  (SELECT MAX(status_date) AS maxdate,institutionid  AS instid, group_name AS grpname,unit AS atmunit FROM CS_MONATMSTATUS GROUP BY institutionid, group_name,unit)").
		append( " INNER JOIN CS_MONATMSTATUS atmss ON atmss.institutionid = instid AND atmss.group_name = grpname AND atmss.unit = atmunit AND atmss.status_date = maxdate ) ").
		append( " where sortbyrank = 1 and status =101 group by status ");
		return qryBuilder.toString();
	}
	
	private static String getUpTerminalsBySiteSwDb() {
		StringBuilder  qryBuilder = new StringBuilder();		
		qryBuilder.append("SELECT termid1 AS upterminals FROM (SELECT atmss.status AS status,termid1,RANK() OVER(PARTITION BY instid, grpname, atmunit, atmss.status_date ORDER BY status_time DESC) AS sortbyrank from ").
		append(" (SELECT MAX(status_date) AS maxdate,atmstatus.institutionid AS instid,atmstatus.group_name AS grpname,atmstatus.unit AS atmunit,concat(atm.termid, TRIM(atm.term_comp)) AS termid1 FROM CS_MONATMSTATUS atmstatus,CS_MONATM atm ").
		append("  WHERE concat(atm.termid, TRIM(atm.term_comp)) IN (:atmList) AND atm.institutionid = atmstatus.institutionid AND atm.group_name = atmstatus.group_name AND atm.unit = atmstatus.unit GROUP BY atmstatus.institutionid,").
		append(" atmstatus.group_name,atmstatus.unit,atm.termid,atm.term_comp,concat(atm.termid, TRIM(atm.term_comp))) INNER JOIN CS_MONATMSTATUS atmss ON atmss.institutionid = instid AND atmss.group_name = grpname AND atmss.unit = atmunit").
		append("  AND atmss.status_date = maxdate) WHERE sortbyrank = 1 AND status = - 101 GROUP BY status, termid1");
		return qryBuilder.toString();
	}
	private static String getUpAndDownPercentageBySiteMonDb() {
		StringBuilder  qryBuilder = new StringBuilder();		
		qryBuilder.append("SELECT sitetype as siteType,round(((totaluptermidspersite/totaltermidspersite))*100,2) AS upPercentage,round(((totaltermidspersite-totaluptermidspersite)/(totaltermidspersite))*100,2) AS downPercentage from ").
		append( " (SELECT COUNT( CASE WHEN termid IN(:terminals) THEN termid END) AS totaluptermidspersite,COUNT(termid) AS totaltermidspersite,sitetype from cs_monatm_ext GROUP BY sitetype)");
		return qryBuilder.toString();
	}
	
	private static String getTotalRunningATMByMakeSwDb() {
		StringBuilder  qryBuilder = new StringBuilder();		
		qryBuilder.append(" select count(1) as runningATMByMake, make as make from (select atmss.status as status,make,rank() over( partition by instid, grpname, atmunit, atmss.status_date order by status_time desc) as   sortbyrank  from ").
		append(" (select max(status_date) as maxdate , atmstatus.institutionid as instid, atmstatus.group_name as grpname, atmstatus.unit as atmunit, atm.make as make  from CS_MONATMSTATUS atmstatus, CS_MONATM atm where concat(atm.termid,trim(atm.term_comp)) in (:atmList) ").
		append(" and atm.institutionid = atmstatus.institutionid and atm.group_name = atmstatus.group_name and atm.unit = atmstatus.unit    group by    atmstatus.institutionid, atmstatus.group_name , atmstatus.unit, make)").
		append( " inner join CS_MONATMSTATUS atmss on atmss.institutionid = instid and  atmss.group_name = grpname and atmss.unit =atmunit and  atmss.status_date = maxdate)  where sortbyrank = 1 and status = -101 group by make,status");
		return qryBuilder.toString();		
	}
	
	private static String getTotalConfiguredATMByMakeSwDb() {
		StringBuilder  qryBuilder = new StringBuilder();
		qryBuilder.append("select count(1)  as totalConfiguredATM, make as make from CS_MONATM group by make");
		return qryBuilder.toString();
	}
	private static String getUpAndDownPercentageByBranchMonDb() {
		StringBuilder  qryBuilder = new StringBuilder();		
		qryBuilder.append("SELECT branchid as branch,round(((totaluptermidsperbranch/totaltermidsperbranch))*100,2) AS upPercentage,round(((totaltermidsperbranch-totaluptermidsperbranch)/(totaltermidsperbranch))*100,2) AS downPercentage from ").
		append( " (SELECT COUNT( CASE WHEN termid IN(:terminals) THEN termid END) AS totaluptermidsperbranch,COUNT(termid) AS totaltermidsperbranch,branchid from cs_monatm_ext GROUP BY branchid)");
		return qryBuilder.toString();
	}
	
	private static String getFaultWiseCountBySwDb() {
		StringBuilder  qryBuilder = new StringBuilder();
		qryBuilder.append(" SELECT COUNT(1) AS totalATMByFault,status as statusCode FROM (SELECT atmss.status AS status,RANK() OVER(PARTITION BY instid, grpname, atmunit, atmss.status_date ORDER BY status_time DESC) AS sortbyrank ").
		append(" FROM(SELECT MAX(status_date) AS maxdate,institutionid AS instid,group_name AS grpname,unit AS atmunit FROM CS_MONATMSTATUS GROUP BY institutionid,group_name,unit)INNER JOIN CS_MONATMSTATUS atmss ON atmss.institutionid = instid ").
		append(" AND atmss.group_name = grpname AND atmss.unit = atmunit AND atmss.status_date = maxdate ) WHERE sortbyrank = 1 GROUP BY status ");
		return qryBuilder.toString();
	}
	
	private static String getTotalATMBySwDb() {
		return "SELECT count(1)as TOTAL_ATM from CS_MONATM";
	}
	
	private static String getDataSourceFaultDetailsfromISTDB() {
		StringBuilder  qryBuilder = new StringBuilder();
				
		qryBuilder.append("select InstId, GrpName, ATMUnit, Termid, Location, GeoLocation, AcceptorName, Currency, LastTransactionDateTime, Make, status, LastStatusDate, LastStatusTime, StatusDesc, "). 
		append("case when status in (604, 607, 614, 615)  then \'All Cassette Fatal Faults\' "). 
		append("when status in (200, 201, 202, 203) then \'Card Reader Problems\' "). 
		append("when status in (608, 613) then \'Cash Handler Problems\' "). 
		append("when status in (740, 741, 742, 743, 744, 745, 746, 750, 751, 755, 756, 757, 758, 759) then \'Cashout Problems\' "). 
		append("when status in (9717) then \'Communication Problems\' "). 
		append("when status in (7) then \'In Supervisory\' "). 
		append("when status in (600, 605) then \'Reject Bill OverFill\' "). 
		append("when status in (999, 717) then \'Encryptor Problem (Encryptor/PinPad)\' "). 
		append("when status in (500, 503) then 'Journal Printer Problem' "). 
		append("when status in (510) then \'Receipt Printer Problem\' "). 
		append("when status in (512) then \'Receipt Printer Paper Out\' "). 
		append("when status in (502) then \'Journal Printer Paper Out\' "). 
		append("when status in (-101) then \'In-Service ATM\' "). 
		append("when status in (101) then \'Out-Of-Service ATM\' end AS FaultType "). 
		append("from ( select  InstId, GrpName, ATMUnit , atmss.status_date as LastStatusDate, atmss.status_time as LastStatusTime, atmss.status as status , atmss.sdesc as StatusDesc, concat(a.termid,trim(a.term_comp)) as Termid, "). 
		append("a.location as Location, a.geo_loc as GeoLocation, a.acceptorname as AcceptorName, a.currency as Currency, a.Make as Make, "). 
		append(" to_char(TO_TIMESTAMP('1970-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') + NUMTODSINTERVAL(ads.lastmsg_time,'SECOND') , 'DD-MON-YYYY HH24:MI:SS') as LastTransactionDateTime, rank() over "). 
		append("( partition by InstId, GrpName, ATMUnit, atmss.status_date order by status_time desc) as  sortbyrank from (select max(status_date) as maxdate , institutionid as InstId, group_name as GrpName, unit as ATMUnit "). 
		append("from CS_MONATMSTATUS  group by    institutionid, group_name, unit ) inner join CS_MONATMSTATUS atmss on atmss.institutionid = InstId and  atmss.group_name = GrpName and atmss.unit = ATMUnit and atmss.status_date = maxdate "). 
		append("inner join CS_MONATM a on a.institutionid=InstId and a.group_name=GrpName and a.unit=ATMUnit left join CS_MONATMDEVICESTATE ads on ads.institutionid =InstId and ads.group_name = GrpName and ads.unit = ATMUnit ) "). 
		append("where sortbyrank = 1 and status in (:status) "). 
		append("group by InstId, GrpName, ATMUnit, Termid, Location, GeoLocation,AcceptorName,Currency,LastTransactionDateTime, Make,  status, LastStatusDate, LastStatusTime, StatusDesc order by FaultType, LastStatusDate ");

		return qryBuilder.toString();
	}	
		
	// Data Source SQL#10 : Real Time Cash Position 
	private static String getDataSourceRltmCashfromISTDB() {
		StringBuilder  qryBuilder = new StringBuilder();
				
		qryBuilder.append("select instid, groupname, atmunit ,termid1 , time, location, GeoLocation, AcceptorName,Currency, Make, ").
		append("to_char(TO_TIMESTAMP('1970-01-01 00:00:00' ,'YYYY-MM-DD HH24:MI:SS') + NUMTODSINTERVAL(ads.lastmsg_time,'SECOND') , 'DD-MON-YYYY HH24:MI:SS') as lastWithdrawaldateTime,	").
		append("Hopper1_Bill, Hopper2_Bill, Hopper3_Bill, Hopper4_Bill, Hopper1_CashDispense, "). 
		append("Hopper2_CashDispense, Hopper3_CashDispense, Hopper4_CashDispense,  Hopper1_EndCash, Hopper2_EndCash, Hopper3_EndCash, Hopper4_EndCash ").
		append("from  ").
		append("(select concat(a.termid,trim(a.term_comp)) as termid1, to_char(sysdate,'MON DD,YYYY HH24:MI:SS')  as time , ").  
		append("atmcctr.institutionid as instid, atmcctr.group_name as groupname, atmcctr.unit as atmunit, a.location as Location, ").
		append("a.geo_loc as GeoLocation,  a.acceptorname as AcceptorName, a.currency as Currency, a.Make as Make, "). 
		append("atmcctr.cash_cur_bal as HopperEndCash,  atmcctr.cash_out as HopperCashOut,   atmcctr.cash_start_bal as HopperBill , cassette_nbr ").  
		append("from CS_MONATMCASCNTER atmcctr , CS_MONATM a where  a.institutionid=atmcctr.institutionid and a.group_name = atmcctr.group_name  and "). //atmcassettecounter to CS_MONATMCASCNTER 
		append("a.unit = atmcctr.unit order by termid1 )  ").
		append("pivot (min(HopperBill) as Bill, min(HopperEndCash) as EndCash, min(HopperCashOut) as CashDispense  ").
		append("for cassette_nbr in ( 1 HOPPER1, 2 HOPPER2, 3 HOPPER3,4 HOPPER4) )  ").
		append("left join CS_MONATMDEVICESTATE ads on ads.institutionid =instid and ads.group_name = groupname and ").  //atmdevicestate to CS_MONATMDEVICESTATUS to CS_MONATMDEVICESTATE
		append("ads.unit = atmunit and ads.last_txntype=1  order by termid ");
		
		return qryBuilder.toString();
	}
	
	private static String getDataSourceBranchSiteCntryDetailsfromMONDB() {
		StringBuilder qryBuilder = new StringBuilder();
		qryBuilder.append("select termid , sitename, sitetype, branchid, branchname,country from cs_monatm_ext where termid in (:termid)");
		String queryString = qryBuilder.toString();
		return queryString;
	}	
	
	//Data Source: Down by Branch - SQL#3
		private static String getATMDownByBranchSwDb() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select InstId, GrpName, ATMUnit,Termid,Location,GeoLocation,AcceptorName,Currency,LastTransactionDateTime, ").
			append("Make, FaultStatusCode, LastStatusDate, LastStatusTime, FaultStatusDesc  ").
			append("from  (select InstId, GrpName, ATMUnit , atmss.status_date as LastStatusDate, atmss.status_time as LastStatusTime,  ").
			append("atmss.status as FaultStatusCode , atmss.sdesc as FaultStatusDesc,concat(a.termid,trim(a.term_comp)) as Termid,  ").
			append("a.location as Location, a.geo_loc as GeoLocation, a.acceptorname as AcceptorName,  ").
			append("a.currency as Currency, a.Make as Make, to_char(TO_TIMESTAMP('1970-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') + NUMTODSINTERVAL(ads.lastmsg_time,'SECOND') , 'DD-MON-YYYY HH24:MI:SS') as LastTransactionDateTime, ").
			append("rank() over ( partition by InstId, GrpName, ATMUnit, atmss.status_date order by status_time desc) as sortbyrank ").
			append("from (select max(status_date) as maxdate , institutionid as InstId, group_name as GrpName, unit as ATMUnit  ").
			append("from CS_MONATMSTATUS  group by  institutionid, group_name, unit ) inner join CS_MONATMSTATUS atmss ").
			append("on atmss.institutionid = InstId and  atmss.group_name = GrpName and atmss.unit =ATMUnit and atmss.status_date = maxdate  ").
			append("inner join CS_MONATM a on a.institutionid=InstId and a.group_name=GrpName and a.unit=ATMUnit ").
			append("left join CS_MONATMDEVICESTATE ads on ads.institutionid =InstId and ads.group_name = GrpName and "). //atmdevicestate to CS_MONATMDEVICESTATUS to CS_MONATMDEVICESTATE
			append("ads.unit = ATMUnit) where sortbyrank = 1 and FaultStatusCode = 101 ").
			append("group by InstId, GrpName, ATMUnit, Termid, Location, GeoLocation,AcceptorName,Currency,LastTransactionDateTime, ").
			append("Make, FaultStatusCode, LastStatusDate, LastStatusTime, FaultStatusDesc");
			
			String queryString = qryBuilder.toString();
			return queryString;
		}
		
		//Data Source: Down by Site - SQL#4  
		private static String getATMDownBySiteMonDb() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select termid, sitename, sitetype, branchid, branchname, country from cs_monatm_ext order by sitetype");
			String queryString = qryBuilder.toString();
			return queryString;
		}
		
		//Data Source: Down by Branch - SQL#5  
		private static String getATMDownByBranchMonDb() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select   termid , branchid, branchname, sitename, sitetype, country from cs_monatm_ext order by branchid");
			String queryString = qryBuilder.toString();
			return queryString;
		}
		
		//Data Source: Down by Make - SQL#6
		private static String getATMTermIdSwDb() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select Make,InstId, GrpName, ATMUnit,Termid,Location, GeoLocation,AcceptorName,Currency,LastTransactionDateTime,").  
					append("FaultStatusCode, LastStatusDate, LastStatusTime, FaultStatusDesc "). 
					append("from (select InstId, GrpName, ATMUnit , atmss.status_date as LastStatusDate, atmss.status_time as LastStatusTime, ").  
					append("atmss.status as FaultStatusCode , atmss.sdesc as FaultStatusDesc,concat(a.termid,trim(a.term_comp)) as Termid, ").  
					append("a.location as Location, a.geo_loc as GeoLocation, a.acceptorname as AcceptorName, "). 
					append("a.currency as Currency, a.Make as Make, to_char(TO_TIMESTAMP('1970-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') + NUMTODSINTERVAL(ads.lastmsg_time,'SECOND') , 'DD-MON-YYYY HH24:MI:SS') as LastTransactionDateTime, "). 
					append("rank() over ( partition by InstId, GrpName, ATMUnit, atmss.status_date order by status_time desc) as sortbyrank "). 
					append("from (select max(status_date) as maxdate , institutionid as InstId, group_name as GrpName, unit as ATMUnit  ").  
					append("from CS_MONATMSTATUS group by    institutionid, group_name, unit ) inner join CS_MONATMSTATUS atmss ").  
					append("on atmss.institutionid = InstId and  atmss.group_name = GrpName and atmss.unit =ATMUnit and atmss.status_date = maxdate ").   
					append("inner join CS_MONATM a  on a.institutionid=InstId and a.group_name=GrpName and a.unit=ATMUnit left join CS_MONATMDEVICESTATE ads ").  //atmdevicestate to CS_MONATMDEVICESTATUS to CS_MONATMDEVICESTATE  
					append("on ads.institutionid =InstId and ads.group_name = GrpName and ads.unit = ATMUnit ) ").  
					append("where sortbyrank = 1 and FaultStatusCode = 101 group by Make,InstId, GrpName, ATMUnit, Termid, Location,").   
					append("GeoLocation,AcceptorName,Currency,LastTransactionDateTime, FaultStatusCode, LastStatusDate, LastStatusTime, FaultStatusDesc ");

			String queryString = qryBuilder.toString();
			return queryString;
		}
		
		//Data Source: Down by Make - SQL#7
		private static String getATMDownByMakeMonDb() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select termid , sitename, sitetype, branchid, branchname,country from cs_monatm_ext where termid in (:termid)");
			String queryString = qryBuilder.toString();
			return queryString;
		}	
		
		//Data Source: Overall Up Terminals - SQL#8
		private static String getUpTerminalsSwDb() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select Termid1 as Termid,InstId, GrpName, ATMUnit,Location, GeoLocation,AcceptorName,Currency,LastTransactionDateTime,").
			append("Make,FaultStatusCode, LastStatusDate, LastStatusTime, FaultStatusDesc ").
			append("from ( select  InstId, GrpName, ATMUnit , atmss.status_date as LastStatusDate, atmss.status_time as LastStatusTime,").
			append("atmss.status as FaultStatusCode , atmss.sdesc as FaultStatusDesc,Termid1, ").
			append("a.location as Location, a.geo_loc as GeoLocation, a.acceptorname as AcceptorName, ").
			append("a.currency as Currency, a.Make as Make, to_char(TO_TIMESTAMP('1970-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') + NUMTODSINTERVAL(ads.lastmsg_time,'SECOND') , 'DD-MON-YYYY HH24:MI:SS') as LastTransactionDateTime,").
			append("rank() over ( partition by InstId, GrpName, ATMUnit, atmss.status_date order by status_time desc) as sortbyrank ").
			append("from (select max(status_date) as maxdate , atmstatus.institutionid as InstId, atmstatus.group_name as GrpName, atmstatus.unit as ATMUnit,").
			append("concat(atm.termid,trim(atm.term_comp)) as termid1 from CS_MONATMSTATUS atmstatus, CS_MONATM atm where concat(atm.termid,trim(atm.term_comp)) in (:termid) ").
			append("and atm.institutionid = atmstatus.institutionid and atm.group_name = atmstatus.group_name and atm.unit = atmstatus.unit ").
			append("group by  atmstatus.institutionid, atmstatus.group_name, atmstatus.unit, atm.termid, atm.term_comp )  inner join CS_MONATMSTATUS atmss ").
			append("on atmss.institutionid = InstId and  atmss.group_name = GrpName and atmss.unit =ATMUnit and ").
			append("atmss.status_date = maxdate inner join CS_MONATM a on a.institutionid=InstId and a.group_name=GrpName and a.unit=ATMUnit ").
			append("left join CS_MONATMDEVICESTATE ads on ads.institutionid =InstId and ads.group_name = GrpName and ads.unit = ATMUnit ) "). //atmdevicestate to CS_MONATMDEVICESTATUS to CS_MONATMDEVICESTATE
			append("where sortbyrank = 1 and FaultStatusCode = -101 group by Termid1, InstId, GrpName, ATMUnit, Location, GeoLocation,AcceptorName,Currency,LastTransactionDateTime, ").
			append("Make,FaultStatusCode, LastStatusDate, LastStatusTime, FaultStatusDesc ");
			String queryString = qryBuilder.toString();
			return queryString;
		}
		
		//Data Source: Overall Up Terminals - SQL#9
		private static String getUpTerminalsMonDb() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select termid , sitename, sitetype, branchid, branchname, country from cs_monatm_ext where termid in (:termid)");
			String queryString = qryBuilder.toString();
			return queryString;
		}
		
		private static String getIndividualAtmStatus() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append(" select institutionId, netname, groupName, unit, severity, fault,  " ).
			 append("   statusdesc1 || chr(13) || chr(10) || " ).
			 append("   statusdesc2 || chr(13) || chr(10) || " ).
			 append("   statusdesc3 || chr(13) || chr(10) || " ).
			 append("   statusdesc4 || chr(13) || chr(10) || " ).
			 append("   statusdesc5 as statusDescList, terminalcomp, terminal, location, \r\n" + 
			 		"   make, acceptorname, siteid " ).
			 append("   from (  " ).
			 append("    SELECT atmdevicestate.institutionid as institutionId,atmdevicestate.net_name as netname,atmdevicestate.group_name as groupName,  " ).
			 append("    atmdevicestate.unit as unit ,atmdevicestate.severity as severity, atmdevicestate.fault as fault,   " ).
			 append("    (select description from CS_MONATMSDESC where status=atmdevicestate.status1) as statusdesc1,  " ).
			 append("    (select description from CS_MONATMSDESC where status=atmdevicestate.status2) as statusdesc2,   " ).
			 append("    (select description from CS_MONATMSDESC where status=atmdevicestate.status3) as statusdesc3,  " ).
			 append("    (select description from CS_MONATMSDESC where status=atmdevicestate.status4) as statusdesc4,  " ).
			 append("    (select description from CS_MONATMSDESC where status=atmdevicestate.status5) as statusdesc5,  " ).
			 append("    atm.term_comp as terminalComp,atm.termid as terminal,atm.location as location,atm.make as make ,  " ).
			 append("    atm.acceptorname as acceptorname,atmdevicestate.site_id as siteId  " ).
			 append("    from CS_MONATMDEVICESTATE atmdevicestate   " ). //atmdevicestate to CS_MONATMDEVICESTATUS to CS_MONATMDEVICESTATE
			 append("    join CS_MONATM atm   " ).
			 append("    on  atmdevicestate.institutionid = atm.institutionid  " ).
			 append("    AND atm.group_name = atmdevicestate.group_name AND atmdevicestate.unit = atm.unit ");// and atm.institutionid=? and atm.group_name=? and atm.unit=?");
            
			return qryBuilder.toString();
		}
		
		private static String getCountByIndividualAtmStatus() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append(" SELECT count(1) as count from CS_MONATMDEVICESTATE atmdevicestate, CS_MONATM atm where  atmdevicestate.institutionid = atm.institutionid "). //atmdevicestate as CS_MONATMDEVICESTATUS to CS_MONATMDEVICESTATE
			append(" AND atm.group_name = atmdevicestate.group_name AND atmdevicestate.unit = atm.unit "); //and atm.institutionid=? and atm.group_name=? and atm.unit=?");
            return qryBuilder.toString();
		}
		
		private static String getCassetteCounterBySwDB() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append(" SELECT INSTITUTIONID as institutionId,GROUP_NAME as groupName,UNIT as unit,CASSETTE_NBR as cassetteNbr,ITEMS_REJECTED as itemsRejected,").
			append(" CASH_INC as cashIncrement,CASH_DEC as cashDecrement,CASH_OUT as cashOut,CASH_CUR_BAL as currentCashBalance, CASH_START_BAL as startCashBalance,").
			append(" CASH_PREV_BAL as previousCashBalance, TO_CHAR(RESET_TIME, 'DD-MON-RRRR HH24:MI:SS') as resetTime,RECYCLE_COUNT as recycleCount,PREV_RECYCLE_COUNT as previousRecycleCount from CS_MONATMCASCNTER  where 1=1"); //ATMCASSETTECOUNTER as CS_MONATMCASCNTER
			//append(" where INSTITUTIONID = ? AND GROUP_NAME =? AND UNIT =?");
		   return qryBuilder.toString();
		}
		
		
		private static String getCountByCassetteCounterBySwDB() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append(" SELECT count(1) as count from CS_MONATMCASCNTER WHERE 1=1 "); //and atm.institutionid=? and atm.group_name=? and atm.unit=?");
            return qryBuilder.toString();
		}
		
		private static String getATMTotalsBySwDB() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("SELECT INSTITUTIONID as institutionId,GROUP_NAME as groupName,UNIT as unit,TYPE as type,CURRENCY as currency,").
			append(" COUNT as count,AMOUNT as amount,TO_CHAR(RESET_TIME, 'DD-MON-RRRR HH24:MI:SS') as resetTime,PREV_COUNT as prevCount, PREV_AMOUNT as prevAmount from CS_MONATMTOTALS WHERE 1=1 ");
			//append(" where INSTITUTIONID = ? AND GROUP_NAME =? AND UNIT =?");
		   return qryBuilder.toString();
		}
		private static String getATMTotalsCountBySwDB() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append(" SELECT count(1) as count from CS_MONATMTOTALS where 1=1 "); //and atm.institutionid=? and atm.group_name=? and atm.unit=?");
            return qryBuilder.toString();
		}
		
		private static String getTypeOfTaskCmd() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select count(1) as recordCount, field2 as recordTypeOf from CS_MONCMDOUT "
					+ "where CMD='tskcmd' "
					+ "and product = :product "
					+ "and nodeid = :nodeId "
					+ "group by field2 ");
            return qryBuilder.toString();			
		}
		
		private static String getTypeOfBinStatus() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select count(1) as recordCount, field2 as recordTypeOf "
							+ "from CS_MONCMDOUT "
							+ "where CMD='shccmd list' "
							+ "and product = :product "
							+ "and nodeid = :nodeId "
							+ "group by field2 ");
            return qryBuilder.toString();			
		}
		
		private static String getTypeOfBinStatusByInstId() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select field0 as instId, count(field1) as binId, field2 as statusByInstId "
							+ "from CS_MONCMDOUT "
							+ "where CMD='shccmd list' "
							+ "and product = :product "
							+ "and nodeid = :nodeId "
							+ "group by  field0, field2 order by field0 ");
            return qryBuilder.toString();			
		}
			
		private static String getDataBaseDetails() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select count(1) as recordCount, field1 as recordTypeOf "
							+ "from CS_MONCMDOUT "
							+ "where CMD='dbconn' "
							+ "and product = :product "
							+ "and nodeid = :nodeId "
							+ "group by field1 ");
            return qryBuilder.toString();			
		}
		
		private static String getPortDetails() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select count(1) as recordCount, field3 as recordTypeOf "
							+ "from CS_MONCMDOUT "
							+ "where CMD='mbportcmd list' "
							+ "and product = :product "
							+ "and nodeid = :nodeId "
							+ "group by field3 order by field3");
            return qryBuilder.toString();			
		}
		
		private static String getTraceDetails() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select count(1) as recordCount, field2 as recordTypeOf "
							+ "from CS_MONCMDOUT "
							+ "where CMD='otracecmd list' "
							+ "and product = :product "
							+ "and nodeid = :nodeId "
							+ "group by field2 order by field2");
            return qryBuilder.toString();			
		}
		
		private static String getDebugInfoByFileName() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select filename as fileName, count(filename) as fileNameCount, debuglevel as debugLevel "
							+ "from CS_MONDEBUG "
							+ "where product = :product "
							+ "and nodeid = :nodeId "
							+ "and logdate > :fromDate and logdate < :toDate "
							+ "group by filename, debuglevel order by fileName desc");
            return qryBuilder.toString();			
		}
		
		private static String getResourcesUsed() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select cmdoutput as resourceResult  "
							+ "from CS_MONCMDOUT "
							+ "where CMD='mbcmd usage' "
							+ "and product = :product "
							+ "and nodeid = :nodeId ");
            return qryBuilder.toString();			
		}
		
		private static String getAlloctedBasicConfigurations() {
			StringBuilder qryBuilder = new StringBuilder();
			qryBuilder.append("select cmdoutput as alloactedBasicConfigs from CS_MONCMDOUT  "
							+ "where CMD='mbcmd options' "
							+ "and product = :product "
							+ "and nodeid = :nodeId ");
            return qryBuilder.toString();			
		}
}
