package com.fis.ist.common;

public class CustomConstants {
	
	public static final String ACTION_INSERT = "insert";
    public static final String ACTION_UPDATE = "update";
    public static final String ACTION_QUERY = "query";
    public static final String ACTION_DELETE = "delete";
    public static final String ACTION_QUERY_DETAIL = "detail";  
    public static final String ACTION_SINGLE_BATCH_SAVE = "save";
    
    public static final String SINGLEPAGE_ADD = "I";
	public static final String SINGLEPAGE_UPDATE = "U";
	public static final String SINGLEPAGE_ADD_DELETE = "ID";
	public static final String SINGLEPAGE_DELETE = "D";	
	public static final String ACTION_SEARCHLIST = "searchlist";
	public static final String SWITCH_SUBSYSTEM = "SWITCH";
	
	//----------Employee single page (EMPLISTSP) FORM--------------------
	public static final String EMPLISTSP = "EMPLISTSP";
	public static final String EMPLISTSPTAB = "EMPLISTSPTAB";
	public static final String EMPLISTSPCOL = "EMPLISTSPCOL";
	public static final String EMPLISTSPSEC = "EMPLISTSPSEC";
	
	//----------Employee List FORM--------------------
	public static final String EMPLIST = "EMPLIST";
	public static final String EMPDETAIL = "EMPDETAIL";
	public static final String EMPDETAILTAB = "EMPDETAILTAB";
	
	// -------   Transation Monitoring ------------
	public static final String TRANSMNTRNG = "TRANSMNTRNG";
	public static final String TRANSMNTRNGTAB = "TRANSMNTRNGTAB";
	public static final String TRANSMNTRNGCOL = "TRANSMNTRNGCOL";
	public static final String TRANSMNTRNGSEC = "TRANSMNTRNGSEC";
	
	// -------   Tasks Monitoring - Task Command ------------
	public static final String TSKCMD = "TSKCMD";
	public static final String TSKCMDTAB = "TSKCMDTAB";
	public static final String TSKCMDCOL = "TSKCMDCOL";
	public static final String TSKCMDSEC = "TSKCMDSEC";
	
	// -------   Incident Monitoring ------------
	public static final String INCLIST = "INCLIST";
	public static final String INCLISTTAB = "INCLISTTAB";
	public static final String INCLISTCOL = "INCLISTCOL";
	public static final String INCLISTSECTION = "INCLISTSECTION";
			
	// -------   Incident Action ------------
	public static final String INCACTION = "INCACTION";
	public static final String INCACTIONTAB = "INCACTIONTAB";
	public static final String INCACTIONSECTION = "INCACTIONSECTION";
	public static final String INCACTIONCOL = "INCACTIONCOL";

	// -------   Incident Alert ------------
	public static final String INCALERT = "INCALERT";
	public static final String INCALERTTAB = "INCALERTTAB";
	public static final String INCALERTSECTION = "INCALERTSECTION";
	public static final String INCALERTCOL = "INCALERTCOL";
	
	// -------   ATM Data Source - Fault Status View ------------
	public static final String ATMFLTVIEW = "ATMFLTVIEW";
	public static final String ATMFLTVIEWTAB = "ATMFLTVIEWTAB";
	public static final String ATMFLTVIEWCOL = "ATMFLTVIEWCOL";
	public static final String ATMFLTVIEWSEC = "ATMFLTVIEWSEC";
	
	// -------   ATM Real Time Cash Position ------------
	public static final String ATMRTCASH = "ATMRTCASH";
	public static final String ATMRTCASHTAB = "ATMRTCASHTAB";
	public static final String ATMRTCASHCOL = "ATMRTCASHCOL";
	public static final String ATMRTCASHSEC = "ATMRTCASHSEC";
	
	// -------   ATM Real Time Cash Position History ------------
	public static final String ATMRTCASHHIS = "ATMRTCASHH";
	public static final String ATMRTCASHHISTAB = "ATMRTCASHH_TAB";
	public static final String ATMRTCASHHISCOL = "ATMRTCASHH_COL";
	public static final String ATMRTCASHHISSEC = "ATMRTCASHH_SEC";
	
	// --------- Application Monitoring - Debug Monitoring ------------
	public static final String DEBUG_MTR_REQ = "DEBUGM_REQ";
	public static final String DEBUG_MTR_TAB = "DEBUG_MTR_TAB";
	public static final String DEBUG_MTR_COL = "DEBUG_MTR_COL";
	public static final String DEBUG_MTR_SEC = "DEBUG_MTR_SEC";
}
