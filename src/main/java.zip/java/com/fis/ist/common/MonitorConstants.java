package com.fis.ist.common;

public class MonitorConstants {

	public static final String ACTION_INSERT = "insert";
	public static final String ACTION_UPDATE = "update";
	public static final String ACTION_QUERY = "query";
	public static final String ACTION_DELETE = "delete";
	public static final String ACTION_QUERY_DETAIL = "detail";
	public static final String ACTION_SINGLE_BATCH_SAVE = "save";

	public static final String SINGLEPAGE_ADD = "I";
	public static final String SINGLEPAGE_UPDATE = "U";
	public static final String SINGLEPAGE_ADD_DELETE = "ID";
	public static final String SINGLEPAGE_DELETE = "D";
	public static final String ACTION_SEARCHLIST = "searchlist";
	public static final String SWITCH_SUBSYSTEM = "SWITCH";

	// ------- ATM Availability ------------
	public static final String ATM_AVAILABILITY_REQ = "ATMAVL_REQ";
	public static final String ATM_AVAILABILITY_TAB = "ATMAVL_TAB";
	public static final String ATM_AVAILABILITY_COL = "ATMAVL_COL";
	public static final String ATM_AVAILABILITY_SEC = "ATMAVL_SEC";

	// ------- Transaction Stats ------------
	public static final String TRANS_STATS_REQ = "TXNSTS_REQ";
	public static final String TRANS_STATS_TAB = "TRANSSTATS_TAB";
	public static final String TRANS_STATS_COL = "TRANSSTATS_COL";
	public static final String TRANS_STATS_SEC = "TRANSSTATS_SEC";
	public static final String TRANS_DTL_COL = "TRANS_DTL_COL";

	// ------- Transaction Stats Resp Code------------
	public static final String TRANS_STATS_RC_REQ = "TXNRC_REQ";
	public static final String TRANS_STATS_RC_TAB = "TXN_RESPCODE_TAB";
	public static final String TRANS_STATS_RC_COL = "TXN_RESPCODE_COL";
	public static final String TRANS_STATS_RC_SEC = "TXN_RESPCODE_SEC";

	// ------- Transaction Terminal Comp------------
	public static final String TRANS_STATS_TER_REQ = "TXNTC_REQ";
	public static final String TRANS_STATS_TER_TAB = "TXN_TERCOMP_TAB";
	public static final String TRANS_STATS_TER_COL = "TXN_TERCOMP_COL";
	public static final String TRANS_STATS_TER_SEC = "TXN_TERCOMP_SEC";
	public static final String TRANS_STATS_TER_TD_SEC = "TXN_TERCOMP_TD_SEC";
	public static final String TRANS_STATS_TER_TD_COL = "TXN_TERCOMP_TD_COL";

	// ------- Least Transaction Terminal Comp------------
	public static final String TRANS_TER_LEAST_REQ = "TXNTL_REQ";
	public static final String TRANS_TER_LEAST_TAB = "TXN_TERLEAST_TAB";
	public static final String TRANS_TER_LEAST_COL = "TXN_TERLEAST_COL";
	public static final String TRANS_TER_LEAST_SEC = "TXN_TERLEAST_SEC";

	// ------- Transaction Stats Issuer ------------
	public static final String TRANS_STATS_ISSUER_REQ = "TXNISS_REQ";
	public static final String TRANS_STATS_ISSUER_TAB = "TXNISS_TAB";
	public static final String TRANS_STATS_ISSUER_COL = "TXNISS_COL";
	public static final String TRANS_STATS_ISSUER_SEC = "TXNISS_SEC";

	// ------- Transaction Stats Comp Acq ------------
	public static final String TRANS_STATS_COMP_ACQ_REQ = "TXNSTS_ACQ";
	public static final String TRANS_STATS_COMP_ACQ_TAB = "TXNSTS_ACQ_TAB";
	public static final String TRANS_STATS_COMP_ACQ_COL = "TXNSTS_ACQ_COL";
	public static final String TRANS_STATS_COMP_ACQ_SEC = "TXNSTS_ACQ_SEC";

	// ------- Transaction Stats Comp Iss ------------
	public static final String TRANS_STATS_COMP_ISS_REQ = "TXNSTS_ISS";
	public static final String TRANS_STATS_COMP_ISS_TAB = "TXNSTS_ISS_TAB";
	public static final String TRANS_STATS_COMP_ISS_COL = "TXNSTS_ISS_COL";
	public static final String TRANS_STATS_COMP_ISS_SEC = "TXNSTS_ISS_SEC";

	// ------- Top 5 acquiring transactions rejections ------------
	public static final String TRANS_T5_ACQ_REQ = "TXNRJACQ";
	public static final String TRANS_T5_ACQ_TAB = "TXNRJACQ_TAB";
	public static final String TRANS_T5_ACQ_COL = "TXNRJACQ_COL";
	public static final String TRANS_T5_ACQ_SEC = "TXNRJACQ_SEC";

	// ------- Transactions Stats by Processing Code ------------
	public static final String TRANS_STATS_PROC_CD_REQ = "TXNPROCCD";
	public static final String TRANS_STATS_PROC_CD_TAB = "TXNPROCCD_TAB";
	public static final String TRANS_STATS_PROC_CD_COL = "TXNPROCCD_COL";
	public static final String TRANS_STATS_PROC_CD_DTL_COL = "TXNPROCCD_DTL_COL";
	public static final String TRANS_STATS_PROC_CD_SEC = "TXNPROCCD_SEC";

	// ------- Transactions Stats ATM POS ------------
	public static final String TRANS_STATS_ATM_POS_REQ = "TXNATMPOS";
	public static final String TRANS_STATS_ATM_POS_TAB = "TXNATMPOS_TAB";
	public static final String TRANS_STATS_ATM_POS_COL = "TXNATMPOS_COL";
	public static final String TRANS_STATS_ATM_POS_SEC = "TXNATMPOS_SEC";

	public static final String TERMINAL_INSTITUTION = "TERMINAL_INSTITUTION";
	public static final String ISSUING_LIST = "ISSUING_LIST";
	public static final String ISS_CARDSCHEME_LIST = "ISS_CARDSCHEME_LIST";
	public static final String IST_PRODUCT = "ISTSWT";
	// ------- Transactions Stats OverSeas ------------
	public static final String TRANS_STATS_OS_REQ = "TXNSTSOS";
	public static final String TRANS_STATS_OS_TAB = "TXNSTSOS_TAB";
	public static final String TRANS_STATS_OS_COL = "TXNSTSOS_COL";
	public static final String TRANS_STATS_OS_SEC = "TXNSTSOS_SEC";

	// ------- Transactions High Volume ------------
	public static final String TRANS_STATS_HV_REQ = "TXNHVOL";
	public static final String TRANS_STATS_HV_TAB = "TXNHVOL_TAB";
	public static final String TRANS_STATS_HV_COL = "TXNHVOL_COL";
	public static final String TRANS_STATS_HV_DTL_COL = "TXNHVOL_DTL_COL";
	public static final String TRANS_STATS_HV_SEC = "TXNHVOL_SEC";
	// ------- Transactions Stats Terminals ------------
	public static final String TRANS_TER_REQ = "TXNTERC";
	public static final String TRANS_TER_TAB = "TXNTERC_TAB";
	public static final String TRANS_TER_COL = "TXNTERC_COL";
	public static final String TRANS_TER_DTL_COL = "TXNTERC_DTL_COL";
	public static final String TRANS_TER_SEC = "TXNTERC_SEC";

	// ------- Top and Least 25 Transacting Terminals ------------
	public static final String TRANS_STATS_TERM_REQ = "TXNSTP_REQ";
	public static final String TRANS_STATS_TERM_TAB = "TXNS_TERMTOP_TAB";
	public static final String TRANS_STATS_TERM_COL = "TXNS_TERMTOP_COL";
	public static final String TRANS_STATS_TERM_SEC = "TXNS_TERMTOP_SEC";
	public static final String TRANS_STATS_TERM_DTL_COL = "TRANS_DTL_COL";

	// ------- To monitor Individual Host transactions ------------
	public static final String TRANS_STATS_HOST_REQ = "TXNSHT_REQ";
	public static final String TRANS_STATS_HOST_TAB = "TXNS_HOST_TAB";
	public static final String TRANS_STATS_HOST_COL = "TXNS_HOST_COL";
	public static final String TRANS_STATS_HOST_SEC = "TXNS_HOST_SEC";
	public static final String TRANS_STATS_HOST_DTL_COL = "TXNS_HOST_DTL_COL";

	// ------- Data point Rejected transactions count ------------
	public static final String TRANS_STATS_REJC_REQ = "TXNSRJ_REQ";
	public static final String TRANS_STATS_REJC_TAB = "TXNS_REJC_TAB";
	public static final String TRANS_STATS_REJC_COL = "TXNS_REJC_COL";
	public static final String TRANS_STATS_REJC_SEC = "TXNS_REJC_SEC";

	// ------- Data point Successful transactions count ------------
	public static final String TRANS_STATS_SUC_REQ = "TXNSSC_REQ";
	public static final String TRANS_STATS_SUC_TAB = "TXNS_SUC_TAB";
	public static final String TRANS_STATS_SUC_COL = "TXNS_SUC_COL";
	public static final String TRANS_STATS_SUC_DTL_COL = "TXNS_SUC_DTL_COL";
	public static final String TRANS_STATS_SUC_SEC = "TXNS_SUC_SEC";
	

	// ------- Data Point Transactions Per Second ------------
	public static final String TRANS_TPS_REQ = "TXNTPS_REQ";
	public static final String TRANS_TPS_TAB = "TXNS_TPS_TAB";
	public static final String TRANS_TPS_COL = "TXNS_TPS_COL";
	public static final String TRANS_TPS_SEC = "TXNS_TPS_SEC";

	// ------- Data point Fallback transactions count ------------
	public static final String TRANS_STATS_FBC_REQ = "TXNFBC_REQ";
	public static final String TRANS_STATS_FBC_TAB = "TXNS_FLBK_TAB"; //"TXNS_FBC_TAB";
	public static final String TRANS_STATS_FBC_COL = "TXNS_FBC_COL";
	public static final String TRANS_STATS_FBC_DTL_COL = "TXNS_FBC_DTL_COL";
	public static final String TRANS_STATS_FBC_SEC = "TXNS_FBC_SEC";

	// ------- ATM Down by Make ------------
	public static final String ATM_DOWN_MAKE_REQ = "ATMDWM_REQ";
	public static final String ATM_DOWN_MAKE_TAB = "ATM_DWM_TAB";
	public static final String ATM_DOWN_MAKE_COL = "ATM_DWM_COL";
	public static final String ATM_DOWN_MAKE_SEC = "ATM_DWM_SEC";

	// ------- ATM Down by Branch ------------
	public static final String ATM_DOWN_BRANCH_REQ = "ATMDWB_REQ";
	public static final String ATM_DOWN_BRANCH_TAB = "ATM_DWB_TAB";
	public static final String ATM_DOWN_BRANCH_COL = "ATM_DWB_COL";
	public static final String ATM_DOWN_BRANCH_SEC = "ATM_DWB_SEC";

	// ------- ATM Down by Site ------------
	public static final String ATM_DOWN_SITE_REQ = "ATMDWS_REQ";
	public static final String ATM_DOWN_SITE_TAB = "ATM_DWS_TAB";
	public static final String ATM_DOWN_SITE_COL = "ATM_DWS_COL";
	public static final String ATM_DOWN_SITE_SEC = "ATM_DWS_SEC";

	// ------- ATM Overall Up Terminals ------------
	public static final String ATM_UP_TERM_REQ = "ATMUPT_REQ";
	public static final String ATM_UP_TERM_TAB = "ATM_UPT_TAB";
	public static final String ATM_UP_TERM_COL = "ATM_UPT_COL";
	public static final String ATM_UP_TERM_SEC = "ATM_UPT_SEC";

	// ------- Mon Global Value ------------
	public static final String MONGLBVAL = "MONGLBVAL";
	public static final String MONGLBVALTAB = "MONGLBVALTAB";
	public static final String MONGLBVALCOL = "MONGLBVALCOL";
	public static final String MONGLBVALSEC = "MONGLBVALSEC";

	// ------- Mon ATM Extension ------------
	public static final String MONATMEXT = "MONATMEXT";
	public static final String MONATMEXTTAB = "MONATMEXTTAB";
	public static final String MONATMEXTCOL = "MONATMEXTCOL";
	public static final String MONATMEXTSEC = "MONATMEXTSEC";

	// ------- Individual ATM Status ------------
	public static final String INDVL_ATM_STATUS_REQ = "INVATM_REQ";
	public static final String INDVL_ATM_STATUS_TAB = "INVATM_TAB";
	public static final String INDVL_ATM_STATUS_COL = "INVATM_COL";
	public static final String INDVL_ATM_STATUS_SEC = "INVATM_SEC";

	// ------- ATM CASSETTE COUNTER ------------
	public static final String ATM_CASSETTE_COUNTER_REQ = "ATMCTE_REQ";
	public static final String ATM_CASSETTE_COUNTER_TAB = "ATMCTE_TAB";
	public static final String ATM_CASSETTE_COUNTER_COL = "ATMCTE_COL";
	public static final String ATM_CASSETTE_COUNTER_SEC = "ATMCTE_SEC";

	// ------- ATM TOTALS ------------
	public static final String ATM_TOTALS_REQ = "ATMTOT_REQ";
	public static final String ATM_TOTALS_TAB = "ATMTOT_TAB";
	public static final String ATM_TOTALS_COL = "ATMTOT_COL";
	public static final String ATM_TOTALS_SEC = "ATMTOT_SEC";
			
	// ------- Data Retention Config ------------
	public static final String DATA_RT_REQ = "DATARTCONF";
	public static final String DATA_RT_TAB = "DATARTCONFTAB";
	public static final String DATA_RT_SEC = "DATARTCONFSEC";
	public static final String DATA_RT_COL = "DATARTCONFCOL";
	// TPS Vs Memory
	public static final String TPS_VS_MEM_REQ = "TPSVSMEM";
	public static final String TPS_VS_MEM_TAB = "TPSVSMEMTAB";
	public static final String TPS_VS_MEM_SEC = "TPSVSMEMSEC";
	public static final String TPS_VS_MEM_COL = "TPSVSMEMCOL";
	public static final String TPS_COL = "TPSCOL";
	public static final String TPS_DTL_COL = "TPSDTLCOL";
	public static final String TPS_VS_MEM_DTL_COL = "TRANS_DTL_COL";

	// ------- ATM Database CRA ------------
	public static final String ATM_CRA_REQ = "ATMCRA_REQ";
	public static final String ATM_CRA_TAB = "ATM_CRA_TAB";
	public static final String ATM_CRA_COL = "ATM_CRA_COL";
	public static final String ATM_CRA_SEC = "ATM_CRA_SEC";

	// ------- Transactions Statistics Logs ------------
	public static final String TRANS_STATS_LOGS_REQ = "TXNSTSLOG";
	public static final String TRANS_STATS_LOGS_TAB = "TXNSTSLOG_TAB";
	public static final String TRANS_STATS_LOGS_COL = "TXNSTSLOG_COL";
	public static final String TRANS_STATS_LOGS_SEC = "TXNSTSLOG_SEC";

	// ------- Transaction Stats ------------
	public static final String TRANS_STATS_TYPE_REQ = "TXNTYPEREQ";
	public static final String TRANS_STATS_TYPE_TAB = "TXNTYPE_TAB";
	public static final String TRANS_STATS_TYPE_COL = "TXNTYPE_COL";
	public static final String TRANS_STATS_TYPE_SEC = "TXNTYPE_SEC";
	
	// ------- ATM Total History ------------ATMTOTHIST
	public static final String ATM_HISTORY_REQ = "ATMTOTHIST";
	public static final String ATM_HISTORY_TAB = "ATMTOTHIST_TAB";
	public static final String ATM_HISTORY_COL = "ATMTOTHIST_COL";
	public static final String ATM_HISTORY_SEC = "ATMTOTHIST_SEC";
	
	// ------- ATM COUNTER ------------
	public static final String ATM_COUNTER_REQ = "MONATMCOUN";
	public static final String ATM_COUNTER_TAB = "MONATMCOUN_TAB";
	public static final String ATM_COUNTER_COL = "MONATMCOUN_COL";
	public static final String ATM_COUNTER_SEC = "MONATMCOUN_SEC";

	// ------- ATM Network Overall ------------
	public static final String ATMNTWRKDS = "ATMNTWRKDS";
	public static final String ATMNTWRKDS_TAB = "ATMNTWRKDSTAB";
	public static final String ATMNTWRKDSTAB_COL = "ATMNTWRKDSCOL";
	public static final String ATMNTWRKDSTAB_SEC = "ATMNTWRKDSSEC";
	
	// ------- POS TERMINAL DETAILS ------------ATMTOTHIST
	public static final String POS_DETAILS_REQ = "POSTERDETA";
	public static final String POS_DETAILS_TAB = "POSTERDETA_TAB";
	public static final String POS_DETAILS_COL = "POSTERDETA_COL";
	public static final String POS_DETAILS_SEC = "POSTERDETA_SEC";

    // ------- POS Dashboard ------------
	public static final String POS_DASHBOARD_REQ = "POSDASH";
	public static final String POS_DASHBOARD_TAB = "POSDASH_TAB";
	public static final String POS_DASHBOARD_COL = "POSDASH_COL";
	public static final String POS_DASHBOARD_SEC = "POSDASH_SEC";
	
    // ------- POS Trans Overview ------------
	public static final String POS_TRANSOVERVIEW_REQ = "POSTRANVW";
	public static final String POS_TRANSOVERVIEW_TAB = "POSTRANVW_TAB";
	public static final String POS_TRANSOVERVIEW_COL = "POSTRANVW_COL";
	public static final String POS_TRANSOVERVIEW_DTL_COL = "POSTRANVW_DTL_COL";
	public static final String POS_TRANSOVERVIEW_SEC = "POSTRANVW_SEC";
	
    // ------- Cortex Dashboard ------------
	public static final String CTX_DASHBOARD_REQ = "CTXDASH";
	public static final String CTX_DASHBOARD_TAB = "CTXDASH_TAB";
	public static final String CTX_DASHBOARD_COL = "CTXDASH_COL";
	public static final String CTX_DASHBOARD_SEC = "CTXDASH_SEC";
	
	// ------- INC Dashboard ------------
	public static final String INC_DASHBOARD_REQ = "INCDASH";
	public static final String INC_DASHBOARD_TAB = "INCDASH_TAB";
	public static final String INC_DASHBOARD_COL = "INCDASH_COL";
	public static final String INC_DASHBOARD_SEC = "INCDASH_SEC";
	
	public static final String BD_RESP_CODE_LIST = "BD_RESP_CODE_LIST";
	public static final String TD_RESP_CODE_LIST = "TD_RESP_CODE_LIST";
	
	// ------- POS MERCHANT DETAILS ------------
	public static final String POSMERCHNT_REQ = "POSMERCHNT";
	public static final String POSMERCHNT_TAB = "POSMERCHNT_TAB";
	public static final String POSMERCHNT_COL = "POSMERCHNT_COL";
	public static final String POSMERCHNT_SEC = "POSMERCHNT_SEC";
		
	// --------- Data Points - Encash ------------
	public static final String DPENCASH = "DPENCASH";
	public static final String DPENCASHTAB = "DPENCASHTAB";
	public static final String DPENCASHCOL = "DPENCASHCOL";
	public static final String DPENCASHSEC = "DPENCASHSEC";

	// --------- Data Points - Dbsum ------------
	public static final String DPDBSUM = "DPDBSUM";
	public static final String DPDBSUMTAB = "DPDBSUMTAB";
	public static final String DPDBSUMCOL = "DPDBSUMCOL";
	public static final String DPDBSUMSEC = "DPDBSUMSEC";

	// --------- Data Points - Cdsum ------------
	public static final String DPCDSUM = "DPCDSUM";
	public static final String DPCDSUMTAB = "DPCDSUMTAB";
	public static final String DPCDSUMCOL = "DPCDSUMCOL";
	public static final String DPCDSUMSEC = "DPCDSUMSEC";

	// ------- Transaction Trend Reports Screen ------------
	public static final String TXN_TREND_REQ = "TXNTREND";
	public static final String TXN_TREND_TAB = "TXNTREND_TAB";
	public static final String TXN_TREND_COL = "TXNTREND_COL";
	public static final String TXN_TREND_SEC = "TXNTREND_SEC";
	
    // ------- Platform Dashboard ------------
	public static final String PLTF_DASHBOARD_REQ = "PLTFDASH";
	public static final String PLTF_DASHBOARD_TAB = "PLTFDASH_TAB";
	public static final String PLTF_DASHBOARD_COL = "PLTFDASH_COL";
	public static final String PLTF_DASHBOARD_SEC = "PLTFDASH_SEC";
	
	// ------- INC Dashboard ------------
	public static final String TXN_DASHBOARD_REQ = "TXNDASH";
	public static final String TXN_DASHBOARD_TAB = "TXNDASH_TAB";
	public static final String TXN_DASHBOARD_COL = "TXNDASH_COL";
	public static final String TXN_DASHBOARD_SEC = "TXNDASH_SEC";
	public static final String TXNDASH_DTL_COL = "TXNDASH_DTL_COL";

	// ------- POS Machine Make wise transaction Screen ------------
	public static final String POSMAKE_REQ = "POSMAKE";
	public static final String POSMAKE_TAB = "POSMAKE_TAB";
	public static final String POSMAKE_COL = "POSMAKE_COL";
	public static final String POSMAKE_SEC = "POSMAKE_SEC";
	public static final String POSMAKE_DTL_COL = "POSMAKE_DTL_COL";
	
	// ------- Data point Successful transactions count ------------
	public static final String CPNCPC_STATS_REQ = "CPNCPC_REQ";
	public static final String CPNCPC_STATS_TAB = "CPNCPC_TAB";
	public static final String CPNCPC_STATS_COL = "CPNCPC_COL";
	public static final String CPNCPC_STATS_SEC = "CPNCPC_SEC";
	public static final String CPNCPC_STATS_DTL_COL = "CPNCPC_SUC_DTL_COL";
}
