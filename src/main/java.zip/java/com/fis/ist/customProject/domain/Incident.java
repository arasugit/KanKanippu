package com.fis.ist.customProject.domain;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CS_MONINCCFG" )
public class Incident implements java.io.Serializable {

	private Integer cfgId;
	private String description;
	private String product;
	private String nodeId;
	private String cmd;
	private String subcmd;
	private String condition;
	private String priority;
	private String alertType;
	private Date startDate;
	private Date endDate;
	private String message;
	private String smsNumber;
	private String emailId;
	private String type;
	private String l2_EmailId;
	private String l2_smsNumber;
	private String l3_EmailId;
	private String l3_smsNumber;
	
	private String startDateAsString;
	private String endDateAsString;
	
	private String cmdToExe;


	public Incident() {	}


	public Incident(Integer cfgId) {
		this.cfgId = cfgId;
	}

	
	public Incident(Integer cfgId, String description, String product, String nodeId, String cmd, String subcmd,
			String condition, String priority, String alertType, Date startDate, Date endDate, String message,
			String smsNumber, String emailId, String type, String l2_EmailId, String l2_smsNumber, String l3_EmailId,
			String l3_smsNumber, String startDateAsString, String endDateAsString, String cmdToExe) {
	
		this.cfgId = cfgId;
		this.description = description;
		this.product = product;
		this.nodeId = nodeId;
		this.cmd = cmd;
		this.subcmd = subcmd;
		this.condition = condition;
		this.priority = priority;
		this.alertType = alertType;
		this.startDate = startDate;
		this.endDate = endDate;
		this.message = message;
		this.smsNumber = smsNumber;
		this.emailId = emailId;
		this.type = type;
		this.l2_EmailId = l2_EmailId;
		this.l2_smsNumber = l2_smsNumber;
		this.l3_EmailId = l3_EmailId;
		this.l3_smsNumber = l3_smsNumber;
		this.startDateAsString = startDateAsString;
		this.endDateAsString = endDateAsString;
		this.cmdToExe = cmdToExe;
	}


	@Id
	@Column(name = "CFGID",unique = true, nullable = false, precision = 6, scale = 0)
	public Integer getCfgId() {
		return this.cfgId;
	}

	public void setCfgId(Integer cfgId) {
		this.cfgId = cfgId;
	}

	@Column(name = "DESCRIPTION", length = 30)
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Column(name = "PRODUCT", length = 20)
	public String getProduct() {
		return this.product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@Column(name = "NODEID", length = 20)
	public String getNodeId() {
		return this.nodeId;
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	
	@Column(name = "CMD", length = 20)
	public String getCmd() {
		return this.cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}
	
	@Column(name = "SUBCMD", length = 20)
	public String getSubCmd() {
		return this.subcmd;
	}

	public void setSubCmd(String subcmd) {
		this.subcmd = subcmd;
	}
	
	@Column(name = "CONDITION", length = 20)
	public String getCondition() {
		return this.condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}
	
	@Column(name = "PRIORITY", length = 20)
	public String getPriority() {
		return this.priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	@Column(name = "ALERTTYPE", length = 20)
	public String getAlertType() {
		return this.alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	
	
	@Temporal(TemporalType.DATE)
	@Column(name = "STARTDATE", nullable = true, length = 7)
	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	
	@Temporal(TemporalType.DATE)
	@Column(name = "ENDDATE", nullable = true, length = 7)
	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	@Column(name = "MESSAGE", length = 20)
	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	@Column(name = "SMSNUMBER", length = 20)
	public String getSmsNumber() {
		return this.smsNumber;
	}
	
	public void setSmsNumber(String smsNumber) {
		this.smsNumber = smsNumber;
		
	}

	@Column(name = "EMAILID", length = 20)
	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Column(name = "TYPE", length = 32)
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Column(name = "L2_EMAILID", length = 256)
	public String getL2_EmailId() {
		return l2_EmailId;
	}

	public void setL2_EmailId(String l2_EmailId) {
		this.l2_EmailId = l2_EmailId;
	}

	@Column(name = "L2_SMSNUMBER", length = 16)
	public String getL2_smsNumber() {
		return l2_smsNumber;
	}

	public void setL2_smsNumber(String l2_smsNumber) {
		this.l2_smsNumber = l2_smsNumber;
	}

	@Column(name = "L3_EMAILID", length = 256)
	public String getL3_EmailId() {
		return l3_EmailId;
	}

	public void setL3_EmailId(String l3_EmailId) {
		this.l3_EmailId = l3_EmailId;
	}

	@Column(name = "L3_SMSNUMBER", length = 16)
	public String getL3_smsNumber() {
		return l3_smsNumber;
	}

	public void setL3_smsNumber(String l3_smsNumber) {
		this.l3_smsNumber = l3_smsNumber;
	}

	@Column(name = "CMDTOEXE", length = 256)
	public String getCmdToExe() {
		return cmdToExe;
	}

	public void setCmdToExe(String cmdToExe) {
		this.cmdToExe = cmdToExe;
	}
}
