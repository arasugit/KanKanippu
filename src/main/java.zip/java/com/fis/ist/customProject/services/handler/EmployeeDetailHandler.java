package com.fis.ist.customProject.services.handler;


import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkField;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.ForeignKeysCheckException;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MKCHandler;
import com.fis.ist.customProject.dao.EmployeeDAO;
import com.fis.ist.customProject.domain.Employee;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class EmployeeDetailHandler extends ISTRequestHandler {

	private static final ISTLogger log = ISTLogger.getLogger(EmployeeDetailHandler.class);

	private static String formAuthId = "Employee";

	// user can't change these when looking at an existing record
	private static final String [] constant_key_fields = {"employeeId"};

	public EmployeeDetailHandler() {
		checkMKCEnabled(formAuthId);
	}

	private WorkRequest getNewWorkRequest(WorkRequest workRequest, UserContext userContext,
			UIMetaData uiMetaData, 
			WorkRequestHandlerData data) throws Exception {

		// this method is called when the screen is invoked in the Insert/Add mode. The list of screen fields will be created as workfield and add to the 
		// workRequest. If any default value to be set to the screen fields, it can be done here.
		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, 
						workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			WorkRequestHelper workHelper = WorkRequestHelper.getInstance();			

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}
		} catch (Exception ex) {
			throw ex;
		} 
		return workRequest;
	}

	/**
	 * Retrieve an existing model object for a possible update.
	 * Save a copy in the session.
	 * 
	 * @param workRequest
	 * @param userContext
	 * @param uiMetaData
	 * @param data
	 * @param requestParams
	 * @return
	 * @throws Exception
	 */
	private WorkRequest getWorkRequest(WorkRequest workRequest, UserContext userContext,
			UIMetaData uiMetaData, 
			WorkRequestHandlerData data,
			Map<String, String> requestParams) throws Exception {
		// This method is invoked to get the records from the database (for updation or to view the complete record)
		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.GET, 
						workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			WorkRequestHelper workHelper = WorkRequestHelper.getInstance();			

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			//read the parameter sent by the client as below and invoke the DAO to get the records and set the values from the database to the workfield
			// to send it to the client.
			Map<String, WorkField> workFields = workRequest.getFields();

			String mkcId =null;
			String mkcRecordAction = "";
			String mkcStatus ="";
			if (isMKCEnabled) {
				mkcId = (String) requestParams.get("mkc_id");
				mkcRecordAction = (String) requestParams.get("mkc_record_action");
				mkcRecordAction = (mkcRecordAction==null?"":mkcRecordAction);
				mkcStatus = (String) requestParams.get("mkc_status");
				mkcStatus = (mkcStatus==null?"":mkcStatus);

			}

			if (isMKCEnabled &&  mkcId!=null && mkcId.equals("0")==false) {
				workRequest = getMKCRequest(workRequest, new Long(mkcId),false);
				if (isCheckerAction==false || (isCheckerAction && (mkcRecordAction.equals("I") || mkcRecordAction.equals("D"))))
					return workRequest;
			}

			if (isCheckerAction && mkcRecordAction.equals("U")) {
				requestParams = new HashMap<String, String>();
				WorkField wf = workRequest.getField("employeeId");
				if (wf !=null) {
					requestParams.put("employeeId", wf.getValue());
				}
			}

			String empId = (String) requestParams.get("employeeId");
			if (empId == null || empId.equals("")) {
				throw new Exception("key not found");
			}

			Integer integerEmpId = null;

			if (empId !=null)
				integerEmpId = empId.equals("") ? null : Integer.valueOf(empId);

			EmployeeDAO empDAO = new EmployeeDAO();
			Employee record = new Employee();
			record = empDAO.findById(integerEmpId);

			if (record ==null)
			{
				if(isMKCEnabled && isCheckerAction){
					MKCHandler.getInstance().updateSystemFailure(workRequest.getMkcId(),userContext.getUserID(),"MKC08");
					log.error("Employee record is missing for update - MKC Enabled" );
					throw new Exception("MKC08");
				}else{
					log.error("Employee record is missing for update" );
					throw new Exception("ER244");
				}
			}

			String value= null;
			WorkField workField=null;
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			if(record.getEmployeeId()!=null){
				value =record.getEmployeeId().toString(); 
				workField = workHelper.createWorkField(value, "employeeId", uiMetaData, "");
				workFields.put("employeeId", workField);
			}			
			workField = workHelper.createWorkField(record.getEmpName()!=null?record.getEmpName():"", "empName", uiMetaData, "");
			workFields.put("empName", workField);

			workField = workHelper.createWorkField(record.getEmail()!=null?record.getEmail():"", "email", uiMetaData, "");
			workFields.put("email", workField);



			workField = workHelper.createWorkField(record.getHireDate()!=null?sdf.format(record.getHireDate()):"", "hireDate", uiMetaData, "");		
			workFields.put("hireDate", workField);
			if(record.getSalary()!=null){
				value =record.getSalary().toString();
				workField = workHelper.createWorkField(value, "salary", uiMetaData, "");
				workFields.put("salary", workField);
			}

			if(record.getDepartmentId()!=null){
				value =record.getDepartmentId().toString();
				workField = workHelper.createWorkField(value, "departmentId", uiMetaData, "");
				workFields.put("departmentId", workField);
			}
			if (isMKCEnabled &&  mkcId!=null && mkcId.equals("0")==false && isCheckerAction)
			{
				return mergeWorkRequestWithMKCData(workRequest, mkcId, null);
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}


	public WorkRequest insertRecord(UserContext userContext, WorkRequest workRequest) {

		//This method will be invoked to insert the record into the database
		save(userContext, workRequest,true);
		return workRequest;
	}

	public WorkRequest updateRecord(UserContext userContext, WorkRequest workRequest) {

		//This method will be invoked to update the record into the database
		save(userContext, workRequest,false);
		return workRequest;
	}

	public WorkRequest deleteRecord(UserContext userContext, WorkRequest workRequest) {
		//This method will be invoked to delete the record into the database
		delete(userContext, workRequest);
		return workRequest;
	}

	public WorkRequest getDataForAdd(UserContext userContext, Map<String, String> requestParams,String action) throws Exception {
		return getDetailRecord(userContext, null,action);
	}

	public WorkRequest getDataForUpdate(UserContext userContext, Map<String, String> requestParams,String action) throws Exception {

		return getDetailRecord(userContext, requestParams,action);
	}

	public WorkRequest getMKCRequest(UserContext userContext, Map<String, String> requestParams, String action) throws Exception {

		return getDetailRecord(userContext, requestParams, action);
	}
	
	/**
	 * Look up an institution object or create an empty one with default values;
	 * return its contents in a 'pseudo' WorkRequest.
	 * @param userContext
	 * @param requestParams
	 * @param action
	 * @return
	 * @throws Exception
	 */
	private WorkRequest getDetailRecord(UserContext userContext, Map<String, String> requestParams, String action) throws Exception {
		WorkRequestHelper wrh = WorkRequestHelper.getInstance();
		WorkRequest workReq = new WorkRequest();

		try {
			String requestType = CustomConstants.EMPDETAIL;
			String tabTag = CustomConstants.EMPDETAILTAB;

			workReq = wrh.makeWorkRequest(workReq, requestType, tabTag);
			try {
				isCheckerRequest(formAuthId,action);
			}catch (Exception e) {}

			UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(requestType);
			if (requestParams == null) {
				workReq = getNewWorkRequest(workReq, userContext, uiMetaData, null);
			} else {
				workReq = getWorkRequest(workReq, userContext, uiMetaData, null, requestParams);
			}
			enableWorkFields(workReq, requestParams,action);
		}
		catch (Exception ex)
		{
			wrh.reportException(log, ex, workReq);
		}
		return workReq;

	}
	
	private void enableWorkFields(WorkRequest workReq, Map<String, String> requestParams, String action)
	{
		if (isMKCEnabled)
		{
			
			String mkcId = workReq.getMkcId()==null?"0":workReq.getMkcId().toString();
			if  (mkcId!=null && mkcId.equals("0")==false)
			{
				String mkcStatus = requestParams.get("mkc_status");
				if (AppConstants.MKC_STATUS_REWORK.equalsIgnoreCase(mkcStatus) && action.equals(AppConstants.MKC_ACTION_REWORK_EDIT))
				{
					String mkcRecordAction = requestParams.get("mkc_record_action");
					if (mkcRecordAction != null)
					{
						if (mkcRecordAction.equals("I"))
							mkcRecordAction = CustomConstants.ACTION_INSERT;
						else if (mkcRecordAction.equals("U"))
							mkcRecordAction = CustomConstants.ACTION_UPDATE;
						else if (mkcRecordAction.equals("D"))
							mkcRecordAction = CustomConstants.ACTION_DELETE;
						else
						{;}
						enableWorkFields( workReq,  mkcRecordAction);
					}
				}
				return;
			}
		}
		enableWorkFields( workReq,  action);
	}
	
	private void enableWorkFields(WorkRequest workReq, String action)
	{
		Map<String, WorkField> fields = workReq.getFields();
		Collection<WorkField> cfields = fields.values();

		if (action.equals(CustomConstants.ACTION_INSERT) || action.equals(CustomConstants.ACTION_UPDATE))
		{
			for(WorkField field : cfields) {
				field.setModifyable("Y");
				field.setVisible("Y");
			}
		}
		if (action.equals(CustomConstants.ACTION_UPDATE))
		{
			for (String name: constant_key_fields)
			{
				WorkField field = fields.get(name);
				log.debug("setting non-modifyable:" + field.tag);
				field.setModifyable("N");
			}
		}
	}

	/**
	 *  Save updates/adds for Work Request comments to the institution table
	 *  
	 *  @param WorkRequestHandlerData 
	 */ 
	public void save(UserContext userContext, WorkRequest workRequest, Boolean isInsertRecord) {
		// check if contact field data is present
		Map<String, WorkField> fields = workRequest.getFields();		   
		if (fields == null) 
		{
			WorkRequestHelper.getInstance().reportError("Work fields not found", workRequest);
			return;
		}		  
		//check for the mandatory fields/primary key fields which is required to save the record
		//if it is not entered, then throw the exception to display the error message in the screen
		WorkField EmpIdField = fields.get("employeeId");
		if (EmpIdField == null || StringUtil.isEmpty(EmpIdField.getValue())  ) {
			WorkRequestHelper.getInstance().reportError("Employee Id is mandatory field", workRequest);
			if (EmpIdField != null) {
				EmpIdField.setErrorInfo("Required field");
			}
			return;
		}
		WorkField hireDate = fields.get("hireDate");
		if (hireDate == null || StringUtil.isEmpty(hireDate.getValue())  ) {
			WorkRequestHelper.getInstance().reportError("Hire date is mandatory field", workRequest);
			if (hireDate != null) {
				hireDate.setErrorInfo("Required field");
			}
			return;
		}

		Integer integerEmpId = EmpIdField.getValue() == null ? null : Integer.valueOf(EmpIdField.getValue());

		EmployeeDAO empDAO = new EmployeeDAO();
		// Check record exists
		Employee empRecord = null;
		if (isInsertRecord)
		{
			if ((empRecord = empDAO.findById(integerEmpId)) != null) {
				log.error("Duplicate record" );
				WorkRequestHelper.getInstance().reportError("ERR89", workRequest); //duplicate record
				return;
			}
		}

		//Otherwise invoke the DAOs and insert, update the record.

		if(empRecord == null){
			empRecord = new Employee();
			empRecord.setEmployeeId(integerEmpId);
		}

		empRecord.setEmpName(fields.get("empName").getValue());
		empRecord.setEmail(fields.get("email").getValue());

		String value = fields.get("salary").getValue();
		value = value.replaceAll(",", "");
		BigDecimal dSaralary = null;
		if (value != null)
			dSaralary = value.equals("") ? null : new BigDecimal(value);
		empRecord.setSalary(dSaralary);

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		value = fields.get("hireDate").getValue();

		try {
			empRecord.setHireDate(StringUtil.isNotEmpty(value)?sdf.parse(value):null);
		} catch (ParseException pe) {
			workRequest.setErrorDetail("Save failed Value hire date parse exception)");
			log.error(pe, pe);
		}

		value = fields.get("departmentId").getValue();
		Integer deptId = null;
		if (value !=null)
			deptId = value.equals("") ? null : Integer.valueOf(value);

		empRecord.setDepartmentId(deptId);

		try 
		{
			if  ((!isMKCEnabled) || (isMKCEnabled && isCheckerAction)) {
				if (isInsertRecord)
					empDAO.save(empRecord);
				else
					empDAO.merge(empRecord);
			} else if (isMKCEnabled && !isCheckerAction) {
				 if (workRequest.getMkcStatus() !=null && workRequest.getMkcStatus().equalsIgnoreCase(AppConstants.MKC_STATUS_REWORK))
					 UpdateMKCRecord(workRequest, null,"", (isInsertRecord ? "I" : "U"), getUserId(userContext), null);
				 else
					 insertIntoMKC(workRequest, null, "", (isInsertRecord ? "I" : "U"), getUserId(userContext), null);
				 return;
			 }
		} 
		catch (Exception e) 
		{
			 workRequest.setSystemFailure(true);			   
			 WorkRequestHelper.getInstance().reportException(log, e, workRequest);
		}
		finally
		{
			//clearModel();
		}
	}

	public void delete(UserContext userContext, WorkRequest workRequest) {

		Map<String, WorkField> fields = workRequest.getFields();		   
		if (fields == null) 
		{
			WorkRequestHelper.getInstance().reportError("Work fields not found", workRequest);
			return;
		}

		//check for primary key to delete the record.
		WorkField EmpIdField = fields.get("employeeId");
		if (EmpIdField == null || StringUtil.isEmpty(EmpIdField.getValue())  ) {
			WorkRequestHelper.getInstance().reportError("Employeee Id is missing", workRequest);
			if (EmpIdField != null) {
				EmpIdField.setErrorInfo("Required field");
			}
			return;
		}

		//invoke the DAO and delete the record from the database.
		EmployeeDAO empDAO = new EmployeeDAO();
		Employee empRecord = new Employee();

		Integer integerEmpId = EmpIdField.getValue() == null ? null : Integer.valueOf(EmpIdField.getValue());

		try{			  
			empRecord = empDAO.findById(integerEmpId);
			if (empRecord ==null)
			{
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("Record is already deleted");
				return;
			}
			if (isMKCEnabled && !isCheckerAction)
			{
				insertIntoMKC(workRequest, null, "", "D", getUserId(userContext), null);
				return;
			}

			if  ((!isMKCEnabled) || (isMKCEnabled && isCheckerAction)) {
				empDAO.attachClean(empRecord);
				empDAO.delete(empRecord);
			}
		}catch(ForeignKeysCheckException e){
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setMessageSubstitutions(e.getChildTables());				  
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail(e.getMessage());
		}
		catch (Exception e){
			workRequest.setSystemFailure(true);			   
			WorkRequestHelper.getInstance().reportException(log, e, workRequest);
		}		   
	}
}