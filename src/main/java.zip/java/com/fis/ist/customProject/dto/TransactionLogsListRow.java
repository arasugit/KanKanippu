package com.fis.ist.customProject.dto;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Logger;

import com.efunds.t21.common.util.DateUtil;
import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.common.dao.Country;
import com.fis.ist.common.dao.CountryDAO;
import com.fis.ist.common.dao.CurrencyCode;
import com.fis.ist.common.dao.CurrencyCodeDAO;
import com.fis.ist.customProject.dao.ShcLog;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.vo.EditableListRow;

public class TransactionLogsListRow extends EditableListRow {
	private static final ISTLogger log = ISTLogger.getLogger(TransactionLogsListRow.class);
	private String chipIndex;
	private String maskedPan;
	private String pan;
	private String txnsrc;
	private String txndest;
	private String msgtype;
	private String pcode;
	private String trace;
	private String authnum;
	private String refnum;
	private String respcode;
	private String respCodeDesc;
	private String localTime;
	private String termid;
	private String amount;
	private String localDate;
	private String acqCurrencyCode;
	private String amountEquiv;
	private String acceptorname;
	private String termloc;
	private String acqCountry;
	private String merchantType;
	private BigDecimal siteId;
	private String tranDate;
	private String tranTime;
	private String declineCategory;
	private String origDate;
	private String origTrace;
	private String origTime;
	private String origMsg;
	private String pCodeDesc;
	private String alphaRespCode;
	
	SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
	
	//Keep the already loaded info for this set of retrieved records
	private static Map<String, String> currDescCache = new HashMap<String, String>();

	//Keep the already loaded info for this set of retrieved records
	private static Map<String, String> countryDescCache = new HashMap<String, String>();

	public String getChipIndex() {
		return chipIndex;
	}
	public void setChipIndex(String chipIndex) {
		this.chipIndex = chipIndex;
	}
	public String getMaskedPan() {
		return maskedPan;
	}
	public void setMaskedPan(String maskedPan) {
		this.maskedPan = maskedPan;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getTxnsrc() {
		return txnsrc;
	}
	public void setTxnsrc(String txnsrc) {
		this.txnsrc = txnsrc;
	}
	public String getTxndest() {
		return txndest;
	}
	public void setTxndest(String txndest) {
		this.txndest = txndest;
	}
	public String getMsgtype() {
		return msgtype;
	}
	public void setMsgtype(String msgtype) {
		this.msgtype = msgtype;
	}
	public String getPcode() {
		return pcode;
	}
	public void setPcode(String pcode) {
		this.pcode = pcode;
	}
	public String getTrace() {
		return trace;
	}
	public void setTrace(String trace) {
		this.trace = trace;
	}
	public String getAuthnum() {
		return authnum;
	}
	public void setAuthnum(String authnum) {
		this.authnum = authnum;
	}
	public String getRefnum() {
		return refnum;
	}
	public void setRefnum(String refnum) {
		this.refnum = refnum;
	}
	public String getRespcode() {
		return respcode;
	}
	public void setRespcode(String respcode) {
		this.respcode = respcode;
	}
	
	public String getRespCodeDesc() {
		return respCodeDesc;
	}
	public void setRespCodeDesc(String respCodeDesc) {
		this.respCodeDesc = respCodeDesc;
	}

	public String getLocalTime() {
		return this.localTime;
	}

	public void setLocalTime(String localTime) {
		this.localTime = localTime;
	}

	public String getTermid() {
		return this.termid;
	}

	public void setTermid(String termid) {
		this.termid = termid;
	}
	public String getAmount() {
		return this.amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getLocalDate() {
		return this.localDate;
	}

	public void setLocalDate(String localDate) {
		this.localDate = localDate;
	}

	public String getAcqCurrencyCode() {
		return acqCurrencyCode;
	}
	public void setAcqCurrencyCode(String acqCurrencyCode) {
		this.acqCurrencyCode = acqCurrencyCode;
	}
	public String getAmountEquiv() {
		return amountEquiv;
	}
	public void setAmountEquiv(String amountEquiv) {
		this.amountEquiv = amountEquiv;
	}
	public String getAcceptorname() {
		return acceptorname;
	}
	public void setAcceptorname(String acceptorname) {
		this.acceptorname = acceptorname;
	}
	public String getTermloc() {
		return termloc;
	}
	public void setTermloc(String termloc) {
		this.termloc = termloc;
	}
	public String getAcqCountry() {
		return acqCountry;
	}
	public void setAcqCountry(String acqCountry) {
		this.acqCountry = acqCountry;
	}
	public String getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}
	
	public BigDecimal getSiteId() {
		return siteId;
	}
	public void setSiteId(BigDecimal siteId) {
		this.siteId = siteId;
	}
	public String getTranDate() {
		return tranDate;
	}
	public void setTranDate(String tranDate) {
		this.tranDate = tranDate;
	}
	public String getTranTime() {
		return tranTime;
	}
	public void setTranTime(String tranTime) {
		this.tranTime = tranTime;
	}

	public String getDeclineCategory() {
		return declineCategory;
	}
	public void setDeclineCategory(String declineCategory) {
		this.declineCategory = declineCategory;
	}
	public String getOrigDate() {
		return origDate;
	}
	public void setOrigDate(String origDate) {
		this.origDate = origDate;
	}
	public String getOrigTrace() {
		return origTrace;
	}
	public void setOrigTrace(String origTrace) {
		this.origTrace = origTrace;
	}
	public String getOrigTime() {
		return origTime;
	}
	public void setOrigTime(String origTime) {
		this.origTime = origTime;
	}
	public String getOrigMsg() {
		return origMsg;
	}
	public void setOrigMsg(String origMsg) {
		this.origMsg = origMsg;
	}
	public String getpCodeDesc() {
		return pCodeDesc;
	}
	public void setpCodeDesc(String pCodeDesc) {
		this.pCodeDesc = pCodeDesc;
	}
	
	public String getAlphaRespCode() {
		return alphaRespCode;
	}
	public void setAlphaRespCode(String alphaRespCode) {
		this.alphaRespCode = alphaRespCode;
	}
	
	
	public void load(ShcLog model) {
		if(model.getId() != null) {
			setChipIndex(model.getId().getChipIndex());
			setSiteId(model.getId().getSiteId());
		}
		setMaskedPan(model.getMaskedPan());
		setPan(model.getPan());
		setTxnsrc(model.getTxnsrc());
		setTxndest(model.getTxndest());
		setMsgtype(String.valueOf(model.getMsgtype()));
		setPcode(String.valueOf(model.getPcode()));
		setTrace(String.valueOf(model.getTrace()));
		setAuthnum(model.getAuthnum());
		setRefnum(model.getRefnum());
		setRespcode(String.valueOf(model.getRespcode()));
		setLocalTime(String.valueOf(model.getLocalTime()));
		setTermid(model.getTermid());
		setAmount(model.getAmount() != null ? format(model.getAmount().toPlainString(),getCurrExponent(model.getAcqCurrencyCode())) : "");
		setLocalDate(outputFormat.format(model.getLocalDate()));
		setAcqCurrencyCode(getCurrencyCodeDescription(model.getAcqCurrencyCode()));
		setAmountEquiv(model.getAmountEquiv() != null ? format(model.getAmountEquiv().toPlainString(),getCurrExponent(model.getIssCurrencyCode())) : "");
		setAcceptorname(model.getAcceptorname());
		setTermloc(model.getTermloc());
		setAcqCountry(getCountryCodeDescription(model.getAcqCountry()));
		setMerchantType(model.getMerchantType() != null ? String.valueOf(model.getMerchantType()) : "");
		setTranDate(outputFormat.format(model.getTrandate()));
		setTranTime(String.valueOf((model.getTrantime())));
		setOrigMsg(String.valueOf(model.getOrigmsg()));
		setOrigDate(outputFormat.format(model.getOrigdate()));
		setOrigTrace(String.valueOf(model.getOrigtrace()));
		setOrigTime(String.valueOf(model.getOrigtime()));
		setAlphaRespCode(model.getAlpharesponsecode() != null ?  String.valueOf(model.getAlpharesponsecode()) : "");
	}

	public void store(ShcLog model) {

	}

	private String getFormattedTime(BigDecimal time){
		String temp = time != null ? "" + time : ""; 
		/* 10000 = 1:00:00
		 * 102006 = 10:20:06
		 * 5815 = 00:58:15
		 * 01/1 = 000001 = 00:00:01
		 * 10 = 00:00:10
		 * 0512 = 512 = 00:05:12 
		 */
		StringBuffer timeBuffer = new StringBuffer();
		if(StringUtil.isNotEmpty(temp)){
			temp = temp.trim();
			if(temp.length() == 1){
				timeBuffer.append("00:00:0");
				timeBuffer.append(temp);
			}else if(temp.length() == 2){
				timeBuffer.append("00:00:");
				timeBuffer.append(temp);
			}else if(temp.length() == 3){
				timeBuffer.append(temp);
				timeBuffer.insert(1,":");
				timeBuffer.insert(0, "00:0");
			}else if(temp.length() == 4){
				timeBuffer.append(temp);
				timeBuffer.insert(2,":");
				timeBuffer.insert(0, "00:");
			}else if(temp.length() == 5){
				timeBuffer.append(temp);
				timeBuffer.insert(1,":");
				timeBuffer.insert(4,":");
			}else if(temp.length() == 6){
				timeBuffer.append(temp);
				timeBuffer.insert(2,":");
				timeBuffer.insert(5,":");
			}else{
				timeBuffer = new StringBuffer("");
			}
		}
		return timeBuffer.toString();
	}
	
	private String getCurrencyCodeDescription(BigDecimal curr){
		String currCode = (curr != null) ? String.valueOf(curr) : "";
		
		if(StringUtil.isEmpty(currCode))
			return "";
		
		currCode = currCode.trim();
		if(currCode.length() == 1)
			currCode = "00" + currCode;
		else if (currCode.length() == 2)
			currCode = "0" + currCode;
		
		String name = currDescCache.get(currCode);
		if(StringUtil.isNotEmpty(name))
			return name;
		
		CurrencyCodeDAO dao = new CurrencyCodeDAO();
		CurrencyCode model = dao.findById(currCode);
		if(model != null){
			name = model.getCurrName();
			String name1 = model.getCurrCodeAlpha2();
			String name2 = model.getCurrCodeAlpha3();
			String toCache = (StringUtil.isNotEmpty(name) ? name : currCode)+
					"-"+(StringUtil.isNotEmpty(name1) ? name1 : currCode)+
					"-"+(StringUtil.isNotEmpty(name2) ? name2 : currCode); 

			currDescCache.put(currCode, toCache);
			return (currDescCache.get(currCode));
		}
		currDescCache.put(currCode, currCode);
		return (currDescCache.get(currCode));
	}

	private String getCountryCodeDescription(BigDecimal country){
		String countryCode = (country != null) ? String.valueOf(country) : "";
		
		if(StringUtil.isEmpty(countryCode))
			return "";
		
		countryCode = countryCode.trim();
		if(countryCode.length() == 1)
			countryCode = "00" + countryCode;
		else if (countryCode.length() == 2)
			countryCode = "0" + countryCode;
		
		String name = countryDescCache.get(countryCode);
		if(StringUtil.isNotEmpty(name))
			return name;
		
		CountryDAO dao = new CountryDAO();
		Country model = dao.findById(countryCode);
		if(model != null){
			name = model.getCntryName();
			String name1 = model.getCntryCodeAlpha2();
			String name2 = model.getCntryCodeAlpha3();
			String toCache = (StringUtil.isNotEmpty(name) ? name : countryCode)+
					"-"+(StringUtil.isNotEmpty(name1) ? name1 : countryCode)+
					"-"+(StringUtil.isNotEmpty(name2) ? name2 : countryCode); 
			
			currDescCache.put(countryCode, toCache);
			return (currDescCache.get(countryCode));
		}
		currDescCache.put(countryCode, countryCode);
		return (currDescCache.get(countryCode));
	}

	public static void clearCache(){
		currDescCache.clear();
		countryDescCache.clear();
	}
	
	private int getCurrExponent(BigDecimal currency){
		int exponent = 2; //By default 2 decimal places.
		
		if(currency != null){
			String currCode = ""+currency;
			
			if("0".equalsIgnoreCase(currCode))
				return exponent;
			
			if(currCode.length() == 1)
				currCode = "00" + currCode;
			else if (currCode.length() == 2)
				currCode = "0" + currCode;
			
			CurrencyCodeDAO daoObj = new CurrencyCodeDAO();
			CurrencyCode obj = daoObj.findById(currCode);
			if(obj != null){
				String temp = obj.getCurrExponent(); 
				if(StringUtil.isNotEmpty(temp)){
					try{
						exponent = Integer.parseInt(temp);
					}catch(NumberFormatException nfe){
						log.error("NumberFormatException" +nfe.getMessage());
					}
				}
			}
		}
		return exponent;
	}
	
	private String format(String value, int exponent){
		if(value == null){
			return "";
		}
		
		try{
			NumberFormat nf = DecimalFormat.getInstance();
			nf.setMinimumFractionDigits(exponent);
			nf.setMaximumFractionDigits(exponent);
			nf.setGroupingUsed(false);
			return (nf.format(Double.parseDouble(value)));
		}catch(Exception e){
			return "";
		}
	}
}
