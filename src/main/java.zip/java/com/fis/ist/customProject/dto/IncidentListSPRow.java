package com.fis.ist.customProject.dto;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.customProject.domain.Incident;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class IncidentListSPRow  extends EditableListRowForSDK implements Cloneable{
	
	private static final long serialVersionUID = 1L;
	private static final ISTLogger log = ISTLogger.getLogger(IncidentListSPRow.class);
	private String startDateAsString;
	private String endDateAsString;
	private IncidentListSPRow orignalRow;
	private String cfgId;
	private String description;
	private String product;
	private String nodeId;
	private String cmd;
	private String subcmd;
	private String condition;
	private String priority;
	private String alertType;
	private String startDate;
	private String endDate;
	private String message;
	private String smsNumber;
	private String emailId;
	private String type;
	private String l2_EmailId;
	private String l2_smsNumber;
	private String l3_EmailId;
	private String l3_smsNumber;	
	private String cmdtoexe;

	public void load(Incident incident)
	{
		setCfgId(incident.getCfgId().toString());
		setDescription(incident.getDescription());
		setProduct(incident.getProduct());
		setNodeId(incident.getNodeId());
		setCmd(incident.getCmd());
		setSubCmd(incident.getSubCmd());
		setCondition(incident.getCondition());
		setPriority(incident.getPriority());
		setAlertType(incident.getAlertType());
  	 	setStartDate(incident.getStartDate());
  	 	setEndDate(incident.getEndDate());
		setMessage(incident.getMessage());
		setSmsNumber(incident.getSmsNumber());
		setEmailId(incident.getEmailId());		
		setType(incident.getType());
		setL2_EmailId(incident.getL2_EmailId());
		setL2_smsNumber(incident.getL2_smsNumber());
		setL3_EmailId(incident.getL3_EmailId());
		setL3_smsNumber(incident.getL3_smsNumber());		
		setCmdtoexe(incident.getCmdToExe());
	}
	
	public void loadDateResult(Object[] model) {
		setCfgId(((Integer) model[0]).toString());
		setDescription((String) model[1]);
		setProduct((String) model[2]);
		setNodeId((String) model[3]);
		setCmd((String) model[4]);
		setSubCmd((String) model[5]);
		setCondition((String) model[6]);
		setPriority((String) model[7]);
		setAlertType((String) model[8]);
  	 	setStartDate(model[9]);
  	 	setEndDate(model[10]);
		setMessage((String) model[11]);
		setSmsNumber((String) model[12]);
		setEmailId((String) model[13]);
		setType((String) model[14]);
		setL2_EmailId((String) model[15]);
		setL2_smsNumber((String) model[16]);
		setL3_EmailId((String) model[17]);
		setL3_smsNumber((String) model[18]);
		
	}

	public void store(Incident model) throws ParseException{
		model.setCfgId(Integer.parseInt(cfgId));
		model.setDescription(description);
		model.setProduct(product);
		model.setNodeId(nodeId);
		model.setCmd(cmd);
		model.setSubCmd(subcmd);
		model.setCondition(condition);
		boolean isValidFormatStartDate =false;
		boolean isValidFormatEndDate =false;
		
		if(StringUtil.isNotEmpty(startDate)) {
			isValidFormatStartDate = PaymonUtils.isValidDate(startDate);
		} 
		
		if(StringUtil.isNotEmpty(endDate)) {
			isValidFormatEndDate = PaymonUtils.isValidDate(endDate);
		}
		
		Date dateStart = null;
		Date dateEnd = null;
		if (isValidFormatStartDate && startDate != null) {
			dateStart=new SimpleDateFormat(PaymonUtils.InputDateFormat).parse(startDate);
			model.setStartDate(dateStart);
		} else if("".equalsIgnoreCase(startDate))  {
			model.setStartDate(null);
		}
		
		if (isValidFormatEndDate && endDate != null) {
			dateEnd=new SimpleDateFormat(PaymonUtils.InputDateFormat).parse(endDate);
			model.setEndDate(dateEnd);
		} else if("".equalsIgnoreCase(endDate))  {
			model.setEndDate(null);
		} 
				
		model.setPriority(priority);
		model.setAlertType(alertType);
		model.setMessage(message);
		model.setSmsNumber(smsNumber);
		model.setEmailId(emailId);		
		model.setType(type);
		model.setL2_EmailId(l2_EmailId);
		model.setL2_smsNumber(l2_smsNumber);
		model.setL3_EmailId(l3_EmailId);
		model.setL3_smsNumber(l3_smsNumber);
		model.setCmdToExe(cmdtoexe);
	}
	
	public IncidentListSPRow getOrignalRow() {
		return orignalRow;
	}

	public void setOrignalRow(IncidentListSPRow orignalRow){
		try{
			if(orignalRow != null)
				this.orignalRow = (IncidentListSPRow) orignalRow.clone();
		}catch (Exception e){
			log.error(e);
		}
	}	

	@Override
	public String getFormKey() {
		return "cfgId";
	}
	
	
	public String getCfgId() {
		return this.cfgId;
	}

	public void setCfgId(String cfgId) {
		this.cfgId = cfgId;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getProduct() {
		return this.product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getNodeId() {
		return this.nodeId;
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	
	public String getCmd() {
		return this.cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}
	
	public String getSubCmd() {
		return this.subcmd;
	}

	public void setSubCmd(String subcmd) {
		this.subcmd = subcmd;
	}
	
	public String getCondition() {
		return this.condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}
	
	public String getPriority() {
		return this.priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	public String getAlertType() {
		return this.alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	
	public String getStartDate() {
		return this.startDate;
	}
	
	public void setStartDate(Object startDate) {
		this.startDate = PaymonUtils.getFormattedResponseDate(startDate);
	}
	
	public String getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Object endDate) {
		this.endDate = PaymonUtils.getFormattedResponseDate(endDate);
	}
	
	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getSmsNumber() {
		return this.smsNumber;
	}

	public void setSmsNumber(String smsNumber) {
		this.smsNumber = smsNumber;
	}
	
	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getL2_EmailId() {
		return l2_EmailId;
	}

	public void setL2_EmailId(String l2_EmailId) {
		this.l2_EmailId = l2_EmailId;
	}

	public String getL2_smsNumber() {
		return l2_smsNumber;
	}

	public void setL2_smsNumber(String l2_smsNumber) {
		this.l2_smsNumber = l2_smsNumber;
	}

	public String getL3_EmailId() {
		return l3_EmailId;
	}

	public void setL3_EmailId(String l3_EmailId) {
		this.l3_EmailId = l3_EmailId;
	}

	public String getL3_smsNumber() {
		return l3_smsNumber;
	}

	public void setL3_smsNumber(String l3_smsNumber) {
		this.l3_smsNumber = l3_smsNumber;
	}

	public String getStartDateAsString() {
		return startDateAsString;
	}

	public void setStartDateAsString(String startDateAsString) {
		this.startDateAsString = startDateAsString;
	}
	
	public String getEndDateAsString() {
		return endDateAsString;
	}

	public void setEndDateAsString(String endDateAsString) {
		this.endDateAsString = endDateAsString;
	}

	public String getCmdtoexe() {
		return cmdtoexe;
	}

	public void setCmdtoexe(String cmdtoexe) {
		this.cmdtoexe = cmdtoexe;
	}
	
}
