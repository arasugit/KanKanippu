package com.fis.ist.customProject.services.handler;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.ForeignKeysCheckException;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MKCHandler;
import com.fis.ist.common.dao.MkcQueue;
import com.fis.ist.customProject.dao.IncidentActionDAO;
import com.fis.ist.customProject.domain.IncidentAction;
import com.fis.ist.customProject.dto.IncidentActionRow;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.MenuService;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.EditableListRow;
import com.fis.ist.services.vo.WorkRequest;

public class IncidentActionHandler extends ISTRequestHandler {

	private static final ISTLogger log = ISTLogger.getLogger(IncidentActionHandler.class);
	private static String reqTypeId = CustomConstants.INCACTION;
	private static String formAuthId = "INCACTION";

	public IncidentActionHandler(){
		checkMKCEnabled(formAuthId);
	}
	/**
	 * Create a 'logical' work request for storing the Device Detail
	 * information. This work request will never be persisted to the database
	 *
	 * @param WorkRequest
	 * @param UserContext
	 * @param UIMetaData
	 * @param WorkRequestHandlerData
	 * @param params
	 * @return WorkRequest
	 */
	
	private IncidentActionRow getNewINCACTIONRowInstance() {
		IncidentActionRow dto = new IncidentActionRow();
		dto.setDbAction('a');
		return dto;
	}

	/**
	 * Get device detail information from CED and Rules Engine reverse
	 * engineering. Populate into a 'pseudo' WorkRequest object for returning
	 * back to the caller.
	 *
	 * @param UserContext
	 * @param String
	 *            (deviceId)
	 * @return WorkRequest
	 */
	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
			throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(
						WorkRequestHandlerData.RequestMode.ADD_NEW,
						workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null
					|| workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag =validateQueryFields(params,workRequest);
			if (errFlag)
			{
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
	
			}
		} catch (Exception ex) {
			throw ex;
		} 
		return workRequest;
	}
	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(
						WorkRequestHandlerData.RequestMode.ADD_NEW,
						workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null
					|| workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			// Create a logical collection for add
			List<IncidentActionRow> workRows = getNewWorkINCACTIONRows(workRequest, uiMetaData);
			workRows.add(getNewINCACTIONRowInstance());
		} catch (Exception ex) {
			throw ex;
		} 
		return workRequest;
	}

	
	public WorkRequest getDataForAdd(UserContext userContext,
			WorkRequest workRequest) throws Exception {
		if (workRequest != null) {
			WorkCollection wc = workRequest.getCollections().get(CustomConstants.INCACTIONCOL);
			wc.getRows().add(0, getNewINCACTIONRowInstance());
			return workRequest;
		} else {
			WorkRequest workReq = new WorkRequest();
			UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.INCACTION);
			try {

				workReq.setRequestId("0");
				workReq.setRequestState("DRAFT");
				workReq.setRequestTypeId(CustomConstants.INCACTION);

				Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
				workReq.setNextStates(nextStates);

				// Set values of all tabs to be modifiable
				Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
				WorkTabStatus workStatus = new WorkTabStatus();
				workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
				workStatus.setTag(CustomConstants.INCACTIONTAB);
				workStatus.setModifyable("Y");
				tabStatus.put(CustomConstants.INCACTIONTAB, workStatus);

				workReq.setTabStatus(tabStatus);

				addWorkFields(workReq, uiMetaData);

				workReq = addNewWorkRequest(workReq, userContext, uiMetaData,
						null);

				// TODO Determine field level security for each WorkField
				// Enable all the fields for the time being
				Map<String, WorkField> fields = workReq.getFields();
				Collection<WorkField> cfields = fields.values();
				for (WorkField field : cfields) {
					field.setModifyable("Y");
					field.setVisible("Y");
				}
			} catch (Exception ex) {
		      	  WorkRequestHelper.getInstance().reportException(log, ex, workReq);
			}
			return workReq;
		}
	}
	
	public WorkRequest getINCACTION(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}
	
	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params ) throws Exception{
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.INCACTION);


		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(CustomConstants.INCACTION);

			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);

			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(CustomConstants.INCACTIONTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(CustomConstants.INCACTIONTAB, workStatus);

			workReq.setTabStatus(tabStatus);

			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("cfgId".equals(field.getTag())) {
					String value = (String) params.get("cfgId");
					field.setValue(value);
				}
				if ("incId".equals(field.getTag())) {
					String value = (String) params.get("incId");
					field.setValue(value);
				}
				if ("incDate".equals(field.getTag())) {
					String value = (String) params.get("incDate");
					field.setValue(value);
				}
				
				if ("status".equals(field.getTag())) {
					String value = (String) params.get("status");
					field.setValue(value);
				}
				
				if ("smsStatus".equals(field.getTag())) {
					String value = (String) params.get("smsStatus");
					field.setValue(value);
				}
				
				if ("emailStatus".equals(field.getTag())) {
					String value = (String) params.get("emailStatus");
					field.setValue(value);
				}
				
				
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public WorkRequest mkcSubmittedList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext,params);
		isCheckerRequest(formAuthId, AppConstants.MKC_ACTION_PENDING_REQ);
		if(workReq!=null && workReq.getRequestResult().equals(ResponseBase.REQUEST_RESULT_SUCCESS)){
			workReq = loadFromMKC(workReq, params,"submit");
		}
		return workReq;
	}
	
	public WorkRequest mkcReworkList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext,params);
		if(workReq!=null && workReq.getRequestResult().equals(ResponseBase.REQUEST_RESULT_SUCCESS)){
			workReq = loadFromMKC(workReq, params,"rework");
		}
		return workReq;
	}

	public WorkRequest loadFromMKC(WorkRequest workRequest,Map<String, String> params,String query)
	{
		if (query == null || query.trim().equals("") || (!query.equalsIgnoreCase("rework") && !query.equalsIgnoreCase("submit"))) {
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail("Invalid query options passed");
			return workRequest;
		}
		try {
			List<MkcQueue> mkcrecords = getAllPendingMKCRequest(reqTypeId,query);
			UIMetaData uiMetaData=null;

			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);

			List<IncidentActionRow> workEmps =getNewWorkINCACTIONRows(workRequest ,uiMetaData);

			for (MkcQueue mkcrec : mkcrecords) {
				try {
					ByteArrayInputStream baip = new ByteArrayInputStream(mkcrec.getRecordObj());
					ObjectInputStream ois = new ObjectInputStream(baip);
					IncidentActionRow listObj = (IncidentActionRow) ois.readObject();
					if (listObj !=null) {
						listObj.setMkcId(mkcrec.getMkcId());
						listObj.setMkcRecordAction(mkcrec.getAction());
						listObj.setMkcStatus(mkcrec.getStatus());
						listObj.setMkcRemarks(mkcrec.getRemarks());
						listObj.setMakerId(mkcrec.getMakerId());
						listObj.setInactive("");
						listObj.setErrorFlag(false);
						listObj.setErrorMessage("");
						workEmps.add(listObj);
					}
				}catch (Exception e) {
					log.error("Unable to load records from Queue");
					WorkRequestHelper.getInstance().reportException(log, e, workRequest);
				}
			}

			// check if the submitted request from checker and merge the data from the database
			if (isCheckerAction && isMKCEnabled) {
				IncidentActionDAO dao = new IncidentActionDAO();

				IncidentAction dbRecord ;
				IncidentActionRow mkcOrignalRecord;

				for (IncidentActionRow mkcRecord : workEmps)
				{
					if (mkcRecord.getDbAction().equals('c') && !mkcRecord.getMakerId().equals(getUserID())) {
						dbRecord = dao.findById(mkcRecord.getCfgId());
						if (dbRecord != null) {
							// which are information same between the mkc record and the original record, overwrite that field value from the latest db record
							// Unchanged information between the mkc record and the orignal record should be overwritten from the latest db record
							mkcOrignalRecord = mkcRecord.getOrignalRow();
					
						}
					}
				}
			}
			if (mkcrecords.size()>0)
				workRequest.setLastModified(new Long(mkcrecords.size()));
		}catch (Exception e){
			log.error("unable to load the mkc data");
			WorkRequestHelper.getInstance().reportException(log, e, workRequest);
		}
		return workRequest;
	}

	public Boolean isCellDataChanged(Date first, Date second) {
		 if(first == null && second == null)
			 return false;

		 if(first != null && second != null)
			 return !(first.compareTo(second) == 0);
		 
		 if (first == null && second != null)
			 return true;

		 if (first != null && second == null)
			 return true;
		 
		 return false;
	}
	
	public Boolean isCellDataChanged(Double first, Double second) {
		 if(first == null && second == null)
			 return false;

		 if(first != null && second != null)
			 return !(first.compareTo(second) == 0);
		 
		 if (first == null && second != null)
			 return true;

		 if (first != null && second == null)
			 return true;
		 
		 return false;
	}

	public Boolean isCellDataChanged(Integer first, Integer second) {
		 if(first == null && second == null)
			 return false;

		 if(first != null && second != null)
			 return !(first.compareTo(second) == 0);
		 
		 if (first == null && second != null)
			 return true;

		 if (first != null && second == null)
			 return true;
		 
		 return false;
	}

	/**
	 * Initialize the Work Request to include all the fields that are part of
	 * all the tabs on a Device Detail lookup
	 *
	 * @param WorkRequest
	 * @param UIMetaData
	 */
	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData)
			throws Exception {
		addWorkFields(workReq, uiMetaData, CustomConstants.INCACTIONTAB);
	}

	/**
	 * Retrieve the institutions for a Work Request from the institution table
	 * and load into a WorkCollection in the WorkRequest
	 *
	 * @param WorkRequest
	 * @param UIMetaData
	 */
	public void load(WorkRequest workRequest, Map<String, String> params) throws ParseException {
		log.debug("Load INCACTION Definition");
		
		// needs_total variable is used to indicate whether the total count
		// should be fetched and sent to the client. First time,it will be set
		// to get the record count.
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		// ist_page_ctrl will contain the page number and according the records
		// will be fetched based on the pagesize and sent to the client.
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;


		IncidentAction findRecord = new IncidentAction();
		String cfgId = params.get("cfgId") != null ? params.get("cfgId") : "";
		String incId = params.get("incId") != null ? params.get("incId") : "";
		String incDateFromFormat = "";
		String incDateToFormat = "";
		String incDateTodayFormat = "";
		String incDateStartOfYearFormat = "";
		List dateResults = null;
		String configDesc = params.get("configDesc") != null ? params.get("configDesc") : "";
		String product = params.get("product") != null ? params.get("product") : "";
		String nodeId = params.get("nodeId") != null ? params.get("nodeId") : "*";
		log.debug("Site-NodeID Info : " + "nodeId = " + nodeId + " productId = " + product );
		
		 if (!StringUtils.isBlank(params.get("incDateFrom")) || !StringUtils.isBlank(params.get("incDateTo"))) {
	        SimpleDateFormat sdf=new SimpleDateFormat(PaymonUtils.InputDateFormat);
			Date todaysdate = Calendar.getInstance().getTime();	
			Calendar c = Calendar.getInstance(); 
		    c.set(Calendar.DAY_OF_YEAR, 1);
		    Date newYearStartDate = c.getTime();
		    Date currentdateFrom = null;
	        Date currentdateTo = null;
	        
			try {
				if (!StringUtils.isBlank(params.get("incDateFrom")))
					currentdateFrom = params.get("incDateFrom") == "" ? null : sdf.parse(params.get("incDateFrom"));
				if (!StringUtils.isBlank(params.get("incDateTo")))
					currentdateTo = params.get("incDateTo") == "" ? null : sdf.parse(params.get("incDateTo"));
			} catch (ParseException e2) {
				// TODO Auto-generated catch block
				log.error(e2);
			}
	        SimpleDateFormat sdf2=new SimpleDateFormat("dd-MMM-yyyy");
	        incDateFromFormat = currentdateFrom == null ? "" : sdf2.format(currentdateFrom);
	        incDateToFormat = currentdateTo == null ? "" : sdf2.format(currentdateTo);
	        incDateTodayFormat = sdf2.format(todaysdate);
	        incDateStartOfYearFormat = sdf2.format(newYearStartDate);


		 }
		 
		String status = params.get("status");
		String smsStatus = params.get("smsStatus");
		String emailStatus = params.get("emailStatus");
				

		// to get the results.
		// results will hold the result set fetched from the database
		// if needs_total is set, the record the record count and set it to the
		// lastModified property of the workRequest.

		List<IncidentAction> results = new ArrayList<IncidentAction>();

					
		if(StringUtil.isNotEmpty(cfgId)) {
			//findRecord.setCfgId(Integer.parseInt(cfgId));
			int searchTermcfgId;
			if (cfgId.startsWith("*") && cfgId.endsWith("*")) { 
				searchTermcfgId = Integer.parseInt(cfgId.substring(1, cfgId.length() - 1));
			}
			else if (cfgId.startsWith("*")) {
				searchTermcfgId = Integer.parseInt(cfgId.substring(1));
			} else if (cfgId.endsWith("*")) {
				searchTermcfgId = Integer.parseInt(cfgId.substring(0, cfgId.length() - 1));
			}
			else {
				searchTermcfgId = Integer.parseInt(cfgId);
			}
			findRecord.setCfgId(searchTermcfgId);
		}
		
		if(StringUtil.isNotEmpty(incId)) {
			//findRecord.setIncId(Integer.parseInt(incId));
			int searchTermincId;
			if (incId.startsWith("*") && incId.endsWith("*")) { 
				searchTermincId = Integer.parseInt(incId.substring(1, incId.length() - 1));
			}
			else if (incId.startsWith("*")) {
				searchTermincId = Integer.parseInt(incId.substring(1));
			} else if (incId.endsWith("*")) {
				searchTermincId = Integer.parseInt(incId.substring(0, incId.length() - 1));
			}
			else {
				searchTermincId = Integer.parseInt(incId);
			}
			findRecord.setIncId(searchTermincId);
		}
		
		if(StringUtil.isNotEmpty(status)) {
			findRecord.setStatus(status);
		}
		
		if(StringUtil.isNotEmpty(smsStatus)) {
			findRecord.setSmsStatus(smsStatus);
		}
		
		if(StringUtil.isNotEmpty(emailStatus)) {
			findRecord.setEmailStatus(emailStatus);
		}
		
		if(StringUtil.isNotEmpty(emailStatus)) {
			findRecord.setEmailStatus(emailStatus);
		}		
		
		List<IncidentActionRow> tempConfigIncActRowList = new ArrayList<IncidentActionRow>();

		if (!needs_total) {
			dateResults = loadIncidentActionData(findRecord, pageNum, product, nodeId, incDateFromFormat, incDateToFormat, incDateTodayFormat, incDateStartOfYearFormat, configDesc, cfgId, incId);
		} else if (needs_total) {
			total = loadIncidentActionDataCount(findRecord, pageNum, product, nodeId, incDateFromFormat, incDateToFormat, incDateTodayFormat, incDateStartOfYearFormat, configDesc, cfgId, incId);
			dateResults = loadIncidentActionData(findRecord, pageNum, product, nodeId, incDateFromFormat, incDateToFormat, incDateTodayFormat, incDateStartOfYearFormat, configDesc, cfgId, incId);
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData=null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		}
		catch (Exception e){
			log.error("unable to get the Meta data"+e.getMessage());
		}

		List<IncidentActionRow> workRows = getNewWorkINCACTIONRows(workRequest, uiMetaData);
		if (params.get("incDateFrom") == "" && params.get("incDateTo") == "") {
			if(params.get("configDesc") == "") {
			} else {
				if (dateResults == null || dateResults.size() == 0) {
					return;
				}
			}
		} else {

			if (dateResults == null || dateResults.size() == 0) {
				return;
			}
		}

		IncidentActionRow dto2 = null;
		Object[] result2 = null;
		//if(params.get("incDateFrom") != "" || params.get("incDateTo") != "" || params.get("configDesc") != "") {
			for (int i = 0; i < dateResults.size(); i++)  {			
				dto2 = new IncidentActionRow();
					result2 = (Object[]) dateResults.get(i);
					if(params.get("configDesc") == "") {
						tempConfigIncActRowList = new ArrayList<IncidentActionRow>();
					}
					dto2.loadDateResult(result2, tempConfigIncActRowList); 
					dto2.setDbAction('x');
					if (isMKCEnabled){
						dto2.setOrignalRow(dto2);
					}
					workRows.add(dto2);	
			}
		//} 

		
		if(params.get("incDateFrom") == "" && params.get("incDateTo") == "") {
			for (IncidentAction incident: results) {
				if(incident != null){
					IncidentActionRow dto = new IncidentActionRow();
					dto2.loadDateResult(result2, tempConfigIncActRowList); 
					dto.setDbAction('x');
					if (isMKCEnabled){
						dto.setOrignalRow(dto);
					}
					workRows.add(dto);
				}
			}
		}
		
	}

	private List<IncidentActionRow> getNewWorkINCACTIONRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(CustomConstants.INCACTIONCOL);
		workCollection.setSectionId(CustomConstants.INCACTIONSECTION);
        workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(CustomConstants.INCACTIONTAB);

		workRequest.getCollections().put(workCollection.getTag(),
				workCollection);

		List<IncidentActionRow> workRows = new ArrayList<IncidentActionRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, CustomConstants.INCACTIONCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	

	public WorkRequest saveSinglePageRecords(UserContext userContext, WorkRequest workRequest,HashMap<String,Boolean> permMap) {
		try {
			workRequest = saveWorkRequest(userContext,workRequest,permMap);
		}catch (Exception e){
			log.error("Exception occured in the Save Single Pags Records"+e.getMessage());
		}
		return workRequest;
	}

	public WorkRequest saveWorkRequest(UserContext userContext,
			WorkRequest workRequest,HashMap<String, Boolean> permMap) throws Exception{
		if (validateCollectionField(workRequest,CustomConstants.INCACTIONCOL))
			return workRequest;

		save(userContext, workRequest,permMap);
		return workRequest;
	}

	private void save(UserContext userContext, WorkRequest workRequest, HashMap<String, Boolean> permMap) {
		// check if contact field data is present
		try{
			Map<String, WorkField> fields = workRequest.getFields();
			if (fields == null) {
				WorkRequestHelper.getInstance().reportError("Work fields not found", workRequest);
				return;
			}

			boolean isInvalidData = false;
			String value = null;
			List<IncidentActionRow> corrCollection = new ArrayList<IncidentActionRow>();
			List<String> duplicateCollection = new ArrayList<String>();
			IncidentActionDAO dao = new IncidentActionDAO();
			WorkCollection wc = workRequest.getCollections().get(CustomConstants.INCACTIONCOL);
			List<IncidentActionRow> rows = wc.getRows();

			//Only the affected rows will be available here.

			for(int i = 0; i < rows.size();i++){
				IncidentActionRow row = rows.get(i);
				row.setErrorFlag(false);
				String flag = row.getDbAction().toString();
				if(flag.equals("a")  &&!(permMap.get("I") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for adding a record");
					isInvalidData = true;
				}else if(flag.equals("c") && !(permMap.get("U") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for updating a record");
					isInvalidData = true;
				}else if(flag.equals("d") && !(permMap.get("D") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for deleting a record");
					isInvalidData = true;
				}

				IncidentActionRow model = new IncidentActionRow();

				Object object = row.getCfgId();
				if(object == null){
					row.setErrorFlag(true);
					row.setErrorMessage("CFG ID cannot be empty");
					isInvalidData = true;
					continue;
				}
				model.setCfgId(row.getCfgId());
				String key = ""+model.getCfgId();


				if (isMKCEnabled && isCheckerAction){
					if(duplicateCollection.contains(key+row.getMkcStatus()) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())){
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same same CFG ID");
						isInvalidData = true;
						continue;
					}else{
						duplicateCollection.add(key+row.getMkcStatus());
					}
				}else{
					if(!flag.equals("d")){
						if(duplicateCollection.contains(key)){
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same CFG ID");
							isInvalidData = true;
							continue;
						}else{
							duplicateCollection.add(key);
						}
					}
				}

				if (isMKCEnabled && isCheckerAction){
					if("a".equals(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus()) && dao.findById(model.getCfgId()) != null){
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same same CFG ID");
						isInvalidData = true;
						continue;
					}
				}else{
					if(flag.equals("a")){
						if(dao.findById(model.getCfgId()) != null){
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same CFG ID");
							isInvalidData = true;
							continue;
						}
					}
				}

				if (isMKCEnabled && isCheckerAction && AppConstants.MKC_SP_ACTION_REWORK.equals(row.getMkcStatus()) && "d".equalsIgnoreCase(flag)){
					row.setErrorFlag(true);
					row.setErrorMessage("Deleted record cannot be set to rework");
					isInvalidData = true;
					continue;
				}

				if(isMKCEnabled && isCheckerAction && "d".equalsIgnoreCase(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())){
					IncidentAction incident = dao.findById(model.getCfgId());
					if (incident == null) {
						row.setErrorFlag(true);
						row.setErrorMessage("The record is already deleted. Please reject the record.");
						isInvalidData = true;
						continue;
					}
					dao.getSession().evict(incident);
				}
				corrCollection.add(row);
			}
			
			if(isInvalidData){
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0106");
				return;
			}
			
			if(isMKCEnabled && !isCheckerAction){ // maker changes should go into the queue
				for (EditableListRow edlsrow : corrCollection) {
					if (edlsrow!=null){
						IncidentActionRow dto = (IncidentActionRow)edlsrow;
						MKCHandler.getInstance().insertListRowIntoMKC(dto, dto.getCfgId().toString(), workRequest.getRequestTypeId(), getUserId(userContext), MenuService.getModuleName(reqTypeId));
					}
				}
			}else{
				for(IncidentActionRow dto:corrCollection)
				{
					String action = dto.getDbAction().toString();
					if(!isMKCEnabled){ // non mkc
						if("c".equalsIgnoreCase(action))
						{
							IncidentAction incident = dao.findById(dto.getIncId());
							if(incident != null){
								dto.store(incident);
								dao.attachDirty(incident);
							}
						}else if("a".equalsIgnoreCase(action)){
							IncidentAction incident = new IncidentAction();
							IncidentActionDAO daoInc= new IncidentActionDAO();
							dto.store(incident);
							dao.save(incident);
							daoInc.save(incident);
						}else if("d".equalsIgnoreCase(action)){
							IncidentAction incident = new IncidentAction();
							dto.store(incident);
							dao.delete(incident);
						}
					}else if (isMKCEnabled && isCheckerAction){ // MKC Checker
						String status = dto.getMkcStatus();
						if((AppConstants.MKC_SP_ACTION_APPROVE).equals(status)){
							if ("c".equalsIgnoreCase(action)) {
								IncidentAction incident = dao.findById(dto.getCfgId());
								if(incident != null){
									dto.store(incident);
									dao.attachDirty(incident);
									dao.save(incident);									
								}
							} else if ("a".equalsIgnoreCase(action)) {
								IncidentAction incident = new IncidentAction();
								dto.store(incident);
								dao.save(incident);
							} else if ("d".equalsIgnoreCase(action)) {
								IncidentAction incident = new IncidentAction();
								dto.store(incident);
								dao.delete(incident);
							}
							MKCHandler.getInstance().ApproveMKCRecord(dto.getMkcId(),getUserId(userContext),dto.getMkcRemarks(),dto.getMkcScheduleDt());
						}else if(AppConstants.MKC_SP_ACTION_REJECT.equals(status) || AppConstants.MKC_SP_ACTION_REWORK.equals(status)){
							MKCHandler.getInstance().RejectOrReturnRecord(dto.getMkcId(),getUserId(userContext),dto.getMkcRemarks(),dto.getMkcScheduleDt(),status);
						}else{
						}
					}
				}
			}
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_NONE);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_SUCCESS);
			workRequest.setErrorDetail("");
			rows.clear();
		}catch (Exception e){
		   workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
           workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
           workRequest.setErrorDetail(e.getMessage());
   		   if(e instanceof ForeignKeysCheckException){
			   workRequest.setMessageSubstitutions(((ForeignKeysCheckException)e).getChildTables());				  
		   }
		}
	}

	private List<IncidentAction> loadIncidentActionData(IncidentAction model, int pageNum, String product, String nodeId, 
			String incDateFromFormat, String incDateToFormat, String incDateTodayFormat, String incDateStartOfYearFormat, String configDesc, String cfgId, String incId) {
		log.debug("Load Incident records - loadIncidentActionData()");
		IncidentActionDAO dao = new IncidentActionDAO();
		List<IncidentAction> results = dao.findByExample(model, pageNum, product, nodeId, 
										incDateFromFormat, incDateToFormat, incDateTodayFormat, incDateStartOfYearFormat, configDesc, cfgId, incId);
		return results;
	}

	private int loadIncidentActionDataCount(IncidentAction model, Integer pageNum, String product, String nodeId, 
			String incDateFromFormat, String incDateToFormat, String incDateTodayFormat, String incDateStartOfYearFormat, String configDesc, String cfgId, String incId) {
		log.debug("Load Incident records - loadIncidentActionDataCount()");
		IncidentActionDAO dao = new IncidentActionDAO();
		int count = dao.getTotalByExample(model, pageNum, product, nodeId, 
						incDateFromFormat, incDateToFormat, incDateTodayFormat, incDateStartOfYearFormat, configDesc, cfgId, incId);
		return count;
	}
	
	public HashMap<String,String> getDBMapping()
	{
		HashMap<String,String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("cfgId","cfgId");
		dtoMapping.put("description","description");
		dtoMapping.put("product","product");
		dtoMapping.put("nodeId","nodeId");
		dtoMapping.put("cmd","cmd");
		dtoMapping.put("subCmd","subCmd");
		dtoMapping.put("condition","condition");
		dtoMapping.put("priority","priority");
		dtoMapping.put("alertType","alertType");
		dtoMapping.put("startDate","startDate");
		dtoMapping.put("endDate","endDate");
		dtoMapping.put("message","message");
		dtoMapping.put("smsNumber","smsNumber");
		dtoMapping.put("emailId","emailId");
		return dtoMapping;
	}

	private Boolean validateQueryFields(Map<String, String> params,WorkRequest workReq) throws Exception{
		Map <WorkField,String> fieldDataMap = new HashMap<WorkField, String>();
		return validateFields(fieldDataMap);
	}
}