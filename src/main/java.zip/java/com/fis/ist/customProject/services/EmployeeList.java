package com.fis.ist.customProject.services;

import java.util.Map;

import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.services.SimpleListSubservice;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.customProject.services.handler.EmployeeListQueryHandler;

public class EmployeeList extends SimpleListSubservice {
	protected boolean doCache() {
		return true;
	}

	@Override
	protected ISimpleListHandler getListHandler() {
		return new EmployeeListQueryHandler();
	}

	@Override
	protected String getName() {
		return "EmployeeList";
	}

	 @Override
	 public WorkRequest getService
	 (
	             UserContext userContext,
	             String requestType,
	             String action,
	             Map<String, String>requestParams
	       ) throws Exception
	 {
	       WorkRequest workReq = super.getService(userContext, requestType, action, requestParams);
	       new FormAuditHandler().saveFormAudit(userContext, "EMPLIST", action, workReq, CustomConstants.SWITCH_SUBSYSTEM);
	       return workReq;
	 }
}



