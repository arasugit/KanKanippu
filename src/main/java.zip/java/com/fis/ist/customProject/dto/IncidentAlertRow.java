package com.fis.ist.customProject.dto;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.TimeZone;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fis.ist.customProject.domain.Employee;
import com.fis.ist.customProject.domain.Incident;
import com.fis.ist.customProject.domain.IncidentAlert;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class IncidentAlertRow  extends EditableListRowForSDK implements Cloneable{
	private static final ISTLogger log = ISTLogger.getLogger(IncidentAlertRow.class);
	private String incDateAsString;
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	
	private IncidentAlertRow orignalRow;
	
	
	private Integer cfgId;
	private Integer incId;
	private String upddate;
	private String comments;
	private String escType;
	private Integer age;
	
	public void load(IncidentAlert incidentAlert)
	{
		setCfgId(incidentAlert.getCfgId());
		setIncId(incidentAlert.getIncId());
  	 	setUpdDatee(incidentAlert.getUpddate());
		setComments(incidentAlert.getComments());
	}
	
	public void loadDateResult(Object[] model) {
		setCfgId((Integer) model[0]);
		setIncId((Integer) model[1]);
  	 	setUpdDatee(model[2]);
		setComments((String) model[3]);
	}


	public void store(IncidentAlert model){
		model.setCfgId(cfgId);
		model.setIncId(incId);
		model.setComments(comments);			
	}

	public IncidentAlertRow getOrignalRow() {
		return orignalRow;
	}

	public void setOrignalRow(IncidentAlertRow orignalRow){
		try{
			if(orignalRow != null)
				this.orignalRow = (IncidentAlertRow) orignalRow.clone();
		}catch (Exception e){
			log.error(e);
		}
	}

	

	@Override
	public String getFormKey() {
		return "cfgId";
	}
	
	
	@Id
	@Column(name = "CFGID",unique = true, nullable = false, precision = 6, scale = 0)
	public Integer getCfgId() {
		return this.cfgId;
	}

	public void setCfgId(Integer cfgId) {
		this.cfgId = cfgId;
	}
	
	@Id
	@Column(name = "INCID",unique = true, nullable = false, precision = 6, scale = 0)
	public Integer getIncId() {
		return this.incId;
	}

	public void setIncId(Integer incId) {
		this.incId = incId;
	}
	
	public String getUpddate() {
		return this.upddate;
	}
	
	public void setUpdDatee(Object updatedDate) {
		this.upddate = PaymonUtils.getFormattedResponseDate(updatedDate);
	}
	
	@Column(name = "COMMENTS", length = 20)
	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getEscType() {
		return escType;
	}

	public void setEscType(String escType) {
		this.escType = escType;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
}
