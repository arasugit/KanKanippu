package com.fis.ist.customProject.services;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.audit.FormAudit;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.customProject.services.handler.IncidentActionHandler;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

public class IncidentActionService extends CRUDSubService
{
    private static final ISTLogger log = ISTLogger.getLogger(IncidentActionService.class);
   	public WorkRequest getService
		(
			UserContext userContext,
			String requestType,
			String action,
		   	Map<String, String>requestParams
		) throws Exception
	{
		WorkRequest workReq = null;
		IncidentActionHandler ddh = new IncidentActionHandler();
		
   		HttpServletRequest request = HTTPRequestGetter.getRequest();
	 	String productId = (String) request.getSession(false).getAttribute("product_id");
	 	//If node name contains all manipulate the string... () & put IN clause in the DAO
	 	String nodeName = (String) request.getSession(false).getAttribute("node_name");
	 	if(nodeName != null && nodeName.contains("All Nodes")) {
	 		int startParentheses = nodeName.indexOf("(");
	 		int endParentheses = nodeName.indexOf(")");
	 		
	 		if(startParentheses != -1 && endParentheses != -1 && endParentheses > startParentheses) {
	 			String allNodeNames = nodeName.substring(startParentheses + 1, endParentheses);
	 			allNodeNames = allNodeNames.trim();
	 			
	 			// Split the multiple values..
	 			String[] extractedNodes = allNodeNames.split(",\\s*");
	 			
	 			//Join back with single quotes''
	 			allNodeNames = "'" + String.join("', '", extractedNodes) + "'";
	 			
	 			requestParams.put("nodeId", nodeName == null ? "*" : allNodeNames);
	 		}
	 	}
	 	else {
	 		nodeName = "'" + nodeName + "'";
	 		requestParams.put("nodeId", nodeName == null ? "*" : nodeName);
	 	}
   		requestParams.put("product", productId == null ? "" : productId);
   		
		if(action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = ddh.getINCACTION(userContext, requestParams);
		}  else if (AppConstants.MKC_ACTION_PENDING_REQ.equals(action)){
   			workReq = ddh.mkcSubmittedList(userContext, requestParams);
   		}else if ( AppConstants.MKC_ACTION_REWORK_REQ.equals(action)){
   			workReq = ddh.mkcReworkList(userContext, requestParams); 
   		}else {
			log.error("**** Employee single page (EMPLISTSP) List: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		 }
		if(Boolean.parseBoolean(ConfigParams.getInstance().getProperty("ist.paymon.audit.log"))){
			new FormAuditHandler().saveFormAudit(userContext,requestType,action,workReq,CustomConstants.SWITCH_SUBSYSTEM);
	        WorkRequestCacher.getInstance().put(userContext,workReq);
		}
		return workReq;
	}
   	public WorkRequest setService
		(
			UserContext userContext,
			String requestType,
			String action,
		   	WorkRequest workRequest
		) throws Exception
	{
		FormAuditHandler ah = new FormAuditHandler();
		FormAudit handle = ah.beginEditableListAudit(userContext, requestType, action, workRequest,CustomConstants.SWITCH_SUBSYSTEM);
   		WorkRequest workReq = new WorkRequest();
   		IncidentActionHandler ddh = new IncidentActionHandler();
   		if(action.compareTo(CustomConstants.ACTION_INSERT) == 0){
   			workReq = ddh.getDataForAdd(userContext,workRequest); 
   		}else if(action.compareTo(CustomConstants.ACTION_SINGLE_BATCH_SAVE) == 0){   				
   			workReq = ddh.saveWorkRequest(userContext,workRequest,setPermissions());
   		}else if(action.compareTo(AppConstants.MKC_ACTION_BATCH_SAVE) == 0){   				
   			workReq = ddh.saveBatchByChecker(userContext,workRequest,setPermissions());
   		}else{
   			log.error("**** Employee single page (EMPLISTSP) List: setService() inbound...unknown request type");
   			throw new Exception("Unknown request type");
   		}
        ah.saveEditableListAudit(handle, workReq);
   		return workReq;
	}
}
