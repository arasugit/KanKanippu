package com.fis.ist.customProject.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.customProject.services.handler.DebugMonitoringHandler;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class DebugMonitoringService extends CRUDSubService {
	private static final ISTLogger log = ISTLogger.getLogger(DebugMonitoringService.class);

	public WorkRequest getService(UserContext userContext, String requestType, String action,
			Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		DebugMonitoringHandler ddh = new DebugMonitoringHandler();
		
		if (action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
				workReq = ddh.getDebugMonitorData(userContext, requestParams);
				
		}else {
			log.error("**** Application Monitoring Debug Monitoring single page List: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		}
		if(Boolean.parseBoolean(ConfigParams.getInstance().getProperty("ist.paymon.audit.log"))){
			new FormAuditHandler().saveFormAudit(userContext, requestType, action, workReq,
					CustomConstants.SWITCH_SUBSYSTEM);
			WorkRequestCacher.getInstance().put(userContext, workReq);
		}
		return workReq;
	}
}