package com.fis.ist.customProject.dto;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

import com.fis.ist.customProject.domain.Employee;
import com.fis.ist.services.vo.MKCListRow;

public class EmpListRow  extends MKCListRow implements java.io.Serializable {
     
	private Integer employeeId;
	private String empName;
	private String email;
	private String hireDate;
	private BigDecimal salary;
	private Integer departmentId;
	
     public void load(Employee empRecord)
     {
    	 setEmployeeId(empRecord.getEmployeeId());
    	 setEmpName(empRecord.getEmpName());
    	 setEmail(empRecord.getEmail());
    	 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    	 setHireDate(empRecord.getHireDate()!=null?sdf.format(empRecord.getHireDate()):"");
    	 setSalary(empRecord.getSalary());
    	 setDepartmentId(empRecord.getDepartmentId());
     }
	public Integer getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getHireDate() {
		return hireDate;
	}


	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}
	
	public BigDecimal getSalary() {
		return this.salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public Integer getDepartmentId() {
		return this.departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
}