package com.fis.ist.customProject.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;

import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.customProject.domain.Employee;
import com.fis.ist.log.ISTLogger;

public class EmployeeDAO  extends BaseDAO<Employee, Integer>
 {
	private static final ISTLogger log = ISTLogger.getLogger(EmployeeDAO.class);
	// property constants
	public static final String EMP_NAME = "empName";
	public static final String EMAIL = "email";
	public static final String SALARY = "salary";
	public static final String DEPARTMENT_ID = "departmentId";

	@Override
	public Class<Employee> getEntityClass() {
		return Employee.class;
	}

	public List<Employee> findByExample(Employee instance, int pageNum) {
		log.debug("finding Employee instance by example");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(Employee.class);
			Map<String, Object> condition = new HashMap<String, Object>();
			
			String value = null;
			Object data = null;
			
			data = instance.getEmployeeId();
			if(data != null){
				condition.put("employeeId", data);
			}

			value = instance.getEmpName();
			if(StringUtil.isNotEmpty(value)){
				condition.put("empName", value);
			}

			data = instance.getDepartmentId();
			if(data != null){
				condition.put("departmentId", data);
			}

			c = c.add(Restrictions.allEq(condition));
			setPaging(c, pageNum);
			List<Employee> results = c.list();
			
            log.debug("findByExample successful, result size: " + results.size());
            return results;
        } catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public Integer getTotalByExample(Employee instance) {
		log.debug("getTotalByExample Employee");
		Integer count = null;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(Employee.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();
			
			String value = null;
			Object data = null;
			
			data = instance.getEmployeeId();
			if(data != null){
				condition.put("employeeId", data);
			}

			value = instance.getEmpName();
			if(StringUtil.isNotEmpty(value)){
				condition.put("empName", value);
			}

			data = instance.getDepartmentId();
			if(data != null){
				condition.put("departmentId", data);
			}

			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;

		} catch (RuntimeException re) {
			log.error("getTotalByExample Employee failed", re);
			throw re;
		}
        return count;
	}
	
	public List getDepartments(String department){
		log.debug("getDepartments searchlist..");
		try {
			String queryString = "SELECT id, name, description from department "; 
			boolean dept = StringUtil.isNotEmpty(department);
			if(dept){
				queryString += " where id = ? ";
			}else{
				queryString += " order by id ";
			}
			Query queryObject = createSQLQuery(queryString)
					.addScalar("id", StandardBasicTypes.INTEGER)
					.addScalar("name", StandardBasicTypes.STRING)
					.addScalar("description", StandardBasicTypes.STRING);
			
			if(dept)
				queryObject.setString(0, department);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Exception Occured in getDepartments searchlist.. failed", re);
			throw re;
		}
	}
	
	public List getDepartments(){
		log.debug("getDepartments dropdown list..");
		try {
			String queryString = "SELECT id, id || '-' || name as deptDesc from department order by id"; 

			Query queryObject = createSQLQuery(queryString)
					.addScalar("id", StandardBasicTypes.INTEGER)
					.addScalar("deptDesc", StandardBasicTypes.STRING);
			
			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Exception Occured in getDepartments dropdown list.. failed", re);
			throw re;
		}
	}
}