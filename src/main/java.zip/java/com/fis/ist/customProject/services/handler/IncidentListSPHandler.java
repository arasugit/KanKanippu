package com.fis.ist.customProject.services.handler;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.ForeignKeysCheckException;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MKCHandler;
import com.fis.ist.common.dao.MkcQueue;
import com.fis.ist.customProject.dao.IncidentDAO;
import com.fis.ist.customProject.domain.Incident;
import com.fis.ist.customProject.dto.IncidentListSPRow;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.controller.ControllerSupportConstants;
import com.fis.ist.services.MenuService;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.EditableListRow;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

public class IncidentListSPHandler extends ISTRequestHandler {

	private static final ISTLogger log = ISTLogger.getLogger(IncidentListSPHandler.class);
	private static String reqTypeId = CustomConstants.INCLIST;
	private static String formAuthId = "INCLIST";
	private static SimpleDateFormat sdf = new SimpleDateFormat(PaymonUtils.InputDateFormat);

	public IncidentListSPHandler() {
		checkMKCEnabled(formAuthId);
	}


	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;

			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			// Create a logical collection for add
			List<IncidentListSPRow> workRows = getNewWorkINCLISTSPRows(workRequest, uiMetaData);
			workRows.add(getNewINCLISTSPRowInstance());
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private IncidentListSPRow getNewINCLISTSPRowInstance() {
		IncidentListSPRow dto = new IncidentListSPRow();
		dto.setDbAction('a');
		return dto;
	}

	public WorkRequest getINCLISTSP(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.INCLIST);

		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(CustomConstants.INCLIST);

			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);

			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(CustomConstants.INCLISTTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(CustomConstants.INCLISTTAB, workStatus);

			workReq.setTabStatus(tabStatus);

			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				field.setModifyable("Y");
				field.setVisible("Y");
				if ("cfgId".equals(field.getTag())) {
					String value = (String) params.get("cfgId");
					field.setValue(value);
					field.setModifyable("N");
				}
				if ("description".equals(field.getTag())) {
					String value = (String) params.get("description");
					field.setValue(value);
				}
				if ("product".equals(field.getTag())) {
					String value = (String) params.get("product");
					field.setValue(value);
				}

				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}

				if ("cmd".equals(field.getTag())) {
					String value = (String) params.get("cmd");
					field.setValue(value);
				}

				if ("subcmd".equals(field.getTag())) {
					String value = (String) params.get("subcmd");
					field.setValue(value);
				}

				if ("condition".equals(field.getTag())) {
					String value = (String) params.get("condition");
					field.setValue(value);
				}

				if ("priority".equals(field.getTag())) {
					String value = (String) params.get("priority");
					field.setValue(value);
				}

				if ("alertType".equals(field.getTag())) {
					String value = (String) params.get("alertType");
					field.setValue(value);
				}

				if ("startDate".equals(field.getTag())) {
					String value = (String) params.get("startDate");
					field.setValue(value);
				}

				if ("endDate".equals(field.getTag())) {
					String value = (String) params.get("endDate");
					field.setValue(value);
				}

				if ("message".equals(field.getTag())) {
					String value = (String) params.get("message");
					field.setValue(value);
				}

				if ("smsNumber".equals(field.getTag())) {
					String value = (String) params.get("smsNumber");
					field.setValue(value);
				}

				if ("emailId".equals(field.getTag())) {
					String value = (String) params.get("emailId");
					field.setValue(value);
				}

			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public WorkRequest mkcSubmittedList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		isCheckerRequest(formAuthId, AppConstants.MKC_ACTION_PENDING_REQ);
		if (workReq != null && workReq.getRequestResult().equals(ResponseBase.REQUEST_RESULT_SUCCESS)) {
			workReq = loadFromMKC(workReq, params, "submit");
		}
		return workReq;
	}

	public WorkRequest mkcReworkList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		if (workReq != null && workReq.getRequestResult().equals(ResponseBase.REQUEST_RESULT_SUCCESS)) {
			workReq = loadFromMKC(workReq, params, "rework");
		}
		return workReq;
	}

	public WorkRequest loadFromMKC(WorkRequest workRequest, Map<String, String> params, String query) {
		if (query == null || query.trim().equals("")
				|| (!query.equalsIgnoreCase("rework") && !query.equalsIgnoreCase("submit"))) {
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail("Invalid query options passed");
			return workRequest;
		}
		try {
			List<MkcQueue> mkcrecords = getAllPendingMKCRequest(reqTypeId, query);
			UIMetaData uiMetaData = null;

			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);

			List<IncidentListSPRow> workEmps = getNewWorkINCLISTSPRows(workRequest, uiMetaData);

			for (MkcQueue mkcrec : mkcrecords) {
				try {
					ByteArrayInputStream baip = new ByteArrayInputStream(mkcrec.getRecordObj());
					ObjectInputStream ois = new ObjectInputStream(baip);
					IncidentListSPRow listObj = (IncidentListSPRow) ois.readObject();
					if (listObj != null) {
						listObj.setMkcId(mkcrec.getMkcId());
						listObj.setMkcRecordAction(mkcrec.getAction());
						listObj.setMkcStatus(mkcrec.getStatus());
						listObj.setMkcRemarks(mkcrec.getRemarks());
						listObj.setMakerId(mkcrec.getMakerId());
						listObj.setInactive("");
						listObj.setErrorFlag(false);
						listObj.setErrorMessage("");
						workEmps.add(listObj);
					}
				} catch (Exception e) {
					log.error("Unable to load records from Queue");
					WorkRequestHelper.getInstance().reportException(log, e, workRequest);
				}
			}

			// check if the submitted request from checker and merge the data from the
			// database
			if (isCheckerAction && isMKCEnabled) {
				IncidentDAO dao = new IncidentDAO();

				Incident dbRecord;
				IncidentListSPRow mkcOrignalRecord;

				for (IncidentListSPRow mkcRecord : workEmps) {
					if (mkcRecord.getDbAction().equals('c') && !mkcRecord.getMakerId().equals(getUserID())) {
						dbRecord = dao.findById(Integer.parseInt(mkcRecord.getCfgId()));
						if (dbRecord != null) {
							// which are information same between the mkc record and the original record,
							// overwrite that field value from the latest db record
							// Unchanged information between the mkc record and the orignal record should be
							// overwritten from the latest db record
							mkcOrignalRecord = mkcRecord.getOrignalRow();

							if (!isCellDataChanged(mkcOrignalRecord.getDescription(), mkcRecord.getDescription()))
								mkcRecord.setDescription(dbRecord.getDescription());

							if (!isCellDataChanged(mkcOrignalRecord.getProduct(), mkcRecord.getProduct()))
								mkcRecord.setProduct(dbRecord.getProduct());

							if (!isCellDataChanged(mkcOrignalRecord.getStartDate(), mkcRecord.getStartDate())) {
								// TO DO
								// mkcRecord.setStartDate(dbRecord.getStartDate());
								mkcRecord.setStartDate(mkcRecord.getStartDate());
							}

						}
					}
				}
			}
			if (mkcrecords.size() > 0)
				workRequest.setLastModified(new Long(mkcrecords.size()));
		} catch (Exception e) {
			log.error("unable to load the mkc data");
			WorkRequestHelper.getInstance().reportException(log, e, workRequest);
		}
		return workRequest;
	}

	public Boolean isCellDataChanged(Date first, Date second) {
		if (first == null && second == null)
			return false;

		if (first != null && second != null)
			return !(first.compareTo(second) == 0);

		if (first == null && second != null)
			return true;

		if (first != null && second == null)
			return true;

		return false;
	}

	public Boolean isCellDataChanged(Double first, Double second) {
		if (first == null && second == null)
			return false;

		if (first != null && second != null)
			return !(first.compareTo(second) == 0);

		if (first == null && second != null)
			return true;

		if (first != null && second == null)
			return true;

		return false;
	}

	public Boolean isCellDataChanged(Integer first, Integer second) {
		if (first == null && second == null)
			return false;

		if (first != null && second != null)
			return !(first.compareTo(second) == 0);

		if (first == null && second != null)
			return true;

		if (first != null && second == null)
			return true;

		return false;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, CustomConstants.INCLISTTAB);
	}

	public void load(WorkRequest workRequest, Map<String, String> params) throws ParseException {
		log.debug("Load INCLIST Definition");

		// needs_total variable is used to indicate whether the total count
		// should be fetched and sent to the client. First time,it will be set
		// to get the record count.
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;
		String startDateFormat = "";
		String endDateFormat = "";
		List dateResults = null;

		String cfgId = params.get("cfgId");
		String product = params.get("product") != null ? params.get("product") : "";
		String nodeId = params.get("nodeId") != null ? params.get("nodeId") : "*";
		log.debug("Site-NodeID Info : " + "nodeId = " + nodeId + " productId = " + product );
		
		product = (product == null ? "" : product);
		nodeId = (nodeId == null ? "*" : nodeId); 
		String cmd = params.get("cmd");
		String startDate = ((String) (params).get("startDate"));
		String endDate = ((String) (params).get("endDate"));

		List<Incident> results = new ArrayList<Incident>();

		Incident findRecord = new Incident();
		if (StringUtil.isNotEmpty(product)) {
			findRecord.setProduct(product);
		}
		if (StringUtil.isNotEmpty(nodeId)) {
			findRecord.setNodeId(nodeId);
		}
		if (StringUtil.isNotEmpty(cmd) && cmd != null) {
			findRecord.setCmd(cmd.trim());
		}

		if (StringUtil.isNotEmpty(cfgId) && cfgId != null) {
			cfgId = cfgId.trim();
			try {
				int searchTermcfgId;
				if (cfgId.startsWith("*") && cfgId.endsWith("*")) { 
					searchTermcfgId = Integer.parseInt(cfgId.substring(1, cfgId.length() - 1));
				}
				else if (cfgId.startsWith("*")) {
					searchTermcfgId = Integer.parseInt(cfgId.substring(1));
				} else if (cfgId.endsWith("*")) {
					searchTermcfgId = Integer.parseInt(cfgId.substring(0, cfgId.length() - 1));
				}
				else {
					searchTermcfgId = Integer.parseInt(cfgId);
				}
				findRecord.setCfgId(searchTermcfgId);
			} catch (Exception e) {
			}

		}
		if (StringUtil.isNotEmpty(startDate)) {
			startDateFormat = startDate;
			Date date1 = sdf.parse(startDate);
			findRecord.setStartDate(date1);
		}
		if (StringUtil.isNotEmpty(endDate)) {
			endDateFormat = endDate;
			Date date2 = sdf.parse(endDate);
			findRecord.setStartDate(date2);
		}

		IncidentDAO dao = new IncidentDAO();

		if (!needs_total) {
			if (params.get("startDate") == "" && params.get("endDate") == "") {
				results = loadIncidentListSPData(findRecord, cfgId, pageNum);
			} else {
				dateResults = dao.getIncidentListFromDate(cfgId, product, nodeId, cmd, startDateFormat, endDateFormat,
						pageNum);
			}
		} else if (needs_total) {
			if (params.get("startDate") == "" && params.get("endDate") == "") {
				total = loadIncidentListSPDataCount(findRecord, cfgId);
				results = loadIncidentListSPData(findRecord, cfgId, pageNum);
			} else {
				total = dao.getIncidentListFromDateTotal(cfgId, product, nodeId, cmd, startDateFormat, endDateFormat);
				dateResults = dao.getIncidentListFromDate(cfgId, product, nodeId, cmd, startDateFormat, endDateFormat,
						pageNum);
			}
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List<IncidentListSPRow> workRows = getNewWorkINCLISTSPRows(workRequest, uiMetaData);

		if (params.get("startDate") == "" && params.get("endDate") == "") {
			if (results == null || results.size() == 0) {
				return;
			}
		} else {

			if (dateResults == null || dateResults.size() == 0) {
				return;
			}
		}

		IncidentListSPRow dto2 = null;
		Object[] result2 = null;
		if (params.get("startDate") != "" || params.get("endDate") != "") {
			for (int i = 0; i < dateResults.size(); i++) {
				dto2 = new IncidentListSPRow();
				result2 = (Object[]) dateResults.get(i);
				dto2.loadDateResult(result2);
				dto2.setDbAction('x');
				if (isMKCEnabled) {
					dto2.setOrignalRow(dto2);
				}
				workRows.add(dto2);
			}
		}

		if (params.get("startDate") == "" && params.get("endDate") == "")
			for (Incident incident : results) {
				if (incident != null) {
					IncidentListSPRow dto = new IncidentListSPRow();
					dto.load(incident);
					dto.setDbAction('x');
					if (isMKCEnabled) {
						dto.setOrignalRow(dto);
					}
					workRows.add(dto);
				}
			}
	}

	private List<IncidentListSPRow> getNewWorkINCLISTSPRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(CustomConstants.INCLISTCOL);
		workCollection.setSectionId(CustomConstants.INCLISTSECTION);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(CustomConstants.INCLISTTAB);

		workRequest.getCollections().put(workCollection.getTag(), workCollection);
		List<IncidentListSPRow> workRows = new ArrayList<IncidentListSPRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, CustomConstants.INCLISTCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	public WorkRequest getDataForAdd(UserContext userContext, WorkRequest workRequest) throws Exception {
		if (workRequest != null) {
			WorkCollection wc = workRequest.getCollections().get(CustomConstants.INCLISTCOL);
			wc.getRows().add(0, getNewINCLISTSPRowInstance());
			return workRequest;
		} else {
			WorkRequest workReq = new WorkRequest();
			UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.INCLIST);
			try {

				workReq.setRequestId("0");
				workReq.setRequestState("DRAFT");
				workReq.setRequestTypeId(CustomConstants.INCLIST);

				Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
				workReq.setNextStates(nextStates);

				// Set values of all tabs to be modifiable
				Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
				WorkTabStatus workStatus = new WorkTabStatus();
				workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
				workStatus.setTag(CustomConstants.INCLISTTAB);
				workStatus.setModifyable("Y");
				tabStatus.put(CustomConstants.INCLISTTAB, workStatus);

				workReq.setTabStatus(tabStatus);

				addWorkFields(workReq, uiMetaData);

				workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null);

				// TODO Determine field level security for each WorkField
				// Enable all the fields for the time being
				Map<String, WorkField> fields = workReq.getFields();
				Collection<WorkField> cfields = fields.values();
				for (WorkField field : cfields) {
					field.setModifyable("Y");
					field.setVisible("Y");
				}
			} catch (Exception ex) {
				WorkRequestHelper.getInstance().reportException(log, ex, workReq);
			}
			return workReq;
		}
	}

	public WorkRequest saveSinglePageRecords(UserContext userContext, WorkRequest workRequest,
			HashMap<String, Boolean> permMap) {
		try {
			workRequest = saveWorkRequest(userContext, workRequest, permMap);
		} catch (Exception e) {
			log.error("Exception occured in the Save Single Pags Records" + e.getMessage());
		}
		return workRequest;
	}

	public WorkRequest saveWorkRequest(UserContext userContext, WorkRequest workRequest,
			HashMap<String, Boolean> permMap) throws Exception {
		if (validateCollectionField(workRequest, CustomConstants.INCLISTCOL))
			return workRequest;

		save(userContext, workRequest, permMap);
		return workRequest;
	}

	private void save(UserContext userContext, WorkRequest workRequest, HashMap<String, Boolean> permMap) {
		// check if contact field data is present
		try {
			Map<String, WorkField> fields = workRequest.getFields();
			if (fields == null) {
				WorkRequestHelper.getInstance().reportError("Work fields not found", workRequest);
				return;
			}

			boolean isInvalidData = false;
			String value = null;
			List<IncidentListSPRow> corrCollection = new ArrayList<IncidentListSPRow>();
			List<String> duplicateCollection = new ArrayList<String>();
			IncidentDAO dao = new IncidentDAO();
			WorkCollection wc = workRequest.getCollections().get(CustomConstants.INCLISTCOL);
			List<IncidentListSPRow> rows = wc.getRows();

			// Only the affected rows will be available here.
			int maxId = 0;
			int previousId = 0;

			for (int i = 0; i < rows.size(); i++) {
				IncidentListSPRow row = rows.get(i);
				row.setErrorFlag(false);
				String flag = row.getDbAction().toString();
				if (flag.equals("a") && !(permMap.get("I") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for adding a record");
					isInvalidData = true;
				} else if (flag.equals("c") && !(permMap.get("U") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for updating a record");
					isInvalidData = true;
				} else if (flag.equals("d") && !(permMap.get("D") || permMap.get("C"))) {
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for deleting a record");
					isInvalidData = true;
				}

				IncidentListSPRow model = new IncidentListSPRow();

				if(flag.equals("a")){
				if (i == 0) {
					maxId = dao.getMaxId();

				} else {
					maxId = previousId;
				}
				maxId++;
				previousId = maxId;
				row.setCfgId(String.valueOf(maxId));
			}
				
				String object = row.getCmd();
				if (StringUtil.isEmpty(object)) {
					row.setErrorFlag(true);
					row.setErrorMessage("Command cannot be empty");
					isInvalidData = true;
					continue;
				}
				String startDate = row.getStartDate();
				if (StringUtil.isNotEmpty(startDate)) {
					boolean isValidFormatStartDate = PaymonUtils.isValidDate(startDate);
					if (!isValidFormatStartDate) {
						row.setErrorFlag(true);
						row.setErrorMessage("Start date format is not valid, valid format " + PaymonUtils.InputDateFormat);
						isInvalidData = true;
						continue;
					}
				}
				String endDate = row.getEndDate();
				if (StringUtil.isNotEmpty(endDate)) {
					boolean isValidFormatEndDate = PaymonUtils.isValidDate(endDate);
					if (!isValidFormatEndDate) {
						row.setErrorFlag(true);
						row.setErrorMessage("End date format is not valid, valid format " + PaymonUtils.InputDateFormat);
						isInvalidData = true;
						continue;
					}
				}

				String emailId = row.getEmailId();

				if (null != emailId && StringUtil.isNotEmpty(emailId) && !isValidEmailAddress(emailId)) {
					row.setErrorFlag(true);
					row.setErrorMessage("Email id is not valid");
					isInvalidData = true;
					continue;
				}
				
				String l2_EmailId = row.getL2_EmailId();

				if (null != l2_EmailId && StringUtil.isNotEmpty(l2_EmailId) && !isValidEmailAddress(l2_EmailId)) {
					row.setErrorFlag(true);
					row.setErrorMessage("L2 Email id is not valid");
					isInvalidData = true;
					continue;
				}
				
				String l3_EmailId = row.getL3_EmailId();

				if (null != l3_EmailId && StringUtil.isNotEmpty(l3_EmailId) && !isValidEmailAddress(l3_EmailId)) {
					row.setErrorFlag(true);
					row.setErrorMessage("L3 Email id is not valid");
					isInvalidData = true;
					continue;
				}
				model.setCfgId(row.getCfgId());
				String key = "" + model.getCfgId();

				if (isMKCEnabled && isCheckerAction) {
					if ("a".equals(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())
							&& dao.findById(Integer.parseInt(model.getCfgId())) != null) {
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same CFG ID");
						isInvalidData = true;
						continue;
					}
				} else {
					if (flag.equals("a")) {
						if (dao.findById(Integer.parseInt(model.getCfgId())) != null) {
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same CFG ID");
							isInvalidData = true;
							continue;
						}
					}
				}

				if (isMKCEnabled && isCheckerAction && AppConstants.MKC_SP_ACTION_REWORK.equals(row.getMkcStatus())
						&& "d".equalsIgnoreCase(flag)) {
					row.setErrorFlag(true);
					row.setErrorMessage("Deleted record cannot be set to rework");
					isInvalidData = true;
					continue;
				}

				if (isMKCEnabled && isCheckerAction && "d".equalsIgnoreCase(flag)
						&& AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())) {
					Incident incident = dao.findById(Integer.parseInt(model.getCfgId()));
					if (incident == null) {
						row.setErrorFlag(true);
						row.setErrorMessage("The record is already deleted. Please reject the record.");
						isInvalidData = true;
						continue;
					}
					dao.getSession().evict(incident);
				}
				corrCollection.add(row);
			}

			if (isInvalidData) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0106");
				return;
			}

			if (isMKCEnabled && !isCheckerAction) { // maker changes should go into the queue
				for (EditableListRow edlsrow : corrCollection) {
					if (edlsrow != null) {
						IncidentListSPRow dto = (IncidentListSPRow) edlsrow;
						MKCHandler.getInstance().insertListRowIntoMKC(dto, dto.getCfgId().toString(),
								workRequest.getRequestTypeId(), getUserId(userContext),
								MenuService.getModuleName(reqTypeId));
					}
				}
			} else {
				for (IncidentListSPRow dto : corrCollection) {
					String action = dto.getDbAction().toString();
					if (!isMKCEnabled) { // non mkc
						if ("c".equalsIgnoreCase(action)) {
							Incident incident = dao.findById(Integer.parseInt(dto.getCfgId()));
							if (incident != null) {
								dto.store(incident);
								dao.attachDirty(incident);
							}
						} else if ("a".equalsIgnoreCase(action)) {
							Incident incident = new Incident();
							IncidentDAO daoInc = new IncidentDAO();
							String productId = (String) HTTPRequestGetter.getRequest().getSession(false)
									.getAttribute("product_id");
							String nodeId = (String) HTTPRequestGetter.getRequest().getSession(false)
									.getAttribute("node_name");
							dto.setProduct(productId);
							if(ControllerSupportConstants.SWITCH_PRODUCT_ID.equalsIgnoreCase(productId) ||
									ControllerSupportConstants.CORTEX_PRODUCT_ID.equalsIgnoreCase(productId))
							dto.setNodeId(nodeId);
							else
							dto.setNodeId("*");
							
							dto.store(incident);
							dao.save(incident);
							daoInc.save(incident);
						} else if ("d".equalsIgnoreCase(action)) {
							Incident incident = new Incident();
							dto.store(incident);
							dao.delete(incident);
						}
					} else if (isMKCEnabled && isCheckerAction) { // MKC Checker
						String status = dto.getMkcStatus();
						if ((AppConstants.MKC_SP_ACTION_APPROVE).equals(status)) {
							if ("c".equalsIgnoreCase(action)) {
								Incident incident = dao.findById(Integer.parseInt(dto.getCfgId()));
								if (incident != null) {
									dto.store(incident);
									dao.attachDirty(incident);
								}
							} else if ("a".equalsIgnoreCase(action)) {
								Incident incident = new Incident();
								String productId = (String) HTTPRequestGetter.getRequest().getSession(false)
										.getAttribute("product_id");
								String nodeId = (String) HTTPRequestGetter.getRequest().getSession(false)
										.getAttribute("node_name");
								dto.setProduct(productId);
								dto.setNodeId(nodeId);
								dto.store(incident);
								dao.save(incident);
							} else if ("d".equalsIgnoreCase(action)) {
								Incident incident = new Incident();
								dto.store(incident);
								dao.delete(incident);
							}
							MKCHandler.getInstance().ApproveMKCRecord(dto.getMkcId(), getUserId(userContext),
									dto.getMkcRemarks(), dto.getMkcScheduleDt());
						} else if (AppConstants.MKC_SP_ACTION_REJECT.equals(status)
								|| AppConstants.MKC_SP_ACTION_REWORK.equals(status)) {
							MKCHandler.getInstance().RejectOrReturnRecord(dto.getMkcId(), getUserId(userContext),
									dto.getMkcRemarks(), dto.getMkcScheduleDt(), status);
						} else {
						}
					}
				}
			}
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_NONE);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_SUCCESS);
			workRequest.setErrorDetail("");
			rows.clear();
		} catch (Exception e) {
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail(e.getMessage());
			if (e instanceof ForeignKeysCheckException) {
				workRequest.setMessageSubstitutions(((ForeignKeysCheckException) e).getChildTables());
			}
		}
	}

	private List<Incident> loadIncidentListSPData(Incident model, String cfgId, int pageNum) {
		log.debug("Load Incident records - loadIncidentListSPData()");
		IncidentDAO dao = new IncidentDAO();
		List<Incident> results = dao.findByExample(model, cfgId, pageNum);
		return results;
	}

	private int loadIncidentListSPDataCount(Incident model, String cfgId) throws ParseException {
		log.debug("Load Incident records - loadIncidentListSPDataCount()");
		IncidentDAO dao = new IncidentDAO();
		int count = dao.getTotalByExampleCount(model, cfgId);
		return count;
	}
	
	public HashMap<String, String> getDBMapping() {
		HashMap<String, String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("cfgId", "cfgId");
		dtoMapping.put("description", "description");
		dtoMapping.put("product", "product");
		dtoMapping.put("nodeId", "nodeId");
		dtoMapping.put("cmd", "cmd");
		dtoMapping.put("subCmd", "subCmd");
		dtoMapping.put("condition", "condition");
		dtoMapping.put("priority", "priority");
		dtoMapping.put("alertType", "alertType");
		dtoMapping.put("startDate", "startDate");
		dtoMapping.put("endDate", "endDate");
		dtoMapping.put("message", "message");
		dtoMapping.put("smsNumber", "smsNumber");
		dtoMapping.put("emailId", "emailId");
		dtoMapping.put("type", "type");
		dtoMapping.put("l2_EmailId", "l2_EmailId");
		dtoMapping.put("l2_smsNumber", "l2_smsNumber");
		dtoMapping.put("l3_EmailId", "l3_EmailId");
		dtoMapping.put("l3_smsNumber", "l3_smsNumber");
		
		return dtoMapping;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();
		return validateFields(fieldDataMap);
	}

	public boolean isValidEmailAddress(String email) {
		String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
		java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
		java.util.regex.Matcher m = p.matcher(email);
		return m.matches();
	}

	public static boolean isNumeric(String str) {
		try {
			Integer.parseInt(str);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
}
