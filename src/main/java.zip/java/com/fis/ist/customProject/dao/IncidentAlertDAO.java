package com.fis.ist.customProject.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;

import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.customProject.domain.Employee;
import com.fis.ist.customProject.domain.Incident;
import com.fis.ist.customProject.domain.IncidentAction;
import com.fis.ist.customProject.domain.IncidentAlert;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.controller.ControllerSupportConstants;
import com.fis.ist.monitoring.dao.MonitorBaseDAO;

public class IncidentAlertDAO  extends MonitorBaseDAO<IncidentAlert, Integer>
 {
	private static final ISTLogger log = ISTLogger.getLogger(IncidentAlertDAO.class);
	public static final String INCUPDT_INCDTE = "INCUPDT_INCDTE";
	public static final String INCUPDT_INCDTE_TOTL = "INCUPDT_INCDTE_TOTL";
	public static final String INCUPDT_TOTL_BY_ED = "INCUPDT_TOTL_BY_ED";
	public static final String INCUPDT_FND_BY_EG = "INCUPDT_FND_BY_EG";

	@Override
	public Class<IncidentAlert> getEntityClass() {
		return IncidentAlert.class;
	}

	public List<IncidentAlert> findByExample1(IncidentAlert instance, int pageNum) {
		log.debug("finding Incident instance by example");

		
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(IncidentAlert.class);
			Map<String, Object> condition = new HashMap<String, Object>();
			
			String value = null;
			Object data = null;
				

			data = instance.getCfgId();
			if(data != null){
				condition.put("cfgId", data);
			}
			
			data = instance.getIncId();
			if(data != null){
				condition.put("incId", data);
			}
			
			data = instance.getComments();
			if(data != null){
				condition.put("comments", data);
			}
						
			c = c.add(Restrictions.allEq(condition));
			c.addOrder(Order.desc("incId"));
			c.addOrder(Order.desc("upddate"));
			setPaging(c, pageNum);
			List<IncidentAlert> results = c.list();
			
			
            log.debug("findByExample successful, result size: " + results.size());
            return results;
        } catch (RuntimeException re) {
        	log.error("find by example failed", re);
			throw re;
		}
	}
	
	public void save(IncidentAlert transientInstance) 
	{
		getSession().save(transientInstance);
	}
	
	public IncidentAlert findById(Integer id) 
	{
		IncidentAlert instance = (IncidentAlert) getSession().get(getEntityClass(), id);
		return instance;
	}
	
	public List getIncidentAlertFromIncDate(String cfgId, String incId,  String upddate, String comments,  int pageNum) {
		try {
			StringBuffer queryBuffer = new StringBuffer();

			/*queryBuffer.append(
					" Select  cfgid, incid, upddate, comments from cs_monincprogress where trunc(upddate) in to_date(:upddate , 'dd-Mon-yy')");*/
			
			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCUPDT_INCDTE));
			
			String queryString = queryBuffer.toString();
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("cfgid", StandardBasicTypes.INTEGER)
					.addScalar("incid", StandardBasicTypes.INTEGER)
					.addScalar("upddate", StandardBasicTypes.DATE)
					.addScalar("comments", StandardBasicTypes.STRING);
			
			queryObject.setParameter("upddate", upddate);
		
			setPaging(queryObject, pageNum);
						

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}
	
	public int getIncidentAlertFromIncDateTotal(String cfgId, String incId,  String upddate, String comments, Integer pageNum) {
		try {
			StringBuffer queryBuffer = new StringBuffer();

			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCUPDT_INCDTE_TOTL));
			
			String queryString = queryBuffer.toString();
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("cfgid", StandardBasicTypes.INTEGER)
					.addScalar("incid", StandardBasicTypes.INTEGER)
					.addScalar("upddate", StandardBasicTypes.DATE)
					.addScalar("comments", StandardBasicTypes.STRING);
	


		
			queryObject.setParameter("upddate", upddate);
		
			setPaging(queryObject, pageNum);
						

			return queryObject.list().size();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	
	public Integer getTotalByExample1(IncidentAlert instance) {
		log.debug("getTotalByExample IncidentAlert");
		Integer count = null;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(IncidentAlert.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();
			
			String value = null;
			Object data = null;
			
			data = instance.getCfgId();
			if(data != null){
				condition.put("cfgId", data);
			}
			
			data = instance.getUpddate();
			if(data != null){
				condition.put("incDate",data );
			}

			data = instance.getIncId();
			if(data != null){
				condition.put("incId", data);
			}
		
			
			data = instance.getComments();
			if(data != null){
				condition.put("comments", data);
			}

			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;

		} catch (RuntimeException re) {
			log.error("getTotalByExample IncidentAlert failed", re);
			throw re;
		}
        return count;
	}

	public Integer getTotalByExample(IncidentAlert instance, String product1, String nodeId1, String upddateFormat, String cfgId, String incId) {
		log.debug("IncidentActionDAO - findByExample - Fetching for Incident Alert ");
		
		try {
			StringBuffer queryBuffer = new StringBuffer();
			
			Integer configId = instance.getCfgId() != null ? instance.getCfgId() : 0;
			Integer incidentId  = instance.getIncId() != null ? instance.getIncId() : 0;
			String updatedDate = upddateFormat != null ? upddateFormat : "";
			String comments = instance.getComments() != null ? instance.getComments() : "";
			String product = product1 != null ? product1 : "";
			String nodeId = nodeId1 != null ? nodeId1 : "";
			
			if(comments != null || comments != "") {
				comments = comments.trim();
			}

			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCUPDT_TOTL_BY_ED));
			
			if(configId > 0 || !cfgId.isEmpty()) {
				String searchTerm = (String) cfgId;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCPROG.cfgId AS VARCHAR(20)) LIKE '"+ "%" + searchTermcfgId + "%'");
				} else if (searchTerm.startsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1));
					queryBuffer.append(" and CAST(MONINCPROG.cfgId AS VARCHAR(20)) LIKE '" + "%" + searchTermcfgId + "'");
				} else if (searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(0, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCPROG.cfgId AS VARCHAR(20)) LIKE '" + searchTermcfgId + "%'");
				} else {
					queryBuffer.append(" and MONINCPROG.cfgid = " + configId + "" );
				}
			}
			
			if(incidentId > 0 || !incId.isEmpty()) {
				String searchTerm = (String) incId;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(1, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCPROG.incid AS VARCHAR(20)) LIKE '"+ "%" + searchTermincId + "%'");
				} else if (searchTerm.startsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(1));
					queryBuffer.append(" and CAST(MONINCPROG.incid AS VARCHAR(20)) LIKE '" + "%" + searchTermincId + "'");
				} else if (searchTerm.endsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(0, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCPROG.incid AS VARCHAR(20)) LIKE '" + searchTermincId + "%'");
				} else {
					queryBuffer.append(" and MONINCPROG.incid = " + incidentId + "" );
				}
			}
			
			if(!updatedDate.equalsIgnoreCase("")) {
				queryBuffer.append(" and " + getTruncFunctionBasedOnDBType() + "= to_date('" + updatedDate + "' , 'dd-Mon-yy')");
			}
			
			if(!comments.equalsIgnoreCase("")) {
				queryBuffer.append(" and UPPER(MONINCPROG.comments) like UPPER('%" + comments + "%')" ); 
			}
		
			if(StringUtil.isNotEmpty(product) && (product.equalsIgnoreCase(ControllerSupportConstants.SWITCH_PRODUCT_ID) || product.equalsIgnoreCase(ControllerSupportConstants.CORTEX_PRODUCT_ID)))
				queryBuffer.append(" and TRIM(MONINCCFG.product) = '" + product + "' and MONINCCFG.nodeid IN (" + nodeId + ")");
			else 
				queryBuffer.append(" and TRIM(MONINCCFG.product) = '" + product + "' ");
			
			String queryString = queryBuffer.toString();
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
				
			Integer recordCount = (Integer) queryObject.list().get(0);

			return recordCount.intValue();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
		
	}
	
	public List<IncidentAlert> findByExample(IncidentAlert instance, int pageNum, String product1, String nodeId1, String upddateFormat, String cfgId, String incId) {
		log.debug("IncidentActionDAO - findByExample - Fetching for Incident Alert ");
		
		try {
			StringBuffer queryBuffer = new StringBuffer();
			
			Integer configId = instance.getCfgId() != null ? instance.getCfgId() : 0;
			Integer incidentId  = instance.getIncId() != null ? instance.getIncId() : 0;
			String updatedDate = upddateFormat != null ? upddateFormat : "";
			String comments = instance.getComments() != null ? instance.getComments(): "";
			String product = product1 != null ? product1 : "";
			String nodeId = nodeId1 != null ? nodeId1 : "";
			
			if(comments != null || comments != "") {
				comments = comments.trim();
			}
			
			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCUPDT_FND_BY_EG));
			
			if(configId > 0 || !cfgId.isEmpty()) {
				String searchTerm = (String) cfgId;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCPROG.cfgId AS VARCHAR(20)) LIKE '"+ "%" + searchTermcfgId + "%'");
				} else if (searchTerm.startsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1));
					queryBuffer.append(" and CAST(MONINCPROG.cfgId AS VARCHAR(20)) LIKE '" + "%" + searchTermcfgId + "'");
				} else if (searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(0, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCPROG.cfgId AS VARCHAR(20)) LIKE '" + searchTermcfgId + "%'");
				} else {
					queryBuffer.append(" and MONINCPROG.cfgid = " + configId + "" );
				}
			}
			
			if(incidentId > 0 || !incId.isEmpty()) {
				String searchTerm = (String) incId;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(1, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCPROG.incid AS VARCHAR(20)) LIKE '"+ "%" + searchTermincId + "%'");
				} else if (searchTerm.startsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(1));
					queryBuffer.append(" and CAST(MONINCPROG.incid AS VARCHAR(20)) LIKE '" + "%" + searchTermincId + "'");
				} else if (searchTerm.endsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(0, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCPROG.incid AS VARCHAR(20)) LIKE '" + searchTermincId + "%'");
				} else {
					queryBuffer.append(" and MONINCPROG.incid = " + incidentId + "" );
				}
			}
			
			if(!updatedDate.equalsIgnoreCase("")) {
				//queryBuffer.append(" and trunc(MONINCPROG.last_update_date) = to_date('" + updatedDate + "' , 'dd-Mon-yy')");
				queryBuffer.append(" and " + getTruncFunctionBasedOnDBType() + "= to_date('" + updatedDate + "' , 'dd-Mon-yy')");
			}
			
			if(!comments.equalsIgnoreCase("")) {
				queryBuffer.append(" and UPPER(MONINCPROG.comments) like UPPER('%" + comments + "%')" ); 

			}
			
			if(StringUtil.isNotEmpty(product) && (product.equalsIgnoreCase(ControllerSupportConstants.SWITCH_PRODUCT_ID) || product.equalsIgnoreCase(ControllerSupportConstants.CORTEX_PRODUCT_ID)))
				queryBuffer.append(" and TRIM(MONINCCFG.product) = '" + product + "' and MONINCCFG.nodeid IN (" + nodeId + ")");
			else 
				queryBuffer.append(" and TRIM(MONINCCFG.product) = '" + product + "' ");
			
			String queryString = queryBuffer.toString();
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("cfgid", StandardBasicTypes.INTEGER)
					.addScalar("incid", StandardBasicTypes.INTEGER)
					.addScalar("lastupdatedate", StandardBasicTypes.DATE)
					.addScalar("comments", StandardBasicTypes.STRING)
					.addScalar("esctype",StandardBasicTypes.STRING)
					.addScalar("age", StandardBasicTypes.INTEGER);

				
			setPaging(queryObject, pageNum);			

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
		
	}

	private String getTruncFunctionBasedOnDBType() {
		
		if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
			return "date_trunc('day', MONINCPROG.last_update_date) ";
		} 
		
		return "trunc(MONINCPROG.last_update_date) ";
	}
	
}

