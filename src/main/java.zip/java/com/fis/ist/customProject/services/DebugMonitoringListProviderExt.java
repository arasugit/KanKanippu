package com.fis.ist.customProject.services;

import java.util.List;
import java.util.Map;

import com.fis.ist.common.IListProvider;
import com.fis.ist.customProject.dao.CsMonDebugDAO;
import com.fis.ist.spring.HTTPRequestGetter;

public class DebugMonitoringListProviderExt implements IListProvider {
	
	@Override
	public List getList() {
		String product = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id"); 
		List recordList = null;
		recordList = new CsMonDebugDAO().getFileNames(product);
		return recordList;	
	}
	
	@Override
	public String getName() {
		return "DEBUG_MTR_FILENAME_POPUP";
	}

	@Override
	public List getList(Map<String, String> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getListByInstitution(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}
}