package com.fis.ist.customProject.dao;
import javax.persistence.Transient;
import java.util.Date;
import java.math.BigDecimal;
import javax.persistence.Table;
import javax.persistence.Entity;
import java.io.Serializable;

public class ShcLog implements Serializable
{
    private ShcLogId id;
    private String txnsrc;
    private BigDecimal msgtype;
    private BigDecimal flippedMsgtype;
    private String pan;
    private String maskPan;
    private BigDecimal pcode;
    private BigDecimal txntype;
    private BigDecimal amount;
    private BigDecimal avalBalance;
    private BigDecimal amountEquiv;
    private BigDecimal cashBack;
    private BigDecimal issConvRate;
    private BigDecimal issCurrencyCode;
    private Date issConvDate;
    private BigDecimal acqConvRate;
    private BigDecimal acqCurrencyCode;
    private Date acqConvDate;
    private BigDecimal traAmount;
    private BigDecimal traConvRate;
    private BigDecimal traCurrencyCode;
    private Date traConvDate;
    private BigDecimal fee;
    private BigDecimal newFee;
    private BigDecimal newAmount;
    private BigDecimal newSetlAmount;
    private BigDecimal settlementFee;
    private BigDecimal settlementRate;
    private BigDecimal settlementCode;
    private BigDecimal settlementAmount;
    private Date trandate;
    private BigDecimal trantime;
    private BigDecimal trace;
    private BigDecimal localTime;
    private Date localDate;
    private Date settlementDate;
    private Date capDate;
    private BigDecimal posEntryCode;
    private BigDecimal posConditionCode;
    private String posPinCapCode;
    private BigDecimal posCapCode;
    private BigDecimal lifeCycle;
    private String acquirer;
    private String issuer;
    private String transferee;
    private String originator;
    private String memberId;
    private String FId;
    private String txndest;
    private String alternateacquirer;
    private String entityid;
    private String issEntityid;
    private String cardproduct;
    private String mvv;
    private String invoiceNumber;
    private String transId;
    private String fpi;
    private BigDecimal txnStartTime;
    private BigDecimal txnEndTime;
    private BigDecimal deviceCap;
    private BigDecimal respcode;
    private BigDecimal reasonCode;
    private BigDecimal revcode;
    private BigDecimal shcerror;
    private BigDecimal saf;
    private BigDecimal origmsg;
    private BigDecimal origflippedmsg;
    private BigDecimal origtrace;
    private Date origdate;
    private BigDecimal origtime;
    private BigDecimal merchantType;
    private BigDecimal acqCountry;
    private String refnum;
    private String authnum;
    private String termid;
    private String acceptorname;
    private String termloc;
    private String addresponse;
    private String acctnum;
    private BigDecimal branch;
    private BigDecimal serial1;
    private BigDecimal serial2;
    private BigDecimal storeid;
    private BigDecimal lane;
    private BigDecimal terminalTrace;
    private BigDecimal checkerId;
    private BigDecimal supervisor;
    private BigDecimal shiftNumber;
    private BigDecimal batchId;
    private BigDecimal deviceDevcap;
    private BigDecimal shcDevcap;
    private BigDecimal formatterDevcap;
    private BigDecimal authDevcap;
    private String filler1;
    private String filler2;
    private String filler3;
    private String filler4;
    private String issuerData;
    private String acquirerData;
    private BigDecimal newAmountEquiv;
    private BigDecimal acqAvalBalance;
    private BigDecimal acqLedgerBalance;
    private BigDecimal setlAvalBalance;
    private BigDecimal setlLedgerBalance;
    private BigDecimal avalBalanceType;
    private BigDecimal ledgerBalanceType;
    private BigDecimal newSetlFee;
    private BigDecimal txnAmount;
    private BigDecimal txnNewAmount;
    private BigDecimal txnCurrencyCode;
    private BigDecimal txnConvRate;
    private Date txnConvDate;
    private BigDecimal chAmount;
    private BigDecimal chNewAmount;
    private BigDecimal chCurrencyCode;
    private BigDecimal chConvRate;
    private Date chConvDate;
    private BigDecimal ledgerBalance;
    private BigDecimal slotNum;
    private BigDecimal deviceFee;
    private String shcDataBuffer;
    private BigDecimal cardSeqno;
    private String alpharesponsecode;
    private String chipType;
    private Date processorBusday;
    private BigDecimal seqTraceNo;
    private BigDecimal version;
    private String destNode;
    private String srcNode;
    private String maskedPan;
    private String[] pans;
    
    public ShcLog() {
    }
    
    public ShcLog(final ShcLogId id) {
        this.id = id;
    }
    
    public ShcLogId getId() {
        return this.id;
    }
    
    public void setId(final ShcLogId id) {
        this.id = id;
    }
    
    public String getTxnsrc() {
        return this.txnsrc;
    }
    
    public void setTxnsrc(final String txnsrc) {
        this.txnsrc = txnsrc;
    }
    
    public BigDecimal getMsgtype() {
        return this.msgtype;
    }
    
    public void setMsgtype(final BigDecimal msgtype) {
        this.msgtype = msgtype;
    }
    
    public BigDecimal getFlippedMsgtype() {
        return this.flippedMsgtype;
    }
    
    public void setFlippedMsgtype(final BigDecimal flippedMsgtype) {
        this.flippedMsgtype = flippedMsgtype;
    }
    
    public String getPan() {
        return this.pan;
    }
    
    public void setPan(final String pan) {
        this.pan = pan;
    }
    
    public String getMaskPan() {
        return this.maskPan;
    }
    
    public void setMaskPan(final String maskPan) {
        this.maskPan = maskPan;
    }
    
    public BigDecimal getPcode() {
        return this.pcode;
    }
    
    public void setPcode(final BigDecimal pcode) {
        this.pcode = pcode;
    }
    
    public BigDecimal getTxntype() {
        return this.txntype;
    }
    
    public void setTxntype(final BigDecimal txntype) {
        this.txntype = txntype;
    }
    
    public BigDecimal getAmount() {
        return this.amount;
    }
    
    public void setAmount(final BigDecimal amount) {
        this.amount = amount;
    }
    
    public BigDecimal getAvalBalance() {
        return this.avalBalance;
    }
    
    public void setAvalBalance(final BigDecimal avalBalance) {
        this.avalBalance = avalBalance;
    }
    
    public BigDecimal getAmountEquiv() {
        return this.amountEquiv;
    }
    
    public void setAmountEquiv(final BigDecimal amountEquiv) {
        this.amountEquiv = amountEquiv;
    }
    
    public BigDecimal getCashBack() {
        return this.cashBack;
    }
    
    public void setCashBack(final BigDecimal cashBack) {
        this.cashBack = cashBack;
    }
    
    public BigDecimal getIssConvRate() {
        return this.issConvRate;
    }
    
    public void setIssConvRate(final BigDecimal issConvRate) {
        this.issConvRate = issConvRate;
    }
    
    public BigDecimal getIssCurrencyCode() {
        return this.issCurrencyCode;
    }
    
    public void setIssCurrencyCode(final BigDecimal issCurrencyCode) {
        this.issCurrencyCode = issCurrencyCode;
    }
    
    public Date getIssConvDate() {
        return this.issConvDate;
    }
    
    public void setIssConvDate(final Date issConvDate) {
        this.issConvDate = issConvDate;
    }
    
    public BigDecimal getAcqConvRate() {
        return this.acqConvRate;
    }
    
    public void setAcqConvRate(final BigDecimal acqConvRate) {
        this.acqConvRate = acqConvRate;
    }
    
    public BigDecimal getAcqCurrencyCode() {
        return this.acqCurrencyCode;
    }
    
    public void setAcqCurrencyCode(final BigDecimal acqCurrencyCode) {
        this.acqCurrencyCode = acqCurrencyCode;
    }
    
    public Date getAcqConvDate() {
        return this.acqConvDate;
    }
    
    public void setAcqConvDate(final Date acqConvDate) {
        this.acqConvDate = acqConvDate;
    }
    
    public BigDecimal getTraAmount() {
        return this.traAmount;
    }
    
    public void setTraAmount(final BigDecimal traAmount) {
        this.traAmount = traAmount;
    }
    
    public BigDecimal getTraConvRate() {
        return this.traConvRate;
    }
    
    public void setTraConvRate(final BigDecimal traConvRate) {
        this.traConvRate = traConvRate;
    }
    
    public BigDecimal getTraCurrencyCode() {
        return this.traCurrencyCode;
    }
    
    public void setTraCurrencyCode(final BigDecimal traCurrencyCode) {
        this.traCurrencyCode = traCurrencyCode;
    }
    
    public Date getTraConvDate() {
        return this.traConvDate;
    }
    
    public void setTraConvDate(final Date traConvDate) {
        this.traConvDate = traConvDate;
    }
    
    public BigDecimal getFee() {
        return this.fee;
    }
    
    public void setFee(final BigDecimal fee) {
        this.fee = fee;
    }
    
    public BigDecimal getNewFee() {
        return this.newFee;
    }
    
    public void setNewFee(final BigDecimal newFee) {
        this.newFee = newFee;
    }
    
    public BigDecimal getNewAmount() {
        return this.newAmount;
    }
    
    public void setNewAmount(final BigDecimal newAmount) {
        this.newAmount = newAmount;
    }
    
    public BigDecimal getNewSetlAmount() {
        return this.newSetlAmount;
    }
    
    public void setNewSetlAmount(final BigDecimal newSetlAmount) {
        this.newSetlAmount = newSetlAmount;
    }
    
    public BigDecimal getSettlementFee() {
        return this.settlementFee;
    }
    
    public void setSettlementFee(final BigDecimal settlementFee) {
        this.settlementFee = settlementFee;
    }
    
    public BigDecimal getSettlementRate() {
        return this.settlementRate;
    }
    
    public void setSettlementRate(final BigDecimal settlementRate) {
        this.settlementRate = settlementRate;
    }
    
    public BigDecimal getSettlementCode() {
        return this.settlementCode;
    }
    
    public void setSettlementCode(final BigDecimal settlementCode) {
        this.settlementCode = settlementCode;
    }
    
    public BigDecimal getSettlementAmount() {
        return this.settlementAmount;
    }
    
    public void setSettlementAmount(final BigDecimal settlementAmount) {
        this.settlementAmount = settlementAmount;
    }
    
    public Date getTrandate() {
        return this.trandate;
    }
    
    public void setTrandate(final Date trandate) {
        this.trandate = trandate;
    }
    
    public BigDecimal getTrantime() {
        return this.trantime;
    }
    
    public void setTrantime(final BigDecimal trantime) {
        this.trantime = trantime;
    }
    
    public BigDecimal getTrace() {
        return this.trace;
    }
    
    public void setTrace(final BigDecimal trace) {
        this.trace = trace;
    }
    
    public BigDecimal getLocalTime() {
        return this.localTime;
    }
    
    public void setLocalTime(final BigDecimal localTime) {
        this.localTime = localTime;
    }
    
    public Date getLocalDate() {
        return this.localDate;
    }
    
    public void setLocalDate(final Date localDate) {
        this.localDate = localDate;
    }
    
    public Date getSettlementDate() {
        return this.settlementDate;
    }
    
    public void setSettlementDate(final Date settlementDate) {
        this.settlementDate = settlementDate;
    }
    
    public Date getCapDate() {
        return this.capDate;
    }
    
    public void setCapDate(final Date capDate) {
        this.capDate = capDate;
    }
    
    public BigDecimal getPosEntryCode() {
        return this.posEntryCode;
    }
    
    public void setPosEntryCode(final BigDecimal posEntryCode) {
        this.posEntryCode = posEntryCode;
    }
    
    public BigDecimal getPosConditionCode() {
        return this.posConditionCode;
    }
    
    public void setPosConditionCode(final BigDecimal posConditionCode) {
        this.posConditionCode = posConditionCode;
    }
    
    public String getPosPinCapCode() {
        return this.posPinCapCode;
    }
    
    public void setPosPinCapCode(final String posPinCapCode) {
        this.posPinCapCode = posPinCapCode;
    }
    
    public BigDecimal getPosCapCode() {
        return this.posCapCode;
    }
    
    public void setPosCapCode(final BigDecimal posCapCode) {
        this.posCapCode = posCapCode;
    }
    
    public BigDecimal getLifeCycle() {
        return this.lifeCycle;
    }
    
    public void setLifeCycle(final BigDecimal lifeCycle) {
        this.lifeCycle = lifeCycle;
    }
    
    public String getAcquirer() {
        return this.acquirer;
    }
    
    public void setAcquirer(final String acquirer) {
        this.acquirer = acquirer;
    }
    
    public String getIssuer() {
        return this.issuer;
    }
    
    public void setIssuer(final String issuer) {
        this.issuer = issuer;
    }
    
    public String getTransferee() {
        return this.transferee;
    }
    
    public void setTransferee(final String transferee) {
        this.transferee = transferee;
    }
    
    public String getOriginator() {
        return this.originator;
    }
    
    public void setOriginator(final String originator) {
        this.originator = originator;
    }
    
    public String getMemberId() {
        return this.memberId;
    }
    
    public void setMemberId(final String memberId) {
        this.memberId = memberId;
    }
    
    public String getFId() {
        return this.FId;
    }
    
    public void setFId(final String FId) {
        this.FId = FId;
    }
    
    public String getTxndest() {
        return this.txndest;
    }
    
    public void setTxndest(final String txndest) {
        this.txndest = txndest;
    }
    
    public String getAlternateacquirer() {
        return this.alternateacquirer;
    }
    
    public void setAlternateacquirer(final String alternateacquirer) {
        this.alternateacquirer = alternateacquirer;
    }
    
    public String getEntityid() {
        return this.entityid;
    }
    
    public void setEntityid(final String entityid) {
        this.entityid = entityid;
    }
    
    public String getIssEntityid() {
        return this.issEntityid;
    }
    
    public void setIssEntityid(final String issEntityid) {
        this.issEntityid = issEntityid;
    }
    
    public String getCardproduct() {
        return this.cardproduct;
    }
    
    public void setCardproduct(final String cardproduct) {
        this.cardproduct = cardproduct;
    }
    
    public String getMvv() {
        return this.mvv;
    }
    
    public void setMvv(final String mvv) {
        this.mvv = mvv;
    }
    
    public String getInvoiceNumber() {
        return this.invoiceNumber;
    }
    
    public void setInvoiceNumber(final String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }
    
    public String getTransId() {
        return this.transId;
    }
    
    public void setTransId(final String transId) {
        this.transId = transId;
    }
    
    public String getFpi() {
        return this.fpi;
    }
    
    public void setFpi(final String fpi) {
        this.fpi = fpi;
    }
    
    public BigDecimal getTxnStartTime() {
        return this.txnStartTime;
    }
    
    public void setTxnStartTime(final BigDecimal txnStartTime) {
        this.txnStartTime = txnStartTime;
    }
    
    public BigDecimal getTxnEndTime() {
        return this.txnEndTime;
    }
    
    public void setTxnEndTime(final BigDecimal txnEndTime) {
        this.txnEndTime = txnEndTime;
    }
    
    public BigDecimal getDeviceCap() {
        return this.deviceCap;
    }
    
    public void setDeviceCap(final BigDecimal deviceCap) {
        this.deviceCap = deviceCap;
    }
    
    public BigDecimal getRespcode() {
        return this.respcode;
    }
    
    public void setRespcode(final BigDecimal respcode) {
        this.respcode = respcode;
    }
    
    public BigDecimal getReasonCode() {
        return this.reasonCode;
    }
    
    public void setReasonCode(final BigDecimal reasonCode) {
        this.reasonCode = reasonCode;
    }
    
    public BigDecimal getRevcode() {
        return this.revcode;
    }
    
    public void setRevcode(final BigDecimal revcode) {
        this.revcode = revcode;
    }
    
    public BigDecimal getShcerror() {
        return this.shcerror;
    }
    
    public void setShcerror(final BigDecimal shcerror) {
        this.shcerror = shcerror;
    }
    
    public BigDecimal getSaf() {
        return this.saf;
    }
    
    public void setSaf(final BigDecimal saf) {
        this.saf = saf;
    }
    
    public BigDecimal getOrigmsg() {
        return this.origmsg;
    }
    
    public void setOrigmsg(final BigDecimal origmsg) {
        this.origmsg = origmsg;
    }
    
    public BigDecimal getOrigflippedmsg() {
        return this.origflippedmsg;
    }
    
    public void setOrigflippedmsg(final BigDecimal origflippedmsg) {
        this.origflippedmsg = origflippedmsg;
    }
    
    public BigDecimal getOrigtrace() {
        return this.origtrace;
    }
    
    public void setOrigtrace(final BigDecimal origtrace) {
        this.origtrace = origtrace;
    }
    
    public Date getOrigdate() {
        return this.origdate;
    }
    
    public void setOrigdate(final Date origdate) {
        this.origdate = origdate;
    }
    
    public BigDecimal getOrigtime() {
        return this.origtime;
    }
    
    public void setOrigtime(final BigDecimal origtime) {
        this.origtime = origtime;
    }
    
    public BigDecimal getMerchantType() {
        return this.merchantType;
    }
    
    public void setMerchantType(final BigDecimal merchantType) {
        this.merchantType = merchantType;
    }
    
    public BigDecimal getAcqCountry() {
        return this.acqCountry;
    }
    
    public void setAcqCountry(final BigDecimal acqCountry) {
        this.acqCountry = acqCountry;
    }
    
    public String getRefnum() {
        return this.refnum;
    }
    
    public void setRefnum(final String refnum) {
        this.refnum = refnum;
    }
    
    public String getAuthnum() {
        return this.authnum;
    }
    
    public void setAuthnum(final String authnum) {
        this.authnum = authnum;
    }
    
    public String getTermid() {
        return this.termid;
    }
    
    public void setTermid(final String termid) {
        this.termid = termid;
    }
    
    public String getAcceptorname() {
        return this.acceptorname;
    }
    
    public void setAcceptorname(final String acceptorname) {
        this.acceptorname = acceptorname;
    }
    
    public String getTermloc() {
        return this.termloc;
    }
    
    public void setTermloc(final String termloc) {
        this.termloc = termloc;
    }
    
    public String getAddresponse() {
        return this.addresponse;
    }
    
    public void setAddresponse(final String addresponse) {
        this.addresponse = addresponse;
    }
    
    public String getAcctnum() {
        return this.acctnum;
    }
    
    public void setAcctnum(final String acctnum) {
        this.acctnum = acctnum;
    }
    
    public BigDecimal getBranch() {
        return this.branch;
    }
    
    public void setBranch(final BigDecimal branch) {
        this.branch = branch;
    }
    
    public BigDecimal getSerial1() {
        return this.serial1;
    }
    
    public void setSerial1(final BigDecimal serial1) {
        this.serial1 = serial1;
    }
    
    public BigDecimal getSerial2() {
        return this.serial2;
    }
    
    public void setSerial2(final BigDecimal serial2) {
        this.serial2 = serial2;
    }
    
    public BigDecimal getStoreid() {
        return this.storeid;
    }
    
    public void setStoreid(final BigDecimal storeid) {
        this.storeid = storeid;
    }
    
    public BigDecimal getLane() {
        return this.lane;
    }
    
    public void setLane(final BigDecimal lane) {
        this.lane = lane;
    }
    
    public BigDecimal getTerminalTrace() {
        return this.terminalTrace;
    }
    
    public void setTerminalTrace(final BigDecimal terminalTrace) {
        this.terminalTrace = terminalTrace;
    }
    
    public BigDecimal getCheckerId() {
        return this.checkerId;
    }
    
    public void setCheckerId(final BigDecimal checkerId) {
        this.checkerId = checkerId;
    }
    
    public BigDecimal getSupervisor() {
        return this.supervisor;
    }
    
    public void setSupervisor(final BigDecimal supervisor) {
        this.supervisor = supervisor;
    }
    
    public BigDecimal getShiftNumber() {
        return this.shiftNumber;
    }
    
    public void setShiftNumber(final BigDecimal shiftNumber) {
        this.shiftNumber = shiftNumber;
    }
    
    public BigDecimal getBatchId() {
        return this.batchId;
    }
    
    public void setBatchId(final BigDecimal batchId) {
        this.batchId = batchId;
    }
    
    public BigDecimal getDeviceDevcap() {
        return this.deviceDevcap;
    }
    
    public void setDeviceDevcap(final BigDecimal deviceDevcap) {
        this.deviceDevcap = deviceDevcap;
    }
    
    public BigDecimal getShcDevcap() {
        return this.shcDevcap;
    }
    
    public void setShcDevcap(final BigDecimal shcDevcap) {
        this.shcDevcap = shcDevcap;
    }
    
    public BigDecimal getFormatterDevcap() {
        return this.formatterDevcap;
    }
    
    public void setFormatterDevcap(final BigDecimal formatterDevcap) {
        this.formatterDevcap = formatterDevcap;
    }
    
    public BigDecimal getAuthDevcap() {
        return this.authDevcap;
    }
    
    public void setAuthDevcap(final BigDecimal authDevcap) {
        this.authDevcap = authDevcap;
    }
    
    public String getFiller1() {
        return this.filler1;
    }
    
    public void setFiller1(final String filler1) {
        this.filler1 = filler1;
    }
    
    public String getFiller2() {
        return this.filler2;
    }
    
    public void setFiller2(final String filler2) {
        this.filler2 = filler2;
    }
    
    public String getFiller3() {
        return this.filler3;
    }
    
    public void setFiller3(final String filler3) {
        this.filler3 = filler3;
    }
    
    public String getFiller4() {
        return this.filler4;
    }
    
    public void setFiller4(final String filler4) {
        this.filler4 = filler4;
    }
    
    public String getIssuerData() {
        return this.issuerData;
    }
    
    public void setIssuerData(final String issuerData) {
        this.issuerData = issuerData;
    }
    
    public String getAcquirerData() {
        return this.acquirerData;
    }
    
    public void setAcquirerData(final String acquirerData) {
        this.acquirerData = acquirerData;
    }
    
    public BigDecimal getNewAmountEquiv() {
        return this.newAmountEquiv;
    }
    
    public void setNewAmountEquiv(final BigDecimal newAmountEquiv) {
        this.newAmountEquiv = newAmountEquiv;
    }
    
    public BigDecimal getAcqAvalBalance() {
        return this.acqAvalBalance;
    }
    
    public void setAcqAvalBalance(final BigDecimal acqAvalBalance) {
        this.acqAvalBalance = acqAvalBalance;
    }
    
    public BigDecimal getAcqLedgerBalance() {
        return this.acqLedgerBalance;
    }
    
    public void setAcqLedgerBalance(final BigDecimal acqLedgerBalance) {
        this.acqLedgerBalance = acqLedgerBalance;
    }
    
    public BigDecimal getSetlAvalBalance() {
        return this.setlAvalBalance;
    }
    
    public void setSetlAvalBalance(final BigDecimal setlAvalBalance) {
        this.setlAvalBalance = setlAvalBalance;
    }
    
    public BigDecimal getSetlLedgerBalance() {
        return this.setlLedgerBalance;
    }
    
    public void setSetlLedgerBalance(final BigDecimal setlLedgerBalance) {
        this.setlLedgerBalance = setlLedgerBalance;
    }
    
    public BigDecimal getAvalBalanceType() {
        return this.avalBalanceType;
    }
    
    public void setAvalBalanceType(final BigDecimal avalBalanceType) {
        this.avalBalanceType = avalBalanceType;
    }
    
    public BigDecimal getLedgerBalanceType() {
        return this.ledgerBalanceType;
    }
    
    public void setLedgerBalanceType(final BigDecimal ledgerBalanceType) {
        this.ledgerBalanceType = ledgerBalanceType;
    }
    
    public BigDecimal getNewSetlFee() {
        return this.newSetlFee;
    }
    
    public void setNewSetlFee(final BigDecimal newSetlFee) {
        this.newSetlFee = newSetlFee;
    }
    
    public BigDecimal getTxnAmount() {
        return this.txnAmount;
    }
    
    public void setTxnAmount(final BigDecimal txnAmount) {
        this.txnAmount = txnAmount;
    }
    
    public BigDecimal getTxnNewAmount() {
        return this.txnNewAmount;
    }
    
    public void setTxnNewAmount(final BigDecimal txnNewAmount) {
        this.txnNewAmount = txnNewAmount;
    }
    
    public BigDecimal getTxnCurrencyCode() {
        return this.txnCurrencyCode;
    }
    
    public void setTxnCurrencyCode(final BigDecimal txnCurrencyCode) {
        this.txnCurrencyCode = txnCurrencyCode;
    }
    
    public BigDecimal getTxnConvRate() {
        return this.txnConvRate;
    }
    
    public void setTxnConvRate(final BigDecimal txnConvRate) {
        this.txnConvRate = txnConvRate;
    }
    
    public Date getTxnConvDate() {
        return this.txnConvDate;
    }
    
    public void setTxnConvDate(final Date txnConvDate) {
        this.txnConvDate = txnConvDate;
    }
    
    public BigDecimal getChAmount() {
        return this.chAmount;
    }
    
    public void setChAmount(final BigDecimal chAmount) {
        this.chAmount = chAmount;
    }
    
    public BigDecimal getChNewAmount() {
        return this.chNewAmount;
    }
    
    public void setChNewAmount(final BigDecimal chNewAmount) {
        this.chNewAmount = chNewAmount;
    }
    
    public BigDecimal getChCurrencyCode() {
        return this.chCurrencyCode;
    }
    
    public void setChCurrencyCode(final BigDecimal chCurrencyCode) {
        this.chCurrencyCode = chCurrencyCode;
    }
    
    public BigDecimal getChConvRate() {
        return this.chConvRate;
    }
    
    public void setChConvRate(final BigDecimal chConvRate) {
        this.chConvRate = chConvRate;
    }
    
    public Date getChConvDate() {
        return this.chConvDate;
    }
    
    public void setChConvDate(final Date chConvDate) {
        this.chConvDate = chConvDate;
    }
    
    public BigDecimal getLedgerBalance() {
        return this.ledgerBalance;
    }
    
    public void setLedgerBalance(final BigDecimal ledgerBalance) {
        this.ledgerBalance = ledgerBalance;
    }
    
    public BigDecimal getSlotNum() {
        return this.slotNum;
    }
    
    public void setSlotNum(final BigDecimal slotNum) {
        this.slotNum = slotNum;
    }
    
    public BigDecimal getDeviceFee() {
        return this.deviceFee;
    }
    
    public void setDeviceFee(final BigDecimal deviceFee) {
        this.deviceFee = deviceFee;
    }
    
    public String getShcDataBuffer() {
        return this.shcDataBuffer;
    }
    
    public void setShcDataBuffer(final String shcDataBuffer) {
        this.shcDataBuffer = shcDataBuffer;
    }
    
    public BigDecimal getCardSeqno() {
        return this.cardSeqno;
    }
    
    public void setCardSeqno(final BigDecimal cardSeqno) {
        this.cardSeqno = cardSeqno;
    }
    
    public String getAlpharesponsecode() {
        return this.alpharesponsecode;
    }
    
    public void setAlpharesponsecode(final String alpharesponsecode) {
        this.alpharesponsecode = alpharesponsecode;
    }
    
    public String getChipType() {
        return this.chipType;
    }
    
    public void setChipType(final String chipType) {
        this.chipType = chipType;
    }
    
    public Date getProcessorBusday() {
        return this.processorBusday;
    }
    
    public void setProcessorBusday(final Date processorBusday) {
        this.processorBusday = processorBusday;
    }
    
    public BigDecimal getSeqTraceNo() {
        return this.seqTraceNo;
    }
    
    public void setSeqTraceNo(final BigDecimal seqTraceNo) {
        this.seqTraceNo = seqTraceNo;
    }
    
    @Transient
    public String getMaskedPan() {
        return this.maskedPan;
    }
    
    public void setMaskedPan(final String maskedPan) {
        this.maskedPan = maskedPan;
    }
    
    @Transient
    public String[] getPans() {
        return this.pans;
    }
    
    public void setPans(final String[] pans) {
        this.pans = pans;
    }
    
    public BigDecimal getVersion() {
        return this.version;
    }
    
    public void setVersion(final BigDecimal version) {
        this.version = version;
    }
    
    public String getDestNode() {
        return this.destNode;
    }
    
    public void setDestNode(final String destNode) {
        this.destNode = destNode;
    }
    
    public String getSrcNode() {
        return this.srcNode;
    }
    
    public void setSrcNode(final String srcNode) {
        this.srcNode = srcNode;
    }
}