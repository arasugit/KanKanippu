package com.fis.ist.customProject.dao;

import static org.hibernate.criterion.Example.create;

import java.io.Serializable;
import java.util.List;
import org.hibernate.LockMode;
import org.hibernate.Query;
import com.fis.ist.customProject.dao.BaseHibernateDAO;
import com.fis.ist.log.ISTLogger;

public abstract class BaseDAO<M, I extends Object & Serializable> extends BaseHibernateDAO
{
	private static final ISTLogger log = ISTLogger.getLogger(BaseDAO.class);
	public void save(M transientInstance) 
	{
		getSession().save(transientInstance);
	}
	public void delete(M persistentInstance) throws Exception
	{			
	 getSession().delete(persistentInstance);
		
	}
	public void attachClean(M instance) 
	{
		getSession().lock(instance, LockMode.NONE);
	}
	public void attachDirty(M instance) 
	{
		getSession().saveOrUpdate(instance);
	}
	public String getEntityName() { return getEntityClass().getName(); }

	public abstract Class<M> getEntityClass();

	public M findById(I id) 
	{
		M instance = (M) getSession().get(getEntityClass(), id);
		return instance;
	}
	public M merge(M detachedInstance) 
	{
		M result = (M) getSession().merge(detachedInstance);
		return result;
	}
	public List<M> findByProperty(String propertyName, Object value) 
	{
		String queryString = "from " + getEntityName() + " as model where model." 
		+ propertyName + "= ?";
		Query queryObject = createQuery(queryString);
		queryObject.setParameter(0, value);
		return (List<M>)queryObject.list();
	}
	public List<M> findAll() 
	{
		String queryString = "from " + getEntityName();
		Query queryObject = createQuery(queryString);
		return (List<M>)queryObject.list();
	}
	public List<M> findByExample(M instance) 
	{
		List<M> results = (List<M>) getSession()
			.createCriteria(getEntityClass())
			.add(create(instance))
			.list();
		return results;
	}
	

}