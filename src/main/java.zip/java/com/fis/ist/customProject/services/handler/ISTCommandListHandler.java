package com.fis.ist.customProject.services.handler;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.ForeignKeysCheckException;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MKCHandler;
import com.fis.ist.common.dao.MkcQueue;
import com.fis.ist.customProject.dto.ISTCommandListRow;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.ISTCommandDAO;
import com.fis.ist.monitoring.domain.ISTCommand;
import com.fis.ist.services.MenuService;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.EditableListRow;
import com.fis.ist.services.vo.WorkRequest;

import edu.emory.mathcs.backport.java.util.Collections;

public class ISTCommandListHandler extends ISTRequestHandler {

	private static final ISTLogger log = ISTLogger.getLogger(ISTCommandListHandler.class);
	private static String reqTypeId = CustomConstants.TSKCMD;
	private static String formAuthId = "TSKCMD";
	
	public ISTCommandListHandler(){
		checkMKCEnabled(formAuthId);
	}
	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
			throws Exception {
				
		log.debug("By Loading TaskListHandler and addNewWorkRequest " +  params);

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(
						WorkRequestHandlerData.RequestMode.ADD_NEW,
						workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null
					|| workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}
		} catch (Exception ex) {
			throw ex;
		} 
		return workRequest;
	}
	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(
						WorkRequestHandlerData.RequestMode.ADD_NEW,
						workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null
					|| workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			// Create a logical collection for add
			List<ISTCommandListRow> workRows = getNewWorkTSKCMDRows(workRequest, uiMetaData);
			workRows.add(getNewTSKCMDInstance());
		} catch (Exception ex) {
			throw ex;
		} 
		return workRequest;
	}
	
	private ISTCommandListRow getNewTSKCMDInstance() {
		ISTCommandListRow dto = new ISTCommandListRow();
		dto.setDbAction('a');
		return dto;
	}
	
	public WorkRequest getTSKCMD(UserContext userContext, Map<String, String> params) throws Exception {
		log.debug("By Loading TaskListHandler and getTSKCMD " +  params);
		WorkRequest workReq = prepareWorkRequest(userContext, params);

		load(workReq, params);
		return workReq;
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params ) throws Exception{
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.TSKCMD);
		
		
		log.debug("By Loading TaskListHandler and prepareWorkRequest " +  params);

		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(CustomConstants.TSKCMD);

			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);

			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(CustomConstants.TSKCMDTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(CustomConstants.TSKCMDTAB, workStatus);

			workReq.setTabStatus(tabStatus);

			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("product".equals(field.getTag())) {
					String value = (String) params.get("product");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				if ("istCommand".equals(field.getTag())) {
					String value = (String) params.get("istCommand");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}
		
	public WorkRequest mkcSubmittedList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext,params);
		isCheckerRequest(formAuthId, AppConstants.MKC_ACTION_PENDING_REQ);
		if(workReq!=null && workReq.getRequestResult().equals(ResponseBase.REQUEST_RESULT_SUCCESS)){
			workReq = loadFromMKC(workReq, params,"submit");
		}
		return workReq;
	}
	
	public WorkRequest mkcReworkList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext,params);
		if(workReq!=null && workReq.getRequestResult().equals(ResponseBase.REQUEST_RESULT_SUCCESS)){
			workReq = loadFromMKC(workReq, params,"rework");
		}
		return workReq;
	}
	
	public WorkRequest loadFromMKC(WorkRequest workRequest,Map<String, String> params,String query)
	{
		if (query == null || query.trim().equals("") || (!query.equalsIgnoreCase("rework") && !query.equalsIgnoreCase("submit"))) {
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail("Invalid query options passed");
			return workRequest;
		}
		try {
			List<MkcQueue> mkcrecords = getAllPendingMKCRequest(reqTypeId,query);
			UIMetaData uiMetaData=null;

			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);

			List<ISTCommandListRow> workEmps = getNewWorkTSKCMDRows(workRequest ,uiMetaData);

			for (MkcQueue mkcrec : mkcrecords) {
				try {
					ByteArrayInputStream baip = new ByteArrayInputStream(mkcrec.getRecordObj());
					ObjectInputStream ois = new ObjectInputStream(baip);
					ISTCommandListRow listObj = (ISTCommandListRow) ois.readObject();
					if (listObj !=null) {
						listObj.setMkcId(mkcrec.getMkcId());
						listObj.setMkcRecordAction(mkcrec.getAction());
						listObj.setMkcStatus(mkcrec.getStatus());
						listObj.setMkcRemarks(mkcrec.getRemarks());
						listObj.setMakerId(mkcrec.getMakerId());
						listObj.setInactive("");
						listObj.setErrorFlag(false);
						listObj.setErrorMessage("");
						workEmps.add(listObj);
					}
				}catch (Exception e) {
					log.error("Unable to load records from Queue");
					WorkRequestHelper.getInstance().reportException(log, e, workRequest);
				}
			}

			// check if the submitted request from checker and merge the data from the database
			if (isCheckerAction && isMKCEnabled) {
				ISTCommandDAO dao = new ISTCommandDAO();

				ISTCommand dbRecord ;
				ISTCommandListRow mkcOrignalRecord;

				for (ISTCommandListRow mkcRecord : workEmps)
				{
					// System.out.println("111 - ISTCommandListHandler - Need to Revisit, since Key ID different from type " );
				}
			}
			if (mkcrecords.size()>0)
				workRequest.setLastModified(new Long(mkcrecords.size()));
		}catch (Exception e){
			log.error("unable to load the mkc data");
			WorkRequestHelper.getInstance().reportException(log, e, workRequest);
		}
		return workRequest;
	}
	
	public Boolean isCellDataChanged(Date first, Date second) {
		 if(first == null && second == null)
			 return false;

		 if(first != null && second != null)
			 return !(first.compareTo(second) == 0);
		 
		 if (first == null && second != null)
			 return true;

		 if (first != null && second == null)
			 return true;
		 
		 return false;
	}
	
	public Boolean isCellDataChanged(Double first, Double second) {
		 if(first == null && second == null)
			 return false;

		 if(first != null && second != null)
			 return !(first.compareTo(second) == 0);
		 
		 if (first == null && second != null)
			 return true;

		 if (first != null && second == null)
			 return true;
		 
		 return false;
	}

	public Boolean isCellDataChanged(Integer first, Integer second) {
		 if(first == null && second == null)
			 return false;

		 if(first != null && second != null)
			 return !(first.compareTo(second) == 0);
		 
		 if (first == null && second != null)
			 return true;

		 if (first != null && second == null)
			 return true;
		 
		 return false;
	}
	
	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData)
			throws Exception {
		addWorkFields(workReq, uiMetaData, CustomConstants.TSKCMDTAB);
	}
	
	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load TSKCMD Definition");
		
		// needs_total variable is used to indicate whether the total count
		// should be fetched and sent to the client. First time,it will be set
		// to get the record count.
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		// ist_page_ctrl will contain the page number and according the records
		// will be fetched based on the pagesize and sent to the client.
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		String product = params.get("product");
		String nodeId = params.get("nodeId");
		String commandType = params.get("CommandType");
		//fieldName For Search/ Filter parameter by fields
		String portFlags = params.get("portFlags");
		String fieldName = params.get("fieldName");
		String binStatus = params.get("binStatus");
		String binRouteNode = params.get("binRouteNode");
		String instId = params.get("instId");
		String count = params.get("serverMail");
		
		// Read the parameters from the params object and invoke the DAO methods
		// to get the results.
		// results will hold the result set fetched from the database
		// if needs_total is set, the record the record count and set it to the
		// lastModified property of the workRequest.

		List<ISTCommand> results = new ArrayList<ISTCommand>();
		ISTCommand findRecord = new ISTCommand();
		
		if(StringUtil.isNotEmpty(product)){
			try{
				findRecord.setProduct(product);
			}catch (NumberFormatException nfe) {
				log.debug("Invalid Product ["+product+"]", nfe);
			}
		}
		
		if(StringUtil.isNotEmpty(nodeId)){
			try{
				findRecord.setNodeId(nodeId);
			}catch (NumberFormatException nfe) {
				log.debug("Invalid NodeId ["+nodeId+"]", nfe);
			}
		}
				
		if(StringUtil.isNotEmpty(commandType)){
			try{
				findRecord.setIstCommand(commandType);
			}catch (NumberFormatException nfe) {
				log.debug("Invalid commandType ["+commandType+"]", nfe);
			}
		}
			
//		To Implement Search/filter option -  BIN status / Route / nodewise & Search/filter option Port Name / Flags		
		if (StringUtil.isNotEmpty(fieldName) || StringUtil.isNotEmpty(portFlags) || StringUtil.isNotEmpty(binStatus)
				|| StringUtil.isNotEmpty(binRouteNode) || StringUtil.isNotEmpty(instId) || StringUtil.isNotEmpty(count) ) {
			if(commandType.equalsIgnoreCase("mbportcmd list")){
//				Search with Port Name : FIELD2
				fieldName = fieldName.trim();
				findRecord.setTaskType(fieldName);
			}
			
			if(commandType.equalsIgnoreCase("mbportcmd list")) {
//				Search with Port Flags : FIELD3
				portFlags = portFlags.trim();
				findRecord.setFlags(portFlags);
				
				count = count.trim();
				findRecord.setCount(count);
			}
			
			else if(commandType.equalsIgnoreCase("shccmd list")) {
//				Search with BIN status : FIELD2
				binStatus = binStatus.trim();
				findRecord.setTaskType(binStatus);
				
//				Search with BIN Route Node : FIELD4
				binRouteNode = binRouteNode.trim();
				findRecord.setCount(binRouteNode);
				
//				Search with BIN Route Group : FIELD5
				fieldName = fieldName.trim();
				findRecord.setLastStart(fieldName);
				instId = instId.trim();
				findRecord.setpId(instId);
			}
			
			if(commandType.equalsIgnoreCase("tskcmd")) {
				fieldName = fieldName.trim();
				findRecord.setTaskType(fieldName);
			}
			
			if(commandType.equalsIgnoreCase("dbconn")) {
				fieldName = fieldName.trim();
				findRecord.setTaskType(fieldName);
			}
			
			if(commandType.equalsIgnoreCase("otracecmd list")) {
				fieldName = fieldName.trim();
				findRecord.setTaskType(fieldName);
			}
			
			ISTCommandDAO dao = new ISTCommandDAO();
					
			if (!needs_total) {
				log.debug("Load ISTCommand records - ISTCommandListSPData()");
				results = dao.findByExampleWithFields(findRecord, pageNum);
			} else if (needs_total) {
				total = dao.getTotalByExampleWithFields(findRecord);
				results = dao.findByExampleWithFields(findRecord, pageNum);
			}
		}
		else {
			if (!needs_total) {
				results = loadISTCommandListData(findRecord, pageNum);
			} else if (needs_total) {
				total = loadISTCommandListDataCount(findRecord);
				results = loadISTCommandListData(findRecord, pageNum);
			}
		}
		
		//To add default sorting for port details
		if(commandType.equalsIgnoreCase("mbportcmd list")) {
			Collections.sort(results, new ISTCommand.FlagsComparator());
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData=null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		}
		catch (Exception e){
			log.error("unable to get the Meta data"+e.getMessage());
		}

		List<ISTCommandListRow> workRows= getNewWorkTSKCMDRows(workRequest, uiMetaData);

		if (results == null || results.size() == 0) {
			return;
		}
		
		for (ISTCommand istCommand4dto: results) {
			if(istCommand4dto != null){
				ISTCommandListRow dto = new ISTCommandListRow();
				dto.load(istCommand4dto);
				dto.setDbAction('x');
				if (isMKCEnabled){
					dto.setOrignalRow(dto);
				}
				workRows.add(dto);
			}
		}
	}
	
	private List<ISTCommand> loadISTCommandListData(ISTCommand model, int pageNum) {
		log.debug("Load ISTCommand records - ISTCommandListSPData()");
		ISTCommandDAO dao = new ISTCommandDAO();
		List<ISTCommand> results = dao.findByExample(model, pageNum);
	
		return results;
	}

	private int ISTCommandListSPDataCount(ISTCommand model) {
		log.debug("Load ISTCommand records - loadISTCommandListSPDataCount()");
		ISTCommandDAO dao = new ISTCommandDAO();
		int count = dao.getTotalByExample(model);
		return count;
	}
	
	public HashMap<String,String> getDBMapping()
	{
		HashMap<String,String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("product","product");
		dtoMapping.put("nodeId","nodeId");
		dtoMapping.put("taskName","taskName");
		dtoMapping.put("taskType","taskType");
		dtoMapping.put("pId","pId");
		return dtoMapping;
	}
	
	private Boolean validateQueryFields(Map<String, String> params,WorkRequest workReq) throws Exception{
		Map<String, WorkField> fields = workReq.getFields();
		Map <WorkField,String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue="";
		WorkField currentfield = null;


		currentfield = fields.get("product");
		fieldValue = params.get("product");
		fieldDataMap.put(currentfield,fieldValue);

		currentfield = fields.get("nodeId");
		fieldValue = params.get("nodeId");
		fieldDataMap.put(currentfield,fieldValue);

		currentfield = fields.get("istCommand");
		fieldValue = params.get("istCommand");
		fieldDataMap.put(currentfield,fieldValue);

		return validateFields(fieldDataMap);
	}
	
		
	private List<ISTCommandListRow> getNewWorkTSKCMDRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(CustomConstants.TSKCMDCOL);
		workCollection.setSectionId(CustomConstants.TSKCMDSEC);
        workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(CustomConstants.TSKCMDTAB);

		workRequest.getCollections().put(workCollection.getTag(),
				workCollection);

		List<ISTCommandListRow> workRows = new ArrayList<ISTCommandListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, CustomConstants.TSKCMDCOL);
		workCollection.setRows(workRows);
		return workRows;
	}
	
	public WorkRequest getDataForAdd(UserContext userContext,
			WorkRequest workRequest) throws Exception {
		if (workRequest != null) {
			WorkCollection wc = workRequest.getCollections().get(CustomConstants.TSKCMDCOL);
			wc.getRows().add(0, getNewTSKCMDInstance());
			return workRequest;
		} else {
			WorkRequest workReq = new WorkRequest();
			UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.TSKCMD);
			try {

				workReq.setRequestId("0");
				workReq.setRequestState("DRAFT");
				workReq.setRequestTypeId(CustomConstants.TSKCMD);

				Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
				workReq.setNextStates(nextStates);

				// Set values of all tabs to be modifiable
				Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
				WorkTabStatus workStatus = new WorkTabStatus();
				workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
				workStatus.setTag(CustomConstants.TSKCMDTAB);
				workStatus.setModifyable("Y");
				tabStatus.put(CustomConstants.TSKCMDTAB, workStatus);

				workReq.setTabStatus(tabStatus);

				addWorkFields(workReq, uiMetaData);

				workReq = addNewWorkRequest(workReq, userContext, uiMetaData,
						null);

				// TODO Determine field level security for each WorkField
				// Enable all the fields for the time being
				Map<String, WorkField> fields = workReq.getFields();
				Collection<WorkField> cfields = fields.values();
				for (WorkField field : cfields) {
					field.setModifyable("Y");
					field.setVisible("Y");
				}
			} catch (Exception ex) {
		      	  WorkRequestHelper.getInstance().reportException(log, ex, workReq);
			}
			return workReq;
		}
	}
	
	public WorkRequest saveSinglePageRecords(UserContext userContext, WorkRequest workRequest,HashMap<String,Boolean> permMap) {
		try {
			workRequest = saveWorkRequest(userContext,workRequest,permMap);
		}catch (Exception e){
			log.error("Exception occured in the Save Single Pags Records"+e.getMessage());
		}
		return workRequest;
	}
	
	public WorkRequest saveWorkRequest(UserContext userContext,
			WorkRequest workRequest,HashMap<String, Boolean> permMap) throws Exception{
		if (validateCollectionField(workRequest,CustomConstants.TSKCMDCOL))
			return workRequest;

		save(userContext, workRequest,permMap);
		return workRequest;
	}

	private void save(UserContext userContext, WorkRequest workRequest, HashMap<String, Boolean> permMap) {
		// check if contact field data is present
		try{
			Map<String, WorkField> fields = workRequest.getFields();
			if (fields == null) {
				WorkRequestHelper.getInstance().reportError("Work fields not found", workRequest);
				return;
			}

			boolean isInvalidData = false;
			String value = null;
			List<ISTCommandListRow> corrCollection = new ArrayList<ISTCommandListRow>();
			List<String> duplicateCollection = new ArrayList<String>();
			ISTCommandDAO dao = new ISTCommandDAO();
			WorkCollection wc = workRequest.getCollections().get(CustomConstants.TSKCMDCOL);
			List<ISTCommandListRow> rows = wc.getRows();

			//Only the affected rows will be available here.

			for(int i = 0; i < rows.size();i++){
				ISTCommandListRow row = rows.get(i);
				row.setErrorFlag(false);
				String flag = row.getDbAction().toString();
				if(flag.equals("a")  &&!(permMap.get("I") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for adding a record");
					isInvalidData = true;
				}else if(flag.equals("c") && !(permMap.get("U") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for updating a record");
					isInvalidData = true;
				}else if(flag.equals("d") && !(permMap.get("D") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for deleting a record");
					isInvalidData = true;
				}

				ISTCommandListRow model = new ISTCommandListRow();

				Object object = row.getProduct();
				if(object == null){
					row.setErrorFlag(true);
					row.setErrorMessage("Product cannot be empty");
					isInvalidData = true;
					continue;
				}
				model.setProduct(row.getProduct());
				String key = ""+model.getProduct();

				if (isMKCEnabled && isCheckerAction){
					if(duplicateCollection.contains(key+row.getMkcStatus()) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())){
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same same Product");
						isInvalidData = true;
						continue;
					}else{
						duplicateCollection.add(key+row.getMkcStatus());
					}
				}else{
					if(!flag.equals("d")){
						if(duplicateCollection.contains(key)){
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same Product");
							isInvalidData = true;
							continue;
						}else{
							duplicateCollection.add(key);
						}
					}
				}

				if (isMKCEnabled && isCheckerAction){
					// System.out.println("222 - ISTCommandListHandler - Need to Revisit, since Key ID different from type " );

				}else{
					if(flag.equals("a")){
						// System.out.println("333 - ISTCommandListHandler - Need to Revisit, since Key ID different from type " );

					}
				}

				if (isMKCEnabled && isCheckerAction && AppConstants.MKC_SP_ACTION_REWORK.equals(row.getMkcStatus()) && "d".equalsIgnoreCase(flag)){
					row.setErrorFlag(true);
					row.setErrorMessage("Deleted record cannot be set to rework");
					isInvalidData = true;
					continue;
				}

				if(isMKCEnabled && isCheckerAction && "d".equalsIgnoreCase(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())){
					// System.out.println("444 - ISTCommandListHandler -  Need to Revisit, since Key ID different from type " );

					ISTCommand istCommand = null;
					dao.getSession().evict(istCommand);
				}
				corrCollection.add(row);
			}
			
			if(isInvalidData){
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0106");
				return;
			}
			
			if(isMKCEnabled && !isCheckerAction){ // maker changes should go into the queue
				for (EditableListRow edlsrow : corrCollection) {
					if (edlsrow!=null){
						ISTCommandListRow dto = (ISTCommandListRow)edlsrow;
						MKCHandler.getInstance().insertListRowIntoMKC(dto, dto.getProduct().toString(), workRequest.getRequestTypeId(), getUserId(userContext), MenuService.getModuleName(reqTypeId));
					}
				}
			}else{
				// System.out.println("555 - ISTCommandListHandler -  Need to Revisit, since Key ID different from type " );
				
			}
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_NONE);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_SUCCESS);
			workRequest.setErrorDetail("");
			rows.clear();
		}catch (Exception e){
		   workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
           workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
           workRequest.setErrorDetail(e.getMessage());
   		   if(e instanceof ForeignKeysCheckException){
			   workRequest.setMessageSubstitutions(((ForeignKeysCheckException)e).getChildTables());				  
		   }
		}
	}

	private int loadISTCommandListDataCount(ISTCommand model) {
		log.debug("Load Task Command records - loadISTCommandListDataCount()");
		ISTCommandDAO dao = new ISTCommandDAO();
		int count = dao.getTotalByExample(model);
		return count;
	}


}