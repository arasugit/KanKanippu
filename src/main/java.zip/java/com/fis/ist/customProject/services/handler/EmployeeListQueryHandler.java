package com.fis.ist.customProject.services.handler;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.dao.MkcQueue;
import com.fis.ist.customProject.dao.EmployeeDAO;
import com.fis.ist.customProject.domain.Employee;
import com.fis.ist.customProject.dto.EmpListRow;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.MKCWorkRequest;
import com.fis.ist.services.vo.WorkRequest;

public class EmployeeListQueryHandler extends ISTRequestHandler implements
ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(EmployeeListQueryHandler.class);
	private static final String requestTypeForFetchingMKCPendingList = CustomConstants.EMPDETAIL;

	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
					throws Exception {
		workRequest = getNewWorkRequest(workRequest, userContext, uiMetaData,
				data, null);

		Map<String, WorkField> fields = workRequest.getFields();
		Collection<WorkField> cfields = fields.values();
		for (WorkField field : cfields) {
			field.setModifyable("Y");
			field.setVisible("Y");
			if (field.tag.equals("employeeId")) {
				String empId = params.get("employeeId");
				if (StringUtil.isNotEmpty(empId))
					field.setValue(empId); // Set the query values into the
				// work field
			} else if (field.tag.equals("empName")) {
				String empName = params.get("empName");
				if (StringUtil.isNotEmpty(empName))
					field.setValue(empName); // Set the query values into
				// the work field
			} else if (field.tag.equals("departmentId")) {
				String deptId = params.get("departmentId");
				if (StringUtil.isNotEmpty(deptId))
					field.setValue(deptId);
			}
		}

		boolean errFlag = validateQueryFields(params, workRequest);
		if (errFlag) {
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail("E0134");
			return workRequest;
		}
		return workRequest;
	}

	public WorkRequest list(UserContext userContext, Map<String, String> params)
			throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext,params);
		if(workReq!=null && ResponseBase.REQUEST_RESULT_SUCCESS.equals(workReq.getRequestResult())){
			load(userContext, workReq, params);
		}
		return workReq;
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params ) throws Exception{
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData("EMPLIST");
		try {
			workReq.setRequestId("0"); // Don't need a real request number just
			// for a device query
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId("EMPLIST");

			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);

			// Set values of all tabs to be modifiable
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag("EMPLISTTAB");
			workStatus.setModifyable("Y");
			tabStatus.put("EMPLISTTAB", workStatus);

			workReq.setTabStatus(tabStatus);

			addWorkFields(workReq, uiMetaData);

			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null,
					params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData)
			throws Exception {
		addWorkFields(workReq, uiMetaData, "EMPLISTTAB");
	}

	public void load(UserContext userContext, WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load employees");

		// needs_total variable is used to indicate whether the total count
		// should be fetched and sent to the client. First time,it will be set
		// to get the record count.
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		// ist_page_ctrl will contain the page number and according the records
		// will be fetched based on the pagesize and sent to the client.
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		String empId = params.get("employeeId");
		String empName = params.get("empName");
		String deptId = params.get("departmentId");

		// Read the parameters from the params object and invoke the DAO methods
		// to get the results.
		// results will hold the result set fetched from the database
		// if needs_total is set, the record the record count and set it to the
		// lastModified property of the workRequest.
		List<Employee> results = new ArrayList<Employee>();

		Employee findRecord = new Employee();
		if (StringUtil.isNotEmpty(empId)) {
			try {
				findRecord.setEmployeeId(Integer.parseInt(empId));
			} catch (NumberFormatException nfe) {
				log.debug("Invalid employee id [" + empId + "]", nfe);
			}
		}

		findRecord.setEmpName(empName);

		if (StringUtil.isNotEmpty(deptId)) {
			try {
				findRecord.setDepartmentId((Integer.parseInt(deptId)));
			} catch (NumberFormatException nfe) {
				log.debug("Invalid department id [" + deptId + "]", nfe);
			}
		}

		if (!needs_total) {
			results = loadEmployeeListData(findRecord, pageNum);
		} else if (needs_total) {
			total = loadEmployeeListDataCount(findRecord);
			results = loadEmployeeListData(findRecord, pageNum);
		}

		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		List<EmpListRow> workInsts = getEmployeesWorkCollection(workRequest);

		if (results == null || results.size() == 0) {
			return;
		}
		// Set this request as sensitive
		setSensitiveReqFlag();

		for (Employee record : results) {
			EmpListRow dtoRecord = new EmpListRow();
			dtoRecord.load(record);
			workInsts.add(dtoRecord);
		}
	}

	private List<EmpListRow> getEmployeesWorkCollection(WorkRequest workRequest) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag("EMPLISTCOL");

		workRequest.getCollections().put(workCollection.getTag(),
				workCollection);

		List<EmpListRow> workCollectionRows = new ArrayList<EmpListRow>();
		workCollection.setRows(workCollectionRows);
		return workCollectionRows;
	}

	private List<Employee> loadEmployeeListData(Employee model, int pageNum) {
		log.debug("Load Employee records - loadEmployeeListData()");
		EmployeeDAO dao = new EmployeeDAO();
		List<Employee> results = dao.findByExample(model, pageNum);
		return results;
	}

	private int loadEmployeeListDataCount(Employee model) {
		log.debug("Load Employee records - loadEmployeeListDataCount()");
		EmployeeDAO dao = new EmployeeDAO();
		int count = dao.getTotalByExample(model);
		return count;
	}

	private Boolean validateQueryFields(Map<String, String> params,
			WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		currentfield = fields.get("employeeId");
		fieldValue = params.get("employeeId");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("empName");
		fieldValue = params.get("empName");
		fieldDataMap.put(currentfield, fieldValue);

		currentfield = fields.get("departmentId");
		fieldValue = params.get("departmentId");
		fieldDataMap.put(currentfield, fieldValue);

		return validateFields(fieldDataMap);
	}

	public WorkRequest mkcSubmittedList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		if(workReq!=null && ResponseBase.REQUEST_RESULT_SUCCESS.equals(workReq.getRequestResult())){
			workReq = loadFromMKC(workReq, params,"submit");
		}
		return workReq;
	}

	public WorkRequest mkcReworkList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		if(workReq!=null && ResponseBase.REQUEST_RESULT_SUCCESS.equals(workReq.getRequestResult())){
			workReq = loadFromMKC(workReq, params,"rework");
		}
		return workReq;
	}

	public WorkRequest loadFromMKC(WorkRequest workRequest,Map<String, String> params, String query)
	{
		if (query == null || query.trim().equals("") || (!query.equalsIgnoreCase("rework") && !query.equalsIgnoreCase("submit")))
		{
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail("Invalid query options passed");
			return workRequest;
		}
		try{
			List<MkcQueue> mkcrecords = getAllPendingMKCRequest(requestTypeForFetchingMKCPendingList,query);

			List<EmpListRow> workEmployees = getEmployeesWorkCollection(workRequest);
			for (MkcQueue mkcrec : mkcrecords)
			{
				try {
					ByteArrayInputStream baip = new ByteArrayInputStream(mkcrec.getRecordObj());
					ObjectInputStream ois = new ObjectInputStream(baip);
					MKCWorkRequest mkcWrobj = (MKCWorkRequest) ois.readObject();
					if (mkcWrobj !=null)
					{
						EmpListRow dto = createListRowFromMKC(mkcWrobj, mkcrec.getAction());
						//set the mkcId and record action
						dto.setMkcId(mkcrec.getMkcId());
						dto.setMkcRecordAction(mkcrec.getAction());
						dto.setMkcStatus(mkcrec.getStatus());
						workEmployees.add(dto);
					}
				}catch (Exception e) {
					log.error("Unbale to load records from MKC Queue");
					WorkRequestHelper.getInstance().reportException(log, e, workRequest);
				}
			}
			if (mkcrecords.size()>0)
				workRequest.setLastModified(new Long(mkcrecords.size()));
		}catch (Exception e){
			log.error("unable to load the mkc data");
			WorkRequestHelper.getInstance().reportException(log, e, workRequest);
		}
		return workRequest;
	}

	private EmpListRow createListRowFromMKC(MKCWorkRequest mkcreq, String action)
	{ 
		Map<String, WorkField> mkcFields = mkcreq.getWorkFields();
		WorkField wf = null;
		EmpListRow dto = new EmpListRow();
		// assign the fields to dto record.
		dto.setEmployeeId(StringUtil.isNotEmpty(getFieldValue("employeeId",mkcFields)) ? Integer.parseInt(getFieldValue("employeeId",mkcFields)) : 0);
		dto.setEmpName(getFieldValue("empName",mkcFields));
		dto.setEmail(getFieldValue("email",mkcFields));
		dto.setHireDate(getFieldValue("hireDate",mkcFields));
		return dto;
	}
}
