package com.fis.ist.customProject.services.handler;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.services.MonitorConfigService;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.TransactionListRow;
import com.fis.ist.monitoring.dto.TransactionStatisticsListItem;
import com.efunds.t21.common.util.DateUtil;
import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MonitorConstants;
import com.fis.ist.common.ShcConstants;
import com.fis.ist.customProject.dao.ShcLog;
import com.fis.ist.customProject.dao.ShcLogDAO;
import com.fis.ist.customProject.dao.ShcLogId;
import com.fis.ist.ent.AccessManager;
import com.fis.ist.ent.ShowClearPanPermission;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.customProject.dto.TransactionLogsListRow;
import com.oasis.ent.EntException;
import com.oasis.tokenizer.MappingError;
import com.oasis.tokenizer.Tokenizer;
import com.oasis.tokenizer.TokenizerInterface;

public class TransactionLogsListHandler extends ISTRequestHandler implements ISimpleListHandler{

	private static final ISTLogger log = ISTLogger.getLogger(TransactionLogsListHandler.class);

	private static final String  instUserId       = "ist_inst_Id";
	private static final String  pan              = "ist_pan";
	private static final String  msgTyp           = "ist_msgtype";
	private static final String  localDate        = "ist_local_date";
	private static final String  localDateTo      = "ist_local_date_to";
	private static final String  trace            = "ist_trace";
	private static final String  authNum          = "ist_authnum";
	private static final String  refNum           = "ist_refnum";
	private static final String  resCode          = "ist_respcode";
	private static final String  termId           = "ist_term_id";
	private static final String  acquirer         = "ist_acquirer";
	private static final String  searchBy         = "ist_searchBy";

	//Added for additional search criteria
	private static final String  pcode			  = "ist_pcode";
	private static final String  switchcode		  = "ist_switchcode";
	private static final String  reasoncode	      = "ist_reason_code";
	private static final String  terminaltrace	  = "ist_terminal_trace";
	private static final String  flippedmsgtype	  = "ist_flipped_msgtype";
	private static final String  saf	          = "ist_saf";
	private static final String  alpharesponsecode= "ist_alpharesponsecode";
	private static final String  lifecycle		  = "ist_life_cycle";
	private static final String  localtime		  = "ist_local_time";
	private static final String  transdate		  = "ist_trans_date";
	private static final String  transdateto	  = "ist_trans_date_to";
	private static final String  transtime		  = "ist_trans_time";
	private static final String  capdate		  = "ist_cap_date";
	private static final String  processorbusday  = "ist_processor_busday";
	private static final String  alternateacquirer= "ist_alternateacquirer";
	private static final String  memberid		  = "ist_member_id";
	private static final String  entityid		  = "ist_entity_id";
	private static final String  merchtype		  = "ist_merch_type";
	private static final String  mvv			  = "ist_mvv";
	private static final String  forwid			  = "ist_forwist_id";
	private static final String  acqcountry		  = "ist_acq_country";
	private static final String  issuer			  = "ist_issuer";
	private static final String  issentityid	  = "ist_iss_entityid";
	private static final String  cardproduct	  = "ist_cardproduct";
	private static final String  cardseqno	      = "ist_card_seqno";
	private static final String  acctnum	      = "ist_acctnum";
	private static final String  chiptype	      = "ist_chip_type";
	private static final String  acceptorname	  = "ist_acceptorname";
	private static final String  termloc	      = "ist_termloc";
	private static final String  branch	          = "ist_branch";
	private static final String  devicecap 	      = "ist_device_cap";
	private static final String  invoicenumber	  = "ist_invoice_number";
	private static final String  checkerid	      = "ist_checker_id";
	private static final String  storeid	      = "ist_storeid";
	private static final String  lane	          = "ist_lane";
	private static final String  supervisor		  = "ist_supervisor";
	private static final String  batchid		  = "ist_batch_id";
	private static final String  posentrycode	  = "ist_pos_entry_code";
	private static final String  posconditioncode = "ist_pos_condition_code";
	private static final String  pospincapcode	  = "ist_pos_pin_cap_code";
	private static final String  poscapcode	      = "ist_pos_cap_code";
	private static final String  originator	      = "ist_originator";
	private static final String  txnstarttime	  = "ist_txn_start_time";
	private static final String  txnendtime	      = "ist_txn_end_time";
	private static final String  shcerror	      = "ist_shcerror";
	private static final String  addresponse	  = "ist_addresponse";
	private static final String  devicedevcap	  = "ist_device_devcap";
	private static final String  formatterdevcap  = "ist_formatter_devcap";
	private static final String  shcdevcap	      = "ist_shc_devcap";
	private static final String  authdevcap	      = "ist_auth_devcap";
	private static final String  filler1	      = "ist_filler1";
	private static final String  filler2	      = "ist_filler2";
	private static final String  filler3	      = "ist_filler3";
	private static final String  filler4	      = "ist_filler4";
	private static final String  origmsg	      = "ist_origmsg";
	private static final String  origtrace	      = "ist_origtrace";
	private static final String  origdate	      = "ist_origdate";
	private static final String  origtime	      = "ist_origtime";
	private static final String  transid	      = "ist_trans_id";
	private static final String  revcode	      = "ist_revcode";
	private static final String  origflippedmsg	  = "ist_origflippedmsg";
	private static final String  amount	          = "ist_amount";
	private static final String  newamount	      = "ist_new_amount";
	private static final String  acqavalbalance   = "ist_acq_aval_balance";
	private static final String  acqledgerbalance = "ist_acq_ledger_balance";
	private static final String  cashback	      = "ist_cash_back";
	private static final String  devicefee	      = "ist_device_fee";
	private static final String  acqcurrcode	  = "ist_acq_curr_code";
	private static final String  acqconvrate	  = "ist_acq_conv_rate";
	private static final String  acqconvdate	  = "ist_acq_conv_date";
	private static final String  chamount	      = "ist_ch_amount";
	private static final String  fee	          = "ist_fee";
	private static final String  chnewamount	  = "ist_ch_new_amount";
	private static final String  avalbalance	  = "ist_aval_balance";
	private static final String  ledgerbalance	  = "ist_ledger_balance";
	private static final String  amountequiv	  = "ist_amount_equiv";
	private static final String  chcurrencycode	  = "ist_ch_currency_code";
	private static final String  chconvrate	      = "ist_ch_conv_rate";
	private static final String  chconvdate	      = "ist_ch_conv_date";
	private static final String  settlementdate	  = "ist_settlement_date";
	private static final String  settlementamount = "ist_settlement_amount";
	private static final String  settlementfee	  = "ist_settlement_fee";
	private static final String  newsetlfee	      = "ist_new_setl_fee";
	private static final String  setlavalbalance  = "ist_ setl_aval_balance";
	private static final String  setlledgerbalance= "ist_setl_ledger_balance";
	private static final String  settlementcode	  = "ist_settlement_code";
	private static final String  settlementrate	  = "ist_settlement_rate";
	private static final String  transferee	      = "ist_transferee";
	private static final String  traamount	      = "ist_tra_amount";
	private static final String  tracurrencycode  = "ist_tra_currency_code";
	private static final String  traconvrate	  = "ist_tra_conv_rate";
	private static final String  traconvdate	  = "ist_tra_conv_date";
	private static final String  txnamount	      = "ist_txn_amount";
	private static final String  txnnewamount	  = "ist_txn_new_amount";
	private static final String  txncurrencycode  = "ist_txn_currency_code";
	private static final String  txnconvrate	  = "ist_txn_conv_rate";
	private static final String  txnconvdate	  = "ist_txn_conv_date";
	private static final String  txnconvrate1	  = "ist_txn_conv_rate1";
	private static final String  serial2		  = "ist_serial_2";
	private static final String  txntype	  	  = "ist_txn_type";

	//Not defined in metadata, but used in query criteria
	private static final String  transtimeto	  = "ist_trans_time_to";
	private static final String  settlementdateto = "ist_settlement_date_to";
	private static final String  processorbusdayto  = "ist_processor_busday_to";
	private static final String  shclogRespMsgtype  = "ist_shclog_resp_msgtype";
	private static final String  siteId= "ist_combo_site_id";

	   private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext,
	           UIMetaData uiMetaData,
	           WorkRequestHandlerData data,
	           Map<String, String> params) throws Exception {

		 try {

		   if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW,
					workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);
			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}
			boolean errFlag = validateQueryFields(params,workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}

			load(workRequest, uiMetaData, params);
	      } catch (Exception ex) {
	         throw ex;
	      }
	      return workRequest;
	   }

	   /**  Get device detail information from CED and Rules Engine reverse
	    *   engineering. Populate into a 'pseudo' WorkRequest object for returning
	    *   back to the caller.
	    *  @param UserContext
	    *  @param String (deviceId)
	    *  @return WorkRequest
	    */
	   public WorkRequest list(UserContext userContext, Map<String, String> params) throws Exception {

	      WorkRequest workReq = new WorkRequest();
	      UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(ShcConstants.TRANLOGQR);
	          try {

	             workReq.setRequestId(ShcConstants.TRANLOGQR); // Don't need a real request number just for a device query
	             workReq.setRequestState("DRAFT");
	             workReq.setRequestTypeId(ShcConstants.TRANLOGQR);

	             // Not used for Device Query
	             Map<String, WorkNextState> nextStates = new HashMap<String,WorkNextState>();
	             workReq.setNextStates(nextStates);

	             // Set values of all tabs to be modifiable
	             Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
	             WorkTabStatus workStatus = new WorkTabStatus();
	             workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
	             workStatus.setTag(ShcConstants.TRANSLOGTAB);
	             workStatus.setModifyable("Y");
	             tabStatus.put(ShcConstants.TRANSLOGTAB, workStatus);
	             workReq.setTabStatus(tabStatus);
	             addWorkFields(workReq, uiMetaData);
	             Map<String, WorkField> fields = workReq.getFields();
 	 		     Collection<WorkField> cfields = fields.values();

 	 		     setFieldvalues(cfields,params);
	             workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
	          } catch (Exception ex) {
	        	  WorkRequestHelper.getInstance().reportException(log, ex, workReq);
	          }
	      return workReq;
	   }


	   private void setFieldvalues( Collection<WorkField> cfields, Map<String, String> params){

		   for(WorkField field : cfields) {
		    	if (instUserId.equals(field.getTag())) {
					field.setValue((String) params.get(instUserId));
				}else if(pan.equals(field.getTag())){
					field.setValue((String) params.get(pan));
					// decrypt the value
					//if (field.getValue()!="")
						//field.setValue(decryptData(field.getValue()));
				}else if(msgTyp.equals(field.getTag())){
					field.setValue((String) params.get(msgTyp));
				}else if(localDate.equals(field.getTag())){
					field.setValue((String) params.get(localDate));
				}else if(localDateTo.equals(field.getTag())){
					field.setValue((String) params.get(localDateTo));
				}else if(trace.equals(field.getTag())){
					field.setValue((String) params.get(trace));
				}else if(authNum.equals(field.getTag())){
					field.setValue((String) params.get(authNum));
				}else if(refNum.equals(field.getTag())){
					field.setValue((String) params.get(refNum));
				}else if(resCode.equals(field.getTag())){
					field.setValue((String) params.get(resCode));
				}else if(termId.equals(field.getTag().trim())){ //As there is leading space in the t21_field_md table for this tag
					field.setValue((String) params.get(termId));
				}else if(acquirer.equals(field.getTag())){
					field.setValue((String) params.get(acquirer));
				}else if(pcode.equals(field.getTag())) {
					field.setValue((String) params.get(pcode));
				}else if(switchcode.equals(field.getTag())) {
					field.setValue((String) params.get(switchcode));
				}else if(reasoncode.equals(field.getTag())) {
					field.setValue((String) params.get(reasoncode));
				}else if(terminaltrace.equals(field.getTag())) {
					field.setValue((String) params.get(terminaltrace));
				}else if(flippedmsgtype.equals(field.getTag())) {
					field.setValue((String) params.get(flippedmsgtype));
				}else if(saf.equals(field.getTag())) {
					field.setValue((String) params.get(saf));
				}else if(alpharesponsecode.equals(field.getTag())) {
					field.setValue((String) params.get(alpharesponsecode));
				}else if(lifecycle.equals(field.getTag())) {
					field.setValue((String) params.get(lifecycle));
				}else if(localtime.equals(field.getTag())) {
					field.setValue((String) params.get(localtime));
				}else if(transdate.equals(field.getTag())) {
					field.setValue((String) params.get(transdate));
				}else if(transdateto.equals(field.getTag())) {
					field.setValue((String) params.get(transdateto));
				}else if(transtime.equals(field.getTag())) {
					field.setValue((String) params.get(transtime));
				}else if(capdate.equals(field.getTag())) {
					field.setValue((String) params.get(capdate));
				}else if(processorbusday.equals(field.getTag())) {
					field.setValue((String) params.get(processorbusday));
				}else if(processorbusdayto.equals(field.getTag())) {
					field.setValue((String) params.get(processorbusdayto));
				}else if(alternateacquirer.equals(field.getTag())) {
					field.setValue((String) params.get(alternateacquirer));
				}else if(memberid.equals(field.getTag())) {
					field.setValue((String) params.get(memberid));
				}else if(entityid.equals(field.getTag())) {
					field.setValue((String) params.get(entityid));
				}else if(merchtype.equals(field.getTag())) {
					field.setValue((String) params.get(merchtype));
				}else if(mvv.equals(field.getTag())) {
					field.setValue((String) params.get(mvv));
				}else if(forwid.equals(field.getTag())) {
					field.setValue((String) params.get(forwid));
				}else if(acqcountry.equals(field.getTag())) {
					field.setValue((String) params.get(acqcountry));
				}else if(issuer.equals(field.getTag())) {
					field.setValue((String) params.get(issuer));
				}else if(issentityid.equals(field.getTag())) {
					field.setValue((String) params.get(issentityid));
				}else if(cardproduct.equals(field.getTag())) {
					field.setValue((String) params.get(cardproduct));
				}else if(cardseqno.equals(field.getTag())) {
					field.setValue((String) params.get(cardseqno));
				}else if(acctnum.equals(field.getTag())) {
					field.setValue((String) params.get(acctnum));
				}else if(chiptype.equals(field.getTag())) {
					field.setValue((String) params.get(chiptype));
				}else if(acceptorname.equals(field.getTag())) {
					field.setValue((String) params.get(acceptorname));
				}else if(termloc.equals(field.getTag())) {
					field.setValue((String) params.get(termloc));
				}else if(branch.equals(field.getTag())) {
					field.setValue((String) params.get(branch));
				}else if(invoicenumber.equals(field.getTag())) {
					field.setValue((String) params.get(invoicenumber));
				}else if(devicecap.equals(field.getTag())) {
					field.setValue((String) params.get(devicecap));
				}else if(checkerid.equals(field.getTag())) {
					field.setValue((String) params.get(checkerid));
				}else if(storeid.equals(field.getTag())) {
					field.setValue((String) params.get(storeid));
				}else if(lane.equals(field.getTag())) {
					field.setValue((String) params.get(lane));
				}else if(supervisor.equals(field.getTag())) {
					field.setValue((String) params.get(supervisor));
				}else if(batchid.equals(field.getTag())) {
					field.setValue((String) params.get(batchid));
				}else if(posentrycode.equals(field.getTag())) {
					field.setValue((String) params.get(posentrycode));
				}else if(posconditioncode.equals(field.getTag())) {
					field.setValue((String) params.get(posconditioncode));
				}else if(pospincapcode.equals(field.getTag())) {
					field.setValue((String) params.get(pospincapcode));
				}else if(poscapcode.equals(field.getTag())) {
					field.setValue((String) params.get(poscapcode));
				}else if(originator.equals(field.getTag())) {
					field.setValue((String) params.get(originator));
				}else if(txnstarttime.equals(field.getTag())) {
					field.setValue((String) params.get(txnstarttime));
				}else if(txnendtime.equals(field.getTag())) {
					field.setValue((String) params.get(txnendtime));
				}else if(shcerror.equals(field.getTag())) {
					field.setValue((String) params.get(shcerror));
				}else if(addresponse.equals(field.getTag())) {
					field.setValue((String) params.get(addresponse));
				}else if(devicedevcap.equals(field.getTag())) {
					field.setValue((String) params.get(devicedevcap));
				}else if(formatterdevcap.equals(field.getTag())) {
					field.setValue((String) params.get(formatterdevcap));
				}else if(shcdevcap.equals(field.getTag())) {
					field.setValue((String) params.get(shcdevcap));
				}else if(authdevcap.equals(field.getTag())) {
					field.setValue((String) params.get(authdevcap));
				}else if(filler1.equals(field.getTag())) {
					field.setValue((String) params.get(filler1));
				}else if(filler2.equals(field.getTag())) {
					field.setValue((String) params.get(filler2));
				}else if(filler3.equals(field.getTag())) {
					field.setValue((String) params.get(filler3));
				}else if(filler4.equals(field.getTag())) {
					field.setValue((String) params.get(filler4));
				}else if(origmsg.equals(field.getTag())) {
					field.setValue((String) params.get(origmsg));
				}else if(origtrace.equals(field.getTag())) {
					field.setValue((String) params.get(origtrace));
				}else if(origdate.equals(field.getTag())) {
					field.setValue((String) params.get(origdate));
				}else if(origtime.equals(field.getTag())) {
					field.setValue((String) params.get(origtime));
				}else if(transid.equals(field.getTag())) {
					field.setValue((String) params.get(transid));
				}else if(revcode.equals(field.getTag())) {
					field.setValue((String) params.get(revcode));
				}else if(origflippedmsg.equals(field.getTag())) {
					field.setValue((String) params.get(origflippedmsg));
				}else if(amount.equals(field.getTag())) {
					field.setValue((String) params.get(amount));
				}else if(newamount.equals(field.getTag())) {
					field.setValue((String) params.get(newamount));
				}else if(acqavalbalance.equals(field.getTag())) {
					field.setValue((String) params.get(acqavalbalance));
				}else if(acqledgerbalance.equals(field.getTag())) {
					field.setValue((String) params.get(acqledgerbalance));
				}else if(cashback.equals(field.getTag())) {
					field.setValue((String) params.get(cashback));
				}else if(devicefee.equals(field.getTag())) {
					field.setValue((String) params.get(devicefee));
				}else if(acqcurrcode.equals(field.getTag())) {
					field.setValue((String) params.get(acqcurrcode));
				}else if(acqconvrate.equals(field.getTag())) {
					field.setValue((String) params.get(acqconvrate));
				}else if(acqconvdate.equals(field.getTag())) {
					field.setValue((String) params.get(acqconvdate));
				}else if(chamount.equals(field.getTag())) {
					field.setValue((String) params.get(chamount));
				}else if(fee.equals(field.getTag())) {
					field.setValue((String) params.get(fee));
				}else if(chnewamount.equals(field.getTag())) {
					field.setValue((String) params.get(chnewamount));
				}else if(avalbalance.equals(field.getTag())) {
					field.setValue((String) params.get(avalbalance));
				}else if(ledgerbalance.equals(field.getTag())) {
					field.setValue((String) params.get(ledgerbalance));
				}else if(amountequiv.equals(field.getTag())) {
					field.setValue((String) params.get(amountequiv));
				}else if(chcurrencycode.equals(field.getTag())) {
					field.setValue((String) params.get(chcurrencycode));
				}else if(chconvrate.equals(field.getTag())) {
					field.setValue((String) params.get(chconvrate));
				}else if(chconvdate.equals(field.getTag())) {
					field.setValue((String) params.get(chconvdate));
				}else if(settlementdate.equals(field.getTag())) {
					field.setValue((String) params.get(settlementdate));
				}else if(settlementamount.equals(field.getTag())) {
					field.setValue((String) params.get(settlementamount));
				}else if(settlementfee.equals(field.getTag())) {
					field.setValue((String) params.get(settlementfee));
				}else if(newsetlfee.equals(field.getTag())) {
					field.setValue((String) params.get(newsetlfee));
				}else if( setlavalbalance.equals(field.getTag())) {
					field.setValue((String) params.get(setlavalbalance));
				}else if(setlledgerbalance.equals(field.getTag())) {
					field.setValue((String) params.get(setlledgerbalance));
				}else if(settlementcode.equals(field.getTag())) {
					field.setValue((String) params.get(settlementcode));
				}else if(settlementrate.equals(field.getTag())) {
					field.setValue((String) params.get(settlementrate));
				}else if(transferee.equals(field.getTag())) {
					field.setValue((String) params.get(transferee));
				}else if(traamount.equals(field.getTag())) {
					field.setValue((String) params.get(traamount));
				}else if(tracurrencycode.equals(field.getTag())) {
					field.setValue((String) params.get(tracurrencycode));
				}else if(traconvrate.equals(field.getTag())) {
					field.setValue((String) params.get(traconvrate));
				}else if(traconvdate.equals(field.getTag())) {
					field.setValue((String) params.get(traconvdate));
				}else if(txnamount.equals(field.getTag())) {
					field.setValue((String) params.get(txnamount));
				}else if(txnnewamount.equals(field.getTag())) {
					field.setValue((String) params.get(txnnewamount));
				}else if(txncurrencycode.equals(field.getTag())) {
					field.setValue((String) params.get(txncurrencycode));
				}else if(txnconvrate.equals(field.getTag())) {
					field.setValue((String) params.get(traconvrate));
				}else if(txnconvdate.equals(field.getTag())) {
					field.setValue((String) params.get(txnconvdate));
				}else if(txnconvrate1.equals(field.getTag())) {
						field.setValue((String) params.get(txnconvrate1));
				}else if(serial2.equals(field.getTag())) {
					field.setValue((String) params.get(serial2));
				}else if(txntype.equals(field.getTag())) {
					field.setValue((String) params.get(txntype));
				}else if(settlementdateto.equals(field.getTag())) {
					field.setValue((String) params.get(settlementdateto));
				}else if(transtimeto.equals(field.getTag())) {
					field.setValue((String) params.get(transtimeto));
				}else if(shclogRespMsgtype.equals(field.getTag())) {
					field.setValue((String) params.get(msgTyp));
				}else if(siteId.equals(field.getTag())) {
					field.setValue((String) params.get(siteId));
				}
		    	field.setModifyable("Y");
		    	field.setVisible("Y");
		    }
	   }

	   /**
	    * Initialize the Work Request to include all the fields that are part of all the tabs
	    * on a Device Detail lookup
	    * @param WorkRequest
	    * @param UIMetaData
	    */
	   private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {

			if (workReq.getFields() == null) {
				workReq.setFields(new HashMap<String, WorkField>());
			}

			WorkRequestHelper workHelper = WorkRequestHelper.getInstance();

			workHelper.loadFieldsFromMetadataTab(workReq, uiMetaData, ShcConstants.TRANSLOGTAB);

		    // load other fields based on all the tabs present for Device Detail
		    Collection<WorkTabStatus> tabStatuses = workReq.getTabStatus().values();

		    for (WorkTabStatus tabStatus : tabStatuses) {
		    	 workHelper.loadFieldsFromMetadataTab(workReq, uiMetaData, tabStatus.getTag());
		    }

			WorkField workField = workHelper.createWorkField("", transtimeto, uiMetaData, "");
			workReq.getFields().put(transtimeto, workField);
			workField = workHelper.createWorkField("", settlementdateto, uiMetaData, "");
			workReq.getFields().put(settlementdateto, workField);
			workField = workHelper.createWorkField("", localDateTo, uiMetaData, "");
			workReq.getFields().put(localDateTo, workField);
			workField = workHelper.createWorkField("", transdateto, uiMetaData, "");
			workReq.getFields().put(transdateto, workField);
			workField = workHelper.createWorkField("", processorbusdayto, uiMetaData, "");
			workReq.getFields().put(processorbusdayto, workField);
	   }

	   /**
		* Retrieve the institutions for a Work Request from the institution table and
		* load into a WorkCollection in the WorkRequest
		* @param WorkRequest
		* @param UIMetaData
		*/
	   public void load(WorkRequest workRequest, UIMetaData uiMetaData,Map<String, String> params) throws Exception{
            log.debug("Load  TransactionLogListHandler");
			String insIDVal         = params.get(instUserId);
			String panVal           = params.get(pan);
			String msgtypVal        = params.get(msgTyp);
			String localDateVal     = params.get(localDate);
			String localDateToVal   = params.get(localDateTo);
			String traceVal         = params.get(trace);
			String authNumVal       = params.get(authNum);
			String refNumVal        = params.get(refNum);
			String reCodeVal        = params.get(resCode);
			String termIdVal        = params.get(termId);
			String acquirerVal      = params.get(acquirer);
			String searchByInst     = params.get(searchBy);

			String transDate 		= params.get(settlementdate);
			String transDateTo 		= params.get(settlementdateto);
			String txnDate 			= params.get(transdate);
			String txnDateTo 		= params.get(transdateto);
			String transTime		= params.get(transtime);
			String transTimeTo		= params.get(transtimeto);
			String cardType 		= params.get(cardproduct);
			String accountNumber 	= params.get(acctnum);
			String accountType 		= params.get(pcode);
			String txnType 			= params.get(txntype);
			String device 			= params.get(posentrycode);
			String issuerVal	 	= params.get(issuer);

			String acqAmount		= params.get(amount);
			String amountEquiv		= params.get(amountequiv);
			String memberId 		= params.get(memberid);
			String fId				= params.get(forwid);
			String acqEntityId 		= params.get(entityid);
			String issEntityId		= params.get(issentityid);
			String reasonCode 		= params.get(reasoncode);
			String revCode 			= params.get(revcode);
			String shcError			= params.get(shcerror);
			String merchantType		= params.get(merchtype);
			String acceptorName 	= params.get(acceptorname);
			String termLoc 			= params.get(termloc);
			String issRespCode		= params.get(alpharesponsecode);
			String procDate			= params.get(processorbusday);
			String procDateTo		= params.get(processorbusdayto);
			String safVal 			= params.get(saf);

			String capDate			= params.get(capdate);
			String cashBack			= params.get(cashback);
			String acqCurrCode		= params.get(acqcurrcode);
			String chAmount 		= params.get(chamount);
			String fEe				= params.get(fee);
			String chCurrCode		= params.get(chcurrencycode);
			String settlAmount		= params.get(settlementamount);
			String settlFee			= params.get(settlementfee);
			String settlCode		= params.get(settlementcode);
			String siteId		= params.get(TransactionLogsListHandler.siteId);
			String txnconvdt		= params.get(txnconvdate);
			String txnconvrt		= params.get(txnconvrate1);
			String serial		= params.get(serial2);
			
			
			// To get the proc code desc 
			Map<String, String> procCodes = null;
			TransactionsDAO txnDao = new TransactionsDAO();
			procCodes = txnDao.getProcessingCode("", "PCODE_LIST");
			
			Date date = null;
			/* Pan field masking*/
			AccessManager am = AccessManager.getInstance();
			boolean showClearPan = false;
			try
			{
				showClearPan = am.hasPermission(new ShowClearPanPermission());
			}
			catch (EntException e1)
			{
				log.error("entitlement exception", e1);
			}

			String[] token = null;
			TokenizerInterface tokenizer = new Tokenizer();
			try
			{
				if (panVal!=null && panVal.equals("")==false)
					panVal = decryptData(panVal);
					panVal = panVal.trim();
				token = ISTRequestHandler.padAllOnRight(ISTRequestHandler.panToTokens(tokenizer, panVal), 19);//Char length 19 in DB.It is not depend on auth_pan_pad flag.
			}
			catch (MappingError e)
			{
				if (e.getErrorCode() == MappingError.PAN_NOT_FOUND){
					log.error("PAN NOT FOUND", e);
					return;
				}
				throw e;
			}


			String totalReg =  params.get("ist_total");
			int    pageSize =Integer.parseInt(params.get("ist_page_ctrl"));
			ShcLogDAO  transLogDao=new ShcLogDAO();
			ShcLog shcLog=new ShcLog();
			ShcLogId shcLogId=new ShcLogId();
			Integer total=null;
			int  totalRows =0;
			List<ShcLog> results = null;

			shcLog=setSearchByInstitution(shcLog, searchByInst, insIDVal);
			if(StringUtil.isNotEmpty(siteId)){
				shcLogId.setSiteId(new BigDecimal(siteId));
			}

			shcLog.setPans(token);

			if(StringUtil.isNotEmpty(msgtypVal)){
				shcLog.setMsgtype(BigDecimal.valueOf(Long.parseLong(msgtypVal)));
			 }
			if(StringUtil.isNotEmpty(localDateVal)){
				shcLog.setLocalDate(DateUtil.parseFromDate("MM/dd/yyyy",localDateVal));
			}

			if(StringUtil.isNotEmpty(traceVal)){
				traceVal = traceVal.trim();
				shcLog.setTrace(BigDecimal.valueOf(Long.parseLong(traceVal)));
			 }
			if(StringUtil.isNotEmpty(authNumVal)){
				authNumVal = authNumVal.trim();
				shcLog.setAuthnum((authNumVal.indexOf("*") > -1) ? authNumVal : padOnRight(authNumVal, 6));
			 }
			if(StringUtil.isNotEmpty(refNumVal)){
				refNumVal = refNumVal.trim();
				shcLog.setRefnum((refNumVal.indexOf("*") > -1) ? refNumVal : padOnRight(refNumVal, 12));
			 }
			if(StringUtil.isNotEmpty(reCodeVal)){
				shcLog.setRespcode(BigDecimal.valueOf(Long.parseLong(reCodeVal)));
			 }
			if(StringUtil.isNotEmpty(termIdVal)){
				termIdVal = termIdVal.trim();
				shcLog.setTermid((termIdVal.indexOf("*") > -1) ? termIdVal : padOnRight(termIdVal, 8));
			 }
			if(StringUtil.isNotEmpty(acquirerVal)){
				acquirerVal = acquirerVal.trim();
				shcLog.setAcquirer(padOnLeft(acquirerVal, 10));
			 }

			if(StringUtil.isNotEmpty(transDate)){
				shcLog.setSettlementDate(DateUtil.parseFromDate("MM/dd/yyyy",transDate));
			}
			if(StringUtil.isNotEmpty(txnDate)){
				shcLog.setTrandate(DateUtil.parseFromDate("MM/dd/yyyy",txnDate));
			}
			if(StringUtil.isNotEmpty(transTime)){
				shcLog.setTrantime(new BigDecimal(transTime));
			}
			if(StringUtil.isNotEmpty(accountNumber)){
				accountNumber = accountNumber.trim();
				shcLog.setAcctnum((accountNumber.indexOf("*") > -1) ? accountNumber : padOnRight(accountNumber, 65));
			}
			if(StringUtil.isNotEmpty(txnType)){
				shcLog.setTxntype(new BigDecimal(txnType));
			}
			if(StringUtil.isNotEmpty(issuerVal)){
				shcLog.setIssuer(padOnLeft(issuerVal, 10));
			}
			if(StringUtil.isNotEmpty(transDateTo)){
				date = DateUtil.parseFromDate("MM/dd/yyyy",transDateTo);
			}
			if(StringUtil.isNotEmpty(cardType)){
				cardType = cardType.trim();
				shcLog.setCardproduct(padOnRight(cardType, 10));
			}
			if(StringUtil.isNotEmpty(accountType)){
				accountType = accountType.trim();
				shcLog.setPcode(new BigDecimal(accountType));
			}
			if(StringUtil.isNotEmpty(device)){
				shcLog.setPosEntryCode(new BigDecimal(device));
			}
			if(StringUtil.isNotEmpty(acqAmount)){
				acqAmount = acqAmount.replaceAll(",","");
				acqAmount = acqAmount.trim();
				shcLog.setAmount(new BigDecimal(acqAmount));
			}
			if(StringUtil.isNotEmpty(memberId)){
				memberId = memberId.trim();
				shcLog.setMemberId(padOnRight(memberId, 11));
			}
			if(StringUtil.isNotEmpty(fId)){
				shcLog.setFId(padOnRight(fId, 11));
			}
			if(StringUtil.isNotEmpty(acqEntityId)){
				shcLog.setEntityid(acqEntityId);
			}
			if(StringUtil.isNotEmpty(issEntityId)){
				shcLog.setIssEntityid(issEntityId);
			}
			if(StringUtil.isNotEmpty(reasonCode)){
				reasonCode = reasonCode.trim();
				shcLog.setReasonCode(new BigDecimal(reasonCode));
			}
			if(StringUtil.isNotEmpty(revCode)){
				revCode = revCode.trim();
				shcLog.setRevcode(new BigDecimal(revCode));
			}
			if(StringUtil.isNotEmpty(shcError)){
				shcError = shcError.trim();
				shcLog.setShcerror(new BigDecimal(shcError));
			}
			if(StringUtil.isNotEmpty(merchantType)){
				merchantType = merchantType.trim();
				shcLog.setMerchantType(new BigDecimal(merchantType));
			}
			if(StringUtil.isNotEmpty(acceptorName)){
				acceptorName = acceptorName.trim();
				shcLog.setAcceptorname(padOnRight(acceptorName, 40));
			}
			if(StringUtil.isNotEmpty(termLoc)){
				termLoc = termLoc.trim();
				shcLog.setTermloc(padOnRight(termLoc, 25));
			}
			if(StringUtil.isNotEmpty(issRespCode)){
				issRespCode = issRespCode.trim();
				shcLog.setAlpharesponsecode(padOnRight(issRespCode, 3));
			}
			if(StringUtil.isNotEmpty(procDate)){
				shcLog.setProcessorBusday(DateUtil.parseFromDate("MM/dd/yyyy",procDate));
			}

			Date procDtTo = null;
			if(StringUtil.isNotEmpty(procDateTo)){
				procDtTo = DateUtil.parseFromDate("MM/dd/yyyy",procDateTo);
			}

			if(StringUtil.isNotEmpty(safVal)){
				safVal = safVal.trim();
				shcLog.setSaf(new BigDecimal(safVal));
			}

			shcLog.setId(shcLogId);

			Date lclDtTo = null;
			if(StringUtil.isNotEmpty(localDateToVal)){
				lclDtTo = DateUtil.parseFromDate("MM/dd/yyyy",localDateToVal);
			}

			Date txnDtTo = null;
			if(StringUtil.isNotEmpty(txnDateTo)){
				txnDtTo = DateUtil.parseFromDate("MM/dd/yyyy",txnDateTo);
			}

			if(StringUtil.isNotEmpty(capDate)){
				shcLog.setCapDate(DateUtil.parseFromDate("MM/dd/yyyy",capDate));
			}
			if(StringUtil.isNotEmpty(cashBack)){
				cashBack = cashBack.trim();
				shcLog.setCashBack(new BigDecimal(cashBack));
			}
			if(StringUtil.isNotEmpty(acqCurrCode)){
				shcLog.setAcqCurrencyCode(new BigDecimal(acqCurrCode));
			}
			if(StringUtil.isNotEmpty(chAmount)){
				chAmount = chAmount.replaceAll(",","");
				chAmount = chAmount.trim();
				shcLog.setChAmount(new BigDecimal(chAmount));
			}
			
			if(StringUtil.isNotEmpty(amountEquiv)){
				amountEquiv = amountEquiv.replaceAll(",","");
				amountEquiv = amountEquiv.trim();				
				shcLog.setAmountEquiv(new BigDecimal(amountEquiv));
			}
			
			if(StringUtil.isNotEmpty(fEe)){
				fEe = fEe.trim();
				shcLog.setFee(new BigDecimal(fEe));
			}
			if(StringUtil.isNotEmpty(chCurrCode)){
				shcLog.setChCurrencyCode(new BigDecimal(chCurrCode));
			}
			if(StringUtil.isNotEmpty(settlAmount)){
				settlAmount = settlAmount.replaceAll(",","");
				settlAmount = settlAmount.trim();
				shcLog.setSettlementAmount(new BigDecimal(settlAmount));
			}
			if(StringUtil.isNotEmpty(settlFee)){
				settlFee = settlFee.trim();
				shcLog.setSettlementFee(new BigDecimal(settlFee));
			}
			if(StringUtil.isNotEmpty(settlCode)){
				shcLog.setSettlementCode(new BigDecimal(settlCode));
			}
			if(StringUtil.isNotEmpty(txnconvdt)){
				shcLog.setTxnConvDate(DateUtil.parseFromDate("MM/dd/yyyy",txnconvdt));
			}
			if(StringUtil.isNotEmpty(txnconvrt)){
				shcLog.setTxnConvRate(new BigDecimal(txnconvrt.replaceAll(",", "")));
			}
			if(StringUtil.isNotEmpty(serial)){
				shcLog.setSerial2(new BigDecimal(serial.replaceAll(",", "")));
			}

			results = transLogDao.findByExample_transLog_new(shcLog, pageSize+"", date, StringUtil.isNotEmpty(transTimeTo) ? new BigDecimal(transTimeTo) : null, lclDtTo, txnDtTo, procDtTo);

			if (results == null || results.size() == 0) {
					return;
				}

			    if("Y".equalsIgnoreCase(totalReg)){
					total =  transLogDao.getTotalByExample_transLog_new(shcLog, date, StringUtil.isNotEmpty(transTimeTo) ? new BigDecimal(transTimeTo) : null, lclDtTo, txnDtTo, procDtTo);
				}

			if(total!=null){
			  totalRows = total!=null?total.intValue():0;
			  if(totalRows ==0)
			     workRequest.setLastModified((long)-1);
			  else
				  workRequest.setLastModified((long)totalRows);
			 }
			
			TransactionsDAO dao = new TransactionsDAO();
			MonitorConfigService configService = new MonitorConfigService();
			List<String> businessDeclineList = configService.getDeclineRespCodes(dao, MonitorConstants.BD_RESP_CODE_LIST);
			List<String> technicalDeclineList = configService.getDeclineRespCodes(dao, MonitorConstants.TD_RESP_CODE_LIST);
			List<TransactionStatisticsListItem> respCodesAndDesc = configService.getResponseCodesAndDesc(dao);
			
			List<TransactionLogsListRow> workTransLogList = getNewWorkReqTransLog(workRequest);

			if (results == null || results.size() == 0) {
				return;
			}

			 for (ShcLog model : results)
			   {
					if(model != null){
						TransactionLogsListRow dto = new TransactionLogsListRow();
						String pcode="";
						dto.load(model);

						if (dto.getMaskedPan()!=null && dto.getMaskedPan().equals("")==false)
							dto.setMaskedPan(encryptData(dto.getMaskedPan()));

						setDeclineCategory(businessDeclineList, technicalDeclineList, dto);
						setRespCodeDesc(respCodesAndDesc, dto);
						
						try {
							if(dto.getPcode().length()<6)
								dto.setPcode(("000000" + dto.getPcode()).substring(dto.getPcode().length()));
							pcode=String.valueOf((Integer.parseInt(dto.getPcode())/10000));
							dto.setpCodeDesc(procCodes.get(pcode));
						}catch (Exception e) {
							dto.setpCodeDesc("");
						}
						workTransLogList.add(dto);
					}
			   }
			   TransactionLogsListRow.clearCache();
		}
	   
	   private void setDeclineCategory(List<String> businessDeclineList, List<String> technicalDeclineList, TransactionLogsListRow dto)
	   {
		   String declineCategory = PaymonUtils.getDeclineCategoryByRespCode(businessDeclineList, technicalDeclineList, dto.getRespcode());
		   dto.setDeclineCategory(declineCategory);
	   }
	   
	   private void setRespCodeDesc(List<TransactionStatisticsListItem> respCodesAndDesc, TransactionLogsListRow dto)
	   {
		   String respCodeDesc = PaymonUtils.getRespDescByCode(respCodesAndDesc, dto.getRespcode());
		   dto.setRespCodeDesc(respCodeDesc);
	   }

		private List getNewWorkReqTransLog(WorkRequest workRequest) {
			WorkCollection workCollection = new WorkCollection();
			workCollection.setErrorInfo("");
			workCollection.setModifyable("N");
			workCollection.setVisible("Y");
			workCollection.setTag(ShcConstants.TRANSLOGCOL);

			workRequest.getCollections().put(workCollection.getTag(), workCollection);

			List<TransactionLogsListRow> workReqList = new ArrayList<TransactionLogsListRow>();
			workCollection.setRows(workReqList);

			return workReqList;
		}

		private String padOnLeft(String val, int size)
		{
			if (val != null)
			{
				int sz = val.length();
				if (sz > 0 && sz < size)
				{
					StringBuilder b = new StringBuilder(size);
					for (int i = size-sz; i > 0; --i){
						b.append(' ');
					}
					b.append(val);
					val = b.toString();
				}
			}
			return val;
		}

		 private ShcLog setSearchByInstitution(ShcLog dto, String searchBy, String institution){

				if("S".equalsIgnoreCase(searchBy)){
					dto.setTxnsrc(institution);
				}else if("D".equalsIgnoreCase(searchBy)){
					dto.setTxndest(institution);
				}else if("B".equalsIgnoreCase(searchBy)){
					dto.setTxnsrc(institution);
					dto.setTxndest(institution);
				}
				return dto;
			}


			private Boolean validateQueryFields(Map<String, String> params,
					WorkRequest workReq) {
			   	   Map<String, WorkField> fields = workReq.getFields();
			   	   Map <WorkField,String> fieldDataMap = new HashMap<WorkField, String>();
			   	   String fieldValue = "";
			   	   WorkField currentfield = null;

					currentfield = fields.get(instUserId);
					fieldValue = params.get(instUserId);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(pan);
					fieldValue = params.get(pan);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(msgTyp);
					fieldValue = params.get(msgTyp);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(localDate);
					fieldValue = params.get(localDate);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(localDateTo);
					fieldValue = params.get(localDateTo);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(trace);
					fieldValue = params.get(trace);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(authNum);
					fieldValue = params.get(authNum);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(refNum);
					fieldValue = params.get(refNum);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(resCode);
					fieldValue = params.get(resCode);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(termId);
					fieldValue = params.get(termId);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(acquirer);
					fieldValue = params.get(acquirer);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(searchBy);
					fieldValue = params.get(searchBy);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(settlementdate);
					fieldValue = params.get(settlementdate);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(settlementdateto);
					fieldValue = params.get(settlementdateto);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(transdate);
					fieldValue = params.get(transdate);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(transdateto);
					fieldValue = params.get(transdateto);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(transtime);
					fieldValue = params.get(transtime);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(transtimeto);
					fieldValue = params.get(transtimeto);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(cardproduct);
					fieldValue = params.get(cardproduct);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(acctnum);
					fieldValue = params.get(acctnum);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(pcode);
					fieldValue = params.get(pcode);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(txntype);
					fieldValue = params.get(txntype);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(posentrycode);
					fieldValue = params.get(posentrycode);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(issuer);
					fieldValue = params.get(issuer);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(amount);
					fieldValue = params.get(amount);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(memberid);
					fieldValue = params.get(memberid);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(forwid);
					fieldValue = params.get(forwid);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(entityid);
					fieldValue = params.get(entityid);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(issentityid);
					fieldValue = params.get(issentityid);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(reasoncode);
					fieldValue = params.get(reasoncode);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(revcode);
					fieldValue = params.get(revcode);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(shcerror);
					fieldValue = params.get(shcerror);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(merchtype);
					fieldValue = params.get(merchtype);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(acceptorname);
					fieldValue = params.get(acceptorname);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(termloc);
					fieldValue = params.get(termloc);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(alpharesponsecode);
					fieldValue = params.get(alpharesponsecode);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(processorbusday);
					fieldValue = params.get(processorbusday);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(processorbusdayto);
					fieldValue = params.get(processorbusdayto);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(saf);
					fieldValue = params.get(saf);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(capdate);
					fieldValue = params.get(capdate);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(cashback);
					fieldValue = params.get(cashback);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(acqcurrcode);
					fieldValue = params.get(acqcurrcode);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(chamount);
					fieldValue = params.get(chamount);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(fee);
					fieldValue = params.get(fee);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(chcurrencycode);
					fieldValue = params.get(chcurrencycode);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(settlementamount);
					fieldValue = params.get(settlementamount);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(settlementfee);
					fieldValue = params.get(settlementfee);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(settlementcode);
					fieldValue = params.get(settlementcode);
					fieldDataMap.put(currentfield,fieldValue);
					
					currentfield = fields.get(txnconvrate1);
					fieldValue = params.get(txnconvrate1);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(txnconvdate);
					fieldValue = params.get(txnconvdate);
					fieldDataMap.put(currentfield,fieldValue);

					currentfield = fields.get(serial2);
					fieldValue = params.get(serial2);
					fieldDataMap.put(currentfield,fieldValue);

			   	   return validateFields(fieldDataMap);
			}
		}