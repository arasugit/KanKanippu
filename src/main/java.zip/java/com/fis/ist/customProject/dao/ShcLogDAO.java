package com.fis.ist.customProject.dao;

import java.util.Date;
import org.hibernate.query.Query;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.DateType;
import org.hibernate.type.DoubleType;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.hibernate.type.Type;
import org.hibernate.Hibernate;
import java.text.DateFormat;
import java.util.Map;
import java.util.ArrayList;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import com.efunds.t21.common.util.StringUtil;
import java.util.HashMap;
import org.hibernate.criterion.Projections;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;

import com.efunds.t21.common.util.StringPadder;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import java.util.List;
import java.math.BigDecimal;
import com.fis.ist.log.ISTLogger;
import org.apache.logging.log4j.Logger;
import com.fis.ist.monitoring.dao.MonitorBaseDAO;

public class ShcLogDAO extends MonitorBaseDAO<ShcLog, ShcLogId>
{
    private static final ISTLogger log;
    private BigDecimal[] msgTypFrsList;
    
    static {
        log = ISTLogger.getLogger((Class)ShcLogDAO.class);
    }
    
    public ShcLogDAO() {
        this.msgTypFrsList = new BigDecimal[] { new BigDecimal(100), new BigDecimal(110), new BigDecimal(200), new BigDecimal(210), new BigDecimal(9620), new BigDecimal(9630) };
    }
    
    public List<ShcLog> findByExample(final ShcLog instance, final String pageNum) {
        ShcLogDAO.log.debug((String)"finding ShcLog instance by example");
        Session session = null;
        int currPage = 0;
        try {
            session = this.getSession();
            if (pageNum != null) {
                currPage = Integer.parseInt(pageNum);
            }
            Criteria criteria = session.createCriteria((Class)ShcLog.class);
            if (instance.getId() != null && instance.getId().getChipIndex() != null) {
                criteria.add((Criterion)Restrictions.eq("id.chipIndex", (Object)instance.getId().getChipIndex()));
            }
            if (instance.getId() != null && instance.getId().getSiteId() != null) {
                criteria.add((Criterion)Restrictions.eq("id.siteId", (Object)instance.getId().getSiteId()));
            }
            if (instance.getTxnsrc() != null) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            if (instance.getTxndest() != null) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            if (instance.getPan() != null) {
                final String panVal = StringPadder.pad(instance.getPan(), 19);
                criteria.add((Criterion)Restrictions.eq("pan", (Object)panVal));
            }
            else if (instance.getPans() != null && instance.getPans().length > 0) {
                criteria.add(Restrictions.in("pan", (Object[])instance.getPans()));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.eq("localDate", (Object)instance.getLocalDate()));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getPcode() != null) {
                criteria.add((Criterion)Restrictions.eq("pcode", (Object)instance.getPcode()));
            }
            if (instance.getTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("trace", (Object)instance.getTrace()));
            }
            if (instance.getAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("amount", (Object)instance.getAmount()));
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = StringPadder.pad(instance.getAuthnum(), 6);
                criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = StringPadder.pad(instance.getRefnum(), 12);
                criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.eq("respcode", (Object)instance.getRespcode()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            criteria = criteria.addOrder(Order.desc("localTime"));
            this.setPaging(criteria, currPage);
            return (List<ShcLog>)criteria.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
    }
    
    public Integer getTotalByExample(final ShcLog instance) {
        ShcLogDAO.log.debug((String)"finding ShcLog total count by example");
        Session session = null;
        Integer count = null;
        try {
            session = this.getSession();
            final Criteria criteria = session.createCriteria((Class)ShcLog.class);
            criteria.setProjection(Projections.rowCount());
            if (instance.getId() != null && instance.getId().getChipIndex() != null) {
                criteria.add((Criterion)Restrictions.eq("id.chipIndex", (Object)instance.getId().getChipIndex()));
            }
            if (instance.getId() != null && instance.getId().getSiteId() != null) {
                final BigDecimal siteId = instance.getId().getSiteId();
                if (siteId != null) {
                    criteria.add((Criterion)Restrictions.eq("id.siteId", (Object)siteId));
                }
            }
            if (instance.getTxnsrc() != null) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            if (instance.getTxndest() != null) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            if (instance.getPan() != null) {
                final String panVal = StringPadder.pad(instance.getPan(), 19);
                criteria.add((Criterion)Restrictions.eq("pan", (Object)panVal));
            }
            else if (instance.getPans() != null && instance.getPans().length > 0) {
                criteria.add(Restrictions.in("pan", (Object[])instance.getPans()));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.eq("localDate", (Object)instance.getLocalDate()));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getPcode() != null) {
                criteria.add((Criterion)Restrictions.eq("pcode", (Object)instance.getPcode()));
            }
            if (instance.getTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("trace", (Object)instance.getTrace()));
            }
            if (instance.getAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("amount", (Object)instance.getAmount()));
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = StringPadder.pad(instance.getAuthnum(), 6);
                criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = StringPadder.pad(instance.getRefnum(), 12);
                criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.eq("respcode", (Object)instance.getRespcode()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            final Long sLong = (Long)criteria.uniqueResult();
            if (sLong != null) {
                count = sLong.intValue();
            }
            else {
                count = 0;
            }
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
        return count;
    }
    
    public List<ShcLog> findByExampleFRS(final ShcLog instance, final String pageNum) {
        ShcLogDAO.log.debug((String)"finding ShcLog instance by example");
        Session session = null;
        int currPage = 0;
        try {
            session = this.getSession();
            if (pageNum != null) {
                currPage = Integer.parseInt(pageNum);
            }
            final Criteria criteria = session.createCriteria((Class)ShcLog.class);
            if (instance.getTxnsrc() != null) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            if (instance.getTxndest() != null) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            if (instance.getPan() != null) {
                final String panVal = StringPadder.pad(instance.getPan(), 19);
                criteria.add((Criterion)Restrictions.eq("pan", (Object)panVal));
            }
            else if (instance.getPans() != null && instance.getPans().length > 0) {
                criteria.add(Restrictions.in("pan", (Object[])instance.getPans()));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            else {
                criteria.add(Restrictions.in("msgtype", (Object[])this.msgTypFrsList));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.eq("localDate", (Object)instance.getLocalDate()));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getPcode() != null) {
                criteria.add((Criterion)Restrictions.eq("pcode", (Object)instance.getPcode()));
            }
            if (instance.getTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("trace", (Object)instance.getTrace()));
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = StringPadder.pad(instance.getAuthnum(), 6);
                criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = StringPadder.pad(instance.getRefnum(), 12);
                criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.eq("respcode", (Object)instance.getRespcode()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            this.setPaging(criteria, currPage);
            return (List<ShcLog>)criteria.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
    }
    
    public Integer getTotalByExampleFRS(final ShcLog instance) {
        ShcLogDAO.log.debug((String)"finding ShcLog total count by example");
        Session session = null;
        Integer count = null;
        try {
            session = this.getSession();
            final Criteria criteria = session.createCriteria((Class)ShcLog.class);
            criteria.setProjection(Projections.rowCount());
            if (instance.getTxnsrc() != null) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            if (instance.getTxndest() != null) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            if (instance.getPan() != null) {
                final String panVal = StringPadder.pad(instance.getPan(), 19);
                criteria.add((Criterion)Restrictions.eq("pan", (Object)panVal));
            }
            else if (instance.getPans() != null && instance.getPans().length > 0) {
                criteria.add(Restrictions.in("pan", (Object[])instance.getPans()));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            else {
                criteria.add(Restrictions.in("msgtype", (Object[])this.msgTypFrsList));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.eq("localDate", (Object)instance.getLocalDate()));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getPcode() != null) {
                criteria.add((Criterion)Restrictions.eq("pcode", (Object)instance.getPcode()));
            }
            if (instance.getTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("trace", (Object)instance.getTrace()));
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = StringPadder.pad(instance.getAuthnum(), 6);
                criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = StringPadder.pad(instance.getRefnum(), 12);
                criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.eq("respcode", (Object)instance.getRespcode()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            final Long sLong = (Long)criteria.uniqueResult();
            if (sLong != null) {
                count = sLong.intValue();
            }
            else {
                count = 0;
            }
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
        return count;
    }
    
    public List<ShcLog> findByExampleForCaa(final ShcLog instance, final String startDate, final String endDate, final int pageNum) {
        ShcLogDAO.log.debug((String)"findByExampleForCaa - ShcLog instance by example");
        try {
            final Session session = this.getSession();
            Criteria c = session.createCriteria("com.fis.ist.common.dao.ShcLog");
            final Map<String, Object> condition = new HashMap<String, Object>();
            condition.put("msgtype", BigDecimal.valueOf(Long.parseLong("110")));
            String value = null;
            value = instance.getTxnsrc();
            if (StringUtil.isNotEmpty(value)) {
                condition.put("txnsrc", value);
            }
            value = instance.getPan();
            if (StringUtil.isNotEmpty(value)) {
                condition.put("pan", value);
            }
            else if (instance.getPans() != null && instance.getPans().length > 0) {
                c = c.add(Restrictions.in("pan", (Object[])instance.getPans()));
            }
            value = instance.getCardproduct();
            if (StringUtil.isNotEmpty(value)) {
                condition.put("cardproduct", value);
            }
            DateFormat sdf = null;
            if (StringUtil.isNotEmpty(startDate)) {
                sdf = new SimpleDateFormat("MM/dd/yyyy");
                try {
                    c.add((Criterion)Restrictions.ge("trandate", (Object)sdf.parse(startDate)));
                }
                catch (ParseException e) {
                    ShcLogDAO.log.error((String)"find by example startDate parsing", (Throwable)e);
                }
            }
            if (StringUtil.isNotEmpty(endDate)) {
                sdf = ((sdf == null) ? new SimpleDateFormat("MM/dd/yyyy") : sdf);
                try {
                    c.add((Criterion)Restrictions.le("trandate", (Object)sdf.parse(endDate)));
                }
                catch (ParseException e) {
                    ShcLogDAO.log.error((String)"find by example endDate parsing", (Throwable)e);
                }
            }
            List<ShcLog> results = new ArrayList<ShcLog>();
            c = c.add(Restrictions.allEq((Map)condition));
            this.setPaging(c, pageNum);
            results = (List<ShcLog>)c.list();
            ShcLogDAO.log.debug((String)("findByExampleForCaa successful, result size: " + results.size()));
            return results;
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
    }
    
    public Integer getTotalByExampleForCaa(final ShcLog instance, final String startDate, final String endDate) {
        ShcLogDAO.log.debug((String)"getTotalByExampleForCaa");
        Integer count = null;
        try {
            final Session session = this.getSession();
            Criteria c = session.createCriteria("com.fis.ist.common.dao.ShcLog");
            c.setProjection(Projections.rowCount());
            final Map<String, Object> condition = new HashMap<String, Object>();
            condition.put("msgtype", BigDecimal.valueOf(Long.parseLong("110")));
            String value = null;
            value = instance.getTxnsrc();
            if (StringUtil.isNotEmpty(value)) {
                condition.put("txnsrc", value);
            }
            value = instance.getPan();
            if (StringUtil.isNotEmpty(value)) {
                condition.put("pan", value);
            }
            else if (instance.getPans() != null && instance.getPans().length > 0) {
                c = c.add(Restrictions.in("pan", (Object[])instance.getPans()));
            }
            value = instance.getCardproduct();
            if (StringUtil.isNotEmpty(value)) {
                condition.put("cardproduct", value);
            }
            DateFormat sdf = null;
            if (StringUtil.isNotEmpty(startDate)) {
                sdf = new SimpleDateFormat("MM/dd/yyyy");
                try {
                    c.add((Criterion)Restrictions.ge("trandate", (Object)sdf.parse(startDate)));
                }
                catch (ParseException e) {
                    ShcLogDAO.log.error((String)"find by example startDate parsing", (Throwable)e);
                }
            }
            if (StringUtil.isNotEmpty(endDate)) {
                sdf = ((sdf == null) ? new SimpleDateFormat("MM/dd/yyyy") : sdf);
                try {
                    c.add((Criterion)Restrictions.le("trandate", (Object)sdf.parse(endDate)));
                }
                catch (ParseException e) {
                    ShcLogDAO.log.error((String)"find by example endDate parsing", (Throwable)e);
                }
            }
            final Long sLong = (Long)c.add(Restrictions.allEq((Map)condition)).uniqueResult();
            if (sLong != null) {
                count = sLong.intValue();
            }
            else {
                count = 0;
            }
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"getTotalByExampleForCaa failed", (Throwable)re);
            throw re;
        }
        return count;
    }
    
    public List getVisaFRSTrans(final ShcLog shcLogListVal, final String transType) {
        try {
            final StringBuffer queryBuffer = new StringBuffer();
            queryBuffer.append(" SELECT SHCLOG.MSGTYPE MSGTYPE, SHCLOG.PAN PAN, SHCLOG.AMOUNT AMOUNT,SHCLOG.TRANDATE TRANSDATE, SHCLOG.TRANTIME TRANSTIME, SHCLOG.TRACE TRACE,SHCLOG.LOCAL_DATE LOCALDATE,SHCLOG.LOCAL_TIME  LOCALTIME,SHCLOG.MERCHANT_TYPE MERCHTYPE,SHCLOG.POS_ENTRY_CODE POSENTRYCODE, SHCLOG.CARD_SEQNO SEQNO, SHCLOG.ACQUIRER ACQUIRER,SHCLOG.ISSUER ISSUER, SHCLOG.F_ID FID, SHCLOG.REFNUM REFNUM, SHCLOG.AUTHNUM AUTHNUM,SHCLOG.TERMID TERMID, SHCLOG.TERMLOC TERMLOC, SHCLOG.ACCEPTORNAME ACCNAME,SHCLOG.ACQ_CURRENCY_CODE CURRCODE,SHCLOG.POS_CAP_CODE POSCAPCODE,SHCLOG.CASH_BACK CASHBACK, SHCLOG.TRANS_ID TRANSID,SHCLOG.ACQUIRER_DATA ACQUDATA,SHCLOG.ISSUER_DATA ISSUDATA, SHCLOG.TXNSRC TXNSRC,SHCLOG.RESPCODE RESPCODE ,SHCLOG.SETTLEMENT_DATE SETTLEDATE ,SHCLOG.CH_AMOUNT CHAMOUNT,SHCLOG.FEE CHFEE ,SHCLOG.CH_CURRENCY_CODE CHCURRCODE ,SHCLOG.TERMLOC CARDACCID,SHCLOG.ISS_ENTITYID ISSENT,SHCLOG_VFRS.EXPR_DATE EXPDATE, SHCLOG_VFRS.FRAUD_INFO FRAUDINFO,SHCLOG_VFRS.POS_GEO_LOC POSGEOLOC, SHCLOG_VFRS.NETCODE NETCDE,SHCLOG_VFRS.RCVG_INST_ID RCVINSTID, SHCLOG_VFRS.ADDTL_TRACE_DATA ADDTRACEDATA,SHCLOG_VFRS.SUPPORT_INFO SUPPINFO FROM SHCLOG JOIN SHCLOG_VFRS ON SHCLOG.CHIP_INDEX = SHCLOG_VFRS.SHCLOG_IDX WHERE SHCLOG.MSGTYPE = ? AND SHCLOG.PAN = ? AND SHCLOG.TXNSRC = ?AND SHCLOG.CHIP_INDEX = ?");
            final String queryString = queryBuffer.toString();
            Query queryObject = null;
            queryObject = (Query)this.getSession().createSQLQuery(queryString).addScalar("TXNSRC", StringType.INSTANCE).addScalar("PAN", StringType.INSTANCE).addScalar("LOCALDATE", StringType.INSTANCE).addScalar("LOCALTIME", StringType.INSTANCE).addScalar("MSGTYPE", StringType.INSTANCE).addScalar("TRACE", StringType.INSTANCE).addScalar("REFNUM", StringType.INSTANCE).addScalar("AUTHNUM", StringType.INSTANCE).addScalar("SEQNO", StringType.INSTANCE).addScalar("TRANSDATE", StringType.INSTANCE).addScalar("TRANSTIME", StringType.INSTANCE).addScalar("SETTLEDATE", DateType.INSTANCE).addScalar("RESPCODE", StringType.INSTANCE).addScalar("AMOUNT", StringType.INSTANCE).addScalar("CASHBACK", StringType.INSTANCE).addScalar("CURRCODE", StringType.INSTANCE).addScalar("CHAMOUNT", StringType.INSTANCE).addScalar("CHFEE", StringType.INSTANCE).addScalar("CHCURRCODE", StringType.INSTANCE).addScalar("ACQUIRER", StringType.INSTANCE).addScalar("FID", StringType.INSTANCE).addScalar("MERCHTYPE", StringType.INSTANCE).addScalar("CARDACCID", StringType.INSTANCE).addScalar("ISSUER", StringType.INSTANCE).addScalar("ISSENT", StringType.INSTANCE).addScalar("TERMID", StringType.INSTANCE).addScalar("ACCNAME", StringType.INSTANCE).addScalar("TERMLOC", StringType.INSTANCE).addScalar("POSENTRYCODE", StringType.INSTANCE).addScalar("POSCAPCODE", StringType.INSTANCE).addScalar("ACQUDATA", StringType.INSTANCE).addScalar("ISSUDATA", StringType.INSTANCE).addScalar("EXPDATE", StringType.INSTANCE).addScalar("FRAUDINFO", StringType.INSTANCE).addScalar("POSGEOLOC", StringType.INSTANCE).addScalar("NETCDE", StringType.INSTANCE).addScalar("RCVINSTID", StringType.INSTANCE).addScalar("ADDTRACEDATA", StringType.INSTANCE).addScalar("SUPPINFO", StringType.INSTANCE);
            queryObject.setParameter(0, (Object)shcLogListVal.getMsgtype());
            queryObject.setParameter(1, (Object)shcLogListVal.getPan());
            queryObject.setParameter(2, (Object)shcLogListVal.getTxnsrc());
            queryObject.setParameter(3, (Object)shcLogListVal.getId().getChipIndex());
            return queryObject.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"Query Fails", (Throwable)re);
            throw re;
        }
    }
    
    public List getVisaFinancialTrans(final ShcLog shcLogListVal, final String transType) {
        try {
            final StringBuffer queryBuffer = new StringBuffer();
            queryBuffer.append(" SELECT SHCLOG.MSGTYPE MSGTYPE, SHCLOG.PAN PAN, SHCLOG.AMOUNT AMOUNT,SHCLOG.TRANDATE TRANSDATE, SHCLOG.TRANTIME TRANSTIME, SHCLOG.TRACE TRACE,SHCLOG.LOCAL_DATE LOCALDATE,SHCLOG.LOCAL_TIME  LOCALTIME,SHCLOG.MERCHANT_TYPE MERCHTYPE,SHCLOG.POS_ENTRY_CODE POSENTRYCODE, SHCLOG.CARD_SEQNO SEQNO, SHCLOG.ACQUIRER ACQUIRER,SHCLOG.ISSUER ISSUER, SHCLOG.F_ID FID, SHCLOG.REFNUM REFNUM, SHCLOG.AUTHNUM AUTHNUM,SHCLOG.TERMID TERMID, SHCLOG.TERMLOC TERMLOC, SHCLOG.ACCEPTORNAME ACCNAME,SHCLOG.ACQ_CURRENCY_CODE CURRCODE,SHCLOG.POS_CAP_CODE POSCAPCODE,SHCLOG.CASH_BACK CASHBACK, SHCLOG.TRANS_ID TRANSID,SHCLOG.ACQUIRER_DATA ACQUDATA,SHCLOG.ISSUER_DATA ISSUDATA, SHCLOG.TXNSRC TXNSRC,SHCLOG.TXNDEST TXNDEST,SHCLOG.RESPCODE RESPCODE ,SHCLOG.SETTLEMENT_DATE SETTLEDATE ,SHCLOG.CH_AMOUNT CHAMOUNT,SHCLOG.FEE CHFEE ,SHCLOG.CH_CURRENCY_CODE CHCURRCODE ,SHCLOG.TERMLOC CARDACCID,SHCLOG.ISS_ENTITYID ISSENT FROM SHCLOG WHERE SHCLOG.MSGTYPE = ? AND SHCLOG.PAN = ? AND SHCLOG.TXNSRC = ? AND SHCLOG.CHIP_INDEX = ? AND (ACQUIRER_DATA LIKE 'VISA%' OR ISSUER_DATA LIKE 'VISA%')");
            final String queryString = queryBuffer.toString();
            final Query queryObject = (Query)this.getSession().createSQLQuery(queryString).addScalar("TXNSRC", StringType.INSTANCE).addScalar("PAN", StringType.INSTANCE).addScalar("LOCALDATE", StringType.INSTANCE).addScalar("LOCALTIME", StringType.INSTANCE).addScalar("MSGTYPE", StringType.INSTANCE).addScalar("TRACE", StringType.INSTANCE).addScalar("REFNUM", StringType.INSTANCE).addScalar("AUTHNUM", StringType.INSTANCE).addScalar("SEQNO", StringType.INSTANCE).addScalar("TRANSDATE", StringType.INSTANCE).addScalar("TRANSTIME", StringType.INSTANCE).addScalar("SETTLEDATE", DateType.INSTANCE).addScalar("RESPCODE", StringType.INSTANCE).addScalar("AMOUNT", StringType.INSTANCE).addScalar("CASHBACK", StringType.INSTANCE).addScalar("CURRCODE", StringType.INSTANCE).addScalar("CHAMOUNT", StringType.INSTANCE).addScalar("CHFEE", StringType.INSTANCE).addScalar("CHCURRCODE", StringType.INSTANCE).addScalar("ACQUIRER", StringType.INSTANCE).addScalar("FID", StringType.INSTANCE).addScalar("MERCHTYPE", StringType.INSTANCE).addScalar("CARDACCID", StringType.INSTANCE).addScalar("ISSUER", StringType.INSTANCE).addScalar("ISSENT", StringType.INSTANCE).addScalar("TERMID", StringType.INSTANCE).addScalar("ACCNAME", StringType.INSTANCE).addScalar("TERMLOC", StringType.INSTANCE).addScalar("POSENTRYCODE", StringType.INSTANCE).addScalar("POSCAPCODE", StringType.INSTANCE).addScalar("ACQUDATA", StringType.INSTANCE).addScalar("ISSUDATA", StringType.INSTANCE).addScalar("TXNDEST", StringType.INSTANCE);
            queryObject.setParameter(0, (Object)shcLogListVal.getMsgtype());
            queryObject.setParameter(1, (Object)shcLogListVal.getPan());
            queryObject.setParameter(2, (Object)shcLogListVal.getTxnsrc());
            queryObject.setParameter(3, (Object)shcLogListVal.getId().getChipIndex());
            return queryObject.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"Query Fails", (Throwable)re);
            throw re;
        }
    }
    
    public List loadMerchantAccountActivityListProperty(final String institutionId, String merchantNumber, String cardType, String cardNumber, final String mcc, final String merchantStatus, final Date startDate, final Date endDate, final int pageNum) {
        Integer countPosition = -1;
        try {
            final StringBuffer queryBuffer = new StringBuffer();
            if (merchantStatus != null && !merchantStatus.equals("")) {
                queryBuffer.append("select sl.pan as pan,sl.local_date as localDate,sl.local_time as localTime,sl.amount as amount,sl.txntype as txntype,sl.respcode as respcode,sl.authnum as authnum,sl.addresponse as addresponse,sl.refnum as refnum from shclog sl,acq_entity acq where sl.entityid=acq.entity_id and sl.txnsrc=acq.institution_id");
            }
            else {
                queryBuffer.append("select sl.pan as pan,sl.local_date as localDate,sl.local_time as localTime,sl.amount as amount,sl.txntype as txntype,sl.respcode as respcode,sl.authnum as authnum,sl.addresponse as addresponse,sl.refnum as refnum from shclog sl");
            }
            if (institutionId != null && !institutionId.equals("")) {
                if (merchantStatus != null && !merchantStatus.equals("")) {
                    queryBuffer.append(" and sl.txnsrc=?");
                }
                else {
                    queryBuffer.append(" where sl.txnsrc=?");
                }
            }
            queryBuffer.append(" and sl.msgtype=?");
            if (merchantNumber != null && !merchantNumber.equals("")) {
                if (merchantNumber.indexOf("*") > -1) {
                    merchantNumber = merchantNumber.replace("*", "%");
                    queryBuffer.append(" and sl.entityid like ?");
                }
                else {
                    queryBuffer.append(" and sl.entityid=?");
                }
            }
            if (cardType != null && !cardType.equals("")) {
                while (cardType.length() < 10) {
                    cardType = String.valueOf(cardType) + " ";
                }
                queryBuffer.append(" and sl.cardproduct=?");
            }
            if (cardNumber != null && !cardNumber.equals("")) {
                if (cardNumber.indexOf("*") > -1) {
                    cardNumber = cardNumber.replace("*", "%");
                    queryBuffer.append(" and sl.pan like ?");
                }
                else {
                    queryBuffer.append(" and sl.pan=?");
                }
            }
            if (mcc != null && !mcc.equals("")) {
                queryBuffer.append(" and sl.merchant_Type=?");
            }
            if (merchantStatus != null && !merchantStatus.equals("")) {
                queryBuffer.append(" and acq.entity_Status=?");
            }
            if (startDate != null && endDate != null) {
                queryBuffer.append(" and sl.trandate between ? and ?");
            }
            else if (startDate != null) {
                queryBuffer.append(" and sl.trandate >= ?");
            }
            else if (endDate != null) {
                queryBuffer.append(" and sl.trandate <= ?");
            }
            final String queryString = queryBuffer.toString();
            final Query queryObject = (Query)this.getSession().createSQLQuery(queryString).addScalar("pan", StringType.INSTANCE).addScalar("localDate", DateType.INSTANCE).addScalar("localTime", StringType.INSTANCE).addScalar("amount", DoubleType.INSTANCE).addScalar("txntype", BigDecimalType.INSTANCE).addScalar("respcode", BigDecimalType.INSTANCE).addScalar("authnum", StringType.INSTANCE).addScalar("addresponse", StringType.INSTANCE).addScalar("refnum", StringType.INSTANCE);
            if (institutionId != null && !institutionId.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)institutionId);
            }
            queryObject.setParameter((int)(++countPosition), (Object)new BigDecimal("110"));
            if (merchantNumber != null && !merchantNumber.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)merchantNumber);
            }
            if (cardType != null && !cardType.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)cardType);
            }
            if (cardNumber != null && !cardNumber.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)cardNumber);
            }
            if (mcc != null && !mcc.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)new BigDecimal(mcc));
            }
            if (merchantStatus != null && !merchantStatus.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)merchantStatus);
            }
            if (startDate != null && endDate != null) {
                queryObject.setParameter((int)(++countPosition), (Object)startDate);
                queryObject.setParameter((int)(++countPosition), (Object)endDate);
            }
            else if (startDate != null) {
                queryObject.setParameter((int)(++countPosition), (Object)startDate);
            }
            else if (endDate != null) {
                queryObject.setParameter((int)(++countPosition), (Object)endDate);
            }
            if (pageNum == -1) {
                return queryObject.list();
            }
            this.setPaging((org.hibernate.query.Query) queryObject, pageNum);
            return queryObject.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"Query Fails", (Throwable)re);
            throw re;
        }
    }
    
    public Long merchantTotalCount(final String institutionId, String merchantNumber, String cardType, String cardNumber, final String mcc, final String merchantStatus, final Date startDate, final Date endDate) {
        Integer countPosition = -1;
        try {
            final StringBuffer queryBuffer = new StringBuffer();
            List list = null;
            if (merchantStatus != null && !merchantStatus.equals("")) {
                queryBuffer.append("select count(*) as total from shclog sl,acq_entity acq where sl.entityid=acq.entity_id and sl.txnsrc=acq.institution_id");
            }
            else {
                queryBuffer.append("select  count(*) as total from shclog sl");
            }
            if (institutionId != null && !institutionId.equals("")) {
                if (merchantStatus != null && !merchantStatus.equals("")) {
                    queryBuffer.append(" and sl.txnsrc=?");
                }
                else {
                    queryBuffer.append(" where sl.txnsrc=?");
                }
            }
            queryBuffer.append(" and sl.msgtype=?");
            if (merchantNumber != null && !merchantNumber.equals("")) {
                if (merchantNumber.indexOf("*") > -1) {
                    merchantNumber = merchantNumber.replace("*", "%");
                    queryBuffer.append(" and sl.entityid like ?");
                }
                else {
                    queryBuffer.append(" and sl.entityid=?");
                }
            }
            if (cardType != null && !cardType.equals("")) {
                while (cardType.length() < 10) {
                    cardType = String.valueOf(cardType) + " ";
                }
                queryBuffer.append(" and sl.cardproduct=?");
            }
            if (cardNumber != null && !cardNumber.equals("")) {
                if (cardNumber.indexOf("*") > -1) {
                    cardNumber = cardNumber.replace("*", "%");
                    queryBuffer.append(" and sl.pan like ?");
                }
                else {
                    queryBuffer.append(" and sl.pan=?");
                }
            }
            if (mcc != null && !mcc.equals("")) {
                queryBuffer.append(" and sl.merchant_Type=?");
            }
            if (merchantStatus != null && !merchantStatus.equals("")) {
                queryBuffer.append(" and acq.entity_Status=?");
            }
            if (startDate != null && endDate != null) {
                queryBuffer.append(" and sl.trandate between ? and ?");
            }
            else if (startDate != null) {
                queryBuffer.append(" and sl.trandate >= ?");
            }
            else if (endDate != null) {
                queryBuffer.append(" and sl.trandate <= ?");
            }
            final String queryString = queryBuffer.toString();
            final Query queryObject = (Query)this.getSession().createSQLQuery(queryString).addScalar("total", StringType.INSTANCE);
            if (institutionId != null && !institutionId.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)institutionId);
            }
            queryObject.setParameter((int)(++countPosition), (Object)new BigDecimal("110"));
            if (merchantNumber != null && !merchantNumber.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)merchantNumber);
            }
            if (cardType != null && !cardType.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)cardType);
            }
            if (cardNumber != null && !cardNumber.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)cardNumber);
            }
            if (mcc != null && !mcc.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)new BigDecimal(mcc));
            }
            if (merchantStatus != null && !merchantStatus.equals("")) {
                queryObject.setParameter((int)(++countPosition), (Object)merchantStatus);
            }
            if (startDate != null && endDate != null) {
                queryObject.setParameter((int)(++countPosition), (Object)startDate);
                queryObject.setParameter((int)(++countPosition), (Object)endDate);
            }
            else if (startDate != null) {
                queryObject.setParameter((int)(++countPosition), (Object)startDate);
            }
            else if (endDate != null) {
                queryObject.setParameter((int)(++countPosition), (Object)endDate);
            }
            list = queryObject.list();
            if (list.size() > 0) {
                return Long.parseLong(String.valueOf(list.get(0)));
            }
            return 0L;
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"Query Fails", (Throwable)re);
            throw re;
        }
    }
    
    public List<ShcLog> findByExample_transLog(final ShcLog instance, final String pageNum) {
        ShcLogDAO.log.debug((String)"finding ShcLog instance by example");
        Session session = null;
        int currPage = 0;
        try {
            session = this.getSession();
            if (pageNum != null) {
                currPage = Integer.parseInt(pageNum);
            }
            final Criteria criteria = session.createCriteria((Class)ShcLog.class);
            final String txnSrc = instance.getTxnsrc();
            final String txnDxt = instance.getTxndest();
            if (StringUtil.isNotEmpty(txnSrc) && StringUtil.isNotEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.or((Criterion)Restrictions.eq("txnsrc", (Object)txnSrc), (Criterion)Restrictions.eq("txndest", (Object)txnDxt)));
            }
            else if (StringUtil.isNotEmpty(txnSrc) && StringUtil.isEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            else if (StringUtil.isEmpty(txnSrc) && StringUtil.isNotEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            if (instance.getPan() != null) {
                final String panVal = StringPadder.pad(instance.getPan(), 19);
                criteria.add((Criterion)Restrictions.eq("pan", (Object)panVal));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.eq("localDate", (Object)instance.getLocalDate()));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getPcode() != null) {
                criteria.add((Criterion)Restrictions.eq("pcode", (Object)instance.getPcode()));
            }
            if (instance.getTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("trace", (Object)instance.getTrace()));
            }
            if (instance.getTermid() != null) {
                criteria.add((Criterion)Restrictions.eq("termid", (Object)instance.getTermid()).ignoreCase());
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = StringPadder.pad(instance.getAuthnum(), 6);
                criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = StringPadder.pad(instance.getRefnum(), 12);
                criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.eq("respcode", (Object)instance.getRespcode()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("amount", (Object)instance.getAmount()));
            }
            if (instance.getTerminalTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("terminalTrace", (Object)instance.getTerminalTrace()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            criteria.addOrder(Order.desc("localTime"));
            this.setPaging(criteria, currPage);
            return (List<ShcLog>)criteria.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
    }
    
    public List<ShcLog> findByExample_transLog_new(final ShcLog instance, final String pageNum, final Date tranDateTo, final BigDecimal tranTimeTo, final Date localDateTo, final Date txnDateTo, final Date procDtTo) {
        ShcLogDAO.log.debug((String)"finding ShcLog instance by example(new method)");
        Session session = null;
        int currPage = 0;
        String cardProduct = null;
        cardProduct = instance.getCardproduct();
       
        try {
            session = this.getSession();
            if (pageNum != null) {
                currPage = Integer.parseInt(pageNum);
            }
            Criteria criteria = session.createCriteria((Class)ShcLog.class);
            final String txnSrc = instance.getTxnsrc();
            final String txnDxt = instance.getTxndest();
            if (StringUtil.isNotEmpty(txnSrc) && StringUtil.isNotEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.or((Criterion)Restrictions.eq("txnsrc", (Object)txnSrc), (Criterion)Restrictions.eq("txndest", (Object)txnDxt)));
            }
            else if (StringUtil.isNotEmpty(txnSrc) && StringUtil.isEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            else if (StringUtil.isEmpty(txnSrc) && StringUtil.isNotEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            final BigDecimal siteId = instance.getId().getSiteId();
            if (siteId != null) {
                criteria.add((Criterion)Restrictions.eq("id.siteId", (Object)siteId));
            }
            if (instance.getPans() != null && instance.getPans().length > 0) {
                criteria.add(Restrictions.in("pan", (Object[])instance.getPans()));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.ge("localDate", (Object)instance.getLocalDate()));
            }
            if (localDateTo != null) {
                criteria.add((Criterion)Restrictions.le("localDate", (Object)localDateTo));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getPcode() != null) {
                criteria.add(Restrictions.sqlRestriction("SUBSTR(pcode, 2, 2)=?", (Object)instance.getPcode().toPlainString(), StringType.INSTANCE));
            }
            if (instance.getTrace() != null) {
                final String trace = instance.getTrace().toPlainString();
                if (StringUtil.isNotEmpty(trace)) {
                    if (trace.length() >= 7 || trace.length() < 6) {
                        criteria.add(Restrictions.sqlRestriction("trace=?", (Object)trace, StringType.INSTANCE));
                    }
                    else if (trace.length() == 6) {
                        criteria.add(Restrictions.sqlRestriction("SUBSTR(trace, 2)=?", (Object)trace, StringType.INSTANCE));
                    }
                }
            }
            if (instance.getTermid() != null) {
                if (instance.getTermid().indexOf("*") > -1) {
                    criteria.add(Restrictions.ilike("termid", (Object)instance.getTermid().replace('*', '%')));
                }
                else {
                    criteria.add((Criterion)Restrictions.eq("termid", (Object)instance.getTermid()).ignoreCase());
                }
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = instance.getAuthnum();
                if (authNumVal.indexOf("*") > -1) {
                    criteria.add(Restrictions.ilike("authnum", (Object)authNumVal.replace('*', '%')));
                }
                else {
                    criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
                }
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = instance.getRefnum();
                if (refNumVal.indexOf("*") > -1) {
                    criteria.add(Restrictions.ilike("refnum", (Object)refNumVal.replace('*', '%')));
                }
                else {
                    criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
                }
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.eq("respcode", (Object)instance.getRespcode()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("amount", (Object)instance.getAmount()));
            }
            if (instance.getAmountEquiv() != null) {
                criteria.add((Criterion)Restrictions.eq("amountEquiv", (Object)instance.getAmountEquiv()));
            }
            if (instance.getTerminalTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("terminalTrace", (Object)instance.getTerminalTrace()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            if (instance.getSettlementDate() != null) {
                criteria.add((Criterion)Restrictions.ge("settlementDate", (Object)instance.getSettlementDate()));
            }
            if (tranDateTo != null) {
                criteria.add((Criterion)Restrictions.le("settlementDate", (Object)tranDateTo));
            }
            if (instance.getTrandate() != null) {
                criteria.add((Criterion)Restrictions.ge("trandate", (Object)instance.getTrandate()));
            }
            if (txnDateTo != null) {
                criteria.add((Criterion)Restrictions.le("trandate", (Object)txnDateTo));
            }
            if (instance.getTrantime() != null) {
                criteria.add((Criterion)Restrictions.ge("trantime", (Object)instance.getTrantime()));
            }
            if (tranTimeTo != null) {
                criteria.add((Criterion)Restrictions.le("trantime", (Object)tranTimeTo));
            }
            final String acct = instance.getAcctnum();
            if (StringUtil.isNotEmpty(acct)) {
                if (acct.indexOf("*") > -1) {
                    criteria.add((Criterion)Restrictions.like("acctnum", (Object)acct.replace('*', '%')));
                }
                else {
                    criteria.add((Criterion)Restrictions.eq("acctnum", (Object)acct));
                }
            }
            if (instance.getTxntype() != null) {
                criteria.add((Criterion)Restrictions.eq("txntype", (Object)instance.getTxntype()));
            }
            if (StringUtil.isNotEmpty(instance.getIssuer())) {
                criteria.add((Criterion)Restrictions.eq("issuer", (Object)instance.getIssuer()));
            }
            if (StringUtil.isNotEmpty(instance.getCardproduct())) {
                criteria.add((Criterion)Restrictions.eq("cardproduct", cardProduct));
            }
            if (instance.getPosEntryCode() != null) {
                this.constructCriteria(instance.getPosEntryCode(), criteria);
            }
            if (StringUtil.isNotEmpty(instance.getMemberId())) {
                criteria.add((Criterion)Restrictions.eq("memberId", (Object)instance.getMemberId()));
            }
            if (StringUtil.isNotEmpty(instance.getFId())) {
                criteria.add((Criterion)Restrictions.eq("FId", (Object)instance.getFId()));
            }
            if (StringUtil.isNotEmpty(instance.getEntityid())) {
                if (instance.getEntityid().indexOf("*") > -1) {
                    criteria.add(Restrictions.ilike("entityid", (Object)instance.getEntityid().trim().replace('*', '%')));
                }
                else {
                    criteria.add((Criterion)Restrictions.eq("entityid", (Object)instance.getEntityid()));
                }
            }
            if (StringUtil.isNotEmpty(instance.getIssEntityid())) {
                criteria.add((Criterion)Restrictions.eq("issEntityid", (Object)instance.getIssEntityid()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getRevcode() != null) {
                criteria.add((Criterion)Restrictions.eq("revcode", (Object)instance.getRevcode()));
            }
            if (instance.getShcerror() != null) {
                criteria.add((Criterion)Restrictions.eq("shcerror", (Object)instance.getShcerror()));
            }
            if (instance.getMerchantType() != null) {
                criteria.add((Criterion)Restrictions.eq("merchantType", (Object)instance.getMerchantType()));
            }
            if (StringUtil.isNotEmpty(instance.getAcceptorname())) {
                criteria.add((Criterion)Restrictions.eq("acceptorname", (Object)instance.getAcceptorname()));
            }
            if (StringUtil.isNotEmpty(instance.getTermloc())) {
                criteria.add((Criterion)Restrictions.eq("termloc", (Object)instance.getTermloc()));
            }
            if (StringUtil.isNotEmpty(instance.getAlpharesponsecode())) {
                criteria.add((Criterion)Restrictions.eq("alpharesponsecode", (Object)instance.getAlpharesponsecode()));
            }
            if (instance.getProcessorBusday() != null) {
                criteria.add((Criterion)Restrictions.ge("processorBusday", (Object)instance.getProcessorBusday()));
            }
            if (procDtTo != null) {
                criteria.add((Criterion)Restrictions.le("processorBusday", (Object)procDtTo));
            }
            if (instance.getSaf() != null) {
                criteria.add((Criterion)Restrictions.eq("saf", (Object)instance.getSaf()));
            }
            if (instance.getCapDate() != null) {
                criteria.add((Criterion)Restrictions.eq("capDate", (Object)instance.getCapDate()));
            }
            if (instance.getCashBack() != null) {
                criteria.add((Criterion)Restrictions.eq("cashBack", (Object)instance.getCashBack()));
            }
            if (instance.getAcqCurrencyCode() != null) {
                criteria.add((Criterion)Restrictions.eq("acqCurrencyCode", (Object)instance.getAcqCurrencyCode()));
            }
            if (instance.getChAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("chAmount", (Object)instance.getChAmount()));
            }
            if (instance.getFee() != null) {
                criteria.add((Criterion)Restrictions.eq("fee", (Object)instance.getFee()));
            }
            if (instance.getChCurrencyCode() != null) {
                criteria.add((Criterion)Restrictions.eq("chCurrencyCode", (Object)instance.getChCurrencyCode()));
            }
            if (instance.getSettlementAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("settlementAmount", (Object)instance.getSettlementAmount()));
            }
            if (instance.getSettlementFee() != null) {
                criteria.add((Criterion)Restrictions.eq("settlementFee", (Object)instance.getSettlementFee()));
            }
            if (instance.getSettlementCode() != null) {
                criteria.add((Criterion)Restrictions.eq("settlementCode", (Object)instance.getSettlementCode()));
            }
            if (instance.getTxnConvDate() != null) {
                criteria.add((Criterion)Restrictions.eq("txnConvDate", (Object)instance.getTxnConvDate()));
            }
            if (instance.getTxnConvRate() != null) {
                criteria.add((Criterion)Restrictions.eq("txnConvRate", (Object)instance.getTxnConvRate()));
            }
            if (instance.getSerial2() != null) {
                criteria.add((Criterion)Restrictions.eq("serial2", (Object)instance.getSerial2()));
            }
            
            // Selecting specific columns using projectionList
            ProjectionList projectionList = Projections.projectionList();
            projectionList.add(Projections.property("origmsg"),"origMsg");
            projectionList.add(Projections.property("origdate"),"origDate");
            projectionList.add(Projections.property("origtrace"),"origTrace");
            projectionList.add(Projections.property("origtime"),"origTime");

            
            criteria = criteria.addOrder(Order.desc("localDate")).addOrder(Order.desc("localTime"));
            this.setPaging(criteria, currPage);
            return (List<ShcLog>)criteria.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
    }
    
    public Integer getTotalByExample_transLog(final ShcLog instance) {
        ShcLogDAO.log.debug((String)"finding ShcLog total count by example");
        Session session = null;
        Integer count = null;
        try {
            session = this.getSession();
            final Criteria criteria = session.createCriteria((Class)ShcLog.class);
            criteria.setProjection(Projections.rowCount());
            final String txnSrc = instance.getTxnsrc();
            final String txnDxt = instance.getTxndest();
            if (StringUtil.isNotEmpty(txnSrc) && StringUtil.isNotEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.or((Criterion)Restrictions.eq("txnsrc", (Object)txnSrc), (Criterion)Restrictions.eq("txndest", (Object)txnDxt)));
            }
            else if (StringUtil.isNotEmpty(txnSrc) && StringUtil.isEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            else if (StringUtil.isEmpty(txnSrc) && StringUtil.isNotEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            if (instance.getPan() != null) {
                final String panVal = StringPadder.pad(instance.getPan(), 19);
                criteria.add((Criterion)Restrictions.eq("pan", (Object)panVal));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.eq("localDate", (Object)instance.getLocalDate()));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getTermid() != null) {
                criteria.add((Criterion)Restrictions.eq("termid", (Object)instance.getTermid()).ignoreCase());
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getPcode() != null) {
                criteria.add((Criterion)Restrictions.eq("pcode", (Object)instance.getPcode()));
            }
            if (instance.getTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("trace", (Object)instance.getTrace()));
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = StringPadder.pad(instance.getAuthnum(), 6);
                criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = StringPadder.pad(instance.getRefnum(), 12);
                criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
            }
            if (instance.getAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("amount", (Object)instance.getAmount()));
            }
            if (instance.getTerminalTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("terminalTrace", (Object)instance.getTerminalTrace()));
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.eq("respcode", (Object)instance.getRespcode()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            final Long sLong = (Long)criteria.uniqueResult();
            if (sLong != null) {
                count = sLong.intValue();
            }
            else {
                count = 0;
            }
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
        return count;
    }
    
    public Integer getTotalByExample_transLog_new(final ShcLog instance, final Date tranDateTo, final BigDecimal tranTimeTo, final Date localDateTo, final Date txnDateTo, final Date procDtTo) {
        ShcLogDAO.log.debug((String)"finding ShcLog total count by example(new method)");
        Session session = null;
        Integer count = null;
        try {
            session = this.getSession();
            String cardProduct = null;
            cardProduct = instance.getCardproduct();
            final Criteria criteria = session.createCriteria((Class)ShcLog.class);
            criteria.setProjection(Projections.rowCount());
            final String txnSrc = instance.getTxnsrc();
            final String txnDxt = instance.getTxndest();
            if (StringUtil.isNotEmpty(txnSrc) && StringUtil.isNotEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.or((Criterion)Restrictions.eq("txnsrc", (Object)txnSrc), (Criterion)Restrictions.eq("txndest", (Object)txnDxt)));
            }
            else if (StringUtil.isNotEmpty(txnSrc) && StringUtil.isEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            else if (StringUtil.isEmpty(txnSrc) && StringUtil.isNotEmpty(txnDxt)) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            final BigDecimal siteId = instance.getId().getSiteId();
            if (siteId != null) {
                criteria.add((Criterion)Restrictions.eq("id.siteId", (Object)siteId));
            }
            if (instance.getPans() != null && instance.getPans().length > 0) {
                criteria.add(Restrictions.in("pan", (Object[])instance.getPans()));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.ge("localDate", (Object)instance.getLocalDate()));
            }
            if (localDateTo != null) {
                criteria.add((Criterion)Restrictions.le("localDate", (Object)localDateTo));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getTermid() != null) {
                if (instance.getTermid().indexOf("*") > -1) {
                    criteria.add(Restrictions.ilike("termid", (Object)instance.getTermid().replace('*', '%')));
                }
                else {
                    criteria.add((Criterion)Restrictions.eq("termid", (Object)instance.getTermid()).ignoreCase());
                }
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getPcode() != null) {
                criteria.add(Restrictions.sqlRestriction("SUBSTR(pcode, 2, 2)=?", (Object)instance.getPcode().toPlainString(), StringType.INSTANCE));
            }
            if (instance.getTrace() != null) {
                final String trace = instance.getTrace().toPlainString();
                if (StringUtil.isNotEmpty(trace)) {
                    if (trace.length() >= 7 || trace.length() < 6) {
                        criteria.add(Restrictions.sqlRestriction("trace=?", (Object)trace, StringType.INSTANCE));
                    }
                    else if (trace.length() == 6) {
                        criteria.add(Restrictions.sqlRestriction("SUBSTR(trace, 2)=?", (Object)trace, StringType.INSTANCE));
                    }
                }
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = instance.getAuthnum();
                if (authNumVal.indexOf("*") > -1) {
                    criteria.add(Restrictions.ilike("authnum", (Object)authNumVal.replace('*', '%')));
                }
                else {
                    criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
                }
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = instance.getRefnum();
                if (refNumVal.indexOf("*") > -1) {
                    criteria.add(Restrictions.ilike("refnum", (Object)refNumVal.replace('*', '%')));
                }
                else {
                    criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
                }
            }
            if (instance.getAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("amount", (Object)instance.getAmount()));
            }
            if (instance.getTerminalTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("terminalTrace", (Object)instance.getTerminalTrace()));
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.eq("respcode", (Object)instance.getRespcode()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            if (instance.getSettlementDate() != null) {
                criteria.add((Criterion)Restrictions.ge("settlementDate", (Object)instance.getSettlementDate()));
            }
            if (tranDateTo != null) {
                criteria.add((Criterion)Restrictions.le("settlementDate", (Object)tranDateTo));
            }
            if (instance.getTrandate() != null) {
                criteria.add((Criterion)Restrictions.ge("trandate", (Object)instance.getTrandate()));
            }
            if (txnDateTo != null) {
                criteria.add((Criterion)Restrictions.le("trandate", (Object)txnDateTo));
            }
            if (instance.getTrantime() != null) {
                criteria.add((Criterion)Restrictions.ge("trantime", (Object)instance.getTrantime()));
            }
            if (tranTimeTo != null) {
                criteria.add((Criterion)Restrictions.le("trantime", (Object)tranTimeTo));
            }
            final String acct = instance.getAcctnum();
            if (StringUtil.isNotEmpty(acct)) {
                if (acct.indexOf("*") > -1) {
                    criteria.add((Criterion)Restrictions.like("acctnum", (Object)acct.replace('*', '%')));
                }
                else {
                    criteria.add((Criterion)Restrictions.eq("acctnum", (Object)acct));
                }
            }
            if (instance.getTxntype() != null) {
                criteria.add((Criterion)Restrictions.eq("txntype", (Object)instance.getTxntype()));
            }
            if (StringUtil.isNotEmpty(instance.getIssuer())) {
                criteria.add((Criterion)Restrictions.eq("issuer", (Object)instance.getIssuer()));
            }
            if (StringUtil.isNotEmpty(instance.getCardproduct())) {
                criteria.add((Criterion)Restrictions.eq("cardproduct", cardProduct));
            }
            if (instance.getPosEntryCode() != null) {
                this.constructCriteria(instance.getPosEntryCode(), criteria);
            }
            if (StringUtil.isNotEmpty(instance.getMemberId())) {
                criteria.add((Criterion)Restrictions.eq("memberId", (Object)instance.getMemberId()));
            }
            if (StringUtil.isNotEmpty(instance.getFId())) {
                criteria.add((Criterion)Restrictions.eq("FId", (Object)instance.getFId()));
            }
            if (StringUtil.isNotEmpty(instance.getEntityid())) {
                if (instance.getEntityid().indexOf("*") > -1) {
                    criteria.add(Restrictions.ilike("entityid", (Object)instance.getEntityid().trim().replace('*', '%')));
                }
                else {
                    criteria.add((Criterion)Restrictions.eq("entityid", (Object)instance.getEntityid()));
                }
            }
            if (StringUtil.isNotEmpty(instance.getIssEntityid())) {
                criteria.add((Criterion)Restrictions.eq("issEntityid", (Object)instance.getIssEntityid()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getRevcode() != null) {
                criteria.add((Criterion)Restrictions.eq("revcode", (Object)instance.getRevcode()));
            }
            if (instance.getShcerror() != null) {
                criteria.add((Criterion)Restrictions.eq("shcerror", (Object)instance.getShcerror()));
            }
            if (instance.getMerchantType() != null) {
                criteria.add((Criterion)Restrictions.eq("merchantType", (Object)instance.getMerchantType()));
            }
            if (StringUtil.isNotEmpty(instance.getAcceptorname())) {
                criteria.add((Criterion)Restrictions.eq("acceptorname", (Object)instance.getAcceptorname()));
            }
            if (StringUtil.isNotEmpty(instance.getTermloc())) {
                criteria.add((Criterion)Restrictions.eq("termloc", (Object)instance.getTermloc()));
            }
            if (StringUtil.isNotEmpty(instance.getAlpharesponsecode())) {
                criteria.add((Criterion)Restrictions.eq("alpharesponsecode", (Object)instance.getAlpharesponsecode()));
            }
            if (instance.getProcessorBusday() != null) {
                criteria.add((Criterion)Restrictions.ge("processorBusday", (Object)instance.getProcessorBusday()));
            }
            if (procDtTo != null) {
                criteria.add((Criterion)Restrictions.le("processorBusday", (Object)procDtTo));
            }
            if (instance.getSaf() != null) {
                criteria.add((Criterion)Restrictions.eq("saf", (Object)instance.getSaf()));
            }
            if (instance.getCapDate() != null) {
                criteria.add((Criterion)Restrictions.eq("capDate", (Object)instance.getCapDate()));
            }
            if (instance.getCashBack() != null) {
                criteria.add((Criterion)Restrictions.eq("cashBack", (Object)instance.getCashBack()));
            }
            if (instance.getAcqCurrencyCode() != null) {
                criteria.add((Criterion)Restrictions.eq("acqCurrencyCode", (Object)instance.getAcqCurrencyCode()));
            }
            if (instance.getChAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("chAmount", (Object)instance.getChAmount()));
            }
            if (instance.getFee() != null) {
                criteria.add((Criterion)Restrictions.eq("fee", (Object)instance.getFee()));
            }
            if (instance.getChCurrencyCode() != null) {
                criteria.add((Criterion)Restrictions.eq("chCurrencyCode", (Object)instance.getChCurrencyCode()));
            }
            if (instance.getSettlementAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("settlementAmount", (Object)instance.getSettlementAmount()));
            }
            if (instance.getSettlementFee() != null) {
                criteria.add((Criterion)Restrictions.eq("settlementFee", (Object)instance.getSettlementFee()));
            }
            if (instance.getSettlementCode() != null) {
                criteria.add((Criterion)Restrictions.eq("settlementCode", (Object)instance.getSettlementCode()));
            }
            if (instance.getTxnConvDate() != null) {
                criteria.add((Criterion)Restrictions.eq("txnConvDate", (Object)instance.getTxnConvDate()));
            }
            if (instance.getTxnConvRate() != null) {
                criteria.add((Criterion)Restrictions.eq("txnConvRate", (Object)instance.getTxnConvRate()));
            }
            if (instance.getSerial2() != null) {
                criteria.add((Criterion)Restrictions.eq("serial2", (Object)instance.getSerial2()));
            }
            final Long sLong = (Long)criteria.uniqueResult();
            if (sLong != null) {
                count = sLong.intValue();
            }
            else {
                count = 0;
            }
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
        return count;
    }
    
    public List getCurrentDateAndTime() {
        try {
            final StringBuffer queryBuffer = new StringBuffer();
            queryBuffer.append("SELECT SYSDATE FROM DUAL");
            final String queryString = queryBuffer.toString();
            final Query queryObject = (Query)this.getSession().createSQLQuery(queryString).addScalar("SYSDATE", TimestampType.INSTANCE);
            return queryObject.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"Date Query Fails", (Throwable)re);
            throw re;
        }
    }
    
    public Class<ShcLog> getEntityClass() {
        return ShcLog.class;
    }
    
    public List<ShcLog> findByExampleBOAdjustment(final ShcLog instance, final String pageNum) {
        ShcLogDAO.log.debug((String)"finding ShcLog instance by example");
        Session session = null;
        int currPage = 0;
        try {
            session = this.getSession();
            if (pageNum != null) {
                currPage = Integer.parseInt(pageNum);
            }
            Criteria criteria = session.createCriteria((Class)ShcLog.class);
            if (instance.getId() != null && instance.getId().getChipIndex() != null) {
                criteria.add((Criterion)Restrictions.eq("id.chipIndex", (Object)instance.getId().getChipIndex()));
            }
            if (instance.getTxnsrc() != null) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            if (instance.getTxndest() != null) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            if (instance.getPan() != null) {
                final String panVal = StringPadder.pad(instance.getPan(), 19);
                criteria.add((Criterion)Restrictions.eq("pan", (Object)panVal));
            }
            else if (instance.getPans() != null && instance.getPans().length > 0) {
                criteria.add(Restrictions.in("pan", (Object[])instance.getPans()));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.eq("localDate", (Object)instance.getLocalDate()));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getPcode() != null) {
                criteria.add((Criterion)Restrictions.eq("pcode", (Object)instance.getPcode()));
            }
            if (instance.getTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("trace", (Object)instance.getTrace()));
            }
            if (instance.getAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("amount", (Object)instance.getAmount()));
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = StringPadder.pad(instance.getAuthnum(), 6);
                criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = StringPadder.pad(instance.getRefnum(), 12);
                criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.or((Criterion)Restrictions.eq("respcode", (Object)0), (Criterion)Restrictions.eq("respcode", (Object)112)));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            criteria = criteria.addOrder(Order.desc("localTime"));
            this.setPaging(criteria, currPage);
            return (List<ShcLog>)criteria.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
    }
    
    public Integer getTotalByExampleBOAdjustment(final ShcLog instance) {
        ShcLogDAO.log.debug((String)"finding ShcLog total count by example");
        Session session = null;
        Integer count = null;
        try {
            session = this.getSession();
            final Criteria criteria = session.createCriteria((Class)ShcLog.class);
            criteria.setProjection(Projections.rowCount());
            if (instance.getId() != null && instance.getId().getChipIndex() != null) {
                criteria.add((Criterion)Restrictions.eq("id.chipIndex", (Object)instance.getId().getChipIndex()));
            }
            if (instance.getTxnsrc() != null) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            if (instance.getTxndest() != null) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            if (instance.getPan() != null) {
                final String panVal = StringPadder.pad(instance.getPan(), 19);
                criteria.add((Criterion)Restrictions.eq("pan", (Object)panVal));
            }
            else if (instance.getPans() != null && instance.getPans().length > 0) {
                criteria.add(Restrictions.in("pan", (Object[])instance.getPans()));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.eq("localDate", (Object)instance.getLocalDate()));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getPcode() != null) {
                criteria.add((Criterion)Restrictions.eq("pcode", (Object)instance.getPcode()));
            }
            if (instance.getTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("trace", (Object)instance.getTrace()));
            }
            if (instance.getAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("amount", (Object)instance.getAmount()));
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = StringPadder.pad(instance.getAuthnum(), 6);
                criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = StringPadder.pad(instance.getRefnum(), 12);
                criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.or((Criterion)Restrictions.eq("respcode", (Object)0), (Criterion)Restrictions.eq("respcode", (Object)112)));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            final Long sLong = (Long)criteria.uniqueResult();
            if (sLong != null) {
                count = sLong.intValue();
            }
            else {
                count = 0;
            }
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
        return count;
    }
    
    public List<ShcLog> findByExampleForVoiceAuthCapture(final ShcLog instance, final String pageNum) {
        ShcLogDAO.log.debug((String)"finding ShcLog instance by example");
        Session session = null;
        int currPage = 0;
        try {
            session = this.getSession();
            if (pageNum != null) {
                currPage = Integer.parseInt(pageNum);
            }
            Criteria criteria = session.createCriteria((Class)ShcLog.class);
            if (instance.getId() != null && instance.getId().getChipIndex() != null) {
                criteria.add((Criterion)Restrictions.eq("id.chipIndex", (Object)instance.getId().getChipIndex()));
            }
            if (instance.getTxnsrc() != null) {
                criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
            }
            if (instance.getTxndest() != null) {
                criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
            }
            if (instance.getPan() != null) {
                final String panVal = StringPadder.pad(instance.getPan(), 19);
                criteria.add((Criterion)Restrictions.eq("pan", (Object)panVal));
            }
            if (instance.getMsgtype() != null) {
                criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
            }
            if (instance.getLocalDate() != null) {
                criteria.add((Criterion)Restrictions.eq("localDate", (Object)instance.getLocalDate()));
            }
            if (instance.getLocalTime() != null) {
                criteria.add((Criterion)Restrictions.eq("localTime", (Object)instance.getLocalTime()));
            }
            if (instance.getPcode() != null) {
                criteria.add((Criterion)Restrictions.eq("pcode", (Object)instance.getPcode()));
            }
            if (instance.getTrace() != null) {
                criteria.add((Criterion)Restrictions.eq("trace", (Object)instance.getTrace()));
            }
            if (instance.getAmount() != null) {
                criteria.add((Criterion)Restrictions.eq("amount", (Object)instance.getAmount()));
            }
            if (instance.getAcquirer() != null) {
                criteria.add((Criterion)Restrictions.eq("acquirer", (Object)instance.getAcquirer()));
            }
            if (instance.getAuthnum() != null) {
                final String authNumVal = StringPadder.pad(instance.getAuthnum(), 6);
                criteria.add((Criterion)Restrictions.eq("authnum", (Object)authNumVal));
            }
            if (instance.getRefnum() != null) {
                final String refNumVal = StringPadder.pad(instance.getRefnum(), 12);
                criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
            }
            if (instance.getRespcode() != null) {
                criteria.add((Criterion)Restrictions.eq("respcode", (Object)instance.getRespcode()));
            }
            if (instance.getReasonCode() != null) {
                criteria.add((Criterion)Restrictions.eq("reasonCode", (Object)instance.getReasonCode()));
            }
            if (instance.getDeviceCap() != null) {
                criteria.add((Criterion)Restrictions.eq("deviceCap", (Object)instance.getDeviceCap()));
            }
            if (instance.getShcerror() == BigDecimal.ZERO) {
                criteria.add((Criterion)Restrictions.eq("shcerror", (Object)instance.getShcerror()));
            }
            criteria = criteria.addOrder(Order.desc("localTime"));
            this.setPaging(criteria, currPage);
            return (List<ShcLog>)criteria.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
    }
    
    private Criteria createCriteriaObj(final ShcLog instance, final Date localDate, final Date localDateTo, final Date txnDate, final Date txnDateTo) {
        final Session session = this.getSession();
        final Criteria criteria = session.createCriteria((Class)ShcLog.class);
        final String txnSrc = instance.getTxnsrc();
        final String txnDxt = instance.getTxndest();
        if (StringUtil.isNotEmpty(txnSrc) && StringUtil.isNotEmpty(txnDxt)) {
            criteria.add((Criterion)Restrictions.or((Criterion)Restrictions.eq("txnsrc", (Object)txnSrc), (Criterion)Restrictions.eq("txndest", (Object)txnDxt)));
        }
        else if (StringUtil.isNotEmpty(txnSrc) && StringUtil.isEmpty(txnDxt)) {
            criteria.add((Criterion)Restrictions.eq("txnsrc", (Object)instance.getTxnsrc()));
        }
        else if (StringUtil.isEmpty(txnSrc) && StringUtil.isNotEmpty(txnDxt)) {
            criteria.add((Criterion)Restrictions.eq("txndest", (Object)instance.getTxndest()));
        }
        final BigDecimal siteId = instance.getId().getSiteId();
        if (siteId != null) {
            criteria.add((Criterion)Restrictions.eq("id.siteId", (Object)siteId));
        }
        if (localDate != null) {
            criteria.add((Criterion)Restrictions.ge("localDate", (Object)localDate));
        }
        if (localDateTo != null) {
            criteria.add((Criterion)Restrictions.le("localDate", (Object)localDateTo));
        }
        if (txnDate != null) {
            criteria.add((Criterion)Restrictions.ge("trandate", (Object)txnDate));
        }
        if (txnDateTo != null) {
            criteria.add((Criterion)Restrictions.le("trandate", (Object)txnDateTo));
        }
        if (StringUtil.isNotEmpty(instance.getFId())) {
            criteria.add((Criterion)Restrictions.eq("FId", (Object)instance.getFId()));
        }
        if (instance.getTrace() != null) {
            criteria.add((Criterion)Restrictions.eq("trace", (Object)instance.getTrace()));
        }
        if (instance.getRefnum() != null) {
            final String refNumVal = instance.getRefnum();
            if (refNumVal.indexOf("*") > -1) {
                criteria.add(Restrictions.ilike("refnum", (Object)refNumVal.replace('*', '%')));
            }
            else {
                criteria.add((Criterion)Restrictions.eq("refnum", (Object)refNumVal));
            }
        }
        if (instance.getRespcode() != null) {
            criteria.add((Criterion)Restrictions.eq("respcode", (Object)instance.getRespcode()));
        }
        if (instance.getMsgtype() != null) {
            criteria.add((Criterion)Restrictions.eq("msgtype", (Object)instance.getMsgtype()));
        }
        if (instance.getPcode() != null) {
            criteria.add((Criterion)Restrictions.eq("pcode", (Object)instance.getPcode()));
        }
        return criteria;
    }
    
    public Integer getTotalShc800Records(final ShcLog instance, final Date localDate, final Date localDateTo, final Date txnDate, final Date txnDateTo) {
        ShcLogDAO.log.debug((String)"finding getTotalShc800Records total count by example...");
        Integer count = null;
        try {
            final Criteria criteria = this.createCriteriaObj(instance, localDate, localDateTo, txnDate, txnDateTo);
            criteria.setProjection(Projections.rowCount());
            final Long sLong = (Long)criteria.uniqueResult();
            if (sLong != null) {
                count = sLong.intValue();
            }
            else {
                count = 0;
            }
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"find by example failed", (Throwable)re);
            throw re;
        }
        return count;
    }
    
    public List<ShcLog> getShc800Records(final ShcLog instance, final Date localDate, final Date localDateTo, final Date txnDate, final Date txnDateTo, final int pageNum) {
        ShcLogDAO.log.debug((String)"finding getShc800Records ...");
        try {
            final Criteria criteria = this.createCriteriaObj(instance, localDate, localDateTo, txnDate, txnDateTo);
            this.setPaging(criteria, pageNum);
            return (List<ShcLog>)criteria.list();
        }
        catch (RuntimeException re) {
            ShcLogDAO.log.error((String)"getShc800Records failed", (Throwable)re);
            throw re;
        }
    }
    
    private void constructCriteria(final BigDecimal posEntryCode, final Criteria criteria) {
        final String POSTABLE = "(1, 2, 5, 6, 79, 93, 7, 91) ";
        if (posEntryCode.intValue() == 0) {
            criteria.add((Criterion)Restrictions.eq("merchantType", (Object)new BigDecimal("6011")));
        }
        else if (posEntryCode.intValue() == 1) {
            criteria.add((Criterion)Restrictions.ne("merchantType", (Object)new BigDecimal("6011")));
            criteria.add(Restrictions.sqlRestriction("round((bitand(pos_entry_code, 1023))/10, 0) in " + POSTABLE));
        }
        else {
            criteria.add((Criterion)Restrictions.ne("merchantType", (Object)new BigDecimal("6011")));
            criteria.add(Restrictions.sqlRestriction("round((bitand(pos_entry_code, 1023))/10, 0) not in " + POSTABLE));
        }
    }
}
