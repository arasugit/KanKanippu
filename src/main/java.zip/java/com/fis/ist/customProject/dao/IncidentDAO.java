package com.fis.ist.customProject.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.time.temporal.TemporalAccessor;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.logging.log4j.core.time.Instant;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;

import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.customProject.domain.Employee;
import com.fis.ist.customProject.domain.Incident;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.controller.ControllerSupportConstants;
import com.fis.ist.monitoring.dao.MonitorBaseDAO;

public class IncidentDAO extends MonitorBaseDAO<Incident, Integer> {
	private static final ISTLogger log = ISTLogger.getLogger(IncidentDAO.class);
	public static final String INCCFG_GT_DEPT = "INCCFG_GT_DEPT";
	public static final String INCCFG_GT_INCLST = "INCCFG_GT_INCLST";
	public static final String INCCFG_GT_INCLST_FRMDTE = "INCCFG_GT_INCLST_FRMDTE";
	public static final String INCCFG_GT_INCLST_FRMDTETOTL = "INCCFG_GT_INCLST_FRMDTETOTL";
	public static final String INCCFG_GT_MXID = "INCCFG_GT_MXID";
	
	

	@Override
	public Class<Incident> getEntityClass() {
		return Incident.class;
	}

	public List<Incident> findByExample(Incident instance, String cfgId, int pageNum) {
		log.debug("finding Incident instance by example");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(Incident.class);
			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;
			String cmd = null;

			data = cfgId;
			if (data != null && !cfgId.isEmpty()) {
				String searchTerm = (String) cfgId;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1, searchTerm.length() - 1));
					c.add(Restrictions.sqlRestriction("CAST(cfgId AS VARCHAR(20)) LIKE ?", "%" + searchTermcfgId + "%", StandardBasicTypes.STRING));
				} else if (searchTerm.startsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1));
					c.add(Restrictions.sqlRestriction("CAST(cfgId AS VARCHAR(20)) LIKE ?", "%" + searchTermcfgId , StandardBasicTypes.STRING));
				} else if (searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(0, searchTerm.length() - 1));
					c.add(Restrictions.sqlRestriction("CAST(cfgId AS VARCHAR(20)) LIKE ?", searchTermcfgId + "%", StandardBasicTypes.STRING));
				} else {
					condition.put("cfgId", Integer.parseInt(cfgId));
				}
			}
			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}

			data = instance.getCmd();
			if (data != null) {
				String searchTerm = (String) data;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(1, searchTerm.length() - 1);
					c.add(Restrictions.ilike("cmd", searchTerm, MatchMode.ANYWHERE));
				} else if (searchTerm.startsWith("*")) {
					searchTerm = searchTerm.substring(1);
					c.add(Restrictions.ilike("cmd", searchTerm, MatchMode.END));
				} else if (searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(0, searchTerm.length() - 1);
					c.add(Restrictions.ilike("cmd", searchTerm, MatchMode.START));
				} else {
					c.add(Restrictions.ilike("cmd", searchTerm, MatchMode.EXACT));
				}
			}

			data = instance.getSubCmd();
			if (data != null) {
				condition.put("subcmd", data);
			}

			data = instance.getCondition();
			if (data != null) {
				condition.put("condition", data);
			}

			data = instance.getPriority();
			if (data != null) {
				condition.put("priority", data);
			}

			data = instance.getAlertType();
			if (data != null) {
				condition.put("alertType", data);
			}

			data = instance.getStartDate();
			if (data != null) {
				condition.put("startDate", data);
			}

			data = instance.getEndDate();
			if (data != null) {
				condition.put("endDate", data);
			}

			data = instance.getMessage();
			if (data != null) {
				condition.put("message", data);
			}

			data = instance.getSmsNumber();
			if (data != null) {
				condition.put("smsNumber", data);
			}

			data = instance.getEmailId();
			if (data != null) {
				condition.put("emailId", data);
			}
			
			data = instance.getNodeId();
			if(getNodeValue(instance.getProduct(), instance.getNodeId()) && instance.getNodeId().contains(",")) {
				Object[] nodeIds = instance.getNodeId().split(",");
				c.add(Restrictions.in("nodeId", nodeIds));
			}
			else if(getNodeValue(instance.getProduct(), instance.getNodeId())){
				c.add(Restrictions.in("nodeId", data));
			}
			
			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("type"),"type");
			projectionList.add(Projections.property("l2_emailid"),"l2_EmailId");
			projectionList.add(Projections.property("l2_smsnumber"),"l2_SmsNumber");
			projectionList.add(Projections.property("l3_emailid"),"l3_EmailId");
			projectionList.add(Projections.property("l3_smsnumber"),"l3_SmsNumber");
			
			c = c.add(Restrictions.allEq(condition));
			c.addOrder(Order.desc("cfgId"));
			setPaging(c, pageNum);
			List<Incident> results = c.list();

			log.debug("findByExample successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public void save(Incident transientInstance) {
		getSession().save(transientInstance);
	}

	@SuppressWarnings("deprecation")
	public Integer getTotalByExampleCount(Incident instance, String cfgId) throws ParseException {
		log.debug("getTotalByExample Incident");
		Integer count = null;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(Incident.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();

			String value = null;
			Object data = null;
			String sDate = null;
			String eDate = null;
			String cmd = null;

			data = cfgId;
			if (data != null && !cfgId.isEmpty()) {
				
				String searchTerm = (String) cfgId;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1, searchTerm.length() - 1));
					c.add(Restrictions.sqlRestriction("CAST(cfgId AS VARCHAR(20)) LIKE ?", "%" + searchTermcfgId + "%", StandardBasicTypes.STRING));
				} else if (searchTerm.startsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1));
					c.add(Restrictions.sqlRestriction("CAST(cfgId AS VARCHAR(20)) LIKE ?", "%" + searchTermcfgId , StandardBasicTypes.STRING));
				} else if (searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(0, searchTerm.length() - 1));
					c.add(Restrictions.sqlRestriction("CAST(cfgId AS VARCHAR(20)) LIKE ?", searchTermcfgId + "%", StandardBasicTypes.STRING));
				} else {
					condition.put("cfgId", Integer.parseInt(cfgId));
				}
			}

			value = instance.getDescription();
			if (StringUtil.isNotEmpty(value)) {
				condition.put("description", value);
			}

			data = instance.getProduct();
			if (data != null) {
				condition.put("product", data);
			}
 
//			data = instance.getNodeId();
//			if (data != null) {
//				condition.put("nodeId", data);
//			}

			data = instance.getCmd();
			if (data != null) {
				//cmd = ((String) data).trim();
				//c.add(Restrictions.eq("cmd",cmd).ignoreCase());
				String searchTerm = (String) data;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(1, searchTerm.length() - 1);
					c.add(Restrictions.ilike("cmd", searchTerm, MatchMode.ANYWHERE));
				} else if (searchTerm.startsWith("*")) {
					searchTerm = searchTerm.substring(1);
					c.add(Restrictions.ilike("cmd", searchTerm, MatchMode.END));
				} else if (searchTerm.endsWith("*")) {
					searchTerm = searchTerm.substring(0, searchTerm.length() - 1);
					c.add(Restrictions.ilike("cmd", searchTerm, MatchMode.START));
				} else {
					c.add(Restrictions.ilike("cmd", searchTerm, MatchMode.EXACT));
				}
			}

			data = instance.getSubCmd();
			if (data != null) {
				condition.put("subcmd", data);
			}

			data = instance.getCondition();
			if (data != null) {
				condition.put("condition", data);
			}

			data = instance.getPriority();
			if (data != null) {
				condition.put("priority", data);
			}

			data = instance.getAlertType();
			if (data != null) {
				condition.put("alertType", data);
			}

			data = instance.getStartDate();
			if (data != null) {
				String DATE_FORMAT_NOW = "dd/MM/yyyy";
				LocalDate date2 = null;
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);

				DateTimeFormatter f = DateTimeFormatter.ofPattern("E MMM dd HH:mm:ss z uuuu").withLocale(Locale.US);
				ZonedDateTime zdt = ZonedDateTime.parse(instance.getStartDate().toString(), f);

				LocalDate ld = zdt.toLocalDate();
				DateTimeFormatter fLocalDate = DateTimeFormatter.ofPattern("dd/MM/uuuu");
				String output = ld.format(fLocalDate);
				Date fd = sdf.parse(output);

				try {

					LocalDate date = LocalDate.parse(output, DateTimeFormatter.ofPattern("dd/MM/uuuu"));

					java.time.Instant instant = date.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant();
					Date res = Date.from(instant);
					SimpleDateFormat DateFor = new SimpleDateFormat("dd/MM/yyyy");

					Date date3 = DateFor.parse(output);

					condition.put("startDate", fd);

				} catch (Exception e) {
					// handle exception
				}
			}

			data = instance.getEndDate();
			if (data != null) {
				condition.put("endDate", data);
			}

			data = instance.getMessage();
			if (data != null) {
				condition.put("message", data);
			}

			data = instance.getSmsNumber();
			if (data != null) {
				condition.put("smsNumber", data);
			}

			data = instance.getEmailId();
			if (data != null) {
				condition.put("emailId", data);
			}
			
			data = instance.getNodeId();
			String product = instance.getProduct();
			if(data != null && getNodeValue(product, instance.getNodeId()) && instance.getNodeId().contains(",")) {
				Object[] nodeIds = instance.getNodeId().split(",");
				c.add(Restrictions.in("nodeId", nodeIds));
			}
			else if(getNodeValue(product, instance.getNodeId())){
				c.add(Restrictions.in("nodeId", data));
			}
			
			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;

		} catch (RuntimeException re) {
			log.error("getTotalByExample Employee failed", re);
			throw re;
		}
		return count;
	}

	public List getDepartments(String department) {
		log.debug("getDepartments searchlist..");
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery(INCCFG_GT_DEPT);
			
			boolean dept = StringUtil.isNotEmpty(department);
			if (dept) {
				queryString += " where id = ? ";
			} else {
				queryString += " order by id ";
			}
			Query queryObject = createSQLQuery(queryString).addScalar("id", StandardBasicTypes.INTEGER)
					.addScalar("name", StandardBasicTypes.STRING).addScalar("description", StandardBasicTypes.STRING);

			if (dept)
				queryObject.setString(0, department);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Exception Occured in getDepartments searchlist.. failed", re);
			throw re;
		}
	}

	public List getDepartments() {
		log.debug("getDepartments dropdown list..");
		try {
			String queryString = "SELECT id, id || '-' || name as deptDesc from department order by id";

			Query queryObject = createSQLQuery(queryString).addScalar("id", StandardBasicTypes.INTEGER)
					.addScalar("deptDesc", StandardBasicTypes.STRING);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Exception Occured in getDepartments dropdown list.. failed", re);
			throw re;
		}
	}

	public List getIncidentList() {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCCFG_GT_INCLST));

			String queryString = queryBuffer.toString();
			Query queryObject = null;
			queryObject = getSession().createSQLQuery(queryString).addScalar("CFGID", StandardBasicTypes.STRING)
					.addScalar("DESCRIPTION", StandardBasicTypes.STRING).addScalar("PRODUCT", StandardBasicTypes.STRING)
					.addScalar("NODEID", StandardBasicTypes.STRING).addScalar("CMD", StandardBasicTypes.STRING)
					.addScalar("SUBCMD", StandardBasicTypes.STRING).addScalar("CONDITION", StandardBasicTypes.STRING)
					.addScalar("PRIORITY", StandardBasicTypes.STRING).addScalar("ALERTTYPE", StandardBasicTypes.STRING)
					.addScalar("STARTDATE", StandardBasicTypes.STRING).addScalar("ENDDATE", StandardBasicTypes.STRING)
					.addScalar("SMSNUMBER", StandardBasicTypes.STRING).addScalar("EMAILID", StandardBasicTypes.STRING);

			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("Exception Occured in getIncident list.. failed", re);
			throw re;
		}

	}

	public List getIncidentListFromDate(String cfgId, String product, String nodeId, String cmd, String startDateFormat,
			String endDateFormat, Integer pageNum) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			String queryString = "";
			Query queryObject = null;
			
			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCCFG_GT_INCLST_FRMDTE));
			
			if (null != cfgId && StringUtil.isNotEmpty(product)) {
				queryBuffer.append(" where product = :product ");
			}
			 
			if (null != cfgId && getNodeValue(product, nodeId)) {
				queryBuffer.append(" and nodeid IN (:nodeId)");
			}
			if (null != cfgId && StringUtil.isNotEmpty(cfgId)) {
				queryBuffer.append(" and cfgid = :cfgid");
			}
			if (null != cfgId && StringUtil.isNotEmpty(cfgId)) {
				queryBuffer.append(" and cmd = :cmd ");
			}

			if (null != startDateFormat && StringUtil.isNotEmpty(startDateFormat)) {
				queryBuffer.append(" and " + getTruncFunctionBasedOnDBType("startdate") + " >= to_date(:startdate , '" + PaymonUtils.InputDateFormat + "') ");
			}
			if (null != endDateFormat && StringUtil.isNotEmpty(endDateFormat)) {
				queryBuffer.append(" and " + getTruncFunctionBasedOnDBType("enddate") + " <= to_date(:enddate , '" + PaymonUtils.InputDateFormat + "') ");
			}

			queryString = queryBuffer.toString();
			queryObject = getSession().createSQLQuery(queryString).addScalar("cfgid", StandardBasicTypes.INTEGER)
					.addScalar("description", StandardBasicTypes.STRING).addScalar("product", StandardBasicTypes.STRING)
					.addScalar("nodeid", StandardBasicTypes.STRING).addScalar("cmd", StandardBasicTypes.STRING)
					.addScalar("subcmd", StandardBasicTypes.STRING).addScalar("condition", StandardBasicTypes.STRING)
					.addScalar("priority", StandardBasicTypes.STRING).addScalar("alerttype", StandardBasicTypes.STRING)
					.addScalar("startdate", StandardBasicTypes.DATE).addScalar("enddate", StandardBasicTypes.DATE)
					.addScalar("message", StandardBasicTypes.STRING).addScalar("smsnumber", StandardBasicTypes.STRING)
					.addScalar("emailid", StandardBasicTypes.STRING)
					.addScalar("type", StandardBasicTypes.STRING).addScalar("l2_emailid", StandardBasicTypes.STRING)
					.addScalar("l2_smsnumber", StandardBasicTypes.STRING).addScalar("l3_emailid", StandardBasicTypes.STRING)
					.addScalar("l3_smsnumber", StandardBasicTypes.STRING);

			if (null != cfgId && StringUtil.isNotEmpty(product)) {
				queryObject.setParameter("product", product);
			}
			
			String[] nodeIds = nodeId.contains(",") ? nodeId.split(",") : new String[]{nodeId};
			if (null != cfgId && getNodeValue(product, nodeId)) {
				queryObject.setParameterList("nodeId", nodeIds);
			}
			if (null != cfgId && StringUtil.isNotEmpty(cfgId)) {
				queryObject.setParameter("cfgid", cfgId);
			}
			if (null != cfgId && StringUtil.isNotEmpty(cfgId)) {
				queryObject.setParameter("cmd", cmd);
			}

			if (null != startDateFormat && StringUtil.isNotEmpty(startDateFormat)) {
				queryObject.setParameter("startdate", startDateFormat);
			}
			if (null != endDateFormat && StringUtil.isNotEmpty(endDateFormat)) {
				queryObject.setParameter("enddate", endDateFormat);
			}

			setPaging(queryObject, pageNum);

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}

	public int getIncidentListFromDateTotal(String cfgId, String product, String nodeId, String cmd,
			String startDateFormat, String endDateFormat) {

		StringBuffer queryBuffer = new StringBuffer();
		String queryString = "";
		Query queryObject = null;
		
		queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCCFG_GT_INCLST_FRMDTETOTL));
		
		if (null != cfgId && StringUtil.isNotEmpty(product)) {
			queryBuffer.append(" where product = :product ");
		}
		 
		if (null != cfgId && getNodeValue(product, nodeId)) {
			queryBuffer.append(" and nodeid IN (:nodeId)");
		}
		if (null != cfgId && StringUtil.isNotEmpty(cfgId)) {
			queryBuffer.append(" and cfgid = :cfgid");
		}
		if (null != cfgId && StringUtil.isNotEmpty(cfgId)) {
			queryBuffer.append(" and cmd = :cmd ");
		}

		if (null != startDateFormat && StringUtil.isNotEmpty(startDateFormat)) {
			queryBuffer.append(" and " + getTruncFunctionBasedOnDBType("startdate") + " >= to_date(:startdate , '" + PaymonUtils.InputDateFormat + "') ");
		}
		if (null != endDateFormat && StringUtil.isNotEmpty(endDateFormat)) {
			queryBuffer.append(" and " + getTruncFunctionBasedOnDBType("enddate") + " <= to_date(:enddate , '" + PaymonUtils.InputDateFormat + "') ");
		}

		queryString = queryBuffer.toString();
		queryObject = getSession().createSQLQuery(queryString).addScalar("cfgid", StandardBasicTypes.INTEGER)
				.addScalar("description", StandardBasicTypes.STRING).addScalar("product", StandardBasicTypes.STRING)
				.addScalar("nodeid", StandardBasicTypes.STRING).addScalar("cmd", StandardBasicTypes.STRING)
				.addScalar("subcmd", StandardBasicTypes.STRING).addScalar("condition", StandardBasicTypes.STRING)
				.addScalar("priority", StandardBasicTypes.STRING).addScalar("alerttype", StandardBasicTypes.STRING)
				.addScalar("startdate", StandardBasicTypes.DATE).addScalar("enddate", StandardBasicTypes.DATE)
				.addScalar("message", StandardBasicTypes.STRING).addScalar("smsnumber", StandardBasicTypes.STRING)
				.addScalar("emailid", StandardBasicTypes.STRING)
				.addScalar("type", StandardBasicTypes.STRING).addScalar("l2_emailid", StandardBasicTypes.STRING)
				.addScalar("l2_smsnumber", StandardBasicTypes.STRING).addScalar("l3_emailid", StandardBasicTypes.STRING)
				.addScalar("l3_smsnumber", StandardBasicTypes.STRING);;

		if (null != cfgId && StringUtil.isNotEmpty(product)) {
			queryObject.setParameter("product", product);
		}
		String[] nodeIds = nodeId.contains(",") ? nodeId.split(",") : new String[]{nodeId};
		if (null != cfgId && getNodeValue(product, nodeId)) {
			queryObject.setParameterList("nodeId", nodeIds);
		}
		if (null != cfgId && StringUtil.isNotEmpty(cfgId)) {
			queryObject.setParameter("cfgid", cfgId);
		}
		if (null != cfgId && StringUtil.isNotEmpty(cfgId)) {
			queryObject.setParameter("cmd", cmd);
		}

		if (null != startDateFormat && StringUtil.isNotEmpty(startDateFormat)) {
			queryObject.setParameter("startdate", startDateFormat);
		}
		if (null != endDateFormat && StringUtil.isNotEmpty(endDateFormat)) {
			queryObject.setParameter("enddate", endDateFormat);
		}
		
		return queryObject.list().size();
	}
	public int getMaxId() {
		int result = 0;
		try {
			
			String queryString = SqlQueryProvider.getDBSqlQuery(INCCFG_GT_MXID);

			Query queryObject = createSQLQuery(queryString)
								.addScalar("maxId", StandardBasicTypes.INTEGER);
			
			result = (Integer)queryObject.uniqueResult();
			
			log.debug("Success Result Incident List  - getMaxId" + result);
			
			return result;			
			
		} catch (RuntimeException re) {
			log.error("Exception Occured in Incident getmaxId() list.. failed", re);
			throw re;
		}
	}
	
	private String getTruncFunctionBasedOnDBType(String tempDate) {
		
		if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
			return "date_trunc('day', " + tempDate + ")";
		} 
		
		return "trunc(" + tempDate + ")";
	}
	
	private boolean getNodeValue(String product, String nodeId){
		return StringUtil.isNotEmpty(product) && 
				(product.equalsIgnoreCase(ControllerSupportConstants.SWITCH_PRODUCT_ID) || product.equalsIgnoreCase(ControllerSupportConstants.CORTEX_PRODUCT_ID)) 
				&& StringUtil.isNotEmpty(nodeId);
	}
	
}