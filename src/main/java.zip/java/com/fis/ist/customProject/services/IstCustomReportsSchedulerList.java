package com.fis.ist.customProject.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.audit.FormAudit;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.handler.IstCustomReportsSchedulerListHandler;
import com.fis.ist.services.vo.WorkRequest;

public class IstCustomReportsSchedulerList extends CRUDSubService{

    private static final ISTLogger log = ISTLogger.getLogger(IstCustomReportsSchedulerList.class);
    
    private static final String SUBSYSTEM = "Custom GUI";
	private static final String ACTION_INSERT = "insert";
    private static final String ACTION_QUERY = "query";
    private static final String ACTION_SINGLE_BATCH_SAVE = "save";
    private static final String ACTION_SINGLE_BATCH_APPLY = "apply";
    private static final String ACTION_SINGLE_BATCH_SHUTDOWN = "shutdown";

    public WorkRequest getService
		(
			UserContext userContext,
			String requestType,
			String action,
		   	Map<String, String>requestParams
		) throws Exception
	{
		WorkRequest workReq = null;
		if(action.compareTo(ACTION_QUERY) == 0) {
			IstCustomReportsSchedulerListHandler ddh = new IstCustomReportsSchedulerListHandler();
			workReq = ddh.getReportsSchedulerList(userContext, requestParams);
		} else {
			log.error("**** IstCustomReportsSchedulerList: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		 }
		if(Boolean.parseBoolean(ConfigParams.getInstance().getProperty("ist.paymon.audit.log"))){
			new FormAuditHandler().saveFormAudit(userContext, requestType, action, workReq, SUBSYSTEM);
	        WorkRequestCacher.getInstance().put(userContext, workReq);
		}
		return workReq;
	}
   	public WorkRequest setService
		(
			UserContext userContext,
			String requestType,
			String action,
		   	WorkRequest workRequest
		) throws Exception
	{
		FormAuditHandler ah = new FormAuditHandler();
		FormAudit handle = ah.beginEditableListAudit(userContext, requestType, action, workRequest, SUBSYSTEM);
   		if(action.compareTo(ACTION_INSERT) == 0){   				
   			IstCustomReportsSchedulerListHandler ddh = new IstCustomReportsSchedulerListHandler();
   				workRequest = ddh.getDataForAdd(userContext,workRequest);
   		}else if(action.compareTo(ACTION_SINGLE_BATCH_SAVE) == 0){   				
   			IstCustomReportsSchedulerListHandler ddh = new IstCustomReportsSchedulerListHandler();
   				workRequest = ddh.saveWorkRequest(userContext,workRequest,setPermissions());
   		}else if(action.compareTo(ACTION_SINGLE_BATCH_APPLY) == 0){   				
   			IstCustomReportsSchedulerListHandler ddh = new IstCustomReportsSchedulerListHandler();
				workRequest = ddh.applyChanges(workRequest);
   		}else if(action.compareTo(ACTION_SINGLE_BATCH_SHUTDOWN) == 0){   				
   			IstCustomReportsSchedulerListHandler ddh = new IstCustomReportsSchedulerListHandler();
				workRequest = ddh.shutdownSchedulers(workRequest);
   		}else{
   			log.error("**** IstCustomReportsSchedulerList List: setService() inbound...unknown request type");
   			throw new Exception("Unknown request type");
   		}
   		if(action.compareTo(ACTION_SINGLE_BATCH_APPLY) != 0	&& action.compareTo(ACTION_SINGLE_BATCH_SHUTDOWN) != 0)//These actions are not recognized yet
   			ah.saveEditableListAudit(handle, workRequest);
   		return workRequest;
	}
}