package com.fis.ist.customProject.dto;

import com.fis.ist.customProject.domain.CsMonDebug;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class DebugMonitoringListRow extends EditableListRowForSDK implements Cloneable  {
	
	
	private static final long serialVersionUID = 1L;
	private static final ISTLogger log = ISTLogger.getLogger(DebugMonitoringListRow.class);
	
	@Override
	public String getFormKey() {
		return null;
	} 
	
	private String nodeid;
	private String logdate;
	private String filename;
	private String pid; 
	private String debuglevel;
	private String debug;

	public String getNodeid() {
		return nodeid;
	}
	public void setNodeid(String nodeid) {
		this.nodeid = nodeid;
	}
	public String getLogdate() {
		return logdate;
	}
	public void setLogdate(String logdate) {
		this.logdate = logdate;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getDebuglevel() {
		return debuglevel;
	}
	public void setDebuglevel(String debuglevel) {
		this.debuglevel = debuglevel;
	}
	public String getDebug() {
		return debug;
	}
	public void setDebug(String debug) {
		this.debug = debug;
	}
	
	@Override
	public String toString() {
		return "DebugMonitoringListRow [nodeid=" + nodeid + ", logdate=" + logdate + ", filename=" + filename + ", pid="
				+ pid + ", debuglevel=" + debuglevel + ", debug=" + debug + "]";
	}
	
	public void loadDebugData(CsMonDebug data) {
		setNodeid(data.getNodeid());
		setLogdate((data.getLogdate()).toString().replace(".0", ""));
		setFilename(data.getFilename());
		setPid(data.getPid());
		setDebuglevel(data.getDebuglevel());
		setDebug(data.getDebug());
	}
}
