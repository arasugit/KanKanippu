package com.fis.ist.customProject.services;

import java.util.List;
import java.util.Map;

import com.fis.ist.common.IListProvider;
import com.fis.ist.customProject.dao.EmployeeDAO;

public class DepartmentIdListProvider implements IListProvider
{
	private String searchListType="";
	
	public List getList(Map<String, String> params)
	{
		EmployeeDAO dao = new EmployeeDAO();
		List recordList = null;
		searchListType = params.get("type");
		if (searchListType.compareToIgnoreCase("DEPARTMENT_ID_POPUP")==0)
		{
			recordList = dao.getDepartments(params.get("department"));
		}
		return recordList;
	}	
	
	public String getName()
	{
		return "DEPARTMENT_ID_POPUP";
	}

	public List getList() {
		List recordList = new EmployeeDAO().getDepartments();
		return recordList;
	}

	public List getListByInstitution(String instId) {
		// TODO Auto-generated method stub
		return null;
	}
}