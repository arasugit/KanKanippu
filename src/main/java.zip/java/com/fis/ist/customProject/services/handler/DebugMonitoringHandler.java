package com.fis.ist.customProject.services.handler;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.customProject.dao.CsMonDebugDAO;
import com.fis.ist.customProject.domain.CsMonDebug;
import com.fis.ist.customProject.dto.DebugMonitoringListRow;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.ISTCommandDAO;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;
import com.fis.ist.spring.HTTPRequestGetter;

import javax.servlet.http.HttpServletRequest;

public class DebugMonitoringHandler extends ISTRequestHandler implements ISimpleListHandler {

	private static final ISTLogger log = ISTLogger.getLogger(DebugMonitoringHandler.class);
	private static String reqTypeId = CustomConstants.DEBUG_MTR_REQ;
	private static String formAuthId = "DEBUGM_REQ";

	public DebugMonitoringHandler() {
		checkMKCEnabled(formAuthId);
	}

	public WorkRequest getDebugMonitorData(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, CustomConstants.DEBUG_MTR_TAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.DEBUG_MTR_REQ);
		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(CustomConstants.DEBUG_MTR_REQ);
			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);
			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(CustomConstants.DEBUG_MTR_TAB);
			workStatus.setModifyable("Y");
			tabStatus.put(CustomConstants.DEBUG_MTR_TAB, workStatus);
			workReq.setTabStatus(tabStatus);
			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			 
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public void load(WorkRequest workRequest, Map<String, String> params){
		log.debug("Load Debug Monitoring screen");
		
		String product = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("product_id"); 
		String nodeId = (String) HTTPRequestGetter.getRequest().getSession(false).getAttribute("node_name"); 		
		String fileName = params.get("fileName");
		String debugLevel = params.get("debugLevel");
		String fromDate = params.get("fromDate");
		String fromTime = params.get("fromTime");
		String toDate = params.get("toDate");
		String toTime = params.get("toTime");
		String dateFormateDB="DD-MON-YYYY";
		DateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy");
		DateFormat inputFormat = new SimpleDateFormat("MM/dd/yyyy");
		boolean isTimeNull = false;
		
		if(debugLevel != null && !debugLevel.isEmpty()) {
			debugLevel.toUpperCase();
		}
		
		if((fromTime == null || "".equalsIgnoreCase(fromTime)) && (toTime == null || "".equalsIgnoreCase(toTime))) {
			isTimeNull = true;
			//System.out.println("Original Date toDate : " + toDate);
			try {
				Date toDateDt = inputFormat.parse(toDate);
				
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(toDateDt);
				calendar.add(Calendar.DAY_OF_MONTH, 1);
				
				Date toDatePlusOneDayDt = calendar.getTime();
				
				//Format toDatePlusOneDayDt back to the string toDate
				toDate = inputFormat.format(toDatePlusOneDayDt);
			} catch (ParseException e2) {
				// TODO Auto-generated catch block
				log.error(e2);
			} 
		}
		
		log.debug("Params :: fromDate = " +fromDate + " toDate = " + toDate + " product = " + product +" nodeId = " + nodeId 
				+" fileName = "+ fileName + " debugLevel = "+ debugLevel);
		
		boolean isFromTimeNotNull=false;
		boolean isToTimeNotNull=false;
		
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		// ist_page_ctrl will contain the page number and according the records
		// will be fetched based on the pagesize and sent to the client.
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		CsMonDebugDAO dao = new CsMonDebugDAO(); 
		
		// If fromTime is not null
		if (!(fromTime == null || "".equalsIgnoreCase(fromTime))) {
			fromDate = fromDate + " " + fromTime;
			dateFormateDB = "DD-MON-YYYY HH24:MI:SS";
			 outputFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
			 inputFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			 if("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName()))
				 dao.altersession();
			 isFromTimeNotNull=true;
		}
		
		// If toTime is not null
		if (!(toTime == null || "".equalsIgnoreCase(toTime))) {
			toDate = toDate + " " + toTime;
			dateFormateDB = "DD-MON-YYYY HH24:MI:SS";
			 outputFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
			 inputFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			 isToTimeNotNull=true;
			 if(!isFromTimeNotNull) {
				fromDate = fromDate + " 00:00:00";
				if("oracle".equalsIgnoreCase(PaymonUtils.getDatabseName()))
					 dao.altersession();
			 }
		}
		
		if(isFromTimeNotNull && !isToTimeNotNull) {
			toDate = toDate + " 23:59:59";
		}
		
		Date fromDateObj = null;
		Date toDateObj = null;
		String formattedFromDate = "";
		String formattedToDate = "";
		
		try {
			if(fromDate != null && !fromDate.isEmpty()  && toDate != null && !toDate.isEmpty() ) {	
					fromDateObj = inputFormat.parse(fromDate);
					toDateObj = inputFormat.parse(toDate);
					formattedFromDate = outputFormat.format(fromDateObj);
					formattedToDate = outputFormat.format(toDateObj);
			}else
				log.debug("fromDate and/or toDate is null");
		} catch (ParseException e1) {
			log.error(e1);
		}
		
		List<CsMonDebug> recordList = null;
		
		CsMonDebug searchRecord = new CsMonDebug();
		
		if(StringUtil.isNotEmpty(product)){
			try{
				searchRecord.setProduct(product);
			}catch (NumberFormatException nfe) {
				log.debug("Invalid Product ["+product+"]", nfe);
			}
		}
		
		if(StringUtil.isNotEmpty(nodeId)){
			try{
				searchRecord.setNodeid(nodeId);
			}catch (NumberFormatException nfe) {
				log.debug("Invalid Node id ["+nodeId+"]", nfe);
			}
		}
		
		if(StringUtil.isNotEmpty(fileName)){
			try{
				searchRecord.setFilename(fileName);
			}catch (NumberFormatException nfe) {
				log.debug("Invalid file name ["+fileName+"]", nfe);
			}
		}
		
		if(StringUtil.isNotEmpty(debugLevel)){
			try{
				searchRecord.setDebuglevel(debugLevel);
			}catch (NumberFormatException nfe) {
				log.debug("Invalid debug level ["+debugLevel+"]", nfe);
			}
		}
		
		// Using the criteria API
		if(!needs_total) {
			recordList = dao.getDebugMonInfo(searchRecord,formattedFromDate, formattedToDate, isTimeNull, pageNum);
		}
		else if (needs_total) {
			total = dao.getTotalDebugMonInfo(searchRecord,formattedFromDate, formattedToDate, isTimeNull);
			recordList = dao.getDebugMonInfo(searchRecord,formattedFromDate, formattedToDate, isTimeNull, pageNum);
		}
		
		if(recordList.size() == 0)
			log.debug("No records found !!!");
		
		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}
		
		UIMetaData uiMetaData = null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}
		DebugMonitoringListRow dto = null;
		List<DebugMonitoringListRow> workRows = getDebugInfoList(workRequest, uiMetaData);
		for(CsMonDebug CsMonDebugdata : recordList) {
			dto = new DebugMonitoringListRow();
			dto.loadDebugData(CsMonDebugdata);
			workRows.add(dto);
		}	
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<String, WorkField> fields = workReq.getFields();
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue = "";
		WorkField currentfield = null;

		return validateFields(fieldDataMap);
	}

	private List<DebugMonitoringListRow> getDebugInfoList(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(CustomConstants.DEBUG_MTR_COL);
		workCollection.setSectionId(CustomConstants.DEBUG_MTR_SEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(CustomConstants.DEBUG_MTR_TAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<DebugMonitoringListRow> workRows = new ArrayList<DebugMonitoringListRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, CustomConstants.DEBUG_MTR_COL);
		workCollection.setRows(workRows);
		return workRows;
	}
}
