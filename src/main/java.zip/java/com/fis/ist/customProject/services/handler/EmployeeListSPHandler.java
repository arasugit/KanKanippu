package com.fis.ist.customProject.services.handler;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.efunds.t21.common.util.StringUtil;
import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.ForeignKeysCheckException;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.common.MKCHandler;
import com.fis.ist.common.dao.MkcQueue;
import com.fis.ist.customProject.dao.EmployeeDAO;
import com.fis.ist.customProject.domain.Employee;
import com.fis.ist.customProject.dto.EmpListSPRow;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.MenuService;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.EditableListRow;
import com.fis.ist.services.vo.WorkRequest;

public class EmployeeListSPHandler extends ISTRequestHandler {

	private static final ISTLogger log = ISTLogger.getLogger(EmployeeListSPHandler.class);
	private static String reqTypeId = CustomConstants.EMPLISTSP;
	private static String formAuthId = "EMPLISTSP";

	public EmployeeListSPHandler(){
		checkMKCEnabled(formAuthId);
	}
	
	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params)
			throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(
						WorkRequestHandlerData.RequestMode.ADD_NEW,
						workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null
					|| workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag =validateQueryFields(params,workRequest);
			if (errFlag)
			{
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		} 
		return workRequest;
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest,
			UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(
						WorkRequestHandlerData.RequestMode.ADD_NEW,
						workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null
					|| workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			// Create a logical collection for add
			List<EmpListSPRow> workRows = getNewWorkEMPLISTSPRows(workRequest, uiMetaData);
			workRows.add(getNewEMPLISTSPRowInstance());
		} catch (Exception ex) {
			throw ex;
		} 
		return workRequest;
	}

	private EmpListSPRow getNewEMPLISTSPRowInstance() {
		EmpListSPRow dto = new EmpListSPRow();
		dto.setDbAction('a');
		return dto;
	}

	public WorkRequest getEMPLISTSP(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}
	
	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params ) throws Exception{
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.EMPLISTSP);

		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(CustomConstants.EMPLISTSP);

			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);

			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(CustomConstants.EMPLISTSPTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(CustomConstants.EMPLISTSPTAB, workStatus);

			workReq.setTabStatus(tabStatus);

			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("employeeId".equals(field.getTag())) {
					String value = (String) params.get("employeeId");
					field.setValue(value);
				}
				if ("empName".equals(field.getTag())) {
					String value = (String) params.get("empName");
					field.setValue(value);
				}
				if ("departmentId".equals(field.getTag())) {
					String value = (String) params.get("departmentId");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

	public WorkRequest mkcSubmittedList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext,params);
		isCheckerRequest(formAuthId, AppConstants.MKC_ACTION_PENDING_REQ);
		if(workReq!=null && workReq.getRequestResult().equals(ResponseBase.REQUEST_RESULT_SUCCESS)){
			workReq = loadFromMKC(workReq, params,"submit");
		}
		return workReq;
	}
	
	public WorkRequest mkcReworkList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext,params);
		if(workReq!=null && workReq.getRequestResult().equals(ResponseBase.REQUEST_RESULT_SUCCESS)){
			workReq = loadFromMKC(workReq, params,"rework");
		}
		return workReq;
	}

	public WorkRequest loadFromMKC(WorkRequest workRequest,Map<String, String> params,String query)
	{
		if (query == null || query.trim().equals("") || (!query.equalsIgnoreCase("rework") && !query.equalsIgnoreCase("submit"))) {
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
			workRequest.setErrorDetail("Invalid query options passed");
			return workRequest;
		}
		try {
			List<MkcQueue> mkcrecords = getAllPendingMKCRequest(reqTypeId,query);
			UIMetaData uiMetaData=null;

			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);

			List<EmpListSPRow> workEmps =getNewWorkEMPLISTSPRows(workRequest ,uiMetaData);

			for (MkcQueue mkcrec : mkcrecords) {
				try {
					ByteArrayInputStream baip = new ByteArrayInputStream(mkcrec.getRecordObj());
					ObjectInputStream ois = new ObjectInputStream(baip);
					EmpListSPRow listObj = (EmpListSPRow) ois.readObject();
					if (listObj !=null) {
						listObj.setMkcId(mkcrec.getMkcId());
						listObj.setMkcRecordAction(mkcrec.getAction());
						listObj.setMkcStatus(mkcrec.getStatus());
						listObj.setMkcRemarks(mkcrec.getRemarks());
						listObj.setMakerId(mkcrec.getMakerId());
						listObj.setInactive("");
						listObj.setErrorFlag(false);
						listObj.setErrorMessage("");
						workEmps.add(listObj);
					}
				}catch (Exception e) {
					log.error("Unable to load records from Queue");
					WorkRequestHelper.getInstance().reportException(log, e, workRequest);
				}
			}

			// check if the submitted request from checker and merge the data from the database
			if (isCheckerAction && isMKCEnabled) {
				EmployeeDAO dao = new EmployeeDAO();

				Employee dbRecord ;
				EmpListSPRow mkcOrignalRecord;

				for (EmpListSPRow mkcRecord : workEmps)
				{
					if (mkcRecord.getDbAction().equals('c') && !mkcRecord.getMakerId().equals(getUserID())) {
						dbRecord = dao.findById(mkcRecord.getEmployeeId());
						if (dbRecord != null) {
							// which are information same between the mkc record and the original record, overwrite that field value from the latest db record
							// Unchanged information between the mkc record and the orignal record should be overwritten from the latest db record
							mkcOrignalRecord = mkcRecord.getOrignalRow();

							if (!isCellDataChanged(mkcOrignalRecord.getEmpName(), mkcRecord.getEmpName()))
								mkcRecord.setEmpName(dbRecord.getEmpName());

							if (!isCellDataChanged(mkcOrignalRecord.getEmail(), mkcRecord.getEmail()))
								mkcRecord.setEmail(dbRecord.getEmail());

							if (!isCellDataChanged(mkcOrignalRecord.getHireDate(), mkcRecord.getHireDate())){ 
								mkcRecord.setHireDate(dbRecord.getHireDate());
								mkcRecord.setHireDateAsString(mkcRecord.getHireDate());
							}

							if (!isCellDataChanged(mkcOrignalRecord.getSalary(), mkcRecord.getSalary()))
								mkcRecord.setSalary(dbRecord.getSalary());
							
							if (!isCellDataChanged(mkcOrignalRecord.getDepartmentId(), mkcRecord.getDepartmentId()))
								mkcRecord.setDepartmentId(dbRecord.getDepartmentId());
						}
					}
				}
			}
			if (mkcrecords.size()>0)
				workRequest.setLastModified(new Long(mkcrecords.size()));
		}catch (Exception e){
			log.error("unable to load the mkc data");
			WorkRequestHelper.getInstance().reportException(log, e, workRequest);
		}
		return workRequest;
	}

	public Boolean isCellDataChanged(Date first, Date second) {
		 if(first == null && second == null)
			 return false;

		 if(first != null && second != null)
			 return !(first.compareTo(second) == 0);
		 
		 if (first == null && second != null)
			 return true;

		 if (first != null && second == null)
			 return true;
		 
		 return false;
	}
	
	public Boolean isCellDataChanged(Double first, Double second) {
		 if(first == null && second == null)
			 return false;

		 if(first != null && second != null)
			 return !(first.compareTo(second) == 0);
		 
		 if (first == null && second != null)
			 return true;

		 if (first != null && second == null)
			 return true;
		 
		 return false;
	}

	public Boolean isCellDataChanged(Integer first, Integer second) {
		 if(first == null && second == null)
			 return false;

		 if(first != null && second != null)
			 return !(first.compareTo(second) == 0);
		 
		 if (first == null && second != null)
			 return true;

		 if (first != null && second == null)
			 return true;
		 
		 return false;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData)
			throws Exception {
		addWorkFields(workReq, uiMetaData, CustomConstants.EMPLISTSPTAB);
	}

	public void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load EMPLISTSP Definition");
		
		// needs_total variable is used to indicate whether the total count
		// should be fetched and sent to the client. First time,it will be set
		// to get the record count.
		boolean needs_total = "Y".equalsIgnoreCase(params.get("ist_total"));
		// ist_page_ctrl will contain the page number and according the records
		// will be fetched based on the pagesize and sent to the client.
		String pageCtrl = (String) params.get("ist_page_ctrl");
		Integer pageNum = pageCtrl == null ? null : Integer.valueOf(pageCtrl);
		int total = 0;

		String empId = params.get("employeeId");
		String empName = params.get("empName");
		String deptId = params.get("departmentId");

		// Read the parameters from the params object and invoke the DAO methods
		// to get the results.
		// results will hold the result set fetched from the database
		// if needs_total is set, the record the record count and set it to the
		// lastModified property of the workRequest.

		List<Employee> results = new ArrayList<Employee>();

		Employee findRecord = new Employee();
		
		if(StringUtil.isNotEmpty(empId)){
			try{
				findRecord.setEmployeeId(Integer.parseInt(empId));
			}catch (NumberFormatException nfe) {
				log.debug("Invalid employee id ["+empId+"]", nfe);
			}
		}

		findRecord.setEmpName(empName);
		
		if(StringUtil.isNotEmpty(deptId)){
			try{
				findRecord.setDepartmentId((Integer.parseInt(deptId)));
			}catch (NumberFormatException nfe) {
				log.debug("Invalid department id ["+deptId+"]", nfe);
			}
		}

		if (!needs_total) {
			results = loadEmployeeListSPData(findRecord, pageNum);
		} else if (needs_total) {
			total = loadEmployeeListSPDataCount(findRecord);
			results = loadEmployeeListSPData(findRecord, pageNum);
		}


		if (total == 0) {
			workRequest.setLastModified(-1L);
		} else {
			workRequest.setLastModified((long) total);
		}

		UIMetaData uiMetaData=null;
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		}
		catch (Exception e){
			log.error("unable to get the Meta data"+e.getMessage());
		}

		List<EmpListSPRow> workRows= getNewWorkEMPLISTSPRows(workRequest, uiMetaData);

		if (results == null || results.size() == 0) {
			return;
		}

		for (Employee employee: results) {
			if(employee != null){
				EmpListSPRow dto = new EmpListSPRow();
				dto.load(employee);
				dto.setDbAction('x');
				if (isMKCEnabled){
					dto.setOrignalRow(dto);
				}
				workRows.add(dto);
			}
		}
	}

	private List<EmpListSPRow> getNewWorkEMPLISTSPRows(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(CustomConstants.EMPLISTSPCOL);
		workCollection.setSectionId(CustomConstants.EMPLISTSPSEC);
        workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(CustomConstants.EMPLISTSPTAB);

		workRequest.getCollections().put(workCollection.getTag(),
				workCollection);

		List<EmpListSPRow> workRows = new ArrayList<EmpListSPRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, CustomConstants.EMPLISTSPCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	public WorkRequest getDataForAdd(UserContext userContext,
			WorkRequest workRequest) throws Exception {
		if (workRequest != null) {
			WorkCollection wc = workRequest.getCollections().get(CustomConstants.EMPLISTSPCOL);
			wc.getRows().add(0, getNewEMPLISTSPRowInstance());
			return workRequest;
		} else {
			WorkRequest workReq = new WorkRequest();
			UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.EMPLISTSP);
			try {

				workReq.setRequestId("0");
				workReq.setRequestState("DRAFT");
				workReq.setRequestTypeId(CustomConstants.EMPLISTSP);

				Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
				workReq.setNextStates(nextStates);

				// Set values of all tabs to be modifiable
				Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
				WorkTabStatus workStatus = new WorkTabStatus();
				workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
				workStatus.setTag(CustomConstants.EMPLISTSPTAB);
				workStatus.setModifyable("Y");
				tabStatus.put(CustomConstants.EMPLISTSPTAB, workStatus);

				workReq.setTabStatus(tabStatus);

				addWorkFields(workReq, uiMetaData);

				workReq = addNewWorkRequest(workReq, userContext, uiMetaData,
						null);

				Map<String, WorkField> fields = workReq.getFields();
				Collection<WorkField> cfields = fields.values();
				for (WorkField field : cfields) {
					field.setModifyable("Y");
					field.setVisible("Y");
				}
			} catch (Exception ex) {
		      	  WorkRequestHelper.getInstance().reportException(log, ex, workReq);
			}
			return workReq;
		}
	}

	public WorkRequest saveSinglePageRecords(UserContext userContext, WorkRequest workRequest,HashMap<String,Boolean> permMap) {
		try {
			workRequest = saveWorkRequest(userContext,workRequest,permMap);
		}catch (Exception e){
			log.error("Exception occured in the Save Single Pags Records"+e.getMessage());
		}
		return workRequest;
	}

	public WorkRequest saveWorkRequest(UserContext userContext,
			WorkRequest workRequest,HashMap<String, Boolean> permMap) throws Exception{
		if (validateCollectionField(workRequest,CustomConstants.EMPLISTSPCOL))
			return workRequest;

		save(userContext, workRequest,permMap);
		return workRequest;
	}

	private void save(UserContext userContext, WorkRequest workRequest, HashMap<String, Boolean> permMap) {
		// check if contact field data is present
		try{
			Map<String, WorkField> fields = workRequest.getFields();
			if (fields == null) {
				WorkRequestHelper.getInstance().reportError("Work fields not found", workRequest);
				return;
			}

			boolean isInvalidData = false;
			String value = null;
			List<EmpListSPRow> corrCollection = new ArrayList<EmpListSPRow>();
			List<String> duplicateCollection = new ArrayList<String>();
			EmployeeDAO dao = new EmployeeDAO();
			WorkCollection wc = workRequest.getCollections().get(CustomConstants.EMPLISTSPCOL);
			List<EmpListSPRow> rows = wc.getRows();

			//Only the affected rows will be available here.

			for(int i = 0; i < rows.size();i++){
				EmpListSPRow row = rows.get(i);
				row.setErrorFlag(false);
				String flag = row.getDbAction().toString();
				if(flag.equals("a")  &&!(permMap.get("I") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for adding a record");
					isInvalidData = true;
				}else if(flag.equals("c") && !(permMap.get("U") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for updating a record");
					isInvalidData = true;
				}else if(flag.equals("d") && !(permMap.get("D") || permMap.get("C"))){
					row.setErrorFlag(true);
					row.setErrorMessage("Access Denied for deleting a record");
					isInvalidData = true;
				}

				EmpListSPRow model = new EmpListSPRow();

				Object object = row.getEmployeeId();
				if(object == null){
					row.setErrorFlag(true);
					row.setErrorMessage("Employee ID cannot be empty");
					isInvalidData = true;
					continue;
				}
				model.setEmployeeId(row.getEmployeeId());
				String key = ""+model.getEmployeeId();

				value = row.getHireDateAsString();
				if(StringUtil.isEmpty(value)){
					row.setErrorFlag(true);
					row.setErrorMessage("Hire date cannot be empty");
					isInvalidData = true;
					continue;
				}

				if (isMKCEnabled && isCheckerAction){
					if(duplicateCollection.contains(key+row.getMkcStatus()) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())){
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same same Employee ID");
						isInvalidData = true;
						continue;
					}else{
						duplicateCollection.add(key+row.getMkcStatus());
					}
				}else{
					if(!flag.equals("d")){
						if(duplicateCollection.contains(key)){
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same Employee ID");
							isInvalidData = true;
							continue;
						}else{
							duplicateCollection.add(key);
						}
					}
				}

				if (isMKCEnabled && isCheckerAction){
					if("a".equals(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus()) && dao.findById(model.getEmployeeId()) != null){
						row.setErrorFlag(true);
						row.setErrorMessage("Duplicate record with same same Employee ID");
						isInvalidData = true;
						continue;
					}
				}else{
					if(flag.equals("a")){
						if(dao.findById(model.getEmployeeId()) != null){
							row.setErrorFlag(true);
							row.setErrorMessage("Duplicate record with same Employee ID");
							isInvalidData = true;
							continue;
						}
					}
				}

				if (isMKCEnabled && isCheckerAction && AppConstants.MKC_SP_ACTION_REWORK.equals(row.getMkcStatus()) && "d".equalsIgnoreCase(flag)){
					row.setErrorFlag(true);
					row.setErrorMessage("Deleted record cannot be set to rework");
					isInvalidData = true;
					continue;
				}

				if(isMKCEnabled && isCheckerAction && "d".equalsIgnoreCase(flag) && AppConstants.MKC_SP_ACTION_APPROVE.equalsIgnoreCase(row.getMkcStatus())){
					Employee employee = dao.findById(model.getEmployeeId());
					if (employee == null) {
						row.setErrorFlag(true);
						row.setErrorMessage("The record is already deleted. Please reject the record.");
						isInvalidData = true;
						continue;
					}
					dao.getSession().evict(employee);
				}
				corrCollection.add(row);
			}
			
			if(isInvalidData){
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0106");
				return;
			}
			
			if(isMKCEnabled && !isCheckerAction){ // maker changes should go into the queue
				for (EditableListRow edlsrow : corrCollection) {
					if (edlsrow!=null){
						EmpListSPRow dto = (EmpListSPRow)edlsrow;
						MKCHandler.getInstance().insertListRowIntoMKC(dto, dto.getEmployeeId().toString(), workRequest.getRequestTypeId(), getUserId(userContext), MenuService.getModuleName(reqTypeId));
					}
				}
			}else{
				for(EmpListSPRow dto:corrCollection)
				{
					String action = dto.getDbAction().toString();
					if(!isMKCEnabled){ // non mkc
						if("c".equalsIgnoreCase(action))
						{
							Employee employee = dao.findById(dto.getEmployeeId());
							if(employee != null){
								dto.store(employee);
								dao.attachDirty(employee);
							}
						}else if("a".equalsIgnoreCase(action)){
							Employee employee = new Employee();
							dto.store(employee);
							dao.save(employee);
						}else if("d".equalsIgnoreCase(action)){
							Employee employee = new Employee();
							dto.store(employee);
							dao.delete(employee);
						}
					}else if (isMKCEnabled && isCheckerAction){ // MKC Checker
						String status = dto.getMkcStatus();
						if((AppConstants.MKC_SP_ACTION_APPROVE).equals(status)){
							if ("c".equalsIgnoreCase(action)) {
								Employee employee = dao.findById(dto.getEmployeeId());
								if(employee != null){
									dto.store(employee);
									dao.attachDirty(employee);
								}
							} else if ("a".equalsIgnoreCase(action)) {
								Employee employee = new Employee();
								dto.store(employee);
								dao.save(employee);
							} else if ("d".equalsIgnoreCase(action)) {
								Employee employee = new Employee();
								dto.store(employee);
								dao.delete(employee);
							}
							MKCHandler.getInstance().ApproveMKCRecord(dto.getMkcId(),getUserId(userContext),dto.getMkcRemarks(),dto.getMkcScheduleDt());
						}else if(AppConstants.MKC_SP_ACTION_REJECT.equals(status) || AppConstants.MKC_SP_ACTION_REWORK.equals(status)){
							MKCHandler.getInstance().RejectOrReturnRecord(dto.getMkcId(),getUserId(userContext),dto.getMkcRemarks(),dto.getMkcScheduleDt(),status);
						}else{
						}
					}
				}
			}
			workRequest.setMessageId(ResponseBase.RESPONSE_CODE_NONE);
			workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_SUCCESS);
			workRequest.setErrorDetail("");
			rows.clear();
		}catch (Exception e){
		   workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
           workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
           workRequest.setErrorDetail(e.getMessage());
   		   if(e instanceof ForeignKeysCheckException){
			   workRequest.setMessageSubstitutions(((ForeignKeysCheckException)e).getChildTables());				  
		   }
		}
	}

	private List<Employee> loadEmployeeListSPData(Employee model, int pageNum) {
		log.debug("Load Employee records - loadEmployeeListSPData()");
		EmployeeDAO dao = new EmployeeDAO();
		List<Employee> results = dao.findByExample(model, pageNum);
		return results;
	}

	private int loadEmployeeListSPDataCount(Employee model) {
		log.debug("Load Employee records - loadEmployeeListSPDataCount()");
		EmployeeDAO dao = new EmployeeDAO();
		int count = dao.getTotalByExample(model);
		return count;
	}
	
	public HashMap<String,String> getDBMapping()
	{
		HashMap<String,String> dtoMapping = new HashMap<String, String>();
		dtoMapping.put("employeeId","employeeId");
		dtoMapping.put("empName","empName");
		dtoMapping.put("email","email");
		dtoMapping.put("hireDate","hireDateAsString");
		dtoMapping.put("salary","salary");
		dtoMapping.put("departmentId","departmentId");
		return dtoMapping;
	}

	private Boolean validateQueryFields(Map<String, String> params,WorkRequest workReq) throws Exception{
		Map<String, WorkField> fields = workReq.getFields();
		Map <WorkField,String> fieldDataMap = new HashMap<WorkField, String>();

		String fieldValue="";
		WorkField currentfield = null;


		currentfield = fields.get("employeeId");
		fieldValue = params.get("employeeId");
		fieldDataMap.put(currentfield,fieldValue);

		currentfield = fields.get("empName");
		fieldValue = params.get("empName");
		fieldDataMap.put(currentfield,fieldValue);

		currentfield = fields.get("departmentId");
		fieldValue = params.get("departmentId");
		fieldDataMap.put(currentfield,fieldValue);

		return validateFields(fieldDataMap);
	}
}