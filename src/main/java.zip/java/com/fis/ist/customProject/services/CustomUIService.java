package com.fis.ist.customProject.services;

import com.fis.ist.customProject.hibernate.CustomTransactionHelper;
import com.fis.ist.services.UIService;


public class CustomUIService extends UIService {
	public CustomUIService() { super(); }
	
	public CustomUIService(boolean do_entitlement) 
	{
		super(do_entitlement);
	}
	
	public CustomUIService(boolean do_entitlement, boolean preload) 
	{	
		super(do_entitlement, preload);
	}
	
	@Override
	protected void closeHibernateSessions(boolean commit) throws Exception {
		CustomTransactionHelper.closeHibernateSessions(commit);
		super.closeHibernateSessions(commit);
	}

	@Override
	protected void setReadOnlyHibernateSessions(boolean val) {
		CustomTransactionHelper.setReadOnlyHibernateSessions(val);
		super.setReadOnlyHibernateSessions(val);
	}
}