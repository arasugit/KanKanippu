package com.fis.ist.customProject.dto;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fis.ist.customProject.domain.Employee;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class EmpListSPRow  extends EditableListRowForSDK implements Cloneable{
	private static final ISTLogger log = ISTLogger.getLogger(EmpListSPRow.class);
	private Integer employeeId;
	private String empName;
	private String email;
	private Date hireDate;
	private BigDecimal salary;
	private Integer departmentId;
	private String hireDateAsString;
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	
	private EmpListSPRow orignalRow;


	public void load(Employee model)
	{
		setEmployeeId(model.getEmployeeId());
		setEmpName(model.getEmpName());
		setEmail(model.getEmail());
		setHireDate(model.getHireDate());
		setSalary(model.getSalary());
		setDepartmentId(model.getDepartmentId());
		setHireDateAsString(model.getHireDate() != null ? sdf.format(model.getHireDate()) : "");
	}

	public void store(Employee model){
		model.setEmployeeId(employeeId);
		model.setEmpName(empName);
		model.setEmail(email);
		try {
			model.setHireDate(sdf.parse(hireDateAsString));
		} catch (ParseException e) {
		}
		model.setSalary(salary);
		model.setDepartmentId(departmentId);		
	}
	
	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getHireDateAsString() {
		return hireDateAsString;
	}

	public void setHireDateAsString(String hireDateAsString) {
		this.hireDateAsString = hireDateAsString;
	}

	public EmpListSPRow getOrignalRow() {
		return orignalRow;
	}

	public void setOrignalRow(EmpListSPRow orignalRow){
		try{
			if(orignalRow != null)
				this.orignalRow = (EmpListSPRow) orignalRow.clone();
		}catch (Exception e){
			log.error(e);
		}
	}

	public void setHireDateAsString(Date date) {
		setHireDateAsString(date != null ? sdf.format(date) : "");
	}

	@Override
	public String getFormKey() {
		return "employeeId";
	}
}