package com.fis.ist.customProject.services;
import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.audit.FormAudit;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.customProject.services.handler.EmployeeListSPHandler;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.CRUDSubService;
import com.fis.ist.services.vo.WorkRequest;

public class EmployeeListSP extends CRUDSubService
{
    private static final ISTLogger log = ISTLogger.getLogger(EmployeeListSP.class);
   	public WorkRequest getService
		(
			UserContext userContext,
			String requestType,
			String action,
		   	Map<String, String>requestParams
		) throws Exception
	{
		WorkRequest workReq = null;
		EmployeeListSPHandler ddh = new EmployeeListSPHandler();
		if(action.compareTo(CustomConstants.ACTION_QUERY) == 0) {
			workReq = ddh.getEMPLISTSP(userContext, requestParams);
		}  else if (AppConstants.MKC_ACTION_PENDING_REQ.equals(action)){
   			workReq = ddh.mkcSubmittedList(userContext, requestParams);
   		}else if ( AppConstants.MKC_ACTION_REWORK_REQ.equals(action)){
   			workReq = ddh.mkcReworkList(userContext, requestParams); 
   		}else {
			log.error("**** Employee single page (EMPLISTSP) List: getService() inbound...unknown action: " + action);
			throw new Exception("Unknown action error");
		 }
		new FormAuditHandler().saveFormAudit(userContext,requestType,action,workReq,CustomConstants.SWITCH_SUBSYSTEM);
        WorkRequestCacher.getInstance().put(userContext,workReq);
		return workReq;
	}
   	public WorkRequest setService
		(
			UserContext userContext,
			String requestType,
			String action,
		   	WorkRequest workRequest
		) throws Exception
	{
		FormAuditHandler ah = new FormAuditHandler();
		FormAudit handle = ah.beginEditableListAudit(userContext, requestType, action, workRequest,CustomConstants.SWITCH_SUBSYSTEM);
   		WorkRequest workReq = new WorkRequest();
   		EmployeeListSPHandler ddh = new EmployeeListSPHandler();
   		if(action.compareTo(CustomConstants.ACTION_INSERT) == 0){
   			workReq = ddh.getDataForAdd(userContext,workRequest);
   		}else if(action.compareTo(CustomConstants.ACTION_SINGLE_BATCH_SAVE) == 0){   				
   			workReq = ddh.saveWorkRequest(userContext,workRequest,setPermissions());
   		}else if(action.compareTo(AppConstants.MKC_ACTION_BATCH_SAVE) == 0){   				
   			workReq = ddh.saveBatchByChecker(userContext,workRequest,setPermissions());
   		}else{
   			log.error("**** Employee single page (EMPLISTSP) List: setService() inbound...unknown request type");
   			throw new Exception("Unknown request type");
   		}
        ah.saveEditableListAudit(handle, workReq);
   		return workReq;
	}
}