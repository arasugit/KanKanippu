package com.fis.ist.customProject.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CS_MONDEBUG")
public class CsMonDebug implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String product;
	private String nodeid;
	private String logdate;
	private String filename;
	private String pid;
	private String debuglevel;
	private String debug;

	public CsMonDebug() {}

	@Id
	@Column(name = "ID", nullable = false, length = 38)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(name = "PRODUCT", nullable = false, length = 50)
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@Column(name = "NODEID", nullable = false, length = 50)
	public String getNodeid() {
		return nodeid;
	}

	public void setNodeid(String nodeid) {
		this.nodeid = nodeid;
	}

	@Column(name = "LOGDATE", nullable = false)
	public String getLogdate() {
		return logdate;
	}

	public void setLogdate(String logdate) {
		this.logdate = logdate;
	}

	@Column(name = "FILENAME", nullable = false, length = 50)
	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	@Column(name = "PID", length = 50)
	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	@Column(name = "DEBUGLEVEL", length = 50)
	public String getDebuglevel() {
		return debuglevel;
	}

	public void setDebuglevel(String debuglevel) {
		this.debuglevel = debuglevel;
	}

	@Column(name = "DEBUG", length = 500)
	public String getDebug() {
		return debug;
	}

	public void setDebug(String debug) {
		this.debug = debug;
	}
}

