package com.fis.ist.customProject.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "EMPLOYEE" )
public class Employee implements java.io.Serializable {

	private Integer employeeId;
	private String empName;
	private String email;
	private Date hireDate;
	private BigDecimal salary;
	private Integer departmentId;

	public Employee() {	}

	public Employee(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Employee(Integer employeeId, String empName, String email,
			Date hireDate, BigDecimal salary, Integer departmentId) {
		this.employeeId = employeeId;
		this.empName = empName;
		this.email = email;
		this.hireDate = hireDate;
		this.salary = salary;
		this.departmentId = departmentId;
	}

	@Id
	@Column(name = "EMPLOYEE_ID", unique = true, nullable = false, precision = 6, scale = 0)
	public Integer getEmployeeId() {
		return this.employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	@Column(name = "EMP_NAME", length = 30)
	public String getEmpName() {
		return this.empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Column(name = "EMAIL", length = 20)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "HIRE_DATE", nullable = false, length = 7)
	public Date getHireDate() {
		return this.hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	@Column(name = "SALARY", precision = 12)
	public BigDecimal getSalary() {
		return this.salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	@Column(name = "DEPARTMENT_ID", precision = 4, scale = 0)
	public Integer getDepartmentId() {
		return this.departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

}