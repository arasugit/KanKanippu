package com.fis.ist.customProject;

import com.fis.ist.hibernate.SessionFactory;
import com.fis.ist.log.ISTLogger;

public class CustomHibernateSessionFactory extends SessionFactory 
{
	private static final ISTLogger log = ISTLogger.getLogger(CustomHibernateSessionFactory.class);
    private static String CONFIG_FILE_LOCATION = "/com/fis/ist/customProject/config/hibernate.cfg.xml";
	private static volatile CustomHibernateSessionFactory instance = new CustomHibernateSessionFactory();  
    public static synchronized CustomHibernateSessionFactory getInstance()
	{
		return instance;
	}
	
	private CustomHibernateSessionFactory()
	{
		super(CONFIG_FILE_LOCATION);
	}

	
}
