package com.fis.ist.customProject.services;
import com.fis.ist.services.SimpleListSubservice;
import com.fis.ist.services.handler.ISimpleListHandler;
import com.fis.ist.customProject.services.handler.TransactionLogsListHandler;

public class TransactionLogsList extends SimpleListSubservice
{
	private TransactionLogsListHandler transLog = new TransactionLogsListHandler();
	protected boolean doCache() { return true; }
   	protected String getAuditName() { return "Transaction Logs"; }
	@Override
	protected ISimpleListHandler getListHandler() {
		return transLog;
	}
	@Override
	protected String getName() {
		return "Transaction logs list";
	}
};
