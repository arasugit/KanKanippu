package com.fis.ist.customProject.dao;
import java.math.BigDecimal;
import java.io.Serializable;

public class ShcLogId implements Serializable
{
    private String chipIndex;
    private BigDecimal siteId;
    
    public ShcLogId() {
    }
    
    public ShcLogId(final String chipIndex, final BigDecimal siteId) {
        this.chipIndex = chipIndex;
        this.siteId = siteId;
    }
    
    public String getChipIndex() {
        return this.chipIndex;
    }
    
    public void setChipIndex(final String chipIndex) {
        this.chipIndex = chipIndex;
    }
    
    public BigDecimal getSiteId() {
        return this.siteId;
    }
    
    public void setSiteId(final BigDecimal siteId) {
        this.siteId = siteId;
    }
}
