package com.fis.ist.customProject.services.handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.efunds.t21.services.cache.base.CacheFactory;
import com.efunds.t21.services.vo.ResponseBase;
import com.efunds.t21.services.vo.UIMetaData;
import com.efunds.t21.services.vo.UserContext;
import com.efunds.t21.services.vo.WorkCollection;
import com.efunds.t21.services.vo.WorkField;
import com.efunds.t21.services.vo.WorkNextState;
import com.efunds.t21.services.vo.WorkTabStatus;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.common.ISTRequestHandler;
import com.fis.ist.customProject.dto.ISTDashCommandRow;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.dao.TransactionsDAO;
import com.fis.ist.monitoring.dto.Pair;
import com.fis.ist.services.helpers.WorkRequestHelper;
import com.fis.ist.services.requests.WorkRequestHandlerData;
import com.fis.ist.services.vo.WorkRequest;

public class ISTDashCommandListHandler extends ISTRequestHandler {

	private static final ISTLogger log = ISTLogger.getLogger(ISTDashCommandListHandler.class);
	private static String reqTypeId = CustomConstants.TSKCMD;
	private static String formAuthId = "TSKCMD";
	
	public ISTDashCommandListHandler(){
		checkMKCEnabled(formAuthId);
	}
	
	public WorkRequest getServerMailList(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = prepareWorkRequest(userContext, params);
		load(workReq, params);
		return workReq;
	}

	private void load(WorkRequest workRequest, Map<String, String> params) {
		log.debug("Load IST Dashboard Handler ....");
		
		TransactionsDAO dao = new TransactionsDAO();
		UIMetaData uiMetaData = null;
		
		try {
			uiMetaData = CacheFactory.getInstance().getMetaData(reqTypeId);
		} catch (Exception e) {
			log.error("unable to get the Meta data" + e.getMessage());
		}

		List<ISTDashCommandRow> data = new ArrayList<ISTDashCommandRow>();
		
		List<Pair<String, Integer>> connection = dao.getConnectionCountGroupByServiceMail(params);
				
		connection.forEach(x ->
		{
			ISTDashCommandRow dto = data.stream()
				.filter(r -> x.getKey().equalsIgnoreCase(r.getServerMailId().trim()))
				.findAny()
				.orElse(null);
			
			if (dto == null) {
				dto = new ISTDashCommandRow();
				dto.setServerMailId(x.getKey().trim());
				data.add(dto);
			}
			
			dto.setServerMailCount(x.getValue());
		});	
		
		List<ISTDashCommandRow> workRows = prepareWorkCollection(workRequest, uiMetaData);
		
		if (data.size() == 0) {
			workRequest.setLastModified(-1L);
			return;
		}
		
		workRequest.setLastModified((long) data.size());
		workRows.addAll(data);
	}

	private WorkRequest addNewWorkRequest(WorkRequest workRequest, UserContext userContext, UIMetaData uiMetaData,
			WorkRequestHandlerData data, Map<String, String> params) throws Exception {

		try {

			if (data == null) {
				data = new WorkRequestHandlerData(WorkRequestHandlerData.RequestMode.ADD_NEW, workRequest, userContext);
			}

			data.setUiMetaData(uiMetaData);

			data.initLastModified();

			if (workRequest.getSwitchId() == null || workRequest.getSwitchId().trim().equals("")) {
				workRequest.setSwitchId(userContext.getSwitchID());
			}

			boolean errFlag = validateQueryFields(params, workRequest);
			if (errFlag) {
				workRequest.setMessageId(ResponseBase.RESPONSE_CODE_ERROR);
				workRequest.setRequestResult(ResponseBase.REQUEST_RESULT_ERROR);
				workRequest.setErrorDetail("E0134");
				return workRequest;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return workRequest;
	}

	private Boolean validateQueryFields(Map<String, String> params, WorkRequest workReq) throws Exception {
		Map<WorkField, String> fieldDataMap = new HashMap<WorkField, String>();

		return validateFields(fieldDataMap);
	}

	private List<ISTDashCommandRow> prepareWorkCollection(WorkRequest workRequest, UIMetaData uiMetaData) {
		WorkCollection workCollection = new WorkCollection();
		workCollection.setErrorInfo("");
		workCollection.setModifyable("N");
		workCollection.setVisible("Y");
		workCollection.setTag(CustomConstants.TSKCMDCOL);
		workCollection.setSectionId(CustomConstants.TSKCMDSEC);
		workCollection.setDbMappingAttr(getDBMapping());
		workCollection.setTabId(CustomConstants.TSKCMDTAB);
		workRequest.getCollections().put(workCollection.getTag(), workCollection);

		List<ISTDashCommandRow> workRows = new ArrayList<ISTDashCommandRow>();
		updateWorkCollectionFields(workRequest, uiMetaData, CustomConstants.TSKCMDCOL);
		workCollection.setRows(workRows);
		return workRows;
	}

	private void addWorkFields(WorkRequest workReq, UIMetaData uiMetaData) throws Exception {
		addWorkFields(workReq, uiMetaData, CustomConstants.TSKCMDTAB);
	}

	private WorkRequest prepareWorkRequest(UserContext userContext, Map<String, String> params) throws Exception {
		WorkRequest workReq = new WorkRequest();
		UIMetaData uiMetaData = CacheFactory.getInstance().getMetaData(CustomConstants.TSKCMD);
		
		
		log.debug("By Loading TaskListHandler and prepareWorkRequest for port dashboard " +  params);

		try {

			workReq.setRequestId("0");
			workReq.setRequestState("DRAFT");
			workReq.setRequestTypeId(CustomConstants.TSKCMD);

			Map<String, WorkNextState> nextStates = new HashMap<String, WorkNextState>();
			workReq.setNextStates(nextStates);

			Map<String, WorkTabStatus> tabStatus = new HashMap<String, WorkTabStatus>();
			WorkTabStatus workStatus = new WorkTabStatus();
			workStatus.setStatus(WorkTabStatus.WORK_TAB_STATUS_NOT_STARTED);
			workStatus.setTag(CustomConstants.TSKCMDTAB);
			workStatus.setModifyable("Y");
			tabStatus.put(CustomConstants.TSKCMDTAB, workStatus);

			workReq.setTabStatus(tabStatus);

			addWorkFields(workReq, uiMetaData);

			Map<String, WorkField> fields = workReq.getFields();
			Collection<WorkField> cfields = fields.values();
			for (WorkField field : cfields) {
				if ("product".equals(field.getTag())) {
					String value = (String) params.get("product");
					field.setValue(value);
				}
				if ("nodeId".equals(field.getTag())) {
					String value = (String) params.get("nodeId");
					field.setValue(value);
				}
				if ("istCommand".equals(field.getTag())) {
					String value = (String) params.get("istCommand");
					field.setValue(value);
				}
				field.setModifyable("Y");
				field.setVisible("Y");
			}
			workReq = addNewWorkRequest(workReq, userContext, uiMetaData, null, params);
		} catch (Exception ex) {
			WorkRequestHelper.getInstance().reportException(log, ex, workReq);
		}
		return workReq;
	}

}
