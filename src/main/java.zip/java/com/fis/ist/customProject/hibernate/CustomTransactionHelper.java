
package com.fis.ist.customProject.hibernate;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.fis.ist.log.ISTLogger;

public class CustomTransactionHelper
{
	private static final ISTLogger log = ISTLogger.getLogger(CustomTransactionHelper.class);

  	private static void closeHibernateSession(Session sess, boolean commit, String label) throws Exception
   	{
   		if (sess == null)
   			return;
		if (!sess.isOpen())
   			return;
   		log.debug("Closing: "+ label);
   		Transaction t = null;
   		try
   		{
   			if (sess.isDirty())
   			{
   				if (commit)
   				{
   					log.debug("Flushing dirty session: " + label);
   					sess.flush();
   				}
   				else
   				{
   					log.debug("Not flushing dirty session");
   				}
   			}
   			t = sess.getTransaction();
   			if (t == null)
   				log.debug("No transaction");
   			else
   			{
   				boolean active_txn = t.isActive();
   				log.debug("active transaction: " + active_txn);
   				if (active_txn)
   				{
   					if (commit)
   						t.commit();
   					else
   						t.rollback();
   				}
   			}
   		}
   		catch (Exception e)
   		{
 			log.error(e);
			Transaction t2 = sess.getTransaction();
			if (t2 != null)
				t2.rollback();
   			throw e;
   		}
   		finally
   		{
   			sess.close();
   		}
   	}
  	
  	/**
  	 * Close custom hibernate sessions, flushing them if commit is true.
  	 * Used at the end of a remote call.
  	 */
	public static void closeHibernateSessions(boolean commit) throws Exception {
		Session s = null;
		s = com.fis.ist.customProject.CustomHibernateSessionFactory.getInstance().getCurrentSession();
		closeHibernateSession(s, commit, "Custom");
		Session session = com.fis.ist.monitoring.MonitorHibernateSessionFactory.getInstance().getCurrentSession();
		closeHibernateSession(session, commit, "monitor");
	}
	
	public static void setReadOnlyHibernateSessions(boolean val)
	{
		com.fis.ist.customProject.CustomHibernateSessionFactory.getInstance().setReadOnly(val);	
		com.fis.ist.monitoring.MonitorHibernateSessionFactory.getInstance().setReadOnly(val);
	}
}
