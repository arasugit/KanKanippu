package com.fis.ist.customProject.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CS_MONINCOUT" )
public class IncidentAction implements java.io.Serializable {

	private Integer cfgId;
	private Integer incId;
	private Date incDate;          //OPEN_DATE
	private String status;
	private String smsStatus;
	private String emailStatus;
	private Date closeDate;
	private String escType;
	private Integer age;
	private String resolution;
	private String clearedBy;
	private String description;
	
		
	public IncidentAction() {
	}

	public IncidentAction(Integer cfgId) {
		this.cfgId = cfgId;
	}

	public IncidentAction(Integer cfgId, Integer incId, Date incDate, String status, String smsStatus,
			String emailStatus, Date closeDate, String escType, Integer age, String resolution, String clearedBy,
			String description) {
		super();
		this.cfgId = cfgId;
		this.incId = incId;
		this.incDate = incDate;
		this.status = status;
		this.smsStatus = smsStatus;
		this.emailStatus = emailStatus;
		this.closeDate = closeDate;
		this.escType = escType;
		this.age = age;
		this.resolution = resolution;
		this.clearedBy = clearedBy;
		this.description = description;
	}
	

	@Column(name = "CFGID",unique = true, nullable = false, precision = 6, scale = 0)
	public Integer getCfgId() {
		return this.cfgId;
	}

	public void setCfgId(Integer cfgId) {
		this.cfgId = cfgId;
	}
	
	@Id
	@Column(name = "INCID",unique = true, nullable = false, precision = 6, scale = 0)
	public Integer getIncId() {
		return this.incId;
	}

	public void setIncId(Integer incId) {
		this.incId = incId;
	}	
	
	@Temporal(TemporalType.DATE)
	@Column(name = "OPEN_DATE", nullable = true, length = 7)
	public Date getIncDate() {
		return this.incDate;
	}

	public void setIncDate(Date incDate) {
		this.incDate = incDate;
	}
	
	
	@Column(name = "STATUS", length = 30)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "SMSSTATUS", length = 20)
	public String getSmsStatus() {
		return this.smsStatus;
	}

	public void setSmsStatus(String smsStatus) {
		this.smsStatus = smsStatus;
	}

	@Column(name = "EMAILSTATUS", length = 20)
	public String getEmailStatus() {
		return this.emailStatus;
	}

	public void setEmailStatus(String emailStatus) {
		this.emailStatus = emailStatus;
	}
	
	@Temporal(TemporalType.DATE)
	@Column(name = "CLOSE_DATE", nullable = true, length = 7)
	public Date getCloseDate() {
		return closeDate;
	}

	public void setCloseDate(Date closeDate) {
		this.closeDate = closeDate;
	}
	
	@Column(name = "ESC_TYPE", length = 5)
	public String getEscType() {
		return escType;
	}

	public void setEscType(String escType) {
		this.escType = escType;
	}
	
	@Column(name = "AGE")
	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
	
	@Column(name = "RESOLUTION", length = 20)
	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}
	
	@Column(name = "CLEARED_BY", length = 20)
	public String getClearedBy() {
		return clearedBy;
	}

	public void setClearedBy(String clearedBy) {
		this.clearedBy = clearedBy;
	}

	@Override
	public String toString() {
		return "IncidentAction [cfgId=" + cfgId + ", incId=" + incId + ", incDate=" + incDate + ", status=" + status
				+ ", smsStatus=" + smsStatus + ", emailStatus=" + emailStatus + ", closeDate=" + closeDate
				+ ", escType=" + escType + ", age=" + age + ", resolution=" + resolution + ", clearedBy=" + clearedBy
				+ ", description=" + description + "]";
	}

}