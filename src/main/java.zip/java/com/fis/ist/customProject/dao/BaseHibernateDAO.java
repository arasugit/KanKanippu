package com.fis.ist.customProject.dao;

import com.fis.ist.customProject.CustomHibernateSessionFactory;
import com.fis.ist.hibernate.HibernateDAO;

public abstract class BaseHibernateDAO extends HibernateDAO 
{
	public BaseHibernateDAO()
	{
		super(CustomHibernateSessionFactory.getInstance());
	}
}