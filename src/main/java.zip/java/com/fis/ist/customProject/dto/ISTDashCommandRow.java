package com.fis.ist.customProject.dto;

public class ISTDashCommandRow implements java.io.Serializable {
private static final long serialVersionUID = 1L;
	
	private String serverMailId;
	private Integer serverMailCount;

	public String getServerMailId() {
		return serverMailId;
	}
	
	public void setServerMailId(String serverMailId) {
		this.serverMailId = serverMailId;
	}
	
	public Integer getServerMailCount() {
		return serverMailCount;
	}
	
	public void setServerMailCount(Integer serverMailCount) {
		this.serverMailCount = serverMailCount;
	}
}

