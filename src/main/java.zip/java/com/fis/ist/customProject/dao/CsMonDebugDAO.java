package com.fis.ist.customProject.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.Criteria;
import org.hibernate.query.Query;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.type.StringType;

import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.customProject.domain.CsMonDebug;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.dao.MonitorBaseDAO;

public class CsMonDebugDAO extends MonitorBaseDAO<CsMonDebug, Integer> {

	private static final ISTLogger log = ISTLogger.getLogger(CsMonDebugDAO.class);
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Class<CsMonDebug> getEntityClass() {
		return CsMonDebug.class;
	}

	
	public List getFileNames(String product) {
		log.debug("get Debug Monitoring dropdown list for file names..");
		try {

			String queryString = "select distinct field_value1 as filename from cs_monglobalvalue where field_name = 'mondebuglogger' and product = :product";
			Query queryObject = createSQLQuery(queryString).addScalar("filename", StandardBasicTypes.STRING);
			
			queryObject.setParameter("product", product);

			List result = queryObject.list();

			log.debug("Result of Debug Monitoring filename " + result.toString());
			return result;
		} catch (RuntimeException re) {
			log.error("Exception Occured in getFileNames dropdown list.. failed", re);
			throw re;
		}
	}
	
	// To alter the session
	public void altersession() {
		log.debug("altersession list..");
		try {
			String queryString = "alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS'";

			Query queryObject = createSQLQuery(queryString);

			int i = queryObject.executeUpdate();

			log.debug("session altered :" + i);

			// return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Exception Occured... failed", re);
			throw re;
		}
	}

	
	public List<CsMonDebug> getDebugMonInfo(CsMonDebug instance, String fromDate,
			String toDate, boolean isTimeNull,Integer pageNum) {
		log.debug("getDebugMonInfo - Fetch data from CsMonDebug ");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(CsMonDebug.class);
			HashMap<String, Object> condition = new HashMap<String, Object>();
			String value = null;
			
			value = instance.getProduct();
			if (StringUtil.isNotEmpty(value)) {
				condition.put("product", value);
			}

			value = instance.getNodeid();
			if (StringUtil.isNotEmpty(value)) {
				condition.put("nodeid", value);
			}

			value = instance.getFilename();
			if (StringUtil.isNotEmpty(value)) {
				condition.put("filename", value);
			}
			
			value = instance.getDebuglevel();
			if (StringUtil.isNotEmpty(value)) {
				condition.put("debuglevel", value);
			}
			
			if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())){
				if (StringUtil.isNotEmpty(fromDate)) {
					fromDate = formattedDateForPostgres(fromDate,isTimeNull);
					try {
						c.add(Restrictions.sqlRestriction("CAST({alias}.logdate AS TIMESTAMP) >= CAST(? AS TIMESTAMP )", fromDate, StringType.INSTANCE));
					} catch(RuntimeException e) {
						log.error("getTotalDebugMonInfo PostgreSQL fromDate failed", e);
					}
				}
				
				if (StringUtil.isNotEmpty(toDate)) {
					toDate = formattedDateForPostgres(toDate,isTimeNull);
					try {
						if(isTimeNull)
							c.add(Restrictions.sqlRestriction("CAST({alias}.logdate AS TIMESTAMP) < CAST(? AS TIMESTAMP )", toDate, StringType.INSTANCE));
						else
							c.add(Restrictions.sqlRestriction("CAST({alias}.logdate AS TIMESTAMP) <= CAST(? AS TIMESTAMP )", toDate, StringType.INSTANCE));
					} catch(RuntimeException e) {
						log.error("getTotalDebugMonInfo PostgreSQL toDate failed", e);
					}
				}
			}
			else {
				if (StringUtil.isNotEmpty(fromDate)) {
					try {
						c.add(Restrictions.ge("logdate", fromDate));
					} catch (RuntimeException e) {
						log.error("getTotalDebugMonInfo fromDate failed", e);
					}
				}

				if (StringUtil.isNotEmpty(toDate)) {
					try {
						if(isTimeNull)
							c.add(Restrictions.lt("logdate", toDate));
						else
							c.add(Restrictions.le("logdate", toDate));
					} catch (RuntimeException e) {
						log.error("getTotalDebugMonInfo toDate failed", e);
					}
				}
			}
			
			List<CsMonDebug> results = new ArrayList<CsMonDebug>();
			c = c.add(Restrictions.allEq(condition));
			setPaging(c, pageNum);
			results = c.list();
			log.debug("getDebugMonInfo successful, result size: " + results.size());

			return results;
		} catch (RuntimeException re) {
			log.error("getDebugMonInfo failed...", re);
			throw re;
		}
	}

	
	public int getTotalDebugMonInfo(CsMonDebug instance, String fromDate, String toDate, boolean isTimeNull) {
		log.debug("getTotalDebugMonInfo - fetch total count ");
		Integer count = null;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(CsMonDebug.class);
			c.setProjection(Projections.rowCount());
			
			HashMap<String, Object> condition = new HashMap<String, Object>();
			String value = null;

			value = instance.getProduct();
			if (StringUtil.isNotEmpty(value)) {
				condition.put("product", value);
			}

			value = instance.getNodeid();
			if (StringUtil.isNotEmpty(value)) {
				condition.put("nodeid", value);
			}

			value = instance.getFilename();
			if (StringUtil.isNotEmpty(value)) {
				condition.put("filename", value);
			}
			
			value = instance.getDebuglevel();
			if (StringUtil.isNotEmpty(value)) {
				condition.put("debuglevel", value);
			}
			
			if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())){
				if (StringUtil.isNotEmpty(fromDate)) {
					fromDate = formattedDateForPostgres(fromDate,isTimeNull);
					try {
						c.add(Restrictions.sqlRestriction("CAST({alias}.logdate AS TIMESTAMP) >= CAST(? AS TIMESTAMP )", fromDate, StringType.INSTANCE));
					} catch(RuntimeException e) {
						log.error("getTotalDebugMonInfo PostgreSQL fromDate failed", e);
					}
				}
				
				if (StringUtil.isNotEmpty(toDate)) {
					toDate = formattedDateForPostgres(toDate,isTimeNull);
					try {
						if(isTimeNull)
							c.add(Restrictions.sqlRestriction("CAST({alias}.logdate AS TIMESTAMP) < CAST(? AS TIMESTAMP )", toDate, StringType.INSTANCE));
						else
							c.add(Restrictions.sqlRestriction("CAST({alias}.logdate AS TIMESTAMP) <= CAST(? AS TIMESTAMP )", toDate, StringType.INSTANCE));
					} catch(RuntimeException e) {
						log.error("getTotalDebugMonInfo PostgreSQL toDate failed", e);
					}
				}
			}
			else {
				if (StringUtil.isNotEmpty(fromDate)) {
					try {
						c.add(Restrictions.ge("logdate", fromDate));
					} catch (RuntimeException e) {
						log.error("getTotalDebugMonInfo fromDate failed", e);
					}
				}

				if (StringUtil.isNotEmpty(toDate)) {
					try {
						if(isTimeNull)
							c.add(Restrictions.lt("logdate", toDate));
						else
							c.add(Restrictions.le("logdate", toDate));
					} catch (RuntimeException e) {
						log.error("getTotalDebugMonInfo toDate failed", e);
					}
				}
			}
				
			Long sLong = (Long) c.add(Restrictions.allEq(condition)).uniqueResult();
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;
			log.debug("getTotalDebugMonInfo successful, no. of records: " + count);

			return count;
		} catch (RuntimeException re) {
			log.error("getTotalDebugMonInfo failed...", re);
			throw re;
		}
	}
	
	
	// Format date for PostgreSQL
	String formattedDateForPostgres(String ipDate, boolean isTimeNull) {
		
		SimpleDateFormat ipFormat = isTimeNull ? new SimpleDateFormat("dd-MMM-yyyy") : new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
		Date parsedDate = null;
		try {
			parsedDate = ipFormat.parse(ipDate);
		} catch (ParseException e) {
			log.debug("formattedDateForPostgres failed could not parse ipDate : "+ ipDate);
			log.error(e);
		}
		
		SimpleDateFormat opFormat = isTimeNull ? new SimpleDateFormat("yyyy-MM-dd") : new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String formattededDate = opFormat.format(parsedDate);
		
		return formattededDate;
	} 
}
