package com.fis.ist.customProject.dto;

import com.fis.ist.common.OracleDaoConstants;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.domain.ISTCommand;
import com.fis.ist.services.vo.EditableListRowForSDK;


public class ISTCommandListRow extends EditableListRowForSDK implements Cloneable{
	private static final ISTLogger log = ISTLogger.getLogger(ISTCommandListRow.class);
	private String product; 
	private String nodeId;
	private String taskName;	//FIELD1
	private String taskType;	//FIELD2
	private String pId;			//FIELD0
	private String logDate;
	private String lastStart;	//FIELD5
	private String lastDie;		//FIELD6
	private String flags;		//FIELD3
	private String count;		//FIELD4
	private String output;
	private String field7;		//FIELD7
	private String field8;		//FIELD8
	private String field9;		//FIELD9


	public String getField9() {
		return field9;
	}

	public void setField9(String field9) {
		this.field9 = field9;
	}

	private ISTCommandListRow orignalRow;
	
	public void load(ISTCommand model)
	{
		setProduct(model.getProduct());
		setNodeId(model.getNodeId());
		setTaskName(model.getTaskName());
		setTaskType(model.getTaskType());
		setpId(model.getpId());
		setLogDate(model.getLogdate());
		setLastStart(model.getLastStart());
		setLastDie(model.getLastDie());
		//Below logic has been added for Cortex command mapping;
		//Cortex mappings done to different fields compared to IST commands in CS_MONCMDOUT table
		if(model.getIstCommand().equalsIgnoreCase(OracleDaoConstants.CORTEX_COMMAND_CAPCP)) {
			setFlagsDate(model.getFlags());
		} else {
			setFlags(model.getFlags());
		}
		setCount(model.getCount());
		setOutput(model.getOutput());
		setField7(model.getField7());
		setField8(model.getField8());
		setField9(model.getField9());
	}
	
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getpId() {
		return pId;
	}
	public void setpId(String pId) {
		this.pId = pId;
	}
	
	public String getLogDate() {
		return logDate;
	}

	public void setLogDate(String logDate) {
		this.logDate = PaymonUtils.getFormattedResponseDateTime(logDate);
	}

	public String getLastStart() {
		return lastStart;
	}

	public void setLastStart(String lastStart) {
		this.lastStart = PaymonUtils.getFormattedResponseDateTime(lastStart);
	}

	public String getLastDie() {
		return lastDie;
	}

	public void setLastDie(String lastDie) {
		this.lastDie = PaymonUtils.getFormattedResponseDateTime(lastDie);
	}
	
	public String getFlags() {
		return flags;
	}

	public void setFlags(String flags) {
		this.flags = flags;
	}
	
	public void setFlagsDate(String flags) {
		this.flags = PaymonUtils.getFormattedResponseDateTime(flags);
	}
	
	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}
	
	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}
	
	public String getField7() {
		return field7;
	}

	public void setField7(String field7) {
		this.field7 = field7;
	}

	public String getField8() {
		return field8;
	}

	public void setField8(String field8) {
		this.field8 = field8;
	}

	@Override
	public String getFormKey() {
		return "nodeId";
	}

	public void setOrignalRow(ISTCommandListRow orignalRow){
		try{
			if(orignalRow != null)
				this.orignalRow = (ISTCommandListRow) orignalRow.clone();
		}catch (Exception e){
			log.error(e);
		}
	}
}
