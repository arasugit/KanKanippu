package com.fis.ist.customProject;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.web.context.ConfigurableWebApplicationContext;

import com.fis.ist.log.ISTLogger;
import com.fis.ist.spring.CtxLdrListener;
public class CustomCtxLdrListener extends CtxLdrListener 
{
	private static final ISTLogger log = ISTLogger.getLogger(CustomCtxLdrListener.class);
	
	protected void customizeContext(ServletContext servletContext,
	ConfigurableWebApplicationContext applicationContext) {
		super.customizeContext(servletContext, applicationContext);
		boolean added = false;
		List<String> addList = new ArrayList<String>();
		String [] temp = applicationContext.getConfigLocations();
		for (String loc: temp) {
			addList.add(loc);
			if (loc.indexOf("applicationContext-Custom-Report.xml") > -1) {
				added = true;
				break;
			}
		}
		
		if (!added) {
			addList.add("/WEB-INF/applicationContext-Custom-Report.xml");
			applicationContext.setConfigLocations(addList.toArray(temp));
			if (log.isDebugEnabled())
			{
				log.debug("locations:");
				for (String s: addList){
					log.debug(s);
				}
				log.debug("locations end");
			}
		}
	}
}
