package com.fis.ist.customProject.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;

import com.efunds.t21.common.util.StringUtil;
import com.fis.ist.customProject.domain.IncidentAction;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.cfg.PaymonConfigParams;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.monitoring.common.SqlQueryProvider;
import com.fis.ist.monitoring.controller.ControllerSupportConstants;
import com.fis.ist.monitoring.dao.MonitorBaseDAO;
import com.fis.ist.monitoring.dto.IncidentCountByDaysDto;
import com.fis.ist.monitoring.dto.IncidentCountByHoursDto;
import com.fis.ist.monitoring.dto.IncidentCountByPriorityDto;
import com.fis.ist.monitoring.dto.IncidentCountByStatusDto;
import com.fis.ist.monitoring.dto.IncidentDashboardDto;
import com.fis.ist.monitoring.dto.Pair;

public class IncidentActionDAO  extends MonitorBaseDAO<IncidentAction, Integer>
 {
	private static final ISTLogger log = ISTLogger.getLogger(IncidentActionDAO.class);
	public static final String INCALRT_TOTL_BY_EG = "INCALRT_TOTL_BY_EG";
	public static final String INCALRT_FND_BY_EG = "INCALRT_FND_BY_EG";
	public static final String INCALRT_ACTN_DTE = "INCALRT_ACTN_DTE";
	public static final String INCALRT_ACTN_DTETOTL = "INCALRT_ACTN_DTETOTL";
	public static final String INCALRT_ACTN_CNFGDSC = "INCALRT_ACTN_CNFGDSC";

	@Override
	public Class<IncidentAction> getEntityClass() {
		return IncidentAction.class;
	}
	
	public Integer getTotalByExample(IncidentAction instance, Integer pageNum, String product, String nodeId, String incDateFrom,
			String incDateTo, String incDateToday, String incDateStartOfYear, String configDesc1, String cfgId, String incId) {
		log.debug("IncidentActionDAO - findByExample - Fetching for Incident Alert ");
		
		try {
			StringBuffer queryBuffer = new StringBuffer();
			
			Integer configId = instance.getCfgId() != null ? instance.getCfgId() : 0;
			Integer incidentId  = instance.getIncId() != null ? instance.getIncId() : 0;
			String status = instance.getStatus() != null ? instance.getStatus(): "";
			String smsStatus = instance.getSmsStatus() != null ? instance.getSmsStatus(): "";
			String emailStatus = instance.getEmailStatus() != null ? instance.getEmailStatus(): "";
			String configDesc = configDesc1 != null ? configDesc1 : "";
			
			if(configDesc != null || configDesc != "") {
				configDesc = configDesc.trim();
			}
			
			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCALRT_TOTL_BY_EG));
			
			if(configId > 0 || !cfgId.isEmpty()) {
				//queryBuffer.append(" and MONINCOUT.cfgid = " + configId + "" ); 
				String searchTerm = (String) cfgId;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCOUT.cfgId AS VARCHAR(20)) LIKE '"+ "%" + searchTermcfgId + "%'");
				} else if (searchTerm.startsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1));
					queryBuffer.append(" and CAST(MONINCOUT.cfgId AS VARCHAR(20)) LIKE '" + "%" + searchTermcfgId + "'");
				} else if (searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(0, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCOUT.cfgId AS VARCHAR(20)) LIKE '" + searchTermcfgId + "%'");
				} else {
					queryBuffer.append(" and MONINCOUT.cfgid = " + configId + "" );
				}
			}
			
			if(incidentId > 0 || !incId.isEmpty()) {
				//queryBuffer.append(" and MONINCOUT.incid = " + incidentId + "" ); 
				String searchTerm = (String) incId;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(1, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCOUT.incid AS VARCHAR(20)) LIKE '"+ "%" + searchTermincId + "%'");
				} else if (searchTerm.startsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(1));
					queryBuffer.append(" and CAST(MONINCOUT.incid AS VARCHAR(20)) LIKE '" + "%" + searchTermincId + "'");
				} else if (searchTerm.endsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(0, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCOUT.incid AS VARCHAR(20)) LIKE '" + searchTermincId + "%'");
				} else {
					queryBuffer.append(" and MONINCOUT.incid = " + incidentId + "" );
				}
			}
			
			if(!status.equals("")) {
				queryBuffer.append(" and TRIM(MONINCOUT.status) = '" + status + "'" ); 
			}
			
			if(!smsStatus.equals("")) {
				queryBuffer.append(" and TRIM(MONINCOUT.smsstatus) = '" + smsStatus + "'" ); 
			}
			
			if(!emailStatus.equals("")) {
				queryBuffer.append(" and TRIM(MONINCOUT.emailstatus) = '" + emailStatus + "'" ); 
			}
			
			if(!configDesc.equals("")) {
				queryBuffer.append(" and UPPER(MONINCCFG.description) like UPPER('%" + configDesc + "%')" ); 
			}
			
			if (incDateFrom == "" && incDateTo != "") {
				queryBuffer.append(" and "+ getTruncFunctionBasedOnDBType() + " between to_date( '" + incDateStartOfYear + "', 'dd-Mon-yy' ) and to_date( '" + incDateTo + "', 'dd-Mon-yy' )");
			} else if (incDateFrom != "" && incDateTo == "") {
				queryBuffer.append(" and "+ getTruncFunctionBasedOnDBType() + " between to_date( '" + incDateFrom + "', 'dd-Mon-yy' ) and to_date( '" + incDateToday + "', 'dd-Mon-yy' )");
			} else if (incDateFrom != "" && incDateTo != "") {
				queryBuffer.append(" and "+ getTruncFunctionBasedOnDBType() + " between to_date( '" + incDateFrom + "', 'dd-Mon-yy' ) and to_date( '" + incDateTo + "', 'dd-Mon-yy' )");
			}
			if(StringUtil.isNotEmpty(product) && (product.equalsIgnoreCase(ControllerSupportConstants.SWITCH_PRODUCT_ID) || product.equalsIgnoreCase(ControllerSupportConstants.CORTEX_PRODUCT_ID)))
				queryBuffer.append(" and TRIM(MONINCCFG.product) = '" + product + "' and MONINCCFG.nodeid IN (" + nodeId + ")");
			else 
				queryBuffer.append(" and TRIM(MONINCCFG.product) = '" + product + "' ");
						
			String queryString = queryBuffer.toString();
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);
				
			setPaging(queryObject, pageNum);	
			
			Integer recordCount = (Integer) queryObject.list().get(0);

			return recordCount.intValue();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
		
	}
	
	public List<IncidentAction> findByExample(IncidentAction instance, int pageNum, String product, String nodeId, 
			String incDateFrom, String incDateTo, String incDateToday, String incDateStartOfYear, String configDesc1, String cfgId, String incId) {
		log.debug("IncidentActionDAO - findByExample - Fetching for Incident Alert ");
		
		try {
			StringBuffer queryBuffer = new StringBuffer();
			
			Integer configId = instance.getCfgId() != null ? instance.getCfgId() : 0;
			Integer incidentId  = instance.getIncId() != null ? instance.getIncId() : 0;
			String status = instance.getStatus() != null ? instance.getStatus(): "";
			String smsStatus = instance.getSmsStatus() != null ? instance.getSmsStatus(): "";
			String emailStatus = instance.getEmailStatus() != null ? instance.getEmailStatus(): "";
			String configDesc = configDesc1 != null ? configDesc1 : "";
			
			if(configDesc != null || configDesc != "") {
				configDesc = configDesc.trim();
			}
						
			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCALRT_FND_BY_EG));
			
			if(configId > 0 || !cfgId.isEmpty()) {
				//queryBuffer.append(" and MONINCOUT.cfgid = " + configId + "" );
				String searchTerm = (String) cfgId;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCOUT.cfgId AS VARCHAR(20)) LIKE '"+ "%" + searchTermcfgId + "%'");
				} else if (searchTerm.startsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(1));
					queryBuffer.append(" and CAST(MONINCOUT.cfgId AS VARCHAR(20)) LIKE '" + "%" + searchTermcfgId + "'");
				} else if (searchTerm.endsWith("*")) {
					int searchTermcfgId = Integer.parseInt(searchTerm.substring(0, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCOUT.cfgId AS VARCHAR(20)) LIKE '" + searchTermcfgId + "%'");
				} else {
					queryBuffer.append(" and MONINCOUT.cfgid = " + configId + "" );
				}
			}
			
			if(incidentId > 0 || !incId.isEmpty()) {
				//queryBuffer.append(" and MONINCOUT.incid = " + incidentId + "" ); 
				String searchTerm = (String) incId;
				if (searchTerm.startsWith("*") && searchTerm.endsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(1, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCOUT.incid AS VARCHAR(20)) LIKE '"+ "%" + searchTermincId + "%'");
				} else if (searchTerm.startsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(1));
					queryBuffer.append(" and CAST(MONINCOUT.incid AS VARCHAR(20)) LIKE '" + "%" + searchTermincId + "'");
				} else if (searchTerm.endsWith("*")) {
					int searchTermincId = Integer.parseInt(searchTerm.substring(0, searchTerm.length() - 1));
					queryBuffer.append(" and CAST(MONINCOUT.incid AS VARCHAR(20)) LIKE '" + searchTermincId + "%'");
				} else {
					queryBuffer.append(" and MONINCOUT.incid = " + incidentId + "" );
				}
			}
			if(!status.equals("")) {
				queryBuffer.append(" and TRIM(MONINCOUT.status) = '" + status + "'" ); 
			}
			
			if(!smsStatus.equals("")) {
				queryBuffer.append(" and TRIM(MONINCOUT.smsstatus) = '" + smsStatus + "'" ); 
			}
			
			if(!emailStatus.equals("")) {
				queryBuffer.append(" and TRIM(MONINCOUT.emailstatus) = '" + emailStatus + "'" ); 
			}
			
			if(!configDesc.equals("")) {
				queryBuffer.append(" and UPPER(MONINCCFG.description) like UPPER('%" + configDesc + "%')" ); 
			}
			
			if (incDateFrom == "" && incDateTo != "") {
				queryBuffer.append(" and " + getTruncFunctionBasedOnDBType() + " between to_date( '" + incDateStartOfYear + "', 'dd-Mon-yy' ) and to_date( '" + incDateTo + "', 'dd-Mon-yy' )");
			} else if (incDateFrom != "" && incDateTo == "") {
				queryBuffer.append(" and " + getTruncFunctionBasedOnDBType() + " between to_date( '" + incDateFrom + "', 'dd-Mon-yy' ) and to_date( '" + incDateToday + "', 'dd-Mon-yy' )");
			} else if (incDateFrom != "" && incDateTo != "") {
				queryBuffer.append(" and " + getTruncFunctionBasedOnDBType() + " between to_date( '" + incDateFrom + "', 'dd-Mon-yy' ) and to_date( '" + incDateTo + "', 'dd-Mon-yy' )");
			}
			//queryBuffer.append(" and MONINCCFG.product = '" + product + "' and MONINCCFG.nodeid IN (" + nodeId + ") order by MONINCOUT.incid desc");
			if(StringUtil.isNotEmpty(product) && (product.equalsIgnoreCase(ControllerSupportConstants.SWITCH_PRODUCT_ID) || product.equalsIgnoreCase(ControllerSupportConstants.CORTEX_PRODUCT_ID)))
				queryBuffer.append(" and TRIM(MONINCCFG.product) = '" + product + "' and MONINCCFG.nodeid IN (" + nodeId + ")");
			else 
				queryBuffer.append(" and TRIM(MONINCCFG.product) = '" + product + "' ");		
			
			String queryString = queryBuffer.toString();
			log.debug("Query[" + queryString + "]");
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("cfgid", StandardBasicTypes.INTEGER)
					.addScalar("incid", StandardBasicTypes.INTEGER)
					.addScalar("opendate", StandardBasicTypes.DATE)
					.addScalar("status", StandardBasicTypes.STRING)
					.addScalar("smsstatus", StandardBasicTypes.STRING)
					.addScalar("emailstatus", StandardBasicTypes.STRING)
					.addScalar("closedate", StandardBasicTypes.DATE )
					.addScalar("esctype", StandardBasicTypes.STRING )
					.addScalar("age", StandardBasicTypes.INTEGER )
					.addScalar("resolution", StandardBasicTypes.STRING )
					.addScalar("clearedby", StandardBasicTypes.STRING )
					.addScalar("description", StandardBasicTypes.STRING);
				
			setPaging(queryObject, pageNum);			

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
		
	}

	public List<IncidentAction> findByExample1(IncidentAction instance, int pageNum) {
		log.debug("finding Incident instance by example");
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(IncidentAction.class);
			Map<String, Object> condition = new HashMap<String, Object>();
			
			String value = null;
			Object data = null;
			

			data = instance.getCfgId();
			if(data != null){
				condition.put("cfgId", data);
			}
			
			data = instance.getIncId();
			if(data != null){
				condition.put("incId", data);
			}
			
			data = instance.getIncDate();
			if(data != null){
				condition.put("incDate", data);
			}
			
			data = instance.getStatus();
			if(data != null){
				condition.put("status", data);
			}
			
			data = instance.getSmsStatus();
			if(data != null){
				condition.put("smsStatus", data);
			}
			
			data = instance.getEmailStatus();
			if(data != null){
				condition.put("emailStatus", data);
			}
			
			
			c = c.add(Restrictions.allEq(condition));
			c.addOrder(Order.desc("incId"));
			setPaging(c, pageNum);
			List<IncidentAction> results = c.list();
			
			
            log.debug("findByExample successful, result size: " + results.size());
            return results;
        } catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
	
	public void save(IncidentAction transientInstance) 
	{
		getSession().save(transientInstance);
	}
	
	public IncidentAction findById(Integer id) 
	{
		IncidentAction instance = (IncidentAction) getSession().get(getEntityClass(), id);
		return instance;
	}
	
	
	
	public List getIncidentActionFromIncDate(String cfgId, String incId,  String incDateFrom,  String incDateTo, String incDateToday, String incDateStartOfYear,String status, String smsstatus,
			String emailstatus,  int pageNum, String product, String nodeid) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
					 
			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCALRT_ACTN_DTE));
				
			String queryString = queryBuffer.toString();
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("cfgid", StandardBasicTypes.INTEGER)
					.addScalar("incid", StandardBasicTypes.INTEGER)
					.addScalar("incdate", StandardBasicTypes.DATE)
					.addScalar("status", StandardBasicTypes.STRING)
					.addScalar("smsstatus", StandardBasicTypes.STRING)
					.addScalar("emailstatus", StandardBasicTypes.STRING)
					.addScalar("description", StandardBasicTypes.STRING);

			if (incDateFrom == "" && incDateTo != "") {
			queryObject.setParameter("incdateFrom", incDateStartOfYear);
			queryObject.setParameter("incdateTo", incDateTo);
			} else if (incDateFrom != "" && incDateTo == "") {
				queryObject.setParameter("incdateFrom", incDateFrom);
				queryObject.setParameter("incdateTo", incDateToday);
			} else if (incDateFrom != "" && incDateTo != "") {
				queryObject.setParameter("incdateFrom", incDateFrom);
				queryObject.setParameter("incdateTo", incDateTo);				
			}
			
			queryObject.setParameter("product", product);	
			queryObject.setParameter("nodeid", nodeid);	
			
			log.debug("query in IncidentActionDAO - getIncidentActionFromIncDate : " + queryBuffer.toString());
		
			setPaging(queryObject, pageNum);			

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}
	
	public int getIncidentActionFromIncDateTotal(String cfgId, String incId, String incDateFrom,  String incDateTo, String incDateToday, String incDateStartOfYear, String status,
			String smsStatus, String emailStatus, Integer pageNum, String product, String nodeid) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			
			/*queryBuffer.append("select count(*) as count "
					+ "from cs_monincout MONINCOUT INNER JOIN CS_MONINCCFG MONINCCFG ON MONINCCFG.cfgid = MONINCOUT.cfgid "
					+ " and MONINCCFG.product = :product and MONINCCFG.nodeid IN (:nodeid) "
					+ "and trunc(incdate) between to_date( :incdateFrom, 'dd-Mon-yy' ) and to_date( :incdateTo, 'dd-Mon-yy' )"
					+ "order by MONINCOUT.incid");*/
			
			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCALRT_ACTN_DTETOTL));
			
			
			String queryString = queryBuffer.toString();
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("count", StandardBasicTypes.INTEGER);


			if (incDateFrom == "" && incDateTo != "") {
			queryObject.setParameter("incdateFrom", incDateStartOfYear);
			queryObject.setParameter("incdateTo", incDateTo);
			} else if (incDateFrom != "" && incDateTo == "") {
				queryObject.setParameter("incdateFrom", incDateFrom);
				queryObject.setParameter("incdateTo", incDateToday);
			} else if (incDateFrom != "" && incDateTo != "") {
				queryObject.setParameter("incdateFrom", incDateFrom);
				queryObject.setParameter("incdateTo", incDateTo);				
			}
			
			queryObject.setParameter("product", product);	
			queryObject.setParameter("nodeid", nodeid);	
		
			setPaging(queryObject, pageNum);	
			
			Integer recordCount = (Integer) queryObject.list().get(0);

			return recordCount.intValue();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}



	
	public Integer getTotalByExample1(IncidentAction instance) {
		log.debug("getTotalByExample IncidentAction");
		Integer count = null;
		try {
			Session session = getSession();
			Criteria c = session.createCriteria(IncidentAction.class);
			c.setProjection(Projections.rowCount());

			Map<String, Object> condition = new HashMap<String, Object>();
			
			String value = null;
			Object data = null;
			
			data = instance.getCfgId();
			if(data != null){
				condition.put("cfgId", data);
			}

			data = instance.getIncId();
			if(data != null){
				condition.put("incId", data);
			}
			
			
			data = instance.getIncDate();
			if(data != null){
				condition.put("incDate", data);
			}
			
			data = instance.getStatus();
			if(data != null){
				condition.put("status", data);
			}
			
			data = instance.getSmsStatus();
			if(data != null){
				condition.put("smsStatus", data);
			}
			
			data = instance.getEmailStatus();
			if(data != null){
				condition.put("emailStatus", data);
			}
			
			
			Long sLong = (Long) (c.add(Restrictions.allEq(condition))).uniqueResult();
			c.addOrder(Order.desc("incId"));
			if (sLong != null)
				count = sLong.intValue();
			else
				count = 0;

		} catch (RuntimeException re) {
			log.error("getTotalByExample IncidentAction failed", re);
			throw re;
		}
        return count;
	}

	public List getCfgIdFromConfigTable(Map params) {
		List monInConfigList = null;
		String configDesc = params.get("configDesc") != null ? (String) params.get("configDesc") : "";
		String product = params.get("product") != null ? (String) params.get("product") : "";
		String nodeId = params.get("nodeId") != null ? (String) params.get("nodeId") : "*";
		String configId = "";
		try {
			Query queryObject = getSession().createSQLQuery("select cfgid, description from CS_MONINCCFG where description like '%" + configDesc + "%' "
					+ " and product = '" + product + "' and nodeid IN ("+ nodeId +")")
		    		.addScalar("cfgid", StandardBasicTypes.STRING)
		    		.addScalar("description", StandardBasicTypes.STRING);
			
			System.out.println("queryObject " + queryObject.toString());
		    
		    monInConfigList = queryObject.list();

		    return monInConfigList;
		} catch (RuntimeException re) {
			log.error("Error While finding running atms", re);
			throw re;
		}				
	}
	
	public List getIncidentActionWithConfigDesc(List cfgIdFromConfigList, Integer pageNum) {
		try {
			StringBuffer queryBuffer = new StringBuffer();
			
			queryBuffer.append(SqlQueryProvider.getDBSqlQuery(INCALRT_ACTN_CNFGDSC));
			
			String queryString = queryBuffer.toString();
			Query queryObject = null;

			queryObject = getSession().createSQLQuery(queryString).addScalar("cfgid", StandardBasicTypes.INTEGER)
					.addScalar("incid", StandardBasicTypes.INTEGER)
					.addScalar("incdate", StandardBasicTypes.DATE)
					.addScalar("status", StandardBasicTypes.STRING)
					.addScalar("smsstatus", StandardBasicTypes.STRING)
					.addScalar("emailstatus", StandardBasicTypes.STRING);
			
			queryObject.setParameter("cfgIdFromConfigList", cfgIdFromConfigList);
		
			setPaging(queryObject, pageNum);			

			return queryObject.list();

		} catch (RuntimeException re) {
			log.error("Query Fails", re);
			throw re;
		}
	}
	
	private String getTruncFunctionBasedOnDBType() {
		
		if ("PostgreSQL".equalsIgnoreCase(PaymonUtils.getDatabseName())) {
			return "date_trunc('day', open_date)";
		} 
		
		return "trunc(open_date) ";
	}
	

	public List<IncidentCountByPriorityDto> getIncidentCountGroupedByPriority(String fromDate, String toDate, String product, String nodeId) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("INC_CNT_BY_PRIRTY");
			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("priority", StandardBasicTypes.STRING)
					.addScalar("count", StandardBasicTypes.INTEGER);
			
			queryObject.setParameter("openFromDate", fromDate);
			queryObject.setParameter("openToDate", toDate);
			queryObject.setParameter("productId", product);
			String[] nodeIds = nodeId.contains(",") ? nodeId.split(",") : new String[]{nodeId};
			queryObject.setParameterList("nodeId", nodeIds);
			
			log.debug("Query[" + queryString + "]");
			
			return (List<IncidentCountByPriorityDto>)queryObject.setResultTransformer(Transformers.aliasToBean(IncidentCountByPriorityDto.class)).list();

		} catch (RuntimeException re) {
			log.error("getIncidentCountGroupedByPriority - Query Fails", re);
			throw re;
		}
	}
	
	public List<IncidentCountByStatusDto> getIncidentCountGroupedByStatus(String fromDate, String toDate, String product, String nodeId) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("INC_CNT_BY_STATUS");
			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("status", StandardBasicTypes.STRING)
					.addScalar("count", StandardBasicTypes.INTEGER);
			
			queryObject.setParameter("openFromDate", fromDate);
			queryObject.setParameter("openToDate", toDate);
			queryObject.setParameter("productId", product);
			String[] nodeIds = nodeId.contains(",") ? nodeId.split(",") : new String[]{nodeId};
			queryObject.setParameterList("nodeId", nodeIds);
						
			log.debug("Query[" + queryString + "]");
			
			return (List<IncidentCountByStatusDto>)queryObject.setResultTransformer(Transformers.aliasToBean(IncidentCountByStatusDto.class)).list();

		} catch (RuntimeException re) {
			log.error("getIncidentCountGroupedByStatus - Query Fails", re);
			throw re;
		}
	}
	
	public List<IncidentCountByHoursDto> getIncidentCountGroupedByHours(String fromDate, String product, String nodeId) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("INC_CNT_BY_HRS");
			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("hours", StandardBasicTypes.STRING)
					.addScalar("openCount", StandardBasicTypes.INTEGER);
			
			queryObject.setParameter("productId", product);
			String[] nodeIds = nodeId.contains(",") ? nodeId.split(",") : new String[]{nodeId};
			queryObject.setParameterList("nodeId", nodeIds);
			queryObject.setParameter("fromDate", fromDate);
			
			log.debug("Query[" + queryString + "]");
			
			return (List<IncidentCountByHoursDto>)queryObject.setResultTransformer(Transformers.aliasToBean(IncidentCountByHoursDto.class)).list();

		} catch (RuntimeException re) {
			log.error("getIncidentCountGroupedByHours - Query Fails", re);
			throw re;
		}
	}
	
	public List<IncidentCountByDaysDto> getIncidentCountGroupedByDays(String fromDate, String toDate, String product, String nodeId) {
		try {
			String queryString = SqlQueryProvider.getDBSqlQuery("INC_CNT_BY_DAYS");
			Query queryObject = getSession().createSQLQuery(queryString)
					.addScalar("openDate", StandardBasicTypes.DATE)
					.addScalar("openCount", StandardBasicTypes.INTEGER)
					.addScalar("closedCount", StandardBasicTypes.INTEGER)
					.addScalar("inprogressCount", StandardBasicTypes.INTEGER);

			queryObject.setParameter("fromDate", fromDate);
			queryObject.setParameter("toDate", toDate);
			queryObject.setParameter("productId", product);
			String[] nodeIds = nodeId.contains(",") ? nodeId.split(",") : new String[]{nodeId};
			queryObject.setParameterList("nodeId", nodeIds);
			
			log.debug("Query[" + queryString + "]");
			
			return (List<IncidentCountByDaysDto>)queryObject.setResultTransformer(Transformers.aliasToBean(IncidentCountByDaysDto.class)).list();

		} catch (RuntimeException re) {
			log.error("getIncidentCountGroupedByDays - Query Fails", re);
			throw re;
		}
	}
	
}
