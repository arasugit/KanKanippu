package com.fis.ist.customProject.dto;

import java.util.Date;
import java.util.List;

import com.fis.ist.customProject.domain.IncidentAction;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.monitoring.common.PaymonUtils;
import com.fis.ist.services.vo.EditableListRowForSDK;

public class IncidentActionRow  extends EditableListRowForSDK implements Cloneable{
	private static final ISTLogger log = ISTLogger.getLogger(IncidentActionRow.class);
	private String incDateAsString;
	private Date incDateAsDate;
	
	private IncidentActionRow orignalRow;	
	
	private Integer cfgId;
	private Integer incId;
	private String incDate;   // openDate
	private String status;
	private String smsStatus;
	private String emailStatus;
	private String closeDate;
	private String escType;
	private Integer age;
	private String resolution;
	private String clearedBy;
	private String description;	

	public void load(IncidentAction incidentAction)
	{
		setCfgId(incidentAction.getCfgId());
		setIncId(incidentAction.getIncId());
  	 	setIncDate(incidentAction.getIncDate());
		setStatus(incidentAction.getStatus());
		setSmsStatus(incidentAction.getSmsStatus());
		setEmailStatus(incidentAction.getEmailStatus());
	}

	public void store(IncidentAction model){
		model.setCfgId(cfgId);
		model.setIncId(incId);
		model.setStatus(status);
		model.setSmsStatus(smsStatus);
		model.setEmailStatus(emailStatus);
	}	

	public IncidentActionRow getOrignalRow() {
		return orignalRow;
	}

	public void setOrignalRow(IncidentActionRow orignalRow){
		try{
			if(orignalRow != null)
				this.orignalRow = (IncidentActionRow) orignalRow.clone();
		}catch (Exception e){
			log.error(e);
		}
	}	

	@Override
	public String getFormKey() {
		return "cfgId";
	}	
	
	public Integer getCfgId() {
		return this.cfgId;
	}

	public void setCfgId(Integer cfgId) {
		this.cfgId = cfgId;
	}
	
	public Integer getIncId() {
		return this.incId;
	}

	public void setIncId(Integer incId) {
		this.incId = incId;
	}
	
	public String getIncDate() {
		return this.incDate;
	}

	public void setIncDate(Object incDate) {
		this.incDate = PaymonUtils.getFormattedResponseDate(incDate);
	}	
	
	public String getStatus() {
		return this.status.trim();
	}

	public void setStatus(String status) {
		this.status = status.trim();
	}
	
	
	public String getSmsStatus() {
		return this.smsStatus;
	}

	public void setSmsStatus(String smsStatus) {
		this.smsStatus = smsStatus;
	}	

	public String getEmailStatus() {
		return this.emailStatus;
	}

	public void setEmailStatus(String emailStatus) {
		this.emailStatus = emailStatus;
	}		
	
	public String getIncDateAsString() {
		return incDateAsString;
	}

	public void setIncDateAsString(String incDateAsString) {
		this.incDateAsString = incDateAsString;
	}


	public String getCloseDate() {
		return closeDate;
	}

	public void setCloseDate(Object closeDate) {
		this.closeDate = PaymonUtils.getFormattedResponseDate(closeDate);
	}

	public String getEscType() {
		return escType;
	}

	public void setEscType(String escType) {
		this.escType = escType;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}


	public String getClearedBy() {
		return clearedBy;
	}

	public void setClearedBy(String clearedBy) {
		this.clearedBy = clearedBy;
	}

	public Date getIncDateAsDate() {
		return incDateAsDate;
	}

	public void loadDateResult(Object[] model, List<IncidentActionRow> tempConfigIncActRowList) {
		setCfgId((Integer) model[0]);
		setIncId((Integer) model[1]);
  	 	setIncDate(model[2]);
		setStatus((String) model[3]);
		
		String tempSmsStatus =  model[4] == null ? "" : (String) model[4];
		
		if("success".equalsIgnoreCase(tempSmsStatus.trim())) {
			setSmsStatus("Success");
		} else if("failed".equalsIgnoreCase(tempSmsStatus.trim())) {
			setSmsStatus("Failed");
		} 
	
		String tempEmailStatus = model[5] == null ? "" : (String) model[5];
		
		if("success".equalsIgnoreCase(tempEmailStatus.trim())) {
			setEmailStatus("Success");
		} else if("failed".equalsIgnoreCase(tempEmailStatus.trim())) {
			setEmailStatus("Failed");
		} 
		
		setCloseDate(model[6]);
		setEscType((String) model[7]);
		setAge((Integer) model[8]);
		setResolution((String) model[9]);
		setClearedBy((String) model[10]);
		
		if(tempConfigIncActRowList.size() != 0) {
			bindDescription((Integer) model[0], tempConfigIncActRowList);	
		} else {
			setDescription((String) model[11]);
		}
			
	}
	
	public void bindDescription(Integer cfgId, List tempConfigIncActRowList) {
		Integer configId = cfgId;
		if(tempConfigIncActRowList.size() > 0) {
			for(int count=0; count <= tempConfigIncActRowList.size(); count++ ) {
				IncidentActionRow tempConfigIncActRow = new IncidentActionRow();
				tempConfigIncActRow = (IncidentActionRow) tempConfigIncActRowList.get(count);
				if(tempConfigIncActRow.getCfgId().intValue() == configId.intValue()) {
					setDescription(tempConfigIncActRow.getDescription());
					break;
				}
			}

		}
	}

	public void setIncDateAsDate(Date incD ) {
		this.incDateAsDate = incD;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}	
	
	public void loadInfoFromConfig(Object[] tempMonInConfigList) {
		setCfgId(Integer.parseInt((String) tempMonInConfigList[0]));
		setDescription((String) tempMonInConfigList[1]);
	}	
}