package com.fis.ist.customProject.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CS_MONINCPROGRESS" )
public class IncidentAlert implements java.io.Serializable {

	private Integer cfgId;
	private Integer incId;
	private Date upddate;    // LAST_UPDATE_DATE
	private String comments;

	public IncidentAlert() {
	}

	public IncidentAlert(Integer incId) {
		this.incId = incId;
	}

	public IncidentAlert(Integer cfgId, Integer incId, Date upddate, String comments) {
		super();
		this.cfgId = cfgId;
		this.incId = incId;
		this.upddate = upddate;
		this.comments = comments;
	}

	@Column(name = "CFGID",unique = true, nullable = false, precision = 6, scale = 0)
	public Integer getCfgId() {
		return this.cfgId;
	}

	public void setCfgId(Integer cfgId) {
		this.cfgId = cfgId;
	}
	
	@Id
	@Column(name = "INCID",unique = true, nullable = false, precision = 6, scale = 0)
	public Integer getIncId() {
		return this.incId;
	}

	public void setIncId(Integer incId) {
		this.incId = incId;
	}	
	
	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_UPDATE_DATE", nullable = false, length = 7)
	public Date getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Date upddate) {
		this.upddate = upddate;
	}

	@Column(name = "COMMENTS", length = 20)
	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
}
