package com.fis.ist.customProject.services;

import java.util.Map;

import com.efunds.t21.services.cache.WorkRequestCacher;
import com.efunds.t21.services.vo.UserContext;
import com.fis.ist.audit.handler.FormAuditHandler;
import com.fis.ist.common.AppConstants;
import com.fis.ist.common.CustomConstants;
import com.fis.ist.customProject.services.handler.EmployeeDetailHandler;
import com.fis.ist.log.ISTLogger;
import com.fis.ist.services.SubService;
import com.fis.ist.services.vo.WorkRequest;

public class EmployeeDetail implements SubService {
	private static final ISTLogger log = ISTLogger.getLogger(EmployeeDetail.class);

	public WorkRequest getService(UserContext userContext, String requestType,
			String action, Map<String, String> requestParams) throws Exception {
		WorkRequest workReq = null;
		EmployeeDetailHandler ddh = new EmployeeDetailHandler();
		if (CustomConstants.ACTION_INSERT.equals(action))
			workReq = ddh.getDataForAdd(userContext, requestParams, action);
		else if ((action.compareTo(CustomConstants.ACTION_QUERY_DETAIL) == 0)
				|| (action.compareTo(CustomConstants.ACTION_UPDATE) == 0) 	|| (action.compareTo(AppConstants.MKC_ACTION_REWORK_EDIT) == 0)	) {
			workReq = ddh.getDataForUpdate(userContext, requestParams, action);
		} else if ((action.compareTo(AppConstants.MKC_ACTION_REQUEST) == 0)) {
			workReq = ddh.getMKCRequest(userContext, requestParams, action);
		} else {
			log.error("**** SampleDetail: getService() inbound...unknown action: "
					+ action);
			throw new Exception("Unknown action error");
		}
		WorkRequestCacher.getInstance().put(userContext, workReq);
		return workReq;
	}

	public WorkRequest setService(UserContext userContext, String requestType,
			String action, WorkRequest workRequest) throws Exception {
		EmployeeDetailHandler ddh = new EmployeeDetailHandler();
		if (CustomConstants.ACTION_INSERT.equals(action))
			workRequest = ddh.insertRecord(userContext, workRequest);
		else if (CustomConstants.ACTION_UPDATE.equals(action))
			workRequest = ddh.updateRecord(userContext, workRequest);
		else if (CustomConstants.ACTION_DELETE.equals(action)) 
			workRequest = ddh.deleteRecord(userContext, workRequest);
		else if (AppConstants.MKC_ACTION_APPROVE.equals(action)) 
			workRequest = ddh.ApproveByChecker(userContext, workRequest);
		else if (AppConstants.MKC_ACTION_REJECT.equals(action)) 
			workRequest = ddh.RejectByChecker(userContext, workRequest);
		else if (AppConstants.MKC_ACTION_REWORK.equals(action)) 
			workRequest = ddh.ReturnReworkByChecker(userContext, workRequest);
		else if (AppConstants.MKC_ACTION_REWORK_EDIT.equals(action)) 
			workRequest = ddh.mkcReworkEdit(userContext, workRequest);
		else {
			log.error("**** SampleDetail: setService() inbound...unknown action: "
					+ action);
			throw new Exception("Unknown action error");
		}
		new FormAuditHandler().saveFormAudit(userContext, "EMPDETAIL", action,
				workRequest, CustomConstants.SWITCH_SUBSYSTEM);
		return workRequest;
	}
}
