package com.oasis.tokenizer;


import com.fis.ist.cfg.ConfigParams;
import com.fis.ist.log.ISTLogger;
import com.oasis.tokenizer.ActiveTokenizer;
import com.oasis.tokenizer.EchoTokenizer;
import com.oasis.tokenizer.ErrorTokenizer;
import com.oasis.tokenizer.TokenizerInterface;

public class CustomTokenizerFactory {
	static final ISTLogger log = ISTLogger.getLogger(CustomTokenizerFactory.class);
	static int mode;

	static {
		log.debug("Static block initialization - begin");
		try {
			String flag = ConfigParams.getInstance().getProperty("ist.tokenizer.mode");
			if ("active".equalsIgnoreCase(flag)) {
				ActiveTokenizer.init();
				mode = TokenizerInterface.MODE_ACTIVE;
			} else if ("echo".equalsIgnoreCase(flag)) {
				mode = TokenizerInterface.MODE_ECHO;
			} else {
				mode = TokenizerInterface.MODE_ERROR;
			}
			log.debug("Static block initialization - end");
		} catch (Exception e) {
			log.error(e, e);
		}
	}

	public TokenizerInterface make(String subsystem) {
		return make();
	}

	public TokenizerInterface make() {
		switch (mode) {
		case TokenizerInterface.MODE_ACTIVE:
			return new ActiveTokenizer();
		case TokenizerInterface.MODE_ECHO:
			return new EchoTokenizer();
		}
		return new ErrorTokenizer();
	}
}
