import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

export const transTrendroutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Trend',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNTREND',
        pathMatch: 'full',
      },
      {
        path: 'TXNTREND',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNTREND' } 
      }
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transTrendroutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransactionTrendRoutingModule { 

  constructor(){
    console.log(' Transaction Trend Routing Module ');
  }
}
