import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',   
    loadChildren: () =>import('./tranlog-landing/tranlog-landing.module').then((m) => m.TranlogLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class ReportsToolBarLandingRoutingModule {
  constructor(){ }
 }
