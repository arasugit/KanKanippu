// Connection Monitoring landing module

import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,PlatformMonitoringModule } from '@ist-custom-project/shell';
import { PlatformMonRoutingModule } from './platform-mon-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    PlatformMonRoutingModule,
    PlatformMonitoringModule

  ],
  declarations: []
})
export class PlatformMonLandingModule {
   constructor(){
     console.log("Inside platform-monitoring-landing-module page");
   }
}
