import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

const cortexDashboardRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Cortex Dashboard'
    },
    children: [
      {
        path: '',
        redirectTo: 'CTXDASH',
        pathMatch: 'full',
      },
      {
        path: 'CTXDASH',
        redirectTo: 'CTXDASH',
        pathMatch: 'full',
      },
      {
        path: 'CTXDASH',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'pos_dash' }
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(cortexDashboardRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class CortexDashboardRoutingModule {
  constructor(){
    console.log('Inside CortexDashboardRoutingModule');
  }
}
