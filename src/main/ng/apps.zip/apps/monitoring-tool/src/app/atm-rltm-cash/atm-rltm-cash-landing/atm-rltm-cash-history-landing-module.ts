import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, AtmRltmCashHistoryModule } from '@ist-custom-project/shell';
import { AtmRltmCashHistoryRoutingModule } from './atm-rltm-cash-history-routing-module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    AtmRltmCashHistoryRoutingModule,
    AtmRltmCashHistoryModule
  ],
  declarations: []
})

export class AtmRltmCashHistoryLandingModule {
   constructor(){
     console.log("Inside AtmRltmCashHistoryLandingModule page");
   }
}
