import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdSumLandingRoutingModule } from './cdSum-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    CdSumLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class CdSumLandingModule {}
