import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const istCmdRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'Task',
      title: 'Task Commands',
    },
    children: [
      {
        path: '',
        redirectTo: 'TSKCMD',
        pathMatch: 'full',
      },
      {
        path: 'TSKCMD',
        redirectTo: 'TSKCMD',
        pathMatch: 'full',
      },
      {
        path: 'BINDTLS',
        redirectTo: 'BINDTLS',
        pathMatch: 'full',
      },
      {
        path: 'MEMDTLS',
        redirectTo: 'MEMDTLS',
        pathMatch: 'full',
      },
      {
        path: 'TRCDTLS',
        redirectTo: 'TRCDTLS',
        pathMatch: 'full',
      },
      {
        path: 'RSRCUSG',
        redirectTo: 'RSRCUSG',
        pathMatch: 'full',
      },
      {
        path: 'EVNTDTLS',
        redirectTo: 'EVNTDTLS',
        pathMatch: 'full',
      },
      {
        path: 'MBCDOPTS',
        redirectTo: 'MBCDOPTS',
        pathMatch: 'full',
      },
      {
        path: 'MBLOOKTS',
        redirectTo: 'MBLOOKTS',
        pathMatch: 'full',
      },
      {
        path: 'MBCDUPTME',
        redirectTo: 'MBCDUPTME',
        pathMatch: 'full',
      },
      {
        path: 'SAFTXNDATA',
        redirectTo: 'SAFTXNDATA',
        pathMatch: 'full',
      },
      {
        path: 'PROCDTLS',
        redirectTo: 'PROCDTLS',
        pathMatch: 'full',
      },
      {
        path: 'QUEUEDTLS',
        redirectTo: 'QUEUEDTLS',
        pathMatch: 'full',
      },
      {
        path: 'DEBUGM_REQ',
        redirectTo: 'DEBUGM_REQ',
        pathMatch: 'full',
      },
      {
        path: 'CA_PSR',
        redirectTo: 'CA_PSR',
        pathMatch: 'full',
      },
      {
        path: 'CA_PCP',
        redirectTo: 'CA_PCP',
        pathMatch: 'full',
      },
      {
        path: 'CA_PSC',
        redirectTo: 'CA_PSC',
        pathMatch: 'full',
      },
      {
        path: 'CA_PQ',
        redirectTo: 'CA_PQ',
        pathMatch: 'full',
      },
      {
        path: 'TSKCMD',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'BINDTLS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'MEMDTLS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'TRCDTLS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'RSRCUSG',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'EVNTDTLS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'MBCDOPTS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'MBLOOKTS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'MBCDUPTME',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'SAFTXNDATA',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'PROCDTLS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'QUEUEDTLS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'DEBUGM_REQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'CA_PSR',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'CA_PCP',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'CA_PSC',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'CA_PQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      }
    ]
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(istCmdRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class ISTCmdRoutingModule {

  constructor(){
    console.log('Inside istcmd-routing.module ');
  }
}
