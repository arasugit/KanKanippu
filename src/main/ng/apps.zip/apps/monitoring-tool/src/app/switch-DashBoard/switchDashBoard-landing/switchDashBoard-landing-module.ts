import { NgModule } from '@angular/core';
import { MonitorNavigationModule,SwitchDashBoardModule } from '@ist-custom-project/shell';
import { SwitchDashBoardRoutingModule } from './switchDashBoard-routing.module';

@NgModule({
    imports :[
    MonitorNavigationModule,
    SwitchDashBoardRoutingModule,
    SwitchDashBoardModule
  ],
  declarations: []
})

export class SwitchDashBoardLandingModule {
   constructor(){
     console.log("Inside SwitchDashBoardLandingModule page");
   }
}
