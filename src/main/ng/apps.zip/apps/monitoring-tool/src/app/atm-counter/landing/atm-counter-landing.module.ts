import { FlexLayoutModule } from '@angular/flex-layout';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ATMCounterLandingRoutingModule } from './atm-counter-landing-routing.module';
import { MonitorNavigationModule} from '@ist-custom-project/shell';
import { AtmCounterModule } from '@ist-custom-project/shell';


@NgModule({
  declarations: [ ],
  imports: [
    CommonModule,
    FlexLayoutModule,
    ATMCounterLandingRoutingModule,
    MonitorNavigationModule,
    AtmCounterModule
  ], 
})
export class ATMCounterLandingModule {
   constructor(){}    
}

