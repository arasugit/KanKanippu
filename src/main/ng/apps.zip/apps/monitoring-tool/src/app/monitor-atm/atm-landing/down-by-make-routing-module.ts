import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, DownByMakeComponent} from '@ist-custom-project/shell';

export const downByMakeRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'ATM Down By Make',
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMDWM_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMDWM_REQ',
        component:DownByMakeComponent,
        data: { module: 'ATMDWM_REQ' } 
      }
    ]   
  },
];


@NgModule({
  imports: [
    RouterModule.forChild(downByMakeRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class DownByMakeRoutingModule { 

  constructor(){
    console.log('ATM down by make Routing Module');
  }
}
