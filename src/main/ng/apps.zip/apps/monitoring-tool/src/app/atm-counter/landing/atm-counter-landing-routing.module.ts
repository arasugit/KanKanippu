import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonLandingComponent,MonitorDynamicComponentDisplayComponent} from '@ist-custom-project/shell';


const atmTotalsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'ATM Counter'
    },
    children: [
      {
        path: '',
        redirectTo: 'MONATMCOUN_REQ',
        pathMatch: 'full',
      },
      {
        path: 'MONATMCOUN_REQ',
        redirectTo: 'MONATMCOUN_REQ',
        pathMatch: 'full',
      },
      {
        path: 'MONATMCOUN_REQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'atm_counter' } 
      }     
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(atmTotalsRoutes)],
  exports: [RouterModule]
})
export class ATMCounterLandingRoutingModule { }
