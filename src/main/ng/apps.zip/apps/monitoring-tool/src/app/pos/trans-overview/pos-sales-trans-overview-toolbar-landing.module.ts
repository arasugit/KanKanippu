import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { PosTransOverviewToolbarLandingRoutingModule } from './pos-sales-trans-overview-toolbar-landing-routing.module';

/**
 * NgModule that includes all Material modules that are required to serve the demo-app.
 */
@NgModule({
  imports: [
    CommonModule,
    PosTransOverviewToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})

export class PosTransOverviewToolBarLandingModule {}
