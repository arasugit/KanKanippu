import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./transaction-dashboard-landing/transaction-dashboard-landing-module').then((m) => m.TransactionDashboardLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})

export class TransactionDashboardToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside TransactionDashboardToolbarLandingRoutingModule page... ');
   }
 }
