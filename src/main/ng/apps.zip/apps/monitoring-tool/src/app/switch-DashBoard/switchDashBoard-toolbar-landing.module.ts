import { NgModule } from '@angular/core';
import { SwitchDashBoardToolbarLandingRoutingModule } from './switchDashBoard-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    SwitchDashBoardToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class SwitchDashBoardToolBarLandingModule {}
