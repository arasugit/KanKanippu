import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, DownBySiteModule} from '@ist-custom-project/shell';
import { DownBySiteRoutingModule } from './down-by-site-routing-module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    DownBySiteRoutingModule,
    DownBySiteModule

  ],
  declarations: []
})
export class DownBySiteLandingModule {
   constructor(){}
}
