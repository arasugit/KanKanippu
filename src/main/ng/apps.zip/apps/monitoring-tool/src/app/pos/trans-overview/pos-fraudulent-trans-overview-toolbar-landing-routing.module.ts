import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./landing/pos-fraudulent-trans-overview-landing-module').then((m) => m.PosFraudulentTransOverviewLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})

export class PosFraudulentTransOverviewToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside PosFraudulentTransOverviewToolbarLandingRoutingModule page... ');
   }
 }
