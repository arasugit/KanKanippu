import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const dbSumRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'MGV',
      title: 'Debit Summary',
    },
    children: [
      {
        path: '',
        redirectTo: 'DPDBSUM',
        pathMatch: 'full',
      },
      {
        path: 'DPDBSUM',
        redirectTo: 'DPDBSUM',
        pathMatch: 'full',
      },
      {
        path: 'DPDBSUM',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'DPDBSUM' }
      }
    ]
  }
];



@NgModule({
  imports: [
    RouterModule.forChild(dbSumRoutes)   
  ],
  exports: [
    RouterModule
  ]
})
export class DbSumRoutingModule {

  constructor(){
    console.log('Inside dbSum-routing.module ');
  }
}
