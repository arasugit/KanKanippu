import { Platform } from '@angular/cdk/platform';
import { BrowserModule} from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, InjectionToken, NgModule } from '@angular/core';
import { MAT_RIPPLE_GLOBAL_OPTIONS } from '@angular/material/core';
import { MAT_LEGACY_FORM_FIELD_DEFAULT_OPTIONS as MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/legacy-form-field';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CdkTableModule,CdkColumnDef} from '@angular/cdk/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatLegacyButtonModule as MatButtonModule} from '@angular/material/legacy-button';
import { MatLegacyCardModule as MatCardModule} from '@angular/material/legacy-card';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';
import { MatLegacyInputModule as MatInputModule } from '@angular/material/legacy-input';
import { MatLegacyListModule as MatListModule} from '@angular/material/legacy-list';
import { MatLegacySelectModule as MatSelectModule } from '@angular/material/legacy-select';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatLegacySlideToggleModule as MatSlideToggleModule} from '@angular/material/legacy-slide-toggle';
import { MatLegacySliderModule  as MatSliderModule} from '@angular/material/legacy-slider';
import { MatLegacyTooltipModule as MatTooltipModule } from '@angular/material/legacy-tooltip';
import { ActivatedRouteSnapshot, RouteReuseStrategy } from '@angular/router';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { RufMaterialModule } from '@ruf/material';
import { HomePageComponentsModule } from './home-page-components/home-page-components.module';
import { ThemePickerService } from './home-page-components/theme-color/theme-picker';
import {
  info,
  RufI18nModule,
  RufIconModule,
  RufMDIStrategy,
  RufNavigationModule,
  RufRouterModule,
  RufRouterUtilService,
  RufScrollbarModule,
  RufShellModule,
  RUF_INFO,
  USE_RUF_SCROLLBAR,
  RufTriggerModule,
  RufAppCanvasModule,
  RufLayoutModule,
  RufBannerModule,
  RufFooterModule,
  RufMenubarModule,
  RufNavbarModule,
  RufPageHeaderModule
} from '@ruf/shell';
import { BnNgIdleService } from 'bn-ng-idle';
import { environment } from '../environments/environment';
import { RufThemeRollerModule } from '@ruf/theme-roller';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomTranslateLoader,
         GlobalsService,
         FormBusinessService,
         FormNavigationService,
         RemoteObjectService,
         InstService,
         BizService,
         AuthService,
         MenuService,
         DataTableService,
         RequestedPermissions,
         ISTRouteReuseStrategy,
         MessageService,
         ISTComponentModule,
         IstProfileComponent,
         IstChgPwdComponent,MON_ENV_CONFIG,IstSiteNodeComponent,
         MonConfigService, AutoRefreshService} from '@ist-custom-project/shell';

import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { MonToolLandingModule} from './mon-tool-landing/mon-tool-landing.module';
import { HighchartsChartModule } from 'highcharts-angular';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatBadgeModule } from '@angular/material/badge';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NgxSpinnerModule } from 'ngx-spinner';

export class CustomMDIStrategy extends RufMDIStrategy {
  constructor(util: RufRouterUtilService) {
    super(util);
}

shouldDetach(route: ActivatedRouteSnapshot): boolean {
    const path = this.util.getLeafNodePath(route);
    console.log("PATH",path);
    if (path.includes('mdi-strategy')) {
      return true;
    }
    return false;
  }
}

export const getMDIStrategy = (util: RufRouterUtilService) => new CustomMDIStrategy(util);

export const translateHttpLoaderFactory = (http: HttpClient) => new TranslateHttpLoader(http, 'assets/i18n/');

export const getPlatForm = (platform: Platform) => !(platform.ANDROID || platform.IOS || platform.SAFARI);

@NgModule({
  declarations: [AppComponent,IstProfileComponent,IstChgPwdComponent,IstSiteNodeComponent],
  imports: [
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    RufShellModule,
    RufI18nModule.forRoot(),
    RufRouterModule.forRoot(),
    RufNavigationModule.forRoot(),
    FlexLayoutModule,
    MatIconModule,
    MatDialogModule,
    MatSidenavModule,
    MatButtonModule,
    MatTooltipModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatInputModule,
    MatAutocompleteModule,
    MatSliderModule,
    MatListModule,
    RufIconModule,
    HttpClientModule,
    RufScrollbarModule,
    RufMaterialModule,
    RufThemeRollerModule,
    CdkTableModule,
    MatCardModule,
    HighchartsChartModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: CustomLoaderFactory,
        deps: [GlobalsService, HttpClient, FormBusinessService]
      },
      isolate: false
    }),
    RufTriggerModule,
    RufAppCanvasModule,
    RufLayoutModule,
    RufBannerModule,
    RufFooterModule,
    RufMenubarModule,
    RufNavbarModule,
    RufPageHeaderModule,
    HomePageComponentsModule,
    MonToolLandingModule,
    MonitorNavigationModule,
    ISTComponentModule,
    MatExpansionModule,
    BrowserAnimationsModule,
    MatBadgeModule,
    MatSnackBarModule,
    NgxSpinnerModule,
  ],
  bootstrap: [AppComponent],
  providers: [
    { provide: MAT_RIPPLE_GLOBAL_OPTIONS, useValue: { disabled: true } },
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: { appearance: 'outline' },
    },
    { provide: USE_RUF_SCROLLBAR, useFactory: getPlatForm, deps: [Platform] },
    RemoteObjectService,
    InstService,
    MenuService,
    BizService,
    GlobalsService,
    AuthService,
    DataTableService,
    FormBusinessService,
    CdkColumnDef,
    RequestedPermissions,
    RufRouterUtilService,
    BnNgIdleService,
    {
      provide: RouteReuseStrategy,
      useClass: ISTRouteReuseStrategy,
      deps: [ RufRouterUtilService, GlobalsService ]
    },
    FormNavigationService,
    MessageService,
    {
      provide: RouteReuseStrategy,
      useClass: ISTRouteReuseStrategy,
      deps: [ RufRouterUtilService, GlobalsService ]
    },
    { provide: RUF_INFO, useValue: info },
    { provide: 'THEME_PICKER_SERVICE', useClass: ThemePickerService },
    {provide:MON_ENV_CONFIG,useValue:environment},
    MonConfigService,
    AutoRefreshService
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AppModule {
  constructor(platform: Platform) {}
}
export function CustomLoaderFactory (globals: GlobalsService, http: HttpClient, mform: FormBusinessService) {
  return new CustomTranslateLoader(globals, http, mform);
}

