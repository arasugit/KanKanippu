import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RejectedTxnsToolbarLandingRoutingModule } from './rejected-txn-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { AtmTotalTxnsToolbarLandingRoutingModule } from './atm-total-txn-toolbar-landing-routing.module';

@NgModule({
  imports: [
    CommonModule,
    AtmTotalTxnsToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: []
})
export class AtmTotalTxnsToolBarLandingModule {}
