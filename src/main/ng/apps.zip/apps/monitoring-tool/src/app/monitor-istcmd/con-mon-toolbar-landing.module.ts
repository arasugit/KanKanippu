import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConMonToolbarLandingRoutingModule } from './con-mon-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    ConMonToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class ConMonToolBarLandingModule {}
