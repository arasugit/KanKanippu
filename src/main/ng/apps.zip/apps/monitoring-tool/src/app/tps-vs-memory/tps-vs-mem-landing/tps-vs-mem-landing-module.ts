import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TpsVsMemoryModule } from '@ist-custom-project/shell';
import { TpsVsMemoryRoutingModule } from './tps-vs-mem-routing-module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TpsVsMemoryRoutingModule,
    TpsVsMemoryModule

  ],
  declarations: []
})
export class TpsVsMemoryLandingModule {
   constructor(){}
}
