import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { EnCashLandingRoutingModule } from './enCash-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    EnCashLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class EnCashLandingModule {}
