import { NgModule } from '@angular/core';
import { MonitorNavigationModule, PosFraudulentTransOverviewModule } from '@ist-custom-project/shell';
import { PosFraudulentTransOverviewRoutingModule } from './pos-fraudulent-trans-overview-routing-module';


@NgModule({
    imports :[
    MonitorNavigationModule,
    PosFraudulentTransOverviewRoutingModule,
    PosFraudulentTransOverviewModule
  ],
  declarations: []
})

export class PosFraudulentTransOverviewLandingModule {
   constructor(){
     console.log("Inside PosFraudulentTransOverviewLandingModule page");
   }
}
