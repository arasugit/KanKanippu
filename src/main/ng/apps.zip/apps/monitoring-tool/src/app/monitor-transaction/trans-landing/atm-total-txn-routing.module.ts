import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,} from '@ist-custom-project/shell';
import {AtmTotalTxnsComponent} from '@ist-custom-project/shell';

export const atmTotalTxnsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'ATM Total Transaction History',
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMTOTHIST',
        pathMatch: 'full',
      },
      {
        path: 'ATMTOTHIST',
        component: AtmTotalTxnsComponent,
        data: { module: 'ATMTOTHIST' } 
      }
    ]   
  }, 
];

 

@NgModule({
  imports: [
    RouterModule.forChild(atmTotalTxnsRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class AtmTotalTxnsRoutingModule { 

  constructor(){
    console.log('ATM Total Txns Routing Module ');
  }
}
