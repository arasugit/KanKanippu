import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',redirectTo: '',pathMatch: 'full',
  }, 
  {
    path: '',loadChildren: () =>import('./landing/pos-merch-landing.module').then((m) => m.POSMerchantLandingModule)
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ParentPOSMerchantRoutingModule {
  constructor(){}
}
