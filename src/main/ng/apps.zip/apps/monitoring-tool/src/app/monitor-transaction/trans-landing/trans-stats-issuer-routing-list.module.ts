import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

export const transStatsIssuerListRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats - Issuer',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNISS_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNISS_REQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNISS_REQ' } 
      },
      {
        path: 'HOURLY',
        component: MonitorDynamicComponentDisplayComponent,
       // component: TransactionStatsIssuerDetailsComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'MONTHLY' } 
      }
      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsIssuerListRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsIssuerRoutingListModule { 

  constructor(){
    console.log(' Transaction stats Issuer Routing Module ');
  }
}
