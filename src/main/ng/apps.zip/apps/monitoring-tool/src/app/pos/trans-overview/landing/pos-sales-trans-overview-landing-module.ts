import { NgModule } from '@angular/core';
import { MonitorNavigationModule, PosSalesTransOverviewModule } from '@ist-custom-project/shell';
import { PosTransOverviewRoutingModule } from './pos-sales-trans-overview-routing-module';


@NgModule({
    imports :[
    MonitorNavigationModule,
    PosTransOverviewRoutingModule,
    PosSalesTransOverviewModule
  ],
  declarations: []
})

export class PosTransOverviewLandingModule {
   constructor(){
     console.log("Inside PosTransOverviewLandingModule page");
   }
}
