import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./monAtmExt-landing/monAtmExt-landing-module').then((m) => m.MonAtmExtLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class MonAtmExtToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside MonAtmExtToolbarLandingRoutingModule page... ');
   }
 }
