import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

export const transStatsTerminalRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Terminal',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNTERC',
        pathMatch: 'full',
      },
      {
        path: 'TXNTERC',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNTERC' } 
      }
      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsTerminalRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsTerminalRoutingModule { 

  constructor(){
    console.log(' Transaction stats Terminal Routing Module ');
  }
}
