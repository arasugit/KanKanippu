import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransactionStatsListModule,TransactionStatsIssuerListModule } from '@ist-custom-project/shell';
import { TransStatsRoutingModule } from './trans-stats-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsRoutingModule,
    TransactionStatsListModule

  ],
  declarations: []
})
export class TransStatsLandingModule {
   constructor(){}
}
