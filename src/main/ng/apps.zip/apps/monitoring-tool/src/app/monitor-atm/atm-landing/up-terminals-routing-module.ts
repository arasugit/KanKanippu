import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, UpTerminalsComponent} from '@ist-custom-project/shell';

export const upTerminalsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'ATM Overall Up Terminals',
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMUPT_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMUPT_REQ',
        component:UpTerminalsComponent,
        data: { module: 'ATMUPT_REQ' } 
      }
    ]   
  },
];


@NgModule({
  imports: [
    RouterModule.forChild(upTerminalsRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class UpTerminalsRoutingModule { 

  constructor(){
    console.log('ATM Up Terminals Routing Module');
  }
}
