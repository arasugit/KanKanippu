import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ParentATMTotalsRoutingModule} from './atm-totals-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    ParentATMTotalsRoutingModule,
    MonitorNavigationModule  
  ],
  
})
export class ParentATMTotalsModule {}
