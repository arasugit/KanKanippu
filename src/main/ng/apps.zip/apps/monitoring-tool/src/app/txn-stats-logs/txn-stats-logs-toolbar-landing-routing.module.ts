import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',   
    loadChildren: () =>import('./txn-stats-logs-landing/txn-stats-logs-landing-module').then((m) => m.TransStatsLogsLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class TransStatsLogsToolbarLandingRoutingModule {
  constructor(){ }
 }
