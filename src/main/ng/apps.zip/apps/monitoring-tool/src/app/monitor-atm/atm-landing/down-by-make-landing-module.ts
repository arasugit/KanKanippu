import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, DownByMakeModule} from '@ist-custom-project/shell';
import { DownByMakeRoutingModule } from './down-by-make-routing-module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    DownByMakeRoutingModule,
    DownByMakeModule

  ],
  declarations: []
})
export class DownByMakeLandingModule {
   constructor(){}
}
