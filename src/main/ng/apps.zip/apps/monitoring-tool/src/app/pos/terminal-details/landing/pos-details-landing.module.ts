import { FlexLayoutModule } from '@angular/flex-layout';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PosDetailsLandingRoutingModule } from './pos-details-landing-routing.module';
import { MonitorNavigationModule} from '@ist-custom-project/shell';
import { PosTerminalDetailsModule } from '@ist-custom-project/shell';


@NgModule({
  declarations: [ ],
  imports: [
    CommonModule,
    FlexLayoutModule,
    PosDetailsLandingRoutingModule,
    MonitorNavigationModule,
    PosTerminalDetailsModule
  ],
})
export class PosDetailsLandingModule {
   constructor(){}
}

