import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, SuccessfulTxncpncpcModule} from '@ist-custom-project/shell';
import { SuccessfulTxncpncpcRoutingModule } from './success-txncpncpc-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    SuccessfulTxncpncpcRoutingModule,
    SuccessfulTxncpncpcModule
  ],
  declarations: []
})
export class SuccessfulTxncpncpcsLandingModule {
   constructor(){}
}
