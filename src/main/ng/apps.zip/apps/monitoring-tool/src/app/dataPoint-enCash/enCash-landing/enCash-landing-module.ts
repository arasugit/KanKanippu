import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,EnCashModule } from '@ist-custom-project/shell';
import { EnCashRoutingModule } from './enCash-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    EnCashRoutingModule,
    EnCashModule
  ],
  declarations: []
})
export class EnCashLandingModule {
   constructor(){
     console.log("Inside EnCashLandingModule page");
   }
}
