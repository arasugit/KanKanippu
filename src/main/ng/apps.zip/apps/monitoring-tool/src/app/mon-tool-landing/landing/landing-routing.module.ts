import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonLandingComponent,MonitorDynamicComponentDisplayComponent} from '@ist-custom-project/shell';

export const homeRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Overall Network Status',
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMAVL_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMAVL_REQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'home' } 
      },
      {
        path: 'app-health',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'home' }
      },
    ]
  },
];
@NgModule({
  imports: [RouterModule.forChild(homeRoutes)],
  exports: [RouterModule]
})
export class LandingRoutingModule { }
