import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule } from '../../../../../../ng/libs/shell/src';
import { ReportsToolBarLandingRoutingModule } from './reports-landing-routing.module';
import { MON_TOOL, MonitorComponentData } from '../../../../../../ng/libs/shell/src/monitor-components';
import { TranLogComponent } from '../../../../../../ng/libs/shell/src/reports-components/tranlog.component';
 
export const tranLogData: MonitorComponentData = {
    title: 'Incident Monitoring',
    icon: 'home',
    examples: {  
        'TRANLOG': {
            label: 'Transaction Log',
            title: 'Transaction Log ',
            description: 'Transaction Log',
            rufId: 'TRANLOG',
            component: TranLogComponent
        }
       
    }
  
    
  };
  
/**
 * NgModule that includes all Material modules that are required to serve the demo-app.
 */
@NgModule({
  imports: [
    CommonModule,
    ReportsToolBarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [{ provide: MON_TOOL, useValue: tranLogData }],
  
})
export class ReportsToolBarLandingModule {}
