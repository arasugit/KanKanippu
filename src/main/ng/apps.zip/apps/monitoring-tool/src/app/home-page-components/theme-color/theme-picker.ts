import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { MonTheme } from './mon-theme';

@Injectable({
  providedIn: 'root',
})
export class ThemePickerService {
  private _currentTheme: MonTheme = {
    href: 'fis-default',
    isDefault: true,
    name: 'Default',
    id: 'default',
    primary: '#4bcd3e',
    isLight: true
  };
  themeChange$ = new BehaviorSubject<MonTheme>(this._currentTheme);
  private _isDark = false;

  get darkTheme() {
    return this._isDark;
  }

  set darkTheme(value) {
    this._isDark = value;
  }

  get currentTheme() {
    return this._currentTheme;
  }

  set currentTheme(val) {
    this._currentTheme = val;
    this._currentTheme.isLight = !this.darkTheme;
    this.themeChange$.next(this._currentTheme);
  }
}
