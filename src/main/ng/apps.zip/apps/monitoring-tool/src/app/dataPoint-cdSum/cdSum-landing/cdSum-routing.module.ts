import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const cdSumRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'MGV',
      title: 'Credit Summary',
    },
    children: [
      {
        path: '',
        redirectTo: 'DPCDSUM',
        pathMatch: 'full',
      },
      {
        path: 'DPCDSUM',
        redirectTo: 'DPCDSUM',
        pathMatch: 'full',
      },
      {
        path: 'DPCDSUM',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'DPCDSUM' }
      }
    ]
  }
];



@NgModule({
  imports: [
    RouterModule.forChild(cdSumRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class CdSumRoutingModule {

  constructor(){
    console.log('Inside cdSum-routing.module ');
  }
}
