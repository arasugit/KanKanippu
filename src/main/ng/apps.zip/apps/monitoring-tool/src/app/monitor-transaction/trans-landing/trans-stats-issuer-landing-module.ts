import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransactionStatsIssuerListModule } from '@ist-custom-project/shell';
import { TransStatsIssuerRoutingModule } from './trans-stats-issuer-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsIssuerRoutingModule,
    TransactionStatsIssuerListModule

  ],
  declarations: []
})
export class TransStatsIssuerLandingModule {
   constructor(){}
}
