import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,MonGlbValModule } from '@ist-custom-project/shell';
import { MonGlbValRoutingModule } from './monGlbVal-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    MonGlbValRoutingModule,
    MonGlbValModule

  ],
  declarations: []
})
export class MonGlbValLandingModule {
   constructor(){
     console.log("Inside MonGlbValLandingModule page");
   }
}
