import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,TransactionStatsIssuerListComponent} from '@ist-custom-project/shell';

export const transStatsIssuerRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats - Issuer',
    },
    children: [
      {
        path: '',
        redirectTo: 'TRANS_STATS_ISSUER',
        pathMatch: 'full',
      },
      {
        path: 'TRANS_STATS_ISSUER',
        component: TransactionStatsIssuerListComponent,
        data: { module: 'TRANS_STATS_ISSUER' } 
      },
      {
        path: 'HOURLY',
        //component: MonitorDynamicComponentDisplayComponent,
        component: TransactionStatsIssuerListComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: TransactionStatsIssuerListComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: TransactionStatsIssuerListComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: TransactionStatsIssuerListComponent,
        data: { module: 'MONTHLY' } 
      }
      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsIssuerRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsIssuerRoutingModule { 

  constructor(){
    console.log(' Transaction stats Issuer Routing Module ');
  }
}
