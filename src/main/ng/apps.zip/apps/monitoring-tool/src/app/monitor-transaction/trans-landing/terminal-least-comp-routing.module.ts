import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,TerminalLeastCompComponent} from '@ist-custom-project/shell';

export const terminalLeastCompRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Details',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNTL_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNTL_REQ',
        component: TerminalLeastCompComponent,
        data: { module: 'TXNTL_REQ' } 
      },
      {
        path: 'HOURLY',
        //component: MonitorDynamicComponentDisplayComponent,
        component: TerminalLeastCompComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: TerminalLeastCompComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: TerminalLeastCompComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: TerminalLeastCompComponent,
        data: { module: 'MONTHLY' } 
      }
      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(terminalLeastCompRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TerminalLeastCompRoutingModule { 

  constructor(){
    console.log(' Transaction stats terminal Least Routing Module ');
  }
}
