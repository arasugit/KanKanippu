import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TerminalLeastCompModule } from '@ist-custom-project/shell';
import { TerminalLeastCompRoutingModule } from './terminal-least-comp-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TerminalLeastCompRoutingModule,
    TerminalLeastCompModule

  ],
  declarations: []
})
export class TerminalLeastCompLandingModule {
   constructor(){}
}
