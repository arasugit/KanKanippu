import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransStatsProcCodeModule } from '@ist-custom-project/shell';
import { TransStatsProcCodeRoutingModule } from './trans-stats-proc-code-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsProcCodeRoutingModule,
    TransStatsProcCodeModule

  ],
  declarations: []
})
export class TransStatsProcCodeLandingModule {
   constructor(){}
}
