import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const monGlbValRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'MGV',
      title: 'Mon Global Value',
    },
    children: [
      {
        path: '',
        redirectTo: 'MONGLBVAL',
        pathMatch: 'full',
      },
      {
        path: 'MONGLBVAL',
        redirectTo: 'MONGLBVAL',
        pathMatch: 'full',
      },
      {
        path: 'MONGLBVAL',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'monGlbVal' }
      }
    ]
  }
];



@NgModule({
  imports: [
    RouterModule.forChild(monGlbValRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class MonGlbValRoutingModule {

  constructor(){
    console.log('Inside istcmd-routing.module ');
  }
}
