import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,TransStatsLogsComponent} from '@ist-custom-project/shell';

export const transStatsLogsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Logs',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNSTSLOG',
        pathMatch: 'full',
      },
      {
        path: 'TXNSTSLOG',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNSTSLOG' } 
      }
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsLogsRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsLogsRoutingModule { 

  constructor(){
    console.log(' Transaction Stats Logs Routing Module ');
  }
}
