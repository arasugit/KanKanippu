import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

export const tranLogRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'Transaction Log',
      title: 'Transaction Log',
    },
    children: [
      {
        path: '',
        redirectTo: 'TRANLOG',
        pathMatch: 'full',
      },
      {
        path: 'TRANLOG',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TRANLOG' } 
      }
    ]   
  }
];



@NgModule({
  imports: [
    RouterModule.forChild(tranLogRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TranlogLandingRoutingModule { 

  constructor(){
    console.log(' TranLog Routing Module ');
  }
}
