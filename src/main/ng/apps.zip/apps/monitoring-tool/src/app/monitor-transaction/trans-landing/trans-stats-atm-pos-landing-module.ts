import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransStatsAtmPosModule } from '@ist-custom-project/shell';
import { TransStatsAtmPosRoutingModule } from './trans-stats-atm-pos-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsAtmPosRoutingModule,
    TransStatsAtmPosModule

  ],
  declarations: []
})
export class TransStatsAtmPosLandingModule {
   constructor(){}
}
