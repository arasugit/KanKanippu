export interface MonTheme {
    name: string;
    id: string;
    href?: string;
    primary?: string;
    isDefault?: boolean;
    isLight?: boolean
}