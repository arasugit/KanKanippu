import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,ISTCommandModule } from '@ist-custom-project/shell';
import { ISTCmdRoutingModule } from './istcmd-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    ISTCmdRoutingModule,
    ISTCommandModule

  ],
  declarations: []
})
export class ISTCmdLandingModule {
   constructor(){
     console.log("Inside istcmd-landing-module page");
   }
}
