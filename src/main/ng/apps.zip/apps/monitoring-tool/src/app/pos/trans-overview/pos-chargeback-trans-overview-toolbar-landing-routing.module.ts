import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./landing/pos-chargeback-trans-overview-landing-module').then((m) => m.PosChargebackTransOverviewLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})

export class PosChargebackTransOverviewToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside PosChargebackTransOverviewToolbarLandingRoutingModule page... ');
   }
 }
