import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RltmCashToolbarLandingRoutingModule } from './rltmCash-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    RltmCashToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class RltmCashToolBarLandingModule {}
