import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  // {
  //   path: '',
  //   redirectTo: '',
  //   pathMatch: 'full',
  // },
  {
    path: 'TSKCMD',
    redirectTo: '/TSKCMD/TSKCMD',
    pathMatch: 'full',
  },
  {
    path: 'BINDTLS',
    redirectTo: '/TSKCMD/BINDTLS',
    pathMatch: 'full',
  },
  {
    path: 'PRTDTLS',
    redirectTo: '/PRTDTLS/PRTDTLS',
    pathMatch: 'full',
  },
  {
    path: 'PORTDASH',
    redirectTo: '/PRTDTLS/PORTDASH',
    pathMatch: 'full',
  },
  {
    path: 'MEMDTLS',
    redirectTo: '/TSKCMD/MEMDTLS',
    pathMatch: 'full',
  },
  {
    path: 'TRCDTLS',
    redirectTo: '/TSKCMD/TRCDTLS',
    pathMatch: 'full',
  },
  {
    path: 'RSRCUSG',
    redirectTo: '/TSKCMD/RSRCUSG',
    pathMatch: 'full',
  },
  {
    path: 'EVNTDTLS',
    redirectTo: '/TSKCMD/EVNTDTLS',
    pathMatch: 'full',
  },
  {
    path: 'MBCDOPTS',
    redirectTo: '/TSKCMD/MBCDOPTS',
    pathMatch: 'full',
  },
  {
    path: 'MBLOOKTS',
    redirectTo: '/TSKCMD/MBLOOKTS',
    pathMatch: 'full',
  },
  {
    path: 'MBCDUPTME',
    redirectTo: '/TSKCMD/MBCDUPTME',
    pathMatch: 'full',
  },
  {
    path: 'SAFTXNDATA',
    redirectTo: '/TSKCMD/SAFTXNDATA',
    pathMatch: 'full',
  },
  {
    path: 'FISYUSAGE',
    redirectTo: '/FISYUSAGE/FISYUSAGE',
    pathMatch: 'full',
  },
  {
    path: 'PLTFDASH',
    redirectTo: '/FISYUSAGE/PLTFDASH',
    pathMatch: 'full',
  },
  {
    path: 'SYCPUUSAGE',
    redirectTo: '/FISYUSAGE/SYCPUUSAGE',
    pathMatch: 'full',
  },
  {
    path: 'PLTFDASH',
    redirectTo: '/FISYUSAGE/PLTFDASH',
    pathMatch: 'full',
  },
  {
    path: 'SYCPUUSAGE2',
    redirectTo: '/FISYUSAGE/SYCPUUSAGE2',
    pathMatch: 'full',
  },
  {
    path: 'INCCONFIG',
    redirectTo: '/INCCONFIG/INCCONFIG',
    pathMatch: 'full',
  },
  {
    path: 'INCALERT',
    redirectTo: '/INCALERT/INCALERT',
    pathMatch: 'full',
  },
  {
    path: 'INCUPDATE',
    redirectTo: '/INCUPDATE/INCUPDATE',
    pathMatch: 'full',
  },
  {
    path: 'ATMFLTVIEW',
    redirectTo: '/ATMFLTVIEW/ATMFLTVIEW',
    pathMatch: 'full',
  },
  {
    path: 'ATMRTCASH',
    redirectTo: '/ATMRTCASH/ATMRTCASH',
    pathMatch: 'full',
  },
  {
    path: 'MONGLBVAL',
    redirectTo: '/MONGLBVAL/MONGLBVAL',
    pathMatch: 'full',
  },
  {
    path: 'TRANLOG',
    redirectTo: '/TRANLOG/TRANLOG',
    pathMatch: 'full',
  },
  {
    path: 'ATMNTWRKDS',
    redirectTo: '/ATMNTWRKDS/ATMNTWRKDS',
    pathMatch: 'full',
  },
  {
    path: 'DPENCASH',
    redirectTo: '/DPENCASH/DPENCASH',
    pathMatch: 'full',
  },
  {
    path: 'DPDBSUM',
    redirectTo: '/DPDBSUM/DPDBSUM',
    pathMatch: 'full',
  },
  {
    path: 'DPCDSUM',
    redirectTo: '/DPCDSUM/DPCDSUM',
    pathMatch: 'full',
  },
  {
    path: 'INCCONFIG',
    loadChildren: () =>import('../incident-management-landing/inclist-landing/inclist-landing.module').then((m) => m.IncListLandingModule)
  },
  {
    path: 'INCALERT',
    // loadChildren: () =>import('../incident-management-landing/inclist-landing/incaction-landing.module').then((m) => m.IncActionLandingModule)
    loadChildren: () =>import('../incident-management-landing/inclist-landing/inclist-landing.module').then((m) => m.IncListLandingModule)
  },
  {
    path: 'INCUPDATE',
    // loadChildren: () =>import('../incident-management-landing/inclist-landing/incalert-landing.module').then((m) => m.IncAlertLandingModule)
    loadChildren: () =>import('../incident-management-landing/inclist-landing/inclist-landing.module').then((m) => m.IncListLandingModule)
  },
  {
    path: 'IPCADTLS',
    redirectTo: '/FISYUSAGE/IPCADTLS',
    pathMatch: 'full',
  },
  {
    path: 'PROCDTLS',
    redirectTo: '/TSKCMD/PROCDTLS',
    pathMatch: 'full',
  },
  {
    path: 'QUEUEDTLS',
    redirectTo: '/TSKCMD/QUEUEDTLS',
    pathMatch: 'full',
  },
  {
    path: 'DEBUGM_REQ',
    redirectTo: '/TSKCMD/DEBUGM_REQ',
    pathMatch: 'full',
  },
  {
    path: 'DBCONNDTLS',
    redirectTo: '/PRTDTLS/DBCONNDTLS',
    pathMatch: 'full',
  },
  {
    path: 'CA_PSR',
    redirectTo: '/TSKCMD/CA_PSR',
    pathMatch: 'full',
  },
  {
    path: 'CA_PCP',
    redirectTo: '/TSKCMD/CA_PCP',
    pathMatch: 'full',
  },
  {
    path: 'CA_PSC',
    redirectTo: '/TSKCMD/CA_PSC',
    pathMatch: 'full',
  },
  {
    path: 'CA_PQ',
    redirectTo: '/TSKCMD/CA_PQ',
    pathMatch: 'full',
  },

  {
    path: 'TSKCMD',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'BINDTLS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'PRTDTLS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/con-mon-landing-module').then((m) => m.ConMonLandingModule)
  },
  {
    path: 'MEMDTLS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'TRCDTLS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'RSRCUSG',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'EVNTDTLS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'MBCDOPTS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'MBLOOKTS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'MBCDUPTME',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'SAFTXNDATA',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'FISYUSAGE',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/platform-mon-landing-module').then((m) => m.PlatformMonLandingModule)
  },
  {
    path: 'SYCPUUSAGE',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/platform-mon-landing-module').then((m) => m.PlatformMonLandingModule)
  },
  {
    path: 'SYCPUUSAGE2',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/platform-mon-landing-module').then((m) => m.PlatformMonLandingModule)
  },
  {
    path: 'IPCADTLS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/platform-mon-landing-module').then((m) => m.PlatformMonLandingModule)
  },
  {
    path: 'PROCDTLS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'QUEUEDTLS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'DEBUGM_REQ',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'CA_PSR',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'CA_PCP',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'CA_PSC',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'CA_PQ',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  },
  {
    path: 'DBCONNDTLS',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/con-mon-landing-module').then((m) => m.ConMonLandingModule)
  },
  {
    path: 'ATMFLTVIEW',
    loadChildren: () =>import('../monitor-atm/fltView-landing/fltView-landing-module').then((m) => m.FltViewLandingModule)
  },
  {
    path: 'ATMRTCASH',
    loadChildren: () =>import('../monitor-atm/rltmCash-landing/rltmCash-landing-module').then((m) => m.RltmCashLandingModule)
  },
  {
    path: 'MONGLBVAL',
    loadChildren: () =>import('../mon-glbVal/monGlbVal-landing/monGlbVal-landing-module').then((m) => m.MonGlbValLandingModule)
  },
  {
    "path": "TRANLOG",
    loadChildren : () => import('../reports-landing/reports-landing.module').then(m => m.ReportsToolBarLandingModule)
   },
   {
    path: 'ATMFLTVIEW111',
    loadChildren: () =>import('../monitor-atm/fltView-landing/fltView-landing-module').then((m) => m.FltViewLandingModule)
  },
  {
    path: 'ATMRTCASHH',
    loadChildren: () =>import('../atm-rltm-cash/atm-rltm-cash-landing/atm-rltm-cash-history-landing-module').then((m) => m.AtmRltmCashHistoryLandingModule)
  },
  {
    path: 'ATMNTWRKDS',
    loadChildren: () =>import('../switch-DashBoard/switchDashBoard-landing/switchDashBoard-landing-module').then((m) => m.SwitchDashBoardLandingModule)
  },
  {
    path: 'DPENCASH',
    loadChildren: () =>import('../dataPoint-enCash/enCash-landing/enCash-landing-module').then((m) => m.EnCashLandingModule)
  },
  {
    path: 'DPDBSUM',
    loadChildren: () =>import('../dataPoint -dbSum/dbSum-landing/dbSum-landing.module').then((m) => m.DbSumLandingModule)
  },
  {
    path: 'DPDBSUM',
    loadChildren: () =>import('../dataPoint -dbSum/dbSum-landing/dbSum-landing.module').then((m) => m.DbSumLandingModule)
  },
  {
    path: 'DPCDSUM',
    loadChildren: () =>import('../dataPoint-cdSum/cdSum-landing/cdSum-landing.module').then((m) => m.CdSumLandingModule)
  },
  {
    path: 'PORTDASH',
    loadChildren: () =>import('../monitor-istcmd/istcmd-landing/con-mon-landing-module').then((m) => m.ConMonLandingModule)
  },
  {
    path: '',
    loadChildren: () =>
      import('./landing/landing.module').then((m) => m.LandingModule )
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class MonToolLandingRoutingModule {
  constructor(){
    console.log("Inside mon-tool-landing-routing.module ");
  }
 }
