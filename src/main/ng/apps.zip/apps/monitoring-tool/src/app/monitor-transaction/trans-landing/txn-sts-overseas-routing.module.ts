import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,TerminalLeastCompComponent} from '@ist-custom-project/shell';

export const transStatsOverseasRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Overseas',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNSTSOS',
        pathMatch: 'full',
      },
      {
        path: 'TXNSTSOS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNSTSOS' } 
      }
      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsOverseasRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsOverseasRoutingModule { 

  constructor(){
    console.log(' Transaction stats Overseas Routing Module ');
  }
}
