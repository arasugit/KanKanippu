import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

const posTransOverviewRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'POS Trans Overview'
    },
    children: [
      {
        path: '',
        redirectTo: 'POSTRANVW',
        pathMatch: 'full',
      },
      {
        path: 'POSTRANVW',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'POSTRANVW' }
      },
      {
        path: 'HOURLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'HOURLY' }
      },
      {
        path: 'DAILY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'DAILY' }
      },
      {
        path: 'YESTERDAY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'YESTERDAY' }
      },
      {
        path: 'WEEKLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'WEEKLY' }
      },
      {
        path: 'MONTHLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'MONTHLY' }
      },
      {
        path: 'QUARTELY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'QUARTELY' }
      },
      {
        path: 'CUSTOM',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'CUSTOM' }
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(posTransOverviewRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class PosTransOverviewRoutingModule {
  constructor(){
    console.log('Inside PosTransOverviewRoutingModule');
  }
}
