import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./landing/pos-sales-trans-overview-landing-module').then((m) => m.PosTransOverviewLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})

export class PosTransOverviewToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside PosTransOverviewToolbarLandingRoutingModule page... ');
   }
 }
