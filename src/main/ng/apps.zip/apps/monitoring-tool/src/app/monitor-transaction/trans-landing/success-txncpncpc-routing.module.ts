import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, SuccessfulTxncpncpcComponent} from '@ist-custom-project/shell';

export const successfulTxncpncpcRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Successful Transactions Count',
    },
    children: [
      {
        path: '',
        redirectTo: 'CPNCPC_REQ',
        pathMatch: 'full',
      },
      {
        path: 'CPNCPC_REQ',
        component: SuccessfulTxncpncpcComponent,
        data: { module: 'CPNCPC_REQ' }
      },
      {
        path: 'ACQUIRING',
        component: SuccessfulTxncpncpcComponent,
        data: { module: 'ACQUIRING' }
      },
      {
        path: 'ISSUING',
        component: SuccessfulTxncpncpcComponent,
        data: { module: 'ISSUING' }
      }
    ]
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(successfulTxncpncpcRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class SuccessfulTxncpncpcRoutingModule {

  constructor(){
    console.log('Successful Txns Routing Module ');
  }
}
