import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonToolLandingRoutingModule } from './mon-tool-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    MonToolLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class MonToolLandingModule {}
