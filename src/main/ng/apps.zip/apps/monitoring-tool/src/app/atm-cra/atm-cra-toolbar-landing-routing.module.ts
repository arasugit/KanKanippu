import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./atm-cra-landing/atm-cra-landing-module').then((m) => m.AtmCraLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class AtmCraToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside AtmCraToolbarLandingRoutingModule page... ');
   }
 }
