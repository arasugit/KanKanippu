import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./switchDashBoard-landing/switchDashBoard-landing-module').then((m) => m.SwitchDashBoardLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class SwitchDashBoardToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside SwitchDashBoardToolbarLandingRoutingModule page... ');
   }
 }
