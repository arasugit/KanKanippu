import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, SuccessfulTxnsModule} from '@ist-custom-project/shell';
import { SuccessfulTxnsRoutingModule } from './success-txn-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    SuccessfulTxnsRoutingModule,
    SuccessfulTxnsModule

  ],
  declarations: []
})
export class SuccessfulTxnsLandingModule {
   constructor(){}
}
