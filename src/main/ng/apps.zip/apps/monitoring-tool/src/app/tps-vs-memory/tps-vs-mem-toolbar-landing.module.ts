import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TpsVsMemoryToolbarLandingRoutingModule } from './tps-vs-mem-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    TpsVsMemoryToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class TpsVsMemoryToolBarLandingModule {}
