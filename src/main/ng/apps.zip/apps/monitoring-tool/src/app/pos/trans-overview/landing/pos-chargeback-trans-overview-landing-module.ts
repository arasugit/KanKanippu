import { NgModule } from '@angular/core';
import { MonitorNavigationModule, PosChargebackTransOverviewModule } from '@ist-custom-project/shell';
import { PosChargebackTransOverviewRoutingModule } from './pos-chargeback-trans-overview-routing-module';


@NgModule({
    imports :[
    MonitorNavigationModule,
    PosChargebackTransOverviewRoutingModule,
    PosChargebackTransOverviewModule
  ],
  declarations: []
})

export class PosChargebackTransOverviewLandingModule {
   constructor(){
     console.log("Inside PosChargebackTransOverviewLandingModule page");
   }
}
