import { NgModule } from '@angular/core';
import { PosMakeTxnToolbarLandingRoutingModule } from './pos-make-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

/**
 * NgModule that includes all Material modules that are required to serve the demo-app.
 */
@NgModule({
  imports: [
    PosMakeTxnToolbarLandingRoutingModule,
    MonitorNavigationModule
  ]
})
export class PosMakeTxnToolBarLandingModule {}
