import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const monAtmExtRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'MAE',
      title: 'ATM Extension',
    },
    children: [
      {
        path: '',
        redirectTo: 'MONATMEXT',
        pathMatch: 'full',
      },
      {
        path: 'MONATMEXT',
        redirectTo: 'MONATMEXT',
        pathMatch: 'full',
      },
      {
        path: 'MONATMEXT',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'MONATMEXT' }
      }
    ]
  }
];



@NgModule({
  imports: [
    RouterModule.forChild(monAtmExtRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class MonAtmExtRoutingModule {

  constructor(){
    console.log('Inside MonAtmExtRoutingModule.module ');
  }
}
