import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

export const incListRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'Incidents',
      title: 'Incident List',
    },
    children: [
      {
        path: '',
        redirectTo: 'INCALERT',
        pathMatch: 'full',
      },
      {
        path: 'INCCONFIG',
        redirectTo: 'INCCONFIG',
        pathMatch: 'full',
      },
      {
        path: 'INCALERT',
        redirectTo: 'INCALERT',
        pathMatch: 'full',
      },
      {
        path: 'INCUPDATE',
        redirectTo: 'INCUPDATE',
        pathMatch: 'full',
      },
      {
        path: 'INCCONFIG',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'incList' }
      },
      {
        path: 'INCALERT',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'incAction' }
      },
      {
        path: 'INCUPDATE',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'incAlert' }
      }
    ]
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(incListRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class IncListRoutingModule {

  constructor(){
    console.log(' IncList Routing Module ');
  }
}
