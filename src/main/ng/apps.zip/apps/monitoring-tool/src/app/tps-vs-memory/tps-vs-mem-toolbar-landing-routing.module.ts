import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',   
    loadChildren: () =>import('./tps-vs-mem-landing/tps-vs-mem-landing-module').then((m) => m.TpsVsMemoryLandingModule)
  }
];
 
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class TpsVsMemoryToolbarLandingRoutingModule {
  constructor(){ }
 }
