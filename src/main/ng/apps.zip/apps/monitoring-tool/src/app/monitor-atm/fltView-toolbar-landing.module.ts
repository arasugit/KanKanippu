import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FltViewToolbarLandingRoutingModule } from './fltView-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    FltViewToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class FltViewToolBarLandingModule {}
