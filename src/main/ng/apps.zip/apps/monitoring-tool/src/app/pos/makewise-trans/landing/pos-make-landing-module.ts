import { NgModule } from '@angular/core';
import { MonitorNavigationModule,POSMakewiseTxnsModule } from '@ist-custom-project/shell';
import { PosMakeTxnRoutingModule } from './pos-make-routing-module';

@NgModule({
    imports: [
    MonitorNavigationModule,
    PosMakeTxnRoutingModule,
    POSMakewiseTxnsModule
  ]
})

export class PosMakeTxnLandingModule {
   constructor(){}
}
