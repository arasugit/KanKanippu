import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, TxnStatsTypeComponent} from '@ist-custom-project/shell';

export const txnStatsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'Task',
      title: 'Transaction Stats by Type',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNTYPEREQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNTYPEREQ',
        component:TxnStatsTypeComponent,
        data: { module: 'TXNTYPEREQ' }
      },
      {
        path: 'HOURLY',
        component:TxnStatsTypeComponent,
        data: { module: 'HOURLY' }
      },
      {
        path: 'DAILY',
        component:TxnStatsTypeComponent,
        data: { module: 'DAILY' }
      },
      {
        path: 'WEEKLY',
        component:TxnStatsTypeComponent,
        data: { module: 'WEEKLY' }
      },
      {
        path: 'MONTHLY',
        component:TxnStatsTypeComponent,
        data: { module: 'MONTHLY' }
      }
    ]
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(txnStatsRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TxnStatsTypeRoutingModule {

  constructor(){
    console.log('TxnStats by Type Routing Module ');
  }
}
