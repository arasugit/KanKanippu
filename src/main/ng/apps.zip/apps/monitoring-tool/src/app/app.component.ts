import {
  Component,
  Inject,
  LOCALE_ID,
  OnInit,
  OnDestroy,
  ViewChild,
  ViewEncapsulation,
  Injectable,
  Output,
  EventEmitter
} from '@angular/core';
import { Location, DOCUMENT, PlatformLocation, DatePipe } from '@angular/common';
import {
  RufLocaleService,
  RufKeyCodes,
  RUF_INFO,
  RufDynamicSidemenuItem,
  RufWindowRef,
  RufDropdownPanelComponent,
  RufDynamicSideMenuComponent,
} from '@ruf/shell';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';
import { TAB, ESCAPE } from '@angular/cdk/keycodes';
import { Subject, Observable,Subscription, interval } from 'rxjs';
import { switchMap,map,takeUntil, tap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { MenuItem, MenuService,BizService,GlobalsService,
         InstService,RemoteObjectService,FormNavigationService,
         MessageService,StringUtil, MonConfigService, AutoRefreshService,
         IstChgPwdComponent,IstProfileComponent,
         StringMap,CommonConstants,sidenavItems,MON_ENV_CONFIG,LabelsAndValues,LabelAndValue,IstSiteNodeComponent}
         from '@ist-custom-project/shell';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { DateAdapter, NativeDateAdapter } from '@angular/material/core';
import { MediaObserver } from '@angular/flex-layout';
import { BnNgIdleService } from 'bn-ng-idle';
import { NotificationService, Notification } from './notification/notification.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Injectable()
export class ISTDateAdapter extends NativeDateAdapter { }

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers : [{ provide: DateAdapter, useClass: ISTDateAdapter}]
})

export class AppComponent implements OnInit, OnDestroy {
  title = 'PayMon - IST Switch Monitoring';
  titleXs = 'PayMon - IST Switch Monitoring';
  locale: string;
  cssVars = {};
  demoThemeName = 'Default';
  minimized = false;
  themeMode: 'light' | 'dark' = 'light';
  showbannerRow = false;
  private unsubscribe = new Subject();
  lastLoginDateTime = '';
  welcomeMsg;
  userID;
  authType;
  siteId;
  nodeName;
  showProfileLink = false;
  showChangePasswordLink = false;
  showSiteIdNodeLink = false;
  homeLinkUrl = '';
  logoutUrl = '';
  private profileMap: StringMap = {};
  chgPwdWindow: MatDialogRef<IstChgPwdComponent>;
  profileWindow: MatDialogRef<IstProfileComponent>;
  use_multilevel_menu;
  currentYear = new Date().getFullYear();
  buildVal: string;
  builds;
  themeRollerConfig;
  menuItems: RufDynamicSidemenuItem[];
  menuItemsChildren: RufDynamicSidemenuItem[];
  filteredItem: Observable<any[]>;
  log = console.log.bind(console);
  mode: string;
  @ViewChild('sidenav', { static: false }) sidenav;
  @ViewChild('rufDynamicSidemenu') rufDynamicSidemenu: RufDynamicSideMenuComponent;
  subscription: Subscription;
  formatDate = new DatePipe('en_US');
  localInfo = null;
  currentLanguageDesc = '';
  show_menu:boolean = false;
  selectedPath:string;
  siteNodeList: LabelsAndValues = new LabelsAndValues();
  selectSiteNodeWindow: MatDialogRef<IstSiteNodeComponent>;
  autoRefresh:boolean = false;
  notifications: Notification[] = [];
  unreadCount = 0;
  panelOpen = false; // To control overlay visibility
  allNotificationIds: number[] = [];
  clearNotificationIds: number[] = [];
  triggeredNotifications: any[];
  clearAllLocalIds: any;
  markAsReadLocalIds: any;
  static myapp;
  notiArray: any[] = [];
  hideClearAllButton: boolean = false;
 constructor(
    private menuService: MenuService,
    private bizService: BizService,
    private globalsService: GlobalsService,
    private instService: InstService,
    private dialog: MatDialog,
    private remoteObjectService: RemoteObjectService,
    private formNavigationService: FormNavigationService,
    private msgService: MessageService,
    public translate: TranslateService,
    private dateAdapter: DateAdapter<Date>,
    private location: PlatformLocation,
    private bnIdle: BnNgIdleService,
    private monConfigService: MonConfigService,
    private autoRefreshService: AutoRefreshService,
    @Inject(MON_ENV_CONFIG) environment:any,
    @Inject(RUF_INFO) public RUF,
    private localeService: RufLocaleService,
    @Inject(DOCUMENT) private document,
	  private _mediaObserver: MediaObserver,
    private router: Router,
    private _http: HttpClient,
    private notificationService: NotificationService,
    private sanitizer: DomSanitizer
  ) {
    console.log(" root component initialized ");

    this._mediaObserver.asObservable().pipe(takeUntil(this.unsubscribe)).subscribe(() => {
        this.mode = this.getMode();
    });
    this. use_multilevel_menu=!!(environment['use_multilevel_menu']);

    this.subscription = this.msgService.getMessage().subscribe(message => {
      if (message.text !== undefined && message.text !== 'localechanged' && this.globalsService.currentModuleTobeLoaded !== message.text) {
        this.globalsService.currentModuleTobeLoaded = message.text;
        this.translate.resetLang(this.globalsService.currentLanguage);
        this.translate.use(this.translate.getDefaultLang());
        setTimeout(() => { this.translate.use(this.globalsService.currentLanguage); }, 10);
      }
    }
    );
    GlobalsService.isNextStep = false;

    this.bnIdle.startWatching(900).subscribe((res) => {
      if (res) {
        const userName: String = this.globalsService.userContext.userID;
        this.menuService.removingEditStatus(userName).subscribe((result: any) => {
         });

        let url: any = this.globalsService.getRedirectUrl();
        const browserSafeUrl = this.getSafeUrl(window.location.href);
        if (url === 'j_spring_security_logout' && browserSafeUrl.indexOf('/forms/') > -1) {
            url = browserSafeUrl.substring(0, browserSafeUrl.indexOf('/forms/')) + '/' + url;
        }
        window.location.href = url;
      }
    });
  }

  getSafeUrl(location) {
    try {
      const url = new URL(location);

      if(url.protocol !== 'https:' && url.protocol !== 'http:' && url.origin !== window.location.origin) return '';

      var safeUrl = `${url.protocol}${url.hostname}${url.pathname}`;
      const sanitizedUri = this.sanitizer.bypassSecurityTrustUrl(safeUrl);
      safeUrl = `${safeUrl}?${sanitizedUri}`;
      return safeUrl;
    }
    catch(error) {
      return '';
    }
  }

  ngOnInit() {
    AppComponent.myapp = this;
    this.menuItems = sidenavItems;
    this.globalsService
      .loadConfig()
      .pipe(
        switchMap(() => {
        this.use_multilevel_menu = this.strToBool(this.globalsService.getProperty('use_multilevel_menu'), this.use_multilevel_menu);
        this.globalsService.setSelectedProductDetails();
        this.setHeaderBanner();
        this.triggerNotification('');
        this.callAllNotifications();
        this.instService.getLocaleInformation().subscribe(next => this.applyLocaleChanges(next));
        if (this.use_multilevel_menu) {
          return this.menuService.getMenu2();
        } else {
          return this.menuService.getMenu(this.globalsService.productId);
        }
      }))
      .subscribe(this.onGotMenu, this.onMenuErr);
  }

  callAllNotifications(){
    interval(900000).pipe(tap(()=>this.triggerNotification(''))).subscribe();
  }
  triggerNotification(change) {
    if(change === 'node_Change'){
      this.notificationService.emptyNotifications();
      if(this.panelOpen === true){
        this.togglePanel();
      }
    }
    this.notificationService.notifications$.subscribe(
      notifications => {
        this.notifications = notifications;
        this.unreadCount = this.notificationService.getUnreadCount();
      }
    );
    this.notifications.forEach(element => {
      if(!this.allNotificationIds.includes(element.id)){
        this.allNotificationIds.push(element.id);
      }
    });

    this.clearAllLocalIds = JSON.parse(localStorage.getItem('clearNotificationIds'+this.userID) as any);
    if(this.clearAllLocalIds === null){
      this.clearAllLocalIds = [];
    }
    this.markAsReadLocalIds = JSON.parse(localStorage.getItem('markAsReadIds'+this.userID)as any);
    if(this.markAsReadLocalIds === null){
      this.markAsReadLocalIds = [];
    }
    this.triggeredNotifications = [];

    this.globalsService.getNotifications().then((responseNotification:any)=>{
      this.triggeredNotifications =JSON.parse(responseNotification);
      console.log('noti',this.triggeredNotifications);
      this.triggeredNotifications.forEach(res => {
        if((!this.clearAllLocalIds.includes(res.id)) && (!this.allNotificationIds.includes(res.id))){
          this.notificationService.addNotification(res.id,res.type,res.desc,res.logDate,this.markAsReadLocalIds.includes(res.id)?true:false);
          this.notiArray.push(res.id);
        }
        else{
          this.notiArray = [];
        }
      });
      if(this.triggeredNotifications.length === 0){
        this.notificationService.emptyNotifications();
        if(this.panelOpen === true){
          this.togglePanel();
        }
      }
      if(this.notiArray.length === 0 && this.notifications.length === 0){
        this.hideClearAllButton = true;
        if(this.panelOpen === true){
          this.togglePanel();
        }
       }
       else{
        this.hideClearAllButton = false;
       }
    });
  }

  togglePanel() {
    this.panelOpen = !this.panelOpen;
  }

  markAsRead(notificationId: number) {
    this.notificationService.markAsRead(notificationId);
  }

  clearAllNotifications() {
    this.notificationService.notifications$.subscribe(
      notifications => {
        this.notifications = notifications;
      }
    );
    this.notifications.forEach(element => {
      if(!this.clearAllLocalIds.includes(element.id)){
        this.clearAllLocalIds.push(element.id);
      }
    });
    this.notificationService.clearNotifications(this.clearAllLocalIds);
    this.togglePanel();
  }

  open(path: string): void {
    this.globalsService.setStatusMessage('');
    GlobalsService.isNextStep = true;
    this.show_menu = true;
    this.selectedPath=path;
    if (path.match('://')) { // an absolute URL, assume outside of app
      document.location.href = path;
    } else {
      this.router.navigate([path])
        .then(() => this.formNavigationService.clearStack())
        .catch((e: Error) => {
          console.log('Caught a navigation error: ', e.message);
          this.globalsService.checkErrorResponse(e);
        });
    }
  }
  get color(): String {
    return this.globalsService.statusMessageColor;
  }
  get statusMessage(): String {
    return this.globalsService.statusMessage;
  }

  get lastRefreshTime(): String {
    return this.autoRefreshService.lastRefreshTime;
  }

  private strToBool(val: string, def: boolean): boolean {
    if (!val) { return def; }
    return (val === 'true' || val === 'Y' || val === 'y' || val === '1');
  }

  setHeaderBanner(): void {
    // Set Application Name
    const appName = "PayMon - "+this.globalsService.productName;
    this.title = StringUtil.isNotEmpty(appName) ? appName : 'IST/Monitor';
    this.titleXs=StringUtil.isNotEmpty(appName) ? appName : 'IST/Monitor';
    // get the base URL
    this.logoutUrl = this.globalsService.getRedirectUrl();
    this.authType = this.globalsService.authType;
    // Display profile Link
    if (this.authType === 'oassrv') {
      this.showProfileLink = true;
    }
    // Display Logged user
    this.welcomeMsg = 'Welcome ' + this.globalsService.userContext.userID;
    this.userID = this.globalsService.userContext.userID;
    // Display Site Id and Node
     const productId = this.globalsService.productId;
     if (
      productId !== null &&
       (productId === 'ISTSWT' || productId === 'CORTEX')
     ) {
       this.showSiteIdNodeLink = true;
     }
     this.siteId=this.globalsService.siteId;
     this.nodeName=this.globalsService.nodeName;
     console.log('this.siteId ::'+this.siteId);
     console.log('this.nodeName ::'+this.nodeName);

    // Display change Password
    this.showChangePasswordLink = this.globalsService.showChangePasswordLink();

    // Home button link - launcher application
    this.homeLinkUrl = this.globalsService.configOptions['launcherhome.url'];
    // Last Login Date & Time
    if (this.globalsService.userContext !== null) {
      let dt;
      if (this.authType === 'oassrv' && this.globalsService.userContext.lastLoginDateTime !== null) {
        dt = this.globalsService.userContext.lastLoginDateTime;
      }
      if (this.authType === 'oidc' && this.globalsService.userContext.lastLoginDateTimeOidc !== undefined) {
        dt = this.globalsService.userContext.lastLoginDateTimeOidc;
      }
      try {
        if (dt && dt !== null) {
          this.lastLoginDateTime =
            'Last login:' +
            this.formatDate.transform(dt, this.globalsService.dateFormat) +
            ' at ' +
            this.formatDate.transform(dt, 'HH:mm:ss');
        }
      } catch (error) {
        console.log('Invalid Last login Date and Time details: ', dt);
      }
    }
  }

  private onGotMenu = (x: MenuItem[]) => {
    this.menuItems = x as RufDynamicSidemenuItem[]; // it is really the same thing, otherwise we would have to convert
    const userName: String = this.globalsService.userContext.userID;
    this.menuItems.forEach(menu=>{
      this.menuItemsChildren= menu['children'] as RufDynamicSidemenuItem[];
      this.menuItemsChildren.forEach(y =>{
        this.globalsService.availableMenuItems.push(y['path']);
      });
    });
    this.menuService.removingEditStatus(userName).subscribe((result: any) => {
    });
    GlobalsService.isNextStep=true;
    const productId = this.globalsService.productId;
    if(productId === 'ISTSWT'){
      this.router.navigate(['/monitor']);
    }
    else if(productId === 'ISTCLR'){
     this.open('monitor/TSKCMD')
    }
    else if(productId === 'ISTMAS'){
      this.open('monitor/TSKCMD');
   }
   else{
    this.open('monitor/CTXDASH');
   }
  }

  private onMenuErr = (err: Object) => {
    this.globalsService.setErrorMessage('communication error');
  }
  applyLocaleChanges(localInfo) {
    this.localInfo = localInfo;
  }

  matches(path) {
    const pattern = new RegExp('(' + path + ')(/.*)?$');
    if (pattern.test(this.location.pathname)) {
      return false;
    }
    return true;
  }

  OpenChgPwdWindow(): void {
    this.chgPwdWindow = this.dialog.open(IstChgPwdComponent);
    this.chgPwdWindow.afterClosed().subscribe(result => {

    });
  }
  OpenProfileWindow(): void {
    const userId = this.globalsService.userContext !== null? this.globalsService.userContext.userID: '';
    if (userId !== null && userId !== '') {
      this.profileMap['DATA_TYPE'] = this.globalsService.encryptData('GET_DATA');
      this.profileMap['USER_ID'] = this.globalsService.encryptData(userId);
      console.log(this.profileMap);
      this.instService
        .getDatabaseRecords('EDIT_USER_PROFILE', this.profileMap)
        .subscribe(
          x => this.getProfileResult(x),
          err => this.getProfileResultError(err)
        );
    }
  }

  private getProfileResult(x: any): void {
    console.log('User Information:', JSON.stringify(x, null, 2));
    if (x !== null && x.length > 0) {
      const obj: any = x[0];
      if (
        typeof obj === 'string' &&
        obj !== null &&
        obj.toString().search('ERROR:') > -1
      ) {
        this.globalsService.showDialog(CommonConstants.ERROR, obj.replace('ERROR:', ''), CommonConstants.ALERT_OK);
      } else {
        this.profileWindow = this.dialog.open(IstProfileComponent, {
          data: { userObj: obj }
        });
        this.profileWindow.afterClosed().subscribe(result => {
          //  console.log('Edit profile status result ' + result);
        });
      }
    }
  }

  private getProfileResultError(x: any): void {
    if (this.globalsService.checkErrorResponse(x)) {
      this.globalsService.showDialog(CommonConstants.ERROR, x, CommonConstants.ALERT_OK);
    }
  }

  setMinimizedState(value) {
    this.minimized = value;
  }

  scrollToSelectedItem() {
    if (this.sidenav.opened) {
      this.rufDynamicSidemenu.scrollToSelectedItem();
    }
  }

  changeMinimized() {
    this.minimized = !this.minimized;
    this.mode = this.getMode();
  }

  focusSideMenu() {
    const firtElem = this.sidenav._elementRef.nativeElement.querySelectorAll(
      'a'
    )[0];
    if (firtElem) {
      firtElem.focus();
    }
  }
  focusSideMenuButton() {
    this.document.getElementById('mon_main_menu_0').focus();
  }

  handleSideMenuButtonKeydown(event: KeyboardEvent) {
    switch (event.keyCode) {
      case TAB:
        if (!event.shiftKey && this.sidenav._opened) {
          // focus on first elemement when side menu is open and TAB key is pressed
          event.preventDefault();
          this.focusSideMenu();
        }
        break;
      default:
        break;
    }
  }

  handleSideMenuKeydown(event: KeyboardEvent) {
    switch (event.keyCode) {
      case event.shiftKey && TAB:
        // focus on side menu button when focus is on sidemenuitem and shift +tab is pressed
        if (this.document.activeElement.getAttribute('tabindex') === '0') {
          event.preventDefault();
          this.focusSideMenuButton();
        }
        break;
      case ESCAPE:
        this.focusSideMenuButton();
        break;
      default:
    }
  }

  getMode(): string {
    // set mode based on a breakpoint
    if (this._mediaObserver.isActive('lt-sm') && !this.minimized) {
      return 'push';
    } else {
      return 'side';
    }
  }

  themeRollerChange(cssVars) {
    this.cssVars = cssVars;
    Object.keys(this.cssVars).forEach((k) => {
      this.document.documentElement.style.setProperty(k, this.cssVars[k]);
    });
  }

  ngOnDestroy() {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
  }

  removeCssVarsProp() {
    Object.keys(this.cssVars).forEach((k) => {
      this.document.documentElement.style.removeProperty(k);
    });
  }

  OpenSiteNodeWindow(): void {
    this.selectSiteNodeWindow = this.dialog.open(IstSiteNodeComponent);
    this.selectSiteNodeWindow.afterClosed().subscribe(result => {
      console.log('result POPUP closed::'+result);
      this.siteId=this.globalsService.siteId;
      this.nodeName=this.globalsService.nodeName;
    });
  }

  onAutoRefreshChange() {
    this.autoRefreshService.autoRefresh = this.autoRefresh;

    if (this.autoRefreshService.autoRefresh) {
      this.autoRefreshService.updateAutoRefreshInterval();
    }
  }
  public printPageInfo(): void {
    window.print();
  }
  public openPageInfo(): void {
    let version = this.globalsService.configOptions['ist_version'];
    version = StringUtil.isNotEmpty(version) ? version : 'IST/Paymon Initial - 0.0.0';
    this.globalsService.showDialog(CommonConstants.INFORMATION, version , CommonConstants.ALERT_OK);
  }
}
