import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const conMonRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'Task',
      title: 'Task Commands',
    },
    children: [

      {
        path: '',
        redirectTo: 'PRTDTLS',
        pathMatch: 'full',
      },
      {
        path: 'PRTDTLS',
        redirectTo: 'PRTDTLS',
        pathMatch: 'full',
      },
      {
        path: 'PORTDASH',
        redirectTo: 'PORTDASH',
        pathMatch: 'full',
      },
      {
        path: 'DBCONNDTLS',
        redirectTo: 'DBCONNDTLS',
        pathMatch: 'full',
      },
      {
        path: 'PRTDTLS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'PORTDASH',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'DBCONNDTLS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      }
    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(conMonRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class ConMonRoutingModule {

  constructor(){
    console.log('Inside connection-monitoring-routing.module ');
  }
}
