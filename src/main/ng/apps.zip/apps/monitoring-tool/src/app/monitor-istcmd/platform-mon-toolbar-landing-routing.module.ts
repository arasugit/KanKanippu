import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./istcmd-landing/platform-mon-landing-module').then((m) => m.PlatformMonLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class PlatformMonToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside platform-monitoring-toolbar-routing.module ');
   }
 }
