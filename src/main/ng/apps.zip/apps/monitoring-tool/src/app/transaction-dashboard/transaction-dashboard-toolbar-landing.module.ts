import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { TransactionDashboardToolbarLandingRoutingModule } from './transaction-dashboard-toolbar-landing-routing.module';

@NgModule({
  imports: [
    CommonModule,
    TransactionDashboardToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})

export class TransactionDashboardToolBarLandingModule {}
