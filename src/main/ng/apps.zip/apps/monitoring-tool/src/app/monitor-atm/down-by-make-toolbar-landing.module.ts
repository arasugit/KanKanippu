import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { DownByMakeToolbarLandingRoutingModule } from './down-by-make-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    DownByMakeToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: []
})

export class DownByMakeToolBarLandingModule {}
