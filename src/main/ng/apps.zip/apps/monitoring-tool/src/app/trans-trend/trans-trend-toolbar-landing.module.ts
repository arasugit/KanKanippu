import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransTrendToolbarLandingRoutingModule } from './trans-trend-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    TransTrendToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class TransTrendToolBarLandingModule {}
