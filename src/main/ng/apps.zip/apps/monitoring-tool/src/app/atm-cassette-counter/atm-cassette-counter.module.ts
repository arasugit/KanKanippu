import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ParentCassetteCounterRoutingModule } from './atm-cassette-counter-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    ParentCassetteCounterRoutingModule,
    MonitorNavigationModule  
  ],
  
})
export class ParentCassetteCounterModule {}
