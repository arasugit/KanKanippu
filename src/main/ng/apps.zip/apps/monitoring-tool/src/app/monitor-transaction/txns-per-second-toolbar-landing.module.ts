import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TxnsPerSecondToolbarLandingRoutingModule } from './txns-per-second-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

/**
 * NgModule that includes all Material modules that are required to serve the demo-app.
 */
@NgModule({
  imports: [
    CommonModule,
    TxnsPerSecondToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class TxnsPerSecondToolBarLandingModule {}
