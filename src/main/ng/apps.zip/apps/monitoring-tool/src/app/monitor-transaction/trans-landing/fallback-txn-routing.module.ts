import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, FallbackTxnsComponent} from '@ist-custom-project/shell';

export const fallbackTxnRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Fallback Transactions Count',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNFBC_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNFBC_REQ',
        component: FallbackTxnsComponent,
        data: { module: 'TXNFBC_REQ' } 
      }
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(fallbackTxnRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class FallbackTxnsRoutingModule { 

  constructor(){
    console.log('Fallback Txns Routing Module ');
  }
}
