import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { IncidentDashboardToolbarLandingRoutingModule } from './incident-dashboard-toolbar-landing-routing.module';

@NgModule({
  imports: [
    CommonModule,
    IncidentDashboardToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})

export class IncidentDashboardToolBarLandingModule {}
