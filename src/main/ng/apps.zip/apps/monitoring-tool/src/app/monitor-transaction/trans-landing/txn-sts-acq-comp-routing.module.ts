import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,TransStatsAcqCompComponent} from '@ist-custom-project/shell';

export const txnstsCompRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Details',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNSTS_ACQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNSTS_ACQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNSTS_ACQ' } 
      },
      {
        path: 'HOURLY',
        //component: MonitorDynamicComponentDisplayComponent,
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'MONTHLY' } 
      }
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(txnstsCompRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsAcqCompRoutingModule { 

  constructor(){
    console.log(' Transaction stats Acq Routing Module ');
  }
}
