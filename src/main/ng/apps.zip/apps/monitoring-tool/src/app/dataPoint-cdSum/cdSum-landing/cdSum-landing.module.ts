import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, CdSumModule } from '@ist-custom-project/shell';
import { CdSumRoutingModule } from './cdSum-routing.module';

@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    CdSumRoutingModule,
    CdSumModule
  ],
  declarations: []
})
export class CdSumLandingModule {
   constructor(){
     console.log("Inside CdSumLandingModule page");
   }
}
