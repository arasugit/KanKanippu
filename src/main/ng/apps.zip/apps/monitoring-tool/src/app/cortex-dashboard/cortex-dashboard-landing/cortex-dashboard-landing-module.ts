import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, CortexDashboardModule } from '@ist-custom-project/shell';
import { CortexDashboardRoutingModule } from './cortex-dashboard-routing-module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    CortexDashboardRoutingModule,
    CortexDashboardModule
  ],
  declarations: []
})

export class CortexDashboardLandingModule {
   constructor(){
     console.log("Inside CortexDashboardLandingModule page");
   }
}
