import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, RejectedTxnsComponent} from '@ist-custom-project/shell';

export const rejectedTxnRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Rejected Transactions Count',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNSRJ_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNSRJ_REQ',
        component:RejectedTxnsComponent,
        data: { module: 'TXNSRJ_REQ' } 
      },
      {
        path: 'ACQUIRING',
        component: RejectedTxnsComponent,
        data: { module: 'ACQUIRING' } 
      },
      {
        path: 'ISSUING',
        component: RejectedTxnsComponent,
        data: { module: 'ISSUING' } 
      }  
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(rejectedTxnRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class RejectedTxnsRoutingModule { 

  constructor(){
    console.log('Rejected Txns Routing Module ');
  }
}
