import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, PosDashboardModule } from '@ist-custom-project/shell';
import { PosDashboardRoutingModule } from './pos-dashboard-routing-module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    PosDashboardRoutingModule,
    PosDashboardModule
  ],
  declarations: []
})

export class PosDashboardLandingModule {
   constructor(){
     console.log("Inside PosDashboardLandingModule page");
   }
}
