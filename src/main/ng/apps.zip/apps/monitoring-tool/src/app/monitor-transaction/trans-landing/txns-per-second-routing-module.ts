import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonLandingComponent,TxnsPerSecondComponent} from '@ist-custom-project/shell';

export const txnsPerSecondRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transactions Per Second',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNTPS_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNTPS_REQ',
        component: TxnsPerSecondComponent,
        data: { module: 'TXNTPS-DASH' }
      },
      {
        path: 'CURRENT-TPS',
        component: TxnsPerSecondComponent,
        data: { module: 'CURRENT-TPS' }
      },
      {
        path: 'AVERAGE-TPS',
        component: TxnsPerSecondComponent,
        data: { module: 'AVERAGE-TPS' }
      },
      {
        path: 'TODAY-TPS',
        component: TxnsPerSecondComponent,
        data: { module: 'TODAY-TPS' }
      }
    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(txnsPerSecondRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TxnsPerSecondRoutingModule {

  constructor(){
    console.log(' Transactions per second Routing Module ');
  }
}
