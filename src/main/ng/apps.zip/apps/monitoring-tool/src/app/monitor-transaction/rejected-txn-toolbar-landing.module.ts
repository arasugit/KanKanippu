import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RejectedTxnsToolbarLandingRoutingModule } from './rejected-txn-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    RejectedTxnsToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: []
})
export class RejectedTxnsToolBarLandingModule {}
