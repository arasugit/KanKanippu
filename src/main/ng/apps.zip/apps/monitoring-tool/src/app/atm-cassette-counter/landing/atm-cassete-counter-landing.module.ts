import { FlexLayoutModule } from '@angular/flex-layout';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CassetteCounterLandingRoutingModule } from './atm-cassette-landing-routing.module';
import { MonitorNavigationModule} from '@ist-custom-project/shell';
import { CassetteCounterHomeModule } from '@ist-custom-project/shell';


@NgModule({
  declarations: [ ],
  imports: [
    CommonModule,
    FlexLayoutModule,
    CassetteCounterLandingRoutingModule,
    MonitorNavigationModule,
    CassetteCounterHomeModule
  ], 
})
export class CasseteCounterLandingModule {
   constructor(){}    
}

