import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,MonAtmExtModule } from '@ist-custom-project/shell';
import { MonAtmExtRoutingModule } from './monAtmExt-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    MonAtmExtRoutingModule,
    MonAtmExtModule

  ],
  declarations: []
})
export class MonAtmExtLandingModule {
   constructor(){
     console.log("Inside MonAtmExtLandingModule page");
   }
}
