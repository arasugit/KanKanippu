import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const enCashRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'MGV',
      title: 'EnCash',
    },
    children: [
      {
        path: '',
        redirectTo: 'DPENCASH',
        pathMatch: 'full',
      },
      {
        path: 'DPENCASH',
        redirectTo: 'DPENCASH',
        pathMatch: 'full',
      },
      {
        path: 'DPENCASH',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'DPENCASH' }
      }
    ]
  }
];



@NgModule({
  imports: [
    RouterModule.forChild(enCashRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class EnCashRoutingModule {

  constructor(){
    console.log('Inside enCash-routing.module ');
  }
}
