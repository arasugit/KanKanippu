import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',   
    loadChildren: () =>import('./landing/atm-counter-landing.module').then((m) => m.ATMCounterLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class AtmCounterToolbarLandingRoutingModule {
  constructor(){ }
}
