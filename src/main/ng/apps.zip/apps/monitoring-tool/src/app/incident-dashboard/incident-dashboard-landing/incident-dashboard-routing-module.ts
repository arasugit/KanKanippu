import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

const incidentDashboardRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Incident Dashboard'
    },
    children: [
      {
        path: '',
        redirectTo: 'INCDASH',
        pathMatch: 'full',
      },
      {
        path: 'INCDASH',
        redirectTo: 'INCDASH',
        pathMatch: 'full',
      },
      {
        path: 'INCDASH',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'inc_dashboard' }
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(incidentDashboardRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class IncidentDashboardRoutingModule {
  constructor(){
    console.log('Inside IncidentDashboardRoutingModule');
  }
}
