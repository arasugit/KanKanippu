import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./monGlbVal-landing/monGlbVal-landing-module').then((m) => m.MonGlbValLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class MonGlbValToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside MonGlbValToolbarLandingRoutingModule page... ');
   }
 }
