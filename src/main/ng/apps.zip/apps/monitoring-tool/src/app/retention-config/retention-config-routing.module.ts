import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',redirectTo: '',pathMatch: 'full',
  },
  {
    path: '',loadChildren: () =>import('./landing/retention-config-landing.module').then((m) => m.RetentionConfigLandingModule)
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ParentRetentionConfigRoutingModule {
  constructor(){}
}
