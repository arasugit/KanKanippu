import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const platformMonRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'Task',
      title: 'Task Commands',
    },
    children: [
      {
        path: '',
        redirectTo: 'FISYUSAGE',
        pathMatch: 'full',
      },
      {
        path: 'FISYUSAGE',
        redirectTo: 'FISYUSAGE',
        pathMatch: 'full',
      },
      {
        path: 'SYCPUUSAGE',
        redirectTo: 'SYCPUUSAGE',
        pathMatch: 'full',
      },
      {
        path: 'SYCPUUSAGE2',
        redirectTo: 'SYCPUUSAGE2',
        pathMatch: 'full',
      },
      {
        path: 'IPCADTLS',
        redirectTo: 'IPCADTLS',
        pathMatch: 'full',
      },
      {
        path: 'PLTFDASH',
        redirectTo: 'PLTFDASH',
        pathMatch: 'full',
      },
      {
        path: 'FISYUSAGE',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'SYCPUUSAGE',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'SYCPUUSAGE2',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'IPCADTLS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
      {
        path: 'PLTFDASH',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'taskcmd' }
      },
    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(platformMonRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class PlatformMonRoutingModule {

  constructor(){
    console.log('Inside platform-monitoring-routing.module ');
  }
}
