import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransStatsIssCompModule } from '@ist-custom-project/shell';
import { TransStatsIssCompRoutingModule } from './txn-sts-iss-comp-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsIssCompRoutingModule,
    TransStatsIssCompModule

  ],
  declarations: []
})
export class TransStatsIssCompLandingModule {
   constructor(){}
}
