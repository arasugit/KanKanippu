import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransStatsLogsModule } from '@ist-custom-project/shell';
import { TransStatsLogsRoutingModule } from './txn-stats-logs-routing-module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsLogsRoutingModule,
    TransStatsLogsModule

  ],
  declarations: []
})
export class TransStatsLogsLandingModule {
   constructor(){}
}
