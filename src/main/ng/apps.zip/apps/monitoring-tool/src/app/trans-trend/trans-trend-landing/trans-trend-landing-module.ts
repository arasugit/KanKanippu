import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransTrendModule } from '@ist-custom-project/shell';
import { TransactionTrendRoutingModule } from './trans-trend-routing-module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransactionTrendRoutingModule,
    TransTrendModule

  ],
  declarations: []
})
export class TransactionTrendLandingModule {
   constructor(){}
}
