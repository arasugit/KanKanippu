import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,TransactionStatsListComponent} from '@ist-custom-project/shell';

export const transStatsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats - Acquirer',
    },
    children: [
      {
        path: '',
        redirectTo: 'TRANSSTATS',
        pathMatch: 'full',
      },
      {
        path: 'TRANSSTATS',
        component: TransactionStatsListComponent,
        data: { module: 'TRANSSTATS' } 
      },
      {
        path: 'HOURLY',
        //component: MonitorDynamicComponentDisplayComponent,
        component: TransactionStatsListComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: TransactionStatsListComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: TransactionStatsListComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: TransactionStatsListComponent,
        data: { module: 'MONTHLY' } 
      },
      {
        path: 'YEARLY',
        component: TransactionStatsListComponent,
        data: { module: 'YEARLY' } 
      }
      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsRoutingModule { 

  constructor(){
    console.log(' Transaction stats Routing Module ');
  }
}
