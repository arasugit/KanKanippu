import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, DownBySiteComponent} from '@ist-custom-project/shell';

export const downBySiteRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'ATM Down By Site',
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMDWS_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMDWS_REQ',
        component:DownBySiteComponent,
        data: { module: 'ATMDWS_REQ' } 
      }
    ]   
  },
];


@NgModule({
  imports: [
    RouterModule.forChild(downBySiteRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class DownBySiteRoutingModule { 

  constructor(){
    console.log('ATM down by site Routing Module');
  }
}
