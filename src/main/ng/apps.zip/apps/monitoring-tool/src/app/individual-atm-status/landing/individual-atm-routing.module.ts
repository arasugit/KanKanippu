import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonLandingComponent,MonitorDynamicComponentDisplayComponent} from '@ist-custom-project/shell';

const individualATMStatus: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Individual ATM Status',
    },
    children: [
      {
        path: '',
        redirectTo: 'INVATM_REQ',
        pathMatch: 'full',
      },
      {
        path: 'INVATM_REQ',
        redirectTo: 'INVATM_REQ',
        pathMatch: 'full',
      },
      {
        path: 'INVATM_REQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'individual_atm' } 
      }     
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(individualATMStatus)],
  exports: [RouterModule]
})
export class IndividualATMStatusRoutingModule { }
