import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { SuccessfulTxncpncpcToolbarLandingRoutingModule } from './success-txncpncpc-toolbar-landing-routing.module';

@NgModule({
  imports: [
    CommonModule,
    SuccessfulTxncpncpcToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: []
})
export class SuccessfulTxncpncpcToolBarLandingModule {}
