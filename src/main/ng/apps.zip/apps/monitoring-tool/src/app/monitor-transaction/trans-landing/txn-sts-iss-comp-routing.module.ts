import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

export const txnstsIssCompRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Details',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNSTS_ISS',
        pathMatch: 'full',
      },
      {
        path: 'TXNSTS_ISS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNSTS_ISS' } 
      },
      {
        path: 'HOURLY',
        //component: MonitorDynamicComponentDisplayComponent,
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'MONTHLY' } 
      }
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(txnstsIssCompRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsIssCompRoutingModule { 

  constructor(){
    console.log(' Transaction stats Iss Routing Module ');
  }
}
