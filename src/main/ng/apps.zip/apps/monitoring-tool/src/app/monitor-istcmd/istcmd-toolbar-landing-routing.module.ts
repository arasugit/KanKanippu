import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./istcmd-landing/istcmd-landing-module').then((m) => m.ISTCmdLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class ISTCmdToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside istcmd-routing.module ');
   }
 }
