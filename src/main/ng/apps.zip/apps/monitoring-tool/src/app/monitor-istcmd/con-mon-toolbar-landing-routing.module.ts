import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./istcmd-landing/con-mon-landing-module').then((m) => m.ConMonLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class ConMonToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside connection-monitoring-toolbar-routing.module ');
   }
 }
