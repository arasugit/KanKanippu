import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { TranlogLandingRoutingModule } from './tranlog-landing-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TranlogLandingRoutingModule


  ],
  declarations: []
})
export class TranlogLandingModule {
   constructor(){}
}
