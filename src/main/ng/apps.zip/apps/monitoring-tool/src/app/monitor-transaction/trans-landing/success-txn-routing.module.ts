import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, SuccessfulTxnsComponent} from '@ist-custom-project/shell';

export const successfulTxnRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Successful Transactions Count',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNSSC_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNSSC_REQ',
        component: SuccessfulTxnsComponent,
        data: { module: 'TXNSSC_REQ' } 
      },
      {
        path: 'ACQUIRING',
        component: SuccessfulTxnsComponent,
        data: { module: 'ACQUIRING' } 
      },
      {
        path: 'ISSUING',
        component: SuccessfulTxnsComponent,
        data: { module: 'ISSUING' } 
      }  
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(successfulTxnRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class SuccessfulTxnsRoutingModule { 

  constructor(){
    console.log('Successful Txns Routing Module ');
  }
}
