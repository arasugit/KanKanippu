import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,AtmCraModule } from '@ist-custom-project/shell';
import { AtmCraRoutingModule } from './atm-cra-routing-module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    AtmCraRoutingModule,
    AtmCraModule

  ],
  declarations: []
})
export class AtmCraLandingModule {
   constructor(){
     console.log("Inside AtmCraLandingModule page");
   }
}
