import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { UpTerminalsToolbarLandingRoutingModule } from './up-terminals-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    UpTerminalsToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: []
})

export class UpTerminalsToolBarLandingModule {}
