import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

const switchDashBoardRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'MGV',
      title: 'Switch DashBoard Value',
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMNTWRKDS',
        pathMatch: 'full',
      },
      {
        path: 'ATMNTWRKDS',
        redirectTo: 'ATMNTWRKDS',
        pathMatch: 'full',
      },
      {
        path: 'ATMNTWRKDS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'ATMNTWRKDS' }
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(switchDashBoardRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class SwitchDashBoardRoutingModule {
  constructor() {
    console.log('Inside switchDashBoard-routing.module ');
  }
}
