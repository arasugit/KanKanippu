import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonGlbValToolbarLandingRoutingModule } from './monGlbVal-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    MonGlbValToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class MonGlbValToolBarLandingModule {}
