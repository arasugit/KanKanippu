import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { DownByBranchToolbarLandingRoutingModule } from './down-by-branch-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    DownByBranchToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: []
})

export class DownByBranchToolBarLandingModule {}
