import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonLandingComponent,MonitorDynamicComponentDisplayComponent} from '@ist-custom-project/shell';

const cassetteCounterRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'ATM Cassette Counter',
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMCTE_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMCTE_REQ',
        redirectTo: 'ATMCTE_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMCTE_REQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'cassette_counter' } 
      }     
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(cassetteCounterRoutes)],
  exports: [RouterModule]
})
export class CassetteCounterLandingRoutingModule { }
