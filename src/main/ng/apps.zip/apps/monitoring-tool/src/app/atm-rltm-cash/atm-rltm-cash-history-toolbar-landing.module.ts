import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { AtmRltmCashHistoryaToolbarLandingRoutingModule } from './atm-rltm-cash-history-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    AtmRltmCashHistoryaToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class AtmRltmCashHistoryToolBarLandingModule {}
