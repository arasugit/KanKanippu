import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, UpTerminalsModule} from '@ist-custom-project/shell';
import { UpTerminalsRoutingModule } from './up-terminals-routing-module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    UpTerminalsRoutingModule,
    UpTerminalsModule

  ],
  declarations: []
})
export class UpTerminalsLandingModule {
   constructor(){}
}
