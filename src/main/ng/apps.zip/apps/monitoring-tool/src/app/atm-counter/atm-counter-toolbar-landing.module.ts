import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { AtmCounterToolbarLandingRoutingModule } from './atm-counter-toolbar-landing-routing.module';

@NgModule({
  imports: [
    CommonModule,
    AtmCounterToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: []
})
export class AtmCounterToolBarLandingModule {}
