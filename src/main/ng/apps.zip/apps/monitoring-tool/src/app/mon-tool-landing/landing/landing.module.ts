import { FlexLayoutModule } from '@angular/flex-layout';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LandingRoutingModule } from './landing-routing.module';
import { MonitorNavigationModule} from '@ist-custom-project/shell';
import { HomeModule} from '@ist-custom-project/shell';

@NgModule({
  declarations: [ ],
  imports: [
    CommonModule,
    FlexLayoutModule,
    LandingRoutingModule,
    MonitorNavigationModule,
    HomeModule
  ],
  providers: [],
  exports: []
})
export class LandingModule {
   constructor(){}
}

