import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, AtmTotalTxnsModule} from '@ist-custom-project/shell';
import { AtmTotalTxnsRoutingModule } from './atm-total-txn-routing.module';


@NgModule({
    imports:[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    AtmTotalTxnsRoutingModule,
    AtmTotalTxnsModule
  ],
  declarations: []
})
export class AtmTotalTxnsLandingModule {
   constructor(){}
}
