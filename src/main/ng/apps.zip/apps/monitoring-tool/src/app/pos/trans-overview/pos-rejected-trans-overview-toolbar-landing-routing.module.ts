import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./landing/pos-rejected-trans-overview-landing-module').then((m) => m.PosRejectedTransOverviewLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})

export class PosRejectedTransOverviewToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside PosRejectedTransOverviewToolbarLandingRoutingModule page... ');
   }
 }
