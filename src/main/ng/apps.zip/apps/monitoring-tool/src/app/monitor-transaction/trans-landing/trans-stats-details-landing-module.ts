import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransactionStatsDetailsModule } from '@ist-custom-project/shell';
import { TransStatsDetailsRoutingModule } from './trans-stats-details-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsDetailsRoutingModule,
    TransactionStatsDetailsModule

  ],
  declarations: []
})
export class TransStatsDetailsLandingModule {
   constructor(){}
}
