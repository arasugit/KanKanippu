import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TxnsPerSecondModule } from '@ist-custom-project/shell';
import { TxnsPerSecondRoutingModule } from './txns-per-second-routing-module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TxnsPerSecondRoutingModule,
    TxnsPerSecondModule

  ],
  declarations: []
})
export class TxnsPerSecondLandingModule {
   constructor(){}
}
