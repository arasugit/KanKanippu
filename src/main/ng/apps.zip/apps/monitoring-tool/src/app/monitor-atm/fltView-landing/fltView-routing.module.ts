import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const fltViewRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'Task',
      title: 'Task Commands',
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMFLTVIEW',
        pathMatch: 'full',
      },
      {
        path: 'ATMFLTVIEW',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'fltView' }
      },
      {
        path: 'ATMRTCASH',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'rltmCash' }
      }
    ]
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(fltViewRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class FltViewRoutingModule {

  constructor(){
    console.log('Inside istcmd-routing.module ');
  }
}
