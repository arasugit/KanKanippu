import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransStatsIssuerToolbarLandingRoutingListModule } from './trans-stats-issuer-toolbar-landing-routing-list.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

/**
 * NgModule that includes all Material modules that are required to serve the demo-app.
 */
@NgModule({
  imports: [
    CommonModule,
    TransStatsIssuerToolbarLandingRoutingListModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class TransStatsIssuerToolBarLandingListModule {}
