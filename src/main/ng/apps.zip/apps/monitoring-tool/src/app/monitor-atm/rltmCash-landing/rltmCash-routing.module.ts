import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const fltViewRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'Task',
      title: 'Task Commands',
    },
    children: [
      {
        path: '',
        redirectTo: '/ATMRTCASH/ATMRTCASH',
        pathMatch: 'full',
      },
      {
        path: 'ATMRTCASH',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'rltmCash' }
      },
      {
        path: 'ATMFLTVIEW',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'fltView' }
      }
    ]
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(fltViewRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class RltmCashRoutingModule {

  constructor(){
    console.log('Inside istcmd-routing.module ');
  }
}
