import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./atm-rltm-cash-landing/atm-rltm-cash-history-landing-module').then((m) => m.AtmRltmCashHistoryLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})

export class AtmRltmCashHistoryaToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside AtmRltmCashHistoryaToolbarLandingRoutingModule page... ');
   }
 }
