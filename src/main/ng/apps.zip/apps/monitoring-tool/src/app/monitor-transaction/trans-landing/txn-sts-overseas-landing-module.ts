import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransStatsOverseasModule } from '@ist-custom-project/shell';
import { TransStatsOverseasRoutingModule } from './txn-sts-overseas-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsOverseasRoutingModule,
    TransStatsOverseasModule

  ],
  declarations: []
})
export class TransStatsOverseasLandingModule {
   constructor(){}
}
