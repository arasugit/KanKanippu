import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./rltmCash-landing/rltmCash-landing-module').then((m) => m.RltmCashLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class RltmCashToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside Real Time cash routing module ');
   }
 }
