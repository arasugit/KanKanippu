import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConfigLoaderResolver } from '@ist-custom-project/shell';
import { AuthService } from '@ist-custom-project/shell';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'monitor',
    pathMatch: 'full'
  },
  {
    path:'',
    children: [
      {
        path: 'monitor',
        canActivate:[AuthService],
        loadChildren: () => import('./mon-tool-landing/mon-tool-landing.module').then(m => m.MonToolLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: 'monitor/INVATM_REQ',
        canActivate:[AuthService],
        loadChildren: () => import('./individual-atm-status/individual-atm-status.module').then(m => m.ParentIndividualATMLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: 'monitor/ATMCTE_REQ',
        canActivate:[AuthService],
        loadChildren: () => import('./atm-cassette-counter/atm-cassette-counter.module').then(m => m.ParentCassetteCounterModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: 'monitor/ATMTOT_REQ',
        canActivate:[AuthService],
        loadChildren: () => import('./atm-totals/atm-totals.module').then(m => m.ParentATMTotalsModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/TSKCMD",
        loadChildren : () => import('./monitor-istcmd/istcmd-toolbar-landing.module').then(m => m.ISTCmdToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/PRTDTLS",
        loadChildren : () => import('./monitor-istcmd/con-mon-toolbar-landing.module').then(m => m.ConMonToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/FISYUSAGE",
        loadChildren : () => import('./monitor-istcmd/platform-mon-toolbar-landing.module').then(m => m.PlatformMonToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TRANSSTATS",
       loadChildren : () => import('./monitor-transaction/trans-stats-toolbar-landing-routing.module').then(m => m.TransStatsToolbarLandingRoutingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TRANS_STATS_ISSUER",
       loadChildren : () => import('./monitor-transaction/trans-stats-issuer-toolbar-landing-routing.module').then(m => m.TransStatsIssuerToolbarLandingRoutingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TXNSTS_REQ",
       loadChildren : () => import('./monitor-transaction/trans-stats-details-toolbar-landing-routing.module').then(m => m.TransStatsDetailsToolbarLandingRoutingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TXNTC_REQ",
       loadChildren : () => import('./monitor-transaction/terminal-top-comp-toolbar-landing-routing.module').then(m => m.TerminalTopCompToolbarLandingRoutingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TXNTL_REQ",
       loadChildren : () => import('./monitor-transaction/terminal-least-comp-toolbar-landing-routing.module').then(m => m.TerminalLeastCompToolbarLandingRoutingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      } ,
      {
        path: "monitor/TXNISS_REQ",
        loadChildren : () => import('./monitor-transaction/trans-stats-issuer-toolbar-landing-routing-list.module').then(m => m.TransStatsIssuerToolbarLandingRoutingListModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TXNSTS_ACQ",
        loadChildren : () => import('./monitor-transaction/txn-sts-acq-comp-toolbar-landing-routing.module').then(m => m.TransStatsAcqCompToolbarLandingRoutingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TXNSTS_ISS",
        loadChildren : () => import('./monitor-transaction/txn-sts-iss-comp-toolbar-landing-routing.module').then(m => m.TransStatsIssCompToolbarLandingRoutingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TXNRJACQ",
        loadChildren : () => import('./monitor-transaction/trans-stats-acq-top5-toolbar-landing.module').then(m => m.TransAcqRejectionToolBarLandingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TXNPROCCD",
        loadChildren : () => import('./monitor-transaction/trans-stats-proc-code-toolbar-landing.module').then(m => m.TransStatsProcCodeToolBarLandingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TXNATMPOS",
        loadChildren : () => import('./monitor-transaction/trans-stats-atm-pos-toolbar-landing.module').then(m => m.TransStatsAtmPosToolBarLandingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      } ,
      {
        path: "monitor/TXNSTSOS",
        loadChildren : () => import('./monitor-transaction/txn-sts-overseas-toolbar-landing.module').then(m => m.TransStatsOverseasToolBarLandingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TXNTERC",
        loadChildren : () => import('./monitor-transaction/txn-sts-terminal-toolbar-landing.module').then(m => m.TransStatsTerminalToolBarLandingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      } ,
      {
        path: "monitor/TXNHVOL",
        loadChildren : () => import('./monitor-transaction/txn-sts-high-vol-toolbar-landing.module').then(m => m.TransStatsHighVolToolBarLandingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/TXNSTP_REQ",
        loadChildren : () => import('./monitor-transaction/txnstats-toolbar-landing.module').then(m => m.TxnStatsToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/TXNSHT_REQ",
        loadChildren : () => import('./monitor-transaction/host-txnstats-toolbar-landing.module').then(m => m.HostTxnStatsToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/TXNTPS_REQ",
        loadChildren : () => import('./monitor-transaction/txns-per-second-toolbar-landing.module').then(m => m.TxnsPerSecondToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/TXNSRJ_REQ",
        loadChildren : () => import('./monitor-transaction/rejected-txn-toolbar-landing.module').then(m => m.RejectedTxnsToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/TXNSSC_REQ",
        loadChildren : () => import('./monitor-transaction/success-txn-toolbar-landing.module').then(m => m.SuccessfulTxnsToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }

      },
      {
        "path": "monitor/CPNCPC_REQ",
        loadChildren : () => import('./monitor-transaction/success-txncpncpc-toolbar-landing.module').then(m => m.SuccessfulTxncpncpcToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }

      },
      {
        "path": "monitor/TXNFBC_REQ",
        loadChildren : () => import('./monitor-transaction/fallback-txn-toolbar-landing.module').then(m => m.FallbackTxnsToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/ATMTOTHIST",
        loadChildren : () => import('./monitor-transaction/atm-total-txn-toolbar-landing.module').then(m => m.AtmTotalTxnsToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/MONATMCOUN",
        loadChildren : () => import('./atm-counter/atm-counter-toolbar-landing.module').then(m => m.AtmCounterToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/INCDASH",
        loadChildren : () => import('./incident-dashboard/incident-dashboard-toolbar-landing.module').then(m => m.IncidentDashboardToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/INCLIST",
        loadChildren : () => import('./incident-management-landing/incident-management-landing.module').then(m => m.IncListToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/INCALERT",
        loadChildren : () => import('./incident-management-landing/incident-management-landing.module').then(m => m.IncListToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/INCUPDATE",
        loadChildren : () => import('./incident-management-landing/incident-management-landing.module').then(m => m.IncListToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/ATMFLTVIEW",
        loadChildren : () => import('./monitor-atm/fltView-toolbar-landing.module').then(m => m.FltViewToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/ATMRTCASH",
        loadChildren : () => import('./monitor-atm/rltmCash-landing/rltmCash-landing-module').then(m => m.RltmCashLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/ATMRTCASHH",
        loadChildren : () => import('./atm-rltm-cash/atm-rltm-cash-history-toolbar-landing.module').then(m => m.AtmRltmCashHistoryToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/ATMDWM_REQ",
        loadChildren : () => import('./monitor-atm/down-by-make-toolbar-landing.module').then(m => m.DownByMakeToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/ATMDWB_REQ",
        loadChildren : () => import('./monitor-atm/down-by-branch-toolbar-landing.module').then(m => m.DownByBranchToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/ATMDWS_REQ",
        loadChildren : () => import('./monitor-atm/down-by-site-toolbar-landing.module').then(m => m.DownBySiteToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/ATMUPT_REQ",
        loadChildren : () => import('./monitor-atm/up-terminals-toolbar-landing.module').then(m => m.UpTerminalsToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/MONGLBVAL",
        loadChildren : () => import('./mon-glbVal/monGlbVal-toolbar-landing.module').then(m => m.MonGlbValToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/MONATMEXT",
        loadChildren : () => import('./mon-atmExt/monAtmExt-toolbar-landing.module').then(m => m.MonAtmExtToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/ATMCRA_REQ",
        loadChildren : () => import('./atm-cra/atm-cra-toolbar-landing.module').then(m => m.AtmCraToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/DATARTCONF",
        loadChildren : () => import('./retention-config/retention-config-routing.module').then(m => m.ParentRetentionConfigRoutingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        path: "monitor/TPSVSMEM",
        loadChildren : () => import('./tps-vs-memory/tps-vs-mem-toolbar-landing.module').then(m => m.TpsVsMemoryToolBarLandingModule),
          resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/TXNSTSLOG",
        loadChildren : () => import('./txn-stats-logs/txn-stats-logs-toolbar-landing.module').then(m => m.TransStatsLogsToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/TXNTYPEREQ",
        loadChildren : () => import('./monitor-transaction/txnstats-type-toolbar-landing.module').then(m => m.TxnStatsTypeToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/ATMNTWRKDS",
        loadChildren : () => import('./switch-DashBoard/switchDashBoard-toolbar-landing.module').then(m => m.SwitchDashBoardToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/POSTERDETA",
        loadChildren : () => import('./pos/terminal-details/pos-details-toolbar-landing.module').then(m => m.PosDetailsToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/POSMERCHNT",
        loadChildren : () => import('./pos/merchant-details/pos-merch.module').then(m => m.ParentPOSMerchantModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
	    {
        "path": "monitor/POSDASH",
        loadChildren : () => import('./pos/dashboard/pos-dashboard-toolbar-landing.module').then(m => m.PosDashboardToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/POSTRANSVW",
        loadChildren : () => import('./pos/trans-overview/pos-sales-trans-overview-toolbar-landing.module').then(m => m.PosTransOverviewToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/POSTRANCVW",
        loadChildren : () => import('./pos/trans-overview/pos-chargeback-trans-overview-toolbar-landing.module').then(m => m.PosChargebackTransOverviewToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/POSTRANFVW",
        loadChildren : () => import('./pos/trans-overview/pos-fraudulent-trans-overview-toolbar-landing.module').then(m => m.PosFraudulentTransOverviewToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/POSTRANRVW",
        loadChildren : () => import('./pos/trans-overview/pos-rejected-trans-overview-toolbar-landing.module').then(m => m.PosRejectedTransOverviewToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/DPENCASH",
        loadChildren : () => import('./dataPoint-enCash/enCash-landing.module').then(m => m.EnCashLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/CTXDASH",
        loadChildren : () => import('./cortex-dashboard/cortex-dashboard-toolbar-landing.module').then(m => m.CortexDashboardToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/TXNTREND",
        loadChildren : () => import('./trans-trend/trans-trend-toolbar-landing.module').then(m => m.TransTrendToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/POSMAKE",
        loadChildren : () => import('./pos/makewise-trans/pos-make-toolbar-landing.module').then(m => m.PosMakeTxnToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/TXNDASH",
        loadChildren : () => import('./transaction-dashboard/transaction-dashboard-toolbar-landing.module').then(m => m.TransactionDashboardToolBarLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/DPDBSUM",
        loadChildren : () => import('./dataPoint -dbSum/dbSum-landing.module').then(m => m.DbSumLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      },
      {
        "path": "monitor/DPCDSUM",
        loadChildren : () => import('./dataPoint-cdSum/cdSum-landing.module').then(m => m.CdSumLandingModule),
        resolve: { configLoaded: ConfigLoaderResolver }
      }
    ]
  },
];


@NgModule({
  imports: [
    RouterModule.forRoot(routes, { enableTracing: true }),
  ],
  providers: [ConfigLoaderResolver],
  exports: [RouterModule],
})
export class AppRoutingModule {}
