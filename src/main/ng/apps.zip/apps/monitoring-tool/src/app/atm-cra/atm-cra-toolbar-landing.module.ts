import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { AtmCraToolbarLandingRoutingModule } from './atm-cra-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    AtmCraToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class AtmCraToolBarLandingModule {}
