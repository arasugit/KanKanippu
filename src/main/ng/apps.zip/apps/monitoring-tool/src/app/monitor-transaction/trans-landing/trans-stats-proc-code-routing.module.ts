import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,TransStatsProcCodeComponent} from '@ist-custom-project/shell';

export const transStatsProcCodeRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Details',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNPROCCD',
        pathMatch: 'full',
      },
      {
        path: 'TXNPROCCD',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNPROCCD' } 
      }
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsProcCodeRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsProcCodeRoutingModule { 

  constructor(){
    console.log(' Transaction stats Details Routing Module ');
  }
}
