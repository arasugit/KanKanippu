import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

const posMakeTxnRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'POS Makewise Transactions'
    },
    children: [
      {
        path: '',
        redirectTo: 'POSMAKE',
        pathMatch: 'full',
      },
      {
        path: 'POSMAKE',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'POSMAKE' } 
      },
      {
        path: 'HOURLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'MONTHLY' } 
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(posMakeTxnRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class PosMakeTxnRoutingModule {
  constructor(){
    console.log('Inside PosMakeTxnRoutingModule');
  }
}
