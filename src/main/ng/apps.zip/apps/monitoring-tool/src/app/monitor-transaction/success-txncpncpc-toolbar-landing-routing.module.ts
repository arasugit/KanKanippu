import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./trans-landing/success-txncpncpc-landing.module').then((m) => m.SuccessfulTxncpncpcsLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class SuccessfulTxncpncpcToolbarLandingRoutingModule {
  constructor(){ }
}
