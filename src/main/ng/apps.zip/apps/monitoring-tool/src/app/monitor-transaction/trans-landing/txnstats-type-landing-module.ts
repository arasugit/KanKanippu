import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, TxnStatsTypeModule} from '@ist-custom-project/shell';
import { TxnStatsTypeRoutingModule } from './txnstats-type-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TxnStatsTypeRoutingModule,
    TxnStatsTypeModule

  ],
  declarations: []
})
export class TxnStatsTypeLandingModule {
   constructor(){}
}
