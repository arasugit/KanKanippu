import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, DownByBranchComponent} from '@ist-custom-project/shell';

export const downByBranchRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'ATM Down By Branch',
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMDWB_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMDWB_REQ',
        component:DownByBranchComponent,
        data: { module: 'ATMDWB_REQ' } 
      }
    ]   
  },
];


@NgModule({
  imports: [
    RouterModule.forChild(downByBranchRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class DownByBranchRoutingModule { 

  constructor(){
    console.log('ATM down by branch Routing Module');
  }
}
