import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TerminalTopCompModule } from '@ist-custom-project/shell';
import { TerminalTopCompRoutingModule } from './terminal-top-comp-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TerminalTopCompRoutingModule,
    TerminalTopCompModule

  ],
  declarations: []
})
export class TerminalTopCompLandingModule {
   constructor(){}
}
