import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransStatsLogsToolbarLandingRoutingModule } from './txn-stats-logs-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    TransStatsLogsToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class TransStatsLogsToolBarLandingModule {}
