import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./pos-dashboard-landing/pos-dashboard-landing-module').then((m) => m.PosDashboardLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})

export class PosDashboardToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside PosDashboardToolbarLandingRoutingModule page... ');
   }
 }
