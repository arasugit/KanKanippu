import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./cdSum-landing/cdSum-landing.module').then((m) => m.CdSumLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class CdSumLandingRoutingModule {
  constructor(){
    console.log('Inside CdSumLandingRoutingModuleLandingRoutingModule page... ');
   }
 }
