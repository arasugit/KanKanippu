import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ParentRetentionConfigRoutingModule } from './retention-config-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    ParentRetentionConfigRoutingModule,
    MonitorNavigationModule
  ],

})
export class ParentRetentionConfigLandingModule {}
