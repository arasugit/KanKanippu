import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonAtmExtToolbarLandingRoutingModule } from './monAtmExt-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    MonAtmExtToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class MonAtmExtToolBarLandingModule {}
