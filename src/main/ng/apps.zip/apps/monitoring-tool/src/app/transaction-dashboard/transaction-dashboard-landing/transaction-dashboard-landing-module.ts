import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, TransactionDashboardModule } from '@ist-custom-project/shell';
import { TransactionDashboardRoutingModule } from './transaction-dashboard-routing-module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransactionDashboardRoutingModule,
    TransactionDashboardModule
  ],
  declarations: []
})

export class TransactionDashboardLandingModule {
   constructor(){
     console.log("Inside TransactionDashboardLandingModule page");
   }
}
