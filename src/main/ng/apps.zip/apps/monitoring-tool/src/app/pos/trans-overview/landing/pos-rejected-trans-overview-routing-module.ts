import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

const tranType = 'Rejection';
const posRejectedTransOverviewRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'POS Trans Overview'
    },
    children: [
      {
        path: '',
        redirectTo: 'POSTRANVW',
        pathMatch: 'full',
      },
      {
        path: 'POSTRANVW',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'POSTRANVW' }
      },
      {
        path: 'HOURLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { tranType: tranType, module: 'HOURLY' }
      },
      {
        path: 'DAILY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { tranType: tranType, module: 'DAILY' }
      },
      {
        path: 'YESTERDAY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { tranType: tranType, module: 'YESTERDAY' }
      },
      {
        path: 'WEEKLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { tranType: tranType, module: 'WEEKLY' }
      },
      {
        path: 'MONTHLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { tranType: tranType, module: 'MONTHLY' }
      },
      {
        path: 'QUARTELY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { tranType: tranType, module: 'QUARTELY' }
      },
      {
        path: 'CUSTOM',
        component: MonitorDynamicComponentDisplayComponent,
        data: { tranType: tranType, module: 'CUSTOM' }
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(posRejectedTransOverviewRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class PosRejectedTransOverviewRoutingModule {
  constructor(){
    console.log('Inside PosRejectedTransOverviewRoutingModule');
  }
}
