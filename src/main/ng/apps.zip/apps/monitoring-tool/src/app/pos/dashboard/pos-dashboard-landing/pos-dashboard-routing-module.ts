import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

const posDashboardRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'POS Dashboard'
    },
    children: [
      {
        path: '',
        redirectTo: 'POSDASH',
        pathMatch: 'full',
      },
      {
        path: 'POSDASH',
        redirectTo: 'POSDASH',
        pathMatch: 'full',
      },
      {
        path: 'POSDASH',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'pos_dash' }
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(posDashboardRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class PosDashboardRoutingModule {
  constructor(){
    console.log('Inside PosDashboardRoutingModule');
  }
}
