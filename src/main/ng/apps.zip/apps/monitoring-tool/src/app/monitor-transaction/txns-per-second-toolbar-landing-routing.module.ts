import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',   
    loadChildren: () =>import('./trans-landing/txns-per-second-landing-module').then((m) => m.TxnsPerSecondLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class TxnsPerSecondToolbarLandingRoutingModule {
  constructor(){ }
 }
