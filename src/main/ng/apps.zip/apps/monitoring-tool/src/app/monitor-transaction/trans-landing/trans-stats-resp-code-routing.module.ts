import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,TransactionStatsRespCodeComponent} from '@ist-custom-project/shell';

export const transStatsRespCodeRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Details',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNSTS_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNSTS_REQ',
        component: TransactionStatsRespCodeComponent,
        data: { module: 'TXNSTS_REQ' } 
      },
      {
        path: 'HOURLY',
        //component: MonitorDynamicComponentDisplayComponent,
        component: TransactionStatsRespCodeComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: TransactionStatsRespCodeComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: TransactionStatsRespCodeComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: TransactionStatsRespCodeComponent,
        data: { module: 'MONTHLY' } 
      },
      {
        path: 'YEARLY',
        component: TransactionStatsRespCodeComponent,
        data: { module: 'YEARLY' } 
      }
      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsRespCodeRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsRespCodeRoutingModule { 

  constructor(){
    console.log(' Transaction stats Resp Code Routing Module ');
  }
}
