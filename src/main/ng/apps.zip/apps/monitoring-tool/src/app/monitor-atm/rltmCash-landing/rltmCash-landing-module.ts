import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,  AtmDataSourceModule} from '@ist-custom-project/shell';
import { RltmCashRoutingModule } from './rltmCash-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    RltmCashRoutingModule,
    AtmDataSourceModule

  ],
  declarations: []
})
export class RltmCashLandingModule {
   constructor(){
     console.log("Inside rltCash-landing-module page");
   }
}
