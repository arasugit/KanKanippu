import { Injectable } from '@angular/core';
import { BehaviorSubject, interval } from 'rxjs';
import { switchMap, tap } from 'rxjs/operators'
import { MatSnackBar } from '@angular/material/snack-bar';
import { GlobalsService } from '@ist-custom-project/shell';
import { DatePipe } from '@angular/common';
export interface Notification {
  id: any;
  type: string;
  message: string;
  logDate: any
  read: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  clearAllLocalIds: any;
  markAsReadLocalIds: any[];
  audioContext: AudioContext;
  currentuserId: string;
  formatDate = new DatePipe('en_US');
  constructor(private snackBar: MatSnackBar, private globals: GlobalsService) {
    this.audioContext = new AudioContext();
  }
  private notificationsSubject = new BehaviorSubject<Notification[]>([]);
  notifications$ = this.notificationsSubject.asObservable();
  private notificationId = 0;
  markedAsReadIds: number[] = [];
  clearNotificationIds: number[] = [];
  fetchNotifications() {
    const newNotification: Notification = {
      id: ++this.notificationId,
      message: `New Notification at ${new Date().toLocaleTimeString()}`,
      type: 'info',
      logDate: 'any',
      read: false
    };
    const updatedNotifications = [...this.notificationsSubject.value, newNotification];
    this.notificationsSubject.next(updatedNotifications);

    // Show toast notification
    this.showNotificationToast(newNotification.message);

    // Play beep sound
    this.playNotificationSound();
  }
  // Show toast notification using MatSnackBar
  showNotificationToast(message: string) {
    this.snackBar.open(message, 'Close', {
      duration: 5000, // Toast will disappear after 5 seconds
      verticalPosition: 'bottom',
      horizontalPosition: 'right',
      panelClass: ['custom-toast']
    });
  }

  // Play beep sound using Audio API
  playNotificationSound() {
    const oscillator = this.audioContext.createOscillator();
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(200, this.audioContext.currentTime);
    oscillator.connect(this.audioContext.destination);
    oscillator.start();
    setTimeout(() => {
      oscillator.stop();
    }, 50)
  }
  addNotification(id: any, type: string, message: string, logDate: any, read: any) {
    const currentNotifications = this.notificationsSubject.getValue();
    const newNotification: Notification = {
      id: id,
      type: type.toLocaleLowerCase(),
      message: message,
      logDate: logDate,
      read: read
    };
    
    this.showNotificationToast('New Notification Incoming !!!');
    this.notificationsSubject.next([...currentNotifications, newNotification]);
  }

  markAsRead(id: number) {
    this.currentuserId = this.globals.userContext.userID;
    const updatedNotifications = this.notificationsSubject.getValue().map(notification =>
      notification.id === id ? { ...notification, read: true } : notification
    );

    this.markAsReadLocalIds = JSON.parse(localStorage.getItem(`markAsReadIds` + this.currentuserId) as any);
    if (this.markAsReadLocalIds === null) {
      this.markAsReadLocalIds = [];
    }
    if (!this.markAsReadLocalIds.includes(id)) {
      this.markAsReadLocalIds.push(id);
      this.saveMarkAsReadListToLocalStorage();
    }
    this.notificationsSubject.next(updatedNotifications);
  }
  saveMarkAsReadListToLocalStorage() {
    localStorage.setItem(`markAsReadIds` + this.currentuserId, JSON.stringify(this.markAsReadLocalIds));
  }
  getUnreadCount() {
    return this.notificationsSubject.getValue().filter(n => !n.read).length;
  }

  clearNotifications(allIds) {
    this.currentuserId = this.globals.userContext.userID;
    this.clearNotificationIds = allIds;
    localStorage.setItem('clearNotificationIds' + this.currentuserId, JSON.stringify(allIds));
    this.notificationsSubject.next([]);
  }
  emptyNotifications() {
    this.notificationsSubject.next([]);
  }

}
