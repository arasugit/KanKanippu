import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, RetentionConfigModule} from '@ist-custom-project/shell';
import { RetentionConfigRoutingModule } from './retention-config-routing.module';


@NgModule({
  imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    RetentionConfigRoutingModule,
    RetentionConfigModule
  ],
  declarations: []
})
export class RetentionConfigLandingModule {
   constructor(){}
}

