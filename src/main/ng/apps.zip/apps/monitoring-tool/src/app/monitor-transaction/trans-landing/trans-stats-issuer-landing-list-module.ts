import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransactionStatsIssuerDetailsModule } from '@ist-custom-project/shell';
import { TransStatsIssuerRoutingListModule } from './trans-stats-issuer-routing-list.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsIssuerRoutingListModule,
    TransactionStatsIssuerDetailsModule

  ],
  declarations: []
})
export class TransStatsIssuerLandingListModule {
   constructor(){}
}
