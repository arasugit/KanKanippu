import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, TxnStatsComponent} from '@ist-custom-project/shell';

export const txnStatsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'Task',
      title: 'Transaction Statistics',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNSTP_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNSTP_REQ',
        component:TxnStatsComponent,
        data: { module: 'TOP' } 
      },
      {
        path: 'BOTTOM',
        component: TxnStatsComponent,
        data: { module: 'BOTTOM' } 
      } 
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(txnStatsRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TxnStatsRoutingModule { 

  constructor(){
    console.log('TxnStats Routing Module ');
  }
}
