import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransAcqRejectionModule } from '@ist-custom-project/shell';
import { TransAcqRejectionRoutingModule } from './trans-stats-acq-top5-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransAcqRejectionRoutingModule,
    TransAcqRejectionModule

  ],
  declarations: []
})
export class TransAcqRejectionLandingModule {
   constructor(){}
}
