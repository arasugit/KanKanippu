import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RejectedTxnsToolbarLandingRoutingModule } from './rejected-txn-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { FallbackTxnsToolbarLandingRoutingModule } from './fallback-txn-toolbar-landing-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FallbackTxnsToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: []
})
export class FallbackTxnsToolBarLandingModule {}
