import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransAcqRejectionToolbarLandingRoutingModule } from './trans-stats-acq-top5-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

/**
 * NgModule that includes all Material modules that are required to serve the demo-app.
 */
@NgModule({
  imports: [
    CommonModule,
    TransAcqRejectionToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class TransAcqRejectionToolBarLandingModule {}
