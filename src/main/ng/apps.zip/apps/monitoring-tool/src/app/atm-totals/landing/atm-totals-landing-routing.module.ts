import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonLandingComponent,MonitorDynamicComponentDisplayComponent} from '@ist-custom-project/shell';


const atmTotalsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'ATM Totals'
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMTOT_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMTOT_REQ',
        redirectTo: 'ATMTOT_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMTOT_REQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'atm_totals' } 
      }     
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(atmTotalsRoutes)],
  exports: [RouterModule]
})
export class ATMTotalsLandingRoutingModule { }
