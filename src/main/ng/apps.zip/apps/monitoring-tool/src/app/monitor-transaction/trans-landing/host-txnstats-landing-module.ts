import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, HostTxnStatsModule} from '@ist-custom-project/shell';
import { HostTxnStatsRoutingModule } from './host-txnstats-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    HostTxnStatsRoutingModule,
    HostTxnStatsModule
  ],
  declarations: []
})
export class HostTxnStatsLandingModule {
   constructor(){}
}
