import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./enCash-landing/enCash-landing-module').then((m) => m.EnCashLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class EnCashLandingRoutingModule {
  constructor(){
    console.log('Inside EnCashLandingRoutingModuleLandingRoutingModule page... ');
   }
 }
