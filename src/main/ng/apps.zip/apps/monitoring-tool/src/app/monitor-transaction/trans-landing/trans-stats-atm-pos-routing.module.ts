import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

export const transStatsAtmPosRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats ATM POS',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNATMPOS',
        pathMatch: 'full',
      },
      {
        path: 'TXNATMPOS',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNATMPOS' } 
      },
      {
        path: 'TXN-POS-ACQ',
        //component: MonitorDynamicComponentDisplayComponent,
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNPOSACQ' } 
      },
      {
        path: 'TXN-ATM-ISSUER',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNATMISSUER' } 
      },
      {
        path: 'TXN-POS-ISSUER',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNPOSISSUER' } 
      }      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsAtmPosRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsAtmPosRoutingModule { 

  constructor(){
    console.log(' Transaction stats ATM POS Routing Module ');
  }
}
