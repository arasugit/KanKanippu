import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ISTCmdToolbarLandingRoutingModule } from './istcmd-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    ISTCmdToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class ISTCmdToolBarLandingModule {}
