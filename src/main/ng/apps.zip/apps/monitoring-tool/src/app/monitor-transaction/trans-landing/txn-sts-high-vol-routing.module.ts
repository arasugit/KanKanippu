import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

export const transStatsHighVolRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats High Volume',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNHVOL',
        pathMatch: 'full',
      },
      {
        path: 'TXNHVOL',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNHVOL' } 
      }
      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsHighVolRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsHighVolRoutingModule { 

  constructor(){
    console.log(' Transaction stats High Volumn Routing Module ');
  }
}
