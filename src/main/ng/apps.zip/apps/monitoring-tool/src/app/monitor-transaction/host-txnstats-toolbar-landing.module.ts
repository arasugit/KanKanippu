import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { HostTxnStatsToolbarLandingRoutingModule } from './host-txnstats-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    HostTxnStatsToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: []
})
export class HostTxnStatsToolBarLandingModule {}
