import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./incident-dashboard-landing/incident-dashboard-landing-module').then((m) => m.IncidentDashboardLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})

export class IncidentDashboardToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside IncidentDashboardToolbarLandingRoutingModule page... ');
   }
 }
