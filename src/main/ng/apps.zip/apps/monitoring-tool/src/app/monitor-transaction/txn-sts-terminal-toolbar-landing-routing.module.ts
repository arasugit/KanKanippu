import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',   
    loadChildren: () =>import('./trans-landing/txn-sts-terminal-landing-module').then((m) => m.TransStatsTerminalLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class TransStatsTerminalToolbarLandingRoutingModule {
  constructor(){ }
 }
