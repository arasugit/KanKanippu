import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent, HostTxnStatsComponent} from '@ist-custom-project/shell';

export const hostTxnStatsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Host Transaction Statistics',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNSHT_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNSHT_REQ',
        component:MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNSHT_REQ' } 
      },
      {
        path: 'HOURLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'MONTHLY' } 
      }
    ]   
  },
];


@NgModule({
  imports: [
    RouterModule.forChild(hostTxnStatsRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class HostTxnStatsRoutingModule { 

  constructor(){
    console.log(' HostTxnStats Routing Module ');
  }
}
