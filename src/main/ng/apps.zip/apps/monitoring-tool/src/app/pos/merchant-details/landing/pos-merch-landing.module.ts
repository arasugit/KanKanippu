import { FlexLayoutModule } from '@angular/flex-layout';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { POSMerchantLandingRoutingModule } from './pos-merch-landing-routing.module';
import { MonitorNavigationModule} from '@ist-custom-project/shell';
import { POSMerchantHomeModule } from '@ist-custom-project/shell';


@NgModule({
  declarations: [ ],
  imports: [
    CommonModule,
    FlexLayoutModule,
    POSMerchantLandingRoutingModule,
    MonitorNavigationModule,
    POSMerchantHomeModule
  ], 
})
export class POSMerchantLandingModule {
   constructor(){}    
}

