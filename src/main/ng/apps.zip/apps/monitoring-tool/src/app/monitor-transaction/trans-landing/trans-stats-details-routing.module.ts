import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

export const transStatsDetailsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Details',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNSTS_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNSTS_REQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNSTS_REQ' } 
      },
      {
        path: 'HOURLY',
        component: MonitorDynamicComponentDisplayComponent,
        //component: TransactionStatsDetailsComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'MONTHLY' } 
      }
      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transStatsDetailsRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransStatsDetailsRoutingModule { 

  constructor(){
    console.log(' Transaction stats Details Routing Module ');
  }
}
