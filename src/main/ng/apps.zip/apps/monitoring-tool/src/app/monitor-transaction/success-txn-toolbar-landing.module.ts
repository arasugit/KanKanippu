import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { SuccessfulTxnsToolbarLandingRoutingModule } from './success-txn-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    SuccessfulTxnsToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: []
})
export class SuccessfulTxnsToolBarLandingModule {}
