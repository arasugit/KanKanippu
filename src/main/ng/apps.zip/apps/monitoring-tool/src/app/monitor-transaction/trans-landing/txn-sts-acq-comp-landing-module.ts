import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransStatsAcqCompModule } from '@ist-custom-project/shell';
import { TransStatsAcqCompRoutingModule } from './txn-sts-acq-comp-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsAcqCompRoutingModule,
    TransStatsAcqCompModule

  ],
  declarations: []
})
export class TransStatsAcqCompLandingModule {
   constructor(){}
}
