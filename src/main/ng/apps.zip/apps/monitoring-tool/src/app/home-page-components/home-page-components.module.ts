import { NgModule, SecurityContext } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { RufThemeColorDirective } from './theme-color/theme-color.directive';
import {
  RufToolbarModule,
  RufUniqueIdModule,
  RufRouterModule,
  RufPageHeaderModule,
  RufDynamicMenubarModule,
  RufLayoutModule,
  RufNavigationModule,
  RufIconModule,
  RufSidemenuModule,
  RufLabeledIconModule,
} from '@ruf/shell';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    RufToolbarModule,
    RufRouterModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatTabsModule,
    MatSelectModule,
    MatSlideToggleModule,
    RufDynamicMenubarModule,
    RufUniqueIdModule,
    RufPageHeaderModule,
    MatIconModule,
    RufLayoutModule,
    RufNavigationModule,
    RufIconModule,
    RufSidemenuModule,
    RufLabeledIconModule,
    FormsModule
   
  ],
  declarations: [RufThemeColorDirective],

  exports: [RufThemeColorDirective],
 
})
export class HomePageComponentsModule { }