import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

export const routes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Tps Vs Memory Stats',
    },
    children: [
      {
        path: '',
        redirectTo: 'TPSVSMEM',
        pathMatch: 'full',
      },
      {
        path: 'TPSVSMEM',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TPSVSMEM' } 
      }
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class TpsVsMemoryRoutingModule { 

  constructor(){
    console.log(' Tps Vs Memory Routing Module ');
  }
}
