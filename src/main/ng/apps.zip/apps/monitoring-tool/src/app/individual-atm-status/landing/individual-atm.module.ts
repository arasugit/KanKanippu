import { FlexLayoutModule } from '@angular/flex-layout';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndividualATMStatusRoutingModule } from './individual-atm-routing.module';
import { MonitorNavigationModule} from '@ist-custom-project/shell';
import { IndividualATMStatusModule} from '@ist-custom-project/shell';


@NgModule({
  declarations: [ ],
  imports: [
    CommonModule,
    FlexLayoutModule,
    IndividualATMStatusRoutingModule,
    MonitorNavigationModule,
    IndividualATMStatusModule
  ], 
})
export class IndividualATMStatusLandingModule {
   constructor(){}    
}

