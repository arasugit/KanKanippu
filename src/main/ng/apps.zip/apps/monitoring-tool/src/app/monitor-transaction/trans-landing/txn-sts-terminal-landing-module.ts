import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransStatsTerminalModule } from '@ist-custom-project/shell';
import { TransStatsTerminalRoutingModule } from './txn-sts-terminal-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsTerminalRoutingModule,
    TransStatsTerminalModule

  ],
  declarations: []
})
export class TransStatsTerminalLandingModule {
   constructor(){}
}
