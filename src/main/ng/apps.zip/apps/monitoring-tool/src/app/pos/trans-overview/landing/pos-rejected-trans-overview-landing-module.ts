import { NgModule } from '@angular/core';
import { MonitorNavigationModule, PosRejectedTransOverviewModule } from '@ist-custom-project/shell';
import { PosRejectedTransOverviewRoutingModule } from './pos-rejected-trans-overview-routing-module';


@NgModule({
    imports :[
    MonitorNavigationModule,
    PosRejectedTransOverviewRoutingModule,
    PosRejectedTransOverviewModule
  ],
  declarations: []
})

export class PosRejectedTransOverviewLandingModule {
   constructor(){
     console.log("Inside PosRejectedTransOverviewLandingModule page");
   }
}
