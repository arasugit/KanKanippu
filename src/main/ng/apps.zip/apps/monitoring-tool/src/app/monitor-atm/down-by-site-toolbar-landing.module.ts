import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { DownBySiteToolbarLandingRoutingModule } from './down-by-site-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    DownBySiteToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: []
})

export class DownBySiteToolBarLandingModule {}
