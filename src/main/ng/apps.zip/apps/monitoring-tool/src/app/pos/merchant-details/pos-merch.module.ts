import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ParentPOSMerchantRoutingModule } from './pos-merch-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
/**
 * NgModule that includes all Material modules that are required to serve the demo-app.
 */
@NgModule({
  imports: [
    CommonModule,
    ParentPOSMerchantRoutingModule,
    MonitorNavigationModule  
  ],
  
})
export class ParentPOSMerchantModule {}
