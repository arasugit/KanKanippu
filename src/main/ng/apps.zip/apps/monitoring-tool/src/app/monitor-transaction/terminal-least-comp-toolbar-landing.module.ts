import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TerminalLeastCompToolbarLandingRoutingModule } from './terminal-least-comp-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    TerminalLeastCompToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class TerminalLeastCompToolBarLandingModule {}
