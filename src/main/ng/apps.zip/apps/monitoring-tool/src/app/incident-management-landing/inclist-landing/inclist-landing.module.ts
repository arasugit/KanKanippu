import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,IncidentListModule } from '@ist-custom-project/shell';
import { IncListRoutingModule } from './inclist-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    IncListRoutingModule,
    IncidentListModule

  ],
  declarations: []
})
export class IncListLandingModule {
   constructor(){}
}
