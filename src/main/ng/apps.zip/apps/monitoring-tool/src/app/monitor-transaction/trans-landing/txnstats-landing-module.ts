import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, TxnStatsModule} from '@ist-custom-project/shell';
import { TxnStatsRoutingModule } from './txnstats-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TxnStatsRoutingModule,
    TxnStatsModule

  ],
  declarations: []
})
export class TxnStatsLandingModule {
   constructor(){}
}
