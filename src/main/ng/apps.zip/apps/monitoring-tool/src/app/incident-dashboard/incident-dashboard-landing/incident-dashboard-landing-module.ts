import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, IncidentDashboardModule } from '@ist-custom-project/shell';
import { IncidentDashboardRoutingModule } from './incident-dashboard-routing-module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    IncidentDashboardRoutingModule,
    IncidentDashboardModule
  ],
  declarations: []
})

export class IncidentDashboardLandingModule {
   constructor(){
     console.log("Inside IncidentDashboardLandingModule page");
   }
}
