import { FlexLayoutModule } from '@angular/flex-layout';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ATMTotalsLandingRoutingModule } from './atm-totals-landing-routing.module';
import { MonitorNavigationModule} from '@ist-custom-project/shell';
import { ATMTotalsHomeModule } from '@ist-custom-project/shell';


@NgModule({
  declarations: [ ],
  imports: [
    CommonModule,
    FlexLayoutModule,
    ATMTotalsLandingRoutingModule,
    MonitorNavigationModule,
    ATMTotalsHomeModule
  ], 
})
export class ATMTotalsLandingModule {
   constructor(){}    
}

