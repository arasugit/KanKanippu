import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const atmRltmCashHistoryRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Real Time Cash Position History'
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMRTCASHH',
        pathMatch: 'full',
      },
      {
        path: 'ATMRTCASHH',
        redirectTo: 'ATMRTCASHH',
        pathMatch: 'full',
      },
      {
        path: 'ATMRTCASHH',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'atm_rltm_cash_history' }
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(atmRltmCashHistoryRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class AtmRltmCashHistoryRoutingModule {
  constructor(){
    console.log('Inside AtmRltmCashHistoryRoutingModule');
  }
}
