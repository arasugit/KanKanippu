import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonLandingComponent,MonitorDynamicComponentDisplayComponent} from '@ist-custom-project/shell';

const posMerchantRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'POS Merchant Details',
    },
    children: [
      {
        path: '',
        redirectTo: 'POSMERCHNT',
        pathMatch: 'full',
      },
      {
        path: 'POSMERCHNT',
        redirectTo: 'POSMERCHNT',
        pathMatch: 'full',
      },
      {
        path: 'POSMERCHNT',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'pos_merch' } 
      }     
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(posMerchantRoutes)],
  exports: [RouterModule]
})
export class POSMerchantLandingRoutingModule { }
