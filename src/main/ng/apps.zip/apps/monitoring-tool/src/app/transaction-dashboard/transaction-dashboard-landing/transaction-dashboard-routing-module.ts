import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

const txnDashboardRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Dashboard'
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNDASH',
        pathMatch: 'full',
      },
      {
        path: 'TXNDASH',
        redirectTo: 'TXNDASH',
        pathMatch: 'full',
      },
      {
        path: 'TXNDASH',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'txn_dashboard' }
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(txnDashboardRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class TransactionDashboardRoutingModule {
  constructor(){
    console.log('Inside TransactionDashboardRoutingModule');
  }
}
