import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',   
    loadChildren: () =>import('./atm-landing/down-by-site-landing-module').then((m) => m.DownBySiteLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class DownBySiteToolbarLandingRoutingModule {
  constructor(){ }
 }
