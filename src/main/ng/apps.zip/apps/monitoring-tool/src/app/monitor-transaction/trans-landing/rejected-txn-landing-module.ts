import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, RejectedTxnsModule} from '@ist-custom-project/shell';
import { RejectedTxnsRoutingModule } from './rejected-txn-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    RejectedTxnsRoutingModule,
    RejectedTxnsModule

  ],
  declarations: []
})
export class RejectedTxnsLandingModule {
   constructor(){}
}
