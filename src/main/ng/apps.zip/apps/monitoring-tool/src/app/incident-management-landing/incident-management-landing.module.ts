import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { IncListToolbarLandingRoutingModule } from './incident-management-landing-routing.module';

@NgModule({
  imports: [
    CommonModule,
    IncListToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class IncListToolBarLandingModule {}
