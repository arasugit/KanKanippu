import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransStatsIssuerToolbarLandingRoutingModule } from './trans-stats-issuer-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

/**
 * NgModule that includes all Material modules that are required to serve the demo-app.
 */
@NgModule({
  imports: [
    CommonModule,
    TransStatsIssuerToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class TransStatsIssuerToolBarLandingModule {}
