import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',   
    loadChildren: () =>import('./trans-landing/trans-stats-acq-top5-landing-module').then((m) => m.TransAcqRejectionLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class TransAcqRejectionToolbarLandingRoutingModule {
  constructor(){ }
 }
