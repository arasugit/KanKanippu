import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransStatsHighVolModule } from '@ist-custom-project/shell';
import { TransStatsHighVolRoutingModule } from './txn-sts-high-vol-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsHighVolRoutingModule,
    TransStatsHighVolModule

  ],
  declarations: []
})
export class TransStatsHighVolLandingModule {
   constructor(){}
}
