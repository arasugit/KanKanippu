import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { DbSumLandingRoutingModule } from './dbSum-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    DbSumLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class DbSumLandingModule {}
