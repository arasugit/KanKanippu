import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, DbSumModule  } from '@ist-custom-project/shell';
import { DbSumRoutingModule } from './dbSum-routing.module';

@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    DbSumRoutingModule,
    DbSumModule
  ],
  declarations: []
})
export class DbSumLandingModule {
   constructor(){
     console.log("Inside DbSumLandingModule page");
   }
}
