import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./fltView-landing/fltView-landing-module').then((m) => m.FltViewLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class FltViewToolbarLandingRoutingModule {
  constructor(){
    console.log('Inside ATM DS Fault Status View routing module ');
   }
 }
