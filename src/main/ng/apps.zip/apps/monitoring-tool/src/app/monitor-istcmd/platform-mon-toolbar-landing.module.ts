import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlatformMonToolbarLandingRoutingModule } from './platform-mon-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    PlatformMonToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class PlatformMonToolBarLandingModule {}
