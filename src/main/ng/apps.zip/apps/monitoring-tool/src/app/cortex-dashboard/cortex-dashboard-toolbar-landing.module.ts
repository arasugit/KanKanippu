import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { CortexDashboardToolbarLandingRoutingModule } from './cortex-dashboard-toolbar-landing-routing.module';

@NgModule({
  imports: [
    CommonModule,
    CortexDashboardToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})

export class CortexDashboardToolBarLandingModule {}
