import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransStatsHighVolToolbarLandingRoutingModule } from './txn-sts-high-vol-toolbar-landing-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

/**
 * NgModule that includes all Material modules that are required to serve the demo-app.
 */
@NgModule({
  imports: [
    CommonModule,
    TransStatsHighVolToolbarLandingRoutingModule,
    MonitorNavigationModule  
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})
export class TransStatsHighVolToolBarLandingModule {}
