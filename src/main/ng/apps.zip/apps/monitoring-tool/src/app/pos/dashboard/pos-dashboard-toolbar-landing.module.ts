import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule } from '@ist-custom-project/shell';
import { PosDashboardToolbarLandingRoutingModule } from './pos-dashboard-toolbar-landing-routing.module';

@NgModule({
  imports: [
    CommonModule,
    PosDashboardToolbarLandingRoutingModule,
    MonitorNavigationModule
  ],
  exports: [],
  declarations: [],
  providers: [ ]
})

export class PosDashboardToolBarLandingModule {}
