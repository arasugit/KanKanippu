import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,ConnectionMonitoringModule } from '@ist-custom-project/shell';
import { ConMonRoutingModule } from './con-mon-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    ConMonRoutingModule,
    ConnectionMonitoringModule

  ],
  declarations: []
})
export class ConMonLandingModule {
   constructor(){
     console.log("Inside connection-monitoring-landing-module page");
   }
}
