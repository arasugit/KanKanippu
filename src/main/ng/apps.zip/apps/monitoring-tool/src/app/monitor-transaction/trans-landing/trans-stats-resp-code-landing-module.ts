import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,TransactionStatsRespCodeModule } from '@ist-custom-project/shell';
import { TransStatsRespCodeRoutingModule } from './trans-stats-resp-code-routing.module';


@NgModule({
    imports :[
   CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    TransStatsRespCodeRoutingModule,
    TransactionStatsRespCodeModule

  ],
  declarations: []
})
export class TransStatsRespCodeLandingModule {
   constructor(){}
}
