import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,TransAcqRejectionToolComponent} from '@ist-custom-project/shell';

export const transAcqRejectionRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Details',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNRJACQ',
        pathMatch: 'full',
      },
      {
        path: 'TXNRJACQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'TXNRJACQ' } 
      },
      {
        path: 'ISSUING',
        component: MonitorDynamicComponentDisplayComponent,
        //component: TransAcqRejectionToolComponent,
        data: { module: 'ISSUING' } 
      }
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(transAcqRejectionRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TransAcqRejectionRoutingModule { 

  constructor(){
    console.log(' Transaction stats Details Routing Module ');
  }
}
