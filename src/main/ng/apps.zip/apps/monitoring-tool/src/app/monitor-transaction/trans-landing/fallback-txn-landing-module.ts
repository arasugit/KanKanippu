import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, FallbackTxnsModule} from '@ist-custom-project/shell';
import { FallbackTxnsRoutingModule } from './fallback-txn-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    FallbackTxnsRoutingModule,
    FallbackTxnsModule
  ],
  declarations: []
})
export class FallbackTxnsLandingModule {
   constructor(){}
}
