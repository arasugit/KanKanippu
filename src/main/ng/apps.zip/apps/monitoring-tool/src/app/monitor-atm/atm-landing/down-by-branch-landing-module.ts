import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule, DownByBranchModule} from '@ist-custom-project/shell';
import { DownByBranchRoutingModule } from './down-by-branch-routing-module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    DownByBranchRoutingModule,
    DownByBranchModule

  ],
  declarations: []
})
export class DownByBranchLandingModule {
   constructor(){}
}
