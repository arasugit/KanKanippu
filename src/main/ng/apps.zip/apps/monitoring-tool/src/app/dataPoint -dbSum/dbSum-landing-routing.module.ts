import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
  {
    path: '',
    loadChildren: () =>import('./dbSum-landing/dbSum-landing.module').then((m) => m.DbSumLandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class DbSumLandingRoutingModule {
  constructor(){
    console.log('Inside DbSumLandingRoutingModuleLandingRoutingModule page... ');
   }
 }
