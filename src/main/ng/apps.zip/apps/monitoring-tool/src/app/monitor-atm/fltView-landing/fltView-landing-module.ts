import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { MonitorNavigationModule,  AtmDataSourceModule} from '@ist-custom-project/shell';
import { FltViewRoutingModule } from './fltView-routing.module';


@NgModule({
    imports :[
    CommonModule,
    FlexLayoutModule,
    MonitorNavigationModule,
    FltViewRoutingModule,
    AtmDataSourceModule

  ],
  declarations: []
})
export class FltViewLandingModule {
   constructor(){
     console.log("Inside fltView-landing-module page");
   }
}
