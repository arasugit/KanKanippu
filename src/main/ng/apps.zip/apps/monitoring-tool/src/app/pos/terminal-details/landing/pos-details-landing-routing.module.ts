import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonLandingComponent,MonitorDynamicComponentDisplayComponent} from '@ist-custom-project/shell';


const posDetailsRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'POS Terminal Details'
    },
    children: [
      {
        path: '',
        redirectTo: 'POSTERDETA',
        pathMatch: 'full',
      },
      {
        path: 'POSTERDETA',
        redirectTo: 'POSTERDETA',
        pathMatch: 'full',
      },
      {
        path: 'POSTERDETA',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'pos_details' }
      }
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(posDetailsRoutes)],
  exports: [RouterModule]
})
export class PosDetailsLandingRoutingModule { }
