import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonLandingComponent, RetentionConfigComponent} from '@ist-custom-project/shell';

export const routes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Retention Config',
    },
    children: [
      {
        path: '',
        redirectTo: 'DATARTCONF',
        pathMatch: 'full',
      },
      {
        path: 'DATARTCONF',
        component: RetentionConfigComponent,
        data: { module: 'DATARTCONF' } 
      }
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class RetentionConfigRoutingModule { 

  constructor(){
    console.log('Retention ConfigRouting Module ');
  }
}
