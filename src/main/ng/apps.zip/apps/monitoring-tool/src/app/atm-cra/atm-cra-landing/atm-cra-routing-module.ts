import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent} from '@ist-custom-project/shell';

//export
const atmCraRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'MGV',
      title: 'ATM Database CRA (Mon Global Value)',
    },
    children: [
      {
        path: '',
        redirectTo: 'ATMCRA_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMCRA_REQ',
        redirectTo: 'ATMCRA_REQ',
        pathMatch: 'full',
      },
      {
        path: 'ATMCRA_REQ',
        component: MonitorDynamicComponentDisplayComponent,
        data: { module: 'atm_cra' }
      }
    ]
  }
];



@NgModule({
  imports: [
    RouterModule.forChild(atmCraRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AtmCraRoutingModule {

  constructor(){
    console.log('Inside AtmCraRoutingModule-routing.module ');
  }
}
