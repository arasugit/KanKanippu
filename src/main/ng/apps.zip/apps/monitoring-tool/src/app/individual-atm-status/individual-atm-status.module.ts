import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ParentIndividualATMRoutingModule } from './individual-atm-status-routing.module';
import { MonitorNavigationModule } from '@ist-custom-project/shell';

@NgModule({
  imports: [
    CommonModule,
    ParentIndividualATMRoutingModule,
    MonitorNavigationModule  
  ],
  
})
export class ParentIndividualATMLandingModule {}
