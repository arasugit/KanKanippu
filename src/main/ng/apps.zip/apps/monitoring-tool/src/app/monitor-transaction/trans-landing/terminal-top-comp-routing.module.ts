import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MonitorDynamicComponentDisplayComponent, CommonLandingComponent,TerminalTopCompComponent} from '@ist-custom-project/shell';

export const terminalTopCompRoutes: Routes = [
  {
    path: '',
    component: CommonLandingComponent,
    data: {
      displayDensity: false,
      icon: 'table',
      title: 'Transaction Stats Details',
    },
    children: [
      {
        path: '',
        redirectTo: 'TXNTC_REQ',
        pathMatch: 'full',
      },
      {
        path: 'TOP-TERMINAL',
        component: TerminalTopCompComponent,
        data: { module: 'TOP-TERMINAL' } 
      },
      {
        path: 'LEAST-TERMINAL',
        component: TerminalTopCompComponent,
        data: { module: 'LEAST-TERMINAL' } 
      },
      {
        path: 'TXNTC_REQ',
        component: TerminalTopCompComponent,
        data: { module: 'TXNTC_REQ' } 
      },
      {
        path: 'HOURLY',
        //component: MonitorDynamicComponentDisplayComponent,
        component: TerminalTopCompComponent,
        data: { module: 'HOURLY' } 
      },
      {
        path: 'DAILY',
        component: TerminalTopCompComponent,
        data: { module: 'DAILY' } 
      },
      {
        path: 'WEEKLY',
        component: TerminalTopCompComponent,
        data: { module: 'WEEKLY' } 
      },
      {
        path: 'MONTHLY',
        component: TerminalTopCompComponent,
        data: { module: 'MONTHLY' } 
      },
      {
        path: 'LEAST-DAILY',
        component: TerminalTopCompComponent,
        data: { module: 'LEASTDAILY' } 
      },
      {
        path: 'LEAST-WEEKLY',
        component: TerminalTopCompComponent,
        data: { module: 'LEASTWEEKLY' } 
      },
      {
        path: 'LEAST-MONTHLY',
        component: TerminalTopCompComponent,
        data: { module: 'LEASTMONTHLY' } 
      }
      
    ]   
  },
];



@NgModule({
  imports: [
    RouterModule.forChild(terminalTopCompRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TerminalTopCompRoutingModule { 

  constructor(){
    console.log(' Transaction stats terminal Routing Module ');
  }
}
