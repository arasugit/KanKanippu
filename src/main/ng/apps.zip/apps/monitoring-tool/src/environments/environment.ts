export const environment = {
  production: false,
  back_end_url: 'http://localhost:8080/IST-Monitoring/',
  use_multilevel_menu: false
};
