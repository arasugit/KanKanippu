const fs = require('fs');
const prepend = require('prepend-file');
const glob = require('glob');
const license = require('@ruf/fis-license');
let distDir ='./dist/';
if (process.argv && process.argv.length > 2 && process.argv[2]) {
	distDir = process.argv[2];
}
if (distDir.slice(-1) !== '/') {
	distDir = distDir + '/';
}
const extn = "*.js";
const licenseText =`/* ${license.plain()} */\n`;

if(!fs.existsSync(distDir)) {
	console.error("dist directory does not exist");
	return;
}
console.log("Adding license...")
glob(`${distDir}${extn}`, (err,files) => {
  if(err) throw err;
  let cnt = 0;
  if(files.length>0) {
    files.forEach( (fileName) => {
        prepend(fileName, licenseText, (err) => {
        	if(err) throw err;
       });
       cnt = cnt + 1;
    });
  }
  console.log("Processed " + cnt + " files");
});

