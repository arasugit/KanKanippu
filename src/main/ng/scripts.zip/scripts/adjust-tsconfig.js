// $Id$
// gets from the command line a comma-separated list of projects to include in tsconfig.app.json
const fs = require('fs');
const projects = (process.argv[2] || '').split(',');
const json_file_path = './src/tsconfig.app.json';
const orig_json = fs.readFileSync(json_file_path, 'utf-8');
const orig_config = JSON.parse(orig_json);
const path_prefix = '../../../../../';
const path_suffix = '/src/main/ng/src/app/*';
const include_suffix = '/src/main/ng/src/**/*.ts';
const exclude_suffix = '/src/main/ng/src/**/*.spec.ts';
let paths = {
    'app/*': [ path_prefix + 'IST-NG' + path_suffix ],
    'environment': [ './environments/environment' ],
    '*': [ '../node_modules/*' ]
};
let include = [ '*.ts' ];
for (const project of projects) {
    paths[project + '/*'] = [ path_prefix + project + '/src/main/ng/src/app/*' ];
    include.push(path_prefix + project + include_suffix);
}
let new_config = {
    ... orig_config,
    'include': include,
}
new_config.compilerOptions.paths = paths;
const new_json = JSON.stringify(new_config, null, 2);
fs.writeFileSync(json_file_path, new_json, 'utf-8');
