import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { RufCommonModule,RufScrollbarModule } from '@ruf/shell';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { IndividualATMStatusComponent } from './atm-status/individual-atm-status.component';
import { ISTComponentModule } from '../ist-components';
import { MON_TOOL, MonitorComponentData } from '../monitor-components/common-object';
import { TranslateLazyLoadModule } from '../ist-components/ist-translate-lazyload-module';
import { RufCardModule} from '@ruf/shell';

const atmStatusMetaData: MonitorComponentData = {
  title: 'Individual ATM Status',
  icon: 'ATM Status',
  examples: {        
      'INVATM_REQ': {
          label: 'Individual ATM Status',
          title: 'Individual ATM Status',
    description: 'Individual ATM Status',
          rufId: 'individual_atm_status',
          component: IndividualATMStatusComponent
      }
  }   
};


@NgModule({
  declarations:[IndividualATMStatusComponent],
  imports: [
    CommonModule, 
    CdkScrollable,
    MatTableModule,  
    FormsModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    TranslateLazyLoadModule,
    ISTComponentModule,
    MatCardModule,  
    RufScrollbarModule,
    RufCommonModule,
    RufCardModule
   ],
  exports:[IndividualATMStatusComponent],
  providers: [{ provide: MON_TOOL, useValue: atmStatusMetaData }],
})
export class IndividualATMStatusModule {}
