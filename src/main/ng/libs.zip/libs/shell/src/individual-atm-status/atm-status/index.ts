export * from './individual-atm-status.component';

