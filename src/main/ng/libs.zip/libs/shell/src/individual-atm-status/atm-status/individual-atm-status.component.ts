import {ChangeDetectorRef, Component,Injector, OnInit, ViewChild} from '@angular/core';
import { DataTableEditableComponent, ListComponent } from '../../components';
import { FormActionPermission,ISTMonCommandPermission, MKCPermission } from '../../permission';
import { StringMap, StringUtil } from '../../common';


@Component({
  selector: 'individual-atm-status',
  templateUrl: './individual-atm-status.component.html',
  styleUrls: ['./individual-atm-status.component.scss']
})
export class IndividualATMStatusComponent extends ListComponent{
  constructor(private injector: Injector,private cdr: ChangeDetectorRef) {
    super(injector);
  }
  FORM_TITLE = 'Individual ATM Status';
  exportFileName = 'Individual ATM Status';
  pageCtrl = 'pageNum';
  mon_inst_id = '';
  selectedATMInstitution='';
  selectedATMUnit='';
  selectedATMGrpname='';
  selectedATM=';'
  mon_atm_grp_name = '';
  mon_atm_unit = '';
  mon_atm_terminal='';
  private completeCommand: string;
  unitValue: string;
  instID: string;
  
  markidlePerm = new ISTMonCommandPermission('markidle');//markidle
  intoservPerm = new ISTMonCommandPermission('intoserv');
  outservPerm = new ISTMonCommandPermission('outserv');
  clrStatusPerm = new ISTMonCommandPermission('clrStatus');
  clrFitnessPerm = new ISTMonCommandPermission('clrFitness');
  loadallPerm = new ISTMonCommandPermission('loadall');
  getcountPerm = new ISTMonCommandPermission('getcount');

  dbParam: StringMap = {};
  waitingCount: Number = 3;
  @ViewChild('atmCommand', { static: false })
  dataTableComponent: DataTableEditableComponent;
  displayProgressBar = false;
  displayMessage = '';

  setT21Tags(): void {
    this.requestTypeId = 'INVATM_REQ';
    this.metaDataId = 'INVATM_REQ';
    this.tabId = 'INVATM_TAB';
    this.sectionId = 'INVATM_SEC';
    this.collectionId = 'INVATM_COL';
  }

  adjustCriteria(): void {
  //  this.criteria['productId'] = 'ISTSWT';
  //  this.criteria['siteId'] = 'Site1';
  //  this.criteria['nodeId'] = 'node1';
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
  }

  getEntPermList(): any[] {
    this.entObjectId = 'INDIVIDUAL_ATM_STATUS';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.insertPerm = new FormActionPermission(this.entObjectId, 'I');
    this.updatePerm = new FormActionPermission(this.entObjectId, 'U');
    this.deletePerm = new FormActionPermission(this.entObjectId, 'D');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);

    return new Array(this.queryPerm, this.insertPerm, this.updatePerm, this.deletePerm, 
      this.mkcPerm, this.checkerPerm);
  }
  validateBeforeQuery(): boolean {
    this.changeATMServerCommandButtons(false);
    this.globals.setErrorMessage('');
    if (StringUtil.isEmpty(this.mon_inst_id)) {
      this.globals.setErrorMessage('ERR01');
      this.setFocusToFirstField();
      return false;
    }
    return true;
  }

  sendATMCommand(cmd: string, event: any): void {
    if(event.currentTarget.name === 'markidle' || event.currentTarget.name === 'intoserv' ||event.currentTarget.name === 'outserv'
        || event.currentTarget.name === 'clrStatus' || event.currentTarget.name === 'clrFitness'
        || event.currentTarget.name === 'loadall' || event.currentTarget.name === 'getcount' )
    {
      this.completeCommand = cmd + ' ' + this.selectedATMInstitution + '.' + this.selectedATMGrpname + '.' + this.selectedATMUnit
    }

    this.changeATMServerCommandButtons(false);
    this.dbParam['type'] = 'ATMCMDCommandExecutionInsert';
    this.dbParam['insertCommand'] = this.completeCommand;
    this.dbParam['user'] = this.globals.userContext.userID;
    this.instService.getDatabaseRecords("ATMEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.updateInsertProcess(x, this.completeCommand, this.completeCommand);
    });
    this.displayMessage = "Executing command '" + this.completeCommand  + "'  is in progress ...";

  }

  updateInsertProcess(result: any[], excutedCommand: any, process: any): void {
    if (result !== undefined && result !== null && result.length > 0) {

      if(result && result[1] != 0 ) {
        this.waitingCount = result[1];
      }

      let count = 0;

      let intervalrun = setInterval(() => {
        count++;

        if(count == this.waitingCount) {
          this.fetchProcessAfterCommandExecution(excutedCommand);
        }

        if(count == (Number(this.waitingCount)+5)) {
          this.displayProgressBar = false;
          this.displayMessage = '';
          this.cdr.detectChanges();
          clearInterval(intervalrun);
        }

      }, 5000)
    }
  }
  fetchProcessAfterCommandExecution(excutedCommand: any) {

    this.dbParam['type'] = 'ATMCMDCommandExecutionFetchAfterInsert';
    this.dbParam['executedCommand'] = this.dbParam['insertCommand'];
    this.dbParam['user'] = this.globals.userContext.userID;
    this.instService.getDatabaseRecords("ATMEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.fetchProcessAfterCommandExecutionResult(x, excutedCommand);
    });

  }

  fetchProcessAfterCommandExecutionResult(result: any[], excutedCommand: any): void
  {
     if (result !== undefined && result !== null && result.length > 0)
    {
      if(result  && result[0] == ' ')
      {
        this.displayMessage = " Command '" + excutedCommand + "' Execution is failed...";
      } else if(result[0] == 'X') {
        this.displayMessage = " Command '" + excutedCommand + "' Execution is successful...";
      }
      this.displayProgressBar = true;
      this.dataTableComponent.refreshData();
      this.cdr.detectChanges();
    }

  }

  openNodeListComponent(command: string, execlevel: number, authid: string): void {}

  openParameterWindow(cmd: string, event: any): void {}
  onRowClick(event:any) {
    this.changeATMServerCommandButtons(true);
    this.displayMessage='';
    this.selectedATMInstitution = event.institutionId ? event.institutionId : '' ;
    this.selectedATMGrpname = event.groupName ? event.groupName : '' ;
    this.selectedATMUnit = event.unit ? event.unit : '' ;
    this.selectedATM = event.terminal ? event.terminal: '' ;
  }
  
  changeATMServerCommandButtons(toggleFlag:boolean){
    //ATM Server Commands
    this.markidlePerm.allowed=toggleFlag;
    this.intoservPerm.allowed=toggleFlag;
    this.outservPerm.allowed=toggleFlag;
    this.clrStatusPerm.allowed=toggleFlag;
    this.clrFitnessPerm.allowed=toggleFlag;
    this.loadallPerm.allowed=toggleFlag;
    this.getcountPerm.allowed=toggleFlag;
  }

  openSearchList(winName) {}
  getModuleName() { return 'ATM-Monitoring'; }
  emitModuleReady() { this.msgService.sendMessage(this.getModuleName()); }
}

