export * from './tps-vs-module.module';
export * from './tps-vs-memory.component';
