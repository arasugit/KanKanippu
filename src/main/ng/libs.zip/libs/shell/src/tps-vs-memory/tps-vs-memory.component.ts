import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, Inject, Injector, OnDestroy, OnInit, Optional, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { AbstractDataTableComponent, DataTableEditableComponent, DataTableEditableDetailComponent, RendererItem } from '../components';
import { DataTableService, ResponseBase } from '../services';
import { WorkRequest } from '../ist-components';
import { IstDatePickerColumnRendererComponent } from '../ist-components';
import { LabelAndValue, LabelsAndValues } from '../common/labels-and-values';
import { Subject, takeUntil } from 'rxjs';
import { TpsVsMemoryMultiDTO } from './tpsvsmemmultidto';
import { TpsVsMemoryDTO } from './tpsvsmemorydto';
import { CustomValidators } from '../common';
import { PageEvent } from '@angular/material/paginator';
import { TransactionStatsDetailsComponent } from '../transaction';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import highcharts3d from 'highcharts/highcharts-3d';
highcharts3d(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);

@Component({
  selector: 'tps-vs-memory-app',
  templateUrl: './tps-vs-memory.component.html',
  styleUrls: ['../transaction/transaction.scss'],
  encapsulation: ViewEncapsulation.None
 })
export class TpsVsMemoryComponent extends ListComponent implements OnInit, OnDestroy,AfterViewInit {
  [x: string]: any;

  @ViewChild('memoryDataTable', { static: false }) private memoryDataTable: DataTableEditableComponent;
  dataTableComponent: DataTableEditableComponent;
  @ViewChild('tpsDataTable', { static: false }) private tpsDataTable: DataTableEditableDetailComponent;
  private unsubscribe = new Subject();
  constructor( public injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker, @Inject(ElementRef) private element: ElementRef) {
    super(injector);
    this.type="5MIN";
    this.range=this.type;
  }

  FORM_TITLE = 'Tps Vs Memory';
  exportFileName= 'tps_vs_memory';
  cardTitle="Tps Vs Memory"
  isDetailsTab=true;
  multi: any[];
  width=1000;
  widthTps=1000;
  view: any[] = [this.width, 300];
  viewTps: any[] = [this.widthTps, 300];
  Highcharts: typeof Highcharts = Highcharts;
  memoryUtilisation: Highcharts.Options;
  tpsUtilisation: Highcharts.Options;

  // options
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = false;
  showXAxisLabel = true;
  xAxisLabel = 'Time';
  showYAxisLabel = true;
  yAxisLabel = 'Value';
  fromTime :  string = '';
  fromDate : string = '';
  dateTo : string = '';
  toTime : string = '';
  rows = 1;
  tpsrows = 1;
   // line, area
   autoScale = true;
  timeRangeData: LabelsAndValues = new LabelsAndValues();
  colorScheme = {
    domain: ['#5AA454', '#E44D25', '#CFC0BB', '#7aa3e5', '#a8385d', '#aae3f5']
  };
   workRequest:WorkRequest;

   queryPerm = new FormActionPermission('TPSVSMEM', 'Q');
   insertPerm = new FormActionPermission('TPSVSMEM', 'I');
   updatePerm = new FormActionPermission('TPSVSMEM', 'U');
   deletePerm = new FormActionPermission('TPSVSMEM', 'D');
   checkerPerm = new FormActionPermission('TPSVSMEM', 'C');
   mkcPerm = new MKCPermission('TPSVSMEM');

   startDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
   endDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);

   ngOnInit() {
    this.type="5MIN";
    this.range=this.type;
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.insertPerm);
    this.requestPerms.permsArr.push(this.updatePerm);
    this.requestPerms.permsArr.push(this.deletePerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.timeRangeData.array = [new LabelAndValue('5 Min', '5MIN'), new LabelAndValue('Custom', 'custom')];
      this.setAutoRefreshSearch(true);

  }

  ngAfterViewInit(): void {
   // this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'TPSVSMEM';
    this.metaDataId = 'TPSVSMEM';
    this.tabId = 'TPSVSMEMTAB';
    this.sectionId = 'TPSVSMEMSEC';
    this.collectionId = 'TPSVSMEMCOL';
  }
  retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';

    this.dataService.criteria=this.criteria;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        data => this.onGotRecords(data),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }
  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }
  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    console.log(' onGotRecords   ::');
    this.workRequest = wr;
    this.dataLoaded=false;
    this.dataLoadedTps=false;
    if(this.workRequest.lastModified == -3){
     this.globals.setErrorMessage('No Data found for TPS Chart');

    //this.globals.setStatusMessage(' No Data found for TPS Chart');
    }else  if(this.workRequest.lastModified == -2){
      //this.globals.setErrorMessage('Memory Data Not found');
      this.globals.setStatusMessage(' No Data found for Memory Utilisation Chart');
    }else if(this.workRequest.lastModified == -1){
      this.globals.setErrorMessage(' No Data found for both TPS and Memory Utilisation chart');
      this.dataLoaded=false;
      this.dataLoadedTps=false;
      return;
      } else if(this.workRequest.lastModified == -4){
        this.globals.setErrorMessage(' No Data found for the given date range');
        this.dataLoaded=false;
        this.dataLoadedTps=false;
        return;
      }

    let error: Boolean = false;
    let errorId = '';
    if (this.workRequest.requestResult === ResponseBase.REQUEST_RESULT_ERROR) {
      errorId = this.workRequest.errorDetail;
      errorId = (errorId === null || errorId.trim().length <= 0) ? this.workRequest.messageId : errorId;
      this.globals.setErrorMessage(errorId);
      error = true;
    }
    if(this.workRequest!=null && this.workRequest !==undefined &&
      this.workRequest.collections!=null && this.workRequest.collections[this.collectionId]
       !=null && this.workRequest.collections[this.collectionId].rows!=null){
      const rows = this.workRequest.collections[this.collectionId].rows;
      const rowspage = this.workRequest.collections['TRANS_DTL_COL'].rows;

      this.rows=rows.length;
      this.view=[1000,300];
        this.width=(rows.length*1000)/40;
        if(this.rows>38)
        this.view=[this.width,300];

    if(this.workRequest.collections['TRANS_DTL_COL']
    !=null && this.workRequest.collections['TRANS_DTL_COL'].rows!=null){
     this.memoryDataTable.dataSource.data=rowspage;
     DataTableEditableComponent.totalDTLRecords=rows.length;
     this.memoryDataTable.length=rows.length;
     DataTableEditableComponent.isTxnDetailScreen=true;
     this.memoryDTLDataList=rowspage;
    }
    let rowsTps=null;
    if(this.workRequest.collections['TPSCOL']
    !=null && this.workRequest.collections['TPSCOL'].rows!=null){
     rowsTps = this.workRequest.collections['TPSCOL'].rows;
    this.widthTps=(rowsTps.length*1000)/40;
    this.viewTps=[1000,300];
    this.tpsrows=rowsTps.length;
    this.tpsDTLDataList=rowsTps;
    if(this.tpsrows>38)
    this.viewTps=[this.widthTps,300];

    // tpsDataTable
    if(this.workRequest.collections['TPSDTLCOL']
    !=null && this.workRequest.collections['TPSDTLCOL'].rows!=null){
    const rowsPageTps = this.workRequest.collections['TPSDTLCOL'].rows;
    this.tpsDataTable.length=rowsPageTps.length;
    this.tpsDTLDataList=rowsTps;
    }
  }
  if(rows!=null && rows!=undefined && rows.length >0){
     let hdto4:  TpsVsMemoryDTO;
     let hdto2:  TpsVsMemoryDTO;
     let hdto3:  TpsVsMemoryDTO;
     let hdto5:  TpsVsMemoryDTO;
     let htpsdtolist :TpsVsMemoryDTO[]=[];
     let hmemdtolist :TpsVsMemoryDTO[]=[];
     let hcpudtolist :TpsVsMemoryDTO[]=[];
     let hcpuUserdtolist :TpsVsMemoryDTO[]=[];
     rows.forEach((c,index) =>{
      const dateArr = c.specialStr.split("/");
      const timeArr = c.logDate.split(":");

      const dateObj = new Date(parseInt(dateArr[2]), parseInt(dateArr[1])-1, parseInt(dateArr[0]),
                            parseInt(timeArr[0]), parseInt(timeArr[1]), parseInt(timeArr[2]));
      const utcTS = Date.UTC(dateObj.getUTCFullYear(), dateObj.getUTCMonth(),
                            dateObj.getUTCDate(), dateObj.getUTCHours(),
                            dateObj.getUTCMinutes(), dateObj.getUTCSeconds());
      hdto2  = new TpsVsMemoryDTO(utcTS,c.currentTps);
      hdto3  = new TpsVsMemoryDTO(utcTS,c.usedMemoryPct);
      hdto4  = new TpsVsMemoryDTO(utcTS,c.cpuSys);
      hdto5  = new TpsVsMemoryDTO(utcTS,c.cpuUser);
      htpsdtolist.push(hdto2);
      hmemdtolist.push(hdto3);
      hcpudtolist.push(hdto4);
      hcpuUserdtolist.push(hdto5);
  })
   this.getMemoryChart(htpsdtolist,hmemdtolist,hcpudtolist,hcpuUserdtolist);
    this.dataLoaded=true;
    this.cdr.markForCheck();
    }else{
      this.dataLoaded=false;
    }
    if(rowsTps!=null && rowsTps!=undefined && rowsTps.length >0){
    let hdtotps:  TpsVsMemoryDTO;
    let hdtolisttps :TpsVsMemoryDTO[]=[];
     //  For Line Chart
     rowsTps.forEach((c,index) =>{
      const dateArr = c.specialStr.split("/");
      const timeArr = c.logDate.split(":");
      const dateObj = new Date(parseInt(dateArr[2]), parseInt(dateArr[1])-1, parseInt(dateArr[0]),
                            parseInt(timeArr[0]), parseInt(timeArr[1]), parseInt(timeArr[2]));
      const utcTS = Date.UTC(dateObj.getUTCFullYear(), dateObj.getUTCMonth(),
                              dateObj.getUTCDate(), dateObj.getUTCHours(),
                              dateObj.getUTCMinutes(), dateObj.getUTCSeconds());

     hdtotps  = new TpsVsMemoryDTO(utcTS,c.currentTps);
     hdtolisttps.push(hdtotps);
   });
   this.getTPSChart(hdtolisttps);
     this.dataLoadedTps=true;
     this.cdr.markForCheck();
    }else{
      this.dataLoadedTps=false;
    }
    }else{
      this.dataLoaded=false;
    }
    this.globals.hideLoadingBar();
  }

  getMemoryChart(htpsdtolist : TpsVsMemoryDTO[], hmemdtolist : TpsVsMemoryDTO[],
    hcpudtolist: TpsVsMemoryDTO[], hcpuUserdtolist : TpsVsMemoryDTO[]){
      this.memoryUtilisation ={
        chart: {
          zooming: {
              type: 'x'
          },
          height:'300',
          width:'900',
          type: 'spline',
        scrollablePlotArea: {
            minWidth: 600,
            scrollPositionX: 1
        }
      },
      title: {
          text: '',
          align: 'left'
      },
      credits:{enabled:false},
      subtitle: {
          text: document.ontouchstart === undefined ?
              'Click and drag in the plot area to zoom in' :
              'Pinch the chart to zoom in',
          align: 'left'
      },
      xAxis: {
          type: 'datetime',
          title: {
            text: 'Date - Time'
          }
      },
      yAxis: {
          title: {
              text: 'Value'
          }
      },
      time: {
        useUTC: false
      },
      legend: {
          enabled: true,
          layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
      },
      plotOptions: {
          spline: {
            lineWidth: 2,
            states: {
              hover: {
                  lineWidth: 3,
                  brightness: 0.1
              }
            }

          }
      },

      series: [{
          type: 'spline',
          name: 'TPS',
          data: this.formatData(htpsdtolist),
          tooltip: {
          valueDecimals:2
          },
          animation: {
            duration: 2550
          }
        },
        {
          type: 'spline',
          name: 'Memory',
          data: this.formatData(hmemdtolist),
          tooltip: {
          valueDecimals:2
          },
          animation: {
            duration: 2550
          }
        },
        {
          type: 'spline',
          name: 'CPU System',
          data: this.formatData(hcpudtolist),
          tooltip: {
          valueDecimals:2
          },
          animation: {
            duration: 2550
          }
        },
        {
          type: 'spline',
          name: 'CPU User',
          data: this.formatData(hcpuUserdtolist),
          tooltip: {
          valueDecimals:2
          },
          animation: {
            duration: 2550
          }
        }]
      }
  }

  getTPSChart(htpsdtolist : TpsVsMemoryDTO[]){
      this.tpsUtilisation ={
        chart: {
          zooming: {
              type: 'x'
          },
          width:'900'
      },
      title: {
          text: '',
          align: 'left'
      },
      subtitle: {
          text: document.ontouchstart === undefined ?
              'Click and drag in the plot area to zoom in' :
              'Pinch the chart to zoom in',
          align: 'left'
      },
      xAxis: {
          type: 'datetime',
          title: {
            text: 'Date - Time'
          }
      },
      yAxis: {
          title: {
              text: 'Value'
          }
      },
      time: {
        useUTC: false
      },
      legend: {
          enabled: false
      },
      plotOptions: {
          area: {
              marker: {
                  radius: 2
              },
              lineWidth: 1,
              color: {
                  linearGradient: {
                      x1: 0,
                      y1: 0,
                      x2: 0,
                      y2: 1
                  },
                  stops: [
                      [0, 'rgb(199, 113, 243)'],
                      [0.7, 'rgb(76, 175, 254)']
                  ]
              },
              states: {
                  hover: {
                      lineWidth: 1
                  }
              },
              threshold: null
          }
      },

      series: [{
          type: 'area',
          name: 'TPS',
          data: this.formatData(htpsdtolist),
          tooltip: {
          valueDecimals:2
          }
        }]
      }

  }
  formatData(data: TpsVsMemoryDTO[]){
    return data.map((c: TpsVsMemoryDTO) => {
      return [c.utcTS,parseFloat(c.value)];
    });
  }
  onErrorGotRecords(error: Object): void {
    console.log(' onErrorGotRecords   ::');
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
    this.globals.hideLoadingBar();
  }
   onCompleteGotRecords(): void {
    console.log(' onCompleteGotRecords   ::');
    this.globals.hideLoadingBar();
  }
  adjustCriteria(): void {
    this.criteria['type']=this.type;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['isDetailReq']= 'true';
    this.criteria['ist_page_ctrl'] = '1';
    this.criteria['ist_total'] = 'Y';
    this.criteria['COMMAND']='query';
  }
  changeHandler(event: any) {

    this.globals.setErrorMessage('');
    this.globals.setStatusMessage('');
    this.dataLoaded=false;
    this.dataLoadedTps=false;
    this.isDetailsTab=true;
    if(null != event){
    this.type=event;
    if(event=='5MIN'){
      this.isSearchReq=false;
    this.adjustCriteria();
    this.retriveData();
    }else{
      this.globals.hideLoadingBar();
      this.isSearchReq=true;
    }
    }
  }
  onRowClick(event:any) {
    //console.log("Inside OnRowClick " + event);
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
   this.memoryDataTable.paginator.length=0;
   this.memoryDataTable.paginator.pageSizeOptions=null;
   AbstractDataTableComponent.totalDTLRecords=0;
   //AbstractDataTableComponent.totalTpsDTLRecords=0;
   this.memoryDataTable.totalDisplayingRecords=0;

  }
  onSelect(data): void {
   console.log('Item clicked', JSON.parse(JSON.stringify(data)));
   console.log('Item clicked', data['name']);
   console.log('Item clicked', this.type);
   this.cardTitleTxn="AAAAAAAAAAAAAA";
   this.isDetailsTab=false;
   this.adjustCriteria();
   this.retriveData();
  }

  onActivate(data): void {
   // console.log('Activate', JSON.parse(JSON.stringify(data)));
  }

  onDeactivate(data): void {
    //console.log('Deactivate', JSON.parse(JSON.stringify(data)));
  }
  dateTickFormatting(val: any): string {
    console.log('dateTickFormatting....'+val);
    if (val instanceof Date) {
      return (<Date>val).toLocaleString('de-DE');
    }
  }

  search() : void{
  this.dataLoaded=false;
  this.dataLoadedTps=false;

  this.clearErrorMessage();
  if (this.validateBeforeQuery()) {
    this.globals.showLoadingBar();
    this.clearErrorFlags();
    this.encryptCriteria();
  this.adjustCriteria();
    this.criteria['fromDate']=this.fromDate;
    this.criteria['toDate']=this.dateTo;
    this.criteria['fromTime']=this.fromTime;
    this.criteria['toTime']=this.toTime;
    this.criteria['ist_page_num_mem'] = '1';
    this.criteria['ist_page_num_tps'] = '1';
    this.retriveData();
  this.autoRefreshService.setAutoRefreshSearchInterval(this);
  }
  }
  clear() : void{
    // this.resetDetailTable();
    this.globals.setErrorMessage('');
    this.globals.setStatusMessage('');
    this.dataLoaded=false;
    this.dataLoadedTps=false;
    this.isDetailsTab=true;
    this.fromDate = 'null';
    this.fromTime = '';
    this.dateTo = 'null';
    this.toTime = '';
    super.clear();
  }

  validateBeforeQuery(): boolean {
    CustomValidators.globals=this.globals;
    this.fromDate=CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo=CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat);
    let result:boolean;
    result= CustomValidators.validateTPSVsMemDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField);
    return result;
}

validateFromTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
validateToTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}

 // called for data table pagination
 more(pageEvent: PageEvent): void {
  this.globals.showLoadingBar();
  this.criteria['type']=this.type;
  this.criteria['requestTypeId']=this.requestTypeId;
  this.criteria['collectionId']=this.collectionId;
  this.criteria['isDetailReq']= 'true';
  this.criteria['ist_page_ctrl'] = '' + ((pageEvent.pageIndex) + 1);
  this.criteria['ist_total'] = 'Y';
  this.criteria['eventName']=   TransactionStatsDetailsComponent.eventName;
  this.criteria['txnSrcAcq']= TransactionStatsDetailsComponent.txnSrcAcq;
  this.clearErrorFlags();
  this.encryptCriteria();
  this.criteria['fromDate']=this.fromDate;
  this.criteria['toDate']=this.dateTo;
  this.criteria['fromTime']=this.fromTime;
  this.criteria['toTime']=this.toTime;
  this.retriveData();
}

}



