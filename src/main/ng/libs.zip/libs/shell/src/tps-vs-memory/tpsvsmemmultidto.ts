import { TpsVsMemoryDTO } from "./tpsvsmemorydto";

export  class TpsVsMemoryMultiDTO {
    
    name: string;
    series: TpsVsMemoryDTO[];
    constructor(name: string, value: TpsVsMemoryDTO[]){
        this.name=name;
        this.series=value;
    }
}

export  class TpsVsMemoryMultiList {
    private arr;
    private list;
    array: TpsVsMemoryMultiDTO[];
    records: TpsVsMemoryMultiDTO[];

}