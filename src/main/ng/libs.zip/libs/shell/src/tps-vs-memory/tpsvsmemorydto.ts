export  class TpsVsMemoryDTO {
    name: string;
    utcTS: number;
    value: string;
    constructor(name: string | number, value: string){
      if(typeof name === "number"){
        this.utcTS = name;
      }
      else if(typeof name === "string"){
        this.name=name;
      }
       
       this.value=value;
   }
}

export  class TpsVsMemoryDTOList {
    private arr;
    private list;
    array: TpsVsMemoryDTO[];
    records: TpsVsMemoryDTO[];
}
