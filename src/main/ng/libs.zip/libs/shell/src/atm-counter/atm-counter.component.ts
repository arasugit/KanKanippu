import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent} from '../components/base-list.component';
import { CustomValidators, StringUtil } from '../common';
import { T21Base } from '../components';

@Component({
    selector: 'atm-counter-app',
    templateUrl : './atm-counter.component.html',
    styleUrls: ['./atm-counter.component.scss'],
    encapsulation: ViewEncapsulation.None
})
   
export class AtmCounterComponent extends ListComponent implements OnInit {
  constructor(injector: Injector) {
    super(injector);
  }
   FORM_TITLE = '';
   product = '';
   fromTime :  string = '';
   fromDate : string = '';
   dateTo : string = '';
   toTime : string = '';
   screenType ='';
   institutionId = '';
   groupName = '';
   unit = '';
   terminalId = '';

  @ViewChild('toDateFocusField', { static: false })
  toDateFocusField: T21Base;

   queryPerm = new FormActionPermission('MONATMCOUN', 'Q');
   checkerPerm = new FormActionPermission('MONATMCOUN', 'C');
   mkcPerm = new MKCPermission('MONATMCOUN'); 
   
   adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
    this.criteria['fromTime']= this.fromTime;
    this.criteria['toTime']=this.toTime;
    this.criteria['institutionId']= this.institutionId;
    this.criteria['groupName']= this.groupName;
    this.criteria['unit']=this.unit; 
    this.criteria['terminalId']=this.terminalId; 
    
    this.criteria['collectionId']=this.collectionId;  
    this.criteria['COMMAND']='query';   
  }  

   ngOnInit() {
    super.ngOnInit();
    this.requestPerms.permsArr = [];

    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);  
    this.requestPerms.getPermission(this.router.url);
    this.FORM_TITLE='ATM Counter';
    this.exportFileName = 'ATM Counter';
    this.setAutoRefreshSearch(true);
  }

  setT21Tags(): void {
    this.requestTypeId = 'MONATMCOUN';
    this.metaDataId = 'MONATMCOUN';
    this.tabId = 'MONATMCOUN_TAB';
    this.sectionId = 'MONATMCOUN_SEC';
    this.collectionId = 'MONATMCOUN_COL';
	}

  validateBeforeQuery(): boolean {
    this.globals.setErrorMessage('');
    CustomValidators.globals=this.globals;
    this.fromDate=CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo=CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat); 
    let result:boolean;
    result= CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField);
    
    
    if (StringUtil.isEmpty(this.institutionId)) {
      this.globals.setErrorMessage('Select Institution Id');
      this.setFocusToFirstField();
      result = false;
    }  
    
    if (!StringUtil.isEmpty(this.unit) && isNaN(Number(this.unit))) {

      this.globals.setErrorMessage('Unit field must be numeric.');
      this.setFocusToFirstField();
      result = false;
    } 

    if(result){
      result= CustomValidators.validateTimeField(this.fromTime);
    }
 
    
    if(result){
      result= CustomValidators.validateTimeField(this.toTime);
    }
    
    return result;
  }

  validateFromTime(event: any) {
    CustomValidators.globals=this.globals;
    return CustomValidators.formatTimeField(event);
  }

  validateToTime(event: any) {
    CustomValidators.globals=this.globals;
    return CustomValidators.formatTimeField(event);
  }

  getModuleName() { return 'IST-MONITORING'; }
  emitModuleReady() { this.msgService.sendMessage(this.getModuleName()); }
}