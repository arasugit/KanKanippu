import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule, RufScrollbarModule } from '@ruf/shell';
import { AtmCounterComponent } from './atm-counter.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TranslateLazyLoadModule } from '../ist-components/ist-translate-lazyload-module';
import { MatDividerModule } from '@angular/material/divider';

export const atmCounterData: MonitorComponentData = {
  title: 'ATM Counter',
  icon: 'ATM Counter',
  examples: {  
      'MONATMCOUN': {
          label: 'ATM Counter',
          title: 'ATM Counter',
          description: 'ATM Counter',
          rufId: 'atm_counter',
          component: AtmCounterComponent
      }
  }
};

@NgModule({ 
    imports :[ 
      CommonModule, 
      CdkScrollable,
      MatTableModule,  
      FormsModule,
      FlexLayoutModule,
      ReactiveFormsModule,
      TranslateLazyLoadModule,
      ISTComponentModule,
      MatDividerModule,
      MatCardModule,  
      RufScrollbarModule,
      RufCommonModule,
      RufCardModule
  ], 
  declarations: [AtmCounterComponent],
  providers: [{ provide: MON_TOOL, useValue: atmCounterData }],
  exports:[],
})
export class AtmCounterModule {}
