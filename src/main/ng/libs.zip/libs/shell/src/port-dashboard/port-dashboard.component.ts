import {Component, ViewEncapsulation, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef } from '@angular/core';
import { finalize, first } from 'rxjs/operators';
import { MON_ATM_COLOR_SETS } from '../home/ngx-charts-color-sets';
import { ListComponent } from '../components';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { ChartDTO } from './chart-dto';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import highcharts3d from 'highcharts/highcharts-3d';
highcharts3d(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);

@Component({
  selector: 'port-dashboard',
  templateUrl: './port-dashboard.component.html',
  styleUrls: ['./../transaction/transaction.scss'],
  encapsulation: ViewEncapsulation.None
})

export class PortDashboardComponent extends ListComponent implements OnDestroy {
  view: any[] = [400, 300];
  screenType: any;
  connectionData: any[];
  mailLegendValues: string[] = [];
  serverMailData:any[] = [];
  // mailLegendColors: ColorHelper;
  // readonly LegendPosition = LegendPosition;
  Highcharts: typeof Highcharts = Highcharts;
  chartOptionsMail: Highcharts.Options;
  colorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };

  constructor(private injector: Injector, private dataService: DataTableService, private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker) {
      super(injector);

      this.route
      .data
      .pipe(first())
      .subscribe(v => this.screenType=v['module']);

      this.adjustCriteria();
      this.retriveData();
  }

  adjustCriteria(): void {
    this.globals.setErrorMessage('');
  //  this.criteria['productId'] = 'ISTSWT';
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
  }

  retriveData(): void {
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
    this.globals.showLoadingBar();
    this.dataService
    .loadData(false)
    .pipe(
      first(),
      finalize(() => this.globals.hideLoadingBar())
    )
    .subscribe(
      {
        next: (atmData: any) => this.onGotRecords(atmData),
        error: (error: any) => this.onErrorGotRecords(error)
      }
    );
  }

  onGotRecords(wr: WorkRequest): void {
    this.globals.hideLoaderBar();
    const workRequest = wr;

    if(workRequest.lastModified == -1){
      this.globals.setErrorMessage('No Data found');
      //return;
    }

      const rows = workRequest.collections[this.collectionId].rows;
      this.getPortChart(rows);
      let multiDtoList: ChartDTO[] = [];

      rows.forEach((c,index) => {
        let chartDto = new ChartDTO(c.serverMailId, c.serverMailCount);
        multiDtoList.push(chartDto);
        this.mailLegendValues.push(c.serverMailId + " - " + c.serverMailCount);
      });
      // this.mailLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.mailLegendValues, this.colorScheme);
      this.connectionData = JSON.parse(JSON.stringify(multiDtoList));
       console.log( this.connectionData);
      this.adjustChartViewWidth(rows.length);
      this.cdr.markForCheck();
  }

  getPortChart(rows: any){
    this.serverMailData = [];
    rows.forEach((c) => {
     this.serverMailData.push([c.serverMailId, c.serverMailCount]);
    });
     this.chartOptionsMail ={
      chart: {
        renderTo: 'container',
        type: 'column',
        options3d: {
            enabled: true,
            alpha: 20,
            beta: 0,
            depth: 50,
            viewDistance: 50
        }
    },
    credits:{
      enabled: false,
    },
    xAxis: {
      type: 'category',
      title: {
        text: 'Server'
    },
  },
  yAxis: {
    title: {
      text: 'Count'
  },
},
      title: {
          text: 'Server Mail Box Count'
      },
      tooltip: {
        pointFormat: '<b>{point.name}</b> - {point.y}'
    },
      accessibility: {
          screenReaderSection: {
              beforeChartFormat: '<{headingTagName}>' +
                  '{chartTitle}</{headingTagName}><div>{typeDescription}</div>' +
                  '<div>{chartSubtitle}</div><div>{chartLongdesc}</div>'
          }
      },
      legend: {
        enabled: false
    },
      plotOptions: {
        column: {
            depth: 25
        }
    },
      series: [{
          // name: 'Unique users',
          data: this.serverMailData,
          colorByPoint: true,
          events: {
            click:  (event)=> {
              this.onMailBoxBarChartSelect({
                name: event.point.name,
              });
            }
          }
      }] as any
  }
  }
  adjustChartViewWidth(rowCount: number) {
    if(rowCount > 5)
      this.view = [rowCount * 100, 300];
  }

  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  setT21Tags(): void {
    this.requestTypeId = 'PORTDASH';
    this.metaDataId = 'PORTDASH';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
    this.clearErrorMessage();
  }

  onMailBoxBarChartSelect(event) {
    const path = 'monitor/PRTDTLS';
    const paramVal = 'ServerMailBoxId';
    this.router.navigateByUrl(path, {state: {paramKey: paramVal, paramKeyValue: event.name }});
  }

  loadNewForPortDetails(command: any) {
    this.DETAIL_FORM_PATH = '/PRTDTLS/PRTDTLS';
    this.goToDetailForm(command);
  }

  onMailBoxBarChartSelect2(event: any) {
    console.log(event + " towards redirecting to monitor/PRTDTLS" );
    let path = '/PRTDTLS/PRTDTLS';
    let newParam = {};
    newParam = {
      COMMAND: 'query',
      status_code: event,
      NAVIGATION: true
    };
    if (path !== '') { this.loadNewForPortDetails(newParam); }
  }

  doSearch(): void {
    this.adjustCriteria();
    this.retriveData();
  }


}
