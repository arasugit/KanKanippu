// $Id$
import { Component, OnInit, AfterContentInit} from '@angular/core';
import { CustomRenderer } from '../components/data-table-column.component';
import { IstSearchListComponent } from '../components/ist-searchlist-component';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
@Component({
    selector: 'ist-search-list-column-renderer',
    template: ` <div class="row-section">
                   <div class="sl-section">
                    <ist-input class="resetIEdef" value="{{evaluate()}}"
                    isDisabled="isDisabled()" ></ist-input>
                    <button mat-raised-button fisStyle (click)="OpenSearchList(comboBoxType)" [disabled]="isDisabled()">...</button>
                   </div>
                </div>`
})
export class IstSearchListColumnRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {
    constructor(private dialog: MatDialog) {
        super();
        //  console.log('(IstSearchListColumnRendererComponent constructor())');
    }
    public comboBoxType: string = '';
    groupNameSearchListRef: MatDialogRef<IstSearchListComponent>;
    ngOnInit() {
        //  console.log('(IstSearchListColumnRendererComponent onInit())');
    }
    ngAfterContentInit() {
        //  console.log('(IstSearchListColumnRendererComponent ngAfterContentInit())');
    }

    isDisabled(): boolean {
        if ((this.row['dbAction'] === 'x' || this.row['dbAction'] === 'c') && this.column.editable === false) {
            return true;
        }
        if (this.row['inactive'] !== null && this.row['inactive'].toLowerCase() === 'Y') {
            return true;
        }
        if (this.row['dbAction'] === 'd') {
            return true;
        }
        if (this.permissions['U'] === false && this.row['dbAction'] !== 'a') {
            return true;
        }
        return false;
    }
    evaluate(): any {
        try {            
            if (this.column.labelFunction) {
                return this.column.labelFunction(this.row, this.column);
            }
            if (this.value === undefined || this.value === null) {
                return '';
            }
            return this.value;
        } catch (e) {
            // Ignore
        }
    }
    OpenSearchList(popupType: String): void {
        if (this.comboBoxType === 'POS_ACQENTITY_POPUP') {
            this.groupNameSearchListRef = this.dialog.open(IstSearchListComponent,
            {  panelClass: 'sl-mat-dialog-container',
            data: { type: 'POS_ACQENTITY_POPUP', defaultParams: {  institution_id: this.row['institutionId'] } } });
            this.groupNameSearchListRef.updateSize('650px');
        }
        this.groupNameSearchListRef.afterClosed().subscribe(result => {
          if (result != null) {
            if (result['0'] != null) {
                this.value =  String(result['0']);
            } else if (this.comboBoxType === 'POS_ACQENTITY_POPUP' && result['entityId'] != null) {
                this.value =  String(result['entityId']);
            }
                this.onSelectedRowChange.next(this.value);
          }
        });
      }
    propagateChangedRow(selectedValue) {
      
    }
}
