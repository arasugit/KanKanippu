import { Component, OnInit, AfterContentInit,EventEmitter } from '@angular/core';
import { CustomRenderer, DataTableColumnComponent } from '../components/data-table-column.component';


@Component({
    selector: 'ist-checkbox-column-renderer',
    template: `<ist-checkbox [checked]="evaluate()" (onClicked)="propagateChangedRow($event)" isDisabled="isDisabled()"></ist-checkbox>`
})
// Checkbox renderer example for the data table column
export class IstCheckBoxSearchlistRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {

    
    
    constructor() {
        super();
        //  console.log('(IstCheckBoxSearchlistRendererComponent constructor())');
    }
    ngOnInit() {
        //  console.log('(IstCheckBoxSearchlistRendererComponent onInit())');
    }

    ngAfterContentInit() {
        //  console.log('(IstCheckBoxSearchlistRendererComponent ngAfterContentInit())');
    }

    evaluate(): Boolean {
        if (this.row[this.column.name] && typeof this.row[this.column.name] === 'string') {
            if (this.row[this.column.name].toLocaleLowerCase().trim() === 'y'
                || this.row[this.column.name].toLocaleLowerCase().trim() === 'yes') {
                return true;
            }
        }
        return false;
    }

    propagateChangedRow(selectedValue) {
        if (selectedValue === true) {
            this.value = 'y';
        } else {
            this.value = 'n';
        }
        //  console.log('Propagate changed value: ', this.value);
        this.onSelectedRowChange.next(this.value);
    }

    isDisabled(): boolean {
        if (this.row !== undefined) {
            if ((this.row['dbAction'] === 'x' || this.row['dbAction'] === 'c') && this.column.editable === false) {
                return true;
            }
            if (this.row['inactive'] !== undefined && this.row['inactive'] !== null && this.row['inactive'].toLowerCase() === 'Y') {
                return true;
            }
            if (this.row['dbAction'] === 'd') {
                return true;
            }
            if (this.permissions['U'] === false && this.row['dbAction'] !== 'a') {
                return true;
            }
            
        }
        return false;
    }
}
