// $Id$
import { Component, OnInit, Input, ViewChild, TemplateRef, AfterContentInit, EventEmitter } from '@angular/core';
import { IstComboBoxComponent } from '../components/ist-combobox-component';
import { DataTableColumnComponent, CustomRenderer } from '../components/data-table-column.component';
import { LabelsAndValues } from '../common/labels-and-values';

@Component({
    selector: 'ist-currcode-dropdown-column-renderer',
    template: `<ist-combobox  [(selectedValue)]="value" [dataProvider]="dataProvider"
                    (onSelectedValueChange)="propagateChangedRow($event)" isDisabled="isDisabled()"></ist-combobox>`
})

export class IstCurrcodeDropDownColumnRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {
    constructor() {
        super();
        //  console.log('(IstCurrcodeDropDownColumnRenderer constructor())');
    }

    public dataProvider: LabelsAndValues = new LabelsAndValues();
    ngOnInit() {
        //  console.log('(IstDropDownColumnRendererComponent onInit())');
    }

    ngAfterContentInit() {
        //  console.log('(IstDropDownColumnRendererComponent ngAfterContentInit())');
    }

    isDisabled(): Boolean {
        if ((this.row['dbAction'] === 'x' || this.row['dbAction'] === 'c') && this.column.editable === false) {
            return true;
        }
        if (this.row['inactive'] !== null && this.row['inactive'].toLowerCase() === 'Y') {
            return true;
        }
        if (this.row['dbAction'] === 'd') {
            return true;
        }
        if (this.permissions['U'] === false && this.row['dbAction'] !== 'a') {
            return true;
        }
    }

    propagateChangedRow(selectedValue) {
        this.value = selectedValue;
        //  console.log('Propagate changed value: ', this.value);
        this.onSelectedRowChange.next(this.value);
    }
}
