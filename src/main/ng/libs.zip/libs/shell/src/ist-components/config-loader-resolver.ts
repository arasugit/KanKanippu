// $Id$
import { Injectable } from '@angular/core';
import { GlobalsService } from '../services/globals.service';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs';
import { ActivatedRouteSnapshot } from '@angular/router';


@Injectable()
export class ConfigLoaderResolver implements Resolve<boolean> {
  constructor(private globalsService: GlobalsService) {}
  resolve(route: ActivatedRouteSnapshot): Observable<boolean> {
    return this.globalsService.loadConfig();
  }
}
