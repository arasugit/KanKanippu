export class CommandList {
    public static get mbc_clearmsg(): string { return 'mbcmd clear queue'; }
    public static get mbc_options_flag(): string { return 'mbc_options_flag'; }
    public static get mbc_trace(): string { return 'mbc_trace'; }
    public static get mbc_show_throttle(): string { return 'mbc_show_throttle'; }
    public static get mbc_set_throttle(): string { return 'mbc_set_throttle'; }
    public static get mbc_convert2dp(): string { return 'mbc_convert2dp'; }
    public static get mbc_convert2mb(): string { return 'mbc_convert2mb'; }
    public static get mbc_mb_list(): string { return 'mbox_list'; }
    public static get mbc_shutdown_mbox(): string  { return 'mbcmd shutdown_mbox'; }
    public static get mbc_debug_on(): string { return 'mbc_debug_on'; }

    // SHC Ext BIN Load
    public static get shcextbinload(): string { return 'shcextbinload -l '; }
    public static get shcextbinload_r(): string { return 'shcextbinload -r '; }
    public static get shcextbinupdate(): string { return 'shcextbinload -p '; }

    public static get mbc_addr_info(): string { return 'mbc_addr_info'; }
    public static get mbc_count(): string { return 'mbc_count'; }
    public static get mbc_volume(): string { return 'mbc_volume'; }
    public static get mbc_options(): string { return 'mbc_options'; }
    public static get mbc_clear_stats(): string { return 'mbc_clear_stats'; }
    public static get mbc_clearallmsg(): string { return 'mbc_clearallmsg'; }
    public static get mbc_showdp_info(): string { return 'mbc_showdp_info'; }
    public static get mbc_subscribe(): string { return 'mbc_subscribe'; }
    public static get mbc_unsubscribe(): string { return 'mbc_unsubscribe'; }
    public static get mbc_debug(): string { return 'mbcmd_debug'; }
    public static get mbc_debug_off(): string { return 'mbc_debug_off'; }
    public static get mbc_buffers(): string { return 'mbc_buffers'; }
    public static get mbc_wait_time(): string { return 'mbc_wait_time'; }
    public static get mbc_createmb(): string { return 'mbc_createmb'; }
    public static get mbc_deletemb(): string { return 'mbc_deletemb'; }
    public static get mbc_create2dp(): string { return 'mbc_create2dp'; }
    public static get mbc_up_time(): string { return 'mbc_up_time'; }

    // Event Manager - Commands
    public static get event_list(): string { return 'event_list'; }
    public static get mbc_removeevents(): string { return 'mbcmd clear event'; }

    // Shared Memory Manager - Commands'; }
    public static get istshtablist(): string { return 'istshtablist'; }

    // Task Manager - Commands
    public static get task_list(): string { return 'tskcmd'; }
    public static get stop_task(): string { return  'mbcmd kill'; }
    public static get run_task(): string { return  'mbcmd run'; }
    public static get bounce_task(): string { return  'mbcmd bounce '; }

    // APM Task Manager - Commands
    public static get istapmcmd_list(): string { return 'istapmcmd list'; }
    public static get oas_restart(): string { return 'oascmd restart'; }
    public static get oas_shutdown(): string { return 'oascmd shutdown'; }
    public static get oas_suspend(): string { return 'oascmd suspend'; }
    public static get oas_resume(): string { return 'oascmd resume'; }
    public static get apm_start(): string { return 'istapmcmd start'; }
    public static get apm_terminate(): string { return 'istapmcmd terminate'; }
    public static get apm_runup(): string { return 'istapmcmd runup'; }

    // Shared Memory Table Manager - Commands
    public static get mbrule_list(): string { return 'mbrulecmd list'; }
    public static get mbrulecmd_update(): string { return 'mbrulecmd update'; }
    public static get shtab_list(): string { return 'istshtablist'; }
    public static get vertab_list(): string { return 'istvertabcmd list'; }
    public static get vertabcmd_create(): string { return 'istvertabcmd create'; }
    public static get vertabcmd_delete(): string { return 'istvertabcmd delete'; }
    public static get vertabcmd_add(): string { return 'istvertabcmd add'; }
    public static get vertabcmd_remove(): string { return 'istvertabcmd remove'; }
    public static get vertabcmd_update(): string { return 'istvertabcmd update'; }

    // Trace Manager - Commands
    public static get otrace_list(): string { return 'otracecmd list'; }
    public static get mbc_trace_mailbox(): string { return 'mbcmd trace mailbox'; }
    public static get mbport_trace(): string { return 'mbportcmd trace'; }
    public static get cmmt_traceinfo(): string { return 'cmmtcmd'; }
    public static get otrace_default(): string { return 'otracecmd default'; }
    public static get otrace_add(): string { return 'otracecmd new'; }
    public static get otrace_update(): string { return 'otracecmd set'; }
    public static get otrace_add_attrib(): string { return 'otracecmd add'; }
    public static get otrace_remove_attrib(): string { return 'otracecmd remove'; }
    public static get oas_debug_on(): string { return 'oascmd debugon '; }
    public static get oas_debug_off(): string { return 'oascmd debugoff'; }
    public static get mbport_tracelevel(): string { return 'mbportcmd trace'; }
    public static get dbm_debug_on(): string { return 'dbmcmd debugon'; }
    public static get dbm_debug_off(): string { return 'dbmcmd debugoff'; }
    public static get security_debug_on(): string { return 'securitycmd debugon'; }
    public static get security_debug_off(): string { return 'securitycmd debugoff'; }
    public static get cmmt_tracelevel(): string { return 'cmmtcmd'; }
    public static get cmmt_tracearchive(): string { return 'cmmtcmd'; }
    public static get apm_trace(): string { return 'istapmcmd trace'; }

    // System Information
    public static get sysinfo_list(): string { return 'sysinfocmd list'; }
    public static get sysinfo_setstatus_dswitch_on(): string { return 'sysinfocmd set dSwitch ON'; }
    public static get sysinfo_setstatus_dswitch_off(): string { return 'sysinfocmd set dSwitch OFF'; }
    public static get sysinfo_setstatus_lm_on(): string { return 'sysinfocmd set LM ON'; }
    public static get sysinfo_setstatus_lm_off(): string { return 'sysinfocmd set LM OFF'; }

    // Fraud Information
    public static get fm_list(): string { return 'fmcmd list'; }
    public static get fm_request(): string { return 'fmcmd request'; }

    // Advice Manager
    public static get istadvice_setstatus(): string { return 'istadvicecmd set'; }
    public static get istadvice_interval(): string { return 'istadvicecmd interval'; }
    public static get istadvice_show(): string { return 'istadvicecmd show'; }
    public static get istadvice_transmit(): string { return 'istadvicecmd transmit'; }
    public static get istadvice_percent(): string { return 'istadvicecmd percent'; }
    public static get istadvice_replay(): string { return 'istadvicecmd replay'; }
    public static get istadvice_forward(): string { return 'istadvicecmd forward'; }
    public static get istadvice_list(): string { return 'istadvicecmd list'; }

    // Port Manager-CMMT List Buttons' Commands
    public static get cmmt_runtime(): string { return 'cmmt_runtime'; }
    public static get cmmt_addport(): string { return 'cmmt_addport'; }
    public static get cmmt_clearport(): string { return 'cmmtcmd -c remove '; }
    public static get cmmt_clearremove(): string { return 'cmmt_clearremove'; }
    public static get cmmt_resetport(): string { return 'cmmt_resetport'; }
    public static get cmmt_shutdown(): string { return 'cmmt_shutdown'; }
    public static get cmmt_startport(): string { return 'cmmt_startport'; }
    public static get cmmt_configinfo(): string { return 'cmmt_configinfo'; }
    public static get cmmt_configfiledisp(): string { return 'cmmt_configfiledisp'; }
    public static get cmmt_configfileinfo(): string { return 'cmmt_configfileinfo'; }
    public static get cmmt_dllinfo(): string { return 'cmmtcmd  -c dll'; }
    public static get cmmt_plugininfo(): string { return 'cmmtcmd  -c plugin'; }
    public static get cmmt_statusinfo(): string { return 'cmmt_statusinfo'; }
    public static get cmmt_statsinfo(): string { return 'cmmt_statsinfo'; }
    public static get cmmt_utilinfo(): string { return 'cmmt_utilinfo'; }
    public static get cmmt_list(): string { return 'cmmtcmd -c list'; }

    // Port Manager-MBPORT List Buttons' Commands
    public static get mbport_list(): string { return 'mbportcmd list'; }
    public static get mbport_stop(): string { return 'mbportcmd stop '; }
    public static get mbport_start(): string { return 'mbportcmd start '; }
    public static get mbport_toggletrace(): string { return 'port_traceoff|'; }
    public static get mbport_list_addr(): string { return 'mbportcmd list -a'; }
    public static get mbport_add(): string { return 'mbportcmd add port'; }
    public static get mbport_add_server(): string { return 'mbportcmd add server'; }
    public static get mbport_flags(): string { return 'mbportcmd flags '; }
    public static get mbport_nodelist(): string { return 'mbportcmd nodes'; }
    public static get mbport_proc_list(): string { return 'mbportcmd proc'; }
    public static get mbport_reconnect(): string { return 'mbportcmd reconnect '; }
    public static get mbport_setaddress(): string { return 'mbportcmd set address '; }
    public static get mbport_setflag(): string { return 'mbportcmd update '; }
    public static get mbport_unsetflag(): string { return 'mbportcmd update '; }
    public static get cmmt_stopport(): string { return 'cmmtcmd '; }

    // Security Manager
    public static get security_list(): string { return 'securitycmd list'; }
    public static get security_diag(): string { return 'securitycmd diag'; }
    public static get security_genivmfk(): string { return 'securitycmd genivmfk'; }

    // POS Manager
    public static get pos_list(): string { return 'pos_cmd list'; }
    public static get pos_dump_on(): string { return 'pos_dump_on'; }
    public static get pos_dump_off(): string { return 'pos_dump_off'; }
    public static get pos_close(): string { return 'pos_cmd close '; }
    public static get pos_extract(): string { return 'pos_extract '; }
    public static get pos_dispatcher(): string { return 'dispatcher'; }
    public static get pos_tc57(): string { return 'ext_format '; }
    public static get pos_ocs(): string { return 'ext_format '; }
    public static get rec_format(): string { return 'rec_format '; }

    // Institution Manager
    public static get shccmd_list(): string { return 'shccmd list'; }
    public static get shc_routeset(): string { return 'shccmd routeset'; }
    public static get shc_update_node(): string { return 'shccmd update'; }
    public static get shc_show_throttle(): string { return 'shccmd throttlelist'; }
    public static get shc_set_down(): string { return 'shccmd set down'; }
    public static get shc_set_up(): string { return 'shccmd set up'; }
    public static get shc_routeupdate(): string { return 'shccmd routeupdate'; }
    public static get shc_acknodeupdate(): string { return 'shccmd acknodeupdate'; }
    public static get shc_instprofile(): string { return 'profile_inst_update'; }
    public static get shc_list_instprofile(): string { return 'shccmd -m instprofile'; }
    public static get shc_routesend(): string { return 'shccmd routesend'; }
    public static get shc_newnode(): string { return 'shccmd newnode'; }
    public static get shc_trace(): string { return 'shccmd trace'; }
    public static get shc_reconcile(): string { return 'shccmd reconcile'; }
    public static get shc_saf(): string { return 'shccmd saf'; }
    public static get shc_shutdownnode(): string { return 'shccmd shutdownnode'; }
    public static get shcready(): string { return 'shccmd ready'; }
    public static get shc_cutover(): string { return 'shccmd cutover'; }
    public static get shc_netcode(): string { return 'shccmd send'; }
    public static get shc_flags(): string { return 'shccmd flags'; }
    public static get shc_keys(): string { return 'shccmd -m keys'; }
    public static get shc_echo(): string { return 'shccmd echo'; }
    public static get shc_acq_update(): string { return 'profile_acq_update'; }
    public static get shc_issuer_update(): string { return 'profile_iss_update'; }
    public static get shc_inst_update(): string { return 'shccmd update'; }
    public static get shc_replay(): string { return 'shccmd replay'; }
    public static get shc_update_bin(): string { return 'shccmd update'; }
    public static get shc_update_bin_all(): string { return 'shccmd update all'; }
    public static get shc_entity_down(): string { return 'shccmd instset'; }
    public static get shc_entity_up(): string { return  'shccmd instset'; }
    public static get shc_update_inst_bin(): string { return  'shccmd update'; }


    // ATM Manager
    public static get load_state(): string { return 'load state'; }
    public static get load_fit(): string { return 'load fit'; }
    public static get load_screen(): string { return 'load screen'; }
    public static get init_device(): string { return 'load all'; }
    public static get show_status(): string { return 'show status'; }
    public static get show_fitness(): string { return 'show status'; }
    public static get out_of_service(): string { return 'go out service'; }
    public static get load_misc(): string { return 'load misc'; }
    public static get clear_all(): string { return 'clear status'; }
    public static get clear_fitness(): string { return 'clear fitness'; }
    public static get load_key(): string { return 'load key'; }
    public static get go_in_service(): string { return 'go in service'; }
    public static get atm_update(): string { return 'atm_update|'; }
    public static get atm_load_mac(): string { return 'atm_load_mac|'; }
    public static get atm_load_selmac(): string { return 'atm_load_selmac|'; }

    // Messsage & Error Distribution Statistics
    public static get mon_stat(): string { return 'mon_stat'; }

    // Cctcmd Manager
    public static get cct_cfg(): string { return 'cctcmd cfg'; }
    public static get cct_force(): string { return 'cctcmd force'; }
    public static get cct_list(): string { return 'cctcmd list'; }
    public static get cct_monitor(): string { return 'cctcmd monitor'; }
    public static get cct_reinit(): string { return 'cctcmd reinit'; }

    // icmcmd Manager
    public static get icm_help(): string { return 'icmcmd help'; }
    public static get icm_list(): string { return 'icmcmd list'; }
    public static get icm_send(): string { return 'icmcmd send'; }
    public static get icm_profile(): string { return 'icmcmd profile'; }
    public static get icm_extrncounts(): string { return 'icminfocmd'; }
    public static get icm_rtf(): string { return 'mbrulecmd update rtfilters'; }
    public static get icm_excl_reload(): string { return 'mbrulecmd update exclusions reload'; }
    public static get icm_excl_refresh(): string { return 'mbrulecmd update exclusions refreseh'; }
    public static get icm_excl_info(): string { return 'mbrulecmd update exclusions info'; }
    public static get icm_quit(): string { return 'icmcmd quit'; }
    public static get Icmfi_init_load(): string { return 'Icmfi_init_load'; }
    public static get Icmaffinity_init_load(): string { return 'Icmaffinity_init_load'; }
    public static get Icmbin_init_load(): string { return 'Icmbin_init_load'; }

    // ICM SAF Commands
    public static get icmsaf_clear(): string { return 'icmsafcmd clear '; }
    public static get icmsaf_info(): string { return 'icmsafcmd info '; }
    public static get icmsaf_list(): string { return 'icmsafcmd list'; }
    public static get icmsaf_monitor(): string { return 'icmsafcmd monitor '; }
    public static get icmsaf_set(): string { return 'icmsafcmd set '; }
    public static get icmsaf_show(): string { return 'icmsafcmd show '; }
    public static get icmsaf_dump(): string { return 'icmsafcmd dump '; }

    // SDI File Commands
    public static get conv2tsfCmd(): string { return 'conv2tsf '; }

    // DJFA Commands
    public static get djfa_stat(): string { return 'DjfaCmd stat '; }
    public static get djfa_debug(): string { return 'DjfaCmd debug '; }
    public static get djfa_list(): string { return 'DjfaCmd list '; }
    public static get djfa_node(): string { return 'DjfaCmd node '; }
    public static get djfa_skiprec(): string { return 'DjfaCmd skiprec '; }
    public static get djfa_subsys(): string { return 'DjfaCmd susbystem '; }
    public static get djfa_takeover(): string { return 'DjfaCmd takeover '; }

    // POS TMK
    public static get gen_rsa_pair(): string { return 'pos_cmd gen_rsa_pair'; }
    public static get set_tki(): string { return 'pos_cmd set_tki'; }

}
