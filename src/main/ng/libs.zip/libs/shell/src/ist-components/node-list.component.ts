// $Id$
import { ChangeDetectorRef, Component, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatLegacyDialogRef as MatDialogRef} from '@angular/material/legacy-dialog';
import { MonitorRadioButtonColumnRendererComponent } from './monitor-radio-column.renderer.component';
import { Criteria } from '../common/criteria';
import { CommonConstants } from '../common/ist.common.constants';
import { LabelsAndValues } from '../common/labels-and-values';
import { RendererItem } from '../components/data-table-column.component';
import { MonitorCheckBoxColumnRendererComponent } from './monitor-checkbox-column.renderer.component';
import { FormBusinessService } from '../services/formbusiness.service';
import { GlobalsService } from '../services/globals.service';
import { WorkRequest } from './work-request-model';
import { CommandList } from './command-list';

@Component({
  selector: 'ist-manager-window',
  templateUrl: 'node-list.component.html'
})
export class NodeListComponent implements OnInit {
  public nodeListForm: FormGroup;
  
  @Input() manager: string;
  @Input() command: string;
  @Input() execLevel: number; // 0-All Nodes, 1 - Only one Node and 2 - One or more node
  @Input() isTable: boolean;
  @Input() logAudit: boolean;
  @Input() authId: string;
  @Input() nodeType: string;
  @Input() assignedNode: string;
  @Input() isParametersAvailable: boolean;
  @Input() commandList: any[];
  @Input() methodName: string;
  @Input() selectedFileName: string;
  @Input() isCustomCommand: boolean;
  @Output() displayATMUnitResult: string;
  @Output() selectedNode: string;
  @Output() selectedSite: string;
  @Input() volLicCmd: any[];
  @Input() command_name: string;
  commandResultList = [];
  volnodename;
  constructor(
    private globals: GlobalsService,
    public dialogRef: MatDialogRef<any>,
    private fb: FormBuilder,   
    private mformService: FormBusinessService,    
    private changeDetector: ChangeDetectorRef
  ) { }
  hasResult: boolean;
  isAllNode: boolean;
  siteId: string;
  nodeName: string;
  nodeId: string;
  internalHostName: string;
  externalHostName: string;
  portNodAgt: number;
  execLevelStr: string;
  proceedToExecute: boolean;
  commandResponse: LabelsAndValues = new LabelsAndValues();
  radioRenderer: RendererItem = new RendererItem(MonitorRadioButtonColumnRendererComponent);
  checkRenderer: RendererItem = new RendererItem(MonitorCheckBoxColumnRendererComponent);
  length = 0;
  isLoadingResults: boolean;
  workRequest: WorkRequest;
  result = '';
  more = '';
  criteria: Criteria = {};
  nodeResultStatus: string;
  nodeResult: string;
  dataProvider = [];
  dataProviderFiltered = [];
  selected: any; // This is used to get the selected rows in the datagrid
  genSelected: any;
  balSelected: any;
  schDate: string;
  nodeList = [];
  ngOnInit() {
    // console.log('Initiating Node List Component');
    this.dialogRef.updateSize('80%', '80%');
    this.createForm();
    if (!this.isParametersAvailable) {
      this.getNodeList();
    }
    if (this.execLevel === 0) {
      this.execLevelStr = 'All nodes';
    } else if (this.execLevel === 1) {
      this.execLevelStr = 'Only one node';
    } else if (this.execLevel === 2) {
      this.execLevelStr = 'One or more nodes';
    } else {
      this.execLevelStr = 'Invalid execution level';
    }
    // console.log('Node List Component ready with parameters');
  }

  // generate form
  createForm() {
    this.nodeListForm = this.fb.group({
    });
  }

  getNodeList(): void {
    // console.log('Sending Node Record list request...');
    this.mformService.loadData(true).subscribe(
      x => this.onGotRecords(x),
      error => this.onErrorGotRecords(error),
      () => this.onCompleteGotRecords()
    );
  }

  onGotRecords(wr: WorkRequest): void {
    this.workRequest = new WorkRequest();
    this.workRequest = wr;
    this.length = wr.total;
    this.getNodeListCollection(wr);
    this.getNodeStatusForEachNode();
  }

  onErrorGotRecords(error: Object): void {
    // console.log('Could not fetch data from database: ' + JSON.stringify(error, null, 2));
    // this.dataTableComponent.isLoadingResults = false;
  }

  onCompleteGotRecords(): void {
    // this.dataTableComponent.isLoadingResults = false;
    this.changeDetector.detectChanges();
  }

  getNodeStatusForEachNode(): void {
    let siteid: string;
    let nodename: string;
    let hostname: string;
    let port: string;
    let nodeid: string;
    let nodetype: string;
    let nodeMatched: boolean;
    this.dataProviderFiltered = [];
    this.dataProvider.forEach(element => {      
      siteid = '' + element.siteId;
      nodename = element.nodeName;
      if (nodename === this.assignedNode) {
        nodeMatched = true;
        element.select = 'y';
      }
      hostname = element.externalHostName;
      port = '' + element.portNodagt;
      nodeid = '' + element.nodeId;
      nodetype = element.nodeType;
      this.mformService.getNodeStatus('isNodeConnected', siteid, nodeid,
        hostname, nodename, port, nodetype, '', '', true)
        .subscribe((x: any) => {
          element.nodeStatus = x[0].STATUS;
          element.commandResultList = [];
          if (this.commandList !== undefined && this.commandList.length === 1) {
            if (this.commandList[0] === 'iststartup.sh') {
              if (element.nodeStatus === 'Down' || element.nodeStatus === 'down') {
                this.dataProviderFiltered.push(element);
              }
            } else {
              if (element.nodeStatus === 'Up') {
                this.dataProviderFiltered.push(element);
              }
            }
          } else {
            if (element.nodeStatus === 'Up') {
              this.dataProviderFiltered.push(element);
            }
          }
        
        });
    });
    if (this.assignedNode !== undefined && !nodeMatched) {
      this.globals.showDialog(CommonConstants.INFORMATION,
        'Please select any node to send the command', CommonConstants.ALERT_OK);
    }
  }

  sendCommand(): void {
    // get parameters to send command to nodeagt from the node list data grid
    if (this.commandList !== undefined && this.commandList.length > 0) {
      this.sendCommandListToSelectedNodes();
      return;
    }
    // console.log('Sending Command to execute...');
    // console.log('Request parameters: ', this.command, this.nodeName, this.isTable, this.logAudit, this.authId);
    this.mformService.sendCommandService('getCommandResult', this.nodeName, this.command,
      this.isTable, this.logAudit, this.authId)
      .subscribe((x: LabelsAndValues) => { this.commandResponse = x; });
    // console.log('Command Response: ', this.commandResponse);
  }
  sendCommandListToSelectedNodes(): void {
    // console.log('Sending Command List to execute...');
    // console.log('Request parameters: ', this.commandList, this.nodeName, this.isTable, this.logAudit, this.authId);
    
  }
  // to be added only for Maintain ATM Unit manager
  sendATMCommand(): void {
    if (this.execLevel === 0) {
      this.globals.showDialog(CommonConstants.INFORMATION, 'Are you sure to execute the command to all available nodes?',
        CommonConstants.ALERT_YES_NO).subscribe(result => {
          if ('Yes' === result) {
            this.proceedToExecute = true;
            this.selected = this.dataProviderFiltered;
            // console.log('The command will be sent to all available nodes');
            this.sendingCommandAfterConfirmation();
          } else {
            this.proceedToExecute = false;
          }
        });
    } else if (this.execLevel === 1) {
      if (this.selected === undefined || this.selected.length === 0) {
        this.globals.showDialog(CommonConstants.INFORMATION,
          'Please select any node to send the command', CommonConstants.ALERT_OK);
          return;
      }
      this.globals.showDialog(CommonConstants.INFORMATION, 'Are you sure to execute the command to available selected node?',
        CommonConstants.ALERT_YES_NO).subscribe(result => {
          if ('Yes' === result) {
            this.proceedToExecute = true;
            // console.log('The command will be sent to available selected node');
            this.sendingCommandAfterConfirmation();
          } else {
            this.proceedToExecute = false;
          }
        });
    } else if (this.execLevel === 2) {
      if (this.selected === undefined || this.selected.length === 0) {
        this.globals.showDialog(CommonConstants.INFORMATION,
          'Please select any node to send the command', CommonConstants.ALERT_OK);
          return;
      }
      this.globals.showDialog(CommonConstants.INFORMATION, 'Are you sure to execute the command to available selected node(s)?',
        CommonConstants.ALERT_YES_NO).subscribe(result => {
          if ('Yes' === result) {
            this.proceedToExecute = true;
            // console.log('The command will be sent to available selected node(s)');
            this.sendingCommandAfterConfirmation();
          } else {
            this.proceedToExecute = false;
          }
        });
    } else {
      this.execLevelStr = 'Invalid execution level';
    }

    if (this.proceedToExecute === false) {
      return; // cannot execute the command since user selected No to execute
    }
  }

  sendingCommandAfterConfirmation(): void {
    // get parameters to send command to nodeagt from the node list data grid
    // console.log('Sending ATM Command to execute...');
    let siteid: string;
    let nodename: string;
    let hostname: string;
    let port: string;
    let nodeid: string;
    let nodetype: string;
    // console.log('Request parameters: ', this.command, this.nodeName, this.isTable, this.logAudit, this.authId);
    if (!this.hasResult) {
      this.hasResult = true;
    } else {
      this.hasResult = false;
    }
    for (let i = 0; i < this.selected.length; i++) {
      const element = this.selected[i];
      {
        // console.log(element);
        siteid = '' + element.siteId;
        nodename = element.nodeName;
        hostname = element.externalHostName;
        port = '' + element.portNodagt;
        nodeid = '' + element.nodeId;
        nodetype = element.nodeType;
        element.reqStatus = 'Request is sent';
        element.respStatus = 'Waiting for response';
        if (element.nodeStatus === 'Up' || element.nodeStatus === 'up') {
          if (this.authId === 'createMstrKey' || this.authId === 'convertMstrKey'
            || this.authId === 'changeMstrKey' || this.authId === 'propMstrKey') {
            this.mformService.getTokMasCommands('getTokMasCommands', nodename,
              true, this.authId)
              .subscribe((x: any) => {
                // console.log('Response for the node, ', nodename, ': ', x);
                element.commandResultList.push({'command': this.command, 'result': x});
                element.responseMsg = x;
                element.respStatus = 'Received response';
              });
          } else if (this.authId === 'mb_start_stop') {
            this.mformService.sendStartShutdownCommand('getCommandResult', nodename, this.commandList !== undefined?this.commandList[0]:'', false,
              true, this.authId)
              .subscribe((x: any) => {
                // console.log('Response for the node, ', nodename, ': ', x);
                element.responseMsg = x;
                element.commandResultList.push({'command': this.command, 'result': x});
                element.respStatus = 'Received response';
              });
          } else if (this.authId === 'updcurr') {
            for (let j = 0; j < this.commandList.length; j++) {
              this.mformService.sendUpdateCurrencyCommand(this.methodName, nodename, this.commandList[j],
                this.logAudit, this.authId)
                .subscribe((x: LabelsAndValues) => {
                  this.displayATMUnitResult = 'The update request has been sent. Currency information will be refreshed in few seconds!!';
                  element.responseMsg = 'The update request has been sent. Currency information will be refreshed in few seconds!!';
                  element.respStatus = 'Received response';
                  element.commandResultList.push({'command': this.commandList[j], 'result': this.displayATMUnitResult});
                  // console.log('Command Response: ', this.commandResponse);
                });
            }
          } else if (this.authId === 'VolLicenseMng') {
            this.mformService.sendVolumeLicCmd(this.methodName, nodename, this.volLicCmd, this.command_name,
              this.isTable, this.logAudit, this.authId)
              .subscribe((x: string) => {
                this.displayATMUnitResult = x;
                element.commandResultList.push({'command': this.volLicCmd, 'result': this.displayATMUnitResult});
                // console.log('Command Response VolLicenseMngVolLicenseMng--->: ', this.displayATMUnitResult);
              });
          } else if (this.authId === 'upddecpt') {
            this.mformService.sendUpdateCurrencyCommand(this.methodName, nodename, this.command,
              this.logAudit, this.authId)
              .subscribe((x: LabelsAndValues) => {
                this.commandResponse = x;
                element.respStatus = 'Received response';
                this.displayATMUnitResult = 'The update request has been sent. Information will be refreshed in few seconds!!';
                element.responseMsg = 'The update request has been sent. Information will be refreshed in few seconds!!';
                element.commandResultList.push({'command': this.command, 'result': this.displayATMUnitResult});
                // console.log('Command Response: ', this.commandResponse);
              });
          } else if (this.authId === 'shc_cmd') {
            this.nodeList.push(nodename + '|' + nodeid);
            element.respStatus = 'Received response';
          } else if (this.authId === 'set') {
            if (!this.commandList || this.commandList.length === 0) {
              this.mformService.getAdviceManagerCommandResult('getAdviceManagerCommandResult', siteid, nodename,
                this.command, false, true, this.authId).subscribe((x: any) => {
                  this.commandResponse = x;
                  element.respStatus = 'Received response';
                  this.displayATMUnitResult = 'The update request has been sent. Information will be refreshed in few seconds!!';
                  element.responseMsg = 'The update request has been sent. Information will be refreshed in few seconds!!';
                  // console.log('Command Response: ', this.commandResponse);
                });
            } else {
              this.mformService.getAdviceManagerSetIndividual('getAdviceManagerSetIndividual', siteid, nodename,
                CommandList.istadvice_setstatus, this.selectedFileName, this.commandList, false, true, this.authId)
                .subscribe((x: any) => {
                  this.commandResponse = x;
                  element.respStatus = 'Received response';
                  this.displayATMUnitResult = 'The update request has been sent. Information will be refreshed in few seconds!!';
                  element.responseMsg = 'The update request has been sent. Information will be refreshed in few seconds!!';
                  element.commandResultList.push({'command': '', 'result': this.displayATMUnitResult});
                  // console.log('Command Response: ', this.commandResponse);
                });
            }
          } else if (this.isCustomCommand) {
            this.mformService.sendCustomCommand('getCustomCommandResult', nodename, this.commandList[0],
              this.isTable, this.logAudit, this.authId)
              .subscribe((x: any) => {
                // console.log('Response for the node, ', nodename, ': ', x);
                element.responseMsg = x;
                element.commandResultList.push({'command': this.commandList[0], 'result': x});
                element.respStatus = 'Received response';
              });
          } else {
            for (let j = 0; j < this.commandList.length; j++) {
              element.responseMsg = '';
              this.commandResultList = [];
              this.mformService.sendATMCommandService('getAtmCmdResult', nodeid,
               nodename, hostname, port, this.commandList[j], this.isTable, this.authId)
              .subscribe((x: any) => {
                element.responseMsg += this.commandList[j];
                if (x.length === 1) {
                  const result: string = x[0];
                  if (result.includes('ERROR::')) {
                    element.responseMsg += result;
                    element.commandResultList.push({'command': this.commandList[j], 'result': result});
                  } else {
                    element.responseMsg += 'The command was executed,but no response was received.';
                    element.commandResultList.push({'command': this.commandList[j],
                     'result': 'The command was executed,but no response was received.'});
                  }
                } else if (x.length === 2) {
                  element.responseMsg += x[1];
                  element.commandResultList.push({'command': this.commandList[j], 'result': x[1]});
                }
                element.respStatus = 'Received response';
              });
            }
          }
        } else if (element.select === 'y' && (element.nodeStatus === 'Down' || element.nodeStatus === 'down')
          && this.commandList[0] === 'iststartup.sh') {
          this.mformService.sendStartShutdownCommand('getCommandResult', nodename, this.commandList[0], false,
            true, this.authId)
            .subscribe((x: any) => {
              element.responseMsg = x;
              element.respStatus = 'Received response';
              element.commandResultList.push({'command': this.command, 'result': x});
            });
        } else {
          element.reqStatus = 'Request not sent';
          element.respStatus = '';
        }
      }
    }
    if (this.authId === 'shc_cmd') {
      this.nodeList.push(nodename + '|' + nodeid);
      this.mformService.getSchCommandResult('getSchCommandResult',
        this.nodeList, this.schDate, this.command,
        this.balSelected, this.genSelected, false, true, this.authId)
        .subscribe((x: any) => {
          // this.commandResponse = x;
          // this.displayATMUnitResult = x;
          let respArr = [];
          let responseStr: String = '';
          respArr = x[0];
          responseStr += respArr['TSFBalance'][0] + '\n';
          responseStr += respArr['TSFBalance'][1] + '\n';
          responseStr += respArr['TSFUtil'][0] + '\n';
          responseStr += respArr['TSFUtil'][1] + '\n';
          this.globals.showDialog(CommonConstants.INFORMATION,
            responseStr, CommonConstants.ALERT_OK);
        });
      }
  }

  onItemClick(selectedItem: any) {
    if (this.hasResult) {
      this.selectedSite = selectedItem.siteId;
      this.selectedNode = selectedItem.nodeName;
      this.displayATMUnitResult = selectedItem.responseMsg;
      this.commandResultList = selectedItem.commandResultList;
    }
  }
  close() {
    this.dialogRef.close();
  }

  getNodeListCollection(wr: WorkRequest): void {
    this.dataProvider = wr.collections['NODELISTCOL'].rows;
  }

  selectAllNodes(changedEvent: any): void {
    this.selected = [];
    this.workRequest.collections['NODELISTCOL'].rows.forEach(element => {
      // console.log(element);
      if (changedEvent.checked) {
        element.select = 'y';
      } else {
        element.select = 'n';
      }
      this.selected.push(element);
    });
    if (!changedEvent.checked) {
      this.selected = [];
    }
  }

  selectRow(event: any): void {
    // console.log(event);
  }

  selectedNodes(event: any): void {
    // console.log('Selected nodes: ', event);
    if (this.execLevel === 1) {
      this.selected = [];
      this.selected.push(event.row);
    } else if (this.execLevel === 2) {
      const tempRow = [];
      if (event.row !== undefined) {
        if ( this.selected === undefined) {
          this.selected = [];
        }
        if (event.row.checked) {
          this.selected.push(event.row);
        } else {
          if (this.selected !== undefined && this.selected.length > 0) {
            for (let i = 0; i < this.selected.length; i++) {
              const row = this.selected[i];
              if (row.ID !== event.row.ID) {
                tempRow.push(this.selected[i]);
              }
            }
          }
          this.selected = tempRow;
        }
      }
      // console.log('Selected rows: ', this.selected);
    }
  }
}
