// $Id$
import { AfterContentInit, Component, OnInit } from '@angular/core';
import { CustomRenderer } from '../components/data-table-column.component';

@Component({
    selector: 'ist-dropdown-column-renderer',
    template: `<ist-combobox type={{comboBoxType}} [dataProvider]="dataProvider" [fromGlobalValueCtrl]="isGlbVal" [(selectedValue)]="value"
                (onSelectedValueChange)="propagateChangedRow($event)" [optionalField]=false isDisabled="isDisabled()"
                isCellEditor="true"></ist-combobox>`
})

export class IstDropDownColumnRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {
    constructor() {
        super();
        //  console.log('(IstDropDownColumnRendererComponent constructor())');
    }
   
    public isGlbVal: Boolean = false;
    ngOnInit() {
        //  console.log('(IstDropDownColumnRendererComponent onInit())');
    }

    ngAfterContentInit() {
        //  console.log('(IstDropDownColumnRendererComponent ngAfterContentInit())');
    }

    propagateChangedRow(selectedValue) {
        this.value = selectedValue;
        //  console.log('Propagate changed value: ', this.value);
        this.onSelectedRowChange.next(this.value);
    }
}
