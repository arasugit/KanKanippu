import { AfterContentInit, Component, OnInit } from '@angular/core';
import { CustomRenderer } from '../components/data-table-column.component';

@Component({
    selector: 'ist-checkbox-permissions-column-renderer',
    template: `<div fisStyle class="cellEditor-container" fxFlex="100%">
                 <mat-checkbox [checked]="evaluate()" (change)="propagateChangedRow($event)"
                 [disabled]="isDisabled()" [hidden]="hide()" [style.box-shadow]="bgColor"
                 [matTooltip]="toolTip" matTooltipPosition="after"></mat-checkbox>
                </div>`
})

// Checkbox renderer for user and group permissions
export class IstCheckBoxColumnRendererForPermissionsComponent extends CustomRenderer implements OnInit, AfterContentInit {
    bgColor = '';
    toolTip = '';
    perms = ['', '', 'AD', 'AA', 'Q', 'I', 'U', 'D', 'C'];
    constructor() {
        super();
    }
    ngOnInit() {
        //  console.log('(IstCheckBoxColumnRendererForPermissionsComponent onInit())');
    }

    ngAfterContentInit() {
        //  console.log('(IstCheckBoxColumnRendererForPermissionsComponent ngAfterContentInit())');
    }

    evaluate(): Boolean {
        if (this.comboBoxType) {
            if (this.row.checkBoxCollection.indexOf(this.comboBoxType) > -1) {
                const index = this.row.permCollection.indexOf(this.comboBoxType);
                if (index > -1) {
                    const ind = this.perms.indexOf(this.comboBoxType.toString());
                    if (ind > -1) {
                        if (this.row.styleInfoCollection && this.row.styleInfoCollection[ind] === 'mkcCheckBoxStyle') {
                            this.bgColor = 'inset 0 0 40px yellow';
                        } else {
                            this.bgColor = '';
                        }
                        if (this.row.changeInfoCollection) {
                            this.toolTip = this.row.changeInfoCollection[ind];
                        } else {
                            this.toolTip = '';
                        }
                    }
                    return true;
                }
                if (this.row.styleInfoCollection && this.row.changeInfoCollection) {
                    const i = this.row.styleInfoCollection.indexOf('mkcCheckBoxStyle');
                    const ii = this.perms.indexOf(this.comboBoxType.toString());
                    if (i > -1 && i === ii) {
                        this.bgColor = 'inset 0 0 40px yellow';
                        this.toolTip = this.row.changeInfoCollection[i];
                    } else {
                        this.bgColor = '';
                        this.toolTip = '';
                    }
                }
            }
        }
        return false;
    }

    hide(): Boolean {
        if (this.comboBoxType) {
            if (this.row.checkBoxCollection.indexOf(this.comboBoxType) > -1) {
                return false;
            } else if (this.comboBoxType === 'C' && this.row.checkBoxCollection.indexOf('CD') > -1) {
                return false;
            }
        }
        return true;
    }

    propagateChangedRow(event) {
        const selectedValue = event.checked;
        if (this.comboBoxType) {
            this.value = this.comboBoxType;
            if (this.comboBoxType === 'AA') {
                if (selectedValue) {
                    if (this.row.permCollection.indexOf(this.value) === -1) {
                        this.row.permCollection.push(this.value);
                    }
                    if (this.row.checkBoxCollection.indexOf('AD') > -1) { // Class 83 & 95 have only Access allow
                        if (this.row.permCollection.indexOf('AD') > -1) {
                            this.row.permCollection.splice(this.row.permCollection.indexOf('AD'), 1);
                        }
                    }
                    if (this.row.entClassId === 5 || this.row.entClassId === 3) {
                        if (this.row.checkBoxCollection.indexOf('Q') > -1) {
                            if (this.row.permCollection.indexOf('Q') === -1) {
                                this.row.permCollection.push('Q');
                            }
                        }
                        if (this.row.checkBoxCollection.indexOf('I') > -1) {
                            if (this.row.permCollection.indexOf('I') === -1) {
                                this.row.permCollection.push('I');
                            }
                        }
                        if (this.row.checkBoxCollection.indexOf('U') > -1) {
                            if (this.row.permCollection.indexOf('U') === -1) {
                                this.row.permCollection.push('U');
                            }
                        }
                        if (this.row.checkBoxCollection.indexOf('D') > -1) {
                            if (this.row.permCollection.indexOf('D') === -1) {
                                this.row.permCollection.push('D');
                            }
                        }
                    }
                } else {
                    if (this.row.permCollection.indexOf(this.value) > -1) {
                        this.row.permCollection.splice(this.row.permCollection.indexOf(this.value), 1);
                    }
                    this.value = '';
                    if (this.row.entClassId === 5 || this.row.entClassId === 3) {
                        if (this.row.permCollection.indexOf('Q') > -1) {
                            this.row.permCollection.splice(this.row.permCollection.indexOf('Q'), 1);
                        }
                        if (this.row.permCollection.indexOf('I') > -1) {
                            this.row.permCollection.splice(this.row.permCollection.indexOf('I'), 1);
                        }
                        if (this.row.permCollection.indexOf('U') > -1) {
                            this.row.permCollection.splice(this.row.permCollection.indexOf('U'), 1);
                        }
                        if (this.row.permCollection.indexOf('D') > -1) {
                            this.row.permCollection.splice(this.row.permCollection.indexOf('D'), 1);
                        }
                    }
                }
            } else if (this.comboBoxType === 'AD') {
                if (selectedValue) {
                    if (this.row.checkBoxCollection.indexOf(this.value) > -1) {
                        if (this.row.permCollection.indexOf(this.value) === -1) {
                            this.row.permCollection.push(this.value);
                        }
                    }
                    if (this.row.permCollection.indexOf('AA') > -1) {
                        this.row.permCollection.splice(this.row.permCollection.indexOf('AA'), 1);
                    }
                    if (this.row.entClassId === 5  || this.row.entClassId === 3) {
                        if (this.row.permCollection.indexOf('Q') > -1) {
                            this.row.permCollection.splice(this.row.permCollection.indexOf('Q'), 1);
                        }
                        if (this.row.permCollection.indexOf('I') > -1) {
                            this.row.permCollection.splice(this.row.permCollection.indexOf('I'), 1);
                        }
                        if (this.row.permCollection.indexOf('U') > -1) {
                            this.row.permCollection.splice(this.row.permCollection.indexOf('U'), 1);
                        }
                        if (this.row.permCollection.indexOf('D') > -1) {
                            this.row.permCollection.splice(this.row.permCollection.indexOf('D'), 1);
                        }
                    }
                } else {
                    if (this.row.permCollection.indexOf(this.value) > -1) {
                        this.row.permCollection.splice(this.row.permCollection.indexOf(this.value), 1);
                    }
                    this.value = '';
                }
            } else {
                if (selectedValue) {
                    if (this.row.checkBoxCollection.indexOf(this.value) > -1) {
                        if (this.row.permCollection.indexOf(this.value) === -1) {
                            this.row.permCollection.push(this.value);
                        }
                    }
                } else {
                    if (this.row.permCollection.indexOf(this.value) > -1) {
                        this.row.permCollection.splice(this.row.permCollection.indexOf(this.value), 1);
                    }
                    this.value = '';
                }
            }
        }
        //  console.log('Propagate changed value: ', this.value);
        this.onSelectedRowChange.next(this.value);
    }

    isDisabled(): Boolean {
        const flg = super.isDisabled();
        if (flg) {
            return flg;
        }
        if (this.row !== undefined) {
           
            if (this.comboBoxType === 'C') {
                if (this.row.checkBoxCollection.indexOf('CD') > -1) {
                    return true;
                }
            }
            // Access deny is checked then disable other options.
            if (this.comboBoxType !== 'AD' && this.comboBoxType !== 'AA' && this.comboBoxType !== 'C'
                 && this.row.permCollection.indexOf('AD') > -1) {
                return true;
            }
        }
        return false;
    }
}
