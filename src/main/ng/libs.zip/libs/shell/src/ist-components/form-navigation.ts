// $Id$
import {Router, ActivatedRouteSnapshot, UrlSegment} from '@angular/router';

export class FormCallingStackEntry {
    constructor(public url: string, public command_key: string, public breadcrumbText: string) {
    }
}
export class FormCallingStack {
    arr: FormCallingStackEntry[] = [];
    callingForm = false;
    returningFromForm = false;
    commands = {};
    command_counter = 0;
    public clear() {
        this.arr = [];
        this.callingForm = false;
        this.returningFromForm = false;
        this.commands = {};
    }
}

export class FormNavigator {
    public static returnFromForm(stack: FormCallingStack, router: Router, changed: boolean) {
        if (stack.arr.length <= 0) {
            router.navigate(['']);
            return;
        }
        const se = stack.arr.pop();
        console.log('stack pop', se);
        //this.globalsService.stack.commands[se.command_key] as Params;
        const command = {
            COMMAND: 'return',
            changed: changed,
            seq: stack.command_counter++
        };
        // extend the command with the saved state
        //  console.log('returnFromForm, old url = ', se.url);
        stack.returningFromForm = true;
        router.navigate([se.url, command]);
    }
    // this method is added to pass the parameters from detail to List - ex System Generated IDs
    public static returnFromFormWithParams(stack: FormCallingStack, router: Router, changed: boolean,additionalParam?:{}) {
        console.log('returnFromFormWithParams called');
        if (stack.arr.length <= 0) {
            //  console.log('no place to return to');
            router.navigate(['']);
            return;
        }

        const se = stack.arr.pop();
        if (additionalParam === undefined || additionalParam === null) {
        const command = {
            COMMAND: 'return',
            changed: changed,
            seq: stack.command_counter++
        };
       
        stack.returningFromForm = true;
        router.navigate([se.url, command]);
        }
        else {
            let command = {
                COMMAND: 'return',
                changed: changed,
                seq: stack.command_counter++               
            };
            Object.entries(additionalParam).forEach(entry=> {
                let key = entry[0];
                let value = entry[1];
                command[key]=value;
            });
    
            stack.returningFromForm = true;
            router.navigate([se.url, command]);
        }

    }
    public static returnToBreadcrumb(stack: FormCallingStack, router: Router, crumbIndex: number) {
        if (crumbIndex < 0) {
            //  console.log('Internal error, breadcrumb index < 0');
            return;
        }
        const num_to_pop = stack.arr.length - crumbIndex;
        const se = stack.arr[crumbIndex];
        stack.arr = stack.arr.slice(0, crumbIndex);
        const command = {
            COMMAND: 'return',
            changed: false
        };
        
        stack.returningFromForm = true;
        router.navigate([se.url, command]);

    }
    private static makePath(url: UrlSegment[]): string {
        let p = '';
        for (const seg of url) {
            if (seg.path) {
                p = p ? p + '/' + seg.path : seg.path;
            }
        }
        return p;
    }
    public static buildUrl(route: ActivatedRouteSnapshot): string {
        let p = FormNavigator.makePath(route.url);
        for ( ; ; ) {
            route = route.parent;
            if (!route) { break; }
            if (route.url) {
                const p2 = FormNavigator.makePath(route.url);
                if (p && p2) {
                    p = p2 + '/' + p;
                } else if (p2) {
                  p = p2;
                }
            }
        }
        return '/' + p;
    }
    public static clearStack(stack: FormCallingStack): void {
        stack.clear();
    }

}
