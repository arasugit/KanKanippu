import { AfterContentInit, Component, OnInit, ViewContainerRef, ComponentFactoryResolver, Injector, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CustomRenderer } from '../components/data-table-column.component';

@Component({
    selector: 'ist-generic-view-button-column-renderer',
    template: `<ist-button (btnClick)="loadTemplate()" btnLabel="..." isDisabled="isDisabled()"></ist-button>`
})

// Renderer for single record view button in Datatable
export class IstGenericViewButtonColumnRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {
    viewDialogRef: MatDialogRef<any>;
    template: any;
    
    constructor(private dialog: MatDialog, private viewContainerRef: ViewContainerRef,
        private componentFactoryResolver: ComponentFactoryResolver, private injector: Injector) {
        super();
    }

    ngOnInit() {
        if (this.viewButtonTemplate) {
            this.template = this.viewContainerRef.createComponent(this.componentFactoryResolver.resolveComponentFactory(this.viewButtonTemplate), undefined, this.createInjector());
            this.viewContainerRef.clear();
        }
    }

    ngAfterContentInit() {
    }

    propagateChangedRow(event) {

    }

    loadTemplate() {
        if (this.viewButtonTemplate) {
            this.viewDialogRef = this.dialog.open(this.template.componentType, { data: this});
            this.viewDialogRef.updateSize('650px');
            this.viewDialogRef.afterClosed().subscribe(result => {
                this.value = result;
                this.onSelectedRowChange.next(this.value);
            });
        }
    }

    createInjector() {
        return Injector.create({
            providers: [{ provide: MAT_DIALOG_DATA, useValue: this}]
        });
    }
}
