import { Component, OnInit, Input, ViewChild, TemplateRef, HostListener, AfterContentInit } from '@angular/core';
import { CustomRenderer } from '../components/data-table-column.component';
import { IstInputComponent} from '../components/ist-input-component';


@Component({
    selector: 'ist-input-column-renderer',
    template: `<ist-input value={{evaluate()}} isDisabled="isDisabled()"></ist-input>`
})
// Input renderer example for the data table column
export class IstInputColumnRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {
    constructor() {
        super();
        
    }
    ngOnInit() {
       
    }

    ngAfterContentInit() {
       
    }

    propagateChangedRow(selectedValue) {
       
    }

    evaluate(): any {
        try {
            if (this.column.labelFunction) {
                return this.column.labelFunction(this.row, this.column);
            }
            return this.value;
        } catch (e) {
            // Ignore
        }
    }

    isDisabled(): Boolean {
        return true;
    }
}
