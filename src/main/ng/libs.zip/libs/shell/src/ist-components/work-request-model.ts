// $Id$
import {ResponseBase} from '../services/response-base';
export class WorkChoice {
  label = '';
  value = '';
}
export class WorkField {
  public static remoteClassName = 'com.efunds.t21.services.vo.WorkField';
  remoteClass = WorkField.remoteClassName;
  tag = '';
  value = '';
  smartField = '';
  changed = '';
  modifyable = '';
  visible = '';
  errorInfo = '';
  usedByBizRules = '';
  choices: WorkChoice[] = [];
  messageSubstitutions: string[] = [];
  resetWarning = '';
  isDataBindingActive = true;
  label = '';
  dbColumn = '';
  restrict = '';
  editType = '';
  mask = '';
  renderer = '';
  upshift = false;
  oldValue = '';
  style = '';
}

export interface WorkFieldCollection {
  [fieldName: string]: WorkField;
}

export interface WorkCollectionCollection {
  [collectionName: string]: WorkCollection;
}
export class WorkCollection {
  public static remoteClassName = 'com.efunds.t21.services.vo.WorkCollection';
  remoteClass = WorkCollection.remoteClassName;
  tag = '';
  modifyable = '';
  visible = '';
  errorInfo = '';
  rows:any[] = [];
  fields:any[] = [];
  dbMappingAttr: {[attrName: string]: string} = {};
  tabId = '';
  sectionId = '';
}

export class WorkRequest extends ResponseBase {
  public static remoteClassName = 'com.fis.ist.services.vo.WorkRequest';
  remoteClass = WorkRequest.remoteClassName;
  requestTypeId: String;
  fields: WorkFieldCollection = {};
  collections: WorkCollectionCollection = {};
  total = -1;
  lastModified = -1;
  requestId = '';
  // mkc related fields
   mkcId: number;
   mkcRecordAction: string;
   mkcRemarks: string;
   mkcScheduleDt: Date;
   mkcStatus: string;
   makerId: string;
   requestResult:string;
   errorDetail:string;
   messageId:string;
  
}
