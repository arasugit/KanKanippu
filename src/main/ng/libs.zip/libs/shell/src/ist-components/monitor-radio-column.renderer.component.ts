// $Id$
import { AfterContentInit, Component, Input, OnChanges, OnInit } from '@angular/core';
import { CustomRenderer } from '../components/data-table-column.component';

@Component({
    selector: 'app-data-column-radio-renderer',
    template: `<mat-radio-button fisStyle (change)="propagateChangedRow($event)"
                 [name]="id" [disabled]="isDisabled()">{{value}}</mat-radio-button>`
})

export class MonitorRadioButtonColumnRendererComponent extends CustomRenderer implements OnInit,
    OnChanges, AfterContentInit {
    id: any;
    @Input() disable: boolean;
    constructor() {
        super();
    }
    ngOnInit() {
        // console.log('(MonitorRadioButtonColumnRendererComponent onInit()): ');
    }

    ngAfterContentInit() {
        //  console.log('(MonitorRadioButtonColumnRendererComponent ngAfterContentInit()): ');
    }

    ngOnChanges() {
        // console.log('(MonitorRadioButtonColumnRendererComponent onNgChanges()): ');
    }

    propagateChangedRow(event) {
        this.cellClick.emit(this.row);
    }

    isDisabled(): Boolean {
        if (this.row.commandResultList !== undefined) {
            return false;
        } else if (this.row.alarmId !== undefined) {
            return false;
        } else if (this.row.groupLevel === 1 || this.row.groupLevel === 2) {
            return true;
        }
        return false;
    }
}
