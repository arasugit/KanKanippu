import { AfterContentInit, Component, OnInit, Output } from '@angular/core';
import { CustomRenderer } from '../components/data-table-column.component';
import { EventEmitter } from 'events';

@Component({
    selector: 'ist-mon-checkbox-column-renderer',
    template: `<ist-checkbox  [checked]="evaluate()" isCellEditor=true
        (onClicked)="propagateChangedRow($event)" isDisabled="isDisabled()"></ist-checkbox>`
})

export class MonitorCheckBoxColumnRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {
    constructor() {
        super();
    }
    ngOnInit() {
        
    }

    ngAfterContentInit() {
        
    }

    evaluate(): Boolean {
        if (this.row.select !== undefined && typeof this.row.select === 'string') { // for Node List record
            if (this.row.select.toLocaleLowerCase().trim() === 'y' || this.row.select.toLocaleLowerCase().trim() === 'yes') {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    propagateChangedRow(selectedValue) {
        if (selectedValue === true) {
            this.value = 'y';
            this.row.checked = true;
        } else {
            this.value = 'n';
            this.row.checked = false;
        }
        
        this.onSelectedRowChange.next(this.value);
        this.cellClick.emit(this.row);
    }

    isDisabled(): Boolean {
        if (this.row.commandResultList !== undefined) {
            return false;
        } else if (this.row.alarmId !== undefined) {
            return false;
        } else if ((this.row.groupLevel === 1 || this.row.groupLevel === 2) && this.row.taskName !== undefined) {
            return false;
        } else if (this.row.groupLevel === 1 || this.row.groupLevel === 2) {
            return true;
        }
        return false;
    }
}
