import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RufMaterialModule } from '@ruf/material';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CdkTableModule } from '@angular/cdk/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatLegacyCardModule as MatCardModule } from '@angular/material/legacy-card';
import { MatLegacyListModule as MatListModule } from '@angular/material/legacy-list';
import { MatLegacyProgressBarModule as MatProgressBarModule } from '@angular/material/legacy-progress-bar'
import { MatLegacyFormFieldModule as MatFormFieldModule  } from '@angular/material/legacy-form-field';
import { MatLegacyButtonModule as MatButtonModule } from '@angular/material/legacy-button';
import { MatIconModule } from '@angular/material/icon';
import { MatLegacyInputModule as MatInputModule } from '@angular/material/legacy-input';
import { MatLegacyCheckboxModule as MatCheckboxModule } from '@angular/material/legacy-checkbox';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatLegacySlideToggleModule as MatSlideToggleModule } from '@angular/material/legacy-slide-toggle';
import { MatLegacySliderModule as MatSliderModule } from '@angular/material/legacy-slider';
import { MatLegacyTooltipModule as MatTooltipModule } from '@angular/material/legacy-tooltip';
import { MatLegacySelectModule as MatSelectModule } from '@angular/material/legacy-select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatLegacyPaginatorModule as MatPaginatorModule } from '@angular/material/legacy-paginator';
import { MatLegacyTableModule as MatTableModule } from '@angular/material/legacy-table';
import { MatLegacyRadioModule as MatRadioModule } from '@angular/material/legacy-radio';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RufCardModule, RufIconModule, RufLabeledIconModule } from '@ruf/shell';
import { TranslateLazyLoadModule } from './ist-translate-lazyload-module';
import { IstInputColumnRendererComponent } from './ist-input-column.renderer.component';
import { DataTableDetailComponent } from '../components/data-table.detail.component';
import { SearchListComponent } from '../components/base-searchlist-component';
import { IstComboBoxComponent } from '../components/ist-combobox-component';
import { IstDialogComponent } from '../components/ist-dialog-component';
import { IstProgressBarComponent } from '../components/ist-progress-bar-component';
import { IstInputComponent} from '../components/ist-input-component';
import { IstInlineInputComponent} from '../components/ist-inline-input-component';
import { IstButtonComponent} from '../components/ist-button-component';
import { IstInlineComboComponent} from '../components/ist-inline-combo-component';
import { IstCheckBoxComponent} from '../components/ist-checkbox-component'
import { DataTableSearchListDetailComponent }  from '../components/data-table-search-list.component'
import { FormatCurrencyPipe } from '../components/ist-currency-pipe';
import { DataFormatPipe } from '../components/ist-dataFormat-pipe';
import { IstDatePickerComponent } from '../components/ist-datepicker-component';
import { T21RequestComponent } from '../components/t21-request-component';
import { CellEditorDirective } from '../components/cell-editor.directive';
import { CellRendererDirective } from '../components/cell-renderer.directive';
import { DataTableColumnRadioRendererComponent } from '../components/data-table-column.radio.renderer.component';
import { DataTableColumnComponent } from '../components/data-table-column.component';
import { DataTablePaginatorComponent } from '../components/data-table.paginator.component';
import { DataDetailTablePaginatorComponent } from '../components/data-detail-table.paginator.component';
import { DataTableComponent } from '../components/data-table.component';
import { DataTableEditableComponent } from '../components/data-table-editable.component';
import { DataTableEditableDetail2Component} from '../components/data-table-editable-detail2.component'
import { DataTableEditableDetailComponent } from '../components/data-table-editable-detail.component'
import { IstRadioGroupComponent } from '../components/ist-radiogroup-component';
import { IstNumericStepperComponent } from '../components/ist-numeric-stepper-component';
import { IstTextAreaComponent } from '../components/ist-textarea-component';
import { IstSearchInputComponent } from '../components/ist-searchField-component';
import { IstLoadingIndicatorComponent } from '../components/ist-loading-indicator.component';
import { QuerySectionComponent } from '../components/querysection-component';
import { IstSearchListComponent } from '../components/ist-searchlist-component';
import { IstSearchlistInputColumnRendererComponent } from './ist-searchlist-input-column.renderer.component';
import { IstSearchListColumnRendererComponent } from './ist-searchlist-column.renderer.component'
import { IstCheckBoxSearchlistRendererComponent } from './ist-checkbox-searchlist.renderer.component';
import { IstCheckBoxColumnRendererForPermissionsComponent } from './ist-checkbox-column.renderer.permissions.component';
import { IstCheckBoxColumnRendererComponent } from './ist-checkbox-column.renderer.component';
import { IstCurrcodeDropDownColumnRendererComponent } from './ist-currcode-dropdown-column.renderer.component'
import { IstDatePickerColumnRendererComponent } from './ist-datepicker-column.renderer.component'
import { IstDropDownColumnRendererComponent } from './ist-dropdown-column.renderer.component'
import { IstDynamicDropDownColumnRendererComponent } from './ist-dynamic-dropdown-column.renderer.component';
import { IstGenericViewButtonColumnRendererComponent } from './ist-generic-view-button-column.renderer.component';
import { IstMonitorDropDownColumnRendererComponent } from './ist-monitor-dropdown-column.renderer.component'
import { MonitorCheckBoxColumnRendererComponent } from './monitor-checkbox-column.renderer.component';
import { MonitorRadioButtonColumnRendererComponent } from './monitor-radio-column.renderer.component';
import { IstNumberInputComponent } from '../components/ist-number-input-component';
import { InquiryDataTableColumnComponent } from '../components/inquiry-data-table-column.component';
import { InquiryDataTableComponent} from '../components/inquiry-data-table.component'
import { SLDataTableColumnComponent } from '../components/sl-data-table-column.component';
import { SLDataTableComponent} from '../components/sl-data-table.component';
import { DetailComponent } from '../components/base-detail.component';
import { ListComponent } from '../components/base-list.component';
import { MonInputComponent } from '../components/mon-input.component';
import { MonComboBoxComponent } from '../components';
import { MonComboBoxMultiSelectComponent } from '../components/mon-comboboxmultiselect.component';
import { NodeListComponent } from './node-list.component';
import {MatMenuModule} from '@angular/material/menu';
import { IstDatePickerMonthComponent } from '../components/ist-datepicker-month-component';
import { IstInlineDatePickerComponent } from '../components/ist-inline-datepicker-component';
import { IstInlineColNameComponent } from '../components/ist-inline-col-name-components';
@NgModule({
    declarations: [DetailComponent,ListComponent,SLDataTableComponent,SLDataTableColumnComponent,InquiryDataTableComponent,InquiryDataTableColumnComponent,IstNumberInputComponent,DataTableSearchListDetailComponent,DataTableEditableDetail2Component,MonitorRadioButtonColumnRendererComponent,MonitorCheckBoxColumnRendererComponent,
    IstGenericViewButtonColumnRendererComponent,IstDynamicDropDownColumnRendererComponent,IstDropDownColumnRendererComponent,IstDatePickerColumnRendererComponent,IstCurrcodeDropDownColumnRendererComponent,
    IstCheckBoxColumnRendererComponent,IstCheckBoxColumnRendererForPermissionsComponent,IstMonitorDropDownColumnRendererComponent,
    IstCheckBoxSearchlistRendererComponent,IstSearchListColumnRendererComponent,IstSearchlistInputColumnRendererComponent,IstInputColumnRendererComponent,IstLoadingIndicatorComponent,
    CellEditorDirective,CellRendererDirective,SearchListComponent,IstComboBoxComponent,IstDialogComponent,IstProgressBarComponent,IstInputComponent,IstButtonComponent,IstInlineInputComponent,
    IstInlineComboComponent,IstInlineColNameComponent,FormatCurrencyPipe,DataFormatPipe,IstDatePickerComponent,IstInlineDatePickerComponent,IstDatePickerMonthComponent,T21RequestComponent,DataTableColumnComponent,DataTableComponent,
    DataTablePaginatorComponent,DataDetailTablePaginatorComponent,DataTableColumnRadioRendererComponent,IstCheckBoxComponent,IstRadioGroupComponent,IstNumericStepperComponent,IstTextAreaComponent,IstSearchInputComponent,
    DataTableEditableComponent,DataTableEditableDetailComponent,QuerySectionComponent,IstSearchListComponent,DataTableDetailComponent,MonInputComponent,MonComboBoxComponent, MonComboBoxMultiSelectComponent,NodeListComponent],
  imports: [
   CommonModule,
    CdkTableModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    MatCardModule,
    MatFormFieldModule,
    MatRadioModule,
    MatIconModule,
    MatSidenavModule,
    MatButtonModule,
    MatTooltipModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatInputModule,
    MatSliderModule,
    MatListModule,
    MatProgressBarModule,
    MatCheckboxModule,
    MatPaginatorModule,
    MatTableModule,
    MatButtonToggleModule,
    MatToolbarModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ScrollingModule,
    RufCardModule,
    RufIconModule,
    RufLabeledIconModule,
    RufMaterialModule,
    TranslateLazyLoadModule,
    MatMenuModule],
	exports:[DetailComponent,ListComponent,SLDataTableComponent,SLDataTableColumnComponent,InquiryDataTableComponent,InquiryDataTableColumnComponent,DataTableSearchListDetailComponent,DataTableEditableDetail2Component,MonitorRadioButtonColumnRendererComponent,MonitorCheckBoxColumnRendererComponent,
    IstGenericViewButtonColumnRendererComponent,IstDynamicDropDownColumnRendererComponent,IstDropDownColumnRendererComponent,IstDatePickerColumnRendererComponent,IstCurrcodeDropDownColumnRendererComponent,
    IstCheckBoxColumnRendererComponent,IstCheckBoxColumnRendererForPermissionsComponent,IstMonitorDropDownColumnRendererComponent,IstNumberInputComponent,
    IstCheckBoxSearchlistRendererComponent,IstSearchListColumnRendererComponent,IstSearchlistInputColumnRendererComponent,IstInputColumnRendererComponent,IstLoadingIndicatorComponent,CellEditorDirective,
    CellRendererDirective,SearchListComponent,IstComboBoxComponent,IstDialogComponent,IstProgressBarComponent,IstInputComponent,IstButtonComponent,IstInlineInputComponent,
    IstInlineComboComponent,IstInlineColNameComponent,FormatCurrencyPipe,DataFormatPipe,IstDatePickerComponent,IstDatePickerMonthComponent,T21RequestComponent,DataTableColumnComponent,DataTableComponent,
    DataTablePaginatorComponent,DataDetailTablePaginatorComponent,DataTableColumnRadioRendererComponent,IstCheckBoxComponent,IstRadioGroupComponent,IstNumericStepperComponent,IstTextAreaComponent,IstSearchInputComponent,
    DataTableEditableComponent,DataTableEditableDetailComponent,QuerySectionComponent,IstSearchListComponent,MonInputComponent,MonComboBoxComponent, MonComboBoxMultiSelectComponent,NodeListComponent]
 })
export class ISTComponentModule {}
