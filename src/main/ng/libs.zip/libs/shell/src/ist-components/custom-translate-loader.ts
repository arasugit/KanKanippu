import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateLoader } from '@ngx-translate/core';
import { FormBusinessService } from '../services/formbusiness.service';
import { GlobalsService } from '../services/globals.service';
import { RemoteObjectService } from '../services/remote-object.service';
import { forkJoin, of } from 'rxjs';

import { catchError, map } from 'rxjs/operators';

@Injectable()
export class CustomTranslateLoader implements TranslateLoader {
  public prefix =  './assets/i18n/';
  public suffix =  '.json';
  private remoteObject: RemoteObjectService;
  translateURL = '/assets';
  constructor(private globals: GlobalsService, private http: HttpClient,  public mformService: FormBusinessService) {
  }
   public getTranslation(lang: string): any {
   if (lang === 'en-US') {
    return of({'Copyright' : 'Copyright \u00A9 {{year}} Fidelity National Services, Inc. and its subsidiaries. All rights reserved.'});
   } else if(this.globals.configOptions!=null && this.globals.configOptions){
    this.translateURL = this.globals.configOptions!=null && this.globals.getProperty('ist.translate.url')!=null? this.globals.getProperty('ist.translate.url') : '';
    const mod  = this.globals.currentModuleTobeLoaded;
    const filename = (mod === '') ? `${lang}` : `${mod}/${lang}`;
    const resources: { prefix: string, suffix: string }[] = [
      { prefix: 'main_page', suffix: '.json' },
      { prefix: 'menu', suffix: '.json' },
      { prefix: 'messages', suffix: '.json' }];
    if (mod !== '') {
      resources.push({ prefix: `${mod}`, suffix: '.json' });
    }
    return forkJoin(resources.map(config => {
      // console.log('Translate URL ', `${this.translateURL}${lang}/${config.prefix}${config.suffix}`);
      return this.http.get(`${this.translateURL}/${lang}/${config.prefix}${config.suffix}`).pipe(
        catchError(error => { console.log('error', error); return of({}); } ));
    })).pipe(map(response => {
      return response.reduce((a, b) => {
        return Object.assign(a, b);
      });
    }), catchError((error) => of({}))
  );
   }
}
}
