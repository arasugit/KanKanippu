// $Id$
import { Component, OnInit, Input, ViewChild, TemplateRef, AfterContentInit, EventEmitter } from '@angular/core';
import { DataTableColumnComponent, CustomRenderer } from '../components/data-table-column.component';


@Component({
    selector: 'ist-datepicker-column-renderer',
    template: `<ist-datepicker [(value)]="value" tag="column.tag"  [metadataProviderForCollections]="fields" 
                        (onSelectedDateChange)="propagateChangedRow($event)" isDisabled="isDisabled()" width="100px"></ist-datepicker>`                        
})
// Date picker for data table column
export class IstDatePickerColumnRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {

    constructor() {
        super();
    }

    ngOnInit() {
        
        
        if (this.value === null) {
            this.value = '';
        }
    }

    ngAfterContentInit() {
      
    }
    

    propagateChangedRow(selectedValue) {
        this.value = selectedValue;
        this.onSelectedRowChange.next(this.value);
    }
}
