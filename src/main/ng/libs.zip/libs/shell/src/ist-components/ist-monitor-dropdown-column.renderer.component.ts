// $Id$
import { AfterContentInit, Component, OnInit } from '@angular/core';
import { CustomRenderer } from '../components/data-table-column.component';

@Component({
    selector: 'ist-monitor-dropdown-column-renderer',
    template: `<ist-combobox type={{comboBoxType}} [dataProvider]="dataProvider" [(selectedValue)]="value"
                (onSelectedValueChange)="propagateChangedRow($event)"
                isCellEditor="true"></ist-combobox>`
    
})

export class IstMonitorDropDownColumnRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {
    constructor() {
        super();
    }
    
    public isGlbVal: Boolean = false;
    ngOnInit() {}
    ngAfterContentInit() {}

    propagateChangedRow(selectedValue) {
        this.value = selectedValue;
        this.onSelectedRowChange.next(this.value);
    }

    isDisabled(): Boolean {
        if (this.column.name === 'statusnew') 
		{
            return false;
        } else {
            return true;
        }
    }
}
