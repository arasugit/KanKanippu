import { Component, OnInit, Input, ViewChild, TemplateRef, HostListener, AfterContentInit } from '@angular/core';
import { DataTableColumnComponent, CustomRenderer } from '../components/data-table-column.component';
import { IstInputComponent } from '../components/ist-input-component';

@Component({
    selector: 'ist-searchlist-input-column-renderer',
     template: `<label>{{evaluate()}} </label>`
})
// Input renderer example for the data table column
export class IstSearchlistInputColumnRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {
    constructor() {
        super();
        //  console.log('(IstSearchlistInputColumnRendererComponent constructor())');
    }
    ngOnInit() {
        //  console.log('(IstSearchlistInputColumnRendererComponent onInit())');
    }
    ngAfterContentInit() {
        //  console.log('(IstSearchlistInputColumnRendererComponent ngAfterContentInit())');
    }

    propagateChangedRow(selectedValue) {
        //  console.log('Not propagating as this is a display only renderer', this.value);
    }

    evaluate(): any {
        try {
            if (this.column.labelFunction) {
                return this.column.labelFunction(this.row, this.column);
            } else if (this.row['dbAction'] === 'a') {
                if (this.comboBoxType === 'UserButton[0]') {
                    this.row['firstName'] =  this.row.UserButton[0];
                    this.value = this.row.UserButton[0];
                    }
                    if (this.comboBoxType === 'UserButton[1]') {
                        this.row['lastName'] =  this.row.UserButton[1];
                        this.value = this.row.UserButton[1];
                     }
                     if (this.comboBoxType === 'UserButton[3]') {
                        this.row['entObjectId'] =  this.row.UserButton[3];
                        this.value = this.row.UserButton[3];
                     }
                     if (this.comboBoxType === 'UserButton[5]') {
                        this.row['entObjectIduser'] =  this.row.UserButton[5];
                         this.value = this.row.UserButton[3];
                     }
                    if (this.comboBoxType === 'UserButton[2]') {
                        this.row['department'] =  this.row.UserButton[2];
                        this.value = this.row.UserButton[2];
                     }
                    if (this.comboBoxType === 'UserButton[4]') {
                        this.row['clientId'] =  this.row.UserButton[4];
                    this.value = this.row.UserButton[4];
                    }
                return this.value;
            }
            return this.value;
        } catch (e) {
            // Ignore
        }
    }

    isDisabled(): Boolean {
        return true;
    }
}
