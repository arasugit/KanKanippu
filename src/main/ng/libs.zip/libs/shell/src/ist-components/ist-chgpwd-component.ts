import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StringMap } from '../common/criteria';
import { StringUtil } from '../common/ist-string-util';
import { CommonConstants } from '../common/ist.common.constants';
import { GlobalsService } from '../services/globals.service';
import { InstService } from '../services/inst.service';
@Component({
  selector: 'ist-chgpwd',
  templateUrl: './ist-chgpwd-component.html',
})
export class IstChgPwdComponent implements OnInit {
  constructor(
    private windowRef: MatDialogRef<IstChgPwdComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private instService: InstService,
    private globals: GlobalsService
  ) {
    this.globals.setCurrentURL(this.globals.getCurrentURL()+"/"+"change-pwd-dialog");
    windowRef.disableClose = true;
    this.windowRef.beforeClosed().subscribe(result => {
      this.globals.resetCurrentURL("change-pwd-dialog");
      });
  }
  oldPassword = '';
  newPassword = '';
  confirmNewPassword = '';
  private chgPwdObj: StringMap = {};
  ngOnInit() {}

  clearFields(): void {
    this.oldPassword = '';
    this.newPassword = '';
    this.confirmNewPassword = '';
  }
  cancelChange(): void {
    this.windowRef.close('Cancel');
  }
  changePassword(): void {
    if (StringUtil.isEmpty(this.oldPassword)) {
      this.globals.errorDialog(CommonConstants.ERROR, 'UAM16', CommonConstants.ALERT_OK);
    } else if (StringUtil.isEmpty(this.newPassword)) {
      this.globals.errorDialog(CommonConstants.ERROR, 'UAM17', CommonConstants.ALERT_OK);
    } else if (StringUtil.isEmpty(this.confirmNewPassword)) {
      this.globals.errorDialog(CommonConstants.ERROR, 'UAM18', CommonConstants.ALERT_OK);
    } else if (StringUtil.notEquals(this.confirmNewPassword, this.newPassword)) {
      this.globals.errorDialog(CommonConstants.ERROR, 'UAM19', CommonConstants.ALERT_OK);
    } else {
      this.chgPwdObj = {
        FLAG: 'CHGPWD',
        OLDPWD: this.globals.encryptPassword(this.oldPassword),
        NEWPWD: this.globals.encryptPassword(this.newPassword)
      };
      this.instService.getDatabaseRecords('OasUserPopup', this.chgPwdObj).subscribe(
      x => this.getDatabaseRecordResult(x), error => this.getDatabaseRecordsResultError(error));
    }
  }
  private getDatabaseRecordResult(x: any): void {
    let value: any;
    if (x !== null && x.length > 0) {
      value = x[0];
    }
    if (value !== null && value.toString().search('successful') > -1) {
      this.globals.errorDialog(CommonConstants.INFORMATION, value, CommonConstants.ALERT_OK)?.
        subscribe(result => {
          this.windowRef.close('Close');
        });
    } else {
      this.globals.errorDialog(CommonConstants.ERROR, value, CommonConstants.ALERT_OK);
    }
  }
  private getDatabaseRecordsResultError(x: any): void {
    if (this.globals.checkErrorResponse(x)) {
      this.globals.errorDialog(CommonConstants.ERROR, x, CommonConstants.ALERT_OK)?.
        subscribe(result => {
          this.windowRef.close('Close');
        });
    }
  }
}
