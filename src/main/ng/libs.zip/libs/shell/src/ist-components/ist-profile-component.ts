import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StringMap } from '../common/criteria';
import { StringUtil } from '../common/ist-string-util';
import { CommonConstants } from '../common/ist.common.constants';
import { LabelsAndValues } from '../common/labels-and-values';
import { IstComboBoxComponent } from '../components/ist-combobox-component';
import { GlobalsService } from '../services/globals.service';
import { InstService } from '../services/inst.service';

@Component({
  selector: 'ist-profile',
  templateUrl: './ist-profile-component.html',
})
export class IstProfileComponent implements OnInit {
  constructor(
    private windowRef: MatDialogRef<IstProfileComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private instService: InstService,
    private globalsService: GlobalsService,
  ) {
    windowRef.disableClose = true;
  }

  public userObj: any;
  format_date =  new DatePipe('en_US');
  private profileWindow: StringMap = {};
  private dbParams: StringMap = {};
  obj: any;
  firstName = ''; middleName = ''; lastName = '';
  description = ''; department = ''; question1 = '';
  answer1 = ''; question2 = ''; answer2 = ''; question3 = '';
  oldAnswer1 = ''; oldAnswer2 = ''; oldAnswer3 = '';
  answer3 = '';  questionlst1 = '';  questionlst2 = ''; questionlst3 = '';
  ansMinLength = undefined; allowSameAnswer=true;
  qaList: LabelsAndValues = new LabelsAndValues();
  @ViewChild('questionlist1', { static: false })
  private questionlistvalues: IstComboBoxComponent;
  selQuestionLabel = '';
  ngOnInit() {
       this.obj = this.data.userObj;
    if ( this.obj !== null && this.obj !== undefined) {
      this.firstName = this.obj['firstName'];
      this.middleName = this.obj['middleName'];
      this.lastName = this.obj['lastName'];
      this.description = this.obj['description'];
      this.department = this.obj['department'];
      this.question1 = this.obj['question1'];
      this.answer1 = this.obj['answer1'];
      this.oldAnswer1 = this.obj['answer1'];
      this.question2 = this.obj['question2'];
      this.answer2 = this.obj['answer2'];
      this.oldAnswer2 = this.obj['answer2'];
      this.question3 = this.obj['question3'];
      this.answer3 = this.obj['answer3'];
      this.oldAnswer3 = this.obj['answer3'];
      this.ansMinLength = this.obj['ansMinLength'];
      this.allowSameAnswer = this.obj['allowSameAnswer'];
    }
}

clearFields(): void {
  this.question1 = '';  this.answer1 = '';  this.question2 = '';
  this.answer2 = '';  this.question3 = '';  this.answer3 = '';
  this.questionlst1 = '';  this.questionlst2 = '';  this.questionlst3 = '';
  }
  cancelChange(): void {
    this.windowRef.close('Cancel');
  }
  changeHandler(selQuestionKey: any, questionNo: string): void {
    console.log("selQuestionKey",selQuestionKey);
    this.qaList = this.questionlistvalues.dataProvider;
    if ( this.qaList !== null && this.qaList.array.length > 0) {
      for (let i = 0; i < this.qaList.array.length; ++i) {
          if (this.qaList.array[i].value === selQuestionKey) {
            this.selQuestionLabel = this.qaList.array[i].label;
            break;
          }
      }
        if ( questionNo === 'q1' ) {
          if (this.selQuestionLabel === this.question2  || this.selQuestionLabel === this.question3) {
            this.questionlst1 = '';
            this.globalsService.showDialog(CommonConstants.ERROR, 'UAM15', CommonConstants.ALERT_OK);
            } else if (this.selQuestionLabel === this.question1) {
            // nothing
            } else {
              this.question1 = this.selQuestionLabel;
              this.answer1 = '';
            }
        }
        if ( questionNo === 'q2' ) {
          if (this.selQuestionLabel === this.question3  || this.selQuestionLabel === this.question1) {
            this.questionlst2 = '';
            this.globalsService.showDialog(CommonConstants.ERROR, 'UAM15', CommonConstants.ALERT_OK);
            } else if (this.selQuestionLabel === this.question2) {
              // nothing
            } else {
              this.question2 = this.selQuestionLabel;
              this.answer2 = '';
            }
        }
        if ( questionNo === 'q3' ) {
          if (this.selQuestionLabel === this.question1  || this.selQuestionLabel === this.question2) {
            this.questionlst3 = '';
            this.globalsService.showDialog(CommonConstants.ERROR, 'UAM15', CommonConstants.ALERT_OK);
            } else if (this.selQuestionLabel === this.question3) {
              // nothing
            } else {
              this.question3 = this.selQuestionLabel;
              this.answer3 = '';
            }
        }
    }
  }
  checkQuestion(val: String): Boolean {
    if (val === 'q1') {
    if (this.question1 === null || this.question1 === '') {
      this.answer1 = '';
      return true;
      }
    }
    if (val === 'q2') {
      if (this.question2 === null || this.question2 === '') {
        this.answer2 = '';
        return true;
      }
    }
    if (val === 'q3') {
        if (this.question3 === null || this.question3 === '') {
          this.answer3 = '';
          return true;
     }
    }
    return false;
  }
  saveData(): void {
    let minLenMsg = this.globalsService.getMessage('UAM20');
    if (this.oldAnswer1 === this.answer1 &&  this.oldAnswer2 === this.answer2 && this.oldAnswer3 === this.answer3) {
      this.globalsService.showDialog(CommonConstants.INFORMATION, 'MSG22', CommonConstants.ALERT_OK);
      return;
    }
    if (this.question1 === null || this.question1 === '') {
      this.globalsService.showDialog(CommonConstants.ERROR, 'UAM09', CommonConstants.ALERT_OK);
    } else if (this.question2 === null || this.question2 === '') {
      this.globalsService.showDialog(CommonConstants.ERROR, 'UAM10', CommonConstants.ALERT_OK);
    } else if (this.question3 === null || this.question3 === '') {
      this.globalsService.showDialog(CommonConstants.ERROR, 'UAM11', CommonConstants.ALERT_OK);
    } else if (this.answer1 === null || this.answer1 === '') {
      this.globalsService.showDialog(CommonConstants.ERROR, 'UAM12', CommonConstants.ALERT_OK);
    } else if (StringUtil.isNotEmpty(this.answer1) && this.ansMinLength !== undefined && this.answer1.length < this.ansMinLength) {
      this.globalsService.showDialog(CommonConstants.ERROR, minLenMsg + " 1 ( " + this.ansMinLength + " chars) ", CommonConstants.ALERT_OK);
    } else if (this.answer2 === null || this.answer2 === '') {
      this.globalsService.showDialog(CommonConstants.ERROR, 'UAM13', CommonConstants.ALERT_OK);
    } else if (StringUtil.isNotEmpty(this.answer2) && this.ansMinLength !== undefined && this.answer2.length < this.ansMinLength) {
      this.globalsService.showDialog(CommonConstants.ERROR, minLenMsg + " 2 ( " + this.ansMinLength + " chars) ", CommonConstants.ALERT_OK);
    } else if (this.answer3 === null || this.answer3 === '') {
      this.globalsService.showDialog(CommonConstants.ERROR, 'UAM14', CommonConstants.ALERT_OK);
    } else if (StringUtil.isNotEmpty(this.answer3) && this.ansMinLength !== undefined && this.answer3.length < this.ansMinLength) {
      this.globalsService.showDialog(CommonConstants.ERROR, minLenMsg + " 3 ( " + this.ansMinLength + " chars) ", CommonConstants.ALERT_OK);
    } else if ( this.allowSameAnswer === false && (this.answer1.toLowerCase() === this.answer2.toLowerCase() || this.answer1.toLowerCase() === this.answer3.toLowerCase() || this.answer2.toLowerCase() === this.answer3.toLowerCase())) {
      this.globalsService.showDialog(CommonConstants.ERROR, 'UAM21', CommonConstants.ALERT_OK);
    }
    else {
        this.dbParams['DATA_TYPE'] = this.globalsService.encryptData('SET_DATA');
        this.dbParams['USER_ID'] = this.globalsService.encryptData(this.globalsService.userContext.userID);
        this.dbParams['CLIENT_ID'] = this.globalsService.encryptData(this.obj['clientId'] + '');
        this.dbParams['FIRST_NAME'] = this.globalsService.encryptData(this.obj['firstName']);
        this.dbParams['MIDDLE_NAME'] = this.globalsService.encryptData(this.obj['middleName']);
        this.dbParams['LAST_NAME'] = this.globalsService.encryptData(this.obj['lastName']);
        this.dbParams['DEPARTMENT'] = this.globalsService.encryptData(this.obj['department']);
        if(this.obj!=null&&this.obj['expiryDate'] !== null){
          const  data=this.obj['expiryDate'];
          this.globalsService.encryptData(data);
          const transformedData=this.format_date.transform(data, this.globalsService.dateFormat);
          if(transformedData!=null && transformedData!=undefined){
             this.dbParams['EXPIRY_DATE']=transformedData;
          }else{
            this.dbParams['EXPIRY_DATE']='';
          }
        }

        this.dbParams['DESCRIPTION'] = this.globalsService.encryptData(this.obj['description']);
        if(this.obj!=null&&this.obj['creationDate'] !== null){
          const  data=this.obj['creationDate'];
          this.globalsService.encryptData(data);
          const transformedData=this.format_date.transform(data,  this.globalsService.dateFormat);
          if(transformedData!=null && transformedData!=undefined){
             this.dbParams['CREATION_DATE']=transformedData;
          }else{
            this.dbParams['CREATION_DATE']='';
          }
        }

        if(this.obj!=null&&this.obj['creationTime'] !== null){
          const  data=this.obj['creationTime'];
          this.globalsService.encryptData(data);
          const transformedData=this.format_date.transform(data,  this.globalsService.dateFormat);
          if(transformedData!=null && transformedData!=undefined){
             this.dbParams['CREATION_TIME']=transformedData;
          }else{
            this.dbParams['CREATION_TIME']='';
          }
        }

        this.dbParams['QUESTION1'] = this.globalsService.encryptData(this.question1);
        this.dbParams['ANSWER1'] = this.globalsService.encryptData(this.answer1);
        this.dbParams['QUESTION2'] = this.globalsService.encryptData(this.question2);
        this.dbParams['ANSWER2'] = this.globalsService.encryptData(this.answer2);
        this.dbParams['QUESTION3'] = this.globalsService.encryptData(this.question3);
        this.dbParams['ANSWER3'] = this.globalsService.encryptData(this.answer3);
        this.instService.getDatabaseRecords('EDIT_USER_PROFILE', this.dbParams).subscribe(
          x => this.getResult(x), error => this.getResultError(error));
        }
  }
  private getResult(x: any): void {
   if ( x !== null && x.length > 0) {
    const obj: any = x[0];
    if (typeof obj === 'string' && obj !== null && obj.toString().search('ERROR') > -1) {
      this.globalsService.showDialog(CommonConstants.ERROR, obj.replace('ERROR:', ''), CommonConstants.ALERT_OK);
      } else {
        this.globalsService.showDialog(CommonConstants.INFORMATION, obj , CommonConstants.ALERT_OK)?. subscribe(result => {
        this.windowRef.close('Close');
        });
      }
    }
  }
  private getResultError(x: any): void {
       if (this.globalsService.checkErrorResponse(x)) {
      this.globalsService.showDialog(CommonConstants.ERROR, x, CommonConstants.ALERT_OK)?.subscribe(result => {;
      this.windowRef.close('Close');
      });
    }
  }
}
