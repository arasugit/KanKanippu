import { AfterContentInit, Component, OnInit } from '@angular/core';
import { CustomRenderer } from '../components/data-table-column.component';

@Component({
    selector: 'ist-checkbox-column-renderer',
    template: `<div [ngClass]="'cellEditor-container'" fxFlex="100%"><ist-checkbox [(ngModel)] ="_isChecked" (onClicked)="propagateChangedRow()"
    isCellEditor=true isDisabled="isDisabled()"></ist-checkbox></div>`

})
// Checkbox renderer example for the data table column
export class IstCheckBoxColumnRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {
    constructor() {
        super();
    }
    _isChecked: boolean;
    dataType = '';

    ngOnInit() {
        if (this.dataProvider !== undefined) {
            if (this.dataProvider['dataType'] === 'boolean') {
                this.dataType = 'boolean';
            }
        }
    }
    ngAfterContentInit() {
        if (this.dataType !== undefined && this.dataType === 'boolean') {
            this._isChecked = this.value === 'true' ? true : false;
        } else {
            if (this.value && typeof this.value === 'string') {
                if (this.value.toLocaleLowerCase().trim() === 'y' || this.value.toLocaleLowerCase().trim() === 'yes') {
                    this._isChecked = true;
                } else { this._isChecked = false; }
            }
        }
    }

    propagateChangedRow() {

        if (this.dataType !== undefined && this.dataType === 'boolean') {
            if (this._isChecked === true) {
                this.value = true;
            } else {
                this.value = false;
            }
        } else {
            if (this._isChecked === true) {
                this.value = 'y';
            } else {
                this.value = 'n';
            }
        }
        // console.log('Propagate changed value: ', this.value);
        this.onSelectedRowChange.next(this.value);
    }

    isDisabled(): Boolean {
        if (this.row !== undefined) {
            if ((this.row['dbAction'] === 'x' || this.row['dbAction'] === 'c') && this.column.editable === false) {
                return true;
            }
            if (this.row['inactive'] !== undefined && this.row['inactive'] !== null && this.row['inactive'].toLowerCase() === 'Y') {
                return true;
            }
            if (this.row['dbAction'] === 'd') {
                return true;
            }
            if (this.permissions['U'] === false && this.row['dbAction'] !== 'a') {
                return true;
            }
            if (this.isMKCRequest === true && this.isReworkRequest === false) {
                return true;
             }
             if (this.isMKCRequest === true && this.isReworkRequest === true) {
                return false;
             }
        }
    }
}
