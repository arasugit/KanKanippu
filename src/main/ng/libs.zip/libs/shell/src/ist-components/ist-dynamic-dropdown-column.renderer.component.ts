import { Component, OnInit, Input, ViewChild, TemplateRef, EventEmitter } from '@angular/core';
import { IstComboBoxComponent } from '../components/ist-combobox-component';
import { DataTableColumnComponent, CustomRenderer } from '../components/data-table-column.component';

@Component({
    selector: 'ist-dynamic-dropdown-column-renderer',
    template: `<ist-combobox cardScheme={{row.cardScheme}} [(selectedValue)]="value"
    [staticDataProvider]="dataProvider" (onSelectedValueChange)="propagateChangedRow($event)" isDisabled="isDisabled()"
    isCellEditor="true"></ist-combobox>`
})

export class IstDynamicDropDownColumnRendererComponent extends CustomRenderer implements OnInit {
    constructor() {
        super();
    }
    ngOnInit() {}

    propagateChangedRow(selectedValue) {
        this.value = selectedValue;
        this.onSelectedRowChange.next(this.value);
    }
}
