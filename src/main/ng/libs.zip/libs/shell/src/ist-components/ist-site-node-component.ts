import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StringMap } from '../common/criteria';
import { StringUtil } from '../common/ist-string-util';
import { CommonConstants } from '../common/ist.common.constants';
import { GlobalsService } from '../services/globals.service';
import { InstService } from '../services/inst.service';
import { LabelAndValue, LabelsAndValues } from '../common';
import { AutoRefreshService } from '../services';
@Component({
  selector: 'ist-site-node',
  templateUrl: './ist-site-node-component.html',
})
export class IstSiteNodeComponent implements OnInit {
  constructor(
    private windowRef: MatDialogRef<IstSiteNodeComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private instService: InstService,
    private globals: GlobalsService,
    private autoRefreshService: AutoRefreshService
  ) {
    this.globals.setCurrentURL(this.globals.getCurrentURL()+"/"+"select-sitenode-dialog");
    windowRef.disableClose = true;
    this.windowRef.beforeClosed().subscribe(result => {
      this.globals.resetCurrentURL("select-sitenode-dialog");
      });
  }


  sitenode = '';
  siteNodeList: LabelsAndValues = new LabelsAndValues();
  private siteNodeMap: StringMap = {};
  ngOnInit() {
    this.sitenode=this.globals.siteId+'-'+this.globals.nodeId;
    //console.log('sitenode::'+this.sitenode);
    this.instService.getDatabaseRecords("IST_SITE_NODE_LIST").subscribe((x: any[]) => { this.loadSiteNodeList(x); });
  }
  loadSiteNodeList(result: any[]): void {
    this.siteNodeList.array = result.map((y: string[]): LabelAndValue => {
      this.siteNodeMap[''+y[0]+'-'+y[1]]=''+y[2];
      return new LabelAndValue('Site '+y[0]+' - '+y[2], y[0]+'-'+y[1]);
    });
  }
  clearFields(): void {

  }
  cancelChange(): void {
    this.windowRef.close('Cancel');
  }
  changeHandler(selectedSiteNode: any): void {
    console.log('selectedSiteNode::'+selectedSiteNode);
    if(selectedSiteNode !== null){
      let siteNodeArr=selectedSiteNode.split("-");
      let siteId=siteNodeArr[0];
      let nodeId=siteNodeArr[1];
      //this.loadSiteNodeList.array
      if(!(siteId === this.globals.siteId && nodeId === this.globals.nodeId)){
      let nodeName=this.siteNodeMap[''+selectedSiteNode];
      console.log('Node name::'+nodeName);
      this.globals.uodateSelectedSiteNode(siteId,nodeId,nodeName);

      if(selectedSiteNode !== null)
      this.windowRef.close(siteNodeArr);
      this.autoRefreshService.refreshCurrentComponent();
      }else{
      }
    }
  }
  }

