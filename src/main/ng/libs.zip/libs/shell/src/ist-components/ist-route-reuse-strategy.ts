// $Id$
import { RufMDIStrategy, RufRouterUtilService } from '@ruf/shell';
import { ActivatedRouteSnapshot } from '@angular/router';
import { GlobalsService } from '../services/globals.service';

export class ISTRouteReuseStrategy extends RufMDIStrategy {
    constructor(protected util: RufRouterUtilService,private globals: GlobalsService) 
    {
        super(util);
    }

    shouldDetach(route: ActivatedRouteSnapshot): boolean {
        const ret = this.globals.stack.callingForm;
        this.globals.stack.callingForm = false;
        return ret;
    }
    shouldAttach(route: ActivatedRouteSnapshot): boolean {
        let ret = false;
        if (this.globals.stack.returningFromForm) {
            ret = super.shouldAttach(route);
        }
        this.globals.stack.returningFromForm = false;
        return ret;
    }
}
