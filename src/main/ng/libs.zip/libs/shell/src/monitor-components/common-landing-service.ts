import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MonitorLandingService {
  tabsChange$ = new Subject();
  constructor() {}

  updateTab(item, close = false) {
      this.tabsChange$.next({
        item,
        close
      })
  }
}
