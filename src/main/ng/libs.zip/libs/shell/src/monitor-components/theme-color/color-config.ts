
/* eslint-disable @typescript-eslint/naming-convention */
const defaultConfig =  {
    default: {
        colors: ['default'],
        selected: 'default'
    },
    gold: {
        colors: ['default', 'primary', 'accent', 'emphasis'],
        selected: 'primary'
    }
};

const menuConfig =  {
    default: {
        colors: ['default'],
        selected: 'default',
        class: 'ruf-background-default ruf-icon-default-accent2'
    },
    'default-dark': {
        colors: ['default'],
        selected: 'default',
        class: 'ruf-background-default-dark'
    },
    gold: {
        colors: ['default', 'primary'],
        selected: 'primary',
        class: 'ruf-background-primary ruf-icon-primary-light'
    }
};

const checkboxConfig = {
    default: {
        colors: ['primary'],
        selected: 'primary'
    },
    gold: {
        colors: ['primary', 'accent', 'warn'],
        selected: 'accent'
    }
};

export const RUF_COLOR_CONFIG = {
    'ruf-banner': defaultConfig,
    'ruf-page-header': defaultConfig,
    'ruf-toolbar': defaultConfig,
    'ruf-dynamic-menubar': menuConfig,
    'ruf-dynamic-sidemenu': menuConfig,
    'ruf-sidemenu': menuConfig,
    'mat-button': {
        default: {
            colors: ['default', 'primary'],
            selected: 'primary'
        },
        gold: {
            colors: ['default', 'primary', 'accent', 'emphasis', 'warn', 'secondary'],
            selected: 'primary'
        }
    },
    'mat-checkbox': checkboxConfig,
    'mat-radio': checkboxConfig,
    'mat-tab': {
        default: {
            colors: ['primary'],
            selected: 'primary'
        },
        gold: {
            colors: ['primary', 'accent', 'warn'],
            selected: 'primary'
        }
    }
}
