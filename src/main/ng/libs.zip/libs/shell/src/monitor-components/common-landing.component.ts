import {
  Component,
  Inject,
  OnInit,
  OnDestroy,
  Optional,
  ChangeDetectorRef,
} from '@angular/core';
import {
  MON_TOOL,
  MonToolComponentData,
  MonitorComponentData,
} from './common-object';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { MonitorLandingService } from './monitor-landing-service';
import { GlobalsService}   from '../services/globals.service';

@Component({
  selector: 'monitor-ruf-landing',
  styles: [`
    .monitor-router-outlet-density {
      height: calc(100% - 128px);
      padding-bottom: 0;
    }
  `],
  template: `
    <monitor-page-header
      [title]="title"
      [fontIcon]="icon"
      [tabRoutes]="tabRoutes"
      [displayDensity]="displayDensity"
      (densityChange)="onDensityChange($event)"
      (close)="onTabClose($event)"
    ></monitor-page-header>
    <monitor-router-outlet
      id="parentContainer"
      cdk-scrollable
      tabindex="-1"
      [class]="densityClass"
      [class.monitor-router-outlet-density]="displayDensity">
    </monitor-router-outlet>
  `,
})
export class CommonLandingComponent implements OnInit, OnDestroy {
  displayDensity;
  tabRoutes :any[]= [];
  title = 'Overall Network Status';
  icon: string;
  densityClass = '';
  allExample : any=[];
  private _routerData: Subscription;
  availableMenuItems =[];
  tabExclusionMAS =['BINDTLS','SAFTXNDATA'];
  tabExclusionCLR =['BINDTLS','SAFTXNDATA'];
  tabListToInclude:any = ['HOURLY','DAILY','YESTERDAY','WEEKLY','MONTHLY','QUARTELY','CUSTOM','LEAST-DAILY','LEAST-MONTHLY','LEAST-WEEKLY','BOTTOM','ACQUIRING','ISSUING','TXN-POS-ACQ','TXN-ATM-ISSUER','TXN-POS-ISSUER','CURRENT-TPS', 'TOP-TERMINAL', 'LEAST-TERMINAL','TXNTPS-DASH','AVERAGE-TPS', 'TODAY-TPS']
  constructor(
    @Optional() @Inject(MON_TOOL) private example:MonitorComponentData,
    private _route: ActivatedRoute,
    private landingService: MonitorLandingService,
    private cdr: ChangeDetectorRef,private globals:GlobalsService
  ) {}

  ngOnInit() {
    if (this.example) {
      this.availableMenuItems=this.globals.availableMenuItems;
      const onlyAvailableRoutes = this.availableMenuItems.flatMap(item=>item.split('/')[1]);
      this.allExample = this.example.examples;
      const exe = (({...rest})=>rest)(
      Object.fromEntries(
        Object.entries(this.allExample).filter(([key])=> this.tabListToInclude.includes(key)?key:onlyAvailableRoutes.includes(key))
      )
     )
      const examples: { [key: string]: any } = exe;
      this.title = this.example.title;
      this.icon = this.example.icon;
      let tabsData = Object.keys(examples).map((key) => ({
        label: examples[key].label,
        path: key,
        closeable: examples[key]['closeable'] || false,
      }));
     if(this.globals.productId==='ISTCLR')
     tabsData = tabsData.filter(x=>!this.tabExclusionCLR.includes(x.path));
    else if(this.globals.productId==='ISTMAS')
    tabsData = tabsData.filter(x=>!this.tabExclusionMAS.includes(x.path));

      this.tabRoutes = this.tabRoutes.concat(tabsData);
    }
    this._routerData = this._route.data.subscribe((data) => {
      this.displayDensity = data.displayDensity;
      this.title = data.title || this.title;
      this.icon = data.icon || this.icon;
      if (data.tabsData) {
        if (data.displayOverview === false) {
          this.tabRoutes = data.tabsData;
        } else {
          this.tabRoutes = this.tabRoutes.concat(data.tabsData);
        }
      }
    });

    this.landingService.tabsChange$.subscribe((res: any) => {
      if (!res.close) {
        this.tabRoutes = this.tabRoutes.concat(res.item);
      }
      this.cdr.markForCheck();
    });
  }
  onDensityChange(density) {
    this.densityClass = `ruf-mon-density${density}`;
  }

  onTabClose($event) {
    this.landingService.updateTab($event, true);
  }

  ngOnDestroy() {
    this._routerData.unsubscribe();
  }
}
