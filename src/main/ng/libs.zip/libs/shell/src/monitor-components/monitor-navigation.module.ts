import { NgModule, SecurityContext } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatLegacyCardModule as MatCardModule } from '@angular/material/legacy-card';
import { MatIconModule } from '@angular/material/icon';
import { MatLegacySelectModule as MatSelectModule } from '@angular/material/legacy-select';
import { MatLegacyTabsModule as MatTabsModule } from '@angular/material/legacy-tabs';
import { RouterModule } from '@angular/router';
import { RufThemeColorComponent } from './theme-color/theme-color.component';
import { RufThemeColorDirective } from './theme-color/theme-color.directive';
import { MonitorRouterOutletComponent } from './monitor-router-outlet/monitor-router-outlet.component';
import { MonitorDisplaySupportComponent } from './monitor-display-support/monitor-display-support.component';
import { MonitorDisplayDescriptionDirective } from './monitor-display-support/monitor-display-support.component';
import { MonitorPageMenubarComponent } from './page-menubar/page-menubar.component';
import { MonitorPageHeaderComponent } from './monitor-page-header/monitor-page-header.component';
import { RufThemePickerComponent } from './theme-picker/theme-picker.component';
import { CommonLandingComponent } from './common-landing.component';
import { MonitorDynamicComponentDisplayComponent} from './monitor-display/monitor-display.component';
import { MonitorCodeComponent } from './monitor-code/monitor-code.component';
import { MonitorCodeService } from './monitor-code/monitor-code.service';
import { MonitorDisplayLogService } from './monitor-logger/log.service';
import { MatLegacySlideToggleModule as MatSlideToggleModule } from '@angular/material/legacy-slide-toggle';
import { RufDemoTocMenuComponent } from './ruf-demo-toc-menu/ruf-demo-toc-menu.component';
import {
  RufToolbarModule,
  RufUniqueIdModule,
  RufRouterModule,
  RufPageHeaderModule,
  RufDynamicMenubarModule,
  RufLayoutModule,
  RufNavigationModule,
  RufIconModule,
  RufSidemenuModule,
  RufLabeledIconModule,
} from '@ruf/shell';
import { MatLegacyButtonModule as MatButtonModule } from '@angular/material/legacy-button';

@NgModule({
  imports: [
    CommonModule,
    RufToolbarModule,
    RufRouterModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatTabsModule,
    MatSelectModule,
    MatSlideToggleModule,
    RufDynamicMenubarModule,
    RufUniqueIdModule,
    RufPageHeaderModule,
    MatIconModule,
    RufLayoutModule,
    RufNavigationModule,
    RufIconModule,
    RufSidemenuModule,
    RufLabeledIconModule,
    FormsModule,
   
  ],
  declarations: [
    MonitorRouterOutletComponent,
    MonitorDisplaySupportComponent,
    MonitorDisplayDescriptionDirective,
    MonitorPageMenubarComponent,
    RufThemePickerComponent,
    MonitorPageHeaderComponent,
    CommonLandingComponent,
    MonitorDynamicComponentDisplayComponent,
    MonitorCodeComponent,
    RufThemeColorComponent,
    RufThemeColorDirective,
    RufDemoTocMenuComponent,
  ],
  providers: [
    MonitorCodeService,
    { provide: 'LOG_SERVICE', useClass: MonitorDisplayLogService }
  ],
  exports: [
    MonitorRouterOutletComponent,
    MonitorDisplaySupportComponent,
    MonitorDisplayDescriptionDirective,
    MonitorPageMenubarComponent,
    RufThemePickerComponent,
    MonitorPageHeaderComponent,
    CommonLandingComponent,
    MonitorDynamicComponentDisplayComponent,
    MonitorCodeComponent,
    RufThemeColorComponent,
    RufThemeColorDirective,
    RufDemoTocMenuComponent,
  ],
})
export class MonitorNavigationModule { }
