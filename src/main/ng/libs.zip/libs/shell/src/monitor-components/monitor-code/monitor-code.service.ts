import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TemplateBuildSettings } from '@ruf/bundler';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class MonitorCodeService {
  constructor(private http: HttpClient) { }

  getExtn(fileName: string): string {
    return fileName.substring(fileName.lastIndexOf('.') + 1);
  }

  getFiles(
    module: string,
    example: string
  ): Observable<{ label: string; path: string; data: string; type: string }[]> {
    return this.http
      .get<TemplateBuildSettings>(
        `assets/examples/${module}/${example}/ruf-example.json`
      )
      .pipe(
        map((ex) => {
          const exampleFiles = ex.files;
          return Object.keys(exampleFiles)
            .map((key) => ({
              label: key,
              path: key,
              data: exampleFiles[key],
              type: this.getExtn(key),
            }))
            .filter((eachFile) => eachFile.label !== 'index.html');
        })
      );
  }

  getExampleMetadata(module: string, example: string): Observable<TemplateBuildSettings> {
    return this.http
      .get<TemplateBuildSettings>(
        `assets/examples/${module}/${example}/ruf-example.json`
      );
  }
}
