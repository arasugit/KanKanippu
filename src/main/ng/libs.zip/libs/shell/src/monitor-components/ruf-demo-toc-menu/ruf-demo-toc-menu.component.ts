import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, Inject, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { fromEvent } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

/** @dynamic */
@Component({
   // tslint:disable-next-line
   selector: 'ruf-demo-toc-menu',
   template: `
      <div>
         <h5>Contents</h5>
         <nav>
            <a
               [href]="_rootUrl + '#' + link.id"
               *ngFor="let link of links; let i = index"
               class="ruf-demo-toc-{{ link.type }}"
               [class.top-in-view]="link.active"
            >
               {{ link.name }}
            </a>
         </nav>
      </div>
   `,
   styleUrls: ['./ruf-demo-toc-menu.component.scss']
})
export class RufDemoTocMenuComponent implements OnInit, OnDestroy {
   @Input() links: any;
   @Input() container: string;
   @Input() headerSelectors = '.ruf-toc-header-anchor';
   @Input() offset = 0;
   _rootUrl: string;

   private _destroyed = new Subject();
   private _scrollContainer: any;

   constructor(private _router: Router, private _el: ElementRef, @Inject(DOCUMENT) private _document: Document) {}

   ngOnInit() {
      this.reRender();
   }

   public reRender() {
      let rootUrl = this._router.url.split('#')[0];
      rootUrl = rootUrl.slice(1);
      this.links = this.createLinks();
      this._rootUrl = rootUrl;

      Promise.resolve().then(() => {
         this._scrollContainer = this.container ? this._document.querySelectorAll(this.container)[0] : window;

         fromEvent(this._scrollContainer, 'scroll')
            .pipe(takeUntil(this._destroyed))
            .subscribe(() => this.onScroll());
      });
   }

   ngOnDestroy() {
      this._destroyed.next({});
   }

   updateLinks() {
      if (this.links) {
         for (let i = 0; i < this.links.length; i++) {
            this.links[i].active = this.isLinkActive(this.links[i], this.links[i + 1]);
         }
      }
   }

   private createLinks(): any[] {
      const links: any[] = [];
      const anchors = Array.from(this._document.querySelectorAll(this.headerSelectors)) as HTMLElement[];
      if (anchors.length) {
         for (const anchor of anchors) {
            const header = anchor.parentElement;
            const name = header?.innerText.trim().replace(/^link/, '');
            const { top } = header?.getBoundingClientRect();
            links.push({
               name,
               type: header?.tagName.toLowerCase(),
               top,
               id: header?.id,
               active: false
            });
         }
      }
      return links;
   }

   private getScrollOffset(): any {
      const { top } = this._el.nativeElement.getBoundingClientRect();
      if (typeof this._scrollContainer.scrollTop !== 'undefined') {
         return this._scrollContainer.scrollTop + top;
      } else if (typeof this._scrollContainer.pageYOffset !== 'undefined') {
         return this._scrollContainer.pageYOffset + top;
      }
   }

   private onScroll(): void {
      this.updateLinks();
   }

   private isLinkActive(currentLink: any, nextLink: any): boolean {
      // A link is considered active if the page is scrolled passed the anchor without also
      // being scrolled passed the next link
      const scrollOffset: number = +this.getScrollOffset() + +this.offset;
      return scrollOffset >= currentLink.top && !(nextLink && nextLink.top < scrollOffset);
   }
}
