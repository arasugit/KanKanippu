# ruf-theme-color

`ruf-theme-color` component can be used to show different color options using `mat-select`. 
It can be used with any other RUF/Material component where you want to show different color configuration for that component.

`ruf-theme-color` fetches these color configuration from a configuration file `color-config.ts` based on component and selected theme.

e.g. `ruf-banner` supports multiple background colors (`default`, `primary`, `accent`, `emphasis` & `warn`) and if you want to demo this use case then you can use `ruf-theme-color`.

```html
<ruf-theme-color #rtc themeColorFor="ruf-banner">
    Select Background Color
</ruf-theme-color>

<ruf-banner [color]="rtc.selected" [ngClass]="rtc.class"></ruf-banner>

```

## Inputs

### rufThemeColor

Default color value.

Default: `default`

Type: `string`

### themeColorFor

Component name for which you want to add the `ruf-theme-color`.

Default: `ruf-banner`

Type: `string`

## Output

### onSelectionChange

An event is emitted with selected color value when user changes the color option from select box.


## Public Properties

### selectedTheme

Returns the selected theme e.g. `default`, `gold`, `default-dark`, `gold-dark`

### themeType

Returns the selected theme type e.g. `light`, `dark`

### class

Returns the class specific to component and selected theme

Examples - 

```html

<ruf-theme-color #rtc themeColorFor="ruf-banner"></ruf-theme-color>

<ruf-banner [color]="rtc.selected" [ngClass]="rtc.class"></ruf-banner>

```


```html

<ruf-theme-color #rtc themeColorFor="ruf-page-header"></ruf-theme-color>

<ruf-page-header [light]="rtc.selectedTheme === 'gold' ? : null " [color]="rtc.selected" [ngClass]="rtc.class"></ruf-page-header>

```

## RufThemeColorDirective 

`rufThemeColor` can also be used in place of `ruf-theme-color` where user doesn't want to show the color options but want to fetch component's color configuration based on selected theme.

e.g.

```html

<mat-sidenav-container>
    <mat-sidenav rufThemeColor #rtc="rufThemeColor" >
        <ruf-sidemenu [light]="rtc.selectedTheme === 'gold' ? : null " [ngClass="rtc.class"]></ruf-sidemenu>
    </mat-sidenav>
</mat-sidenav-container>
```

## Add color configuration based on theme

You can add component specific configuration in `color-config.ts` based on selected theme.
`ruf-theme-color` reads these configuration using `themeColorFor` input property.
 You can add component specific configuration for different themes with different modes (`light` | `dark`).

```ts
 config = {
   ...,
  'ruf-banner': {
    'default': {
            'colors': ['default', 'primary'],
            'selected': 'primary',
            'class': 'custom-class default-class'
        },
        'default-dark': {
            'colors': ['default', 'accent'],
            'selected': 'default',
            'class': 'custom-class default-dark-class'
        },
        'gold': {
            'colors': ['default', 'primary', 'accent', 'emphasis'],
            'selected': 'primary',
            'class': 'custom-class gold-class'
        }
        'gold-dark': {
            'colors': ['default', 'primary', 'accent', 'emphasis'],
            'selected': 'primary',
            'class': 'custom-class gold-dark-class'
        }
   },
   'ruf-sidemenu': {
      'default': { 
         'selected': 'default',
         'class': 'ruf-background-default'
      },
      'gold': {
          'selected': 'primary',
          'class': 'ruf-dark-background-primary'
      }
   },
   ...
 }
 
```