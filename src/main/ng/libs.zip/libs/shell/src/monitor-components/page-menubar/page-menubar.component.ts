import {
  Component,
  OnInit,
  Input,
  Inject,
  Output,
  EventEmitter,
  ChangeDetectorRef,
} from '@angular/core';
import {
  Router,
  ActivatedRoute,
  RouteReuseStrategy,
  NavigationEnd,
} from '@angular/router';
import { Observable } from 'rxjs';
import { filter, first, map } from 'rxjs/operators';
import { RufDynamicMenubarItem, RufNavigationService } from '@ruf/shell';

@Component({
  selector: 'monitor-page-menubar',
  templateUrl: './page-menubar.html',
})
export class MonitorPageMenubarComponent implements OnInit {
  @Input() tabRoutes: RufDynamicMenubarItem[];
  @Input() backgroundColor: string;
  @Output() close = new EventEmitter<RufDynamicMenubarItem>(); // eslint-disable-line @angular-eslint/no-output-native
  selectedPaths: string;
  parentRoute: ActivatedRoute;
  activeColor = 'primary';

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private navService: RufNavigationService,
    @Inject(RouteReuseStrategy) private routeReuseStrategy,
    private cdr: ChangeDetectorRef
  ) {
    router.events.pipe(
      filter(event1 => event1 instanceof NavigationEnd),
      map(event1 => (event1 as any).url),
      map(url => {
        const segments = url.split('/');
        return segments[segments.length-1];
      })
    ).subscribe(item => {
      this.selectedPaths = item;
      this.cdr.markForCheck()
    });

    // store the parent route for relative navigation
    this.parentRoute = route.parent;
  }

  ngOnInit() {}

  onClose(item) {
    const path = this.getHandlerKey(
      '/ruf',
      this.parentRoute.routeConfig.path,
      item.path
    );
    this.tabRoutes.splice(this.tabRoutes.indexOf(item), 1);
    this.tabRoutes = this.tabRoutes.slice();
    this.destroyRoute(path);
    this.close.emit(item);
  }

  navigate(navigationItem) {
    // use navigate method to allow relative navigation
    return this.navService.navigate(navigationItem, {
      relativeTo: this.parentRoute,
    });
  }

  getHandlerKey(...args) {
    return args.join('/');
  }

  destroyRoute(routeUrl: string) {
    this.routeReuseStrategy.destroy(routeUrl);
    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        first()
      )
      .subscribe((event: NavigationEnd) => {
        this.routeReuseStrategy.destroy(routeUrl);
      });
  }
}
