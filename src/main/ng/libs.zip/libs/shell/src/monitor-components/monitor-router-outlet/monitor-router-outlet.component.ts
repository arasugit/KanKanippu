import { Component } from '@angular/core';

@Component({
  selector: 'monitor-router-outlet',
  template: `<ruf-router-outlet></ruf-router-outlet>`
})
export class MonitorRouterOutletComponent {}
