export * from './theme-color.component';
export * from './theme-color.directive';
