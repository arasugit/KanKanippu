import { ChangeDetectorRef, Component, Inject, Input, Optional } from '@angular/core';
import { RufThemeColorDirective } from './theme-color.directive';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'ruf-theme-color',
    templateUrl: './theme-color.html'
})

export class RufThemeColorComponent extends RufThemeColorDirective {
    @Input() selected = 'default';
    constructor(
        @Optional() @Inject('THEME_PICKER_SERVICE') public themePicker,
        protected cdr: ChangeDetectorRef,
        protected http: HttpClient
    ) {
        super(themePicker, cdr);
    }

}

