import { Injectable } from '@angular/core';
import { Observable, from, BehaviorSubject } from 'rxjs';

@Injectable()
export class MonitorDisplayLogService {
  private _message: string = null;
  private _logSubject: BehaviorSubject<string> = new BehaviorSubject(this._message);
  private _log$: Observable<string> = from(this._logSubject);

  log(message) {
    message = (typeof message === 'string') ? message : JSON.stringify(message, null, 2);
    this._message = message;
    this._logSubject.next(message);
  }

  get log$(): Observable<string> {
    return this._log$;
  }
}
