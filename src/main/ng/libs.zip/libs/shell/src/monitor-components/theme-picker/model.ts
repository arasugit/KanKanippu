export interface DemoTheme {
    name: string;
    id: string;
    href?: string;
    primary?: string;
    isDefault?: boolean;
    isLight?: boolean
}
