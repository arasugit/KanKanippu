import {
  Component,
  Inject,
  Output,
  EventEmitter,
  Input,
  ChangeDetectionStrategy,
  OnChanges,
  SimpleChanges,
  Optional,
} from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { DemoTheme } from './model';

@Component({
  selector: 'demo-theme-picker',
  templateUrl: 'theme-picker.html',
  styleUrls: ['./theme-picker.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RufThemePickerComponent implements OnChanges {
  @Output() selectChange = new EventEmitter<DemoTheme>();
  @Input() mode: 'light' | 'dark' = 'light';
  theme = 'Default';
  className = 'theme-manager';
  themes: DemoTheme[] = [
    {
      name: 'Default',
      id: 'default',
      primary: '#4bcd3e',
      href: 'fis-default',
      isDefault: true,
      isLight: true
    },
    {
      name: 'Gold',
      id: 'gold',
      primary: '#f5ad2a',
      href: 'fis-gold',
      isDefault: false,
      isLight: true
    }
  ];

  constructor(
    @Inject(DOCUMENT) private document,
    @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker
  ) {
    this.themePicker.currentTheme = this.themes[0];
  }

  ngOnChanges(changes: SimpleChanges) {
    if (
      changes &&
      changes.mode &&
      changes.mode.currentValue !== changes.mode.previousValue
    ) {
      this.switchTheme();
    }
  }

  switchTheme() {
    // get current theme object
    const currentTheme = this.themes.find((theme) => theme.name === this.theme);
     const mode = this.mode === 'light' ? '' : '-dark';
    const assetsLink = `assets/${currentTheme.href}${mode}.css`
    // css-vars-ponyfill adds disabled="" attribute on link tag which does not allow to
    // update the new styles, so we need to remove it.
    // check issue for more details https://github.com/jhildenbiddle/css-vars-ponyfill/issues/148
    this.getLinkElement().removeAttribute('disabled');
    this.getLinkElement().setAttribute('href', assetsLink);
    this.selectChange.emit(currentTheme);
    this.themePicker.darkTheme = this.mode === 'light' ? false : true;
    this.themePicker.currentTheme = currentTheme;
  }

  createLinkElement() {
    const linkEl = this.document.createElement('link');
    linkEl.setAttribute('rel', 'stylesheet');
    linkEl.classList.add(this.className);
    this.document.head.appendChild(linkEl);
    return linkEl;
  }

  getLinkElement() {
    return this.getExistingLinkElement() || this.createLinkElement();
  }

  getExistingLinkElement() {
    return this.document.head.querySelector(
      `link[rel="stylesheet"].${this.className}`
    );
  }
}
