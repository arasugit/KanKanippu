import { InjectionToken } from '@angular/core';

export interface MonToolComponentData {
  label: string;
  title?: string;
  description?: string;
  rufId?: string;
  useLog?: boolean;
  component?: any;
  closeable?: boolean;
  stackblitz?: boolean;
}

export interface MonitorComponentData {
  title: string;
  icon: string;
  examples: { [key: string]: MonToolComponentData };
}

export const monitorToken = new InjectionToken('MON_TOOL');

export const MON_TOOL = monitorToken;
