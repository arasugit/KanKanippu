/* eslint-disable max-len */
import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnDestroy, OnInit
} from '@angular/core';
import {ActivatedRoute, NavigationStart, Router, RouterEvent} from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import {MonToolComponentData,MonitorComponentData, MON_TOOL} from '../common-object';

enum Template {
  angularCli = 'angular-cli'
}

@Component({
  selector: 'monitor-display',
  templateUrl: './monitor-display.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MonitorDynamicComponentDisplayComponent implements OnInit, OnDestroy {
  
  moduleName: string;
  exampleFile$: Observable<any[]>;  
  routeName: string;
  currentComponent: any;
  componentData: MonToolComponentData;
  private subscription:Subscription;
  
  private _routerData: Subscription;

  constructor(
    @Inject(MON_TOOL) private example: MonitorComponentData, 
    private changeDetectorRef: ChangeDetectorRef,
    private _router: Router,
    private _route: ActivatedRoute
  ) { }

  reloadMonitorComponent() {
    if (this.componentData && this.componentData.component) {
      this.currentComponent = this.componentData.component;
     }
  }



  ngOnInit() {
    this.componentData = this.getMetaData(this._router.url);
    this.reloadMonitorComponent();
    this.routeName = this.getLeafRouteName(this._router.url);
    this._routerData = this._route.data.subscribe((data) => {
      this.moduleName = data.module;
    });

    this.subscription = this._router.events
      .pipe(filter((event:any) => event instanceof NavigationStart))
      .subscribe((event: RouterEvent) => {
        this.componentData = this.getMetaData(event.url);
        this.reloadMonitorComponent();
        this.changeDetectorRef.markForCheck();
      });

   
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
    this._routerData.unsubscribe();
   
  }

  getMetaData(url: string): MonToolComponentData {
    const key = this.getLeafRouteName(url);
    return this.example && this.example.examples && key
      ? this.example.examples[key]
      : {} as MonToolComponentData ;
  }

  

  private getLeafRouteName(url: string): string {
    return url.substring(url.lastIndexOf('/') + 1);
  }
}
