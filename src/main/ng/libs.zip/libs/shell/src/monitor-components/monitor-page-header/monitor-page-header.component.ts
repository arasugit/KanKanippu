import {
  Component,
  EventEmitter,
  OnInit,
  Input,
  Output,
} from '@angular/core';
import { RufDynamicMenubarItem } from '@ruf/shell';

@Component({
  selector: 'monitor-page-header',
  templateUrl: 'monitor-page-header.component.html',
  styleUrls: ['monitor-page-header.component.scss'],
})
export class MonitorPageHeaderComponent implements OnInit {
  @Input() title: string;
  @Input() fontIcon: string;
  @Input() tabRoutes: any;
  @Input() displayDensity: boolean;
  @Output() densityChange = new EventEmitter<number>();
  @Output() close = new EventEmitter<RufDynamicMenubarItem>(); 
  appDensity = 0;

  constructor() {}
  ngOnInit() {}

  onTabClose(event) {
    this.close.emit(event);
  }
}
