import { Directive, ChangeDetectorRef, Input, Output, EventEmitter, OnDestroy, OnInit, Inject, Optional } from '@angular/core';
import { RUF_COLOR_CONFIG } from './color-config';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Directive({
  selector: '[rufThemeColor]',
  exportAs: 'rufThemeColor',
})

export class RufThemeColorDirective implements OnDestroy, OnInit {
  @Input('rufThemeColor') selected = 'default';
  // eslint-disable-next-line @angular-eslint/no-input-rename
  @Input('themeColorFor') cn = 'ruf-banner';
  @Input() light = false;
  @Output() selectColorChange = new EventEmitter<string>();

  selectedTheme = 'default';
  themeType: 'light' | 'dark' = 'light';
  class = '';

  colors = ['default', 'primary', 'accent', 'emphasis'];
  private destroy$ = new Subject();
  constructor(
    @Optional() @Inject('THEME_PICKER_SERVICE') public themePicker,
    protected cdr: ChangeDetectorRef) { }

  onSelectionChange(event) {
    this.selected = event.value;
    this.selectColorChange.emit(event.value);
  }

  ngOnInit() {
    this.themePicker.themeChange$.pipe(takeUntil(this.destroy$)).subscribe((res) => {
      Promise.resolve().then(_ => {
        this.themeType = res.isLight ? 'light' : 'dark';
        this.selectedTheme = `${res.id}${res.isLight ? '' : '-dark'}`;
        this.updateColorProperties();
        this.selectColorChange.emit(this.selected);
        this.cdr.markForCheck();
      });
    });
  }

  updateColorProperties() {
    this.colors = this.getColors();
    this.selected = this.getSelectedColor();
    this.class = this.getClass();
  }

  getSelectedColor() {
    return this.getValuesOnThemeChange('selected', 'default');
  }

  getColors() {
    return this.getValuesOnThemeChange('colors', ['default', 'primary', 'accent', 'emphasis']);
  }

  getClass() {
    return this.getValuesOnThemeChange('class', '');
  }


  // Check configuration in RUF_COLOR_CONFIG
  // If dark mode does not have configuration then use respective light theme's configuration.
  // If no configuration provided then use default configuration
  getValuesOnThemeChange(key, defaultValue) {
    if (!RUF_COLOR_CONFIG[this.cn]) {
      return defaultValue;
    }

    if (RUF_COLOR_CONFIG[this.cn][this.selectedTheme]) {
      return RUF_COLOR_CONFIG[this.cn][this.selectedTheme][key];
    } else if (RUF_COLOR_CONFIG[this.cn][this.selectedTheme.replace('-dark', '')]) {
      return RUF_COLOR_CONFIG[this.cn][this.selectedTheme.replace('-dark', '')][key];
    } else {
      return defaultValue;
    }
  }

  ngOnDestroy() {
    this.destroy$.unsubscribe();
  }
}
