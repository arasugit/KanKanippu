import {
  Component,
  Input,
  ElementRef,
  Directive,
  Optional,
  Inject,
} from '@angular/core';

@Component({
  selector: 'monitor-content',
  templateUrl: './monitor-content.html',
})
export class MonitorContentComponent {
  @Input() title: string;
  @Input() useLog = false;
  @Input() code = null;
  @Input() id: string;
  @Input() displayInfo = true;
  @Input() stackblitz = false;
   selectedPath: string;
  actionLog: string[] = [];
  codeVisible = false;
  logVisible = false;

  constructor(
    private el: ElementRef,
    @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker
  ) { }

  get darkMode(): boolean {
    return this.themePicker.darkTheme;
  }

  log(value) {
    value = value instanceof String ? value : JSON.stringify(value, null, 2);
    this.actionLog = [].concat(value, this.actionLog as []);
    this.actionLog.length = Math.min(this.actionLog.length, 20);
  }

  clearLog() {
    this.actionLog = [];
  }

  onToggleChange(checked) {
    this.codeVisible = checked;
   
  }

  onPopout() {
   
   }
}

@Directive({
  selector: 'monitor-description',
})
export class MonitorDescriptionDirective { }
