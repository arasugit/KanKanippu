import { Component, ChangeDetectionStrategy, Input } from '@angular/core';

declare let Prism: any; // eslint-disable-line

@Component({
  selector: 'monitor-code',
  templateUrl: './monitor-code.component.html',
  styleUrls: ['./monitor-code.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MonitorCodeComponent {
  @Input() example;
  _files: any[];
  code: string;
  selectedPath: string;
  ingnoreExt = ['svg'];
  exampleFilePaths = ['src/app/example', 'src/assets'];

  @Input()
  set files(value) {
    this._files = value?.filter(val => this.exampleFilePaths.some(path => val.path.includes(path))
      && !this.ingnoreExt.some(ext => val.label?.includes(ext))).map(file => {
        const splittedLabel = file.label.split('/');
        file.label = file.path = splittedLabel[splittedLabel.length - 1];
        return file;
      });
    this.initExamples();
  }

  get files() {
    return this._files;
  }

  constructor() { }

  initExamples() {
    if (this.files && this.files.length > 0) {
      this.selectedPath = this.files[0].path;
      this.highlight(this.files[0].data, this.files[0].type);
    }
  }

  displayCode(file) {
    this.selectedPath = file.path;
    this.highlight(file.data, file.type);
  }

  highlight(code: string, language: string) {
    const prefix =
      language === 'html'
        ? `<!-- ${this.selectedPath}  -->`
        : `// ${this.selectedPath}`;
    code = `${prefix}\n\n` + code;
    this.code = Prism.highlight(code, Prism.languages[language]);
  }
}
