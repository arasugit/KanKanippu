// $Id$
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { RemoteObjectService } from './remote-object.service';
import { LabelsAndValues, LabelAndValue } from '../common/labels-and-values';
import { WorkRequest, WorkCollection } from '../ist-components/work-request-model';
import { Criteria } from '../common/criteria';



@Injectable()
export class FormBusinessService {
  constructor(private remoteObject: RemoteObjectService) {
    console.log('FormBusinessService');

  }
  requestType: String = '';
  action: String = '';
  criteria: Criteria | null;
  collectionTag: string | null;
  data: WorkRequest = new WorkRequest();
  totalRecords = -1; // For retaining total number of records; this is reset on a fresh search

  sendCommandService(method: string, node: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<LabelsAndValues> {
    return this.remoteObject.call('mFormService', method, node, command, isTable, logAudit, authId).pipe(
      map((x: string[][]): LabelsAndValues => {
        const res = new LabelsAndValues();
        res.array = x.map((y: string[]): LabelAndValue => {
          return new LabelAndValue(y[1], y[0]);
        });
        return res;
      })
    );
  }

  sendATMCommandService(method: string, nodeId: string, node: string, host: string, port: string,  command: string,
    isTable: boolean, authId: string): Observable<LabelsAndValues> {
    return this.remoteObject.call('mFormService', 'getCommandResult', node, command, isTable, true, authId).pipe(
      map((x: any): any => {
        return x;
      })
    );
  }

  getLiveNodeStatus(method: string, nodeId: string, host: string, port: string, node: string, command: string,
    isTable: boolean, authId: string): Observable<LabelsAndValues> {
    return undefined;
  }

  // This method is used to get result of Maintain ATM Unit Commands
  getATMUnitCommandResult(method: string, nodeId: string, nodeName: string, host: string, port: string,
    command: string, isTable: boolean, authId: string): Observable<string> {
    return this.remoteObject.call('mFormService', method, nodeId, nodeName, host, port, command, isTable, authId).pipe(
      map((x: string[]): string => {
        let res: string;
        res = x[1];
        return res;
      })
    );
  }

  // This method is used to get result of Maintain ATM Group Commands
  getATMGroupCommandResult(method: string, nodeId: string, nodeName: string, host: string, port: string, command: string,
    isTable: boolean, authId: string): Observable<string> {
    return this.remoteObject.call('mFormService', method, nodeId, nodeName, host, port, command, isTable, authId).pipe(
      map((x: string[]): string => {
        let res: string;
        res = x[1];
        return res;
      })
    );
  }

  // This method is used to get whole ATM information from database in hierarchical structure
  atmMonQuery(method: string, isOldAtm: boolean): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, isOldAtm).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  // This method is used to update the curreny
  sendUpdateCurrencyCommand(method: string, node: string, command: string,
    logAudit: boolean, authId: string): Observable<LabelsAndValues> {
    return this.remoteObject.call('mFormService', method, node, command, logAudit, authId).pipe(
      map((x: string[][]): LabelsAndValues => {
        const res = new LabelsAndValues();
        res.array = x.map((y: string[]): LabelAndValue => {
          return new LabelAndValue(y[1], y[0]);
        });
        return res;
      })
    );
  }

  // This method is used to get node Status for each node
  getNodeStatus(method: string, siteId: string, nodeID: string, hostName: string,
    nodeName: string, port: string, nodeType: string,
    returnLines: string, maxCtrlLines: string, logAudit: boolean): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, siteId, nodeID, hostName, nodeName,
      port, nodeType, returnLines, maxCtrlLines, logAudit).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  loadData(fresh: Boolean): Observable<WorkRequest> {
    if (fresh === true) {
      this.totalRecords = -1;
    }
    let wc: WorkCollection = new WorkCollection();
    return this.remoteObject.call('mFormService', 'getNodeList').pipe(
      map((x: WorkRequest) => {
        if (!x || x == null) {
          return undefined;
        }
        this.data = x;
        const len = this.data.lastModified;
        if (len && +len > 0) {
          this.totalRecords = len;
        }
        wc = this.data.collections[this.collectionTag];
        if (wc) {
          const rows = wc.rows;
          if (rows) {
            if (rows.length <= 0) {
              this.totalRecords = -1;
            }
          }
        }
        this.data.total = this.totalRecords;
        return this.data;
      })
    );
  }

  // This method is used to get whole ATM information from database in hierarchical structure
  atmMonitorTree(): Observable<object[]> {
    return this.remoteObject.call('mFormService', 'atmMonitorTree').pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  // This method is used to get whole ATM information from database in hierarchical structure
  getATMUnitInfo(instId: string, netId: string, grpId: string): Observable<any> {
    return this.remoteObject.call('mFormService', 'getATMUnitInfo', instId, netId, grpId).pipe(
      map((x: any) => {
        return x;
      })
    );
  }
  getATMUnitInfoByStatus(atmStatus: string): Observable<any> {
    return this.remoteObject.call('mFormService', 'atmDeviceDetailsByStatus', atmStatus).pipe(
      map((x: any) => {
        return x;
      })
    );
  }
  getInstitutionStatus(): Observable<Object> {
    return this.remoteObject.call('mFormService', 'getInstitutionStatus')
      .pipe(map(x => {
        return x;
      })
      );
  }

  sendCmdService(method: string, node: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<string> {
    return this.remoteObject.call('mFormService', method, node, command, isTable, logAudit, authId).pipe(
      map((x: string): string => {
        return x;
      })
    );
  }


  // This method is used to get Institution Manager List in the data grid
  getInstitutionManagerList(method: string, nodeName: string, command: string, parameters: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, parameters, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  // This method is used to get Port information for Inst Manager for the selected record
  getPortInfoForInstManager(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  // This method is used to get Mailbox information for Inst Manager for the selected record
  getMailboxInfoForInstManager(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  // This method is used to get Mailbox information for Inst Manager for the selected record
  getAdviceList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  // This method is used to get Mailbox information for Inst Manager for the selected record
  getInstitutionForAdviceManagerList(method: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  // This method is used to get Mailbox Manager List in the data grid
  getMailboxManagersList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  // This method is used to get Port Manager List in the data grid
  getPortManagersList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  // This method is used to get Port Manager CMMT List in the data grid
  getCMMTList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  // This method is used to get Port Manager List in the data grid
  getSharedMemoryManagersList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  getPosManagersList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  getTaskManagersList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  getAPMTaskList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  getUpAndDownNodeList(method: string, logAudit: boolean): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getICMManagersList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getICMSAFManagersList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getDJFAListResult(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getNodeList(method: string, logAudit: boolean): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getCommandResultAfterRefresh(method: string, logAudit: boolean): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getNodesEventList(method: string, command: string, isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, command, isTable, logAudit, authId).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getTokMasCommands(method: string, command: string, logAudit: boolean, authId: string) {
    return this.remoteObject.call('mFormService', method, command, logAudit, authId).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  sendStartShutdownCommand(method: string, node: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<LabelsAndValues> {
    return this.remoteObject.call('mFormService', method, node, command, isTable, logAudit, authId).pipe(
      map((x: any): any => {
        return x;
      })
    );
  }

  getFraudList(method: string, selectedNode: string, command: string, isTable: boolean,
    logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, selectedNode, command,
      isTable, logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }
  getSecurityList(method: string, nodeName: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  getCurrencyList(method: string, nodeName: string, command: string, isTable: boolean): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getAlarmList(method: string, alarmState: string, fromDate: string, toDate: string, isTable: boolean): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, alarmState, fromDate, toDate, isTable).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  updateAlarmTableDetails(method: string, affectedList, userID: string, logAudit: boolean): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, affectedList, userID, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  sendCustomCommand(method: string, node: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<LabelsAndValues> {
    return this.remoteObject.call('mFormService', method, node, command, isTable, logAudit, authId).pipe(
      map((x: any): any => {
        return x;
      })
    );
  }
  sendDormantAccountCommand(method: string, node, command, isTable, logAudit, authId): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, node, command, isTable, logAudit, authId).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  reAuthenticateUser(method: string, userID: string, pwd: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, userID, pwd).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  // This method is used to get Trace List in the data grid
  getOtraceListResult(method: string, nodeName: string,
    isTable: boolean, logAudit: boolean): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, isTable,
      logAudit).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }
  listFileStatusForSetCmd(method, fileName, logAudit): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, fileName, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  getAdviceManagerSetIndividual(method, site, node, command, selectedFileName, setCommandArr, isTable, logAudit, authId) {
    return this.remoteObject.call('mFormService', method, site, node, command, selectedFileName, setCommandArr,
      isTable, logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }
  getAdviceManagerCommandResult(method: string, site: string, node: string, command: string, isTable: boolean, logAudit: boolean, authId: string) {
    return this.remoteObject.call('mFormService', method, site, node, command, isTable, logAudit, authId).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  getPortManagerCommandResult(method: string, node: string, command: string, isTable: boolean, logAudit: boolean, authId: string) {
    return this.remoteObject.call('mFormService', method, node, command, isTable, logAudit, authId).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  getGGProcessForSite(method: string, site: string, siteLevelList: string, command: string) {
    return this.remoteObject.call('mFormService', method, site, siteLevelList, command).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  sendGGCommandResult(method: string, site: string, group: string, siteLevelList: string, command: string) {
    return this.remoteObject.call('mFormService', method, site, siteLevelList, command).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  sendGGSiteShutdown(method: string, site: string, siteLevelList: string) {
    return this.remoteObject.call('mFormService', method, site, siteLevelList).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  getShcKeyExchangeCommand(method: string, nodeName: string, command: string, isTable: boolean,
    logAudit: boolean, authId: string) {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }
  getVolLicenseMngTasks(method: string, cmdParam: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, cmdParam).pipe(
      map((x: any): object[] => {
        //  console.log('got Node Status response ' + JSON.stringify(x, null, 2));
        return x;
      })
    );
  }
  getTaskLogVolLicenseMngTasks(method: string, cmdParaminstid: string, cmdParamusage: string,
    cmdParamschcmdtype: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, cmdParaminstid, cmdParamschcmdtype, cmdParamusage).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  sendVolumeLicCmd(method: string, node: string, command: any[], command_name: string,
    isTable: boolean, logAudit: boolean, authId: string): Observable<string> {
    return this.remoteObject.call('mFormService', method, command, node, command_name, isTable, logAudit, authId).pipe(
      map((x: string): string => {
        return x;
      })
    );
  }
  deleteSharedMemTasks(method: string, deleteTasklistCollection: any[]): Observable<boolean> {
    return this.remoteObject.call('mFormService', method, deleteTasklistCollection).pipe(
      map((x: boolean): boolean => {
        return x;
      })
    );
  }
  getTSFNodeList(method: string) {
    return this.remoteObject.call('mFormService', method).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  getTSFFileListCommand(method: string, site1Node: string, site2Node: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string) {
    return this.remoteObject.call('mFormService', method, site1Node, site2Node, command,
      isTable, logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }
  getSharedMemTaskLogList(method: string, dateStr: string, command: string) {
    return this.remoteObject.call('mFormService', method, dateStr, command).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  getSharedMemoryTasks(method: string, command: string) {
    return this.remoteObject.call('mFormService', method, command).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  getCardAcntList(method: string) {
    return this.remoteObject.call('mFormService', method).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }
  getSchCommandResult(method: string, nodeList: any, date: string, command: string,
    genSelected: any, balSelected: any, isTable: boolean, logAudit: boolean, authId: string) {
    return this.remoteObject.call('mFormService', method, nodeList, date, command, genSelected, balSelected,
      isTable, logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }
  // IST Monitor requests
  getPortListResult(method: string, node: string, command: string,
    isTable: boolean, logAudit: boolean, authId: string) {
    return this.remoteObject.call('mFormService', method, node, command, isTable, logAudit, authId).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getInstStatus(method: string, siteId: string, node: string, command: string,
    formatNumber: number, logAudit: boolean, authId: string) {
    return this.remoteObject.call('mFormService', method, siteId, node, command, formatNumber, logAudit, authId).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getMsgQ(method: string, siteId: string, node: string, logAudit: boolean) {
    return this.remoteObject.call('mFormService', method, siteId, node, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getATMEX(method: string, logAudit: boolean) {
    return this.remoteObject.call('mFormService', method, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getMsgErrorQ(method: string, siteId: string, node: string, logAudit: boolean) {
    return this.remoteObject.call('mFormService', method, siteId, node, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getAlarmTableDetails(method: string, alarmState: string, fromDate: string, toDate: string, logAudit: boolean) {
    return this.remoteObject.call('mFormService', method, alarmState, fromDate, toDate, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getUpdateAlarmTableDetails(method: string, updateCollection: any, usrVal: string, logAudit: boolean) {
    return this.remoteObject.call('mFormService', method, updateCollection, usrVal, logAudit).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getSite1GGProcess(method: string, site1NodeList: string) {
    return this.remoteObject.call('mFormService', method, site1NodeList).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getSite2GGProcess(method: string, site2NodeList: string) {
    return this.remoteObject.call('mFormService', method, site2NodeList).pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getSysLogInfo(method: string, siteId: string, node: string, level: string, sequence: string,
    fromDate: string, retLines: string, maxLines: string, logAudit: boolean) {
    return this.remoteObject.call('mFormService', method, siteId, node, level, sequence,
      fromDate, retLines, maxLines, logAudit).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  getDefaultSysLogInfo(method: string, siteId: string, node: string, level: string, fromDate: string,
    retLines: string, maxLines: string, logAudit: boolean) {
    return this.remoteObject.call('mFormService', method, siteId, node, level,
      fromDate, retLines, maxLines, logAudit).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  getSysLog(method: string, siteId: string, node: string, level: string, fromDate: string, toDate: string,
    msgId: string, programName: string, retLines: string, maxLines: string, sequence: string, keyword: string, logAudit: boolean) {
    return this.remoteObject.call('mFormService', method, siteId, node, level,
      fromDate, toDate, msgId, programName, retLines, maxLines, sequence, keyword, logAudit).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  filterSysLogInfo(method: string, siteId: string, node: string, fromDate: string, retLines: string,
    keyword: string, sequenceNo: string, maxLines: string, logAudit: boolean) {
    return this.remoteObject.call('mFormService', method, siteId, node, fromDate,
       retLines, keyword, sequenceNo, maxLines, logAudit).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }

  // This method is used to get whole ATM information from database in hierarchical structure
  atmDeviceStatus(): Observable<object[]> {
    return this.remoteObject.call('mFormService', 'atmDeviceStatus').pipe(
      map((x: any): object[] => {
        return x;
      })
    );
  }

  getCMMTBasedPortList(method: string, nodeName: string, command: string, isTable: boolean, logAudit: boolean): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, isTable,
      logAudit).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }
  getInstitutionCommandResult(method: string, nodeName: string, command: string,
     params:any, isTable: boolean, logAudit: boolean, authId: string): Observable<object[]> {
    return this.remoteObject.call('mFormService', method, nodeName, command, params, isTable,
      logAudit, authId).pipe(
        map((x: any): object[] => {
          return x;
        })
      );
  }
  
  getGenKCVCommand(method: string,nodeName: string, key: string, keyChk: string, chkDigit: string,command: string,
     isTable: boolean, logAudit: boolean, authId: string) {
    return this.remoteObject.call('mFormService', method,nodeName, key, keyChk,chkDigit, command,
    isTable, logAudit, authId).pipe(
        map((x: any): string => {
          return x;
        })
      );
  }

}
export class TreeItem {
  isBranch?: string;
  name?: string;
  children?: TreeItem[];
  instid?: string;
  netid?: string;
  groupid?: string;
  atmid?: string;
  termid?: string;
  acceptor?: string;
  atmloc?: string;
  siteid?: string;

}
