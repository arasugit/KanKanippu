import {InjectionToken} from '@angular/core';


export const MON_ENV_CONFIG = new InjectionToken<any>('environment');