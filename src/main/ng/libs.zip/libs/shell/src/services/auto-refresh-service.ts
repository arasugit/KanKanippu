// $Id$
import { Injectable } from '@angular/core';
import { RemoteObjectService } from './remote-object.service';
import { MonConfigService } from './mon-config-service';
import { LabelsAndValues } from '../common';
import { DatePipe } from '@angular/common';
import { ListComponent } from '../components';
import { AppComponent } from '../../../../apps/monitoring-tool/src/app/app.component';
import { GlobalsService } from './globals.service';

@Injectable()
export class AutoRefreshService {
  public autoRefresh: boolean;
  public autoRefreshTimer: any;
  public autoRefreshRetriveDataTimer: any;
  public autoRefreshSearch: boolean = false;
  public lastRefreshTime: string;
  public autoRefreshSeconds: number;
  public listComponent: ListComponent;
  public autoRefreshTimeInterval: number = 15; //seconds
  formatDate = new DatePipe('en_US');
  public currentComponent: ListComponent;
  constructor(public monConfigService: MonConfigService, public globals: GlobalsService) {
    console.log('AutoRefreshService');
  }

  getAutoRefreshTimeInterval(): number {
    this.monConfigService
      .getMonGlobalFieldValueList("auto_refresh_time")
      .subscribe((x: LabelsAndValues) => {
        if(x.array.length>0){
        let configValue = parseInt(x.array[0].value);
        if (configValue && configValue > 15) {
          this.autoRefreshTimeInterval = configValue;
        }
        }
      });
    return this.autoRefreshTimeInterval * 1000;
  }

  updateAutoRefreshInterval() {
    let updatedAutoRefreshTimeInterval = this.getAutoRefreshTimeInterval();
    if (this.autoRefreshSeconds !== updatedAutoRefreshTimeInterval) {
      if (this.autoRefreshTimer) {
        this.clearAutoRefreshInterval();
        this.setAutoRefreshInterval(this.listComponent, updatedAutoRefreshTimeInterval);
      }

      if (this.autoRefreshRetriveDataTimer) {
        this.clearAutoRefreshRetriveDataInterval();
        this.setAutoRefreshRetriveDataInterval(this.listComponent,
          updatedAutoRefreshTimeInterval);
      }
    }
  }

  getAutoRefreshSeconds() {
    this.autoRefreshSeconds = this.getAutoRefreshTimeInterval();
    return this.autoRefreshSeconds;
  }

  updateLastRefreshTime() {
    let date = Date.now();
    this.lastRefreshTime = 'Last Update Time: ' + this.formatDate.transform(date, this.globals.dateFormat) +
    ' at ' +
    this.formatDate.transform(date, 'HH:mm:ss');
   }

   setAutoRefreshSearch(autoRefreshSearch: boolean) {
    this.autoRefreshSearch = autoRefreshSearch;
  }

   setAutoRefreshSearchInterval(component: ListComponent) {
    if (this.autoRefreshSearch && !this.autoRefreshTimer) {
      this.setAutoRefreshInterval(component, this.autoRefreshSeconds);
    }
   }

  setAutoRefreshInterval(component: ListComponent, seconds?: number) {
    this.clearAutoRefreshInterval();
    this.listComponent = component;
    this.autoRefreshTimer = setInterval(() => {
      if (this.autoRefresh) {
        component.search();
        this.updateLastRefreshTime();
      }
    }, seconds? seconds : this.getAutoRefreshSeconds());
    return this.autoRefreshTimer;
  }

  clearAutoRefreshInterval() {
    if (this.autoRefreshTimer) {
      clearInterval(this.autoRefreshTimer);
    }
  }

  setAutoRefreshRetriveDataInterval(component: ListComponent, seconds?: number) {
    this.clearAutoRefreshRetriveDataInterval();
    this.listComponent = component;
    this.autoRefreshRetriveDataTimer = setInterval(() => {
      if (this.autoRefresh) {
        component.retriveData();
        this.updateLastRefreshTime();
      }
    }, seconds? seconds : this.getAutoRefreshTimeInterval());
    return this.autoRefreshRetriveDataTimer;
  }

  clearAutoRefreshRetriveDataInterval() {
    if (this.autoRefreshRetriveDataTimer) {
      clearInterval(this.autoRefreshRetriveDataTimer);
    }
  }

  setCurrentComponent(component: ListComponent) {
    this.currentComponent = component;
  }

  refreshCurrentComponent() {
   AppComponent.myapp.triggerNotification('node_Change');
    this.currentComponent.search();
  }

}
