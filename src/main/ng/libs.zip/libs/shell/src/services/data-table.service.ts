// $Id$
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { WorkCollection, WorkRequest } from '../ist-components/work-request-model';
import { BizService } from './biz.service';
import { GlobalsService } from './globals.service';

@Injectable()
export class DataTableService {
  requestType: String = '';
  action: String = '';
  criteria: {} ;
  collectionTag: string;
  data: WorkRequest = new WorkRequest();
  totalRecords = -1; // For retaining total number of records; this is reset on a fresh search
  changedRow = new Subject<any>();
  changedRowObservable$ = this.changedRow.asObservable();

  constructor(private bizService: BizService, private globals: GlobalsService) {
    //  console.log('Data table service constructor');
    this.criteria = {};
  }
  loadData(fresh: Boolean, isDetailTable: boolean = false): Observable<any> {
    if (fresh === true) {
      this.totalRecords = -1;
    }
    let wc: WorkCollection = new WorkCollection();
    this.globals.showLoadingBar();

    return this.bizService
      .getService(
        this.globals.userContext,
        this.requestType,
        this.action,
        this.criteria
      ).pipe(map((x:any) => {
        if(x){
          this.globals.hideLoadingBar();
        }
          if (!x || x == null)
          {
            return undefined;
          }
          this.data = x as WorkRequest;
          const len = (isDetailTable && this.data.messageId && this.data.messageId !== '') ? +this.data.messageId : this.data.lastModified;
          if (len && +len > 0) {
            this.totalRecords = len;
          }
          wc = this.data.collections[this.collectionTag];
          if (wc) {
            const rows = wc.rows;
            if (rows) {
              if (rows.length <= 0) {
                this.totalRecords = -1;
              }
            }
          }
          this.data.total = this.totalRecords;
          return this.data;
        })
      );
  }

  rowChanged(row: any) {
    this.changedRow.next(row); // inform the subscribers
  }

  save(workRequest: WorkRequest) {
    let wc: WorkCollection = new WorkCollection();
    this.totalRecords = -1;
    if (workRequest) {
      let localWc: WorkCollection;
      if (workRequest.collections!=null&&workRequest.collections[this.collectionTag]) {
        localWc  = workRequest.collections[this.collectionTag];
        localWc.remoteClass = wc.remoteClass;
      }
      // Add the remote class for OLDCOLLECTIONS also;
      if (workRequest.collections.OLDCOLLECTIONS !== undefined) {
        localWc  = workRequest.collections.OLDCOLLECTIONS;
        localWc.remoteClass = wc.remoteClass;
      }
    }

    return this.bizService
      .setService(
        this.globals.userContext,
        this.requestType,
        this.action,
        workRequest
      ).pipe(map((x: any) => {
          if (!x || x == null) {
            return undefined;
          }
          this.data = x as WorkRequest;
          wc = this.data.collections[this.collectionTag];
          if (wc) {
            const rows = wc.rows;
            if (rows) {
              this.totalRecords = rows.length;
            }
          }
          this.data.total = this.totalRecords;
          return this.data;
        })
      );
  }
}
