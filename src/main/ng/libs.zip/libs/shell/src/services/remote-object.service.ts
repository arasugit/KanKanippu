// $Id$

import {Inject, Injectable, InjectionToken, Optional} from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import {Observable,  throwError as _throw ,  of } from 'rxjs';
import { map ,  catchError  ,  switchMap } from 'rxjs/operators';
import { StringUtil } from '../common/ist-string-util';
import * as crypto from 'crypto-js';
import { UserContext } from './user-context';
import { MON_ENV_CONFIG } from './env-config';


@Injectable()
export class RemoteObjectService {
  private baseUrl = '';
  private useSiteMinderKludge;
  private userName = 'admin';
  private haveCookie = false;
  private gettingCookie = false;
  aesKey = '';
  aesKeyIV = '';
  userContext: UserContext;
  private cookieGetter: Observable<boolean>;

  constructor(private http: HttpClient,@Optional()@Inject(MON_ENV_CONFIG) private environment:any) {
    console.log('RemoteService');
    this.useSiteMinderKludge = !environment.production;
    if (!environment.production) {
      let back_end_url = environment['back_end_url'];
      if (!back_end_url) {
        back_end_url = '';
      }
      this.baseUrl = back_end_url;
    }

  }

  private getCookie(): Observable<boolean> {
    if (this.haveCookie) {
      return of(true);
    }
    if (this.cookieGetter !== undefined) {
      return this.cookieGetter;
    }
    const x = this.http.get<String>(`${this.baseUrl}guijs/dummy`, {
      withCredentials: true,
      headers: new HttpHeaders().set('SM_USER', this.userName)
    });
    this.cookieGetter = x.pipe(
      map<String, boolean>( (body, i) => {
        this.haveCookie = true;
        return true;
      }),
      catchError( (err, caught) => {
        if (err['status'] === 404) {
          this.haveCookie = true;
          return of(true);
        }
        return _throw(err);
      })
    );
    return this.cookieGetter;
  }
  call(serviceName: String, methodName: String, ...args: Object[]): Observable<Object> {
    const url = `${this.baseUrl}guijs/${serviceName}/${methodName}`;
    let req: Observable<Object>;
    let encArgs = args; // encArgs will be passed in the request
    if( serviceName === 'mFormService'){
      for (let i = 0; i < encArgs.length; i++) {
          let argValue: any = encArgs[i];
          if(argValue !== undefined && argValue !== null) {
            if(typeof argValue === 'string') {
              encArgs[i] = this.encryptData(argValue);
            }
          }
      }
    }
    encArgs.push((this.userContext !== undefined && this.userContext !== null) ? this.userContext.sessionID : '');
    if (this.useSiteMinderKludge) {
      req = this.getCookie().pipe(
        switchMap(() => this.http.post(url, encArgs, {
          withCredentials: true,
          headers: new HttpHeaders().set('SM_USER', this.userName)
        }))
      );
    } else {
      req = this.http.post(url, encArgs, { withCredentials: true });
    }
    return req;
  }

  monitorCall(serviceName: String, ...args: Object[]): Observable<Object> {
    const url = `${this.baseUrl}${serviceName}`;
    let req: Observable<Object>;
    if (this.useSiteMinderKludge) {
      req = this.getCookie().pipe(
        switchMap(() => this.http.post(url, args, {
          // send the cookie
          withCredentials: true,
          headers: new HttpHeaders().set('SM_USER', this.userName)
        }))
      );
    } else {
      req = this.http.post(url, args, { withCredentials: true });
    }
    return req;
  }

  callServlet(serviceName: String, httpParams?: HttpParams, reponseType?: any, ...args: Object[]): Observable<Object> {
    const url = `${this.baseUrl}${serviceName}`;
    let req: Observable<Object>;
    if (this.useSiteMinderKludge) {
      req = this.getCookie().pipe(
        switchMap(() => this.http.post(url, args, {
          // send the cookie
          withCredentials: true,
          observe: 'events',
          params: httpParams,
          responseType: reponseType,
          reportProgress: true,
          headers: new HttpHeaders().set('SM_USER', this.userName)
        }))
      );
    } else {
      req = this.http.post(url, args, {observe: 'events', reportProgress: true, params: httpParams, responseType: reponseType, withCredentials: true });
    }
    return req;
  }

  private getProductCookie(): Observable<boolean> {
    if (this.haveCookie) {
      return of(true);
    }
    if (this.cookieGetter !== undefined) {
      return this.cookieGetter;
    }
    const x = this.http.get<String>(`${this.baseUrl}product/dummy`, {
      // if we don't set withCredentials, Angular will not remember the cookie we get
      withCredentials: true,
      headers: new HttpHeaders().set('SM_USER', this.userName)
    });
    this.cookieGetter = x.pipe(
      map<String, boolean>( (body, i) => {
        this.haveCookie = true;
        console.log('Got the cookie',body);
        return true;
      }),
      catchError( (err, caught) => {
        if (err['status'] === 404) {
          //  console.log('getCookie got 404, still OK');
          this.haveCookie = true;
          return of(true);
        }
        return _throw(err);
      })
    );
    return this.cookieGetter;
  }

  productCall(): Observable<Object> {
    const url = `${this.baseUrl}product/fetch`;
    let req: Observable<Object>;
    let encArgs=[];
    encArgs.push('');
    if (this.useSiteMinderKludge) {
      req = this.getProductCookie().pipe(
        switchMap(() => this.http.post(url, encArgs, {
          // send the cookie
          withCredentials: true,
          headers: new HttpHeaders().set('SM_USER', this.userName)
        }))
      );
    } else {
      req = this.http.post(url, encArgs, { withCredentials: true });
    }
    return req;
  }

  public getBaseURL(): string {
    return this.baseUrl;
  }

    // encrypt data base AES CBC method
    encryptData(inputValue: string): string {
      // console.log('inputValue - ' + inputValue);
      if (StringUtil.isEmpty(inputValue)) { return inputValue; }
      const encryptData = crypto.AES.encrypt
        (inputValue, this.aesKey, { mode: crypto.mode.CBC, padding: crypto.pad.Pkcs7, iv: this.aesKeyIV });
      return encryptData.toString();
    }
    updateSiteNode(siteId: any, nodeId: any, nodeName: any): Observable<Object> {
      const url = `${this.baseUrl}product/updateSiteNode`;
      let req: Observable<Object>;

      var product={siteId:siteId,nodeId:nodeId,nodeName:nodeName};
      if (this.useSiteMinderKludge) {
        req = this.getProductCookie().pipe(
          switchMap(() => this.http.post(url, product, {
            // send the cookie
            withCredentials: true,
            headers: new HttpHeaders().set('SM_USER', this.userName)
          }))
        );
      } else {
        req = this.http.post(url, product, { withCredentials: true });
      }
      return req;
    }

    getServiceCall(serviceName: String, ...args: Object[]): Observable<Object> {
      const url = `${this.baseUrl}${serviceName}`;
      let req: Observable<Object>;
      if (this.useSiteMinderKludge) {
        req = this.getCookie().pipe(
          switchMap(() => this.http.get<String>(url, {
            // if we don't set withCredentials, Angular will not remember the cookie we get
            withCredentials: true,
            headers: new HttpHeaders().set('SM_USER', this.userName)
          })
        ));
      } else {
        req = this.http.get<String>(url, {
          // if we don't set withCredentials, Angular will not remember the cookie we get
          withCredentials: true,
          headers: new HttpHeaders().set('SM_USER', this.userName)
        });
      }
      return req;
    }
}
