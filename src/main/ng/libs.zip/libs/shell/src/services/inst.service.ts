// $Id$
import { Injectable } from '@angular/core';
import { Observable, of  } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { RemoteObjectService } from './remote-object.service';
import { LabelsAndValues, LabelAndValue } from '../common/labels-and-values';
import { StringMap } from '../common/criteria';


@Injectable()
export class InstService {
  constructor(private remoteObject: RemoteObjectService) {
    console.log('InstService');
  }
  getInstTypes(): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getGlobalValueDescList', 'inst_type')
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }
  getDBRecords(type: String): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getDBRecords', type)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }
  getCountryCodeAlpha2(type: String): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getDBRecords', type)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[2]+'-'+y[1],y[2]);
          });
          return res;
        })
      );
  }
  getDatabaseRecords(type: String, dbParam?: StringMap): Observable<any> {
    if (dbParam !== undefined && dbParam !== null) {
      return this.remoteObject.call('instservice', 'getDBRecords', type, dbParam)
        .pipe(map((x: any[]): any => {
          return x;
        }));
    } else {
      return this.remoteObject.call('instservice', 'getDBRecords', type)
        .pipe(map((x: any[]): any => {
          return x;
        }));
    }
  }
  getGlobalValueCtrlList(fieldName: String): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getGlobalValueDescList', fieldName)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }

  getCardProdGblValList(fieldName: String): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getCardProdGblValList', fieldName)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }

  getComboBoxListByInstitution(instId: String, type: String): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getComboBoxListByInstitution', instId, type)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }
  getMerchantTypeList(cardScheme: String): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getMerchantTypeList', cardScheme)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }
  getAllMerchantTypeList(): Observable<Object> {
    return this.remoteObject
    .call('instservice', 'getMerchantTypeList', 'ALLCS')
      .pipe(
        map(x => {
          return x;
        })
      );
  }
  getSearchListData(type: String, dbParam: StringMap): Observable<Object> {
    return this.remoteObject
      .call('instservice', 'getDBRecords', type, dbParam)
      .pipe(
        map(x => {
          return x;
        })
      );
  }
  getSearchListfromGblVal(type: String): Observable<Object> {
    return this.remoteObject
      .call('instservice', 'getGlobalValueDescList', type)
      .pipe(map(x => {
        return x;
      })
      );
  }

  getCountryList(): Observable<Object> {
    return this.remoteObject
      .call('instservice', 'getDBRecords', 'COUNTRY')
      .pipe(
        map(x => {
          return x;
        })
      );
  }

  getProvinceList(param: string): Observable<Object> {
    return this.remoteObject
      .call('instservice', 'getProvinceList', param)
      .pipe(
        map(x => {
          return x;
        })
      );
  }

  getCountyList(param1: string, param2: string): Observable<Object> {
    return this.remoteObject
      .call('instservice', 'getCountyList', param1, param2)
      .pipe(
        map(x => {
          return x;
        })
      );
  }


  getSwitchFieldValues(institutionId: string, status: string): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getSwitchFieldValues', institutionId, status)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }
  getLocaleInformation(): Observable<any> {
    return this.remoteObject
      .call('instservice', 'getLocaleInformation')
      .pipe(
        map((x: string[][]): any => {
          let res;
          if (x && x.length > 0 ) {
            res = x.map((y: any): any => {
              const temp: any = {};
              temp.desc = y.fieldValueDesc;
              temp.locale = y.fieldValue;
              temp.dateFormat = y.dateFormat;
              temp.currencyFormat = y.currencyFormat;
              return temp;
            });
          } else {
            res = {desc: 'English', locale: 'en-US', dateFormat: 'MM/DD/YYYY', currencyFormat: '' };
          }
          return res;
        }), catchError(error => of({desc: 'English', locale: 'en-US', dateFormat: 'MM/DD/YYYY', currencyFormat: ''}))
      );
  }
  getClientPublicKey(): Observable<Object> {
    return this.remoteObject
      .call('instservice', 'getClientPublicKey')
      .pipe(
        map(x => {
          return x;
        })
      );
  }
  getKeysAndPattern(): Observable<Object> {
    return this.remoteObject
      .call('instservice', 'getKeysAndPattern')
      .pipe(
        map(x => {
          return x;
        })
      );
  }
  getEntityTypeStatus(entityType: String, type: String): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getEntityTypeStatus', entityType, type)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }
  // added to get multiple global value ctrl list
  getMultipleGblList(fieldList: String): Observable<Object> {
    return this.remoteObject
      .call('instservice', 'getMultipleGblList', fieldList)
      .pipe(
        map(x => {
          return x;
        })
      );
  }
// Node Name for SHC Module
  getNodeNameList(siteId: String): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getNodeNameList', siteId)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }

  // Get User BIN List for the selected Institution ID
  getUserBinIDList(instID: string) {
    return this.remoteObject
      .call('instservice', 'getUserBinIDList', instID)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }
  // Get State Code list for the country code 840 - For Hot Card Maintenance screen
  getComboBoxListByParameter(cntryCode: String, type: String): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getComboBoxListByParameter', cntryCode, type)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }
  getListByInstitution(instId: String, type: String): Observable<Object> {
    return this.remoteObject
      .call('instservice', 'getComboBoxListByInstitution', instId, type)
      .pipe(
        map(x => {
          return x;
        })
      );
  }
  getFieldValueCtrlList(institutionId: string, fieldName: string): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('instservice', 'getFieldValueCtrlList', institutionId, fieldName)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[1], y[0]);
          });
          return res;
        })
      );
  }
  getTaskNameList(): Observable<Object> {
    return this.remoteObject
      .call('instservice', 'getDBRecords', 'TASK_NAME_POPUP')
      .pipe(
        map(x => {
          return x;
        })
      );
  }

}
