import { Injectable, NgZone} from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot} from '@angular/router';
import { CanActivate } from '@angular/router';
import { GlobalsService } from './globals.service';



@Injectable()
export class AuthService implements CanActivate {
  constructor(private router: Router,private gblService :GlobalsService) {}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {   
    return this.verifyToNavigate(this.gblService.productId,state.url);    
  }
  verifyToNavigate(product:string,routerUrl:string):boolean{
    const atmComponent: string[] = ['ATMAVL_REQ', 'ATMDWM_REQ', 'ATMDWB_REQ', 'ATMDWS_REQ', 'ATMUPT_REQ', 'ATMFLTVIEW', 'ATMRTCASH'];
    routerUrl = routerUrl.substring(routerUrl.lastIndexOf("/")+1); 
    const index = atmComponent.indexOf(routerUrl);       
    if (product !=null && product !== undefined && product=== 'ISTSWT' && index > -1) {
      return true;
    } else if (product!=null && product !== 'ISTSWT' && index > -1) {
      return false;
    } else {
      return true;
    } 
  }

}