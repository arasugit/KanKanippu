import { NativeDateAdapter } from "@angular/material/core";

export class ISTDateAdapter extends NativeDateAdapter { }
