// $Id$
import {Injectable} from '@angular/core';
import {Observable,  throwError as _throw } from 'rxjs';
import { map ,  catchError } from 'rxjs/operators';

import { RemoteObjectService } from './remote-object.service';
import { UserContextResponse, ConfigOptionsResponse, ApplicationMessageResponse } from './response-base';
import { WorkRequest, WorkField } from '../ist-components/work-request-model';
import { UserContext } from './user-context';
import { UIMetadata, UIMetaField } from '../common/vo/ui-metadata-model';
import { StringMap } from '../common/criteria';

@Injectable()
export class BizService {
  static readonly SERVICE_NAME = 'bizservice';
  constructor(private remoteObject: RemoteObjectService) {
    //console.log('bizservice');
  }
  getUserContext(): Observable<UserContext> {
    return this.remoteObject.call(BizService.SERVICE_NAME, 'getUserContext').pipe(
      map( (x: UserContextResponse) => {
        const context: UserContext = x.userContext;
        return context;
      } )
    );
  }
  getConfigOptions(context: UserContext): Observable< StringMap > {
    return this.remoteObject.call(BizService.SERVICE_NAME, 'getConfigOptions', context).pipe(
      map( (x: ConfigOptionsResponse) => {
          return x.configOptions;
        })
      );
  }

  getApplicationMessages(context: UserContext): Observable< StringMap > {
    return this.remoteObject.call(BizService.SERVICE_NAME, 'getApplicationMessages', context).pipe(
      map( (x: ApplicationMessageResponse) => {
          return x.applicationMessages;
        })
      );
  }

  getService(context: UserContext, requestType: String, action: String, criteria: any) {
    return this.remoteObject.call(BizService.SERVICE_NAME, 'getService', context, requestType, action, criteria);
  }
  processCfgSvcService(context: UserContext, action: String, params: StringMap) {
    return this.remoteObject.call(BizService.SERVICE_NAME, 'processCfgSvcService', context, action, params);
  }
  setService(context: UserContext, requestType: String, action: String, workRequest: WorkRequest) {
    if (workRequest) {
      workRequest.remoteClass = WorkRequest.remoteClassName;
      const fields = workRequest.fields;
      if (fields) {
        for (const fieldName in fields) {
          if (1) { // shut up tslint
            const field = fields[fieldName];
            field.remoteClass = WorkField.remoteClassName;
          }
        }
        const collections = workRequest.collections;
        for (const collectionName in collections) {
          if (1) {
            const collection = collections[collectionName];
            if (collection) {
              const uifields = collection.fields;
              if (uifields) {
                for (const fieldName in uifields) {
                  if (1) {
                    const uifield = uifields[fieldName];
                    if (uifield) {
                      uifield.remoteClass = UIMetaField.remoteClassName;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return this.remoteObject.call(BizService.SERVICE_NAME, 'setService', context, requestType, action, workRequest);
  }
  getUIMetaData(userContext: UserContext, requestType: String): Observable<UIMetadata> {
    return this.remoteObject
      .call(
        BizService.SERVICE_NAME,
        'getUIMetaData',
        userContext,
        requestType
      ).pipe(
        map((x: UIMetadata) => {
          return x;
        }),
        catchError((error: any) => {
          return _throw(error);
        })
      );
  }
}
