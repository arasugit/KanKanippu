export class UserContext {
  sessionID: string; // csrf token
  userID: string;
  userRole: string;
  lastLoginDateTime: Date;
  lastLoginDateTimeOidc: string;
}
