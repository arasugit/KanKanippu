import { Injectable } from '@angular/core';
import { Router, Params, ActivatedRouteSnapshot, UrlSegment } from '@angular/router';
import { FormCallingStackEntry, FormNavigator } from '../ist-components/form-navigation';
import { GlobalsService } from './globals.service';

class TreeItem {
    isBranch?: string;
    name?: string;
    children?: TreeItem[];
    instid?: string;
    netid?: string;
    groupid?: string;
    atmid?: string;
    termid?: string;
    acceptor?: string;
    atmloc?: string;
    siteid?: string;
  
  }
  
@Injectable()
export class FormNavigationService {
    constructor(
        private router: Router,
        private globalsService: GlobalsService
    ) {

        console.log('FormNavigationService');
    }
    public callForm(
        route: ActivatedRouteSnapshot,
        new_url: string,
        command: any,
        breadcrumbText?: string
    ): void {
        GlobalsService.isNextStep = true;
        GlobalsService.isRedirected = true;
        if(command['status_code'] !== undefined){
        GlobalsService.param = command['status_code'];
        }
        const stack = this.globalsService.stack;
        const old_url = this.buildUrl(route);
        const command_key = '' + stack.command_counter++;
        stack.commands[command_key] = command;
        if (!breadcrumbText) {
            breadcrumbText = old_url.replace(/^.*\//, '');
        }
        stack.arr.push(new FormCallingStackEntry(old_url, command_key, breadcrumbText));
        stack.callingForm = true;
        this.router.navigate([
            new_url,
            {
                COMMAND: 'indirect',
                k: command_key
            }
        ])
            .then(() => {
                this.clearStatusMessage();
            })
            .catch((e: Error) => {
                if (this.globalsService.checkErrorResponse(e)) {
                    stack.callingForm = false;
                    delete stack.commands[command_key];
                    stack.arr.pop();
                }
            });
    }

    public retrieveFormParams(command: {COMMAND?: string, k?: string}): Params {
        console.log('retrieveFormParams called'+command.COMMAND );
        if (command.COMMAND === 'indirect') {
            
            let params: Params = this.globalsService.stack.commands[command.k] as Params;
            if (params === undefined) {
                params = {};
            }
            return params;
        }
        if (command.COMMAND === 'return') {
            console.log('retrieveFormParams called');
            let params: Params = this.globalsService.stack.commands[command.k] as Params;
            console.log(' ret params', params);
            const changed = command['changed'];
            const newCmd = { ... command, changed: 'true' === changed};
            command = newCmd;
        }
        return command as Params;
    }
    public returnFromForm(changed: boolean, additionalParams?:{}) {
        const stack = this.globalsService.stack;
        if (additionalParams === undefined || additionalParams === null)
             FormNavigator.returnFromForm(stack, this.router, changed);
        else
        FormNavigator.returnFromFormWithParams(stack, this.router, changed,additionalParams);
    }
    
    public returnToBreadcrumb(crumbIndex: number) {
        this.clearStatusMessage();
        const stack = this.globalsService.stack;
        FormNavigator.returnToBreadcrumb(stack, this.router, crumbIndex);
    }
    public buildUrl(route: ActivatedRouteSnapshot): string {
        return FormNavigator.buildUrl(route);
    }
    public clearStack(): void {
        FormNavigator.clearStack(this.globalsService.stack);
    }
    private clearStatusMessage(): void {
        this.globalsService.setStatusMessage('');
    }
    public redirectToPage(
        route: ActivatedRouteSnapshot,
        new_url: string,
        command: any,
        breadcrumbText?: string
    ): void {
        GlobalsService.isNextStep = true;
        GlobalsService.isRedirected = true;
        const stack = this.globalsService.stack;
        const old_url = this.buildUrl(route);
        const command_key = '' + stack.command_counter++;
        stack.commands[command_key] = command;
        if (!breadcrumbText) {
            breadcrumbText = old_url.replace(/^.*\//, '');
        }
        stack.arr.push(new FormCallingStackEntry(old_url, command_key, breadcrumbText));
        stack.callingForm = true;
        this.router.navigate([
            new_url,
            {
                COMMAND: 'indirect',
                statusCode:command.statusCode,
                k: command_key
            }
        ])
            .then(() => {
                this.clearStatusMessage();
            })
            .catch((e: Error) => {
                if (this.globalsService.checkErrorResponse(e)) {
                    stack.callingForm = false;
                    delete stack.commands[command_key];
                    stack.arr.pop();
                }
            });
    }
}
