// $Id$
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import { map } from 'rxjs/operators';
import { RemoteObjectService } from './remote-object.service';
import { RequestedPermission } from '../permission/requested.permission';


export class MenuItem {
  path?: string;
  label?: string;
  children?: MenuItem[];
}
@Injectable()
export class MenuService {
  constructor(private remoteObject: RemoteObjectService) {
    console.log('MenuService');
  }
  private map_menu(x: Object, isRoot: boolean = true): MenuItem[] {
    if (!x) {
      return undefined;
    }
    const inp = [].concat(x);
    const res = [];
    for (const m of inp) {
      const m2 = new MenuItem();
      let val = m['@label'];
      if (val) {
        m2.label = val;
      }
      val = m['@url'];
      if (val) {
        m2.path = val;
      } else {
        val = m['@module_name'];
        if (val) {
          m2.path = 'monitor/' + val;
        }
      }
      if (!val) {
        const children = this.map_menu(m['menuitem'], false);
        if (children && children.length > 0) {
          m2.children = children;
        }
      }
      // ruf megamenu requires the path for top-level items
      if (isRoot) {
        if (!(m2.path)) {
          m2.path = '.';
        }
      }
      res.push(m2);
    }
    return res;
  }
  private map_menu2(x: MenuItem[], level: number = 1): MenuItem[] {
    if (level === 1) {
      for (let i = 0; i < x.length; ++i) {
        const m = x[i];
        m.children = this.map_menu2(m.children, 2);
      }
      return x;
    }
    if (level === 2) {
      const new_level_2 = [];
      const push_to_level3 = [];
      for (let i = 0; i < x.length; ++i) {
        const m = x[i];
        if (m.path) {
          push_to_level3.push(m);
        } else {
          new_level_2.push(m);
          if (m.children) {
            let j = 0;
            while (j < m.children.length) {
              const ch = m.children[j];
              if (ch.children) { // pull it up a level
                new_level_2.push(ch);
                m.children.splice(j, 1);
              } else {
                ++j;
              }
            }
          }
        }
      }
      if (push_to_level3) {
        const new_m = new MenuItem();
        new_m.label = '';
        new_m.children = push_to_level3;
        new_level_2.splice(0, 0, new_m);
      }
      return new_level_2;
    }
    return x;
  }
  getMenu(productId: string): Observable<MenuItem[]> {
    return this.remoteObject.call('menuService', 'getMenu', productId).pipe(
      map(x => {
        let m2:any=[];
        if (x !== undefined && x !== null) {
          m2 = this.map_menu(x['menuitem']);
        }
        return m2;
      })
    );
  }
  private map_menu4(x: Object): MenuItem[] {
    if (!x) {
      return undefined;
    }
    const inp = [].concat(x);
    const res = [];
    for (const m of inp) {
      const m2 = new MenuItem();
      let val = m['@label'];
      if (val) {
        m2.label = val;
      }
      val = m['@url'];
      if (val) {
        m2.path = val;
      } else {
        val = m['@module_name'];
        if (val) {
          m2.path = 'monitor/' + val;
        }
      }
      if (!val) {
        const children = this.map_menu4(m['menuitem']);
        if (children && children.length > 0) {
          m2.children = children;
        }
      }
      res.push(m2);
    }
    return res;
  }
  getMenu2(): Observable<MenuItem[]> {
    return this.remoteObject.call('menuService', 'getMenu').pipe(
      map(x => {
        let m2 = [];
        if (x !== undefined && x !== null) {
          m2 = this.map_menu4(x['menuitem']);
        }
        return m2;
      })
    );
  }
  checkPermissions(url: String, requestedPermissions: RequestedPermission[]): Observable<RequestedPermission[]> {
    return this.remoteObject.call('menuService', 'checkPermissions', url, requestedPermissions).pipe(
      map((x: RequestedPermission[]) => {
        return x;
      })
    );
  }
  getScreenNames(): Observable<any> {
    return this.remoteObject
      .call('menuService', 'getEntDescriptions')
      .pipe(
        map( (x: any[]): any => {
           return x;
        })
      );
  }

  getAcqEntityCLRFlag(): Observable<any> {
    return this.remoteObject
      .call('menuService', 'getAcqEntityCLRRequired')
      .pipe(
        map( (x: any[]): any => {
           return x;
        })
      );
  }
  getEditStatus(): Observable<any> {
    return this.remoteObject.call('menuService', 'getEditStatus').pipe(
      map((x: any) => {
        return x;
      })
    );
  }
  setEditStatus(transSeqNbr: String, userName: String): Observable<any> {
    return this.remoteObject.call('menuService', 'setEditStatus', transSeqNbr, userName).pipe(
      map((x: any) => {
        return x;
      })
    );
  }
  removingEditStatus(userName: String): Observable<any> {
    return this.remoteObject.call('menuService', 'removingEditStatus', userName).pipe(
      map((x: any) => {
        return x;
      })
    );
  }
}
