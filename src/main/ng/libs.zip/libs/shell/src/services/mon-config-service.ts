// $Id$
import { Injectable } from '@angular/core';
import { Observable, of  } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { RemoteObjectService } from './remote-object.service';
import { LabelsAndValues, LabelAndValue } from '../common/labels-and-values';


@Injectable()
export class MonConfigService {
  constructor(private remoteObject: RemoteObjectService) {
    console.log('MonConfigService');
  }
  
  getMonGlobalFieldValueList(fieldName: string): Observable<LabelsAndValues> {
    return this.remoteObject
      .call('monconfigservice', 'getMonGlobalFieldValueList', fieldName)
      .pipe(
        map((x: string[][]): LabelsAndValues => {
          const res = new LabelsAndValues();
          res.array = x.map((y: string[]): LabelAndValue => {
            return new LabelAndValue(y[0], y[1]);
          });
          return res;
        })
      );
  }

}
