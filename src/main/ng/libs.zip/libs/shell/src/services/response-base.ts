// $Id$
import { UserContext } from './user-context';
import { StringMap } from '../common/criteria';

export class ResponseBase {
    public static readonly REQUEST_RESULT_ERROR = 'Error';
    public static readonly REQUEST_RESULT_SUCCESS = 'Success';
    messageId: string;
    requestResult: string;
    errorDetail: string;
    messageSubstitutions: string[];
    messageFieldTag: string;
    createTimeMillis: number;
    stats: Object;
    systemFailure: boolean;
}
export class UserContextResponse extends ResponseBase {
    userContext: UserContext;
}

export class ConfigOptionsResponse extends ResponseBase {
    configOptions: StringMap;
}
export class ApplicationMessageResponse extends ResponseBase {
    applicationMessages: StringMap;
}
