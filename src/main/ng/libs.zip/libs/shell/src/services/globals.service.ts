// $Id$
import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { IstDialogComponent } from '../components/ist-dialog-component';
import { InstService } from './inst.service';
import * as crypto from 'crypto-js';
import { StringUtil } from '../common/ist-string-util';
import { UIMetadata } from '../common/vo/ui-metadata-model';
import { Observable, Subject, lastValueFrom, of } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { IstProgressBarComponent } from '../components/ist-progress-bar-component';
import { FormCallingStack } from '../ist-components/form-navigation';
import { BizService } from './biz.service';
import { UserContext } from './user-context';
import { RemoteObjectService } from './remote-object.service';
import { CommonConstants } from '../common/ist.common.constants';
import { MenuService } from './menu.service';
import { CustomValidators } from '../common/ist-validators';
import { DatePipe } from '@angular/common';
import { LabelsAndValues } from '../common';
import { config } from 'process';
import { NgxSpinnerService } from 'ngx-spinner';


declare var RSAKey: any;
declare var Product: any;


@Injectable()
export class GlobalsService {
  constructor(private bizService: BizService,
    private instService: InstService,
    private menuService:MenuService,
    public rmservice: RemoteObjectService,
    private dialog: MatDialog,
    private spinner: NgxSpinnerService
  ) {

    }
  private progressBarRef: MatDialogRef<IstProgressBarComponent>;
  static isNextStep: boolean = false;
  static isRedirected: boolean = false;
  static param: any = '';
  static eventName='';
  static txnSrcAcq='';
  static txnSrcIss='';
  userContext: UserContext;
  configOptions: {};
  applicationMessages: {};
  stack: FormCallingStack = new FormCallingStack();
  statusMessage: String = '';
  statusMessageColor: String = 'green';
  isDualSite = false;
  siteId = 1;
  nodeName = "";
  nodeId = 1;
  currentAppName = '';
  authType = '';
  sessionTimeoutWarning: number = 0; //Default no warning before session timeout
  sessionTimeout: number = 15; // Default to 15 minutes
  authModeFlg = false;
  istcmscustomapp = '';
  istcmsappFlg = false;
  isSwitchInstalled = false;
  isMasInstalled = false;
  isClearingInstalled = false;
  isCortexInstalled = false;
  isMKCIncluded = false;
  isSocgenInstalled = false;
  isAuthInstalled = false;
  isPosInstalled = false;
  isMSAMInstalled = false;
  systemAllowedChars:any = null;
  rsaPublicKey = '';
  aesKey = '';
  aesKeyIV = '';
  showPlainText: boolean;
  currentLanguage = 'en-US';
  currentModuleTobeLoaded = '';
  loadedLocaleModules = [];
  dateFormat = 'MM/dd/yyyy';
  dateTimeFormat = 'MM/dd/yyyy HH:mm:ss';
  _currencyProp = '2,.'; // defauldecimaldigits, groupseparator, decimalseparator
  defFractionDigits = 2;
  groupSeparator = ',';
  decimalSeparator = '.';
  isClearing24Installed = false;
  isClearing25Installed = false;
  savedFields = {}; // this is used to pass the data from detail to list screen.
  customDateMask : boolean = false;
  customCurrency : boolean = false;
  customCurrencyProp = "2 ,:fr";
  customCurrencyLanguage = 'en';
  isMasVoltageNeeded = false;
  istMasGeoCode = false;
  isFirstdataInstalled = false;
  productId;
  productName;
  availableMenuItems = [];
  formatDate = new DatePipe('en_US');
  public incidentSubject$ = new Subject();
  public rowHighlightedSubject$ = new Subject();
  public tableNameRetCnfSubject$ = new Subject();
  loadConfig(): Observable<boolean> {

    if (this.configOptions !== undefined) {
      return of(true);
    }
    return this.bizService.getUserContext()
      .pipe(
        tap((x: UserContext) => {
          this.userContext = x;
          this.rmservice.userContext= this.userContext;
        }),
        switchMap((x: UserContext) => this.bizService.getConfigOptions(x)),
        tap((options: {}) => {
          this.configOptions = options;
          this.setSelectedProductDetails();
          this.setSystemParameters();
          this.setCustomCurrency();
          if (this.isClearingInstalled) {
            const clr25 = this.getProperty('ist_clearing_25_installed');
            if (clr25 !== undefined && clr25 !== '' && clr25 === 'true') {
              this.isClearing25Installed = true;
            }
          }
        }),
        switchMap(() => this.bizService.getApplicationMessages(this.userContext)),
        tap((messages: {}) => {
          this.applicationMessages = messages;
        }),


        switchMap(() => this.instService.getKeysAndPattern()),
        tap((results: {}) => {
          this.rsaPublicKey = results[0];
          if (this.rsaPublicKey.length === 0) {
          }
          this.aesKey = results[1];
          if (this.aesKey.length === 0) {
          } else {
            this.aesKey = crypto.enc.Base64.parse(this.aesKey);
            this.rmservice.aesKey = this.aesKey;
            this.aesKeyIV = this.aesKey;
            this.rmservice.aesKeyIV = this.aesKeyIV;
          }
          if (StringUtil.isNotEmpty(results[2])) { this.showPlainText = false; } else { this.showPlainText = true; }
          this.setCustomDateMask();
        }),
        map(() => true)
      );
  }

  setSystemParameters() {
    let value = this.getProperty('ist_dual_site');
    this.isDualSite = (value === 'true') ? true : false;
    value = this.getProperty('ist_site_id');
    this.siteId = (value !== null && value !== '') ? Number(value) : 0;
    this.authType = this.getProperty('ist.authentication');
    this.authModeFlg = (this.authType !== null && this.authType === 'oassrv') ? true : false;
    this.istcmscustomapp = this.getProperty('ist.istcms_custom_app');
    this.istcmsappFlg = (this.istcmscustomapp !== null && this.istcmscustomapp === 'true') ? true : false;
    this.currentAppName = this.getProperty('ist.current_app_name');
    if (this.currentAppName === 'merchant') {
      this.isMSAMInstalled = true;
    }
    let val = this.getProperty('ist.swrecavailable');
    if ((val !== null && val !== '' && val === 'true') || this.currentAppName === 'switch') {
      this.isSwitchInstalled = true;
    }
    val = this.getProperty('ist.masrecavailable');
    if ((val !== null && val !== '' && val === 'true') || this.currentAppName === 'masg') {
      this.isMasInstalled = true;
    }
    val = this.getProperty('ist.clrrecavailable');
    if ((val !== null && val !== '' && val === 'true') || this.currentAppName === 'clearing') {
      this.isClearingInstalled = true;
    }
    val = this.getProperty('cortex_included');
    if ((val !== null && val !== '' && val === 'true')) {
      this.isCortexInstalled = true;
    }
    val = this.getProperty('ist_mkc_included');
    if (StringUtil.isNotEmpty(val) && val === 'true') {
      this.isMKCIncluded = true;
    }
    val = this.getProperty('socgen.report.installed');
    if (StringUtil.isNotEmpty(val) && val === 'true') {
      this.isSocgenInstalled = true;
    }
    val = this.getProperty('ist_pos_included');
    if (StringUtil.isNotEmpty(val) && val === 'true') {
      this.isPosInstalled = true;
    }
    val = this.getProperty('application.textinput.chars');
    if (StringUtil.isNotEmpty(val)) {
      this.systemAllowedChars = val;
    }
	  val = this.getProperty('ist_mas_voltage_needed');
    console.log('ist_mas_voltage_needed', val);
    if (StringUtil.isNotEmpty(val)&& val === 'true') {
      this.isMasVoltageNeeded = true;
    }
	  val = this.getProperty('ist_mas_geoCode');
    console.log('ist_mas_geoCode', val);
    if (StringUtil.isNotEmpty(val)&& val === 'yes') {
      this.istMasGeoCode = true;
    }

    val = this.getProperty('ist.paymon.inputDateFormat');
    if (StringUtil.isNotEmpty(val)) {
      this.dateFormat = val;
    }
    val = this.getProperty('ist.paymon.inputTimeFormat');
    if (StringUtil.isNotEmpty(val)) {
      this.dateTimeFormat = val;
    }
  }

  getProperty(propertyName: string): string {
    let value = '';
    if (propertyName) {
      value = this.configOptions[propertyName];
    }
    return value;
  }
  setStatusMessage(messageId: String): void {
    if (messageId === ('MSG02')) {
      this.statusMessageColor = 'red';
    } else {
      this.statusMessageColor = 'green'; // should it be any other color?
    }
    this.setMessage(this.getMessage(messageId));
  }

  setErrorMessage(messageId: String): void {
    this.statusMessageColor = 'red';
    this.setMessage(this.getMessage(messageId));
  }

  private setMessage(message: String): void {
    this.statusMessage = message;
  }

  getMessage(messageId: String): string {
    let message: String = '';
    if (this.applicationMessages === undefined) {
      message = messageId;
    } else {
      message = this.applicationMessages['' + messageId];
      message = (message === null || message === undefined) ? messageId : message;
    }
    return message as string;
  }

  // will check the openDialog -- added for Control
  showControlDialog(type: String, messageId: String, buttonFlags: number, yesLabel?: string, noLabel?: string,preventOpenDialog?: boolean): Observable<String>|undefined {
    console.log(' ErrorDialog opened , preventOpenDialog', this.dialog.openDialogs.length, preventOpenDialog);
    if(this.dialog.openDialogs && this.dialog.openDialogs.length > 3){  // 1 is for single record view
          return undefined;
    }
    return this.displayDialog(type,messageId,buttonFlags,yesLabel,noLabel)
  }
  errorDialog(type: String, messageId: String, buttonFlags: number, yesLabel?: string, noLabel?: string,preventOpenDialog?: boolean): Observable<String>|undefined {
    console.log(' ErrorDialog opened , preventOpenDialog', this.dialog.openDialogs.length, preventOpenDialog);
    if(this.dialog.openDialogs && this.dialog.openDialogs.length > 1){  // 1 is for single record view
          return undefined;
    }
    return this.displayDialog(type,messageId,buttonFlags,yesLabel,noLabel)
  }
  showDialog(type: String, messageId: String, buttonFlags: number, yesLabel?: string, noLabel?: string,preventOpenDialog?: boolean,
    height?: string, width?: string): Observable<String>|undefined {
    console.log(' dialog opened , preventOpenDialog', this.dialog.openDialogs.length, preventOpenDialog);
    if(this.dialog.openDialogs && this.dialog.openDialogs.length > 1){ // dialog is opened once, prevent opening the same when shortcut key clicked
          return undefined;
    }
    return this.displayDialog(type,messageId,buttonFlags,yesLabel,noLabel, height, width)
  }

  displayDialog(type: String, messageId: String, buttonFlags: number, yesLabel?: string, noLabel?: string,
      height?: string, width?: string): Observable<String> {
    let ref;
    if (height != undefined && width != undefined) {
      ref = this.dialog.open(IstDialogComponent, {
        height: height,
        width: width
      });
    } else {
      ref = this.dialog.open(IstDialogComponent, {
        height: '25%',
        width: '20%'
      });
    }
    ref.componentInstance.confirmMessage = this.getMessage(messageId);
    ref.componentInstance.type = type;
    console.log('show Dialog', yesLabel, noLabel);
    if (yesLabel!=undefined&&StringUtil.isNotEmpty(yesLabel)) {
      ref.componentInstance.yesLabel = yesLabel!=undefined?yesLabel:'' ;
      console.log('show Dialog yesLabel', yesLabel);
    }
    if (noLabel!=undefined && StringUtil.isNotEmpty(noLabel)) {
      ref.componentInstance.noLabel = noLabel!=undefined?noLabel:'';
      console.log('show Dialog noLabel', noLabel);
    }

    ref.componentInstance.buttonFlags = buttonFlags;
    ref.disableClose = true;
    return ref.afterClosed();
  }
  // get RSA public key
  getRSAKey(): string { // it is not really required
    return this.rsaPublicKey;
  }

  // encryptPassword based on RSA
  encryptPassword(inputValue: string): string {
    const rsa = new RSAKey();
    rsa.setPublic(this.getRSAKey(), '10001');
    const encryptData = rsa.encrypt(inputValue);
    return encryptData;
  }

  // encryptPassword based on AES and then RSA for password
  encryptPasswordAESRSA(inputValue: string): string {
    const rsa = new RSAKey();
    rsa.setPublic(this.getRSAKey(), '10001');
    const encryptData = rsa.encrypt(this.encryptData(inputValue));
    return encryptData;
  }

  // get AES key   // it is not really required.
  getAESKey(): string {
    return this.aesKey;
  }
  // encrypt data base AES CBC method
  encryptData(inputValue: string): string {
    if (StringUtil.isEmpty(inputValue)) { return inputValue; }
    const encryptData = crypto.AES.encrypt
      (inputValue, this.aesKey, { mode: crypto.mode.CBC, padding: crypto.pad.Pkcs7, iv: this.aesKeyIV });
    return encryptData.toString();
  }
  // decrypt data base AES CBC method
  decryptData(inputValue: string): string {

    if (StringUtil.isEmpty(inputValue)) { return inputValue; }
    const decryptData = crypto.AES.decrypt
      (inputValue, this.aesKey, { mode: crypto.mode.CBC, padding: crypto.pad.Pkcs7, iv: this.aesKeyIV });
    return decryptData.toString(crypto.enc.Utf8);

  }

  getMetaData(metadatId: string, showProgress: boolean): Observable<UIMetadata> {
    if (showProgress) {
      this.showLoadingBar();
    }
    return this.bizService.getUIMetaData(this.userContext, metadatId)
      .pipe(
        map((result: UIMetadata) => {
          if (showProgress) {
            this.hideLoadingBar();
          }
          return result;
        })
      );
  }

  getMetaData2(metadatId: string): Observable<UIMetadata> {
    return this.bizService.getUIMetaData(this.userContext, metadatId)
      .pipe(
        map((result: UIMetadata) => {
          return result;
        })
      );
  }

  showLoadingBar(): void {
    // this.progressBarRef = this.dialog.open(IstProgressBarComponent, {
    //   disableClose: true,
    //   hasBackdrop: true
    // });
     setTimeout(() => {
      this.spinner.show();
    }, 10);


    // setTimeout(() => {
    //   this.spinner.hide();
    // }, 2000);
  }
  hideLoaderBar(): void {
    // this.dialog.closeAll();
    setTimeout(() => {
      this.spinner.hide();
    }, 500);
  }
  set currencyProp(value) {
    this._currencyProp = (this.customCurrency)?this.customCurrencyProp:value;
    console.log( this._currencyProp);
    let temp;
    if (this._currencyProp.length >= 3) {
      temp = this._currencyProp.substr(0, 1);
      if (temp !== -1) {
        this.defFractionDigits = temp;
      } else {
        this.defFractionDigits = 0;
      }
      this.groupSeparator = this._currencyProp.substr(1, 1);
      this.decimalSeparator = this._currencyProp.substr(2, 1);
    } else {
    }
  }
  hideLoadingBar(): Observable<any> {
    // this.progressBarRef.close();
    setTimeout(() => {
      this.spinner.hide();
    }, 500);

    return {} as Observable<any>;
  }

  getRedirectUrl(): string {
    let url = this.rmservice.getBaseURL();
    if (url !== null && url !== '') {
      url = url + 'j_spring_security_logout'; // development
    } else {
      url = 'j_spring_security_logout'; // production
    }
    return url;
  }

  checkErrorResponse(err: any): boolean {
    let value: boolean = true;
    if (err !== undefined && err !== null) {
      const message: string = (err && err.hasOwnProperty('message')) ? err['message'] : '';
      const url: string = (err && err.hasOwnProperty('url')) ? err['url'] : '';
      const status: any = (err && err.hasOwnProperty('status')) ? err['status'] : '';
      console.log('status' + status);
      console.log('message' + message);
      console.log('url' + url);
      if (StringUtil.isNotEmpty(message) && ((message.indexOf('Http failure response') > -1  &&
      (status === '0' || status === 0 || status === '404' || status === 404 || status === '500' || status === 500
      || status === '200' || status === 200))
      || message.indexOf('Loading chunk') > -1)) {
        value = false;
        this.showDialog(CommonConstants.WARNING, 'ER499', CommonConstants.ALERT_OK)?.subscribe(result => {
            let baseurl: string = this.rmservice.getBaseURL();
            if (StringUtil.isNotEmpty(url)) {// development
              baseurl = baseurl + 'login.jsp';
            } else { //production
              const safeBrowserUrl = this.getSafeUrl(window.location.href);
              if (safeBrowserUrl.indexOf('/forms/') > -1) {
                baseurl = safeBrowserUrl.substring(0, safeBrowserUrl.indexOf('/forms/')) + '/' + 'login.jsp';
              } else {
                baseurl = safeBrowserUrl + 'login.jsp'
              }
              console.log('chandan baseurl' + baseurl);
            }
            try {
              const url1 = new URL(baseurl);
              const url = encodeURI(baseurl);
              if(url1.protocol === 'http:' || url1.protocol === 'https:') {
                window.location.href = url;
              }
            } catch(e) {}
          });
      }//user session is killed by someone.
      else if (StringUtil.isNotEmpty(url) && (url.indexOf('timeout.jsp') > -1 || url.indexOf('login.jsp') > -1)) {
        value = false;
        this.showDialog(CommonConstants.WARNING, 'ER499', CommonConstants.ALERT_OK)?.
          subscribe(result => {
            window.location.href = url;
          });
      }
    }
    return value;
  }

  getSafeUrl(location) {
    try {
      const url = new URL(location);

      if(url.protocol !== 'https:' && url.protocol !== 'http:' && url.origin !== window.location.origin) return '';

      var safeUrl = `${url.protocol}${url.hostname}${url.pathname}`;
      const sanitizedUri = encodeURIComponent(safeUrl);
      safeUrl = `${safeUrl}?${sanitizedUri}`;
      return safeUrl;
    }
    catch(error) {
      return '';
    }
  }

  setCustomDateMask(){

    this.instService.getGlobalValueCtrlList("apply_custom_date_mask").pipe(
      map(x => {
        const customMask  = x['arr'];
        if(customMask && customMask.length > 0){
        const maskValue = customMask[0];
         const mask =  maskValue.value;
         if(mask && (  maskValue.value.toLowerCase() == "yes" || maskValue.value.toLowerCase() == "y")) {
              this.customDateMask = true;
         }
        }
      })).toPromise();
  }


  private _currentURL="";
  public getCurrentURL():string {
    return this._currentURL;
  }
  public setCurrentURL(url:string) {
    console.log('current url', url);
     this._currentURL = url;
  }
  public resetCurrentURL(compTitle:any) {
    let currUrl = this.getCurrentURL();
    if (StringUtil.isNotEmpty(currUrl)) {
        let lastpos = currUrl.indexOf('/'+compTitle);
        if (lastpos !== -1) {
          let path = currUrl.substring(0,lastpos);
         // if (StringUtil.isNotEmpty(path))
             this.setCurrentURL(path);
        }
      }
  }
  setCustomCurrency(){
    this.instService.getGlobalValueCtrlList("apply_custom_currency").pipe(
      map(x => {
        const customCurrFormat = x['arr'];
        if(customCurrFormat && customCurrFormat.length > 0){
          const currValue = customCurrFormat[0];
          const desc = currValue.label;
          if(desc && (  desc.toLowerCase() == "yes" || desc.toLowerCase() == "y")) {
            this.customCurrency = true;
            const value =  currValue.value;
            if(StringUtil.isNotEmpty(value)){
              this.customCurrencyProp = value;
              let language = value.split(":");
              this.customCurrencyLanguage = language && language.length > 0 ? language[1] : 'en';
            }
            else{
              this.customCurrencyProp = "2,.";
              this.customCurrencyLanguage = "en"
            }
          }
        }
      })).toPromise();
  }

 async setSelectedProductDetails(){
   await lastValueFrom(this.rmservice.productCall().pipe(map(x => {
     this.productId = x[0];
      this.productName=x[1];
      if('ISTSWT'===this.productId || 'CORTEX'===this.productId){
      this.siteId=x[2];
      this.nodeId=x[3];
      this.nodeName=x[4];
      }
    })));
  }

  async uodateSelectedSiteNode(siteIdUpdated: string , nodeIdUpdated: string,nodeNameUpdated: string){
    let siteId=this.siteId;
    let nodeId=this.nodeId;
    let nodeName=this.nodeName;
    try {
    this.siteId= +siteIdUpdated;
    this.nodeId= +nodeIdUpdated;
    this.nodeName=nodeNameUpdated;
    await lastValueFrom(this.rmservice.updateSiteNode(siteIdUpdated,nodeIdUpdated,nodeNameUpdated).pipe(map(x => {
       this.siteId=x[0];
       this.nodeId=x[1];
       this.nodeName=x[2];
     })));
    }catch(error) {
    this.siteId= siteId;
    this.nodeId= nodeId;
    this.nodeName=nodeName;
    this.setErrorMessage('error occured while chnage the site/node, please try again..');
  }
   }

   getBaseUrl(): string {
    let url = this.rmservice.getBaseURL();
    return ''+url;
  }

  getIncident(): void{
    let incident = {
      incidentTime:'2pm',
      incidentStatus: true
    }
    this.incidentSubject$.next(incident);
  }

  setRowToBeHighlighted(row): void{
    this.rowHighlightedSubject$.next(row);
  }

  setRetCnfTableName(selectedValue){
    this.tableNameRetCnfSubject$.next(selectedValue);
  }

  showChangePasswordLink() {
    const allowChangePassword = this.configOptions['do_change_password'];
    return allowChangePassword !== null
      && (allowChangePassword.toLowerCase() === 'y' || allowChangePassword.toLowerCase() === 'yes' || allowChangePassword.toLowerCase() === 'true')
      && this.authType === 'oassrv';
  }

  async postNotifications(){
    return await lastValueFrom(this.rmservice.monitorCall("product/notification").pipe(map(x => {
       const abc = JSON.stringify(x)
       console.log('Calling Notification service ....'+JSON.stringify(x));
       return JSON.stringify(x)
      })));
    }

    async getNotifications(){
      return await lastValueFrom(this.rmservice.getServiceCall("product/notification").pipe(map(x => {
         const abc = JSON.stringify(x)
         console.log('Calling Notification service ....'+JSON.stringify(x));
         return JSON.stringify(x)
        })));
      }
}
