import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';

@Component({
  selector: 'atm-ds-rltm-app',
  templateUrl: './atm-ds-rltmCash.component.html'
 })
export class ATMDSRltmCashComponent extends ListComponent implements OnInit, AfterViewInit {
  [x: string]: any;

  @ViewChild('rltmCashTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
    this.criteria['statusCode'] = this.statusCode;
  }

  FORM_TITLE = 'ATM Datasource Real Time Cash Position';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   workRequest:WorkRequest;

   queryPerm = new FormActionPermission('ATMRTCASH', 'Q');
   checkerPerm = new FormActionPermission('ATMRTCASH', 'C');
   mkcPerm = new MKCPermission('ATMRTCASH');

   ngOnInit() {

    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    this.doSearch();
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'ATMRTCASH';
    this.metaDataId = 'ATMRTCASH';
    this.tabId = 'ATMRTCASHTAB';
    this.sectionId = 'ATMRTCASHSEC';
    this.collectionId = 'ATMRTCASHCOL';
  }


  onRowClick(event:any) {
  }
}



