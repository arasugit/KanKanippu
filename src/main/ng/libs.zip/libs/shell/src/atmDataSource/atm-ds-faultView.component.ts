import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';
import { DataTableService, GlobalsService } from '../services';
import { WorkRequest } from '../ist-components';
import { Location } from '@angular/common';
import { Params } from '@angular/router';

@Component({
  selector: 'atm-ds-fltview-app',
  templateUrl: './atm-ds-faultView.component.html'
 })
export class ATMDSFaultViewComponent extends ListComponent implements OnInit, AfterViewInit {
  [x: string]: any;

  @ViewChild('fltViewTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef, private location: Location) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
    this.criteria['statusCode'] = this.statusCode;
  }

  FORM_TITLE = 'ATM Datasource Fault Status View';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   workRequest:WorkRequest;

   queryPerm = new FormActionPermission('ATMFLTVIEW', 'Q');
   checkerPerm = new FormActionPermission('ATMFLTVIEW', 'C');
   mkcPerm = new MKCPermission('ATMFLTVIEW');

   params = {};
   ngOnInit() {
    this.isRedirected=GlobalsService.isRedirected;
    this.showBackBtn=GlobalsService.isRedirected;
    this.statusCode=GlobalsService.param;
    GlobalsService.isRedirected=false;
    GlobalsService.param='';
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      if (this.isRedirected) {
        this.setQueryParameters(this.params);
        this.doSearch();
      }else{
        this.statusCode='all';
        this.doSearch();
      }
    }, 10);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'ATMFLTVIEW';
    this.metaDataId = 'ATMFLTVIEW';
    this.tabId = 'ATMFLTVIEWTAB';
    this.sectionId = 'ATMFLTVIEWSEC';
    this.collectionId = 'ATMFLTVIEWCOL';
  }


  onRowClick(event:any) {
    console.log("Inside OnRowClick " + event);
  }

  onKey(event: any) { 
    console.log("EVENT " + event.target.value);
    this.statusCode = event.target.value;

    if(event.target.value !=  'none') {
      this.doSearch();
    }
  }
  goBack() {
    this.clearErrorMessage();
    this.globals.setErrorMessage('');
    this.location.back();

  }
  ngOnDestroy(): void {
    //GlobalsService.isRedirected = false;
  }

  setCriteria(): void {
    if (this.isNavigation) {
      this.querySection.setQueryParameters(this.params, this.criteria);
      this.isNavigation = false;
     }
  }

  setQueryParameters(params: Params): void {
    if (undefined !== this.statusCode) {
      this.statusCode=this.getstatusCodeByDesc(this.statusCode);
      this.criteria['statusCode'] = this.statusCode ;
      console.log('setQueryParameters  statusCode::'+this.statusCode);

    }
  }

  getstatusCodeByDesc(statusDesc: any): any {
    let statusCode='';
    console.log('statusDesc ::'+statusDesc);
    switch (statusDesc) {
      case 'All':
        statusCode='all';
        break;
      case 'All Cassette Fatal Faults':
        statusCode='allCassetteFatalFaults';
        break;
      case 'Card Reader Problems':
        statusCode='cardReaderProblems';
        break;
      case 'Cash Handler Problems':
        statusCode='cashHandlerProblems';
        break;
      case 'Cashout Problems':
        statusCode='cashOutProblems';
        break;
      case 'Communication Problems':
        statusCode='communicationProblems';
        break;
      case 'In Supervisory':
        statusCode='inSupervisory';
        break;
      case 'Reject Bill OverFill':
        statusCode='rejectBillOverFill';
          break;
      case 'Encryptor Problem\n(Encryptor/PinPad)':
          statusCode='encryptorProblem';
          break;
      case 'Journal Printer Problem':
          statusCode='journalPrinterProblem';
          break;
      case 'Receipt Printer Problem':
          statusCode='receiptPrinterProblem';
          break;
      case 'Receipt Printer Paper Out':
          statusCode='receiptPrinterPaperOut';
          break;
      case 'Journal Printer Paper Out':
          statusCode='journalPrinterProblem';
          break;
      case 'In-Service ATM':
            statusCode='inServiceATM';
            break;
      case 'Out-Of-Service ATM':
            statusCode='outOfServiceATM';
            break;
    }
    return statusCode;
  }

  faultChanged(event: any) {
    console.log("faultChanged :::: " + event.target.value);
    this.statusCode = event.target.value;

    if(event.target.value !=  'none') {
      //this.doSearch();
    }
  }
}


