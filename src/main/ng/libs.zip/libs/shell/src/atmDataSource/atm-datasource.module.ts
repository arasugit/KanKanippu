import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TranslateModule } from '@ngx-translate/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ATMDSFaultViewComponent } from './atm-ds-faultView.component';
import { CommonModule } from '@angular/common';
import { ATMDSRltmCashComponent } from './atm-ds-rltmCash.component';


export const atmDSFltView: MonitorComponentData = {
  title: 'Switch ATM Data Source',
  icon: 'home',
  examples: {
    'ATMFLTVIEW': {
      label: 'Fault Status View',
      title: 'ATM Data Source Fault Status View',
      description: 'ATM Data Source Fault Status View',
      rufId: 'atm_ds_fltView',
      component: ATMDSFaultViewComponent
    },
    'ATMRTCASH': {
      label: 'Real Time Cash Position',
      title: 'ATM Data Source Real Time Cash Position',
      description: 'ATM Data Real Time Cash Position',
      rufId: 'atm_ds_fltView',
      component: ATMDSRltmCashComponent
    }
  }
};

@NgModule({
    imports :[
    CommonModule,
    ISTComponentModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    TranslateModule,
    MatFormFieldModule,
    MatInputModule

    ],
  declarations: [ ATMDSFaultViewComponent, ATMDSRltmCashComponent ],
  providers: [{ provide: MON_TOOL, useValue: atmDSFltView }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[],
})
export class AtmDataSourceModule {}
