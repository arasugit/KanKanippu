import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent, RendererItem } from '../components';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { IstDatePickerColumnRendererComponent } from '../ist-components';
import { LabelsAndValues } from '../common/labels-and-values';


@Component({
  selector: 'atm-cra-app',
  templateUrl: './atm-cra.component.html'
 })
export class AtmCraComponent extends ListComponent implements OnInit, AfterViewInit {
  [x: string]: any;

  @ViewChild('monAtmDBCraTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['COMMAND']='query';
  }

  FORM_TITLE = 'ATM Database CRA';
  exportFileName= 'ATM Database CRA';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   workRequest:WorkRequest;

   queryPerm = new FormActionPermission('ATMCRA_REQ', 'Q');
   insertPerm = new FormActionPermission('ATMCRA_REQ', 'I');
   updatePerm = new FormActionPermission('ATMCRA_REQ', 'U');
   deletePerm = new FormActionPermission('ATMCRA_REQ', 'D');
   checkerPerm = new FormActionPermission('ATMCRA_REQ', 'C');
   mkcPerm = new MKCPermission('ATMCRA_REQ');

   startDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
   endDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
   deptList: LabelsAndValues = new LabelsAndValues();

   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.insertPerm);
    this.requestPerms.permsArr.push(this.updatePerm);
    this.requestPerms.permsArr.push(this.deletePerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  validateBeforeQuery(): boolean {
    return true;
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'ATMCRA_REQ';
    this.metaDataId = 'ATMCRA_REQ';
    this.tabId = 'ATM_CRA_TAB';
    this.sectionId = 'ATM_CRA_SEC';
    this.collectionId = 'ATM_CRA_COL';
  }


  onRowClick(event:any) {
    console.log("Inside OnRowClick " + event);
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
  }
}
