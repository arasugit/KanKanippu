import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TranslateModule } from '@ngx-translate/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { AtmCraComponent } from './atm-cra.component'

export const atm_cra: MonitorComponentData = {
  title: 'ATM CRA Config',
  icon: 'home',
  examples: {
    'ATMCRA_REQ': {
      label: 'ATM CRA Config ',
      title: 'ATM CRA Config ',
      description: 'ATM CRA Config ',
      rufId: 'atm_cra',
      component: AtmCraComponent
    }
  }
};

@NgModule({
    imports :[
    CommonModule,
    ISTComponentModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    TranslateModule,
    MatFormFieldModule,
    MatInputModule

    ],
  declarations: [ AtmCraComponent ],
  providers: [{ provide: MON_TOOL, useValue: atm_cra }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[],
})
export class AtmCraModule {
}
