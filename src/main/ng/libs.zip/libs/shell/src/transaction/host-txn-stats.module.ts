import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HostTxnStatsComponent } from './host-txn-stats.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule } from '@ruf/shell';

export const hostTxnStatsData: MonitorComponentData = {
  title: 'Switch Host Transaction Statistics List',
  icon: 'home',
  examples: {  
      'TXNSHT_REQ': {
          label: 'Host Transaction Stats - 5 Min',
          title: 'Host Transaction Stats - 5 Min',
          description: 'Host Transaction Stats - 5 Min',
          rufId: 'mon_host_txn_stats',
          component: HostTxnStatsComponent
      },
      'HOURLY': {
        label: 'Host Transaction Stats - Hourly',
        title: 'Host Transaction Stats - Hourly',
        description: 'Host Transaction Stats - Hourly',
        rufId: 'mon_host_txn_stats_hourly',
        component: HostTxnStatsComponent
    },
    'DAILY': {
      label: 'Host Transaction Stats - Daily',
      title: 'Host Transaction Stats - Daily',
      description: 'Host Transaction Stats - Daily',
      rufId: 'mon_host_txn_stats_daily',
      component: HostTxnStatsComponent
    },
    'WEEKLY': {
      label: 'Host Transaction Stats - Weekly',
      title: 'Host Transaction Stats - Weekly',
      description: 'Host Transaction Stats - Weekly',
      rufId: 'mon_host_txn_stats_weekly',
      component: HostTxnStatsComponent
    },
    'MONTHLY': {
      label: 'Host Transaction Stats - Monthly',
      title: 'Host Transaction Stats - Monthly',
      description: 'Host Transaction Stats - Monthly',
      rufId: 'mon_host_txn_stats_monthly',
      component: HostTxnStatsComponent
    }
  }
};

@NgModule({ 
    imports :[ 
    CommonModule,
    FormsModule,
    ReactiveFormsModule,  
    MatTableModule, 
    MatCardModule,  
    RufCommonModule,   
    RufCardModule, 
    ISTComponentModule
  ], 
  declarations: [HostTxnStatsComponent],
  providers: [{ provide: MON_TOOL, useValue: hostTxnStatsData }],
  exports:[],
})
export class HostTxnStatsModule {}
