import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent} from '../components/base-list.component';
import { CustomValidators, StringUtil } from '../common';
import { T21Base } from '../components';

@Component({
  selector: 'txn-sts-atm-pos-list',
  templateUrl: './txn-sts-atm-pos-list.component.html'
})


export class TransStatsAtmPosComponent extends ListComponent implements OnInit { 
     
  constructor(injector: Injector) {
    super(injector);
  }
  FORM_TITLE = '';

   product = '';
   fromTime :  string = '';
   fromDate : string = '';
   dateTo : string = '';
   toTime : string = '';
   screenType ='';
  @ViewChild('toDateFocusField', { static: false })
  toDateFocusField: T21Base;

   queryPerm = new FormActionPermission('TXNATMPOS', 'Q');
   checkerPerm = new FormActionPermission('TXNATMPOS', 'C');
   mkcPerm = new MKCPermission('TXNATMPOS'); 
   
   adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
    this.criteria['fromTime']= this.fromTime;
    this.criteria['toTime']=this.toTime;
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId; 
    this.criteria['collectionId']=this.collectionId;  
    this.criteria['COMMAND']='query';   
  }  
   ngOnInit() {
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);  
    this.requestPerms.getPermission(this.router.url); 
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    if(this.screenType == 'TXNATMPOS'){
      this.FORM_TITLE=' Transaction Stats ATM - Acquirer ';
      this.exportFileName=' Transaction Stats ATM - Acquirer ';
    }else  if(this.screenType == 'TXNPOSACQ'){
      this.FORM_TITLE='Transaction Stats POS - Acquirer';
      this.exportFileName='Transaction Stats POS - Acquirer';
    }else  if(this.screenType == 'TXNATMISSUER'){
      this.FORM_TITLE='Transaction Stats ATM - Issuer';
      this.exportFileName='Transaction Stats ATM - Issuer';
    }else  if(this.screenType == 'TXNPOSISSUER'){
      this.FORM_TITLE='Transaction Stats POS - Issuer';
      this.exportFileName='Transaction Stats POS - Issuer';
    }
    this.setAutoRefreshSearch(true);
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNATMPOS';
    this.metaDataId = 'TXNATMPOS';
    this.tabId = 'TXNATMPOS_TAB';
    this.sectionId = 'TXNATMPOS_SEC';
    this.collectionId = 'TXNATMPOS_COL';
  }
  validateBeforeQuery(): boolean {
    CustomValidators.globals=this.globals;
    this.fromDate=CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo=CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat); 
    let result:boolean;
    result= CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField);
  if(result){
    result= CustomValidators.validateTimeField(this.fromTime);
 }
 
 if(result){
   result= CustomValidators.validateTimeField(this.toTime);
}

return result;
}

validateFromTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
validateToTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
getModuleName() { return 'IST-MONITORING'; }
emitModuleReady() { this.msgService.sendMessage(this.getModuleName() ); }
}