import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TerminalTopCompComponent } from './terminal-top-comp-list.component';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { RufCommonModule } from '@ruf/shell';
import { RufCardModule } from '@ruf/shell';
import { HighchartsChartModule } from "highcharts-angular";
export const terminalTopCompData: MonitorComponentData = {
  title: 'Top Terminal Comp Details',
  icon: 'table',
  examples: {
    'TOP-TERMINAL': {
          label: 'Top Terminal',
          title: 'Top Terminal',
          description: 'Top Terminal',
          rufId: 'mon_ter_top_terminal_comp',
          component: TerminalTopCompComponent
      },
      'LEAST-TERMINAL' : {
          label: 'Least Terminal',
          title: 'Least Terminal',
          description: 'Least Terminal',
          rufId: 'mon_ter_least_comp',
          component: TerminalTopCompComponent
      }
  },


};
@NgModule({
  imports :[
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  MatTableModule,
  MatCardModule,
  RufCommonModule,
  RufCardModule,
  ISTComponentModule,
  HighchartsChartModule
],
declarations: [TerminalTopCompComponent],
providers: [{ provide: MON_TOOL, useValue: terminalTopCompData }],
exports:[],
})
export class TerminalTopCompModule { }
