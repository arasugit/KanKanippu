import {Component, ViewEncapsulation, OnInit, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef, ViewChild} from '@angular/core';
import { Subject,takeUntil } from 'rxjs';
import { MON_ATM_COLOR_SETS } from '../home/ngx-charts-color-sets';
import { DataTableEditableDetailComponent, ListComponent } from '../components';
import { FormActionPermission, MKCPermission } from '../permission';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { TransactionDTO } from './transactiondto';
import { TransactionMultiDTO } from './transactionmultidto';
import { StringMap } from '../common';

@Component({
  selector: 'txn-sts-acq-comp-list',
  templateUrl: './txn-sts-acq-comp-list.component.html',
  styleUrls: ['./transaction.scss'],
  encapsulation: ViewEncapsulation.None
})


export class TransStatsAcqCompComponent extends ListComponent implements OnInit,OnDestroy {
  private unsubscribe = new Subject();
  dummyTitle: String = 'Put bar chart here !!!'
  chartType :any = 'vertical-bar-chart';
  view: any[] =[300, 250];
  animations = true;
  screenType: any;
  workRequest:WorkRequest;
  // public colors: ColorHelper;
  cardTitle:any;
  public transactionDataAcq : any = [];
  dataLoaded:boolean=false;
  showXAxis = true;
  showYAxis = true;
  showXAxisLabel = true;
  xAxisLabel = '';
  showYAxisLabel = true;
  yAxisLabel = 'Transactions';
  roundDomains = true;
  roundEdges = false;
  dataList:any= [];
  atmColorScheme = {
    domain: MON_ATM_COLOR_SETS['rufPieChartDarkColorScheme']
  };
  public legendValues:string[]=[];
  // readonly LegendPosition = LegendPosition;
  // readonly LegendType = LegendType;
  @ViewChild('tableData', { static: false }) private tableDataTable: DataTableEditableDetailComponent;
 constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker){
      super(injector);
      this.route
    .data
    .subscribe(v => this.screenType=v['module']);
      this.adjustCriteria();
     this.retriveData();
  }
  ngAfterViewInit() {
    super.criteria=this.criteria;
     //   super.search();
        this.setAutoRefreshInterval();

}
  adjustCriteria(): void {
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }
  getHeaderBasedOnScreenType() : string {
    if(this.screenType === 'WEEKLY' || this.screenType === 'LEASTWEEKLY')
      return 'Weekstart Date';
    else if(this.screenType === 'MONTHLY' || this.screenType === 'LEASTMONTHLY')
      return 'Transaction Month';
    else
      return 'Transaction Date';
  }
  retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        atmData => this.onGotRecords(atmData),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnInit(){
    super.ngOnInit();
    if(this.screenType == 'TXNSTS_ACQ'){
      this.cardTitle='Transaction Comparison Acq - Daily';
      this.FORM_TITLE='Transaction Comparison Acq - Daily';
      this.exportFileName='Transaction Comparison Acq - Daily';
    }else  if(this.screenType == 'WEEKLY'){
      this.cardTitle='Transaction Comparison Acq - Weekly';
      this.FORM_TITLE='Transaction Comparison Acq - Weekly';
      this.exportFileName='Transaction Comparison Acq - Weekly';
    }else  if(this.screenType == 'MONTHLY'){
      this.cardTitle='Transaction Comparison Acq - Monthly';
      this.FORM_TITLE='Transaction Comparison Acq - Monthly';
      this.exportFileName='Transaction Comparison Acq - Monthly';
    }
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    if(this.workRequest!=null && this.workRequest !==undefined && this.workRequest.collections!=null && this.workRequest.collections[this.collectionId] !=null && this.workRequest.collections[this.collectionId].rows!=null){
      const rows = this.workRequest.collections[this.collectionId].rows;
      this.dataList = this.workRequest.collections[this.collectionId].rows;
      this.tableDataTable.dataSource.data=this.dataList;
      let dtolist :TransactionDTO[]=[];
      let dto:  TransactionDTO;
      this.xAxisLabel=this.getHeaderBasedOnScreenType();
      rows.forEach(c =>{
        dto = new TransactionDTO(c.transactionDate,c.totalTranssaction);
        dtolist.push(dto);
      })
      this.transactionDataAcq=JSON.parse(JSON.stringify(dtolist));
      // this.colors = new ColorHelper(this.atmColorScheme as Color, ScaleType.Ordinal, this.legendValues, this.atmColorScheme);
      this.dataLoaded=true;
      this.cdr.markForCheck();
    }
  }
  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }
  onCompleteGotRecords(): void {
  }
  getEntPermList(): any[] {
    this.entObjectId = 'TXNSTS_ACQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

  onSelect(event) {
    console.log(event);
  }

  gatherDataChanged(event:any):void{
     console.log(this.dataService.data);
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNSTS_ACQ';
    this.metaDataId = 'TXNSTS_ACQ';
    this.tabId = 'TXNSTS_ACQ_TAB';
    this.sectionId = 'TXNSTS_ACQ_SEC';
    this.collectionId = 'TXNSTS_ACQ_COL';
  }
  ngOnDestroy() {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
  }

}

