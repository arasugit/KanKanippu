import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TransAcqRejectionToolComponent } from './txn-sts-acq-top5-list.component';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
export const transAcqRejectionData: MonitorComponentData = {
  title: 'Transaction Stats Acquirer Comp Details',
  icon: 'table',
  examples: {  
      'TXNRJACQ': {
          label: 'Top 5 Acq Trans Rejections',
          title: 'Top 5 Acq Trans Rejections',
          description: 'Top 5 Acq Trans Rejections',
          rufId: 'mon_txn_sts_acq_top5',
          component: TransAcqRejectionToolComponent
      },
  'ISSUING': {
    label: 'Top 5 Issuing Trans Rejections',
    title: 'Top 5 Issuing Trans Rejections',
    description: 'Top 5 Issuing Trans Rejections',
    rufId: 'mon_txn_sts_acq_top5_weekly',

    component: TransAcqRejectionToolComponent
}
  },

  
};
@NgModule({ 
  imports :[ 
  FormsModule,
  ReactiveFormsModule, 
  MatTableModule, 
  MatCardModule,
  MatFormFieldModule,
  MatInputModule, 
  ISTComponentModule
], 
declarations: [TransAcqRejectionToolComponent],
providers: [{ provide: MON_TOOL, useValue: transAcqRejectionData }],
exports:[],
})
export class TransAcqRejectionModule { }
