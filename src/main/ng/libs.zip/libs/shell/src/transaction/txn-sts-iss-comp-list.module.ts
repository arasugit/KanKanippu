import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TransStatsIssCompComponent } from './txn-sts-iss-comp-list.component';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { RufCommonModule } from '@ruf/shell';
import { RufCardModule } from '@ruf/shell';
export const transStatsIssCompData: MonitorComponentData = {
  title: 'Transaction Stats Issuer Comp Details',
  icon: 'table',
  examples: {
      'TXNSTS_ISS': {
          label: 'Transaction Stats Issuer - Daily',
          title: 'Transaction Stats Issuer - Daily',
          description: 'Transaction Stats Issuer - Daily',
          rufId: 'mon_txn_sts_iss_comp',
          component: TransStatsIssCompComponent
      },
  'WEEKLY': {
    label: 'Transaction Stats Issuer - Weekly',
    title: 'Transaction Stats Issuer - Weekly',
    description: 'Transaction Stats Issuer - Weekly',
    rufId: 'mon_txn_sts_iss_comp_weekly',

    component: TransStatsIssCompComponent
},
'MONTHLY': {
  label: 'Transaction Stats Issuer - Monthly',
  title: 'Transaction Stats Issuer - Monthly',
  description: 'Transaction Stats Issuer - Monthly',
  rufId: 'mon_txn_sts_iss_comp_monthly',

  component: TransStatsIssCompComponent
}
  },


};
@NgModule({
  imports :[
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  MatTableModule,
  MatCardModule,
  RufCommonModule,
  RufCardModule,
  ISTComponentModule
],
declarations: [TransStatsIssCompComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsIssCompData }],
exports:[],
})
export class TransStatsIssCompModule { }
