import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TransStatsHighVolComponent } from './txn-sts-high-vol-list.component';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { RufCommonModule } from '@ruf/shell';
import { RufCardModule } from '@ruf/shell';
export const transStatsHighVolData: MonitorComponentData = {
  title: 'Trans Stats - Top 5 Contry',
  icon: 'table',
  examples: {
      'TXNHVOL': {
          label: 'High Volume transactions',
          title: 'High Volume transactions',
          description: 'High Volume transactions',
          rufId: 'mon_txn_sts_high-vol',
          component: TransStatsHighVolComponent
      }
  },


};
@NgModule({
  imports :[
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  MatTableModule,
  MatCardModule,
  RufCommonModule,
  RufCardModule,
  ISTComponentModule
],
declarations: [TransStatsHighVolComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsHighVolData }],
exports:[],
})
export class TransStatsHighVolModule { }
