import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TransactionStatsRespCodeComponent } from './transaction-stats-resp-code.component';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { RufCommonModule } from '@ruf/shell';
import { RufCardModule } from '@ruf/shell';
export const transStatsRespCodeData: MonitorComponentData = {
  title: 'Transaction Stats Details',
  icon: 'table',
  examples: {
      'TXNSTS_REQ': {
          label: 'Transaction Stats - 5 Min',
          title: 'Transaction Stats - 5 Min',
          description: 'Transaction Stats - 5 Min',
          rufId: 'mon_trans_stats_detail',
          component: TransactionStatsRespCodeComponent
      },
      'HOURLY': {
        label: 'Transaction Stats - Hourly ',
        title: 'Transaction Stats - Hourly',
        description: 'Transaction Stats - Hourly',
        rufId: 'mon_trans_stats_detail_hourly',
        component: TransactionStatsRespCodeComponent
    },
    'DAILY': {
      label: 'Transaction Stats - Daily',
      title: 'Transaction Stats - Daily',
      description: 'Transaction Stats - Daily',
      rufId: 'mon_trans_stats_detail_daily',

      component: TransactionStatsRespCodeComponent
  },
  'WEEKLY': {
    label: 'Transaction Stats - Weekly',
    title: 'Transaction Stats - Weekly',
    description: 'Transaction Stats - Weekly',
    rufId: 'mon_trans_stats_detail_weekly',

    component: TransactionStatsRespCodeComponent
},
'MONTHLY': {
  label: 'Transaction Stats - Monthly',
  title: 'Transaction Stats - Monthly',
  description: 'Transaction Stats - MONTHLY',
  rufId: 'mon_trans_stats_detail_monthly',

  component: TransactionStatsRespCodeComponent
}
  },


};
@NgModule({
  imports :[
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  MatTableModule,
  MatCardModule,
  RufCommonModule,
  RufCardModule,
  ISTComponentModule
],
declarations: [TransactionStatsRespCodeComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsRespCodeData }],
exports:[],
})
export class TransactionStatsRespCodeModule { }
