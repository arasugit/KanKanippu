import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TxnsPerSecondComponent } from './txns-per-second.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCommonModule, RufScrollbarModule } from '@ruf/shell';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RufCardModule } from '@ruf/shell';
import { HighchartsChartModule } from 'highcharts-angular';

export const txnsPerSecondData: MonitorComponentData = {
  title: 'Transactions Per Second ',
  icon: 'table',
  examples: {
      'TXNTPS_REQ': {
          label: 'TPS Dashboard',
          title: 'TPS Dashboard',
          description: 'TPS Dashboard',
          rufId: 'tps_dashboard',
          component: TxnsPerSecondComponent
      },
      'CURRENT-TPS': {
        label: 'Current TPS',
        title: 'Current TPS',
        description: 'Current TPS',
        rufId: 'current_tps_usage',
        component: TxnsPerSecondComponent
    },
    'TODAY-TPS': {
        label: 'Today TPS',
        title: 'Today TPS',
        description: 'Today TPS',
        rufId: 'today_tps_usage',
        component: TxnsPerSecondComponent
    },
    'AVERAGE-TPS': {
          label: 'Current Month TPS',
          title: 'Current Month TPS',
          description: 'Current Month TPS',
          rufId: 'avg_tps_status',
          component: TxnsPerSecondComponent
      },
  }
};

@NgModule({
    imports :[
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    RufCommonModule,
    RufScrollbarModule,
    FlexLayoutModule,
    RufCardModule,
    ISTComponentModule,
    HighchartsChartModule
  ],
  declarations: [TxnsPerSecondComponent],
  providers: [{ provide: MON_TOOL, useValue: txnsPerSecondData }],
  exports:[],
})
export class TxnsPerSecondModule {}
