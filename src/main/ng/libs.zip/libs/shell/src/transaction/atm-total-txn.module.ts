import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule, RufScrollbarModule } from '@ruf/shell';
import { AtmTotalTxnsComponent } from './atm-total-txn.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TranslateLazyLoadModule } from '../ist-components/ist-translate-lazyload-module';
import { MatDividerModule } from '@angular/material/divider';

export const atmTotalTxnsData: MonitorComponentData = {
  title: 'ATM Total History',
  icon: 'home',
  examples: {  
      'ATMTOTHIST': {
          label: 'ATM Total History',
          title: 'ATM Total History',
          description: 'ATM Total History',
          rufId: 'atm_total_txn_hist',
          component: AtmTotalTxnsComponent
      }
  }
};

@NgModule({ 
    imports :[ 
      CommonModule, 
      CdkScrollable,
      MatTableModule,  
      FormsModule,
      FlexLayoutModule,
      ReactiveFormsModule,
      TranslateLazyLoadModule,
      ISTComponentModule,
      MatDividerModule,
      MatCardModule,  
      RufScrollbarModule,
      RufCommonModule,
      RufCardModule
  ], 
  declarations: [AtmTotalTxnsComponent],
  providers: [{ provide: MON_TOOL, useValue: atmTotalTxnsData }],
  exports:[],
})
export class AtmTotalTxnsModule {}
