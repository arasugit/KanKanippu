import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TransStatsOverseasComponent } from './txn-sts-overseas-list.component';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { RufCommonModule, RufScrollbarModule } from '@ruf/shell';
import { RufCardModule } from '@ruf/shell';
import { CdkScrollable, ScrollingVisibility } from '@angular/cdk/overlay';
export const transStatsOverseasData: MonitorComponentData = {
  title: 'Trans Stats - Top 5 Country',
  icon: 'table',
  examples: {
      'TXNSTSOS': {
          label: 'Trans Stats - Top 5 Country',
          title: 'Trans Stats - Top 5 Country',
          description: 'Trans Stats - Top 5 Country',
          rufId: 'mon_txn_sts_overseas',
          component: TransStatsOverseasComponent
      }
  },


};
@NgModule({
  imports :[
  CommonModule,
  CdkScrollable,
  FormsModule,
  ReactiveFormsModule,
  MatTableModule,
  MatCardModule,
  RufCommonModule,
  RufCardModule,
  RufScrollbarModule,
  ISTComponentModule
],
declarations: [TransStatsOverseasComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsOverseasData }],
exports:[],
})
export class TransStatsOverseasModule { }
