import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent} from '../components/base-list.component';
import { CustomValidators, StringUtil } from '../common';
import { T21Base } from '../components';

@Component({
    selector: 'rejected-txn-app',
    templateUrl : './rejected-txn.component.html',
    styleUrls: ['./transaction.scss'],
    encapsulation: ViewEncapsulation.None
})

export class RejectedTxnsComponent extends ListComponent implements OnInit {

  constructor(injector: Injector) {
    super(injector);
  }
  FORM_TITLE = '';

   product = '';
   fromTime :  string = '';
   fromDate : string = '';
   dateTo : string = '';
   toTime : string = '';
   screenType ='';

  @ViewChild('toDateFocusField', { static: false })
  toDateFocusField: T21Base;

   queryPerm = new FormActionPermission('TXNSRJ_REQ', 'Q');
   checkerPerm = new FormActionPermission('TXNSRJ_REQ', 'C');
   mkcPerm = new MKCPermission('TXNSRJ_REQ');

   adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
    this.criteria['fromTime']= this.fromTime;
    this.criteria['toTime']=this.toTime;
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }

   ngOnInit() {
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    console.log('screenType::'+this.screenType);
    if(this.screenType == 'TXNSRJ_REQ'){
      this.FORM_TITLE='Onus Transactions Count';
      this.exportFileName = 'Onus Transactions Count';
    }
    else  if(this.screenType == 'ACQUIRING'){
      this.FORM_TITLE='Acquiring Transactions Count';
      this.exportFileName='Acquiring Transactions Count';
    }
    else  if(this.screenType == 'ISSUING'){
      this.FORM_TITLE='Issuing Transactions Count';
      this.exportFileName='Issuing Transactions Count';
    }
    this.setAutoRefreshSearch(true);
  }

  setT21Tags(): void {
	this.requestTypeId = 'TXNSRJ_REQ';
	this.metaDataId = 'TXNSRJ_REQ';
	this.tabId = 'TXNS_REJC_TAB';
	this.sectionId = 'TXNS_REJC_SEC';
	this.collectionId = 'TXNS_REJC_COL';
	}
  validateBeforeQuery(): boolean {
    CustomValidators.globals=this.globals;
    this.fromDate=CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo=CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat);
    let result:boolean;
    result= CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField);
  if(result){
    result= CustomValidators.validateTimeField(this.fromTime);
 }

 if(result){
   result= CustomValidators.validateTimeField(this.toTime);
}

return result;
}

validateFromTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
validateToTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
getModuleName() { return 'IST-MONITORING'; }
emitModuleReady() { this.msgService.sendMessage(this.getModuleName()); }
}
