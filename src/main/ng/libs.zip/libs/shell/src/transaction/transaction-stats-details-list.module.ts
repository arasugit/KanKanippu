import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { RufCommonModule,RufScrollbarModule } from '@ruf/shell';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatGridListModule } from '@angular/material/grid-list';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RufCardModule } from '@ruf/shell';
import { ISTComponentModule } from '../ist-components';
import { MON_TOOL, MonitorComponentData } from '../monitor-components/common-object';
import { TransactionStatsDetailsComponent } from './transaction-stats-details-list.component';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { HighchartsChartModule } from 'highcharts-angular';

export const transStatsDetailsData: MonitorComponentData = {
  title: 'Transaction Stats Details',
  icon: 'table',
  examples: {
      'TXNSTS_REQ': {
          label: 'Transaction Stats - 5 Min',
          title: 'Transaction Stats - 5 Min',
          description: 'Transaction Stats - 5 Min',
          rufId: 'mon_trans_stats_detail',
          component: TransactionStatsDetailsComponent
      },
      'HOURLY': {
        label: 'Transaction Stats - Hourly ',
        title: 'Transaction Stats - Hourly',
        description: 'Transaction Stats - Hourly',
        rufId: 'mon_trans_stats_detail_hourly',
        component: TransactionStatsDetailsComponent
    },
    'DAILY': {
      label: 'Transaction Stats - Daily',
      title: 'Transaction Stats - Daily',
      description: 'Transaction Stats - Daily',
      rufId: 'mon_trans_stats_detail_daily',

      component: TransactionStatsDetailsComponent
  },
  'WEEKLY': {
    label: 'Transaction Stats - Weekly',
    title: 'Transaction Stats - Weekly',
    description: 'Transaction Stats - Weekly',
    rufId: 'mon_trans_stats_detail_weekly',

    component: TransactionStatsDetailsComponent
},
'MONTHLY': {
  label: 'Transaction Stats - Monthly',
  title: 'Transaction Stats - Monthly',
  description: 'Transaction Stats - MONTHLY',
  rufId: 'mon_trans_stats_detail_monthly',

  component: TransactionStatsDetailsComponent
}

  },


};

@NgModule({
  declarations:[TransactionStatsDetailsComponent],
  imports: [
    CommonModule,
    CdkScrollable,
    MatTableModule,
    FormsModule,
    FlexLayoutModule,
    RufCardModule,
    ReactiveFormsModule,
    ISTComponentModule,
    MatCardModule,
    MatGridListModule,
    RufScrollbarModule,
    RufCommonModule,
    MatButtonToggleModule,
    MatTabsModule,
    HighchartsChartModule
   ],
  exports:[TransactionStatsDetailsComponent],
  providers: [{ provide: MON_TOOL, useValue: transStatsDetailsData }],
})
export class TransactionStatsDetailsModule {}
