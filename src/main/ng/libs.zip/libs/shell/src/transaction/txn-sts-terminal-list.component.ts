import {
  Component,
  Injector,
  OnInit,
  ViewChild,
} from "@angular/core";
import { MKCPermission } from "../permission/mkcform.permission";
import { FormActionPermission } from "../permission/form.action.permission";
import { ListComponent } from "../components/base-list.component";
import { CustomValidators } from "../common";
import { T21Base } from "../components";
import { DataTableService } from "../services";
import { WorkRequest } from "../ist-components";
import { DataTableEditableDetailComponent } from "../components";
import { finalize, first } from "rxjs/operators";
import { PageEvent } from '@angular/material/paginator';

@Component({
  selector: "txn-sts-terminal-list",
  templateUrl: "./txn-sts-terminal-list.component.html",
})

export class TransStatsTerminalComponent
  extends ListComponent
  implements OnInit
{
  constructor(injector: Injector, private dataService: DataTableService) {
    super(injector);
  }
  FORM_TITLE = "";

  product = "";
  fromTime: string = "";
  fromDate: string = "";
  dateTo: string = "";
  toTime: string = "";
  screenType = "";
  @ViewChild("toDateFocusField", { static: false })
  toDateFocusField: T21Base;
  txnDetailDataList: any = [];
  workRequest: WorkRequest;
  txnStatsDataList: any = [];
  isDetailsTab: boolean = false;
  @ViewChild("txnTableDataTable", { static: false })
  private txnTableDataTable: DataTableEditableDetailComponent;

  queryPerm = new FormActionPermission("TXNTERC", "Q");
  checkerPerm = new FormActionPermission("TXNTERC", "C");
  mkcPerm = new MKCPermission("TXNTERC");

  adjustCriteria(): void {
    this.criteria["productId"] = "ISTSWT";
    this.criteria["fromTime"] = this.fromTime;
    this.criteria["toTime"] = this.toTime;
    this.criteria["screenType"] = this.screenType;
    this.criteria["requestTypeId"] = this.requestTypeId;
    this.criteria["collectionId"] = this.collectionId;
    this.criteria["COMMAND"] = "query";
  }

  ngOnInit() {
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.route.data.subscribe((v) => (this.screenType = v["module"]));
    if (this.screenType == "TXNTERC") {
      this.FORM_TITLE = "Terminal Transaction";
      this.exportFileName = "Terminal Transaction";
    }
    this.setAutoRefreshSearch(true);
  }

  setT21Tags(): void {
    this.requestTypeId = "TXNTERC";
    this.metaDataId = "TXNTERC";
    this.tabId = "TXNTERC_TAB";
    this.sectionId = "TXNTERC_SEC";
    this.collectionId = "TXNTERC_COL";
  }

  validateBeforeQuery(): boolean {
    CustomValidators.globals = this.globals;
    this.fromDate = CustomValidators.formatDateString(
      this.fromDate,
      this.globals.dateFormat
    );
    this.dateTo = CustomValidators.formatDateString(
      this.dateTo,
      this.globals.dateFormat
    );
    let result: boolean;
    result = CustomValidators.validateTransDate(
      this.fromDate,
      this.dateTo,
      this.firstFocusField,
      this.toDateFocusField
    );
    if (result) {
      result = CustomValidators.validateTimeField(this.fromTime);
    }

    if (result) {
      result = CustomValidators.validateTimeField(this.toTime);
    }

    return result;
  }

  validateFromTime(event: any) {
    CustomValidators.globals = this.globals;
    return CustomValidators.formatTimeField(event);
  }

  validateToTime(event: any) {
    CustomValidators.globals = this.globals;
    return CustomValidators.formatTimeField(event);
  }

  getModuleName() {
    return "IST-MONITORING";
  }

  emitModuleReady() {
    this.msgService.sendMessage(this.getModuleName());
  }

  retriveData(): void {
    this.dataService.requestType = this.requestTypeId;
    this.dataService.collectionTag = this.collectionId;
    this.dataService.action = "query";
    this.dataService.criteria = this.criteria;

    this.dataService
      .loadData(false)
      .pipe(
        first(),
        finalize(() => this.globals.hideLoadingBar())
      )
      .subscribe({
        next: (atmData: any) => {
          this.onGotRecords(atmData);
        },
        error: (error: any) => {
          console.log("error", error);
          this.onErrorGotRecords(error);
        },
      });
  }

  onGotRecords(wr: WorkRequest): void {
    this.workRequest = wr;
    if (this.responseCollectionHasData()) {
      if (
      this.workRequest.collections[this.collectionId] != null &&
      this.workRequest.collections[this.collectionId].rows != null
      ) {
        this.txnStatsDataList = this.workRequest.collections[this.collectionId].rows;
      }

      if (
        this.workRequest.collections["TXNTERC_DTL_COL"] != null &&
        this.workRequest.collections["TXNTERC_DTL_COL"].rows != null
      ) {
        this.txnDetailDataList = this.workRequest.collections["TXNTERC_DTL_COL"].rows;
        this.txnTableDataTable.dataSource.data = this.txnDetailDataList;
        this.setDetailTablePaginationData();
      }
    }
  }

  setDetailTablePaginationData(): void {
      if (this.criteria["ist_total"] !== "y") {
        return;
      }

      DataTableEditableDetailComponent.totalDTLRecords = +this.workRequest.messageId;
      this.txnTableDataTable.length = +this.workRequest.messageId;
      this.txnTableDataTable.totalRecords = +this.workRequest.messageId;
  }

  responseCollectionHasData(): boolean {
    return (
      this.workRequest != null &&
      this.workRequest !== undefined &&
      this.workRequest.collections != null
    );
  }

  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  onCompleteGotRecords(): void {}

  onItemClick(selectedItem: any) {
    super.criteria = this.criteria;
    this.criteria["isTxnDetailReq"] = "true";
    this.criteria["ist_total"] = "y";

    this.criteria["termId"] = selectedItem.terminalId;
    this.criteria["pCode"] = selectedItem.processingCode;
    this.criteria[this.pageCtrl] = "1";
    this.txnTableDataTable.paginator.pageIndex = 0;

    this.resetDetailTable();
    this.globals.showLoadingBar();
    this.retriveData();
    this.isDetailsTab = true;
    this.txnTableDataTable.dataSource.data = this.txnDetailDataList;
  }

  more(pageEvent: PageEvent): void {
    this.resetDetailTable();
    this.criteria["isTxnDetailReq"] = "false";
    super.more(pageEvent);
  }


  moreDetails(pageEvent: PageEvent): void {
    this.criteria["isTxnDetailReq"] = "true";
    this.criteria["ist_total"] = "n";
    this.criteria[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
    this.globals.showLoadingBar();
    this.retriveData();
  }

  search(): void {
    this.resetDetailTable();
    super.search();
  }

  clear(): void {
    this.resetDetailTable();
    super.clear();
  }

  resetDetailTable(): void {
    this.txnDetailDataList = null;
    this.txnTableDataTable.dataSource.data = this.txnDetailDataList;
  }
}
