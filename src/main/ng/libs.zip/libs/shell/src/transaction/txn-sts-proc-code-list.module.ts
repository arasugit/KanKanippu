import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TransStatsProcCodeComponent } from './txn-sts-proc-code-list.component';
export const transStatsProcCodeData: MonitorComponentData = {
  title: 'Transaction Statistics based on processing code',
  icon: 'table',
  examples: {  
      'TXNPROCCD': {
          label: 'Trans Stats By Proc Code',
          title: 'Trans Stats By Proc Code',
          description: 'Trans Stats By Proc Code',
          rufId: 'mon_txn_sts_proc_code_acq',
          component: TransStatsProcCodeComponent
      }
  },

  
};
@NgModule({ 
  imports :[ 
  FormsModule,
  ReactiveFormsModule, 
  MatTableModule, 
  MatCardModule, 
  ISTComponentModule,
  MatFormFieldModule,
], 
declarations: [TransStatsProcCodeComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsProcCodeData }],
exports:[],
})
export class TransStatsProcCodeModule { }
