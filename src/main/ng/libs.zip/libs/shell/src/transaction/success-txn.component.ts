import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { CustomValidators, LabelAndValue, LabelsAndValues } from '../common';
import { T21Base } from '../components';
import { DataTableEditableDetailComponent } from "../components";
import { WorkRequest } from "../ist-components";
import { DataTableService } from "../services";
import { finalize, first } from "rxjs/operators";
import { PageEvent } from '@angular/material/paginator';
import { StringMap } from '../common/criteria';
import { MonComboBoxMultiSelectComponent } from "../components";

@Component({
    selector: 'success-txn-app',
    templateUrl : './success-txn.component.html',
    styleUrls: ['./transaction.scss'],
    encapsulation: ViewEncapsulation.None
})

export class SuccessfulTxnsComponent extends ListComponent implements OnInit {
  responseCodeDisabled: boolean;
  responseGroupDisabled: boolean;

  constructor(injector: Injector, private dataService: DataTableService) {
    super(injector);
  }
  FORM_TITLE = '';

  product = '';
  fromTime :  string = '';
  fromDate : string = '';
  dateTo : string = '';
  toTime : string = '';
  screenType ='';
  txnDetailDataList: any = [];
  txnStatsDataList: any = [];
  workRequest: WorkRequest;
  isDetailsTab: boolean = false;

  dbParam: StringMap = {};
  @ViewChild('toDateFocusField', { static: false })
  toDateFocusField: T21Base;
  @ViewChild("txnTableDataTable", { static: false })
  private txnTableDataTable: DataTableEditableDetailComponent;
  @ViewChild('responseGroupCode', { static: false })
  responseGroupCode: MonComboBoxMultiSelectComponent;
  @ViewChild('responseCode', { static: false })
  responseCode: MonComboBoxMultiSelectComponent;

  responseCodeGroupList : LabelsAndValues = new LabelsAndValues();
  responseCodeList  : LabelsAndValues = new LabelsAndValues();

   queryPerm = new FormActionPermission('TXNSSC_REQ', 'Q');
   checkerPerm = new FormActionPermission('TXNSSC_REQ', 'C');
   mkcPerm = new MKCPermission('TXNSSC_REQ');

   adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
    this.criteria['fromTime']= this.fromTime;
    this.criteria['toTime']=this.toTime;
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }

   ngOnInit() {
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    console.log('screenType::'+this.screenType);
    if(this.screenType == 'TXNSSC_REQ'){
      this.FORM_TITLE='Onus Transactions Count';
      this.exportFileName='Onus Transactions Count';
    }
    else  if(this.screenType == 'ACQUIRING'){
      this.FORM_TITLE='Acquiring Transactions Count';
      this.exportFileName='Acquiring Transactions Count';
    }
    else  if(this.screenType == 'ISSUING'){
      this.FORM_TITLE='Issuing Transactions Count';
      this.exportFileName='Issuing Transactions Count';
    }
    this.setAutoRefreshSearch(true);

    this.getResponseCodeGroupList();


  }

  getResponseCodeGroupList() {
    this.dbParam['type'] = 'SucRejTxnCntResponseCodeGroup';

    // CMDEXECUTION-INSERT was used to fetch values for given parameter
    // It was reused here, even though the name "CMDEXECUTION-INSERT" is not releavant.
    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((primaryResult: any[]) => {
      console.log("Print " + primaryResult.length + ' ' + primaryResult);
      if(primaryResult)  {
        this.responseCodeGroupList.array = primaryResult.map((secondaryResult): LabelAndValue => {
          const respCdArray = secondaryResult.split("((**&**))");
          //console.log(" ...Resp Code.. " + respCdArray[0] +'  :: ' + respCdArray[1])
          return new LabelAndValue(respCdArray[0], respCdArray[1]);
        });
      }
      this.getResponseCode();
    });
  }

  getResponseCode() {
    this.dbParam['type'] = 'SucRejTxnCntResponseCode';

    // CMDEXECUTION-INSERT was used to fetch values for given parameter
    // It was reused here, even though the name "CMDEXECUTION-INSERT" is not releavant.
    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((primaryResult1: any[]) => {
      console.log("Print " + primaryResult1.length + ' ' + primaryResult1);
      if(primaryResult1)  {
        this.responseCodeList.array = primaryResult1.map((secondaryResult1): LabelAndValue => {
          const respCdArray1 = secondaryResult1.split("((**&**))");
          console.log(" ..... " + respCdArray1);
          return new LabelAndValue(respCdArray1[1], respCdArray1[0] );
        });
      }
    });
  }

  onSelectedRespGroupCode(event: any) {
    console.log("Inside - onSelectedRespGroupCode " + event);

    // this.responseCode.isDisabled = true;
    if(event.length > 0){
      this.responseCodeDisabled = true;
    }
    else{
      this.responseCodeDisabled = false;
    }
    //this.responseGroupCode.isDisabled = false;
  }

  onSelectedRespCode(event: any) {
    console.log("Inside - onSelectedRespCode " + event);

    // this.responseGroupCode.isDisabled = true;
    if(event.length > 0){
    this.responseGroupDisabled = true;
    }
    else{
      this.responseGroupDisabled = false;
    }
    //this.responseCode.isDisabled = false;
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNSSC_REQ';
    this.metaDataId = 'TXNSSC_REQ';
    this.tabId = 'TXNS_SUC_TAB';
    this.sectionId = 'TXNS_SUC_SEC';
    this.collectionId = 'TXNS_SUC_COL';
  }

  validateBeforeQuery(): boolean {
    CustomValidators.globals=this.globals;
    this.fromDate=CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo=CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat);
    let result:boolean;
    result= CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField);
    if(result){
      result= CustomValidators.validateTimeField(this.fromTime);
    }

    if(result){
      result= CustomValidators.validateTimeField(this.toTime);
    }

    return result;
  }

  validateFromTime(event: any) {
    CustomValidators.globals=this.globals;
    return CustomValidators.formatTimeField(event);
  }

  validateToTime(event: any) {
    CustomValidators.globals=this.globals;
    return CustomValidators.formatTimeField(event);
  }

  getModuleName() { return 'IST-MONITORING'; }
  emitModuleReady() { this.msgService.sendMessage(this.getModuleName()); }

  retriveData(): void {
    this.dataService.requestType = this.requestTypeId;
    this.dataService.collectionTag = this.collectionId;
    this.dataService.action = "query";
    this.dataService.criteria = this.criteria;

    this.dataService
      .loadData(false)
      .pipe(
        first(),
        finalize(() => this.globals.hideLoadingBar())
      )
      .subscribe({
        next: (atmData: any) => {
          this.onGotRecords(atmData);
        },
        error: (error: any) => {
          console.log("error", error);
          this.onErrorGotRecords(error);
        },
      });
  }

  onGotRecords(wr: WorkRequest): void {
    this.workRequest = wr;

    if (this.responseCollectionHasData()) {
      if (
      this.workRequest.collections[this.collectionId] != null &&
      this.workRequest.collections[this.collectionId].rows != null
      ) {
        this.txnStatsDataList = this.workRequest.collections[this.collectionId].rows;
      }

      if (
        this.workRequest.collections["TXNS_SUC_DTL_COL"] != null &&
        this.workRequest.collections["TXNS_SUC_DTL_COL"].rows != null
      ) {
        this.txnDetailDataList = this.workRequest.collections["TXNS_SUC_DTL_COL"].rows;
        this.txnTableDataTable.dataSource.data = this.txnDetailDataList;
        this.setDetailTablePaginationData();
      }
    }
  }

  setDetailTablePaginationData(): void {
      if (this.criteria["ist_total"] !== "y") {
        return;
      }

      DataTableEditableDetailComponent.totalDTLRecords = +this.workRequest.messageId;
      this.txnTableDataTable.length = +this.workRequest.messageId;
      this.txnTableDataTable.totalRecords = +this.workRequest.messageId;
  }

  responseCollectionHasData(): boolean {
    return (
      this.workRequest != null &&
      this.workRequest !== undefined &&
      this.workRequest.collections != null
    );
  }

  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  onCompleteGotRecords(): void {}

  onItemClick(selectedItem: any) {
    super.criteria = this.criteria;
    this.criteria["isTxnDetailReq"] = "true";
    this.criteria["ist_total"] = "y";
    console.log('selectedItem.txnDest ', selectedItem.txnDest)
    this.criteria["txndest"] = selectedItem.txnDest;
    this.criteria["issuer"] = selectedItem.issuer;
    this.criteria[this.pageCtrl] = "1";
    this.txnTableDataTable.paginator.pageIndex = 0;

    this.resetDetailTable();
    this.globals.showLoadingBar();
    this.retriveData();
    this.isDetailsTab = true;
    this.txnTableDataTable.dataSource.data = this.txnDetailDataList;
  }

  more(pageEvent: PageEvent): void {
    this.resetDetailTable();
    this.criteria["isTxnDetailReq"] = "false";
    super.more(pageEvent);
  }

  moreDetails(pageEvent: PageEvent): void {
    this.criteria["isTxnDetailReq"] = "true";
    this.criteria["ist_total"] = "n";
    this.criteria[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
    this.globals.showLoadingBar();
    this.retriveData();
  }

  search(): void {
    this.resetDetailTable();
    super.search();
    this.responseGroupDisabled = false;
    this.responseCodeDisabled = false;
  }

  clear(): void {
    this.resetDetailTable();
    super.clear();
  }

  resetDetailTable(): void {
    this.txnDetailDataList = null;
    this.txnTableDataTable.dataSource.data = this.txnDetailDataList;
    this.responseGroupCode.isDisabled = false;
    this.responseCode.isDisabled = false;
  }
}
