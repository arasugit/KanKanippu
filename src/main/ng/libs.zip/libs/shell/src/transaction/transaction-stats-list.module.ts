import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TransactionStatsListComponent } from './transaction-stats-list.component';
//import { NgxChartsModule }from '@swimlane/ngx-charts';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { RufCommonModule } from '@ruf/shell';
import { RufCardModule } from '@ruf/shell';
export const transStatsData: MonitorComponentData = {
  title: 'Transaction Stats Acquirer',
  icon: 'table',
  examples: {
      'TRANSSTATS': {
          label: 'Transaction Stats - 5 Min',
          title: 'Transaction Stats - 5 Min',
          description: 'Transaction Stats - 5 Min',
          rufId: 'mon_trans_stats',
          component: TransactionStatsListComponent
      },
      'HOURLY': {
        label: 'Transaction Stats - Hourly ',
        title: 'Transaction Stats - Hourly',
        description: 'Transaction Stats - Hourly',
        rufId: 'Hourly',
        component: TransactionStatsListComponent
    },
    'DAILY': {
      label: 'Transaction Stats - Daily',
      title: 'Transaction Stats - Daily',
      description: 'Transaction Stats - Daily',
      rufId: 'Daily',

      component: TransactionStatsListComponent
  },
  'WEEKLY': {
    label: 'Transaction Stats - Weekly',
    title: 'Transaction Stats - Weekly',
    description: 'Transaction Stats - Weekly',
    rufId: 'Weekly',

    component: TransactionStatsListComponent
},
'MONTHLY': {
  label: 'Transaction Stats - Monthly',
  title: 'Transaction Stats - Monthly',
  description: 'Transaction Stats - MONTHLY',
  rufId: 'monthly',

  component: TransactionStatsListComponent
}

  },


};
@NgModule({
  imports :[
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  MatTableModule,
  MatCardModule,
  RufCommonModule,
  RufCardModule,
  //NgxChartsModule,
  ISTComponentModule
],
declarations: [TransactionStatsListComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsData }],
exports:[],
})
export class TransactionStatsListModule { }
