import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TransStatsTerminalComponent } from './txn-sts-terminal-list.component';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { RufCommonModule } from '@ruf/shell';
import { RufCardModule } from '@ruf/shell';
export const transStatsTerminalData: MonitorComponentData = {
  title: 'Trans Stats - Top 5 Contry',
  icon: 'table',
  examples: {
      'TXNTERC': {
          label: 'Terminal Transaction Statistics',
          title: 'Terminal Transaction Statistics',
          description: 'Terminal Transaction Statistics',
          rufId: 'mon_txn_sts_terminal',
          component: TransStatsTerminalComponent
      }
  },


};
@NgModule({
  imports :[
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  MatTableModule,
  MatCardModule,
  RufCommonModule,
  RufCardModule,
  ISTComponentModule
],
declarations: [TransStatsTerminalComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsTerminalData }],
exports:[],
})
export class TransStatsTerminalModule { }
