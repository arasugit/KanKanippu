import {Component, ViewEncapsulation, OnInit, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef, ViewChild, ElementRef} from '@angular/core';
import { Subject, map, takeUntil} from 'rxjs';
import { MON_ATM_COLOR_SETS } from '../home/ngx-charts-color-sets';
import { AbstractDataTableComponent, DataTableEditableComponent, DataTableEditableDetailComponent, ListComponent, T21Base } from '../components';
import { FormActionPermission, MKCPermission } from '../permission';
import { DataTableService, GlobalsService, ResponseBase } from '../services';
import { WorkRequest } from '../ist-components';
import { TransactionDTO } from './transactiondto';
import { TransactionMultiDTO } from './transactionmultidto';
import { StringUtil } from '../common';
import { eventNames } from 'process';
import { PageEvent } from '@angular/material/paginator';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import HighchartsMore from 'highcharts/highcharts-more';
HighchartsMore(Highcharts);
import HighchartsSolidGauge from 'highcharts/modules/solid-gauge';
HighchartsSolidGauge(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);
@Component({
  selector: 'transaction-stats-details-list',
  templateUrl: './transaction-stats-details-list.component.html',
 styleUrls: ['./transaction.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TransactionStatsDetailsComponent extends ListComponent implements OnInit,OnDestroy {
  private unsubscribe = new Subject();
  chartType :any = 'pie-chart';
  workRequest:WorkRequest;
  view: any[] = [600, 300];
  pieChartView: any[] = [350, 300];
  animations:boolean   = true;
  showLegend:boolean   = true;
  legendTitle: any = 'Legend';
  legendWidth:number=500;
  legendHeight:number=20;
  doughnut = true;
  arcWidth = 0.50;
  screenType: any;
  dataLoaded:boolean=false;
  // public colors: ColorHelper;
  cardTitle:any;
  cardTitleKPI:any;
  cardTitleTxn:any="Acq Trans Details";
  public transactionDataAcq :any[];
  public transactionAcqPercent :any[];
  approvalCnt=0;
  declineCnt=0;
  reversalCnt=0;
  public legendValues:string[]=[];
  public legendValuesPercent:string[]=[];
  // readonly LegendPosition = LegendPosition;
  // readonly LegendType = LegendType;
  // public legendColors: ColorHelper;
  // public transPerLegendColors: ColorHelper;
  public autoRefreshRetriveDataTimer: any;
  currentRequest: WorkRequest = new WorkRequest();
  transStatsRecords: any[] = [];
  isDetailsTab:boolean=true;
  AcqDataList:any=[];
  txnDetailDataList:any=[];
  expandEsc = true;
  isLoading = false;
  loadingMessage = '';
  static txnSrcAcq:any;
  static eventName:any;
  yAxisTicksArr=[50,100,150];
  @ViewChild('firstUpdateField', { static: false })
  firstUpdateField: T21Base;
  @ViewChild('txntableDataTable', { static: false }) private txntableDataTable: DataTableEditableComponent;
  @ViewChild('tableData', { static: false }) private tableDataTable: DataTableEditableDetailComponent;
  colorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };
  perColorScheme :any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };
  columnAcqData: { name: string; data: number[]; }[];
  columnDataAcqCategory: any[] = [];
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options;
  percentageKPIOptions: Highcharts.Options;
  approvalpercent: number;
  declinepercent: number;
  reversalpercent: number;
  constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker, @Inject(ElementRef) private element: ElementRef){
      super(injector);
      this.route
      .data
      .subscribe(v => this.screenType=v['module']);
      this.adjustCriteria();
      this.retriveData();
  }

  ngAfterViewInit() {
    super.criteria=this.criteria;
    //super.search();
    this.setAutoRefreshInterval();
    //this.setAutoRefreshRetriveDataInterval();
}
  adjustCriteria(): void {
    this.globals.setErrorMessage('');
   // this.criteria['productId']= 'ISTSWT';
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['isDetailReq']= 'false';
    this.criteria['ist_page_ctrl'] = '1';
    this.criteria['ist_total'] = 'Y';
    this.criteria['COMMAND']='query';
  }
  retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';

    this.dataService.criteria=this.criteria;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        atmData => this.onGotRecords(atmData),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }
  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnInit(){
    super.ngOnInit();
    if(this.screenType == 'TRANSSTATS' || this.screenType == 'TXNSTS_REQ'){
      this.cardTitle='Transaction Stats Acq - 5 Mins';
      this.exportFileName='Transaction Stats Acq - 5 Mins';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'HOURLY'){
      this.cardTitle='Transaction Stats Acq - Hourly';
      this.exportFileName='Transaction Stats Acq - Hourly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'DAILY'){
      this.cardTitle='Transaction Stats Acq - Daily';
      this.exportFileName='Transaction Stats Acq - Daily';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'WEEKLY'){
      this.cardTitle='Transaction Stats Acq - Weekly';
      this.exportFileName='Transaction Stats Acq - Weekly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'MONTHLY'){
      this.cardTitle='Transaction Stats Acq - Monthly';
      this.exportFileName='Transaction Stats Acq - Monthly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'YEARLY'){
      this.cardTitle='Transaction Stats Acq - Yearly';
      this.exportFileName='Transaction Stats Acq - Yearly';
      this.cardTitleKPI='Percentage KPIs';
    }
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    this.dataLoaded=false;
    if(this.workRequest.lastModified == -1){
      this.globals.setErrorMessage('No Data found');
      return;
    }
    if(this.workRequest!=null && this.workRequest !==undefined &&
      this.workRequest.collections!=null && this.workRequest.collections[this.collectionId]
       !=null && this.workRequest.collections[this.collectionId].rows!=null){
      if(this.workRequest.collections['TRANS_DTL_COL']
         !=null && this.workRequest.collections['TRANS_DTL_COL'].rows!=null){
      this.txnDetailDataList=this.workRequest.collections['TRANS_DTL_COL'].rows;
      this.txntableDataTable.dataSource.data=this.txnDetailDataList;
      DataTableEditableComponent.totalDTLRecords=this.workRequest.lastModified;
      this.txntableDataTable.length=this.workRequest.lastModified;
      DataTableEditableComponent.isTxnDetailScreen=true;
    }

    const rows = this.workRequest.collections[this.collectionId].rows;
    this.AcqDataList = this.workRequest.collections[this.collectionId].rows;
  // const rows = null;
  if(rows!=null && rows!=undefined && rows.length>0){
    let declineCnt=0;
    let reversalCnt=0;
    let totalCnt=0;
    let approvalCnt=0;
    let statusData:any = [];
     let dto:  TransactionDTO;
     let dto2:  TransactionDTO;
     let dto3:  TransactionDTO;
     let dtolist :TransactionDTO[];
     let multidtolist :TransactionMultiDTO[]=[];
     let multidto:  TransactionMultiDTO;
     rows.forEach((c,index) =>{
      approvalCnt=+c.totalApprovalCnt;
      declineCnt=+c.totalDeclineCnt;
      reversalCnt=+c.totalReversalCnt;
     totalCnt=+approvalCnt + +declineCnt + +reversalCnt;
     dtolist =[];
    dto = new TransactionDTO("Approval",approvalCnt.toString());
    dto2  = new TransactionDTO("Decline",declineCnt.toString());
    dto3  = new TransactionDTO("Reversal",reversalCnt.toString());
    dtolist.push(dto);
    dtolist.push(dto2);
    dtolist.push(dto3);

    statusData.push({name: "Approval",value: approvalCnt}) ;
    statusData.push({name: "Decline",value: declineCnt});
    statusData.push({name: "Reversal",value: reversalCnt});
    multidto=new TransactionMultiDTO(""+c.txnsrc+"-"+c.acquirer,dtolist);
   multidtolist.push(multidto);
  })
    this.transactionDataAcq=JSON.parse(JSON.stringify(multidtolist));
    this.getTransactionBarChart();
    //console.log(JSON.stringify(multidtolist));

    approvalCnt=0;
    declineCnt=0;
    reversalCnt=0;

    rows.forEach(c =>{
      approvalCnt=+approvalCnt+ +c.totalApprovalCnt;
      declineCnt=+declineCnt+ +c.totalDeclineCnt;
      reversalCnt=+reversalCnt+ +c.totalReversalCnt;
      totalCnt=+approvalCnt + +declineCnt + +reversalCnt;
   })
   this.adjustChartViewWidth(rows.length);
  //  Legend for bar chart
   this.legendValues.push("Approval"+'-'+approvalCnt);
   this.legendValues.push("Decline"+'-'+declineCnt);
   this.legendValues.push("Reversal"+'-'+reversalCnt);
  //  this.legendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.legendValues, this.colorScheme);
  //  this.transPerLegendColors = new ColorHelper(this.perColorScheme as Color, ScaleType.Ordinal, this.legendValues, this.perColorScheme);
    this.approvalpercent= parseInt(((approvalCnt/totalCnt)*100).toFixed(2));
    this.declinepercent=parseInt(((declineCnt/totalCnt)*100).toFixed(2));
    this.reversalpercent=parseInt(((reversalCnt/totalCnt)*100).toFixed(2));
    let statusDatapercent:any = [];
    let appperdto:  TransactionDTO;
    let delclineperdto:  TransactionDTO;
    let revperdto:  TransactionDTO;
    let dtolistpercent :TransactionDTO[]=[];
    appperdto = new TransactionDTO("Approval % "+this.approvalpercent.toString(),this.approvalpercent.toString());
    delclineperdto  = new TransactionDTO("Decline % "+this.declinepercent.toString(),this.declinepercent.toString());
    revperdto  = new TransactionDTO("Reversal % "+this.reversalpercent.toString(),this.reversalpercent.toString());
    dtolistpercent.push(appperdto);
    dtolistpercent.push(delclineperdto);
    dtolistpercent.push(revperdto);
    this.transactionAcqPercent=JSON.parse(JSON.stringify(dtolistpercent));
    console.log(this.transactionAcqPercent)
    statusDatapercent.push({name: "Approval %",value: this.approvalpercent}) ;
    statusDatapercent.push({name: "Decline %",value: this.declinepercent});
    statusDatapercent.push({name: "Reversal %",value: revperdto});
    this.legendValuesPercent.push("Approval %"+'-'+this.approvalpercent) ;
    this.legendValuesPercent.push("Decline %"+'-'+this.declinepercent);
    this.legendValuesPercent.push("Reversal %"+'-'+this.reversalpercent);
    // this.legendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.legendValues, this.colorScheme);
    // this.transPerLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.legendValuesPercent, this.perColorScheme);
    this.tableDataTable.dataSource.data=this.AcqDataList;
    this.dataLoaded=true;
    this.getTransactionPieChart();
    this.cdr.markForCheck();
    }else{
      this.dataLoaded=false;
    }
    }else{
      this.dataLoaded=false;
    }
  this.globals.hideLoadingBar();
  }

  getTransactionBarChart(){
    let apprData:any[] =[];
    let decData:any[] =[];
    let revData:any[] =[];
    this.columnDataAcqCategory = [];
    this.transactionDataAcq.forEach(res=>{
    this.columnDataAcqCategory.push(res.name);
      res.series.forEach(element => {
        if(element.name === 'Approval'){
          apprData.push(parseInt(element.value));
        }
        if(element.name === 'Decline'){
          decData.push(parseInt(element.value));
        }
        if(element.name === 'Reversal'){
          revData.push(parseInt(element.value));
        }
      });
    })
    this.columnAcqData = [
      { name:'Approval',
      data:apprData
    },
    { name:'Decline',
      data:decData
    },
    { name:'Reversal',
      data:revData
    },
  ]
  this.chartOptions= {
    chart: {
      type: 'column',
  },
  credits:{
    enabled: false,
  },
  title: {
      text: this.cardTitle,
      align: 'left'
  },
  xAxis: {
      categories: this.columnDataAcqCategory,
      crosshair: true,
      accessibility: {
          description: 'Countries'
      }
  },
  yAxis: {
      min: 0,
      title: {
          // text: '1000 metric tons (MT)'
      },
  },
  tooltip: {
      // valueSuffix: ' (1000 MT)'
  },
  legend: {
    labelFormatter: function(){
      const series: any = this as Highcharts.Series;
      const seriesSum = (series.yData || []).reduce((sum,point)=> sum+(point || 0),0);
      return this.name+'(Total:'+seriesSum+')';
    }
},
  plotOptions: {
      column: {
          pointPadding: 0.2,
          borderWidth: 0,
          dataLabels: {
              enabled: true
          }
      },
      series: {
        cursor: 'pointer',
        point: {
            events: {
                click:  (event)=> {
                  this.onBarSliceSelect({
                    x:event.point.x,
                    value:event.point.y,
                    name: event.point.series.name,
                    label: event.point.series.name,
                    series:event.point.category
                  });
                }
              }
        }
    },
  },
  series: this.columnAcqData as any
}
  }
  getTransactionPieChart(){
    const trackColors = Highcharts.getOptions().colors.map(color =>
      new Highcharts.Color(color).setOpacity(0.3).get()
  );
    this.percentageKPIOptions={
      chart: {
          type: 'solidgauge',

          events: {
              // render: renderIcons
          }
      },
      credits:{
        enabled: false,
      },
      legend: {
        // align: "center",
        verticalAlign: "bottom",
        layout: "horizontal",
        labelFormatter: function () {
        return (this as Highcharts.Point).name.split('%')[0] + " - " + ((this as any).yData[0].toFixed(2)+' %' ?? 0);
      },
      },
      title: {
          text: this.cardTitleKPI,
          style: {
              fontSize: '24px'
          }
      },
      tooltip: {
          borderWidth: 0,
          backgroundColor: 'none',
          shadow: false,
          style: {
              fontSize: '16px'
          },
          valueSuffix: '%',
          pointFormat: '{series.name}<br>' +
              '<span style="font-size: 2em; color: {point.color}; ' +
              'font-weight: bold">{point.y}</span>',
          positioner: function (labelWidth) {
              return {
                  x: (this.chart.chartWidth - labelWidth) / 2 + 2,
                  y: (this.chart.plotHeight / 2) + 17
              };
          }
      },
      pane: {
          startAngle: 0,
          endAngle: 360,
          background: [{
              outerRadius: '112%',
              innerRadius: '88%',
              backgroundColor: trackColors[0],
              borderWidth: 0
          }, {
              outerRadius: '87%',
              innerRadius: '63%',
              backgroundColor: trackColors[1],
              borderWidth: 0
          }, {
              outerRadius: '62%',
              innerRadius: '38%',
              backgroundColor: trackColors[2],
              borderWidth: 0
          }]
      },
      yAxis: {
          min: 0,
          max: 100,
          lineWidth: 0,
          tickPositions: []
      },
      plotOptions: {
          solidgauge: {
            colorByPoint: false,
              dataLabels: {
                  enabled: false,
              },
              linecap: 'round',
              stickyTracking: false,
              rounded: true,
          },
      },
      series: [{
          name: 'Approval %',
          showInLegend: true,
          color: Highcharts.getOptions().colors[0],
          data: [{
              color: Highcharts.getOptions().colors[0],
              radius: '112%',
              innerRadius: '88%',
              y: this.approvalpercent
          }],
      }, {
          name: 'Decline %',
          showInLegend: true,
          color: Highcharts.getOptions().colors[1],
          data: [{
              color: Highcharts.getOptions().colors[1],
              radius: '87%',
              innerRadius: '63%',
              y: this.declinepercent
          }],
      }, {
          name: 'Reversal %',
          showInLegend: true,
          color: Highcharts.getOptions().colors[2],
          data: [{
              color: Highcharts.getOptions().colors[2],
              radius: '62%',
              innerRadius: '38%',
              y: this.reversalpercent
          }],
      }] as any
  }
  }
  adjustChartViewWidth(rowCount: number){
    if(rowCount > 5)
      this.view=[rowCount * 120, 300];
  }

  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }
   onCompleteGotRecords(): void {
  }
  getEntPermList(): any[] {
    this.entObjectId = 'TXNSTS_REQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }


  gatherDataChanged(event:any):void{
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNSTS_REQ';
    this.metaDataId = 'TXNSTS_REQ';
    this.tabId = 'TRANSSTATS_TAB';
    this.sectionId = 'TRANSSTATS_SEC';
    this.collectionId = 'TRANSSTATS_COL';
  }
  ngOnDestroy() {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
    this.clearErrorMessage();
  }

onBarSliceSelect(event:any){
  this.globals.showLoadingBar();
  this.adjustCriteria();
  this.criteria['isDetailReq']= 'true';
  this.criteria['eventName']= event.name;
  this.criteria['txnSrcAcq']= event.series;
  TransactionStatsDetailsComponent.eventName=event.name;
  TransactionStatsDetailsComponent.txnSrcAcq=event.series;
  GlobalsService.eventName=event.name;
  GlobalsService.txnSrcAcq=event.series;
  this.criteria['value']= 'event.value';
  this.retriveData();
  var str = event.label;
  var index = str.indexOf( " " );
  var splitted = index > 0 ? str.slice(0,index):str.slice(0);
  this.cardTitleTxn ="Transaction Details "+event.series +" for  "+splitted;
  this.isDetailsTab=false;
  this.setFocusToFirstUpdateField();
}

 // called for data table pagination
 more(pageEvent: PageEvent): void {
  this.globals.showLoadingBar();
  this.criteria[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
  this.criteria['ist_total'] = 'Y';
  this.criteria['isDetailReq']= 'true';
  this.criteria['eventName']=   TransactionStatsDetailsComponent.eventName;
  this.criteria['txnSrcAcq']= TransactionStatsDetailsComponent.txnSrcAcq;
  this.retriveData();
}


}
