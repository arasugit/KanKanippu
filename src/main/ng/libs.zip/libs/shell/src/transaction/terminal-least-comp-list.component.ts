import {Component, ViewEncapsulation, OnInit, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef} from '@angular/core';
import { Subject,takeUntil } from 'rxjs';
import { MON_ATM_COLOR_SETS } from '../home/ngx-charts-color-sets';
import { ListComponent } from '../components';
import { FormActionPermission, MKCPermission } from '../permission';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { StringMap } from '../common';

@Component({
  selector: 'terminal-Least-comp-list',
  templateUrl: './terminal-Least-comp-list.component.html',
  styleUrls: ['./transaction.scss'],
  encapsulation: ViewEncapsulation.None
})


export class TerminalLeastCompComponent extends ListComponent implements OnInit,OnDestroy {
  private unsubscribe = new Subject();
  view: any[] =[300, 250];
  animations = true;
  showLegend = false;
  legendWidth:number=80;
  legendHeight:number=20;
  doughnut = true;
  arcWidth = 0.50;
  atm: any[];
  screenType: any;
  workRequest:WorkRequest;
  // public colors: ColorHelper;
  dataLoaded:boolean=false;
  atmColorScheme = {
    domain: MON_ATM_COLOR_SETS['rufPieChartDarkColorScheme']
  };
  public legendValues:string[]=[];
  // readonly LegendPosition = LegendPosition;
  // readonly LegendType = LegendType;
 constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker){
      super(injector);
       this.retriveData();
  }
  ngAfterViewInit() {
    super.criteria=this.criteria;
        super.search();
        this.setAutoRefreshInterval();

}
  adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
  //  this.criteria['siteId']= 'Site1';
  //  this.criteria['nodeId']='node1';
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }
  getHeaderBasedOnScreenType() : string {
    console.log('screenType inside getHeaderBasedOnScreenType() ::'+this.screenType);
    if(this.screenType === 'WEEKLY' || this.screenType === 'LEASTWEEKLY')
      return 'Weekstart Date';
    else if(this.screenType === 'MONTHLY' || this.screenType === 'LEASTMONTHLY')
      return 'Transaction Month';
    else
      return 'Transaction Date';
  }
  retriveData2():void{
    super.search();
  }
  retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        atmData => this.onGotRecords(atmData),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnInit(){
    super.ngOnInit();
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    console.log('screenType::'+this.screenType);
    if(this.screenType == 'TXNTL_REQ'){
      this.FORM_TITLE='Least Transacting Terminal - Daily';
      this.exportFileName='Least Transacting Terminal - Daily';
    }else  if(this.screenType == 'WEEKLY'){
      this.FORM_TITLE='Least Transacting Terminal - Weekly';
      this.exportFileName='Least Transacting Terminal - Weekly';
    }else  if(this.screenType == 'MONTHLY'){
      this.FORM_TITLE='Least Transacting Terminal - Monthly';
      this.exportFileName='Least Transacting Terminal - Monthly';
    }else  if(this.screenType == 'YEARLY'){
      this.FORM_TITLE='Least Transacting Terminal - Yealy';
      this.exportFileName='Least Transacting Terminal - Yealy';
    }
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    if(this.workRequest!=null && this.workRequest !==undefined && this.workRequest.collections!=null && this.workRequest.collections[this.collectionId] !=null && this.workRequest.collections[this.collectionId].rows!=null){
      const rows = this.workRequest.collections[this.collectionId].rows;
      let statusData:any = [];
      rows.forEach(c =>{
        statusData.push({name: c.terminalId,value: c.terminalId})
        statusData.push({name: c.statusDown,value: c.atmOutOfService})
        this.legendValues.push(c.statusUp+'-'+c.atmInService);
        this.legendValues.push(c.statusDown+'-'+c.atmOutOfService);
      })
      this.atm = [...statusData];
      // this.colors = new ColorHelper(this.atmColorScheme as Color, ScaleType.Ordinal, this.legendValues, this.atmColorScheme);
      this.dataLoaded=true;
      this.cdr.markForCheck();
    }
  }
  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }
  onCompleteGotRecords(): void {
  }
  getEntPermList(): any[] {
    this.entObjectId = 'TXNTL_REQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

  onSelect(event) {
    console.log(event);
  }

  gatherDataChanged(event:any):void{
     console.log(this.dataService.data);
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNTL_REQ';
    this.metaDataId = 'TXNTL_REQ';
    this.tabId = 'TXN_TERLEAST_TAB';
    this.sectionId = 'TXN_TERLEAST_SEC';
    this.collectionId = 'TXN_TERLEAST_COL';
  }
  ngOnDestroy() {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
  }

}

