import {Component, ViewEncapsulation, OnInit, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef} from '@angular/core';
import { Subject,takeUntil } from 'rxjs';
import { MON_ATM_COLOR_SETS } from '../home/ngx-charts-color-sets';
import { ListComponent } from '../components';
import { FormActionPermission, MKCPermission } from '../permission';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';

@Component({
  selector: 'transaction-stats-resp-code',
  templateUrl: './transaction-stats-resp-code.component.html',
  styleUrls: ['./transaction.scss'],
  encapsulation: ViewEncapsulation.None
})


export class TransactionStatsRespCodeComponent extends ListComponent implements OnInit,OnDestroy {
  private unsubscribe = new Subject();
  view: any[] =[300, 250];
  animations = true;
  showLegend = false;
  legendWidth:number=80;
  legendHeight:number=20;
  doughnut = true;
  arcWidth = 0.50;
  atm: any[];
  workRequest:WorkRequest;
  dataLoaded:boolean=false;
  atmColorScheme = {
    domain: MON_ATM_COLOR_SETS['rufPieChartDarkColorScheme']
  };
  public legendValues:string[]=[];
 constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker){
      super(injector);
       //this.retriveData();
  }
  ngAfterViewInit() {

        super.search();
        this.setAutoRefreshInterval();

}
  adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
  //  this.criteria['siteId']= 'Site1';
  //  this.criteria['nodeId']='node1';
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }
  retriveData():void{
    super.search();
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  exportFileName='Transaction Stats Response Code';
  ngOnInit(){
    super.ngOnInit();
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    if(this.workRequest!=null && this.workRequest !==undefined && this.workRequest.collections!=null && this.workRequest.collections[this.collectionId] !=null && this.workRequest.collections[this.collectionId].rows!=null){
      const rows = this.workRequest.collections[this.collectionId].rows;
    }
  }
  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }
  onCompleteGotRecords(): void {
  }
  getEntPermList(): any[] {
    this.entObjectId = 'TXNSTS_REQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

  onSelect(event) {
    console.log(event);
  }

  gatherDataChanged(event:any):void{
     console.log(this.dataService.data);
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNSTS_REQ';
    this.metaDataId = 'TXNSTS_REQ';
    this.tabId = 'TRANSSTATS_TAB';
    this.sectionId = 'TRANSSTATS_SEC';
    this.collectionId = 'TRANSSTATS_COL';
  }
  ngOnDestroy() {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
  }

}

