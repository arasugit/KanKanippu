import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { RufCommonModule,RufScrollbarModule } from '@ruf/shell';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatGridListModule } from '@angular/material/grid-list';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RufCardModule } from '@ruf/shell';
import { ISTComponentModule } from '../ist-components';
import { MON_TOOL, MonitorComponentData } from '../monitor-components/common-object';
import { TransactionStatsIssuerDetailsComponent } from './transaction-stats-details-iss-list.component';
import { HighchartsChartModule } from 'highcharts-angular';

export const transStatsDetailsIssData: MonitorComponentData = {
  title: 'Transaction Stats Details',
  icon: 'table',
  examples: {
      'TXNISS_REQ': {
          label: 'Transaction Stats - 5 Min',
          title: 'Transaction Stats - 5 Min',
          description: 'Transaction Stats - 5 Min',
          rufId: 'mon_trans_stats_detail_issuer',
          component: TransactionStatsIssuerDetailsComponent
      },
      'HOURLY': {
        label: 'Transaction Stats - Hourly ',
        title: 'Transaction Stats - Hourly',
        description: 'Transaction Stats - Hourly',
        rufId: 'mon_trans_stats_detail_issuer_hourly',
        component: TransactionStatsIssuerDetailsComponent
    },
    'DAILY': {
      label: 'Transaction Stats - Daily',
      title: 'Transaction Stats - Daily',
      description: 'Transaction Stats - Daily',
      rufId: 'mon_trans_stats_detail_issuer_daily',

      component: TransactionStatsIssuerDetailsComponent
  },
  'WEEKLY': {
    label: 'Transaction Stats - Weekly',
    title: 'Transaction Stats - Weekly',
    description: 'Transaction Stats - Weekly',
    rufId: 'mon_trans_stats_detail_issuer_weekly',

    component: TransactionStatsIssuerDetailsComponent
},
'MONTHLY': {
  label: 'Transaction Stats - Monthly',
  title: 'Transaction Stats - Monthly',
  description: 'Transaction Stats - MONTHLY',
  rufId: 'mon_trans_stats_detail_issuer_monthly',

  component: TransactionStatsIssuerDetailsComponent
}

  },


};

@NgModule({
  declarations:[TransactionStatsIssuerDetailsComponent],
  imports: [
    CommonModule,
    CdkScrollable,
    MatTableModule,
    FormsModule,
    FlexLayoutModule,
    RufCardModule,
    ReactiveFormsModule,
    ISTComponentModule,
    MatCardModule,
    MatGridListModule,
    RufScrollbarModule,
    RufCommonModule,
    HighchartsChartModule
   ],
  exports:[TransactionStatsIssuerDetailsComponent],
  providers: [{ provide: MON_TOOL, useValue: transStatsDetailsIssData }],
})
export class TransactionStatsIssuerDetailsModule {}
