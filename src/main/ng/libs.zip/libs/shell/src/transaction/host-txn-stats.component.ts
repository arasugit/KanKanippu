import { Component, Injector, OnInit,ChangeDetectorRef, ViewEncapsulation, OnDestroy, ViewChild, Optional, Inject } from '@angular/core';
import { Subject,takeUntil } from 'rxjs';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { DataTableEditableComponent, DataTableEditableDetailComponent } from '../components';
import { PageEvent } from '@angular/material/paginator';

@Component({
    selector: 'host-txn-stats-app',
    templateUrl : './host-txn-stats.component.html',
    styleUrls: ['./transaction.scss'],
    encapsulation: ViewEncapsulation.None
})

export class HostTxnStatsComponent extends ListComponent implements OnInit, OnDestroy{
	private unsubscribe = new Subject();
  view: any[] =[300, 250];
  animations = true;
  screenType: any;
  dataLoaded:boolean=false;
  workRequest:WorkRequest;
  isDetailsTab:boolean=true;
  AcqDataList:any=[];
  txnDetailDataList:any=[];
  cardTitleTxn:any="";
  static terminalId:any;
  @ViewChild('txntableDataTable', { static: false }) private txntableDataTable: DataTableEditableDetailComponent;
	constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef,  @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker){
    super(injector);
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    this.adjustCriteria();
    this.retriveData();
  }

	ngAfterViewInit() {
    super.criteria=this.criteria;
    //super.search();
    this.setAutoRefreshInterval();
  }

	adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['isDetailReq']= 'false';
    this.criteria['ist_page_ctrl'] = '1';
    this.criteria['ist_total'] = 'Y';
    this.criteria['COMMAND']='query';
  }

	retriveData2():void{
    super.search();
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

	retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        atmData => this.onGotRecords(atmData),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      ).add(() => this.globals.hideLoadingBar());
  }

	FORM_TITLE = 'Transaction Statistics for Host Transactions';

	ngOnInit() {
    super.ngOnInit();
    console.log('screenType::'+this.screenType);
    if(this.screenType == 'TXNSHT_REQ'){
      this.FORM_TITLE='Host Transaction Stats - 5 Min';
      this.exportFileName = 'Host Transaction Stats - 5 Min';
    }else  if(this.screenType == 'HOURLY'){
      this.FORM_TITLE='Host Transaction Stats - Hourly';
      this.exportFileName = 'Host Transaction Stats - Hourly';
  	}
    else  if(this.screenType == 'DAILY'){
      this.FORM_TITLE='Host Transaction Stats - Daily';
      this.exportFileName = 'Host Transaction Stats - Daily';
  	}
    else  if(this.screenType == 'WEEKLY'){
      this.FORM_TITLE='Host Transaction Stats - Weekly';
      this.exportFileName = 'Host Transaction Stats - Weekly';
  	}
    else  if(this.screenType == 'MONTHLY'){
      this.FORM_TITLE='Host Transaction Stats - Monthly';
      this.exportFileName = 'Host Transaction Stats - Monthly';
  	}
	}

  responseCollectionHasData(): boolean
  {
    return this.workRequest != null
    && this.workRequest !== undefined
    && this.workRequest.collections != null
    && this.workRequest.collections[this.collectionId] != null
    && this.workRequest.collections[this.collectionId].rows != null;
  }

	onGotRecords(wr: WorkRequest): void {
    this.workRequest = wr;
    this.dataLoaded=false;
    if(this.workRequest.lastModified == -1){
      this.globals.setErrorMessage('No Data found');
      return;
    }
    if(this.responseCollectionHasData()) {
      this.AcqDataList = this.workRequest.collections[this.collectionId].rows;
      if(this.workRequest.collections['TXNS_HOST_DTL_COL'] !=null && this.workRequest.collections['TXNS_HOST_DTL_COL'].rows != null) {
        this.txnDetailDataList=this.workRequest.collections['TXNS_HOST_DTL_COL'].rows;
        console.log("Row Size 11::"+this.txnDetailDataList.length);
        this.txntableDataTable.dataSource.data=this.txnDetailDataList;
        DataTableEditableComponent.totalDTLRecords=this.workRequest.lastModified;
        this.txntableDataTable.length=this.workRequest.lastModified;
        DataTableEditableComponent.isTxnDetailScreen=true;
      }

      this.dataLoaded=true;
      this.cdr.markForCheck();
    }
  }

	onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
	}

	onCompleteGotRecords(): void {
  }

	getEntPermList(): any[] {
    this.entObjectId = 'TXNSHT_REQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

	onSelect(event){
		console.log(event);
	}

	gatherDataChanged(event:any):void{
    console.log(this.dataService.data);
 	}

 setT21Tags(): void {
	this.requestTypeId = 'TXNSHT_REQ';
	this.metaDataId = 'TXNSHT_REQ';
	this.tabId = 'TXNS_HOST_TAB';
	this.sectionId = 'TXNS_HOST_SEC';
	this.collectionId = 'TXNS_HOST_COL';
	}

	ngOnDestroy(): void {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
  }

  onItemClick(selectedItem: any) {
    super.criteria=this.criteria;
    this.criteria['isTxnDetailReq']= 'true';
    this.criteria['terminalId']= selectedItem.terminalId;
    HostTxnStatsComponent.terminalId = selectedItem.terminalId;
    this.globals.showLoadingBar();
    this.retriveData();
    this.isDetailsTab=false;
    this.cardTitleTxn ="Host Transaction Details "
    this.txntableDataTable.dataSource.data=this.txnDetailDataList;
  }

  more(pageEvent: PageEvent): void {
    this.criteria[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
    this.globals.showLoadingBar();
    this.retriveData();
  }
}
