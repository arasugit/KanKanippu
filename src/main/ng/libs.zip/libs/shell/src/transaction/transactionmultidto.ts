import { TransactionDTO } from "./transactiondto";

export  class TransactionMultiDTO {
    
    name: string;
    series: TransactionDTO[];
    //record?: any;
    //constructor(name: string, value: string, record?: any);
    constructor(name: string, value: TransactionDTO[]){
        this.name=name;
        this.series=value;
    }
}

export  class TransactionMultiList {
    private arr;
    private list;
    array: TransactionMultiDTO[];
    records: TransactionMultiDTO[];
}
