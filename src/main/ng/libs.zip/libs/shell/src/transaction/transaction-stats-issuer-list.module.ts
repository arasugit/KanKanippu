import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TransactionStatsIssuerListComponent } from './transaction-stats-issuer-list.component';
//import { NgxChartsModule }from '@swimlane/ngx-charts';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { RufCommonModule } from '@ruf/shell';
import { RufCardModule } from '@ruf/shell';
export const transStatsIssuerData: MonitorComponentData = {
  title: 'Transaction Stats Issuer',
  icon: 'table',
  examples: {
      'TRANS_STATS_ISSUER': {
          label: 'Transaction Stats - 5 Min',
          title: 'Transaction Stats - 5 Min',
          description: 'Transaction Stats - 5 Min',
          rufId: 'mon_trans_stats',
          component: TransactionStatsIssuerListComponent
      },
      'HOURLY': {
        label: 'Transaction Stats - Hourly ',
        title: 'Transaction Stats - Hourly',
        description: 'Transaction Stats - Hourly',
        rufId: 'Hourly',
        component: TransactionStatsIssuerListComponent
    },
    'DAILY': {
      label: 'Transaction Stats - Daily',
      title: 'Transaction Stats - Daily',
      description: 'Transaction Stats - Daily',
      rufId: 'Daily',

      component: TransactionStatsIssuerListComponent
  },
  'WEEKLY': {
    label: 'Transaction Stats - Weekly',
    title: 'Transaction Stats - Weekly',
    description: 'Transaction Stats - Weekly',
    rufId: 'Weekly',

    component: TransactionStatsIssuerListComponent
},
'MONTHLY': {
  label: 'Transaction Stats - Monthly',
  title: 'Transaction Stats - Monthly',
  description: 'Transaction Stats - MONTHLY',
  rufId: 'monthly',

  component: TransactionStatsIssuerListComponent
}

  },


};
@NgModule({
  imports :[
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  MatTableModule,
  MatCardModule,
  RufCommonModule,
  RufCardModule,
  //NgxChartsModule,
  ISTComponentModule
],
declarations: [TransactionStatsIssuerListComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsIssuerData }],
exports:[],
})
export class TransactionStatsIssuerListModule { }
