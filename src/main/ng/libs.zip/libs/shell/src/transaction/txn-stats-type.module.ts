import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TxnStatsTypeComponent } from './txn-stats-type.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule, RufScrollbarModule } from '@ruf/shell';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { HighchartsChartModule } from 'highcharts-angular';

export const txnStatsTypeData: MonitorComponentData = {
  title: 'Transaction Stats By Type',
  icon: 'table',
  examples: {
      'TXNTYPEREQ': {
          label: 'Trans Stats By Type - 5 Min',
          title: 'Trans Stats By Type - 5 Min',
          description: 'Transaction Stats By Type - 5 Min',
          rufId: 'mon_txn_stats_bytype',
          component: TxnStatsTypeComponent
      },
      'HOURLY': {
        label: 'Trans Stats By Type - Hourly',
        title: 'Trans Stats By Type - Hourly ',
        description: 'Transaction Stats By Type - Hourly',
        rufId: 'mon_txn_stats_bytype_hourly',
        component: TxnStatsTypeComponent
    },
    'DAILY': {
      label: 'Trans Stats By Type - Daily',
      title: 'Trans Stats By Type - Daily',
      description: 'Transaction Stats By Type - Daily',
      rufId: 'mon_txn_stats_bytype_daily',
      component: TxnStatsTypeComponent
  },
  'WEEKLY': {
    label: 'Trans Stats By Type - Weekly',
    title: 'Trans Stats By Type - Weekly',
    description: 'Transaction Stats By Type - Weekly',
    rufId: 'mon_txn_stats_bytype_weekly',
    component: TxnStatsTypeComponent
},
  'MONTHLY': {
    label: 'Trans Stats By Type - Monthly',
    title: 'Trans Stats By Type - Monthly',
    description: 'Transaction Stats By Type - Monthly',
    rufId: 'mon_txn_stats_bytype_monthly',
    component: TxnStatsTypeComponent
},
  }
};

@NgModule({
    imports :[
      CommonModule,
      CdkScrollable,
      MatTableModule,
      FormsModule,
      FlexLayoutModule,
      RufCardModule,
      ReactiveFormsModule,
      ISTComponentModule,
      MatCardModule,
      MatGridListModule,
      RufScrollbarModule,
      RufCommonModule,
      MatButtonToggleModule,
      MatTabsModule,
      HighchartsChartModule
  ],
  declarations: [TxnStatsTypeComponent],
  providers: [{ provide: MON_TOOL, useValue: txnStatsTypeData }],
  exports:[],
})
export class TxnStatsTypeModule {}
