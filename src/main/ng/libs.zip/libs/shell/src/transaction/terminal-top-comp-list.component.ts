import {Component, ViewEncapsulation, OnInit, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef, ViewChild, ElementRef} from '@angular/core';
import { min, Subject,takeUntil } from 'rxjs';
import { MON_ATM_COLOR_SETS } from '../home/ngx-charts-color-sets';
import { DataTableEditableComponent, ListComponent } from '../components';
import { FormActionPermission, MKCPermission } from '../permission';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { StringMap } from '../common';
import * as Highcharts from 'highcharts';
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import ExportData from 'highcharts/modules/export-data';
ExportData(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
import { Console } from 'console';
noData(Highcharts);

@Component({
  selector: 'terminal-top-comp-list',
  templateUrl: './terminal-top-comp-list.component.html',
  styleUrls: ['./transaction.scss'],
  encapsulation: ViewEncapsulation.None
})


export class TerminalTopCompComponent extends ListComponent implements OnInit,OnDestroy {
  private unsubscribe = new Subject();
  view: any[] =[300, 250];
  animations = true;
  showLegend = false;
  legendWidth:number=80;
  legendHeight:number=20;
  doughnut = true;
  arcWidth = 0.50;
  atm: any[];
  screenType: any;
  txnDetailDataList: any=[];
  cardTitleTxn: any="Terminal Transactions";
  isDetailsTab: boolean = true;
  topDaily: any[] = [];
  topWeekly: any[] = [];
  topMonthly: any[] = [];
  leastDaily: any[] = [];
  leastWeekly: any[] = [];
  leastMonthly: any[] = [];
  totalDaily: number = 0;
  totalWeekly = 0;
  totalMonthly = 0;
  totalLeastDaily = 0;
  totalLeastWeekly = 0;
  totalLeastMonthly = 0;
  @ViewChild('terminaltxntableDataTable', { static: false }) private terminaltxntableDataTable: DataTableEditableComponent;
  Highcharts: typeof Highcharts = Highcharts;
  getTopTerminalChart:any;
  workRequest:WorkRequest;
  // public colors: ColorHelper;
  dataLoaded:boolean=false;
  atmColorScheme = {
    domain: MON_ATM_COLOR_SETS['rufPieChartDarkColorScheme']
  };
  public legendValues:string[]=[];
  // readonly LegendPosition = LegendPosition;
  // readonly LegendType = LegendType;
 constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker,  @Inject(ElementRef) private element: ElementRef){
      super(injector);
       //this.retriveData();
       this.route
      .data
      .subscribe(v => this.screenType=v['module']);
      this.globals.hideLoadingBar();
  }
  ngAfterViewInit() {
    this.adjustCriteria();
    super.criteria=this.criteria;
        super.search();
        this.retriveData();
        this.setAutoRefreshInterval();
        //this.setAutoRefreshRetriveDataInterval();
}
  adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
  //  this.criteria['siteId']= 'Site1';
  //  this.criteria['nodeId']='node1';
    this.criteria['screenType']=this.screenType;
    if(this.screenType === 'TOP-TERMINAL') {
      this.criteria['screenType']='TXNTC_REQ';
    }
    if(this.screenType === 'LEAST-TERMINAL') {
      this.criteria['screenType']='LEASTDAILY';
    }
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }
  getHeaderBasedOnScreenType() : string {
    if(this.screenType === 'WEEKLY' || this.screenType === 'LEASTWEEKLY')
      return 'Weekstart Date';
    else if(this.screenType === 'MONTHLY' || this.screenType === 'LEASTMONTHLY')
      return 'Transaction Month';
    else
      return 'Transaction Date';
  }
  retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;

    if(this.screenType == 'TOP-TERMINAL'){
      this.globals.showLoadingBar();
      Promise.all([
        this.getData('TXNTC_REQ'),
        this.getData('WEEKLY'),
        this.getData('MONTHLY')
      ])
      .then (()=> {
        this.globals.setErrorMessage("");
        this.getTopChart();
        this.globals.hideLoaderBar();
      });
    }

    if(this.screenType == 'LEAST-TERMINAL'){
      this.globals.showLoadingBar();
      Promise.all([
        this.getData('LEASTDAILY'),
        this.getData('LEASTWEEKLY'),
        this.getData('LEASTMONTHLY')
      ])
      .then (()=> {
      this.globals.setErrorMessage("");
      this.getLeastChart();
      this.globals.hideLoaderBar();
      });
    }
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnInit(){
    super.ngOnInit();
    if(this.screenType == 'TXNTC_REQ'){
      this.FORM_TITLE='Top Transacting Terminal - Daily';
      this.exportFileName='Top Transacting Terminal - Daily';
    }else  if(this.screenType == 'WEEKLY'){
      this.FORM_TITLE='Top Transacting Terminal - Weekly';
      this.exportFileName='Top Transacting Terminal - Weekly';
    }else  if(this.screenType == 'MONTHLY'){
      this.FORM_TITLE='Top Transacting Terminal - Monthly';
      this.exportFileName='Top Transacting Terminal - Monthly';
    }else  if(this.screenType == 'YEARLY'){
      this.FORM_TITLE='Top Transacting Terminal - Yearly';
      this.exportFileName='Top Transacting Terminal - Yearly';
    }else  if(this.screenType == 'LEASTDAILY'){
      this.FORM_TITLE='Least Transacting Terminal - Daily';
      this.exportFileName='Least Transacting Terminal - Daily';
    }else  if(this.screenType == 'LEASTWEEKLY'){
      this.FORM_TITLE='Least Transacting Terminal - Weekly';
      this.exportFileName='Least Transacting Terminal - Weekly';
    }else  if(this.screenType == 'LEASTMONTHLY'){
      this.FORM_TITLE='Least Transacting Terminal - Monthly';
      this.exportFileName='Least Transacting Terminal - Monthly';
    }
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    if(this.workRequest!=null && this.workRequest !==undefined && this.workRequest.collections!=null && this.workRequest.collections[this.collectionId] !=null && this.workRequest.collections[this.collectionId].rows!=null){
      const rows = this.workRequest.collections[this.collectionId].rows;
      this.txnDetailDataList = wr.collections[this.collectionId].rows;
      this.terminaltxntableDataTable.dataSource.data = this.txnDetailDataList;
      DataTableEditableComponent.isTxnDetailScreen = true;
      this.setDetailTablePaginationData(wr);
      let statusData:any = [];
      rows.forEach(c =>{
        statusData.push({name: c.terminalId,value: c.terminalId})
        statusData.push({name: c.statusDown,value: c.atmOutOfService})
        this.legendValues.push(c.statusUp+'-'+c.atmInService);
        this.legendValues.push(c.statusDown+'-'+c.atmOutOfService);
      })
      this.atm = [...statusData];
      // this.colors = new ColorHelper(this.atmColorScheme as Color, ScaleType.Ordinal, this.legendValues, this.atmColorScheme);
      this.dataLoaded=true;
      this.cdr.markForCheck();
    }
  }
  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }
  onCompleteGotRecords(): void {
  }
  getEntPermList(): any[] {
    this.entObjectId = 'TXNTC_REQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');

    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

  onSelect(event) {
    console.log(event);
  }

  gatherDataChanged(event:any):void{
     console.log(this.dataService.data);
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNTC_REQ';
    this.metaDataId = 'TXNTC_REQ';
    this.tabId = 'TXN_TERCOMP_TAB';
    this.sectionId = 'TXN_TERCOMP_SEC';
    this.collectionId = 'TXN_TERCOMP_COL';
  }
  ngOnDestroy() {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
  }
  onItemClick(selectedItem: any) {
  }

  getData(sType: String){
    console.log("screentype: "+ sType);
      this.dataService.requestType=this.requestTypeId;
      this.dataService.collectionTag=this.collectionId;
      this.dataService.action='query';
      this.dataService.criteria=this.criteria;
      this.dataService.criteria['screenType']=sType;
      this.screenType = sType;
        return new Promise((resolve, reject) =>{
          this.dataService.loadData(true).subscribe(
                atmData => {
                  const rows = atmData.collections[this.collectionId].rows;
                  if(sType == 'TXNTC_REQ'){
                    rows.forEach(c =>{
                        this.topDaily.push({terminalid: c.terminalId, totaltransactions: c.totalTranssaction, date: c.transactionDate});
                        this.totalDaily  += parseInt(c.totalTranssaction);
                    });
                    resolve(this.topDaily);
                  }
                  if(sType == 'WEEKLY'){
                    rows.forEach(c =>{
                        this.topWeekly.push({terminalid: c.terminalId, totaltransactions: c.totalTranssaction, date: c.transactionDate});
                        this.totalWeekly  += parseInt(c.totalTranssaction);
                    });
                    resolve(this.topWeekly);
                  }
                  if(sType == 'MONTHLY'){
                    rows.forEach(c =>{
                        this.topMonthly.push({terminalid: c.terminalId, totaltransactions: c.totalTranssaction, date: c.transactionDate});
                        this.totalMonthly  += parseInt(c.totalTranssaction);
                    });
                    resolve(this.topMonthly);
                  }
                  if(sType == 'LEASTDAILY'){
                    rows.forEach(c =>{
                        this.leastDaily.push({terminalid: c.terminalId, totaltransactions: c.totalTranssaction, date: c.transactionDate});
                        this.totalLeastDaily  += parseInt(c.totalTranssaction);
                    });
                    resolve(this.leastDaily);
                  }
                  if(sType == 'LEASTWEEKLY'){
                    rows.forEach(c =>{
                        this.leastWeekly.push({terminalid: c.terminalId, totaltransactions: c.totalTranssaction, date: c.transactionDate});
                        this.totalLeastWeekly  += parseInt(c.totalTranssaction);
                    });
                    resolve(this.leastWeekly);
                  }
                  if(sType == 'LEASTMONTHLY'){
                    rows.forEach(c =>{
                        this.leastMonthly.push({terminalid: c.terminalId, totaltransactions: c.totalTranssaction, date: c.transactionDate});
                        this.totalLeastMonthly  += parseInt(c.totalTranssaction);
                    });
                    resolve(this.leastMonthly);
                  }
                },
                error => this.onErrorGotRecords(error),
                () => this.onCompleteGotRecords()
              );
        });
  }

  getTopChart(){
    this.getTopTerminalChart = {
      chart: {
        type: "column",
        options3d: {
          enabled: true,
          alpha: 10,
          beta: 5,
          depth: 50,
          viewDistance: 25
      },
        events: {
          drilldown: (e: any) => this.onDrillDown(e),
          drillup: () => this.onDrillUp(),
        },
        width:'900',
      },
      title: {
        text: "Top Transacting Terminal",
        align: "left",
      },
      xAxis: {
        type: 'category'
      },
      yAxis: {
        title: {
          text: "Total Transactions",
        },
        type: 'logarithmic',
        min: 1
      },
      legend: {
        enabled: false,
      },
      tooltip: {
        formatter: function() {
          if(this.series.userOptions.id === 'daily' || this.series.userOptions.id === 'weekly') {
            return `Total Transactions: ${this.y}, Date: ${this.point.date}`
          }
          else if (this.series.userOptions.id === 'monthly'){
            return `Total Transactions: ${this.y}, Month: ${this.point.date}`
          }
          else {
            return `${this.key} Transactions: ${this.y}`
          }
        }
      },
      series: [
        {
          name: "Terminal Transactions",
          colorByPoint: true,
          data: [
            {
              name: 'Daily',
              y: this.totalDaily,
              drilldown: 'daily'
            },
            {
              name: 'Weekly',
              y: this.totalWeekly,
              drilldown: 'weekly'
            },
            {
              name: 'Monthly',
              y: this.totalMonthly,
              drilldown: 'monthly'
            }
          ],
        },

      ],
      drilldown: {
        series: [
          {
            id: 'daily',
            name: 'Daily Transactions',
            colorByPoint: true,
            data: this.topDaily.map(item => ({name: item.terminalid,
              y:parseInt(item.totaltransactions), date: item.date}))
          },
          {
            id: 'weekly',
            name: 'Weekly Transactions',
            colorByPoint: true,
            data: this.topWeekly.map(item => ({name: `${item.terminalid} (${item.date})`,
              terminalid: item.terminalid, y:parseInt(item.totaltransactions), date: item.date}))
          },
          {
            id: 'monthly',
            name: 'Monthly Transactions',
            colorByPoint: true,
            data: this.topMonthly.map(item => ({name: item.terminalid,
              y:parseInt(item.totaltransactions), date: item.date}))
          }
        ]
      }
    }
    }
    getLeastChart(){
      this.getTopTerminalChart = {
        chart: {
          type: "column",
          options3d: {
            enabled: true,
            alpha: 10,
            beta: 5,
            depth: 50,
            viewDistance: 25
        },
          events: {
            drilldown: (e: any) => this.onDrillDown(e),
            drillup: () => this.onDrillUp(),
          },
          width:'900',
        },
        title: {
          text: "Least Transacting Terminal",
          align: "left",
        },
        xAxis: {
          type: 'category'
        },
        yAxis: {
          title: {
            text: "Total Transactions",
          },
          type: 'logarithmic',
          min: 1
        },
        legend: {
          enabled: false,
        },
        tooltip: {
          formatter: function() {
            if(this.series.userOptions.id === 'leastdaily' || this.series.userOptions.id === 'leastweekly') {
              return `Total Transactions: ${this.y}, Date: ${this.point.date}`
            }
            else if (this.series.userOptions.id === 'leastmonthly'){
              return `Total Transactions: ${this.y}, Month: ${this.point.date}`
            }
            else {
              return `${this.key} Transactions: ${this.y}`
            }
          }
        },
        series: [
          {
            name: "Terminal Transactions",
            colorByPoint: true,
            data: [
              {
                name: 'Daily',
                y: this.totalLeastDaily,
                drilldown: 'leastdaily'
              },
              {
                name: 'Weekly',
                y: this.totalLeastWeekly,
                drilldown: 'leastweekly'
              },
              {
                name: 'Monthly',
                y: this.totalLeastMonthly,
                drilldown: 'leastmonthly'
              }
            ],
          },

        ],
        drilldown: {
          series: [
            {
              id: 'leastdaily',
              name: 'Daily Transactions',
              colorByPoint: true,
              data: this.leastDaily.map(item => ({name: item.terminalid,
                y:parseInt(item.totaltransactions), date: item.date}))
            },
            {
              id: 'leastweekly',
              name: 'Weekly Transactions',
              colorByPoint: true,
              data: this.leastWeekly.map(item => ({name: `${item.terminalid} (${item.date})`,
                terminalid: item.terminalid, y:parseInt(item.totaltransactions), date: item.date}))
            },
            {
              id: 'leastmonthly',
              name: 'Monthly Transactions',
              colorByPoint: true,
              data: this.leastMonthly.map(item => ({name: item.terminalid,
                y:parseInt(item.totaltransactions), date: item.date}))
            }
          ]
        }
      }
    }
  onDrillUp() {
    this.isDetailsTab = true;
    this.terminaltxntableDataTable.dataSource.data = null;
  }
  onDrillDown(e: any) {
    const type = e.point.drilldown;
    switch(type){
      case 'daily':
        this.onTransByMakeChartClick(e,'TXNTC_REQ', 'Top Transacting Terminal - Daily');
        break;
      case 'weekly':
        this.onTransByMakeChartClick(e,'WEEKLY', 'Top Transacting Terminal - Weekly');
        break;
      case 'monthly':
        this.onTransByMakeChartClick(e,'MONTHLY', 'Top Transacting Terminal - Monthly');
        break;
      case 'leastdaily':
          this.onTransByMakeChartClick(e,'LEASTDAILY', 'Least Transacting Terminal - Daily');
          break;
      case 'leastweekly':
          this.onTransByMakeChartClick(e,'LEASTWEEKLY', 'Least Transacting Terminal - Weekly');
          break;
      case 'leastmonthly':
          this.onTransByMakeChartClick(e,'LEASTMONTHLY', 'Least Transacting Terminal - Monthly');
          break;
    }

  }

  onTransByMakeChartClick(event: Highcharts.SeriesClickEventObject, scType: string, title: string){
    this.globals.showLoadingBar();
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
    this.dataService.criteria['screenType']= scType;
    this.screenType = scType;
    this.terminaltxntableDataTable.paginator.pageIndex = 0;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
      atmData => {this.onGotRecords(atmData);
      },
      error => this.onGotErrorMetaData(error),
      () => this.globals.hideLoadingBar()
    );
    this.cardTitleTxn = ` ${title}`;
    this.isDetailsTab = false;
    this.setFocusToFirstUpdateField();
  }

  setDetailTablePaginationData(wr: WorkRequest): void {
    DataTableEditableComponent.totalDTLRecords = +wr.lastModified;
    this.terminaltxntableDataTable.length = +wr.lastModified;
    this.terminaltxntableDataTable.totalRecords = +wr.lastModified;
}

}

