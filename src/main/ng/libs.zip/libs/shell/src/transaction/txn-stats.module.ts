import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TxnStatsComponent } from './txn-stats.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule } from '@ruf/shell';

export const txnStatsData: MonitorComponentData = {
  title: 'Switch Transacting Terminals List',
  icon: 'table',
  examples: {  
      'TXNSTP_REQ': {
          label: 'Top 25 Transacting Terminals',
          title: 'Top 25 Transacting Terminals',
          description: 'Top 25 Transacting Terminals',
          rufId: 'mon_txn_stats',
          component: TxnStatsComponent
      },
      'BOTTOM': {
        label: 'Least 25 Transacting Terminals',
        title: 'Least 25 Transacting Terminals',
        description: 'Least 25 Transacting Terminals',
        rufId: 'mon_txn_stats',
        component: TxnStatsComponent
    }
 
  }
};

@NgModule({ 
    imports :[ 
    CommonModule,
    FormsModule,
    ReactiveFormsModule,  
    MatTableModule, 
    MatCardModule,  
    RufCommonModule,   
    RufCardModule, 
    ISTComponentModule
  ], 
  declarations: [TxnStatsComponent],
  providers: [{ provide: MON_TOOL, useValue: txnStatsData }],
  exports:[],
})
export class TxnStatsModule {}
