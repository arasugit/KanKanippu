import {Component, ViewEncapsulation, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef, ViewChild } from '@angular/core';
import { finalize, first } from 'rxjs/operators';
import { MON_ATM_COLOR_SETS } from '../../home/ngx-charts-color-sets';
import { DataTableEditableComponent, ListComponent } from '../../components';
import { DataTableService } from '../../services';
import { WorkRequest } from '../../ist-components';
import { ChartDTO, ChartHighChartDTO } from './chart-dto';
import { ChartMultiDTO } from './chart-multi-dto';
import { LabelAndValue, LabelsAndValues } from '@ist-custom-project/shell';
import { Params } from '@angular/router';
import * as Highcharts from 'highcharts';
import timeline from 'highcharts/modules/timeline';
timeline(Highcharts);
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
import { HighChartDto } from '../../cortex/chart-dto';
noData(Highcharts);
@Component({
  selector: 'transaction-dashboard',
  templateUrl: './transaction-dashboard.component.html',
  encapsulation: ViewEncapsulation.None
})

export class TransactionDashboardComponent extends ListComponent implements OnDestroy {
  view: any[] = [300, 300];
  screenType: any;
  txnPeakVolumesData: any[] = [];
  txnPeakVolumesLegendValues: string[] = [];
  txnFailuresData: any[] = [];
  txnFailuresLegendValues: string[] = [];
  txnCompletionTimeData: any[] = [];
  txnCompletionTimeLegendValues: string[] = [];
  txnAuthDenialData: any[] = [];
  txnAuthDenialLegendValues: string[] = [];
  // txnPeakVolumesLegendColors: ColorHelper;
  // txnFailuresLegendColors: ColorHelper;
  // txnCompletionTimeLegendColors: ColorHelper;
  // txnAuthDenialLegendColors: ColorHelper;
  timeRangeData: LabelsAndValues = new LabelsAndValues();
  isDetailReq: boolean = false;
  isDetailsTab:boolean=true;
  txnDetailDataList:any=[];
  @ViewChild('txntableDataTable', { static: false }) private txntableDataTable: DataTableEditableComponent;
  animations = true;
  showLegend = false;
  legendWidth:number=80;
  legendHeight:number=20;
  maxLabelLength:number=20;
  doughnut = true;
  arcWidth = 0.50;
  cardTitleTxn: string;
  Highcharts: typeof Highcharts = Highcharts;
  chartOptionsTransactionStatus: Highcharts.Options;
  transactionAuthroziationDenials: Highcharts.Options;
  transactionAuthroziationCompletion: Highcharts.Options;
  peakTransactionVolumes: Highcharts.Options;
  lineChartPeakTransData: any[];
  lineChartPeakTransAuthCompData: any[];
  lineChartData: any[];
  // readonly LegendPosition = LegendPosition;
  colorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };

  constructor(private injector: Injector, private dataService: DataTableService, private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker) {
      super(injector);


  }

  ngOnInit(): void {
    super.ngOnInit();

    this.route
      .data
      .pipe(first())
      .subscribe(v => this.screenType=v['module']);

      this.adjustCriteria();
      this.retriveData();
  }

  adjustCriteria(): void {
    this.globals.setErrorMessage('');
  //  this.criteria['productId'] = 'ISTSWT';
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
    this.criteria['isDetailReq']= 'false';
    this.criteria['ist_page_ctrl'] = '1';
    this.criteria['ist_total'] = 'Y';
  }

  retriveData(): void {
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;

    this.txnPeakVolumesLegendValues = [];
    this.txnFailuresLegendValues = [];
    this.txnCompletionTimeLegendValues = [];
    this.txnAuthDenialLegendValues = [];

    this.dataService
    .loadData(false)
    .pipe(
      first(),
      finalize(() => this.globals.hideLoadingBar())
    )
    .subscribe(
      {
        next: (data: any) => this.onGotRecords(data),
        error: (error: any) => this.onErrorGotRecords(error)
      }
    );
  }

  onGotRecords(wr: WorkRequest): void {
    const workRequest = wr;
    let multiPeakVolumesList: HighChartDto[] = [],
        multiAuthDenialList: HighChartDto[] = [];

    if(workRequest == null ||  workRequest == undefined || workRequest.collections == null) {
      return;
    }
    if (workRequest.lastModified == -1){
      this.globals.setErrorMessage('No Data found');
      return;
    }

      if (this.isDetailReq) {
          if(workRequest.collections['TXNDASH_DTL_COL']
             !=null && workRequest.collections['TXNDASH_DTL_COL'].rows!=null){
          this.txnDetailDataList=workRequest.collections['TXNDASH_DTL_COL'].rows;
          this.txntableDataTable.dataSource.data=this.txnDetailDataList;
          DataTableEditableComponent.totalDTLRecords=workRequest.lastModified;
          this.txntableDataTable.length=workRequest.lastModified;
          DataTableEditableComponent.isTxnDetailScreen=true;
        }
      } else {
        if (workRequest.collections[this.collectionId] == null
          || workRequest.collections[this.collectionId].rows == null
          || workRequest.collections[this.collectionId].rows == undefined
          || workRequest.collections[this.collectionId].rows.length == 0) {
            return;
          }
      const rows = workRequest.collections[this.collectionId].rows;
      let multiFailuresList: HighChartDto[] = [] , multiPeakVolDtoList: any[] = [];
      this.lineChartPeakTransData = [];
      rows.forEach((c) => {
        let peakVolumesList = c.peakVolumesList;

        peakVolumesList.forEach(p => {
          let dto = new HighChartDto(p.hours, p.tranCount);
          multiPeakVolumesList.push(dto);
          this.txnPeakVolumesLegendValues.push(p.hours + '-' + p.tranCount);
          this.lineChartPeakTransData.push({name:p.hours+':00',label:p.tranCount,description:p.tranCount});
        });

        multiPeakVolDtoList.push(new ChartMultiDTO('Count' , multiPeakVolumesList));
        // this.txnPeakVolumesLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.txnPeakVolumesLegendValues, this.colorScheme);
        this.txnPeakVolumesData = JSON.parse(JSON.stringify(multiPeakVolDtoList));
        console.log('line chart trans peak', this.lineChartPeakTransData);
        this.getPeakTransactionVolumes();

        let authDenialList = c.authDenialList, multiAuthDenialDtoList: any[] = [];
        this.lineChartData = [];
        let authDenialDtoList: HighChartDto[] = [];

        authDenialList.forEach(a => {
          let dto = new HighChartDto(a.txnDate, a.denialCount);
          let multiDto = new ChartMultiDTO(a.txnDate, [dto]);
          authDenialDtoList.push(dto);
          this.txnAuthDenialLegendValues.push(a.txnDate + '-' + a.denialCount);
          this.lineChartData.push({name:a.txnDate,label:a.denialCount,description:a.denialCount});
        });

        multiAuthDenialDtoList.push(new ChartMultiDTO('Open' , authDenialDtoList));
        // this.txnAuthDenialLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.txnAuthDenialLegendValues, this.colorScheme);
        this.txnAuthDenialData = JSON.parse(JSON.stringify(multiAuthDenialDtoList));
        console.log('line chart', this.txnAuthDenialData);
        this.getTransactionAuthroziationDenials();

        let failureList = c.failureList;
        failureList.forEach(f => {
          let successCount = f.successCount === null ? 0 : f.successCount,
              failureCount = f.failureCount === null ? 0 : f.failureCount;
          let dto = new HighChartDto('Success', successCount);
          multiFailuresList.push(dto);
          this.txnFailuresLegendValues.push('Success' + '-' + successCount);

          dto = new HighChartDto('Failure', failureCount);
          multiFailuresList.push(dto);
          this.txnFailuresLegendValues.push('Failure' + '-' + failureCount);
        });

        if (multiFailuresList !== undefined) {
          // this.txnFailuresLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.txnFailuresLegendValues, this.colorScheme);
          this.txnFailuresData = JSON.parse(JSON.stringify(multiFailuresList));
          console.log(this.txnFailuresData);
          this.getTransactionStatus();
        }

        let completionTimeList = c.completionTimeList, multiDtoCompTimeList: any[] = [];
        let multiCompletionTimeDtoList: HighChartDto[] = [];
        this.lineChartPeakTransAuthCompData = [];

        completionTimeList.forEach(h => {
          let dto = new HighChartDto('1 Sec', h.secCount);
          multiCompletionTimeDtoList.push(dto);
          this.txnCompletionTimeLegendValues.push('1 Sec' + '-' + h.count);

          dto = new HighChartDto('1 Min', h.min1Count);
          multiCompletionTimeDtoList.push(dto);
          this.txnCompletionTimeLegendValues.push('1 Min' + '-' + h.min1Count);

          dto = new HighChartDto('2 Min', h.min2Count);
          multiCompletionTimeDtoList.push(dto);
          this.txnCompletionTimeLegendValues.push('2 Min' + '-' + h.min2Count);

          dto = new HighChartDto('3 Min', h.min3Count);
          multiCompletionTimeDtoList.push(dto);
          this.txnCompletionTimeLegendValues.push('3 Min' + '-' + h.min3Count);

          dto = new HighChartDto('4 Min', h.min4Count);
          multiCompletionTimeDtoList.push(dto);
          this.txnCompletionTimeLegendValues.push('4 Min' + '-' + h.min4Count);

          dto = new HighChartDto('5 Min', h.min5Count);
          multiCompletionTimeDtoList.push(dto);
          this.txnCompletionTimeLegendValues.push('5 Min' + '-' + h.min5Count);

          this.lineChartPeakTransAuthCompData.push(
             {name:'1 Sec',label:h.secCount,description:h.secCount}
            ,{name:'1 Min',label:h.min1Count,description:h.min1Count}
            ,{name:'2 Min',label:h.min2Count,description:h.min2Count}
            ,{name:'3 Min',label:h.min3Count,description:h.min3Count}
            ,{name:'4 Min',label:h.min4Count,description:h.min4Count}
            ,{name:'5 Min',label:h.min5Count,description:h.min5Count}
          );
        });

        multiDtoCompTimeList.push(new ChartMultiDTO('Completion Time' , multiCompletionTimeDtoList));
        // this.txnCompletionTimeLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.txnCompletionTimeLegendValues, this.colorScheme);
        this.txnCompletionTimeData = JSON.parse(JSON.stringify(multiDtoCompTimeList));
      });
      this.adjustChartViewWidth(rows.length);
      }
      this.getTransactionAuthroziationCompletion();
      this.cdr.markForCheck();
  }

  adjustChartViewWidth(rowCount: number) {
    if(rowCount > 2)
      this.view = [300, 300];
  }

  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNDASH';
    this.metaDataId = 'TXNDASH';
    this.tabId = 'TXNDASH_TAB';
    this.sectionId = 'TXNDASH_SEC';
    this.collectionId = 'TXNDASH_COL';
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
    this.clearErrorMessage();
  }

  onPeakVolumesSelect(event: any) {
    this.globals.showLoadingBar();
    this.txntableDataTable.dataSource.data=null;
    this.txntableDataTable.length=0;
    this.criteria['chartType'] = 'PEAKVOLUME';
    this.criteria['isDetailReq'] = 'true';
    this.criteria['hour'] = event.name;
    this.isDetailReq = true;
    this.isDetailsTab = false;
    this.cardTitleTxn = 'Transaction Peak Volume Details';
    this.retriveData();
  }

  onAuthDenialSelect(event: any) {
    this.globals.showLoadingBar();
    this.txntableDataTable.dataSource.data=null;
    this.txntableDataTable.length=0;
    this.criteria['chartType'] = 'AUTHDENIAL';
    this.criteria['isDetailReq'] = 'true';
    this.criteria['txnDate'] = event.name;
    this.isDetailReq = true;
    this.isDetailsTab = false;
    this.cardTitleTxn = 'Transaction Authorization Denial Details';
    this.retriveData();
  }

  onTransactionFailureSelect(event: any) {
    this.globals.showLoadingBar();
    this.txntableDataTable.dataSource.data=null;
    this.txntableDataTable.length=0;
    this.criteria['chartType'] = 'FAILURECNT';
    this.criteria['isDetailReq'] = 'true';
    this.criteria['status'] = event.name;
    this.isDetailReq = true;
    this.isDetailsTab = false;
    this.cardTitleTxn = 'Transaction Failure Details';
    this.retriveData();
  }

  onTransactionCompletionSelect(event: any) {
    this.globals.showLoadingBar();
    this.txntableDataTable.dataSource.data=null;
    this.txntableDataTable.length=0;
    this.criteria['chartType'] = 'COMPTIME';
    this.criteria['isDetailReq'] = 'true';
    this.criteria['compTime'] = event.name;
    this.isDetailReq = true;
    this.isDetailsTab = false;
    this.cardTitleTxn = 'Transaction Completion Time Details';
    this.retriveData();
  }

  setQueryParameters(params: Params): void {
    this.params = params;
    this.querySection.setQueryParameters(this.params, this.criteria);
  }

  changeHandler(event: any) {
    this.globals.setErrorMessage('');
    if(null == event) return;
    this.adjustCriteria();
    this.retriveData();
  }

  getTransactionStatus(){
    this.chartOptionsTransactionStatus = {
      chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45
        },

    },
    credits:{
      enabled: false,
    },
    title: {
        text: 'Transaction Failure Count (Current Day)',
        margin:0,
    },
    tooltip: {
        pointFormat: '<b>{point.y}</b>'
    },
    legend: {
      align: "center",
      verticalAlign: "bottom",
      layout: "horizontal",
      labelFormatter: function () {
      return this.name + " - " + ((this as Highcharts.Point).y ?? 0);
    },
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.y}',
                style: {}
            },
            size: '50%',
            innerSize: '60%',
            depth: 45,
            showInLegend: true
        }
    },
    series: [{
        name: '',
        colorByPoint: true,
        type:'pie',
        data:this.txnFailuresData,
        point: {},
    }as any],
    };
  }

  getTransactionAuthroziationCompletion(){
  this.transactionAuthroziationCompletion = {
    chart: { type: 'timeline'},
    credits:{
      enabled: false,
    },
    title: { text: 'Transaction Authorization and Completion Times (By Min)' },
    xAxis: {
      title: {
        text: 'Time(min)'
    },
  },
  yAxis: {
      visible: false
  },
  plotOptions: {
    series: {
        dataLabels: {
            enabled: true
        }
    }
  },
  tooltip: {
  format: '<span ' +
            'style="font-weight: bold;" > ' +
            'Count</span><br/>{point.label}'
  },
    series: [{
      dataLabels: {
        allowOverlap: false,
        format: '<span style="color:{point.color}">● </span><span ' +
            'style="font-weight: bold;" > ' +
            '{point.label}</span><br/>{point.name}'
    },
    marker: {
    },
        data: this.lineChartPeakTransAuthCompData
      },
    ]as any,
  };
  }

getTransactionAuthroziationDenials(){
this.transactionAuthroziationDenials = {
  chart: { type: 'timeline'},
  credits:{
    enabled: false,
  },
  title: { text: 'Authroziation Denials (Daywise)' },
  xAxis: {
    title: {
      text: 'Dates'
  },
},
yAxis: {
    visible: false
},
plotOptions: {
  series: {
      dataLabels: {
          enabled: true
      }
  }
},
tooltip: {
format: '<span ' +
          'style="font-weight: bold;" > ' +
          'Denial Count</span><br/>{point.label}'
},
  series: [{
    dataLabels: {
      allowOverlap: false,
      format: '<span style="color:{point.color}">● </span><span ' +
          'style="font-weight: bold;" > ' +
          '{point.label}</span><br/>{point.name}'
  },
  marker: {
  },
      data: this.lineChartData
    },
  ]as any,
};
}

getPeakTransactionVolumes(){
  this.peakTransactionVolumes = {
    chart: { type: 'timeline'},
    credits:{
      enabled: false,
    },
    title: { text: 'Peak Transaction Volumes (Current Day)' },
    xAxis: {
      title: {
        text: 'Time (Hrs.)'
    },
  },
  yAxis: {
      visible: false
  },
  plotOptions: {
    series: {
        dataLabels: {
            enabled: true
        }
    }
  },
  tooltip: {
  format: '<span ' +
            'style="font-weight: bold;" > ' +
            'Transaction Volume</span><br/>{point.label}'
  },
    series: [{
      dataLabels: {
        allowOverlap: false,
        format: '<span style="color:{point.color}">● </span><span ' +
            'style="font-weight: bold;" > ' +
            '{point.label}</span><br/>{point.name}'
    },
    marker: {
    },
        data: this.lineChartPeakTransData
      },
    ]as any,
  };
}

}
