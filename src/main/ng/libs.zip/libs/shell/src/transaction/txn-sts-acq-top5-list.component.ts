import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent} from '../components/base-list.component';
import { StringUtil,CustomValidators, CommonConstants, LabelsAndValues, LabelAndValue } from '../common';
import { T21Base } from '../components';

@Component({
  selector: 'txn-sts-acq-top5-list',
  templateUrl: './txn-sts-acq-top5-list.component.html',
  styleUrls: ['./transaction.scss'],
  encapsulation: ViewEncapsulation.None
})


export class TransAcqRejectionToolComponent extends ListComponent implements OnInit { 
     
  constructor(injector: Injector) {
    super(injector);
  }
  FORM_TITLE = '';

   product = '';
   fromTime :  string = '';
   fromDate : any = '';
   dateTo : any = '';
   toTime : string = '';
   screenType ='';
   declineCategory : string = '';
   businessDeclineList : LabelsAndValues = new LabelsAndValues();

  @ViewChild('toDateFocusField', { static: false })
  toDateFocusField: T21Base;

   queryPerm = new FormActionPermission('TXNRJACQ', 'Q');
   checkerPerm = new FormActionPermission('TXNRJACQ', 'C');
   mkcPerm = new MKCPermission('TXNRJACQ'); 
   
   adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
    this.criteria['fromTime']= this.fromTime;
    this.criteria['toTime']=this.toTime;
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId; 
    this.criteria['collectionId']=this.collectionId;  
    this.criteria['COMMAND']='query';   
  }  
   ngOnInit() {
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);  
    this.requestPerms.getPermission(this.router.url); 
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    if(this.screenType == 'TXNRJACQ'){
      this.FORM_TITLE=' Top 5 acquiring transactions rejections';
      this.exportFileName=' Top 5 acquiring transactions rejections';
    }else  if(this.screenType == 'ISSUING'){
      this.FORM_TITLE='Top 5 issuing transactions rejections';
      this.exportFileName='Top 5 issuing transactions rejections';
    }

    this.businessDeclineList.array = [new LabelAndValue('', ''), new LabelAndValue('Business Decline', 'Business Decline'), new LabelAndValue('Technical Decline', 'Technical Decline')];
    this.setAutoRefreshSearch(true);
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNRJACQ';
    this.metaDataId = 'TXNRJACQ';
    this.tabId = 'TXNRJACQ_TAB';
    this.sectionId = 'TXNRJACQ_SEC';
    this.collectionId = 'TXNRJACQ_COL';
  }

validateBeforeQuery(): boolean {
    CustomValidators.globals=this.globals;
    this.fromDate=CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo=CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat); 
    let result:boolean;
    result= CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField);
  if(result){
    result= CustomValidators.validateTimeField(this.fromTime);
 }
 
 if(result){
   result= CustomValidators.validateTimeField(this.toTime);
}

return result;
}

validateFromTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
validateToTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
getModuleName() { return 'IST-MONITORING'; }
emitModuleReady() { this.msgService.sendMessage(this.getModuleName() ); }
}