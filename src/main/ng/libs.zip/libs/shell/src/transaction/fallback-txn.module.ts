import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RejectedTxnsComponent } from './rejected-txn.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule } from '@ruf/shell';
import { FallbackTxnsComponent } from './fallback-txn.component';

export const fallbackTxnsData: MonitorComponentData = {
  title: 'Switch Transacting Terminals List',
  icon: 'home',
  examples: {  
      'TXNFBC_REQ': {
          label: 'Fallback Transactions Count',
          title: 'Fallback Transactions Count',
          description: 'Fallback Transactions Count',
          rufId: 'fallback_txns_count',
          component: FallbackTxnsComponent
      }
  }
};

@NgModule({ 
    imports :[ 
    CommonModule,
    FormsModule,
    ReactiveFormsModule,  
    MatTableModule, 
    MatCardModule,  
    RufCommonModule,   
    RufCardModule, 
    ISTComponentModule
  ], 
  declarations: [FallbackTxnsComponent],
  providers: [{ provide: MON_TOOL, useValue: fallbackTxnsData }],
  exports:[],
})
export class FallbackTxnsModule {}
