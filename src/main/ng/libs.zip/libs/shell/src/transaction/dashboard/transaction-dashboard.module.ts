import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RufCardModule } from '@ruf/shell';
import { ISTComponentModule } from '../../ist-components';
import { MON_TOOL, MonitorComponentData } from '../../monitor-components/common-object';
import { TransactionDashboardComponent } from './transaction-dashboard.component';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HighchartsChartModule } from 'highcharts-angular';

export const txnDashboardData: MonitorComponentData = {
  title: 'Transaction Dashboard',
  icon: 'table',
  examples: {
      'TXNDASH': {
          label: 'Transaction Dashboard',
          title: 'Transaction Dashboard',
          description: 'Transaction Dashboard',
          rufId: 'txn_dashboard',
          component: TransactionDashboardComponent
      }
  }
};

@NgModule({
  declarations:[TransactionDashboardComponent],
  imports: [
    FlexLayoutModule,
    RufCardModule,
    MatCardModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    ISTComponentModule,
    HighchartsChartModule,
   ],
  exports:[TransactionDashboardComponent],
  providers: [{ provide: MON_TOOL, useValue:  txnDashboardData}],
})

export class TransactionDashboardModule {}
