import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TransStatsAtmPosComponent } from './txn-sts-atm-pos-list.component';
export const transStatsAtmPosData: MonitorComponentData = {
  title: 'Transaction Statistics based on processing code',
  icon: 'table',
  examples: {  
      'TXNATMPOS': {
          label: 'Trans Stats ATM - Acquirer',
          title: 'Trans Stats ATM - Acquirer',
          description: 'Trans Stats ATM - Acquirer',
          rufId: 'mon_txn_sts_acq_atm',
          component: TransStatsAtmPosComponent
      },
  'TXN-POS-ACQ': {
    label: 'Trans Stats POS - Acquirer',
    title: 'Trans Stats POS - Acquirer',
    description: 'Trans Stats POS - Acquirer',
    rufId: 'mon_txn_sts_acq_pos',

    component: TransStatsAtmPosComponent
},
'TXN-ATM-ISSUER': {
  label: 'Trans Stats ATM - Issuer',
  title: 'Trans Stats ATM - Issuer',
  description: 'Trans Stats ATM - Issuer',
  rufId: 'mon_txn_sts_issuer_atm',

  component: TransStatsAtmPosComponent
},
'TXN-POS-ISSUER': {
  label: 'Trans Stats POS - Issuer',
  title: 'Trans Stats POS - Issuer',
  description: 'Trans Stats POS - Issuer',
  rufId: 'mon_txn_sts_issuer_pos',

  component: TransStatsAtmPosComponent
}
  },

  
};
@NgModule({ 
  imports :[ 
  FormsModule,
  ReactiveFormsModule, 
  MatTableModule, 
  MatCardModule, 
  ISTComponentModule
], 
declarations: [TransStatsAtmPosComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsAtmPosData }],
exports:[],
})
export class TransStatsAtmPosModule { }
