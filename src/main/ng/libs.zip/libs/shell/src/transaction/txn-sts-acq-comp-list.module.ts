import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TransStatsAcqCompComponent } from './txn-sts-acq-comp-list.component';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { RufCommonModule } from '@ruf/shell';
import { RufCardModule } from '@ruf/shell';
export const transStatsAcqCompData: MonitorComponentData = {
  title: 'Transaction Stats Acquirer Comp Details',
  icon: 'table',
  examples: {
      'TXNSTS_ACQ': {
          label: 'Transaction Stats Acquirer - Daily',
          title: 'Transaction Stats Acquirer - Daily',
          description: 'Transaction Stats Acquirer - Daily',
          rufId: 'mon_txn_sts_acq_comp',
          component: TransStatsAcqCompComponent
      },
  'WEEKLY': {
    label: 'Transaction Stats Acquirer - Weekly',
    title: 'Transaction Stats Acquirer - Weekly',
    description: 'Transaction Stats Acquirer - Weekly',
    rufId: 'mon_txn_sts_acq_comp_weekly',

    component: TransStatsAcqCompComponent
},
'MONTHLY': {
  label: 'Transaction Stats Acquirer - Monthly',
  title: 'Transaction Stats Acquirer - Monthly',
  description: 'Transaction Stats Acquirer - Monthly',
  rufId: 'mon_txn_sts_acq_comp_monthly',

  component: TransStatsAcqCompComponent
}
  },


};
@NgModule({
  imports :[
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  MatTableModule,
  MatCardModule,
  RufCommonModule,
  RufCardModule,
  ISTComponentModule
],
declarations: [TransStatsAcqCompComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsAcqCompData }],
exports:[],
})
export class TransStatsAcqCompModule { }
