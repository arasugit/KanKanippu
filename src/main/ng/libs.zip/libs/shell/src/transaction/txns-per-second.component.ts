import { Component, Injector, OnInit,ChangeDetectorRef, ViewEncapsulation, OnDestroy, Optional, Inject, ViewChild } from '@angular/core';
import { Subject,takeUntil } from 'rxjs';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableService } from '../services';
import { DataTableEditableDetailComponent } from "../components";
import { WorkRequest } from '../ist-components';
import { PageEvent } from '@angular/material/paginator';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import highcharts3d from 'highcharts/highcharts-3d';
highcharts3d(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);

@Component({
    selector: 'txns-per-second-app',
    templateUrl : './txns-per-second.component.html',
    styleUrls: ['./transaction.scss'],
    encapsulation: ViewEncapsulation.None
})

export class TxnsPerSecondComponent extends ListComponent implements OnInit, OnDestroy{
	private unsubscribe = new Subject();
  view: any[] =[300, 250];
  animations = true;
  screenType: any;
  isDetailsTab: boolean = true;
  isDashboardTab: boolean = true;
  Highcharts: typeof Highcharts = Highcharts;
  getCurrentTpsChart:Highcharts.Options;
  getTodayTpsChart:Highcharts.Options;
  getMonthTpsChart:Highcharts.Options;
  getInstCurrentTpsChart:Highcharts.Options;
  getInstTodayTpsChart:Highcharts.Options;
  getInstMonthTpsChart:Highcharts.Options;
  cardTitleTxn: any="TPS Dashboard";
  currentTps: any;
  todayTps: any;
  monthTps: any;
  instCurrentTps: any[] = [];
  instTodayTps: any[] = [];
  instMonthTps: any[] = [];
  dataLoaded:boolean=true;
  workRequest:WorkRequest;
  tpsByInstDataList: any = [];
  @ViewChild("tpsByInstDataTable", { static: false })
  private tpsByInstDataTable: DataTableEditableDetailComponent;

	constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker,){
    super(injector);
    this.route
      .data
      .subscribe(v => this.screenType=v['module']);
  }

	ngAfterViewInit() {
    super.criteria=this.criteria;
    super.search();
    this.retriveData();
    this.retriveData1();
    this.setAutoRefreshInterval();
  }

	adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
  //  this.criteria['siteId']= 'Site1';
  //  this.criteria['nodeId']='node1';
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria["ist_total"] = "n";
    this.criteria['COMMAND']='query';
  }

	retriveData():void{
    this.isDetailsTab = false;
    this.isDashboardTab = true;
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;

    if (this.screenType === 'CURRENT-TPS' || this.screenType === 'TODAY-TPS' || this.screenType === 'AVERAGE-TPS')
    {
      this.screenType = 'INST-' + this.screenType;
      this.criteria['screenType'] = this.screenType;
      this.criteria["ist_total"] = "y";

      this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        atmData => this.onGotRecords(atmData),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
    }
  }

	FORM_TITLE = 'Transactions Per Second ';

	ngOnInit() {
    super.ngOnInit();
    if(this.screenType == 'AVERAGE-TPS'){
      this.FORM_TITLE='Current Month TPS';
      this.exportFileName = 'Current Month Average TPS';
      this.cardTitleTxn = 'Current Month Average TPS';
    }else  if(this.screenType == 'CURRENT-TPS'){
      this.FORM_TITLE='Current TPS';
      this.exportFileName = 'Current TPS';
      this.cardTitleTxn = 'Current TPS';
  	}
    else  if(this.screenType == 'TODAY-TPS'){
      this.FORM_TITLE='Today TPS';
      this.exportFileName = 'Today Average TPS';
      this.cardTitleTxn = 'Today Average TPS';
  	}
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

	onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    var rows = [];

    if (this.workRequest === null || this.workRequest === undefined)
      return;

    if (wr.lastModified == -1)
    {
      var data = {tps : "No Transaction Found."}
      rows.push(data)
    }

    if(rows.length == 0 && this.workRequest.collections != null && this.workRequest.collections[this.collectionId] != null && this.workRequest.collections[this.collectionId].rows != null){
      rows = this.workRequest.collections[this.collectionId].rows;
    }

    this.tpsByInstDataList = rows;
    this.tpsByInstDataTable.dataSource.data = this.tpsByInstDataList;
    this.setTpsByInstTablePaginationData();
    this.dataLoaded=true;
  }

  setTpsByInstTablePaginationData(): void {
      if (this.criteria["ist_total"] !== "y") {
        return;
      }

      DataTableEditableDetailComponent.totalDTLRecords = this.workRequest.lastModified;
      this.tpsByInstDataTable.length = this.workRequest.lastModified;
      this.tpsByInstDataTable.totalRecords = this.workRequest.lastModified;
  }

  moreDetails(pageEvent: PageEvent): void {
    this.criteria["ist_total"] = "n";
    this.criteria[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
    this.globals.showLoadingBar();
    this.retriveData();
  }

	onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
	}

	onCompleteGotRecords(): void {
    this.screenType = this.screenType.replace('INST-', '');
    this.criteria['screenType'] = this.screenType;
  }

	getEntPermList(): any[] {
    this.entObjectId = 'TXNTPS_REQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

	onSelect(event){
		console.log(event);
	}

	gatherDataChanged(event:any):void{
    console.log(this.dataService.data);
 	}

 setT21Tags(): void {
	this.requestTypeId = 'TXNTPS_REQ';
	this.metaDataId = 'TXNTPS_REQ';
	this.tabId = 'TXNS_TPS_TAB';
	this.sectionId = 'TXNS_TPS_SEC';
	this.collectionId = 'TXNS_TPS_COL';
	}

	ngOnDestroy(): void {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
  }

  retriveData1():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;

    if(this.screenType == 'TXNTPS-DASH'){
      this.isDetailsTab = true;
      this.isDashboardTab = false;
      this.globals.showLoadingBar();
      Promise.all([
        this.getData('CURRENT-TPS'),
        this.getData('TODAY-TPS'),
        this.getData('AVERAGE-TPS'),
        this.getData('INST-CURRENT-TPS'),
        this.getData('INST-TODAY-TPS'),
        this.getData('INST-AVERAGE-TPS')
      ])
      .then (()=> {
        this.globals.setErrorMessage("");
        this.getCurrentTps();
        this.getTodayTps();
        this.getMonthTps();
        this.getInstCurrentTps();
        this.getInstTodayTps();
        this.getInstMonthTps();
        this.globals.hideLoaderBar();
      });
    }
  }

  getData(sType: String){
    console.log("screentype: "+ sType);
      this.dataService.requestType=this.requestTypeId;
      this.dataService.collectionTag=this.collectionId;
      this.dataService.action='query';
      this.dataService.criteria=this.criteria;
      this.dataService.criteria['screenType']=sType;
      this.screenType = sType;
        return new Promise((resolve, reject) =>{
          this.dataService.loadData(true).subscribe(
                atmData => {
                  const rows = atmData.collections[this.collectionId].rows;
                  if(sType == 'CURRENT-TPS'){
                    this.currentTps = parseFloat(rows[0].tps);
                    resolve(this.currentTps);
                  }
                  else if(sType == 'TODAY-TPS'){
                    this.todayTps = parseFloat(rows[0].tps);
                    resolve(this.todayTps);
                  }
                  else if(sType == 'AVERAGE-TPS'){
                    this.monthTps = parseFloat(rows[0].tps);
                    resolve(this.monthTps);
                  }
                  else if(sType == 'INST-CURRENT-TPS'){
                    rows.forEach(c =>{
                        this.instCurrentTps.push([c.txnDest, parseFloat(c.tps)]);
                    });
                    this.sortInstDataByTps(this.instCurrentTps);
                    resolve(this.instCurrentTps);
                  }
                  else if(sType == 'INST-TODAY-TPS'){
                    rows.forEach(c =>{
                      this.instTodayTps.push([c.txnDest, parseFloat(c.tps)]);
                    });
                    this.sortInstDataByTps(this.instTodayTps);
                    resolve(this.instTodayTps);
                  }
                  else if(sType == 'INST-AVERAGE-TPS'){
                    rows.forEach(c =>{
                      this.instMonthTps.push([c.txnDest, parseFloat(c.tps)]);
                    });
                    this.sortInstDataByTps(this.instMonthTps);
                    resolve(this.instMonthTps);
                  }
                },
                error => this.onErrorGotRecords(error),
                () => this.onCompleteGotRecords()
              );
        });
  }

  getCurrentTps(){
    this.getCurrentTpsChart = {
    chart: {
      type: 'gauge',
      height: '300'
    },

    title: {
        text: 'Current TPS'
    },

    pane: {
        startAngle: -90,
        endAngle: 89.9,
        background: null,
        center: ['50%', '75%'],
        size: '85%'
    },
    credits:{
      enabled: false,
    },

    // the value axis
    yAxis: {
        min: 0,
        max: 5000,
        tickColor: Highcharts.defaultOptions.chart.backgroundColor || '#FFFFFF',
        labels: {
            distance: 20,
            style: {
                fontSize: '14px'
            }
        },
        lineWidth: 0,
         plotBands: [{
            from: 0,
            to: 5000,
            color: '#55BF3B', // green
            thickness: 20,
            borderRadius: '50%'
        }]
    },

    series: [{
      type: 'gauge',
        name: 'Current TPS',
        //data: [parseFloat(this.currentTps[0].tps)],
        data: [this.currentTps],
        tooltip: {
            valueSuffix: ' TPS'
        },
        dataLabels: {
            format: '{y} TPS',
            borderWidth: 0,
            style: {
                fontSize: '16px'
            }
        },
        dial: {
            radius: '80%',
            backgroundColor: 'gray',
            baseWidth: 12,
            baseLength: '0%',
            rearLength: '0%'
        },
        pivot: {
            backgroundColor: 'gray',
            radius: 6
        }

    }]
	}
}
getTodayTps(){
  this.getTodayTpsChart = {
  chart: {
    type: 'gauge',
    height: '300'
  },

  title: {
      text: 'Today Average TPS'
  },

  pane: {
      startAngle: -90,
      endAngle: 89.9,
      background: null,
      center: ['50%', '75%'],
      size: '85%'
  },
  credits:{
    enabled: false,
  },

  // the value axis
  yAxis: {
      min: 0,
      max: 1000,
      tickColor: Highcharts.defaultOptions.chart.backgroundColor || '#FFFFFF',
      labels: {
          distance: 20,
          style: {
              fontSize: '14px'
          }
      },
      lineWidth: 0,
       plotBands: [{
          from: 0,
          to: 5000,
          color: '#55BF3B', // green
          thickness: 20,
          borderRadius: '50%'
      }]
  },

  series: [{
      type: 'gauge',
      name: 'Today Average TPS',
      data: [this.todayTps],
      tooltip: {
          valueSuffix: ' TPS'
      },
      dataLabels: {
          format: '{y} TPS',
          borderWidth: 0,
          style: {
              fontSize: '16px'
          }
      },
      dial: {
          radius: '80%',
          backgroundColor: 'gray',
          baseWidth: 12,
          baseLength: '0%',
          rearLength: '0%'
      },
      pivot: {
          backgroundColor: 'gray',
          radius: 6
      }
  }]
}
}

getMonthTps(){
  this.getMonthTpsChart = {
  chart: {
    type: 'gauge',
    height: '300'
  },

  title: {
      text: 'Month Average TPS'
  },

  pane: {
      startAngle: -90,
      endAngle: 89.9,
      background: null,
      center: ['50%', '75%'],
      size: '85%'
  },
  credits:{
    enabled: false,
  },

  // the value axis
  yAxis: {
      min: 0,
      max: 1000,
      tickColor: Highcharts.defaultOptions.chart.backgroundColor || '#FFFFFF',
      labels: {
          distance: 20,
          style: {
              fontSize: '14px'
          }
      },
      lineWidth: 0,
       plotBands: [{
          from: 0,
          to: 5000,
          color: '#55BF3B', // green
          thickness: 20,
          borderRadius: '50%'
      }]
  },

  series: [{
    type: 'gauge',
      name: 'Month Average TPS',
      data: [this.monthTps],
      tooltip: {
          valueSuffix: ' TPS'
      },
      dataLabels: {
          format: '{y} TPS',
          borderWidth: 0,
          style: {
              fontSize: '16px'
          }
      },
      dial: {
          radius: '80%',
          backgroundColor: 'gray',
          baseWidth: 12,
          baseLength: '0%',
          rearLength: '0%'
      },
      pivot: {
          backgroundColor: 'gray',
          radius: 6
      }
  }]
}
}

getInstCurrentTps(){
  this.getInstCurrentTpsChart = {
    chart: {
        renderTo: 'container',
        type: 'column',
        marginRight: -10,
        options3d: {
            enabled: true,
            alpha: 15,
            beta: 5,
            depth: 50,
            viewDistance: 25
        },
        scrollablePlotArea: {
          minWidth: this.getColumnChartMinWidth()
        }
    },
    xAxis: {
        type: 'category',
        title:{
          text: 'Institution',
        }

    },
    yAxis: {
        title: {
            text: 'TPS',
        },
        type: 'logarithmic',
    },
    tooltip: {
        headerFormat: '<b>{point.key}</b><br>',
        pointFormat: 'TPS: {point.y}'
    },
    title: {
        text: 'Current TPS - by Institution',
        align: 'left'
    },
    legend: {
        enabled: false
    },
    credits:{
      enabled: false,
    },
    plotOptions: {
        column: {
            depth: 25
        }
    },
    series: [{
      type: 'column',
        //data: this.formatData(this.instCurrentTps),
        data: this.instCurrentTps,
        colorByPoint: true
    }]
}
}

getInstTodayTps(){
  this.getInstTodayTpsChart = {
    chart: {
        renderTo: 'container',
        type: 'column',
        marginRight: -10,
        options3d: {
            enabled: true,
            alpha: 15,
            beta: 5,
            depth: 50,
            viewDistance: 25
        },
        scrollablePlotArea: {
          minWidth: this.getColumnChartMinWidth()
        }
    },
    xAxis: {
        type: 'category',
        title:{
          text: 'Institution',
        }

    },
    yAxis: {
        title: {
            text: 'TPS',
        },
        type: 'logarithmic',
    },
    tooltip: {
        headerFormat: '<b>{point.key}</b><br>',
        pointFormat: 'TPS: {point.y}'
    },
    title: {
        text: 'Today Average TPS - by Institution',
        align: 'left'
    },
    legend: {
        enabled: false
    },
    credits:{
      enabled: false,
    },
    plotOptions: {
        column: {
            depth: 25
        }
    },
    series: [{
      type: 'column',
        data: this.instTodayTps,
        colorByPoint: true
    }]
}
}

getInstMonthTps(){
  this.getInstMonthTpsChart = {
    chart: {
        renderTo: 'container',
        type: 'column',
        marginRight: -10,
        options3d: {
            enabled: true,
            alpha: 15,
            beta: 5,
            depth: 50,
            viewDistance: 25
        },
        scrollablePlotArea: {
          minWidth: this.getColumnChartMinWidth()
        }
    },
    xAxis: {
        type: 'category',
        title:{
          text: 'Institution',
        }

    },
    yAxis: {
        title: {
            text: 'TPS',
        },
    },
    tooltip: {
        headerFormat: '<b>{point.key}</b><br>',
        pointFormat: 'TPS: {point.y}'
    },
    title: {
        text: 'Month Average TPS - by Institution',
        align: 'left'
    },
    legend: {
        enabled: false
    },
    credits:{
      enabled: false,
    },
    plotOptions: {
        column: {
            depth: 25
        }
    },
    series: [{
      type: 'column',
        data: this.instMonthTps,
        colorByPoint: true
    }]
}
}

  getColumnChartMinWidth(): number {
    const minWidth = 500;
    const calculatedWidth = this.instCurrentTps.length * 50;
    return calculatedWidth < minWidth ? minWidth : calculatedWidth;
  }

  sortInstDataByTps(data: any[]) {
    data.sort((a, b) => b[1] - a[1]);
  }
}
