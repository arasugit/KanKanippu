import { Component, Injector, OnInit,ChangeDetectorRef, ViewEncapsulation, OnDestroy, ViewChild, Inject, Optional } from '@angular/core';
import { Subject,takeUntil } from 'rxjs';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableService, GlobalsService, ResponseBase } from '../services';
import { WorkRequest } from '../ist-components';
import { DataTableEditableComponent, DataTableEditableDetailComponent } from '../components';
import { PageEvent } from '@angular/material/paginator';


@Component({
  selector: 'txn-stats-app',
  templateUrl: './txn-stats.component.html',
  styleUrls: ['./transaction.scss'],
  encapsulation: ViewEncapsulation.None
 })


export class TxnStatsComponent extends ListComponent implements OnInit, OnDestroy {
  private unsubscribe = new Subject();
  view: any[] =[300, 250];
  animations = true;
  screenType: any;
  autoRefreshTimer: any;
  dataLoaded:boolean=false;
  workRequest:WorkRequest;
  isDetailsTab:boolean=true;
  AcqDataList:any=[];
  txnDetailDataList:any=[];
  cardTitleTxn:any="";
  static terminalId:any;
  currentRequest: WorkRequest = new WorkRequest();
  @ViewChild('txntableDataTable', { static: false }) private txntableDataTable: DataTableEditableDetailComponent;
  constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker){
    super(injector);
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    this.adjustCriteria();
    this.retriveData();
  }

  ngAfterViewInit() {
    super.criteria=this.criteria;
    //super.search();
    this.setAutoRefreshInterval();
  }

  adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['isDetailReq']= 'false';
    this.criteria['ist_page_ctrl'] = '1';
    this.criteria['ist_total'] = 'Y';
    this.criteria['COMMAND']='query';
  }

  retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        workrequest => this.onGotRecords(workrequest),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      ).add(() => this.globals.hideLoadingBar());
  }

  FORM_TITLE = 'Top 25 Transacting Terminals';

   ngOnInit() {
    super.ngOnInit();
    console.log('screenType::'+this.screenType);
    if(this.screenType == 'TOP'){
      this.FORM_TITLE='Top 25 Transacting Terminals';
      this.exportFileName='Top 25 Transacting Terminals';
    }else  if(this.screenType == 'BOTTOM'){
      this.FORM_TITLE='Least 25 Transacting Terminals';
      this.exportFileName='Least 25 Transacting Terminals';
    }
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    //const rows = this.workRequest.collections['TXNS_TERMTOP_COL'].rows;
    if(this.workRequest.lastModified == -1){
      this.globals.setErrorMessage(' No Data found.');
    }

    this.AcqDataList = this.workRequest.collections['TXNS_TERMTOP_COL'].rows;
    if(this.workRequest!=null && this.workRequest !==undefined && this.workRequest.collections!=null && this.workRequest.collections['TRANS_DTL_COL'] !=null && this.workRequest.collections['TRANS_DTL_COL'].rows!=null){
      this.txnDetailDataList=this.workRequest.collections['TRANS_DTL_COL'].rows;
      this.txntableDataTable.dataSource.data=this.txnDetailDataList;
      DataTableEditableComponent.totalDTLRecords=this.workRequest.lastModified;
      this.txntableDataTable.length=this.workRequest.lastModified;
      DataTableEditableComponent.isTxnDetailScreen=true;
      this.dataLoaded=true;
      this.cdr.markForCheck();
    }
  }
  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }
  onCompleteGotRecords(): void {
  }
  getEntPermList(): any[] {
    this.entObjectId = 'TXNTP_REQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

  onSelect(event) {
    console.log(event);
  }

  gatherDataChanged(event:any):void{
    console.log(this.dataService.data);
 }

  setT21Tags(): void {
    this.requestTypeId = 'TXNSTP_REQ';
    this.metaDataId = 'TXNSTP_REQ';
    this.tabId = 'TXNS_TERMTOP_TAB';
    this.sectionId = 'TXNS_TERMTOP_SEC';
    this.collectionId = 'TXNS_TERMTOP_COL';
  }

  ngOnDestroy(): void {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
  }
  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }
  onItemClick(selectedItem: any) {
    super.criteria=this.criteria;
    //super.search();
    this.criteria['isDetailReq']= 'true';
    this.criteria['eventName']= selectedItem.terminalId;
    TxnStatsComponent.terminalId = selectedItem.terminalId;
    GlobalsService.eventName = selectedItem.terminalId;
    this.retriveData();
    this.isDetailsTab=false;
    this.cardTitleTxn ="Transaction Details - Acq "
    this.txntableDataTable.dataSource.data=this.txnDetailDataList;

  }
  totalCellClicked(event) {
    // console.log('treeCellClicked', event);
    if (event.row !== undefined) {
    }
  }

   // called for data table pagination
 more(pageEvent: PageEvent): void {
  console.log('Trnasaction Stats more button clicked : ' + pageEvent.pageIndex + pageEvent.length);
  this.globals.showLoadingBar();
  // + pageEvent.pageSize);
  this.criteria[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
  this.criteria['ist_total'] = 'Y';
  //this.adjustCriteria();
  this.criteria['isDetailReq']= 'true';
  this.criteria['terminalId']=   TxnStatsComponent.terminalId;
  this.criteria['eventName']=   GlobalsService.eventName;
  this.retriveData();
}
}
