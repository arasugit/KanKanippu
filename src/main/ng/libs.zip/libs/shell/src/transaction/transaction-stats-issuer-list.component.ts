import {Component, ViewEncapsulation, OnInit, OnDestroy, Optional, Inject, Injector, EventEmitter, Output,ChangeDetectorRef} from '@angular/core';
import { Subject } from 'rxjs';
import { MON_ATM_COLOR_SETS } from '../home/ngx-charts-color-sets';
import { TransactionDTO } from './transactiondto';
import { StringMap } from '../common';
import { ListComponent } from '../components';
import { InstService } from '../services/inst.service';
//import { ColorHelper,Color,LegendPosition,LegendType,ScaleType } from '@swimlane/ngx-charts';
@Component({
  selector: 'transaction-stats-issuer-list',
  templateUrl: './transaction-stats-issuer-list.component.html',
  styleUrls: ['./transaction.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TransactionStatsIssuerListComponent   extends ListComponent implements OnInit, OnDestroy {
  private unsubscribe = new Subject();
  chartType :any = 'pie-chart';
  view: any[] = [300, 254];
  viewDownBySite: any[] = [350, 350];
  animations:boolean   = true;
  showLegend:boolean   = true;
  legendTitle: any = 'Legend';
  doughnut:boolean   = true;
  arcWidth: any = 0.75;
  screenType: any;
  dataLoaded:boolean=false;
  public instService: InstService;
  // public colors: ColorHelper;
  cardTitle:any;
  cardTitleKPI:any;
  public transactionDataIssuer :any[];
  public transactionIssuerPercent :any[];
  public legendValues:string[]=[];
  public legendValuespercent:string[]=[];
  // readonly LegendPosition = LegendPosition;
  // readonly LegendType = LegendType;
  private cdr: ChangeDetectorRef;
  atmColorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufPieChartLightColorScheme']
  };
  siteColorScheme :any = {
    domain: MON_ATM_COLOR_SETS['rufPieChartLightColorScheme']
  };

  constructor( @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker, injector: Injector,@Optional() @Inject('Label') private label){
    super(injector);
    this.instService = injector.get(InstService);
    }

ngAfterViewChecked() {
}
  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }
  ngOnInit() {
    super.ngOnInit();
    this.retriveData();
    this.setAutoRefreshRetriveDataInterval();
   // console.log('TITLE::'+label);
 }


 retriveData() {
  this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    console.log('screenType::'+this.screenType);
    let dbParamiss: StringMap = {};
    dbParamiss['screenType'] = this.screenType;
    dbParamiss['type'] = 'ISSUER';
    this.instService.getDatabaseRecords("TRANS_STATS_LIST_PROVIDER", dbParamiss).subscribe((x: any[]) => { this.updateTransactionIssuer(x); });

    if(this.screenType == 'TRANS_STATS_ISSUER'){
      this.cardTitle='Transaction Stats - 5 Mins';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'HOURLY'){
      this.cardTitle='Transaction Stats - Hourly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'DAILY'){
      this.cardTitle='Transaction Stats - Daily';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'WEEKLY'){
      this.cardTitle='Transaction Stats - Weekly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'MONTHLY'){
      this.cardTitle='Transaction Stats - Monthly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'YEARLY'){
      this.cardTitle='Transaction Stats - Yearly';
      this.cardTitleKPI='Percentage KPIs';
    }
 }

 updateTransactionIssuer(result: any[]): void {
   //let approvalCnt=0;
   //let declineCnt=0;

   if (result !== undefined && result !== null && result.length > 0) {
     console.log('Tras STATS ISSUER::'+result.length);
     let approvalCnt=0;
     let declineCnt=0;
     let reversalCnt=0;
     let totalCnt=0;
     for (let index = 0; index < result.length; index++) {
       const element = result[index];
         approvalCnt=+approvalCnt+ +element[2];
         declineCnt=+declineCnt+ +element[3];
         reversalCnt=+reversalCnt+ +element[4];

     }
     let statusData:any = [];
      let dto:  TransactionDTO;
      let dto2:  TransactionDTO;
      let dto3:  TransactionDTO;
      let dtolist :TransactionDTO[]=[];

      totalCnt=+approvalCnt + +declineCnt + +reversalCnt;
     console.log(approvalCnt + '   :::'+ declineCnt+' ::::::: '+reversalCnt);
     dto = new TransactionDTO("Approval",approvalCnt.toString());
     dto2  = new TransactionDTO("Decline",declineCnt.toString());
     dto3  = new TransactionDTO("Reversal",reversalCnt.toString());
     dtolist.push(dto);
     dtolist.push(dto2);
     dtolist.push(dto3);
     this.transactionDataIssuer=JSON.parse(JSON.stringify(dtolist));
     //
     statusData.push({name: "Approval",value: approvalCnt}) ;
     statusData.push({name: "Decline",value: declineCnt});
     statusData.push({name: "Reversal",value: reversalCnt});

     this.legendValues.push("Approval"+'-'+approvalCnt) ;
     this.legendValues.push("Decline"+'-'+declineCnt);
     this.legendValues.push("Reversal"+'-'+reversalCnt);
     this.legendValues.push("Total"+'-'+totalCnt);
      // this.colors = new ColorHelper(this.atmColorScheme as Color, ScaleType.Ordinal, this.legendValues, this.atmColorScheme);
     this.dataLoaded=true;
     let approvalpercent= ((approvalCnt/totalCnt)*100).toFixed(2);
     let declinepercent=((declineCnt/totalCnt)*100).toFixed(2);
     let reversalpercent=((reversalCnt/totalCnt)*100).toFixed(2);
     let statusDatapercent:any = [];
     let appperdto:  TransactionDTO;
     let delclineperdto:  TransactionDTO;
     let revperdto:  TransactionDTO;
     let dtolistpercent :TransactionDTO[]=[];
     appperdto = new TransactionDTO("Approval %",approvalpercent.toString());
     delclineperdto  = new TransactionDTO("Decline %",declinepercent.toString());
     revperdto  = new TransactionDTO("Reversal %",reversalpercent.toString());
     dtolistpercent.push(appperdto);
     dtolistpercent.push(delclineperdto);
     dtolistpercent.push(revperdto);
     this.transactionIssuerPercent=JSON.parse(JSON.stringify(dtolistpercent));
     //
     statusDatapercent.push({name: "Approval %",value: approvalpercent}) ;
     statusDatapercent.push({name: "Decline %",value: declinepercent});
     statusDatapercent.push({name: "Reversal %",value: revperdto});

     this.legendValuespercent.push("Approval %"+'-'+approvalpercent) ;
     this.legendValuespercent.push("Decline %"+'-'+declinepercent);
     this.legendValuespercent.push("Reversal %"+'-'+reversalpercent);
     //this.legendValuespercent.push("Total"+'-'+totalCnt);

   }
 }
 setT21Tags(): void {
  this.requestTypeId = 'ATMAVL_REQ';
  this.metaDataId = 'ATMAVL_REQ';
  this.tabId = 'ATMAVL_TAB';
  this.sectionId = 'ATMAVL_SEC';
  this.collectionId = 'ATMAVL_COL';
}
 onSelect(data:any): void {
  //console.log('Item clicked', JSON.parse(JSON.stringify(data)));
}

onActivate(data:any): void {
  //console.log('Activate', JSON.parse(JSON.stringify(data)));
}

onDeactivate(data:any): void {
  //console.log('Deactivate', JSON.parse(JSON.stringify(data)));
}

  getColor(status){
    return status === 'Released' ? 'success' : (status === 'Unreleased' ? 'info' : 'warn' );
  }


  ngOnDestroy() {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
  }
}
