import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SuccessfulTxnsComponent } from './success-txn.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule } from '@ruf/shell';

export const successfulTxnsData: MonitorComponentData = {
  title: 'Switch Transacting Terminals List',
  icon: 'table',
  examples: {  
      'TXNSSC_REQ': {
          label: 'Onus Transactions Count',
          title: 'Onus Transactions Count',
          description: 'Onus Transactions Count',
          rufId: 'onus_txns_count',
          component: SuccessfulTxnsComponent
      },
      'ACQUIRING': {
        label: 'Acquiring Transactions Count',
        title: 'Acquiring Transactions Count',
        description: 'Acquiring Transactions Count',
        rufId: 'acq_txns_count',
        component: SuccessfulTxnsComponent
    },
      'ISSUING': {
        label: 'Issuing Transactions Count',
        title: 'Issuing Transactions Count',
        description: 'Issuing Transactions Count',
        rufId: 'iss_txns_count',
        component: SuccessfulTxnsComponent
    }
  }
};

@NgModule({ 
    imports :[ 
    CommonModule,
    FormsModule,
    ReactiveFormsModule,  
    MatTableModule, 
    MatCardModule,  
    RufCommonModule,   
    RufCardModule, 
    ISTComponentModule
  ], 
  declarations: [SuccessfulTxnsComponent],
  providers: [{ provide: MON_TOOL, useValue: successfulTxnsData }],
  exports:[],
})
export class SuccessfulTxnsModule {}
