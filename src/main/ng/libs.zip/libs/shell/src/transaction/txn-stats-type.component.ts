import { Component, Injector, OnInit,ChangeDetectorRef, ViewEncapsulation, OnDestroy, ViewChild, Inject, Optional } from '@angular/core';
import { Subject,takeUntil } from 'rxjs';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableService, GlobalsService, ResponseBase } from '../services';
import { WorkRequest } from '../ist-components';
import { AbstractDataTableComponent, DataTableEditableComponent, DataTableEditableDetailComponent, T21Base } from '../components';
import { PageEvent } from '@angular/material/paginator';
import { TransactionDTO } from './transactiondto';
import { TransactionMultiDTO } from './transactionmultidto';
import { MON_ATM_COLOR_SETS } from '../home';
import { TransactionStatsDetailsComponent } from './transaction-stats-details-list.component';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import HighchartsMore from 'highcharts/highcharts-more';
HighchartsMore(Highcharts);
import HighchartsSolidGauge from 'highcharts/modules/solid-gauge';
HighchartsSolidGauge(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);
@Component({
  selector: 'txn-stats-app',
  templateUrl: './txn-stats-type.component.html',
  styleUrls: ['./transaction.scss'],
  encapsulation: ViewEncapsulation.None
 })


export class TxnStatsTypeComponent extends ListComponent implements OnInit, OnDestroy {
  private unsubscribe = new Subject();
  chartType :any = 'pie-chart';
  workRequest:WorkRequest;
  view: any[] = [600, 300];
  pieChartView: any[] = [350, 300];
  animations:boolean   = true;
  showLegend:boolean   = true;
  legendTitle: any = 'Legend';
  legendWidth:number=500;
  legendHeight:number=20;
  doughnut = true;
  arcWidth = 0.50;
  screenType: any;
  dataLoaded:boolean=false;
  // public colors: ColorHelper;
  cardTitle:any;
  cardTitleKPI:any;
  cardTitleTxn:any="Acq Trans Details";
  public transactionDataAcq :any[];
  public transactionAcqPercent :any[];
  approvalCnt=0;
  declineCnt=0;
  reversalCnt=0;
  public legendValues:string[]=[];
  public legendValuesPercent:string[]=[];
  // readonly LegendPosition = LegendPosition;
  // readonly LegendType = LegendType;
  // public legendColors: ColorHelper;
  // public transPerLegendColors: ColorHelper;
  public autoRefreshRetriveDataTimer: any;
  currentRequest: WorkRequest = new WorkRequest();
  transStatsRecords: any[] = [];
  isDetailsTab:boolean=true;
  AcqDataList:any=[];
  txnDetailDataList:any=[];
  expandEsc = true;
  isLoading = false;
  loadingMessage = '';
  static txnSrcAcq:any;
  static eventName:any;
  yAxisTicksArr=[50,100,150];
  columnAcqData: { name: string; data: number[]; }[];
  columnDataAcqCategory: any[] = [];
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options;
  @ViewChild('firstUpdateField', { static: false })
  firstUpdateField: T21Base;
  @ViewChild('txntableDataTable', { static: false }) private txntableDataTable: DataTableEditableComponent;
  @ViewChild('tableData', { static: false }) private tableDataTable: DataTableEditableDetailComponent;
  colorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };
  perColorScheme :any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };
  manuData: any[];
  yScaleMaxValue: number;
  constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker){
    super(injector);
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    this.adjustCriteria();
    this.retriveData();
  }

  ngAfterViewInit() {
    super.criteria=this.criteria;
    //super.search();
    this.setAutoRefreshInterval();
  }

  adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['isDetailReq']= 'false';
    this.criteria['ist_page_ctrl'] = '1';
    this.criteria['ist_total'] = 'Y';
    this.criteria['COMMAND']='query';
  }

  retriveData():void{
    console.log('Called retrieveData ...');
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
   // console.log('going to call table services retrieveData ...');
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        workrequest => this.onGotRecords(workrequest),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }

  FORM_TITLE = '';

   ngOnInit() {
    super.ngOnInit();
    console.log('screenType::'+this.screenType);
    this.exportFileName='Transaction_Stats_by_Txn_Type';
    this.cardTitle='Transaction Stats by Transaction Type';
    if(this.screenType == 'TXNTYPEREQ' || this.screenType == 'TXNSTS_REQ'){
      this.cardTitle='Transaction Stats by Transaction Type - 5 Mins';
      this.exportFileName='Transaction Stats by Transaction Type - 5 Mins';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'HOURLY'){
      this.cardTitle='Transaction Stats by Transaction Type - Hourly';
      this.exportFileName='Transaction Stats by Transaction Type - Hourly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'DAILY'){
      this.cardTitle='Transaction Stats by Transaction Type - Daily';
      this.exportFileName='Transaction Stats by Transaction Type - Daily';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'WEEKLY'){
      this.cardTitle='Transaction Stats by Transaction Type - Weekly';
      this.exportFileName='Transaction Stats by Transaction Type - Weekly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'MONTHLY'){
      this.cardTitle='Transaction Stats by Transaction Type - Monthly';
      this.exportFileName='Transaction Stats by Transaction Type - Monthly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'YEARLY'){
      this.cardTitle='Transaction Stats by Transaction Type - Yearly';
      this.exportFileName='Transaction Stats by Transaction Type - Yearly';
      this.cardTitleKPI='Percentage KPIs';
    }
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    const rows = this.workRequest.collections['TXNTYPE_COL'].rows;
    this.AcqDataList = this.workRequest.collections['TXNTYPE_COL'].rows;
    if(this.workRequest!=null && this.workRequest !==undefined && this.workRequest.collections!=null && this.workRequest.collections['TRANS_DTL_COL'] !=null && this.workRequest.collections['TRANS_DTL_COL'].rows!=null){
      this.txnDetailDataList=this.workRequest.collections['TRANS_DTL_COL'].rows;
      this.txntableDataTable.dataSource.data=this.txnDetailDataList;
      DataTableEditableComponent.totalDTLRecords=this.workRequest.lastModified;
      this.txntableDataTable.length=this.workRequest.lastModified;
      DataTableEditableComponent.isTxnDetailScreen=true;
    }
      if(rows!=null && rows!=undefined && rows.length>0){
        let declineCnt=0;
        let reversalCnt=0;
        let totalCnt=0;
        let approvalCnt=0;
        let statusData:any = [];
         let dto:  TransactionDTO;
         let dto2:  TransactionDTO;
         let dto3:  TransactionDTO;
         let dtolist :TransactionDTO[];
         let multidtolist :TransactionMultiDTO[]=[];
         let multidto:  TransactionMultiDTO;
         rows.forEach((c,index) =>{
          approvalCnt=c.totalApprovalCnt > 10000 ? +c.totalApprovalCnt/1000:+c.totalApprovalCnt;
          declineCnt=c.totalDeclineCnt > 10000 ? +c.totalDeclineCnt/1000:+c.totalDeclineCnt;
          reversalCnt=c.totalReversalCnt > 10000 ? +c.totalReversalCnt/1000:+c.totalReversalCnt;
         totalCnt=+approvalCnt + +declineCnt + +reversalCnt;
         dtolist =[];
        dto = new TransactionDTO("Approval",c.totalApprovalCnt.toString());
        dto2  = new TransactionDTO("Decline",c.totalDeclineCnt.toString());
        dto3  = new TransactionDTO("Reversal",c.totalReversalCnt.toString());
        dtolist.push(dto);
        dtolist.push(dto2);
        dtolist.push(dto3);

        statusData.push({name: "Approval",value: c.totalApprovalCnt}) ;
        statusData.push({name: "Decline",value: c.totalDeclineCnt});
        statusData.push({name: "Reversal",value: c.totalReversalCnt});
        multidto=new TransactionMultiDTO(""+c.processingCode+"-"+c.processingCodeDesc,dtolist);
       multidtolist.push(multidto);

      })
        this.transactionDataAcq=JSON.parse(JSON.stringify(multidtolist));
        console.log(JSON.stringify(multidtolist));
        this.getTransactionBarChart();
        approvalCnt=0;
        declineCnt=0;
        reversalCnt=0;

        rows.forEach(c =>{
          approvalCnt=+approvalCnt+ +c.totalApprovalCnt;
          declineCnt=+declineCnt+ +c.totalDeclineCnt;
          reversalCnt=+reversalCnt+ +c.totalReversalCnt;
          totalCnt=+approvalCnt + +declineCnt + +reversalCnt;
       })

       this.adjustChartViewWidth(rows.length);

      //  Legend for bar chart
       this.legendValues.push("Approval"+'-'+approvalCnt);
       this.legendValues.push("Decline"+'-'+declineCnt);
       this.legendValues.push("Reversal"+'-'+reversalCnt);

      //  this.legendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.legendValues, this.colorScheme);
      //  this.transPerLegendColors = new ColorHelper(this.perColorScheme as Color, ScaleType.Ordinal, this.legendValues, this.perColorScheme);

        let approvalpercent= ((approvalCnt/totalCnt)*100).toFixed(2);
        let declinepercent=((declineCnt/totalCnt)*100).toFixed(2);
        let reversalpercent=((reversalCnt/totalCnt)*100).toFixed(2);
        let statusDatapercent:any = [];
        let appperdto:  TransactionDTO;
        let delclineperdto:  TransactionDTO;
        let revperdto:  TransactionDTO;
        let dtolistpercent :TransactionDTO[]=[];
        appperdto = new TransactionDTO("Approval % "+approvalpercent.toString(),approvalpercent.toString());
        delclineperdto  = new TransactionDTO("Decline % "+declinepercent.toString(),declinepercent.toString());
        revperdto  = new TransactionDTO("Reversal % "+reversalpercent.toString(),reversalpercent.toString());

        dtolistpercent.push(appperdto);
        dtolistpercent.push(delclineperdto);
        dtolistpercent.push(revperdto);
        this.transactionAcqPercent=JSON.parse(JSON.stringify(dtolistpercent));

        statusDatapercent.push({name: "Approval %",value: approvalpercent}) ;
        statusDatapercent.push({name: "Decline %",value: declinepercent});
        statusDatapercent.push({name: "Reversal %",value: revperdto});
        this.legendValuesPercent.push("Approval %"+'-'+approvalpercent) ;
        this.legendValuesPercent.push("Decline %"+'-'+declinepercent);
        this.legendValuesPercent.push("Reversal %"+'-'+reversalpercent);

        // this.legendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.legendValues, this.colorScheme);
        // this.transPerLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.legendValuesPercent, this.perColorScheme);

        this.tableDataTable.dataSource.data=this.AcqDataList;
        this.dataLoaded=true;
        this.cdr.markForCheck();

        }else{
          this.dataLoaded=false;
        }
        this.globals.hideLoadingBar();
  }
  
  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  getTransactionBarChart(){
    let apprData:any[] =[];
    let decData:any[] =[];
    let revData:any[] =[];
    this.columnDataAcqCategory = [];
    this.transactionDataAcq.forEach(res=>{
    this.columnDataAcqCategory.push(res.name);
      res.series.forEach(element => {
        if(element.name === 'Approval'){
          apprData.push(parseInt(element.value));
        }
        if(element.name === 'Decline'){
          decData.push(parseInt(element.value));
        }
        if(element.name === 'Reversal'){
          revData.push(parseInt(element.value));
        }
      });
    })
    this.columnAcqData = [
      { name:'Approval',
      data:apprData
    },
    { name:'Decline',
      data:decData
    },
    { name:'Reversal',
      data:revData
    },
  ]
  this.chartOptions= {
    chart: {
      type: 'column',
      scrollablePlotArea: {
        minWidth: 4000,
        opacity: 0,
        scrollPositionX: 0
      }
  },
  credits:{
    enabled: false,
  },
  title: {
      text: this.cardTitle,
      align: 'left'
  },
  // subtitle: {
  //     text:
  //         'Source: <a target="_blank" ' ,
  //     align: 'left'
  // },
  xAxis: {
      categories: this.columnDataAcqCategory,
      crosshair: true,
      accessibility: {
          description: 'Countries'
      },
  },
  yAxis: {
      min: 0,
      // max:50000,
      title: {
          // text: '1000 metric tons (MT)'
      },
    //   stackLabels: {
    //     enabled: true
    // }
  },

  tooltip: {
      // valueSuffix: ' (1000 MT)'
  },
  legend: {
    labelFormatter: function(){
      const series: any = this as Highcharts.Series;
      const seriesSum = (series.yData || []).reduce((sum,point)=> sum+(point || 0),0);
      return this.name+'(Total:'+seriesSum+')';
    }
},
  plotOptions: {
      column: {

          pointWidth:20,
          borderWidth: 1,
          dataLabels: {
              enabled: true
          }
      },
      series: {
        cursor: 'pointer',
        point: {
            events: {
                click:  (event)=> {
                  this.onBarSliceSelect({
                    x:event.point.x,
                    value:event.point.y,
                    name: event.point.series.name,
                    label: event.point.series.name,
                    series:event.point.category
                  });
                }
              }
        }
    },
  },
  series: this.columnAcqData as any
}
  }
  onCompleteGotRecords(): void {
  }
  getEntPermList(): any[] {
    this.entObjectId = 'TXNTYPEREQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

  onSelect(event) {
    console.log(event);
  }

  gatherDataChanged(event:any):void{
    console.log(this.dataService.data);
 }
 adjustChartViewWidth(rowCount: number){
  if(rowCount > 5)
    this.view=[rowCount * 120, 300];
}


  setT21Tags(): void {
    this.requestTypeId = 'TXNTYPEREQ';
    this.metaDataId = 'TXNTYPEREQ';
    this.tabId = 'TXNTYPE_TAB';
    this.sectionId = 'TXNTYPE_SEC';
    this.collectionId = 'TXNTYPE_COL';
  }

  ngOnDestroy(): void {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
    this.txntableDataTable.paginator.length=0;
    this.txntableDataTable.paginator.pageSizeOptions=null;
    AbstractDataTableComponent.totalDTLRecords=0;
    this.txntableDataTable.totalDisplayingRecords=0;
  }
  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  onBarSliceSelect(event:any){
    this.globals.showLoadingBar();
    this.adjustCriteria();
    this.criteria['isDetailReq']= 'true';
    this.criteria['eventName']= event.name;
    this.criteria['txnSrcAcq']= event.series;
    console.log('event.name ::'+event.name);
    console.log('event.series ::'+event.series);
    console.log('event.value ::'+event.value);
    console.log('event.label ::'+event.label);
    TransactionStatsDetailsComponent.eventName=event.name;
    TransactionStatsDetailsComponent.txnSrcAcq=event.series;
    GlobalsService.eventName=event.name;
    GlobalsService.txnSrcAcq=event.series;

    this.retriveData();
    var str = event.label;
    var index = str.indexOf( " " );
    var splitted = index > 0 ? str.slice(0,index):str.slice(0);
    this.cardTitleTxn ="Transaction Details "+event.series +" for  "+splitted;
    this.isDetailsTab=false;
    this.setFocusToFirstUpdateField();
  }

   // called for data table pagination
   more(pageEvent: PageEvent): void {
    this.globals.showLoadingBar();
    this.criteria[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
    this.criteria['ist_total'] = 'Y';
    this.criteria['isDetailReq']= 'true';
    this.criteria['eventName']=   TransactionStatsDetailsComponent.eventName;
    this.criteria['txnSrcAcq']= TransactionStatsDetailsComponent.txnSrcAcq;
    this.retriveData();
  }

}
