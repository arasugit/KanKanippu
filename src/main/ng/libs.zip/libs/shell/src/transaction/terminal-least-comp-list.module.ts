import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TerminalLeastCompComponent } from './terminal-least-comp-list.component';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { RufCommonModule } from '@ruf/shell';
import { RufCardModule } from '@ruf/shell';
export const terminalLeastCompData: MonitorComponentData = {
  title: 'Least Terminal Comp Details',
  icon: 'table',
  examples: {
      'TXNTL_REQ': {
          label: 'Least Terminal - Daily',
          title: 'Least Terminal - Daily',
          description: 'Least Terminal - Daily',
          rufId: 'mon_ter_least_comp',
          component: TerminalLeastCompComponent
      },
  'WEEKLY': {
    label: 'Least Terminal - Weekly',
    title: 'Least Terminal - Weekly',
    description: 'Least Terminal - Weekly',
    rufId: 'mon_ter_least_comp_weekly',

    component: TerminalLeastCompComponent
},
'MONTHLY': {
  label: 'Least Terminal - Monthly',
  title: 'Least Terminal - Monthly',
  description: 'Least Terminal - MONTHLY',
  rufId: 'mon_ter_Least_comp_monthly',

  component: TerminalLeastCompComponent
}
  },


};
@NgModule({
  imports :[
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  MatTableModule,
  MatCardModule,
  RufCommonModule,
  RufCardModule,
  ISTComponentModule
],
declarations: [TerminalLeastCompComponent],
providers: [{ provide: MON_TOOL, useValue: terminalLeastCompData }],
exports:[],
})
export class TerminalLeastCompModule { }
