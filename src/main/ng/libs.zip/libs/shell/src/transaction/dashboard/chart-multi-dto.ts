import { HighChartDto } from "../../cortex/chart-dto";
import { ChartDTO } from "./chart-dto";

export class ChartMultiDTO {
  name: string;
  series: HighChartDto[];

  constructor(name: string, value: HighChartDto[]) {
    this.name = name;
    this.series = value;
  }

  setSeries(chartDtoSeries: HighChartDto[]) {
    this.series = chartDtoSeries;
  }
}
