// $Id$
import {ResponseBase} from '../../services/response-base';
export class UIMetadata extends ResponseBase {

  remoteClass = 'com.efunds.t21.services.vo.UIMetaData';
  fields: any[] = [];
  collection: any[] = [];
  total = -1;
  requestTypeId = '';
  flyOverHelp = '';
  label = '';
  requestGroupId = '';
  useGroupHandler = '';
  formType = '';
  tabs: UIMetaTab[] = [];
  sections: UIMetaSection[] = [];
  choiceGroups: any[] = [];
  states: any[] = [];
  stateGroups: any[] = [];
  lastFilterOptions: any[] = [];

  public get tag(): string {
    return this.requestTypeId;
   }
}
export class UIMetaTab {
  remoteClass = 'com.efunds.t21.services.vo.UIMetaTab';
  label = '';
  flyOverHelp = '';
  isRequiredForSubmit: Boolean = false;
  tabId = '';
  precedence = '';
  displayOrder = 0;
  sections: UIMetaSection[] = [];
  public get tag() {
    return this.tabId;
   }
}
export class UIMetaSection {
  remoteClass = 'com.efunds.t21.services.vo.UIMetaSection';
  label = '';
  flyOverHelp = '';
  sectionId = '';
  parentSectionId = '';
  displayOrder = 0;
  styleName = '';
  containerType = '';
  requestTypeId = '';
  isExpandable: Boolean = false;
  colGroupProperties = '';
  sectionType = '';
  collections: UIMetaCollection[] = [];
  fields: UIMetaField[] = [];
  subsections: UIMetaSection[] = [];

  public get tag() {
    return this.sectionId;
  }
}
export class UIMetaField {
  public static remoteClassName = 'com.efunds.t21.services.vo.UIMetaField';
  remoteClass = UIMetaField.remoteClassName;
  label = '';
  flyOverHelp = '';
  resetWarning = '';
  isRequiredForSave: Boolean = false;
  maxLength = 0;
  mask = '';
  smartField = '';
  renderer = '';
  editType = '';
  substringStart = 0;
  substringLength = 0;
  rulesEngineTag = '';
  usedByBizRules = '';
  minLength = 0;
  upshift: Boolean = false;
  specialUsage: Boolean = false;
  restrict = '';
  tag = '';
  accessProfileId = '';
  choiceGroupId = '';
  shortLabel = '';
  postLabel = '';
  parent = '';
  parentValue = '';
  optional: Boolean = false;
  defaultValue = '';
  rowDisplayOrder = 0;
  colDisplayOrder = 0;
  fieldId = 0;
  collectionId = '';
  isRequiredPerParentRules: Boolean = false;
  trackOriginal: Boolean = false;
  sortKey = '';
  height = 0;
  width = 0;
  dbTable = '';
  dbColumn = '';
  colGroup = 0;
  displayChoiceValue: Boolean = false;
  listItemRenderer;
  linkRequestTypeId;
}
export class UIMetaCollection {
  remoteClass = 'com.efunds.t21.services.vo.UIMetaCollection';
  label = '';
  flyOverHelp = '';
  collectionId = '';
  sequenceNbr = '';
  editable: Boolean = false;
  fields: UIMetaField[] = [];

  public get tag() {
    return this.collectionId; }
}
