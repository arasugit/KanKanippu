import { DatePipe, DecimalPipe } from '@angular/common';
import { StringUtil } from './ist-string-util';

export class CustomFormatter {

  static decimalPipe: DecimalPipe = new DecimalPipe('en-US');
  static datePipe: DatePipe = new DatePipe('en-US');
  public static formatAmount(value: string, fractionDigit?: String): any {
    if (value === undefined || value === '' || value === null) {
      return '';
    }
    // Adding try catch here as value to be transformed can be anything...
    try {
      const digitInfo = (fractionDigit) ? '1.2-' + fractionDigit : '1.2-2';
      const formattedText = this.decimalPipe.transform(value, digitInfo);
      return formattedText ? formattedText : '';
    } catch (e) { }
    return '';
  }
  public static formatToLocaleAmount(value: string, locale: string, defaultDigit): any {
    if (value === undefined || value === '' || value === null) {
      return '';
    }
    // This method will convert the value to the respective locale format.
    // We are just setting the default fraction digits of a locale which was fetched from the backend
    try {
      const formattedText = value !== undefined && value !== null && value !== '' && value !== 'null' ?
        Number(value).toLocaleString(locale, {
          minimumFractionDigits: defaultDigit,
          maximumFractionDigits: defaultDigit
        }) : '';
      return formattedText ? formattedText : '';
    } catch (e) { }
    return '';
  }

  public static formatDate(value: any, dateFormat: string): Date {
    if (value === undefined || value === '' || value === null) {
      return null;
    }
    // Adding try catch here as value to be transformed can be anything...
    try {
      const formattedText = this.formatDateString(value, dateFormat);
      if (formattedText === '') {
        return null;
      }
      const tempDate: Date = new Date(formattedText);
      return tempDate;
    } catch (e) { }
    return null;
  }

  public static formatDateString(value: any, dateFormat: string): any {
    if (value === undefined || value === '' || value === null) {
      return null;
    }

    // Adding try catch here as value to be transformed can be anything...
    try {
      const formattedText = this.datePipe.transform(value, dateFormat); // the date is getting converted to the passed dateformat
      return formattedText;
    } catch (e) { }
    return null;
  }
  public static formatDateWithTimestampString(value: any, dateFormat = 'MM/dd/yyyy'): any {
    if (value === undefined || value === '' || value === null) {
      return null;
    }
    // Adding try catch here as value to be transformed can be anything...
    try {
      if (!(dateFormat.indexOf("hh") > 0 || dateFormat.indexOf("HH")>0))
              dateFormat = dateFormat + " HH:mm:ss"; // add timeformat if it is not there in the mask
      dateFormat = dateFormat.replace("hh","HH");
      const formattedText = this.datePipe.transform(value, dateFormat); // this logic need to be changed for localization

      return formattedText;
    } catch (e) { }
    return null;
  }

  public static serverFormatDate(value: any, dateFormat: string): any {
    if (value === undefined || value === '' || value === null) {
      return '';
    }
    // Adding try catch here as value to be transformed can be anything...
    try {
      const formattedText = this.datePipe.transform(value, dateFormat); // serverFormat should not be changed
      return formattedText ? formattedText : '';
    } catch (e) {}
    return '';
  }

  public static formatHHMMSS(value: any): any {
    if (value === undefined || value === '' || value === null) {
      return '';
    }
    let strValue = String(value).trim();
    const lengthTime: number = strValue.length;
    let formattedText = value;
    switch (lengthTime) {
      case 1:
        formattedText = ''; break;
      case 4:
        formattedText = '00' + ':' + strValue.substr(0, 2) + ':' + strValue.substr(2, 2); break;
      case 5:
        strValue = '0' + strValue;
        formattedText = strValue.substr(0, 2) + ':' + strValue.substr(2, 2) + ':' + strValue.substr(4, 2); break;
      case 6:
        formattedText = strValue.substr(0, 2) + ':' + strValue.substr(2, 2) + ':' + strValue.substr(4, 2); break;
    }
    return formattedText;
  }

  public static getAmountFromExp(amt: string, exp: string, toDb: boolean, decimalSeparator: string,
    groupSeparator: string, defFractionDigits: any, currentLanguage: string): string {
    // toDB -- true - to send the data to database
    // toDB -- false - to display the data to the front
    console.log(' custom formatter Amt received ', amt, exp);
    //let strVal: string =  amt;
    amt = amt.replace(new RegExp(',', 'g'), '');
    console.log(' custom formatter Amt before calculation ', amt);

    if (StringUtil.isEmpty(amt) || StringUtil.isEmpty(exp))
      return '';

    let intExp: number = Number.parseInt(exp);
    let floatAmt: number = Number.parseFloat(amt);

    let strExp: string = "1";
    for (let i = 0; i < intExp; i++) {
      strExp += "0";
    }
    let intStrExp: number = Number.parseInt(strExp);
    let returnAmt: number = 0;

    if (toDb)
      returnAmt = floatAmt * intStrExp;
    else
      returnAmt = floatAmt / intStrExp;
    returnAmt = Number.parseFloat("" + returnAmt);

    let strVal = this.formatToLocale(returnAmt, decimalSeparator, groupSeparator, defFractionDigits, currentLanguage, intExp);

    return strVal;

  }

  public static formatToLocale(value, decimalSeparator, groupSeparator, defFractionDigits, currentLanguage, decimalDigit?) {
    const nativeValue = this.formatToNative(value, decimalSeparator, groupSeparator);
    const decimalVal = (decimalDigit) ? decimalDigit : defFractionDigits;
    try {
      const formattedText = nativeValue !== undefined && nativeValue !== null && nativeValue !== '' && nativeValue !== 'null' ?
        Number(nativeValue).toLocaleString(currentLanguage, decimalVal) : 0;
      return formattedText ? formattedText : '';
    } catch (e) { }
  }
  public static formatToNative(value, decimalSeparator, groupSeparator) {
    // This method will replace the group and decimal separator and it will return just plain number(like 12323123.12)
    // irrespective of the currenct locale.
    let strVal: string = value.toString();
    strVal = strVal.replace(new RegExp('\\' + groupSeparator, 'g'), '').replace(new RegExp('\\' + decimalSeparator, 'g'), '.');
    return strVal;
  }

  public static changeMask(mask: string): string {
    let maskFormatArr = [];
    let maskFormat = "";
    if (StringUtil.isNotEmpty(mask)) {
      let maskArr = mask.split("/");
      if (maskArr && maskArr.length == 3) {
        maskFormatArr = maskArr.map(x => {
          if (x.includes("DD") || x.includes("YY")) {
            return x.toLowerCase();
          }
          return x;
        })
        maskFormat = maskFormatArr.join("/");
        return maskFormat;
      }
    }
    return "";
  }

  public static dateChange(val: string, mask: string, format: string): string {

    let result = [];
    let dateSplit = val.split("/");
    let year: any; let month: any; let day: any;

    let maskSplit = mask.split("/");
    let formatSplit = this.changeMask(format).split("/");

    for (let i = 0; i < maskSplit.length; i++) {
      let bit = maskSplit[i].toLowerCase();
      if (bit.includes("yy")) {
        year = dateSplit[i];
      }
      else if (bit.includes("mm")) {
        month = dateSplit[i];

      }
      else if (bit.includes("dd")) {
        day = dateSplit[i];
      }
    }

    for (let i = 0; i < formatSplit.length; i++) {
      let bit = formatSplit[i].toLowerCase();
      if (bit.includes("yy")) {
        result[i] = year;
      }
      else if (bit.includes("mm")) {
        result[i] = month;
      }
      else if (bit.includes("dd")) {
        result[i] = day;
      }
    }

    let str = result.join("/");
    return str;
  }
}