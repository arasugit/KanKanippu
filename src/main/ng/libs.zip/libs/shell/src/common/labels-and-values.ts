export class LabelAndValue {
  constructor(public label: string, public value: string, public record?: any) {}
}
export class LabelsAndValues {
constructor(public label?: string, public value?: string, public record?: any){}
[x: string]: any;
  public arr: LabelAndValue[] = [];
  private list: LabelAndValue[] = [];

  public set array(val: LabelAndValue[]) {
      this.arr = val;
  }
  public get array(): LabelAndValue[] {
      return this.arr;
  }
  public mapValueToLabel(val: string): any {
      if (!this.arr) {
          return undefined;
      }
      for (const entry of this.arr) {
          if (entry && entry.value && val) {
              if (entry.value.trim() === val.trim()) {
                  return entry.label;
              }
          }
      }
  }

  public mapLabelToValue(label: string): any {
      if (!this.arr) {
          return undefined;
      }
      for (const entry of this.arr) {
          if (entry && entry.label && label) {
              if (entry.label.trim() === label.trim()) {
                  return entry.value;
              }
          }
      }
  }

  public mapValueToDataProvider(val: string): Boolean {
      if (!this.arr) {
          return false;
      }
      for (const entry of this.arr) {
          if (entry && entry.value && val) {
              if (entry.value.trim() === val.trim()) {
                  return true;
              }
          }
      }
      return false;
  }

// added to include empty row in the drop down
public addEmptyRow(): void {
  const val: LabelAndValue = this.arr !== null ? this.arr[0] : null;
  if (val !== null && val !== undefined && val.label === '' && val.value === '') {
  return;
  }
  const rec: string[] = ['', ''];
  const emptyrow: LabelAndValue = new LabelAndValue('', '', rec);
  this.arr.unshift(emptyrow);
}
public addWildCardForBIN(): void {
  const val: LabelAndValue = this.arr !== null ? this.arr[0] : null;
  if (val !== null && val !== undefined && val.label === '' && val.value === '') {
  return;
  }
  const wildcardRow: LabelAndValue = new LabelAndValue('*-ALL', '         *');
  this.arr.unshift(wildcardRow);
}
// added to retain the original record when filter function applied
public set records(val: LabelAndValue[]) {
  this.list = val;
}
public get records(): LabelAndValue[] {
  return this.list;
}
// added if there are more than two properties in the returnted results - used for province, county
public convertToLabelValues(data: any): void {
  const dataProvider: LabelsAndValues = new LabelsAndValues();
  const tempArr = [];
  let labelEntry: LabelAndValue;
 for (const entry of data) {
    labelEntry = new LabelAndValue(entry[1], entry[0], entry);
    tempArr.push(labelEntry);
    }
  this.array = tempArr.copyWithin(tempArr.length, 0);
  this.list = tempArr.copyWithin(tempArr.length, 0);
}
public createCopy(): LabelsAndValues {
  const cloneObj: LabelsAndValues = new LabelsAndValues();
  cloneObj.arr = this.arr.copyWithin(this.arr.length, 0);
  cloneObj.list = this.arr.copyWithin(this.arr.length, 0);
  return cloneObj;
}
}

