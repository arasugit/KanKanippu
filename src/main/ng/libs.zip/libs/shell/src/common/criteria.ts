
export interface StringMap {
    [paramName: string]: string;
}
export interface Criteria {
    [paramName: string]: String;
}
