// $Id$
export interface Permissions {
    [permissionName: string]: Boolean;
}
