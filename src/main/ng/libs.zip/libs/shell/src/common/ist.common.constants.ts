export class CommonConstants {
   static readonly ACTION_INSERT  = 'insert';
   static readonly  ACTION_UPDATE = 'update';
   static readonly ACTION_QUERY = 'query';
   static readonly ACTION_DELETE = 'delete';
   static readonly ACTION_DELETE_ALL = 'deleteAll';
   static readonly ACTION_QUERY_DETAIL = 'detail';
   static readonly ACTION_SINGLE_BATCH_SAVE = 'save';

   static readonly SINGLEPAGE_ADD = 'I';
   static readonly SINGLEPAGE_UPDATE = 'U';
   static readonly SINGLEPAGE_ADD_DELETE = 'ID';
   static readonly SINGLEPAGE_DELETE = 'D';
   static readonly ACTION_SEARCHLIST = 'searchlist';
   static readonly SINGLEPAGE_EXCLUDE = 'X';
   static readonly RETURN = 'return';

   // dialog box
   static readonly ALERT_OK = 4;
   static readonly ALERT_YES = 1;
   static readonly ALERT_NO = 2;
   static readonly ALERT_CANCEL = 8;
   static readonly ALERT_YES_NO = 3;  // YES+NO
   static readonly ALERT_OK_CANCEL = 12; // OK+CANCEL
   static readonly WARNING = 'W';
   static readonly ERROR = 'E';
   static readonly INFORMATION = 'I';
   static readonly CONFIRMATION = 'C';

   // common strings
   static readonly EXPAND_STRING = 'Expand All';
   static readonly COLLAPSE_STRING = 'Collapse All';
   static readonly NEWLINE_CHAR = '\n\r';

   // mkc related constants
   static readonly MKC_ACTION_PENDING_REQ = 'mkc_pending_query';
   static readonly MKC_ACTION_REWORK_REQ =  'mkc_rework_query';
   static readonly MKC_ACTION_REWORK_EDIT =  'mkc_rework_edit';
   static readonly MKC_ACTION_APPROVE  = 'approve';
   static readonly MKC_ACTION_REJECT = 'reject';
   static readonly MKC_ACTION_REWORK = 'rework';

   // MKC record status
   static readonly MKC_STATUS_SUBMIT = 'S';
   static readonly MKC_STATUS_REWORK = 'W';
   static readonly MKC_STATUS_REJECTED = 'X';
   static readonly MKC_STATUS_APPROVED = 'A';
   static readonly MKC_STATUS_SYSFAILURE = 'F';
}
