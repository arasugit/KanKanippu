import { DatePipe } from '@angular/common';
import { StringUtil } from './ist-string-util';
import { GlobalsService } from '../services/globals.service';
import { Injector } from '@angular/core';

export class CustomValidators {

  constructor(injector: Injector) {
    CustomValidators.globals = injector.get(GlobalsService);
  }
static datePipe: DatePipe = new DatePipe('en-US');
public static globals: GlobalsService;
public static validateEmail(email: string):  Boolean {
  const emailPattern = new RegExp('^[A-Za-z0-9._%\\-]+@[A-Za-z0-9.\\-]+\\.[a-zA-Z]{2,4}$');
  if (StringUtil.isEmpty(email)) { return true; }
   return emailPattern.test(email);
  }
// Validate Multiple Email addresses
public static validateMultipleEmail(email: string):  Boolean {
    const emailPattern = new RegExp('^([A-Za-z0-9._%\\-]+@[A-Za-z0-9.\\-]+\\.[a-zA-Z]{2,4}[,;]*)+$');
    if (StringUtil.isEmpty(email)) { return true; }
     return emailPattern.test(email);
  }
// validate URL string
public static validateURL(url: string): Boolean {
  const urlPattern = /^(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/i;
  if (StringUtil.isEmpty(url)) { return true; }
       return urlPattern.test(url);
  }

// validate Date string
public static isValidDate(dateValue: any, dateFormat: string):boolean{

  if (typeof dateValue === 'string') {
    const defaultPattern = /^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.](19|20)?[0-9]{2})*$/;

    // Regular expression for DD/MM/YYYY format with optional leading zeros
    const ddmmyyyyPattern = /^(0?[1-9]|[12][0-9]|3[01])(\/|-)(0?[1-9]|1[0-2])\2(19|20)\d\d$/;

    // Regular expression for MM/DD/YYYY format with optional leading zeros
    const mmddyyyyPattern = /^(0?[1-9]|1[0-2])(\/|-)(0?[1-9]|[12][0-9]|3[01])\2(19|20)\d\d$/;

    if (dateFormat.toUpperCase() == 'DD/MM/YYYY' || dateFormat.toUpperCase() == 'DD-MM-YYYY') {
      return ddmmyyyyPattern.test(dateValue);
    }
    else if (dateFormat.toUpperCase() == 'MM/DD/YYYY' || dateFormat.toUpperCase() == 'MM-DD-YYYY') {
      return mmddyyyyPattern.test(dateValue);
    }

    return defaultPattern.test(dateValue);
  } else if (dateValue instanceof Date && !isNaN(dateValue.getDate())) {
    return true;
  }

  return false;
}

public static formatDateString(dateValue: any, dateFormat = 'MM/dd/yyyy'): string {
  if (typeof dateValue === 'string') {
    return dateValue;
  }

  if (dateValue === undefined || dateValue === '' || dateValue === null) {
    return null;
  }

  var local = 'en-GB';
  if (dateFormat.toUpperCase() === 'MM/DD/YYYY' || dateFormat.toUpperCase() === 'MM-DD-YYYY') {
    local = 'en-US';
  }

  try {
    const formattedText = this.datePipe.transform(dateValue, dateFormat, undefined, 'en-GB');
    return formattedText;
  } catch (e) { }
  return null;
}

public static formatTimeField(event: any) {
  let value: string = event.target.value;
  this.globals.setErrorMessage('');

  if (value === undefined || value === '') {
    return;
  }

  if (value.indexOf(':') === -1) {
     this.globals.setErrorMessage('Please enter valid time in HH:MM:SS format');
     event.target.focus();
     return false;
  }

  if (value.match(/[^0-9]/g) || value.match(/[^:]/g)){
    const sanitizedValue = value.replace(/[^0-9:]/g, '');
    event.target.value = sanitizedValue;
  }

  let result = this.validateTimeField(value);

  if (!result){
    event.target.focus();
  }

  return result;
}

public static validateTransDate(fromDate: any, dateTo: any, firstFocusField: any, toDateFocusField: any):boolean {

  let result: boolean;
   if (null === fromDate || '' === fromDate) {
       result = false;
     this.globals.setErrorMessage('MON1');
       firstFocusField.setFocus();
       return result;
   }
   if(! CustomValidators.isValidDate(fromDate, this.globals.dateFormat)){
     this.globals.setErrorMessage('MON3');
     firstFocusField.setFocus();
     return false;
   }
   if (null === dateTo || '' === dateTo) {
     result = false;
   this.globals.setErrorMessage('MON2');
     toDateFocusField.setFocus();
     return result;
 }
 if(! CustomValidators.isValidDate(dateTo, this.globals.dateFormat)){
   this.globals.setErrorMessage('MON3');
   toDateFocusField.setFocus();
   return false;
 }
 if(this.convertToDate(dateTo, this.globals.dateFormat) < this.convertToDate(fromDate, this.globals.dateFormat)){
  this.globals.setErrorMessage(" 'Date to'" + " should be greater than or equal to " + " 'Date from' ");
  toDateFocusField.setFocus();
  return false;
}
 return true;
}

static convertToDate(dateString: string, dateFormat: string): Date | null {
  if (!dateString) return;
  if (dateString.toString().length >= 8 && !(dateString.toString().includes('-') || dateString.toString().includes('/'))) {
    return new Date(dateString);;
  }

  if(dateString.length < 8) {
    return;
  }

  var separator = '/';
  var dayIndex = 0;
  var monthIndex = 1;

  if (dateFormat.includes('-')) {
    separator = '-';
  }

  dateString = dateString.replace(new RegExp('/', 'g'), separator);
  dateString = dateString.replace(new RegExp('-', 'g'), separator);

  const formatParts = dateFormat.split(separator);
  if (formatParts[0].toUpperCase() === 'MM') {
    monthIndex = 0;
    dayIndex = 1;
  }

  const parts = dateString.split(separator);
  if (parts.length === 3) {
    var day = parseInt(parts[dayIndex], 10);
    var month = parseInt(parts[monthIndex], 10) - 1;
    var year = parseInt(parts[2], 10);

    if (month > 12 && day <= 12) {
      const tempMonth = month;
      month = day - 1;
      day = tempMonth + 1;
    }
    else if (month > 12 && day > 12) {
      return null;
    }

    if (year.toString().length == 2) {
      year = year + 2000;
    }
    return new Date(year, month, day);
  }

  return null;
}

public static validateTPSVsMemDate(fromDate: any, dateTo: any, firstFocusField: any, toDateFocusField: any):boolean {

  let result: boolean;
   if (null === fromDate || '' === fromDate) {
       result = false;
     this.globals.setErrorMessage('MON1');
       firstFocusField.setFocus();
       return result;
   }
   if(! CustomValidators.isValidDate(fromDate, this.globals.dateFormat)){
     this.globals.setErrorMessage('MON3');
     firstFocusField.setFocus();
     return false;
   }
 if( !(null === dateTo || '' === dateTo) && !CustomValidators.isValidDate(dateTo, this.globals.dateFormat)){
   this.globals.setErrorMessage('MON3');
   toDateFocusField.setFocus();
   return false;
 }
 if(dateTo != null && this.convertToDate(dateTo, this.globals.dateFormat) < this.convertToDate(fromDate, this.globals.dateFormat)){
  this.globals.setErrorMessage(" 'Date to'" + " should be greater than or equal to " + " 'Date from' ");
  toDateFocusField.setFocus();
  return false;
}
 return true;
}

public static isFutureDate(date: Date): boolean {
  let currentDate: Date = new Date();
  if (date > currentDate) {
    return true;
  }
}

public static validateTimeField(timeValue: any):boolean {
  this.globals.setErrorMessage('');

  if (timeValue === undefined || timeValue === '') {
    return true;
  }

  const valueArr: string[] = timeValue.split(':');
  if (valueArr.length < 3) {
    this.globals.setErrorMessage('Please enter valid time in HH:MM:SS format');
    return false;
  }

  if (valueArr[0] === '' || Number.isNaN(+valueArr[0]) ||  Number.parseInt(valueArr[0]) > 23) {
    this.globals.setErrorMessage('HH(hours) part must be between 0 and 23');
    return false;
  }
  if (valueArr[1] === '' || Number.isNaN(+valueArr[1]) || Number.parseInt(valueArr[1]) > 59) {
    this.globals.setErrorMessage('MM(minutes) part must be between 0 and 59');
    return false;
  }
  if (valueArr[2] === '' || Number.isNaN(+valueArr[2]) || Number.parseInt(valueArr[2]) > 59) {
    this.globals.setErrorMessage('SS(seconds) part must be between 0 and 59');
    return false;
  }

  return true;
}

  // File name is mandatory for Debug Monitoring
  public static isFileNameEmpty( fileName : string): any {
    let value: string = fileName;
    let tmpStr: string;

    tmpStr = '';
    this.globals.setErrorMessage('');
    if (value === undefined || value === '') {
      this.globals.setErrorMessage('Please select a valid file name');
      return false;
    }
    return true;
  }

  // Terminal Id is mandatory field for Txn Trends
  public static isTermIdEmpty( termId : string): boolean {
    let value: string = termId;

    this.globals.setErrorMessage('');
    if (value === undefined || value === '') {
      this.globals.setErrorMessage('Please enter a valid terminal id');
      return false;
    }
    return true;
  }

  public static validateMonth(fromDate: any):boolean {
    this.globals.setErrorMessage('');
    if (fromDate === null || fromDate === '') {
      this.globals.setErrorMessage('Please select a valid month');
      return false;
    }
      return true;
  }

  public static isYearEmpty( year : string): any {
    let value: string = year;

    this.globals.setErrorMessage('');
    if (value === undefined || value === '') {
      this.globals.setErrorMessage('Please select a year from the dropdow');
      return false;
    }
    return true;
  }
}
