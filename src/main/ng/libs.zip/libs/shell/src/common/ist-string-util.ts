export class StringUtil {

 public static isNotEmpty(value: string):  Boolean {
    return !StringUtil.isEmpty(value);
  }
  public static isEmpty(value: string): boolean {
    if ((value === null) || (value === undefined) || ((value.trim()) === '')) {
        return true;
    } else {
        return false;
    }
 }
 public static ltrim(value: string): string {
  if ((value.length > 1) || (value.length === 1 && value.charCodeAt(0) > 32 && value.charCodeAt(0) < 255)) {
    let i = 0;
    while (i < value.length && (value.charCodeAt(i) <= 32 || value.charCodeAt(i) >= 255)) {
      i++;
    }
    value = value.substring(i);
  } else {
    value = '';
  }
  return value;
}
public static rtrim(value: string): string {
  if ((value.length > 1 ) || (value.length === 1 && value.charCodeAt(0) > 32 && value.charCodeAt(0) < 255)) {
    let i = value.length - 1;
    while (i >= 0 && (value.charCodeAt(i) <= 32 || value.charCodeAt(i) >=   255)) {
      i--;
    }
    value = value.substring(0, i + 1);
  } else {
    value = '';
  }
  return value;
}
public static trim(value: string): string {
  return StringUtil.ltrim(StringUtil.rtrim(value));
}
public static equals(str1: string, str2: string): boolean {
  if (StringUtil.isEmpty(str1)) {
    if (StringUtil.isEmpty(str2)) {
      return true;
    } else {
      return false;
    }
  } else if (StringUtil.isEmpty(str2)) {
    return false;
  } else {
    return (str1 === str2);
  }
}
public static notEquals(str1: string, str2: string): boolean {
  return !StringUtil.equals(str1, str2);
}
}
