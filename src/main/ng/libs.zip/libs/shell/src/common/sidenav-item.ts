import { RufDynamicSidemenuItem } from '@ruf/shell';

export const sidenavItems: RufDynamicSidemenuItem[] = [
  {
    label: 'Home',
    path: 'ruf/welcome',
    icon: 'fis-icon-home',
    params: { keywords: 'Welcome' },
  },
  {
    label: 'ATM',
    path: '/ruf/atm/overview',
    icon: 'fis-icon-chart',
    children: [
      {
        label: 'Atms in service',
        path: 'ruf/atm/service',
        params: { keywords: 'atm' },
      },
      {
        label: 'Out of service',
        path: 'ruf/atm/outofservice',
        params: { keywords: 'atm' },
      },
       {
        label: 'Location',
        path: 'ruf/atm/locations',
        params: { keywords: 'atm' },
      },
      {
        label: 'Branch',
        path: 'ruf/atm/branches',
        params: { keywords: 'atm' },
      }
    ],
  },
  {
    label: 'Transaction',
    path: 'ruf/utils',
    icon: 'fis-icon-ledger',
    params: { keywords: 'utils' }
  },
];
