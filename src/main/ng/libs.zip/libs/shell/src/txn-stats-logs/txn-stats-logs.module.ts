import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TransStatsLogsComponent } from './txn-stats-logs.component';
export const transStatsLogsData: MonitorComponentData = {
  title: 'Transaction Statistics Logs',
  icon: 'table',
  examples: {  
      'TXNSTSLOG': {
          label: 'Transaction Statistics Logs',
          title: 'Transaction Statistics Logs',
          description: 'Transaction Statistics Logs',
          rufId: 'mon_txn_sts_logs',
          component: TransStatsLogsComponent
      }
  },

  
};
@NgModule({ 
  imports :[ 
  FormsModule,
  ReactiveFormsModule, 
  MatTableModule, 
  MatCardModule, 
  ISTComponentModule
], 
declarations: [TransStatsLogsComponent],
providers: [{ provide: MON_TOOL, useValue: transStatsLogsData }],
exports:[],
})
export class TransStatsLogsModule { }
