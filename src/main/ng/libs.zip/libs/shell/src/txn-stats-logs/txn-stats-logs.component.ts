import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent} from '../components/base-list.component';
import { CustomValidators, StringUtil } from '../common';
import { T21Base } from '../components';

@Component({
  selector: 'txn-sts-logs',
  templateUrl: './txn-stats-logs.component.html',
  encapsulation: ViewEncapsulation.None
})


export class TransStatsLogsComponent extends ListComponent implements OnInit {

  constructor(injector: Injector) {
    super(injector);
  }
  FORM_TITLE = 'Transaction Statistics Logs';
  exportFileName = 'Transaction Statistics Logs'

   product = '';
   fromTime :  string = '';
   fromDate : string = '';
   dateTo : string = '';
   toTime : string = '';
   screenType ='';


   optionsList = [
    { label: 'Tran source', value: 'S' },
    { label: 'Tran destination', value: 'D' },
    { label: 'Both', value: 'B' }
  ];

  ist_search_by = 'S';
  ist_inst_Id = '';
  terminalId = '';

  @ViewChild('toDateFocusField', { static: false })
  toDateFocusField: T21Base;

   queryPerm = new FormActionPermission('TXNSTSLOG', 'Q');
   checkerPerm = new FormActionPermission('TXNSTSLOG', 'C');
   mkcPerm = new MKCPermission('TXNSTSLOG');

   adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
    this.criteria['fromTime']= this.fromTime;
    this.criteria['toTime']=this.toTime;
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
    this.criteria['ist_inst_Id']= this.ist_inst_Id;
    this.criteria['ist_search_by']= this.ist_search_by;
    this.criteria['termId'] = this.terminalId;
  }

   ngOnInit() {
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    if(this.screenType == 'TXNSTSLOG'){
      this.FORM_TITLE=' Transaction Statistics Logs';
      this.exportFileName='Txn-Stats-Logs';
    }
    this.setAutoRefreshSearch(true);
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNSTSLOG';
    this.metaDataId = 'TXNSTSLOG';
    this.tabId = 'TXNSTSLOG_TAB';
    this.sectionId = 'TXNSTSLOG_SEC';
    this.collectionId = 'TXNSTSLOG_COL';
  }

  onItemClick(selectedItem: any) {
    this.goToDetailForm({
      COMMAND: 'detail',
      ist_inst_Id: selectedItem.txnsrc,
      ist_txndest: selectedItem.txndest,
    });
  }

  validateBeforeQuery(): boolean {
    CustomValidators.globals=this.globals;
    this.fromDate=CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo=CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat);
    let result:boolean;
    result= CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField);
  if(result){
    result= CustomValidators.validateTimeField(this.fromTime);
 }

 if(result){
   result= CustomValidators.validateTimeField(this.toTime);
}

if (StringUtil.isEmpty(this.ist_inst_Id)) {
  this.globals.setErrorMessage('ERR01');
  this.setFocusToFirstField();
  result = false;
}  


return result;
}

validateFromTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
validateToTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}

getModuleName() { return 'IST-MONITORING'; }
emitModuleReady() { this.msgService.sendMessage(this.getModuleName() ); }
}
