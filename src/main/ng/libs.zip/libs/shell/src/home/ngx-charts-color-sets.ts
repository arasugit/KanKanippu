export const MON_ATM_COLOR_SETS = {
  rufPieChartDarkColorScheme: [
    '#4CB140','#C9190B'
  ],
  rufPieChartLightColorScheme: [
    '#3BCFF0',
    '#4BCD3E',
    '#015B7E',
    '#A18CDE',
    '#FFCD00',
    '#009775'
  ],
  rufBarChartLightColorScheme: [
    '#4BCD3E',
    '#f05c3b',
    '#3BCFF0',
    '#fccf5b',
    '#a358a3',
    '#425be9',
    '#9f8a86'
  ],
  rufGaugeColorScheme: [
    '#4BCD3E',
    '#f05c3b',
    '#3BCFF0',
    '#fccf5b',
    '#a358a3',
    '#425be9'
  ],

};
