export const pieChartSiteData = [
{
    'name': 'Offsite',
    'value': 88.89
  },
  {
    'name': 'Onsite',
    'value': 25
  }
];

export const pieChartMakeData = [
  {
      'name': 'NCR',
      'value': 3
    },
    {
      'name': 'Diebold',
      'value': 4
    }
  ];
