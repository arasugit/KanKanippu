export * from './welcome.component';
export * from './data';
