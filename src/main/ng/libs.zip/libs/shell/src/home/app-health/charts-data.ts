export const pieChartHealthData = [
  {
    'name': 'Up',
    'value': 87
  },
  {
    'name': 'Down',
    'value': 13
  }
];

export const formatedData = [
  'Up','Down'
  
];


export const pieChartHealthSiteData = [
{
    'name': 'Offsite',
    'value': 88.89
  },
  {
    'name': 'Onsite',
    'value': 25
  }
];

export const pieChartHealthMakeData = [
  {
      'name': 'NCR',
      'value': 3
    },
    {
      'name': 'Diebold',
      'value': 4
    }
  ];
