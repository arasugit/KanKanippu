import { MonitorComponentData } from '../monitor-components/common-object';
import { WelcomeComponent } from './welcome';
export const monData: MonitorComponentData = {
    title: 'Overall Network Status',
    icon: 'home',
    examples: {        
        'ATMAVL_REQ': {
            label: 'Overall network status',
            title: 'Overall Application Network Status',
            description: 'Overall Application Network Status',
            rufId: 'mon_netw_status',
            component: WelcomeComponent
        }
    }   
};
