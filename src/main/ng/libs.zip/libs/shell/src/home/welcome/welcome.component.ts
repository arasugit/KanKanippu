import {Component, ViewEncapsulation, OnInit, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef} from '@angular/core';
import { Subject, takeUntil} from 'rxjs';
import { MON_ATM_COLOR_SETS } from '../ngx-charts-color-sets';
import { ListComponent } from '../../components';
import { FormActionPermission, MKCPermission } from '../../permission';
import { DataTableService } from '../../services';
import { WorkRequest } from '../../ist-components';
import { StringUtil } from '../../common';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import highcharts3d from 'highcharts/highcharts-3d';
highcharts3d(Highcharts);
import HCSankey from 'highcharts/modules/sankey';
import HCOrganization from 'highcharts/modules/organization';

HCSankey(Highcharts);
HCOrganization(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);
export interface Branch{
     branch:string,
     up:number,
     down:number
}
export interface Category{
  name:string,
  value:number
}
export interface ATMFault{
  faultDescription:string,
  count:number
}

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class WelcomeComponent extends ListComponent implements OnInit,OnDestroy {
  private unsubscribe = new Subject();
  view: any[] =[380, 280];
  siteView: any[] =[250, 250];
  makeView: any[] =[250, 250];
  animations = true;
  showLegend = false;
  legendWidth:number=80;
  legendHeight:number=20;
  maxLabelLength:number=20;
  doughnut = true;
  arcWidth = 0.50;
  atm: any[]=[];
  site: any[]=[];
  branchArray:Branch[]=[];
  categoryArray:Category[]=[];
  atmFaultArray:ATMFault[]=[];
  make:any[]=[];
  upAtmPercentage : number = 0;
  downAtmPercentage : number = 0;
  workRequest:WorkRequest;
  autoRefreshRetriveDataTimer: any;
  legendTitle = 'Legend';
  dataLoaded:boolean=false;
  atmFaultStats: FormActionPermission;
  cardView: any[] = [500, 130];
  Highcharts: typeof Highcharts = Highcharts;
  colorScheme = {
    domain: ['#015b7e']
  };
  cardColor: string ;
  atmColorScheme = {
    domain: MON_ATM_COLOR_SETS['rufPieChartDarkColorScheme']
  };
  siteColorScheme = {
    domain: MON_ATM_COLOR_SETS['rufPieChartLightColorScheme']
  };
  branchColorScheme = {
    domain: MON_ATM_COLOR_SETS['rufPieChartLightColorScheme']
  };
  makeColorScheme = {
    domain: MON_ATM_COLOR_SETS['rufPieChartLightColorScheme'],

  };
  makeColorSchemeLegend = {
    domain: MON_ATM_COLOR_SETS['rufPieChartLightColorScheme'],

  };
  public atmLegendValues:string[]=[];
  public siteLegendValues:string[]=[];
  public branchLegendValues:string[]=[];
  public makeLegendValues:string[]=[];
  // readonly LegendPosition = LegendPosition;
  // readonly LegendType = LegendType;
  FORM_TITLE = 'ATM Dashboard';
  totalAtms: any;
  operationalAtm: number;
  upAtms: any;
  outOfServiceAtms: any;
  nonOperAtms: number;
  chartOptions: Highcharts.Options;
  chartOptionsSite: Highcharts.Options;
  chartOptionsMake: Highcharts.Options;
  overallStatus: Highcharts.Options;


 constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker){
      super(injector);
      this.retriveData();
  }

  adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';
  //  this.criteria['siteId']= 'Site1';
  //  this.criteria['nodeId']='node1';
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }
  retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
    this.globals.showLoadingBar();
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        atmData => this.onGotRecords(atmData),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnInit(){
    super.ngOnInit();
    this.setAutoRefreshRetriveDataInterval();
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.globals.hideLoaderBar();
    this.workRequest = wr;
    if(this.workRequest!=null && this.workRequest !==undefined && this.workRequest.collections!=null && this.workRequest.collections[this.collectionId] !=null && this.workRequest.collections[this.collectionId].rows!=null){
      const rows = this.workRequest.collections[this.collectionId].rows;
      this.atm = [];
      this.site =[];
      this.branchArray=[];
      this.categoryArray=[];
      this.make=[];
      this.atmFaultArray=[];
      if(rows!=null && rows!=undefined){
            rows.forEach(c =>{
              this.upAtmPercentage =  (c.atmInService/c.totalATM) * 100; //Math.round((c.atmInService/c.totalATM) * 100);
              this.downAtmPercentage = 100 - this.upAtmPercentage;
              this.atm.push({name: c.statusUp,y: this.upAtmPercentage,sliced: true,
                selected: true})
              this.atm.push({name: c.statusDown,y: this.downAtmPercentage})
              this.atmLegendValues.push(c.statusUp+'-'+this.upAtmPercentage.toFixed(2)+' %');
              this.atmLegendValues.push(c.statusDown+'-'+this.downAtmPercentage.toFixed(2)+' %');
              this.site.push({ name:c.onSite+'-Down ',y:parseFloat(c.percentageDownOnSite)});
              this.site.push({ name:c.onSite+'-Up ',y:parseFloat(c.percentageUpOnSite)});
              this.site.push({ name:c.offSite+'-Down ',y:parseFloat(c.percentageDownOffSite)});
              this.site.push({ name:c.offSite+'-Up ',y:parseFloat(c.percentageUpOffSite)});
              this.siteLegendValues.push(c.onSite+'-'+c.percentageDownOnSite+'% down');
              this.siteLegendValues.push(c.onSite+'-'+c.percentageUpOnSite+'% up');
              this.siteLegendValues.push(c.offSite+'-'+c.percentageDownOffSite+'% down');
              this.siteLegendValues.push(c.offSite+'-'+c.percentageUpOffSite+'% up');
              // this.categoryArray.push(this.loadCategory("Total ATMs",c.totalATM));
              this.totalAtms = c.totalATM;
              const operational:number=c.atmInService+c.atmOutOfService;
              // this.categoryArray.push(this.loadCategory("Operational",operational));
              this.operationalAtm = operational;
              const non_operational:number=c.totalATM!=0?c.totalATM-operational:0;
              this.categoryArray.push(this.loadCategory("- UP ATMs",c.atmInService));
              this.upAtms = c.atmInService;
              this.categoryArray.push(this.loadCategory("- Out of Service",c.atmOutOfService));
              this.outOfServiceAtms = c.atmOutOfService;
              // this.categoryArray.push(this.loadCategory("Non-Operational",non_operational));
              this.nonOperAtms = non_operational;
              const branchList = c.branchTermStatusList;
              branchList.forEach(branchObject =>{
                const branchObj:Branch={
                   branch:branchObject.branch,
                   up:branchObject.branchUpPercentage,
                   down:branchObject.branchDownPercentage};
                   this.branchArray.push(branchObj);
              });
              this.branchArray.sort((a,b)=> b.down - a.down);
              const  makeATMList= c.atmByMakeList;
              if(makeATMList !=null && makeATMList!=undefined)
              {
                 let i=0;
                  makeATMList.forEach(atmMake =>{
                    const totalRunningATM= Math.round((atmMake.runningATMByMake/atmMake.totalConfiguredATM)*100);
                    const totalDownATM = Math.round((atmMake.downATMByMake/atmMake.totalConfiguredATM)*100);
                    if(totalRunningATM!==0){
                      this.make.push({name:atmMake.make + '-Up ',y:totalRunningATM});
                      this.makeLegendValues.push(atmMake.make+'-Up: '+totalRunningATM+"%");
                    }
                    if(totalDownATM!==0){
                      this.make.push({name:atmMake.make + '-Down ',y: totalDownATM});
                      this.makeLegendValues.push(atmMake.make+'-Down: '+ totalDownATM+"%");
                    }
                  });
              }
            const atmFaultWiseList=c.atmByFaultWiseList;
            if(atmFaultWiseList !=null && atmFaultWiseList!=undefined)
              {
                    atmFaultWiseList.forEach(atmFaultObj =>{
                      const atmFault:ATMFault={
                        faultDescription:atmFaultObj.statusDescription,
                        count:atmFaultObj.count
                      };
                      this.atmFaultArray.push(atmFault);
                  });
              }

           })
      }
      this.atm = [...this.atm];
      this.site =[...this.site];
      this.branchArray=[...this.branchArray];
      this.categoryArray=[...this.categoryArray];
      this.make=[...this.make];
      this.atmFaultArray=[...this.atmFaultArray];
      this.dataLoaded=true;
      this.cdr.markForCheck();
      this.getOverallStatusChart();
      this.getAtmAvailabilityChart();
      this.getStatusBySiteChart();
      this.getStatusByMakeChart();
    }
  }

  getOverallStatusChart(){
    this.overallStatus= {
      chart: {
        height: 350,
        inverted: true,
      },
      credits:{
        enabled: false,
      },
      title: {
        text: 'Overall status',
        margin:0,
    },
    exporting: {
      chartOptions: {
          plotOptions: {
              series: {
                  dataLabels: {
                      enabled: true
                  }
              }
          }
      },
      fallbackToExportServer: false
    },
    series: [
        {
          type: 'organization',
          name: 'Overall status',
          keys: ['from', 'to'],
          data: [
            { from: 'Total No of ATMs', to: 'Operational' },
            { from: 'Total No of ATMs', to: 'Non-Operational' },
            { from: 'Operational', to: 'UP ATMs' },
            { from: 'Operational', to: 'Out of Service' },
          ],
          levels: [
            {
              level: 0,

            },
            {
              level: 1,

            },
            {
              level: 2,
            },
            {
              level: 4,
            },
          ],
          nodes: [
            {
              id: 'Total No of ATMs',
              title:' <div style="font-size: 15px;">'+ 'Total No of ATMs'+'</div>',
              name:' <div style="font-size: 20px;">'+ this.totalAtms+'</div>',
              color: '#007ad0',
              dataLabels: {
                    color: 'white',
                  },
            },
            {
              id: 'Operational',
              title:' <div style="font-size: 15px;">'+ 'Operational'+'</div>',
              name:' <div style="font-size: 20px;">'+ this.operationalAtm+'</div>',
              color: '#05822f',
              dataLabels: {
                    color: 'white',
                  },
            },
            {
              id: 'Non-Operational',
              title:' <div style="font-size: 15px;">'+ 'Non-Operational'+'</div>',
              name:' <div style="font-size: 20px;">'+ this.nonOperAtms+'</div>',
              color: '#C9190B',
              dataLabels: {
                    color: 'white',
                  },
            },
            {
              id: 'UP ATMs',
              title:' <div style="font-size: 15px;">'+ 'UP ATMs'+'</div>',
              name:' <div style="font-size: 20px;">'+ this.upAtms+'</div>',
              color: '#4CB140',
              dataLabels: {
                    color: 'white',
                  },
            },
            {
              id: 'Out of Service',
              title:' <div style="font-size: 15px;">'+ 'Out of Service'+'</div>',
              name:' <div style="font-size: 20px;">'+ this.outOfServiceAtms+'</div>',
              color: '#C9790B',
              dataLabels: {
                    color: 'white',
                  },
            },
          ],
          colorByPoint: false,
          color: '#007ad0',
          dataLabels: {
            color: 'white',
          },
          borderColor: 'grey',
          borderRadius:25,
          nodeWidth: 75,
        },
      ],
    };
  }

  getAtmAvailabilityChart(){
    this.chartOptions= {

      chart: {
        type: 'pie',
        // options3d: {
        //     enabled: true,
        //     alpha: 45
        // }
        // width:500
    },
    credits:{
      enabled: false,
    },
     legend: {
      align: "center",
      verticalAlign: "bottom",
      layout: "horizontal",
      labelFormatter: function () {
      return this.name + " - " + ((this as Highcharts.Point).percentage.toFixed(2)+' %' ?? 0);
    },
    },
    title: {
        text: 'ATM Availability',
        margin:0,
    },
    tooltip: {
        pointFormat: '{point.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              distance:10,
                enabled: true,
								 
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    // color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            },
							   
						  
									
          size: '50%',
								
						 
          showInLegend: true
        }
    },
    exporting: {
      chartOptions: {
          plotOptions: {
              series: {
                  dataLabels: {
                      enabled: true
                  }
              }
          }
      },
      fallbackToExportServer: false
    },
    series: [{
        name:'ATM Availability',
        colorByPoint: true,
        type:'pie',
        innerSize: '50%',
        point: {
          events: {
              click:  (event)=> {
                this.onSelectAvailability({
                  x:event.point.x,
                  value:event.point.y,
                  name: event.point.series.name,
                  label: event.point.series.name,
                  series:event.point.category
                });
              }
            }
      },
        data:this.atm
    }as any],
    };
  }

  getStatusBySiteChart(){
    this.chartOptionsSite={

      chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45
        },

    },
    credits:{
      enabled: false,
    },
    title: {
        text: 'Status By Site Type',
        margin:0,
    },
    tooltip: {
        pointFormat: '<b>{point.percentage:.2f}%</b>'
    },
    exporting: {
      chartOptions: {
          plotOptions: {
              series: {
                  dataLabels: {
                      enabled: true
                  }
              }
          }
      },
      fallbackToExportServer: false
    },
    legend: {
      align: "center",
      verticalAlign: "bottom",
      layout: "horizontal",
      labelFormatter: function () {
      return this.name + " - " + ((this as Highcharts.Point).percentage.toFixed(2)+' %' ?? 0);
      },
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              distance:5,
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    // color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            },
            size: '40%',
            innerSize: '50%',
            depth: 45,
            showInLegend: true
        }
    },
    series: [{
        name: 'Status By Site Type',
        colorByPoint: true,
        type:'pie',
        data:this.site,
        point: {
          events: {
              click:  (event)=> {
                this.onSelectStatusBySite({
                  x:event.point.x,
                  value:event.point.y,
                  name: event.point.series.name,
                  label: event.point.series.name,
                  series:event.point.category
                });
              }
            }
      },
    }as any],

    }
  }

  getStatusByMakeChart(){
    this.chartOptionsMake= {

      chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45
        }
    },
    exporting: {
      chartOptions: {
          plotOptions: {
              series: {
                  dataLabels: {
                      enabled: true
                  }
              }
          }
      },
      fallbackToExportServer: false
    },
    credits:{
      enabled: false,
    },

    title: {
        text: 'Status By Make',
        margin:0,
    },
    tooltip: {
        pointFormat: '<b>{point.percentage:.2f}%</b>'
    },
    legend: {
      // align: "center",
      verticalAlign: "bottom",
      layout: "horizontal",
      labelFormatter: function () {
      return this.name + " - " + ((this as Highcharts.Point).percentage.toFixed(2)+' %' ?? 0);
    },
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              distance:10,
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
																								 
                }
            },
            size: '60%',
            depth: 45,
            showInLegend: true
        }
    },
    series: [{
        name:'Status By Make',
        colorByPoint: true,
        type:'pie',
        data:this.make,
        point: {
          events: {
              click:  (event)=> {
                this.onSelectStatusByMake({
                  x:event.point.x,
                  value:event.point.y,
                  name: event.point.series.name,
                  label: event.point.series.name,
                  series:event.point.category
                });
              }
            }
      },
    }as any],
    };
  }

  loadCategory(categoryName:string,data:number):Category
  {
    const category:Category={name:categoryName,value:data}
    return category;
  }
  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }
  onCompleteGotRecords(): void {
  }

  labelFormat(value : any){
    return value.toString();
  }
  getEntPermList(): any[] {
    this.entObjectId = 'OVERALL_NETW_STATUS';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.insertPerm = new FormActionPermission(this.entObjectId, 'I');
    this.updatePerm = new FormActionPermission(this.entObjectId, 'U');
    this.deletePerm = new FormActionPermission(this.entObjectId, 'D');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    this.atmFaultStats = new FormActionPermission('ATMFLTVIEW', 'Q');
    this.atmFaultStats = new FormActionPermission('ATMFLTVIEW', 'I');
    this.atmFaultStats = new FormActionPermission('ATMFLTVIEW', 'U');
    this.atmFaultStats = new FormActionPermission('ATMFLTVIEW', 'D');
    this.atmFaultStats = new FormActionPermission('ATMFLTVIEW', 'C');
    return new Array(this.queryPerm, this.insertPerm, this.updatePerm,this.deletePerm,this.mkcPerm,this.checkerPerm,this.atmFaultStats);
  }

  onSelect(event) {
    console.log(event);
  }
  onSelectAvailability(event) {
    console.log(event);
  }
  onSelectStatusBySite(event) {
    console.log(event);

      let newParam = {};
      let path = '';
      newParam = {
        COMMAND: 'query',
        NAVIGATION: true
      };
      path = 'monitor/ATMDWS_REQ';
    this.loadNewForm(newParam, path);
  }
  onSelectStatusByMake(event) {
    console.log(event);
      let newParam = {};
      let path = '';
      newParam = {
        COMMAND: 'query',
        NAVIGATION: true
      };
      path = 'monitor/ATMDWM_REQ';
    this.loadNewForm(newParam, path);
  }
onSelectStatusByBranch(event) {
      let newParam = {};
      let path = '';
      newParam = {
        COMMAND: 'query',
        NAVIGATION: true
      };
      path = 'monitor/ATMDWB_REQ';
      newParam['status_code'] = event;
      if (path !== '') { this.loadNewForm(newParam, path); }
  }

  gatherDataChanged(event:any):void{
     console.log(this.dataService.data);
  }

  setT21Tags(): void {
    this.requestTypeId = 'ATMAVL_REQ';
    this.metaDataId = 'ATMAVL_REQ';
    this.tabId = 'ATMAVL_TAB';
    this.sectionId = 'ATMAVL_SEC';
    this.collectionId = 'ATMAVL_COL';
  }
  ngOnDestroy() {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshRetriveDataInterval();
  }

  onSelectFaultStats(event: any): void {
      let newParam = {};
      let path = 'monitor/ATMFLTVIEW';
      newParam = {
        COMMAND: 'query',
        NAVIGATION: true
      };
      newParam['status_code'] = event;
      if (path !== '') { this.loadNewForm1(newParam); }

  }
  loadNewForm1(command: any) {
    this.DETAIL_FORM_PATH = 'monitor/ATMFLTVIEW';
    this.goToDetailForm(command);
  }

  labelFormatting(c) {
    return `Operational<br><br>
    ${c.data.label[0].name} - ${c.data.label[0].value}<br>
    ${c.data.label[1].name} - ${c.data.label[1].value}
    `;
  }

}
