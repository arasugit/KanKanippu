import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { RufCommonModule,RufScrollbarModule } from '@ruf/shell';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatGridListModule } from '@angular/material/grid-list';
import { monData } from './mon-metadata';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { WelcomeComponent } from './welcome/welcome.component';
import { RufCardModule } from '@ruf/shell';
import { ISTComponentModule } from '../ist-components';
import { MON_TOOL, MonitorComponentData } from '../monitor-components/common-object';
import { MatButtonModule } from '@angular/material/button';
import { HighchartsChartModule } from 'highcharts-angular';

export const welcomeComponentdData: MonitorComponentData = {
  title: 'ATM Dashboard',
  icon: 'table',
  examples: {
      'ATMDASH': {
          label: 'ATM Dashboard',
          title: 'ATM Dashboard',
          description: 'ATM Dashboard',
          rufId: 'atm_dashboard',
          component: WelcomeComponent
      }
  }
};


@NgModule({
  declarations:[WelcomeComponent],
  imports: [
    CommonModule,
    CdkScrollable,
    MatTableModule,
    FormsModule,
    FlexLayoutModule,
    RufCardModule,
    ReactiveFormsModule,
    ISTComponentModule,
    MatCardModule,
    MatGridListModule,
    RufScrollbarModule,
    RufCommonModule,
    MatButtonModule,
    HighchartsChartModule
   ],
  exports:[WelcomeComponent],
  providers: [{ provide: MON_TOOL, useValue: monData }],
})
export class HomeModule {}
