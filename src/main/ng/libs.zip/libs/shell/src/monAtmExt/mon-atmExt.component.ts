import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent, RendererItem } from '../components';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { IstDatePickerColumnRendererComponent } from '../ist-components';
import { LabelAndValue, LabelsAndValues } from '../common/labels-and-values';


@Component({
  selector: 'mon-atmExt-app',
  templateUrl: './mon-atmExt.component.html'
 })
export class MonAtmExtComponent extends ListComponent implements OnInit, AfterViewInit {
  [x: string]: any;

  @ViewChild('monAtmExtTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['COMMAND']='query';
  }

  FORM_TITLE = 'ATM Extension';
  exportFileName= 'ATM Extension';


   workRequest:WorkRequest;

   queryPerm = new FormActionPermission('MONATMEXT', 'Q');
   insertPerm = new FormActionPermission('MONATMEXT', 'I');
   updatePerm = new FormActionPermission('MONATMEXT', 'U');
   deletePerm = new FormActionPermission('MONATMEXT', 'D');
   checkerPerm = new FormActionPermission('MONATMEXT', 'C');
   mkcPerm = new MKCPermission('MONATMEXT');

   startDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
   endDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
   deptList: LabelsAndValues = new LabelsAndValues();
   craListData : LabelsAndValues = new LabelsAndValues();
   cntrlType = 'CBOX';

   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.insertPerm);
    this.requestPerms.permsArr.push(this.updatePerm);
    this.requestPerms.permsArr.push(this.deletePerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.instService.getDatabaseRecords("CRA_LIST_DROPDOWN",null).subscribe((x: any[]) => { this.loadCraNamesList(x); });
    console.log("CRA names List : "+this.craListData.records.length);
    console.log("CRA names List : "+this.craListData.records);
  }

  loadCraNamesList(result: string[]): void {
    this.craListData.array = result.map((y: string): LabelAndValue => {
      return new LabelAndValue(y, y);
    });
  }

  validateBeforeQuery(): boolean {
    return true;
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'MONATMEXT';
    this.metaDataId = 'MONATMEXT';
    this.tabId = 'MONATMEXTTAB';
    this.sectionId = 'MONATMEXTSEC';
    this.collectionId = 'MONATMEXTCOL';
  }


  onRowClick(event:any) {
    console.log("Inside OnRowClick " + event);
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
  }
}



