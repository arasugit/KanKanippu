import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TranslateModule } from '@ngx-translate/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { MonAtmExtComponent } from './mon-atmExt.component';


export const monAtmExt: MonitorComponentData = {
  title: 'ATM Extension',
  icon: 'home',
  examples: {
    'MONATMEXT': {
      label: 'ATM Extension',
      title: 'ATM Extension',
      description: 'ATM Extension',
      rufId: 'mon_atmExt',
      component: MonAtmExtComponent
    }
  }
};

@NgModule({
    imports :[
    CommonModule,
    ISTComponentModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    TranslateModule,
    MatFormFieldModule,
    MatInputModule

    ],
  declarations: [ MonAtmExtComponent ],
  providers: [{ provide: MON_TOOL, useValue: monAtmExt }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[],
})
export class MonAtmExtModule {
}
