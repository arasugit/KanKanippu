import {Component,ViewEncapsulation,Injector} from '@angular/core';
import { ListComponent } from '../../components';
import { FormActionPermission, MKCPermission } from '../../permission';
import { StringUtil } from '../../common';

@Component({
  selector: 'atm-totals-home',
  templateUrl: './atm-totals.component.html',
  styleUrls: ['./atm-totals.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ATMTotalsComponent extends ListComponent{
  constructor(private injector: Injector) {
    super(injector);
  }
  FORM_TITLE = 'ATM Totals';
  exportFileName = 'ATM Totals';
  pageCtrl = 'pageNum';
  mon_inst_id = '';
  mon_atm_grp_name = '';
  mon_atm_unit = '';
  setT21Tags(): void 
  {
    this.requestTypeId = 'ATMTOT_REQ';
    this.metaDataId = 'ATMTOT_REQ';
    this.tabId = 'ATMTOT_TAB';
    this.sectionId = 'ATMTOT_SEC';
    this.collectionId = 'ATMTOT_COL';
  }
  adjustCriteria(): void {
  //  this.criteria['productId'] = 'ISTSWT';
  //  this.criteria['siteId'] = 'Site1';
  //  this.criteria['nodeId'] = 'node1';
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
  }
  
  getEntPermList(): any[] {
    this.entObjectId = 'ATM_TOTALS';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.insertPerm = new FormActionPermission(this.entObjectId, 'I');
    this.updatePerm = new FormActionPermission(this.entObjectId, 'U');
    this.deletePerm = new FormActionPermission(this.entObjectId, 'D');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm, this.insertPerm, this.updatePerm, this.deletePerm, this.mkcPerm, this.checkerPerm);
  }

  validateBeforeQuery(): boolean {
    this.globals.setErrorMessage('');
    if (StringUtil.isEmpty(this.mon_inst_id)) {
      this.globals.setErrorMessage('ERR01');
      this.setFocusToFirstField();
      return false;
    }
    return true;
  }
  openSearchList(winName) {}
  getModuleName() { return 'ATM-Monitoring'; }
  emitModuleReady() { this.msgService.sendMessage(this.getModuleName()); }
}

