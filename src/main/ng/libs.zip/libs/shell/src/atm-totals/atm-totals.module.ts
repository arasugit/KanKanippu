import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { RufCommonModule,RufScrollbarModule } from '@ruf/shell';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ATMTotalsComponent } from './atm-totals-home/atm-totals.component';
import { ISTComponentModule } from '../ist-components';
import { MON_TOOL, MonitorComponentData } from '../monitor-components/common-object';
import { TranslateLazyLoadModule } from '../ist-components/ist-translate-lazyload-module';
import { RufCardModule} from '@ruf/shell';
import { MatDividerModule } from '@angular/material/divider';

const atmTotalsMetaData: MonitorComponentData = {
  title: 'ATM Totals',
  icon: 'ATM Totals',
  examples: {        
      'ATMTOT_REQ': {
          label: 'ATM Totals',
          title: 'ATM Totals',
    description: 'ATM Totals',
          rufId: 'ATM_Totals',
          component: ATMTotalsComponent
      }
  }   
};

@NgModule({
  declarations:[ATMTotalsComponent],
  imports: [
    CommonModule, 
    CdkScrollable,
    MatTableModule,  
    FormsModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    TranslateLazyLoadModule,
    ISTComponentModule,
    MatDividerModule,
    MatCardModule,  
    RufScrollbarModule,
    RufCommonModule,
    RufCardModule
   ],
  exports:[ATMTotalsComponent],
  providers: [{ provide: MON_TOOL, useValue: atmTotalsMetaData }],
})
export class ATMTotalsHomeModule {}
