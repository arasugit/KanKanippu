export * from './atm-totals.component';

