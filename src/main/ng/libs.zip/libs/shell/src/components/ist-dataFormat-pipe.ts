import { Pipe, PipeTransform } from '@angular/core';
import { CustomFormatter } from '../common/ist-formatter';
import { GlobalsService } from '../services/globals.service';
import { StringUtil } from '../common/ist-string-util';
import { DatePipe } from '@angular/common';

@Pipe({ name: 'formatData' })
export class DataFormatPipe implements PipeTransform {
  formatDate = new DatePipe('en_US');
  constructor(private globals: GlobalsService) {
  }

 transform(value: any, ...args: any[]): string {

    if ((args === undefined || args[0] === undefined || String(args[0]) === '') && !(this.detectDate(value))) {
       return value;
     }
     if ((args === undefined || args[0] === undefined || String(args[0]) === '') && (this.detectDate(value))) {
      return this.formatDate.transform(value, this.globals.dateTimeFormat)
     }
     const formatArr = args[0];
     const dateMask = args[1];

     const formatType = formatArr[0];
     let formatStore = formatArr[2];

    // console.log('pipe formatType', formatType);

  let returnValue = value;
  if (String(formatType) === 'DISPLAY-LABEL') {
    if (value === null || value === undefined) {
      returnValue = '';
    }
    if (formatArr[1] !== undefined) {
      const dataProvider =  formatArr[1];
      if (dataProvider !== undefined && dataProvider.arr !== undefined && dataProvider.arr.length > 1) {
        const label = dataProvider && dataProvider.mapValueToLabel ? dataProvider.mapValueToLabel(value+'') || value+'' || '' : '';
        returnValue = label;
        // console.log('dataProvider in pipe ', dataProvider, value, label);
      }
      if (returnValue !== "undefined" && returnValue !== "null" && returnValue !== null) {
        return returnValue;
      }
    }
  }

    if(StringUtil.isEmpty(formatType) && formatStore === "CUSTOMDATE"){

      let mask = this.getMask(dateMask, formatArr[3]);
      mask = this.changeMask(mask) ;
      returnValue =  StringUtil.isNotEmpty(mask) ? CustomFormatter.formatDateString(value, mask) : value;

    }

  switch (String(formatType)) {
    case 'AMOUNT' : {
      if (value === null || value === undefined) {
        return null;
      }
      let strVal: string = String(value);
      strVal = strVal.replace(new RegExp(',', 'g'), '');
      value = strVal;

      let amtArr = value.split(".");

      let mask = this.getMask(dateMask, formatArr[3]);

     let  maskArr =  StringUtil.isNotEmpty(mask)  ? mask.split(".") : null ;

      let maskDec = (maskArr && maskArr.length > 1) ? maskArr[1].length : this.globals.defFractionDigits;

      if(StringUtil.isNotEmpty(amtArr[0]) && amtArr[0].length > 15 ){  //To avoid round off value for digits > 15 like 123456789012345678.123456

        returnValue =  this.amountMask(amtArr,maskDec);

      }
      else{      // the value will be formatted based on the selected locale

      returnValue =   CustomFormatter.formatToLocaleAmount(value, this.globals.currentLanguage,maskDec );
    }
      break;
    }
    case 'HH:MM:SS' : {
      if (value === null || value === undefined) {
        returnValue = '';
      }
        returnValue =  CustomFormatter.formatHHMMSS(value);
      break;
    }
    case 'DATE' : {
      // console.log('formatting date');
      if (value === null || value === undefined) {
       returnValue = '';
      }
     // console.log("Original Value :" + CustomFormatter.formatDateString(value));
     // console.log("CustomMaskFlag : "  + formatStore);

      if(formatStore === "CUSTOMDATE"){
        let mask = "";
        if(StringUtil.isNotEmpty(formatArr[4])){
          mask = this.changeMask(formatArr[4]) ;
        }
        else{
          mask = this.getMask(dateMask, formatArr[3]);
          mask = this.changeMask(mask) ;
        }

        mask =  StringUtil.isNotEmpty(mask) ? mask : this.globals.dateFormat;
        console.log("Date fields from Collection : ");
        if(dateMask && dateMask.length > 0){
          dateMask.forEach(field => {
            // console.log(field["tag"]);
          });
        }

        returnValue = CustomFormatter.formatDateString(value, mask);
      }
      else{
      returnValue = CustomFormatter.formatDateString(value, 'MM/DD/YYYY');
      }
     // console.log("Formatted Value :" + returnValue);
      //console.log("----------------------------------");
      break;
    }
    case 'DATETIME' : {
      // console.log('formatting date');
      if (value === null || value === undefined) {
       returnValue = '';
      }
      //console.log("Original Value :" + CustomFormatter.formatDateWithTimestampString(value));
      //console.log("CustomMaskFlag : "  + formatStore);

      if(formatStore === "CUSTOMDATE"){
        console.log("Tag : "  + formatArr[3]);
        let mask = this.getMask(dateMask, formatArr[3]);
        mask = this.changeMask(mask) ;
        mask =  StringUtil.isNotEmpty(mask) ? mask : this.globals.dateFormat;

        console.log("Date fields from Collection : ");
        if(dateMask && dateMask.length > 0){
        dateMask.forEach(field => {
          console.log(field["tag"]);
        });
      }

        console.log("Tag present in collection fields : " + StringUtil.isNotEmpty(mask));
        console.log("Mask : " + mask);

        returnValue = CustomFormatter.formatDateWithTimestampString(value, mask);
      }
      else{
      returnValue = CustomFormatter.formatDateWithTimestampString(value , this.globals.dateFormat);
      }
      console.log("Formatted Value :" + returnValue);
      console.log("----------------------------------");
      break;
    }
    case 'DECRYPT': {
      if (value === null || value === undefined) {
        returnValue = '';
       }
       returnValue = this.globals.decryptData(value);
      break;
    }
    case 'DISPLAY-LABEL': {
      // console.log('combobox labels');
      if (value === null || value === undefined) {
        returnValue = '';
       }
       if (formatArr[1] !== undefined) {
          const dataProvider =  formatArr[1];
          const label = dataProvider && dataProvider.mapValueToLabel ? dataProvider.mapValueToLabel(value) || value || '' : '';
          returnValue = label;
    }
      break;
    }
  }
  return returnValue;


}

  detectDate(value:any){
    // const regex = /\b\d{4}[-/]\d{2}[-/]\d{2}\b/g;
    if(value !== undefined && value !== null){
      // const regex = /\b(?:\d{4}[-/]\d{2}[-/]\d{2}|\w{3} \d{1,2}, \d{4}|(?:\d{1,2}-\w{3}-\d{4}|\w{3,9} \d{1,2}, \d{4}))\b/g;
      const regex = /\b(?:\d{4}[-/]\d{2}[-/]\d{2}|\w{3} \d{1,2}, \d{4}|(?:\d{1,2}-\w{3}-\d{4}|\w{3,9} \d{1,2},\s?\d{4}))\b/g;
      const matches = value.toString().match(regex);
          if(matches && matches.length >0){
        return true;
      }else{
        return false;
      }
    }
  }
  getMask(dateMask,tag) : string{
    let mask : string = "";
      if(dateMask && dateMask.length > 0){
        dateMask.forEach(field => {
          if(field["tag"] == tag){
            mask = field["mask"];
          }
        });
      }
      return mask;
  }

  changeMask(mask:string)  : string{
    let maskFormatArr = [];
    let maskFormat = "";
    if(StringUtil.isNotEmpty(mask)){
        let maskArr = mask.split("/");
        if(maskArr && maskArr.length == 3){
          maskFormatArr = maskArr.map( x => {
            if(x.includes("DD") || x.includes("YY")){
                return x.toLowerCase();
            }
            return x;
          })
          maskFormat = maskFormatArr.join("/");
          return maskFormat;
        }
      }
    return "";
  }


  amountMask(amtArr , maskDec) : String{

    amtArr[0] =amtArr[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    if(amtArr[1]){
      amtArr[1] = amtArr[1].slice(0,maskDec);
    }else{
      amtArr[1] = "00";
    }

    return amtArr.join(".");

}
}
