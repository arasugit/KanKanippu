// $Id$
import { AfterContentInit, ComponentFactoryResolver, ComponentRef, Directive, EventEmitter,
  Input, OnChanges, OnDestroy, Output, SimpleChanges, ViewContainerRef, Type } from '@angular/core';
import { CustomRenderer, DataTableColumnComponent } from './data-table-column.component';
import { Permissions } from '../common/permissions';

@Directive({
  selector: '[appCellRenderer]'
})
export class CellRendererDirective implements OnChanges, AfterContentInit, OnDestroy {
  @Input() column: DataTableColumnComponent;
  @Input() row: any;
  @Input() permissions: Permissions;
  @Input() dataProvider: any;
  @Input() requestType: String;
  @Input() collectionTag: String;
  @Input() rowIndex: any;
  @Input() isMKCRequest = false;
  @Input() isReworkRequest = false;
  @Input() isCheckerView = false;
  @Input() userID: string;
  @Input() viewButtonTemplate: Type<any>;
  @Input() fields: any;
  @Output() collectionChanged = new EventEmitter<any>();
  @Output() cellClick = new EventEmitter<any>();

  private componentRef: ComponentRef<CustomRenderer>;
  originalRow: object;
  constructor(private viewContainerRef: ViewContainerRef, private componentFactoryResolver: ComponentFactoryResolver) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (this.componentRef !== undefined && this.componentRef !== null) {
      if (changes['dataProvider'] !== undefined && changes['dataProvider'] !== null) {
        const istRenderer: CustomRenderer = this.componentRef.instance;
        istRenderer.dataProvider = changes['dataProvider'].currentValue;
      }
    }
  }

  ngAfterContentInit() {
    if (this.column.itemRenderer && this.column.itemRenderer.component) {
      this.originalRow = Object.assign(new Object(), this.row);
      const cf = this.componentFactoryResolver.resolveComponentFactory(this.column.itemRenderer.component);
      this.ngOnDestroy();
      const vcf = this.viewContainerRef;
      if (vcf) {
        vcf.clear();
        this.componentRef = vcf.createComponent(cf);
        try {
          const istRenderer: CustomRenderer = this.componentRef.instance;
          if (this.column.itemRenderer.comboBoxType !== undefined) {
             istRenderer.comboBoxType = this.column.itemRenderer.comboBoxType ;
          }

          if (this.column.itemRenderer.isGlbVal !== undefined) {
            istRenderer.isGlbVal = this.column.itemRenderer.isGlbVal;
          } else {
            istRenderer.isGlbVal = false;
          }
          if (this.dataProvider !== undefined && this.dataProvider !== null) {
            istRenderer.dataProvider = this.dataProvider;
          }

          istRenderer.row = this.row;
          istRenderer.column = this.column;
          istRenderer.value = (this.row[this.column.dataField] !== null &&
                               this.row[this.column.dataField] !== undefined) ? (this.row[this.column.dataField] + '') : null;
          istRenderer.permissions = this.permissions;
          const onSelectedRowChange: EventEmitter<any> = new EventEmitter<any>();
          istRenderer.onSelectedRowChange = onSelectedRowChange;
          istRenderer.onSelectedRowChange.subscribe(row =>
            this.propagateRow(row)
          );
       
          istRenderer.rowIndex = this.rowIndex;
          const cellClick: EventEmitter<any> = new EventEmitter<any>();
          istRenderer.cellClick = cellClick;
           istRenderer.cellClick.subscribe(rowObj =>
            this.cellClicked()
          );
          istRenderer.isMKCRequest = this.isMKCRequest;
          istRenderer.isReworkRequest = this.isReworkRequest;
          istRenderer.userID = this.userID;
          istRenderer.isCheckerView = this.isCheckerView;
          istRenderer.fields = this.fields;
          if (this.viewButtonTemplate) {
            istRenderer.viewButtonTemplate = this.viewButtonTemplate;
            istRenderer.fields = this.fields;
          }
          
          this.componentRef.changeDetectorRef.detectChanges();
        } catch (error) { }
      }
    }
  }

  ngOnDestroy(): void {
    if (this.componentRef) {
      this.componentRef.changeDetectorRef.detach();
      this.componentRef.destroy();
      this.componentRef = null;
    }
  }

  propagateRow(value) {
    this.row[this.column.dataField] = value;
    if (this.column.dataField !== 'mkcStatus') {
      if (this.row.hasOwnProperty('dbAction')) {
        if (this.row['dbAction'] !== 'd') {   // added by yuva for acq entity
          this.row['dbAction'] = (this.row['dbAction'] === 'a') ? 'a' : 'c';
        } 
      }
    }
    const editedRow: any = {}; 
    editedRow.originalRow = this.originalRow;
    editedRow.row = this.row;
    editedRow.column = this.column;
    editedRow.requestType = this.requestType;
    editedRow.collectionTag = this.collectionTag;
    this.collectionChanged.emit(editedRow);
  }
  cellClicked() {
    const rowObj = {rowIndex: this.rowIndex, row: this.row};
    this.cellClick.emit(rowObj);
  }
}
