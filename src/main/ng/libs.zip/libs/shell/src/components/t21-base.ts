import { Input,Injectable,ChangeDetectorRef, Component} from '@angular/core';


// $Id$
export class IstToolTip {
    message: string;
    constructor(msg: string) {
      this.message = msg;
    }
  }

@Component({template: ''})
export abstract class T21Base {
    protected _metadataProvider: any;
    _focusFlag: boolean;
    _editType: string = 'text';
    changeDetectRef: ChangeDetectorRef;
    dataPropagated: boolean = false;
    toolTipCls: IstToolTip = new IstToolTip('');
    @Input() public sectionId: string;
    @Input() public  tabId: string;
    @Input() public  cntrlType: string;
    public componentType: string;
    @Input() public  tag: string;
    @Input() public type: string='text';
    @Input() public isDisabled: boolean = false;
    @Input() public isreadOnly: boolean = false;
    //@Input() editType: String;
    @Input() public cntrlLabel: string;
    @Input() public cntrlId: string;
    @Input() public restrict: string = '';
    @Input() public paramName: string;
    @Input() public width: any;
    @Input() public rows = 3;
    @Input() public minRows = 3;
    @Input() public id: string;
    @Input() public mandatorySymbol: string;
    @Input() public requiredColon: string;
    @Input() public toolTipMsg: string;
    @Input() public isMkcChange = false;
    @Input() public isCellEditor: boolean;  // to set the width of the combo box to the cell width
    @Input() public placeHolderText = '';
    @Input() public fxFlexLabelWidth ='40%';
    public _selfreference: any;


    @Input()
    set metadataProvider(value: any) {
        // console.log('ist-input tab Id passed ' , this.tabId , ' sectionId passed ', this.sectionId, ' tag :' , this.tag);
        if (value != null) {
            this._metadataProvider = value.tabs[this.tabId].sections[this.sectionId].fields[this.tag];
            if (this._metadataProvider !== undefined) {
                if (this.componentType &&
                    (this.componentType === 'IstInputComponent' || this.componentType === 'IstNumericStepperComponent')) {
                    this.setInputMaxLength();
                    this.setRestrict();
                    this.runChangeDetection();
                }
                if (this.componentType && this.componentType === 'IstComboBoxComponent') {
                    this.runChangeDetection();
                }
            }
        }
    }
    get metadataProvider(): any {
        return this._metadataProvider;
    }
    runChangeDetection() {
       // console.log('calling change detect from t21 base', this.tag);
       if (this.changeDetectRef) {
        this.changeDetectRef.detectChanges();
    }
      }
    setInputMaxLength() {
        this._selfreference.maxAllowedLen = this._metadataProvider.maxLength;
        this.adjustControlWidth();
       
    }
    adjustControlWidth() {
        this.width = this.width ? Number(this.width) : 0;
        if (this.width > 0) {
            this._selfreference.maxWidth = this.width;
        } else {
            this._selfreference.maxWidth = this._selfreference.maxAllowedLen * 10;
            if (this._selfreference.maxWidth < 50) {
                this._selfreference.maxWidth = 50;
            } else if (this._selfreference.maxWidth > 350) {
                this._selfreference.maxWidth = 350;
            }
        }
    }
    setRestrict() {
        if (this._metadataProvider.restrict !== null && this._metadataProvider.restrict !== '') {
            this.restrict = this._metadataProvider.restrict;
        } else {
            this.setPattern();
        }
    }
    setPattern() {
        this.restrict = this.restrict;
    }
    @Input()
    set editType(value: string) {
        this._editType = value;
        this._selfreference.setPattern();
    }
    get editType(): string {
        return this.type;
    }
    @Input()
    set focusFlag(value: boolean) {
        this._focusFlag = value;
        if (value) {
            this.setErrorMsg();
        } else {
            this.setErrorMsg();
        }
    }
    get focusFlag(): boolean {
        return this._focusFlag;
    }
    setErrorMsg() {
        return;
    }
    setToolTip() {
        this.toolTipCls = new IstToolTip(this.toolTipMsg);
    }
    setFocus() {
        // setTimeout(() => this.focusControl.nativeElement.focus());
      }
}
