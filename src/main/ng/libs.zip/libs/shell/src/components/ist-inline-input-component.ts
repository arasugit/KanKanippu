import { Component, ElementRef, forwardRef, OnInit, Input , ViewChild, Renderer2, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { T21Base } from './t21-base';
import { GlobalsService } from '../services/globals.service';
import { IstInputComponent } from './ist-input-component';

const noop = () => {
};

export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_INLINE_INPUT: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => IstInlineInputComponent),
  multi: true
};

export const T21BASE_ACCESSOR_INLINE_INPUT: any = {
  provide: T21Base,
  useExisting: forwardRef(() => IstInlineInputComponent),
  multi: true
};

@Component({
  selector: 'ist-inline-input',
  templateUrl: './ist-inline-input-template.html',
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_INLINE_INPUT, T21BASE_ACCESSOR_INLINE_INPUT]
})
export class IstInlineInputComponent extends IstInputComponent
  implements ControlValueAccessor, OnInit {
  constructor(public _renderer: Renderer2, public elem: ElementRef, protected globalService: GlobalsService,
       ref: ChangeDetectorRef) {
    super(elem, globalService, ref);
    this.componentType = 'IstInlineInputComponent';
    this._selfreference = this;
    this.mandatorySymbol = '';
    this.requiredColon = ' : ';
    this.required = false;
    this.disabled = false;
    this.preValue = '';
    this.editing = false;
  }
  @ViewChild('inlineEditControl', { static: false }) inlineEditControl; // input DOM element
  @Input() required: boolean; // Is input requried?
  @Input() disabled: boolean; // Is input disabled?
  @Input() row:any;
  @Output() itemClick = new EventEmitter<any>();
  private preValue: string; // The value before clicking to edit
  public editing: boolean; // Is Component in edit mode?

  // Do stuff when the input element loses focus
  onBlur($event: Event) {
   this.applyFormatter();
   this.editing = false;
  }

  // Start the editting process for the input element
  edit(value) {
    if (this.disabled) {
      return;
    }
    if (this.row) {
      if (this.row['dbAction'] !== 'd' && this.row.dbAction !== 'dummy') {
        this.globalService.setRowToBeHighlighted(this.row);
      }
      if (this.row.dbAction !== 'dummy') {
        this.itemClick.emit(this.row);
      }
    }
    this.preValue = value;
    this.editing = true;

    setTimeout(() => {
      this.inlineEditControl.nativeElement.focus();
    }, 2);
  }
}
