import { AfterContentInit, ChangeDetectorRef, Component, ComponentFactoryResolver, ContentChildren, EventEmitter, forwardRef, Input, OnChanges, OnDestroy, OnInit, Output, QueryList, SimpleChanges, ViewContainerRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { StringUtil } from '../common/ist-string-util';
import { CommonConstants } from '../common/ist.common.constants';
import { Permissions } from '../common/permissions';
import { DataTableColumnComponent, RendererItem } from './data-table-column.component';
import { T21Base } from './t21-base';
import { DataTableService } from '../services/data-table.service';
import { GlobalsService } from '../services/globals.service';
import { WorkCollection, WorkCollectionCollection, WorkField, WorkRequest } from '../ist-components/work-request-model';
import { ColumnOnDemand } from './column-on-demand.component';
import { AbstractDataTableComponent, DataTableSource } from './abstract-data-table.component';
declare var require: any;

export const T21BASE_ACCESSOR_DETAIL2: any = {
  provide: T21Base,
  useExisting: forwardRef(() => DataTableEditableDetail2Component),
  multi: true
};

export const ISTDATATABLE_ACCESSOR_DETAIL2: any = {
  provide: AbstractDataTableComponent,
  useExisting: forwardRef(() => DataTableEditableDetail2Component),
  multi: true
};

@Component({
  selector: 'app-data-table-editable-detail2',
  templateUrl: 'data-table-editable-detail2.component.html',
  providers: [T21BASE_ACCESSOR_DETAIL2, ISTDATATABLE_ACCESSOR_DETAIL2],
  styles: [
    `.highlight {
        background: #fef8cc;
      }
      .delete {
        background: #a9a9a9;
      }
      .error {
        background: #a9a9a9;
      }
    `
  ]
})
export class DataTableEditableDetail2Component extends AbstractDataTableComponent
  implements OnInit, AfterContentInit, OnDestroy, OnChanges {
  criteria: {};
  length = 0;
  isLoadingResults = false;
  loadingMessage: string;
  workRequest: WorkRequest;
  changedRecords: any[] = [];
  subscription: Subscription;
  singleViewButtonRenderer: RendererItem;
  _txtFilterData = '';
  @Input() showPaginator = true; // By default show paginator
  @Output() itemClick = new EventEmitter<any>();
  @Output() itemEditEnd = new EventEmitter<any>();
  @Output() rowAdded = new EventEmitter<any>();
  @Input() action: String;

  @Input() remoteClass: String; // Did not find another way to get it for now
  columnsArray:string[] = [];
  @Input() query = false; // Not permitted by default; this input is not required here as search button is at the form level itself.
  @Input() insert = false; // Not permitted by default; expecting input from the actual form
  @Input() update = false; // Not permitted by default; expecting input from the actual form
  @Input() delete = false; // Not permitted by default; expecting input from the actual form
  @Input() checker = false; // Not permitted by default; expecting input from the actual form
  @Input() mkc = false; // Not permitted by default; expecting input from the actual form
  @Input() filterRequired = false;
  @Input() showAdd = true;
  @Input() showDelete = true;

  // To keep the entitlement permissions to pass on to column level (may be find another way of doing this later)
  permissions: Permissions;

  /**
   * list of column names which are to be displayed. Can be modified; must be a subset of the
   * names of columns in allColumns.
   * Will take a string which is a comma-separated list of names (no quotes), or an array of names.
   */
  displayedColumns: string[] = [];

  //prat
  defaultPageSize = 0; currentPageIndex = 0;
  startIndex = 0; endIndex = 0;
  @Input()
  set columnsToDisplay(val: string | string[]) {
    if (typeof val === 'string') {
      this.displayedColumns = val.split(/\s*,\s*/);
    } else {
      this.displayedColumns = val;
    }
  }

  @Input() dataTableId: String;

  @ContentChildren(DataTableColumnComponent)
  protected columnElements: QueryList<DataTableColumnComponent>;

  rowToBeHighlighted: object;

  protected columnsOndemand: ColumnOnDemand[] = [];

  userID: string;

  constructor(
    private dataTableService: DataTableService,
    private changeDetector: ChangeDetectorRef,
    public globals: GlobalsService,
    public componentFactoryResolver: ComponentFactoryResolver,
    public viewContainerRef: ViewContainerRef,
    public dialog: MatDialog
  ) {
    super(globals, componentFactoryResolver, viewContainerRef, dialog);
    this.changedRecords = [];
    // Subscribe to row changes from the data table column level
    this.subscription = this.dataTableService.changedRowObservable$.subscribe(
      event => {
        this.gatherChangedRow(event);
      }
    );
    this.permissions = {};
    const pagesize = this.globals.configOptions['ist.editable.dg.default_page_size'];
    this.defaultPageSize = pagesize ? Number(pagesize) : 50;
  }

  ngOnInit() {
    this.userID = this.globals.userContext.userID;
  }

  ngAfterContentInit() {
    if (this.columnElements && this.columnElements.length > 0) {
      this.allColumns = this.columnElements.toArray();
    }
    if (this.displayedColumns.length === 0) {
      this.displayedColumns = this.allColumns.map((col: DataTableColumnComponent) => col.name);
    }
    this.allColumns.forEach(element => {
      if (element.visible === true) {
        if (element.editable === undefined) {
          // If nothing is set at column level, set editable to true
          element.editable = true;
        }
      } else {
        const index = this.displayedColumns.indexOf(element.name);
        if (index > -1) {
          this.displayedColumns.splice(index, 1);
        }
      }
    });

    if (this.allColumns !== null && this.allColumns !== undefined && this.allColumns.length > 0) {
      for (const val in this.allColumns) {
        const obj: any = this.allColumns[val];
        this.columnsArray.push(obj.name);
      }
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    try {
      this.consolidatePermissions(changes);
      this.setOtherInputs(changes);
      if (changes['metadataProvider'] !== undefined && changes['metadataProvider'] !== null) {
        if (changes['metadataProvider'].currentValue) {
          super.collectUIMetaDataFieldInformation(changes['metadataProvider'].currentValue);
        }
      }
      let records: any[];
      if (changes['dataProvider'] !== undefined && changes['dataProvider'] !== null) {
        if (Array.isArray(changes['dataProvider'].currentValue)) {
          records = changes['dataProvider'].currentValue;
        } else {
          // Try with WorkRequest
          this.workRequest = changes['dataProvider'].currentValue;
          records = this.workRequest.collections['' + this.collectionTag].rows;
          this.addColumn();
          this.setMKCRequest();
        }
        // Load the datatable records
        this.loadRecords(records);
      }
    } catch (e) {
      // ignore
    } finally {
      this.clearFlags();
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  // Decide on whether it is a MKC/Rework request??
  setMKCRequest() {
    if (this.workRequest && this.mkc) {
      if (this.workRequest.mkcId && this.workRequest.mkcId > 0) {
        this.isMKCRequest = true;
        if (
          this.workRequest.mkcStatus &&
          this.workRequest.mkcStatus === 'W' &&
          this.action === CommonConstants.MKC_ACTION_REWORK_EDIT
        ) {
          this.isReworkRequest = true;
        } else {
          this.isReworkRequest = false;
        }
      } else {
        this.isMKCRequest = false;
      }
    }
  }

  isChecker(): Boolean {
    if (this.workRequest && this.isMKCRequest && this.checker) {
      if (this.workRequest.mkcStatus && this.workRequest.mkcStatus === CommonConstants.MKC_STATUS_SUBMIT &&
        this.workRequest.makerId && this.workRequest.makerId !== this.globals.userContext.userID) {
        return true;
      }
    }
    return false;
  }

  evaluateAdd(): Boolean {
    if (!(this.insert) || this.isChecker() || (this.isMKCRequest && !this.isReworkRequest)) {
      return true;
    }

    return false;
  }

  evaluateDelete(): Boolean {
    if (!(this.delete) || this.rowToBeHighlighted === undefined || this.rowToBeHighlighted === null) {
      return true;
    }

    if ((!(this.insert) && !(this.update)) || this.isChecker() || (this.isMKCRequest && !this.isReworkRequest)) {
      return true;
    }

    return false;
  }

  // This method will be called when there is a change in the dataProvider.
  loadRecords(records: any[]) {
    try {
      if (records && records !== undefined) {
        if (records.length <= 0) {
          this.showDummy();
        } else {
          records.forEach(record => {
            record['remoteClass'] = this.remoteClass;
          });
          this.loadData(records);
        }
      }
    } catch (e) {
      // Ignore
    }
  }

  protected addColumn() {
    this.columnsOndemand.forEach(column => {
      const columnFactory = this.componentFactoryResolver.resolveComponentFactory(DataTableColumnComponent);
      const col = this.viewContainerRef.createComponent(columnFactory);
      col.instance.itemRenderer = column.renderer;
      col.location.nativeElement.innerHTML = '';
      col.instance.editable = column.editable;
      col.instance.header = column.header ? column.header : 'Header';
      col.instance.name = column.name ? column.name : 'name';
      col.instance.dataField = column.dataField ? column.dataField : 'dataField';
      col.instance.labelFunction = column.expression;
      this.allColumns.push(col.instance);
      this.displayedColumns.push(col.instance.name);
    });
  }

  addColumnsOnDemand(col: ColumnOnDemand) {
    if (col) {
      this.columnsOndemand.push(col);
    }
  }

  highlightRow(row): void {
    if (row) {
      if (row['dbAction'] !== 'd' && row.dbAction !== 'dummy') {
        this.rowToBeHighlighted = row;
      }
      if (row.dbAction !== 'dummy') {
        this.itemClick.emit(row);
      }
    }
  }

  deleteRow(): void {
    if (!this.rowToBeHighlighted) {
      this.globals.showDialog(
        CommonConstants.WARNING,
        'ERR34',
        CommonConstants.ALERT_OK
      );
      return;
    }

    if (
      this.rowToBeHighlighted['dbAction'] === 'a' ||
      this.rowToBeHighlighted['dbAction'] === '' ||
      this.rowToBeHighlighted['dbAction'] === undefined ||
      this.rowToBeHighlighted['dbAction'] === null
    ) {
      // Remove it from the grid.
      if (this.workRequest) {
        const rows = this.workRequest.collections['' + this.collectionTag].rows;
        if (rows.indexOf(this.rowToBeHighlighted) > -1) {
          rows.splice(rows.indexOf(this.rowToBeHighlighted), 1);
          this.workRequest.collections['' + this.collectionTag].rows = rows;
          this.loadRecords(this.workRequest.collections['' + this.collectionTag].rows);
        }
      }
      if (this.changedRecords.indexOf(this.rowToBeHighlighted) > -1) {
        this.changedRecords.splice(this.changedRecords.indexOf(this.rowToBeHighlighted), 1);
      }
      this.changeDetector.detectChanges();
      this.rowToBeHighlighted = {};
      return;
    }

    if (this.rowToBeHighlighted['dbAction'] !== 'd') {
      this.globals.showDialog(CommonConstants.WARNING,'MSG11',CommonConstants.ALERT_YES_NO)?.subscribe(result => {
          if ('Yes' === result) {
            this.rowToBeHighlighted['dbAction'] = 'd';
            this.rowToBeHighlighted['remoteClass'] = this.remoteClass; // Add the remote class set by the actual form
            const index = this.changedRecords.indexOf(this.rowToBeHighlighted);
            if (index > -1) {
              this.changedRecords.splice(index, 1); // Remove old changes
            }
            this.changedRecords.push(this.rowToBeHighlighted); // Add the fresh changes
            this.changeDetector.detectChanges();
            this.rowToBeHighlighted = {};
          }
        });
    }
  }

  deleteSpecificRow(rowRowToBeDeleted: any) {
    if (rowRowToBeDeleted) {
      this.rowToBeHighlighted = rowRowToBeDeleted;
      this.deleteRow();
    }
  }

  addRow(): any {
    const newRecord = this.newRow();
    if (!this.workRequest) {
      this.workRequest = new WorkRequest();
      const collections: WorkCollectionCollection = {};
      collections['' + this.collectionTag] = new WorkCollection(); // Normal set method of map is not working
      this.workRequest.collections = collections;
      // Single page save method expects workRequest.getFields(); but actually no use for this
      this.addWorkFields(this.workRequest, this.fields);
    }

    // Adding the new row as first record
    if (this.workRequest.collections === undefined) {
      const collections: WorkCollectionCollection = {};
      this.workRequest.collections = collections;
    }

    if (this.workRequest.collections['' + this.collectionTag] === undefined) {
      this.workRequest.collections['' + this.collectionTag] = new WorkCollection();
    }

    if (this.workRequest.collections['' + this.collectionTag].rows === undefined) {
      this.workRequest.collections['' + this.collectionTag].rows = [];
    }

    this.workRequest.collections['' + this.collectionTag].rows.splice(this.startIndex, 0, newRecord);
    this.loadRecords(this.workRequest.collections['' + this.collectionTag].rows);
    this.rowAdded.emit(newRecord); // Used in IST MAS GUI
    this.highlightRow(newRecord);
    this.changeDetector.detectChanges();
    return newRecord;
  }

  newRow(forNewRecord: Boolean = true): any {
    let newRecord = {};
    if (forNewRecord) {
      // For dummy row we do not need default values to be populated.
      newRecord = {
        remoteClass: this.remoteClass,
        inactive: '',
        dbAction: 'a',
        errorFlag: null,
        errorMessage: null
      };
      this.allColumns.map((col: DataTableColumnComponent) => {
        newRecord[col.dataField] = col.defaultValue;
        if (col.labelFunction) {
          newRecord[col.dataField] = col.labelFunction(newRecord, col);
        }
      });
    }
    return newRecord;
  }

  gatherChangedRow(event: any) {
    if (event.collectionTag && event.requestType && event.row) {
      if (this.requestType === event.requestType && this.collectionTag === event.collectionTag) {
        const index = this.changedRecords.indexOf(event.row);
        if (index > -1) {
          this.changedRecords.splice(index, 1); // Remove old changes for this record
        }
        if (event.row['remoteClass'] === undefined || event.row['remoteClass'] === null) {
          event.row['remoteClass'] = this.remoteClass; // Add the remote class set by the actual form
        }
        this.changedRecords.push(event.row); // Add the fresh changes for this record
        this.changeDetector.detectChanges();
        this.addOldRow(event);
        this.itemEditEnd.emit(event);
      }
    }
  }

  addWorkFields(wr: WorkRequest, fields: any) {
    // Adding dummy work field to the workrequest; save method in java just checks whether
    // workRequest.getFields() is not null before continuing to save
    const wf: WorkField = new WorkField();
    wf.tag = 'dummy';
    const flds: { [fieldName: string]: WorkField } = {};
    flds[wf.tag] = wf;
    wr.fields[wf.tag] = wf;
  }

  consolidatePermissions(changes: SimpleChanges): void {
    if (changes['insert'] !== undefined && changes['insert'] !== null) {
      this.insert = changes['insert'].currentValue;
      this.permissions['I'] = this.insert;
    }
    if (changes['update'] !== undefined && changes['update'] !== null) {
      this.update = changes['update'].currentValue;
      this.permissions['U'] = this.update;
    }
    if (changes['delete'] !== undefined && changes['delete'] !== null) {
      this.delete = changes['delete'].currentValue;
      this.permissions['D'] = this.delete;
    }
    if (changes['checker'] !== undefined && changes['checker'] !== null) {
      this.checker = changes['checker'].currentValue;
      this.permissions['C'] = this.checker;
    }
    if (changes['mkc'] !== undefined && changes['mkc'] !== null) {
      this.mkc = changes['mkc'].currentValue;
      this.permissions['mkc'] = this.mkc;
    }
  }

  setOtherInputs(changes: SimpleChanges) {
    if (changes['action'] !== undefined && changes['action'] !== null) {
      this.action = changes['action'].currentValue;
      this.dataTableService.action = this.action;
    }

    if (changes['requestType'] !== undefined && changes['requestType'] !== null) {
      this.requestType = changes['requestType'].currentValue;
      this.dataTableService.requestType = this.requestType;
    }

    if (changes['collectionTag'] !== undefined && changes['collectionTag'] !== null) {
      this.collectionTag = changes['collectionTag'].currentValue;
      this.dataTableService.collectionTag = this.collectionTag;
    }
  }

  checkChange(): boolean {
    return (
      this.changedRecords !== undefined &&
      this.changedRecords !== null &&
      this.changedRecords.length > 0
    );
  }

  showDummy(): void {
    const row = this.newRow(false);
    row.dbAction = 'dummy'; // No need to edit this row.
    const newRow = [].concat(row);
    this.dataSource = new DataTableSource(newRow);
    this.length = newRow.length;
    this.totalRecords = 0;
  }

  protected addOldRow(event) {
    if (this.workRequest && event.originalRow) {
      // Add originalRow as 'OLDCOLLECTIONS' so that the ISTAudit record stores the original record
      // for comparison (old and new data) later on the ISTAuditResearchScreen
      const collections: WorkCollectionCollection = this.workRequest
        .collections;
      if (collections.OLDCOLLECTIONS === undefined) {
        collections.OLDCOLLECTIONS = new WorkCollection();
      } else {
        collections.OLDCOLLECTIONS.remoteClass = WorkCollection.remoteClassName;
      }
      const oldRows: any[] = this.workRequest.collections.OLDCOLLECTIONS.rows;
      if (oldRows.indexOf(event.originalRow) === -1) {
        if (event.originalRow.dbAction === 'x') {
          oldRows.push(event.originalRow);
        }
      }
    }
  }

  clearFlags() {
    this.globals.hideLoadingBar();
  }
  public loadData(fielddata: any[]) {
    this.startIndex = this.currentPageIndex * this.defaultPageSize;
    this.endIndex = this.startIndex + this.defaultPageSize;
    this.endIndex = (this.endIndex >= fielddata.length) ? fielddata.length : this.endIndex;
    this.dataSource = new DataTableSource(fielddata.slice(this.startIndex, this.endIndex));
    this.dataSource.sort = this.sort;
    this.length = fielddata.length;
    this.totalRecords = this.length;
  }
  public previous() {
    this.currentPageIndex--;
    this.loadData(this.workRequest.collections['' + this.collectionTag].rows);
  }
  public next() {
    this.currentPageIndex++;
    this.loadData(this.workRequest.collections['' + this.collectionTag].rows)
  }

  get txtFilterData(): any {
    return this._txtFilterData;
  }

  set txtFilterData(value: any) {
    this._txtFilterData = value;
    let filteredData: any[] = [];
    const dgData: any[] = this.workRequest.collections[this.collectionTag].rows;
    if (StringUtil.isNotEmpty(value) && dgData !== undefined && dgData !== null && dgData.length > 0) {
      filteredData = dgData.filter(row => (this.filterIt(row)));
    } else {
      filteredData = dgData;
    }
    this.currentPageIndex = 0;
    this.loadRecords(filteredData);
  }

  private filterIt(row: any) {
    let flag = false;
    for (const str in row) {
      if (this.columnsArray.indexOf(str) > -1) {
        const obj = row[str];
        if (obj !== undefined && obj !== null &&
          obj.toString().search(new RegExp(this._txtFilterData, 'i')) !== -1) {
          flag = true;
          break;
        }
      }
    }
    return flag;
  }

  updateWorkCollection(rowIndex: any, rowData: any) {
    this.workRequest.collections['' + this.collectionTag].rows.splice(this.startIndex + rowIndex, 1);
    this.workRequest.collections['' + this.collectionTag].rows.splice(this.startIndex + rowIndex, 0, rowData);
  }
}