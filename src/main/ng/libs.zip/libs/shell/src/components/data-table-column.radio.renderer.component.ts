// $Id$
import { AfterContentInit, Component, HostListener, OnInit } from '@angular/core';
import { CustomRenderer } from './data-table-column.component';

@Component({
    selector: 'app-data-column-radio-renderer',
    template: `<mat-radio-button fisStyle [id]="id">{{value}}</mat-radio-button>`
})
// Radio renderer example for the data table column
export class DataTableColumnRadioRendererComponent extends CustomRenderer implements OnInit, AfterContentInit {
    id: any;
    constructor() {
        super();
    }
    ngOnInit() {
        //  console.log('(DataTableColumnRadioRendererComponent onInit()): ');
    }

    ngAfterContentInit() {
        //  console.log('(DataTableColumnRadioRendererComponent ngAfterContentInit()): ');
    }

    propagateChangedRow(row: any): void {
        //  console.log('Propogating changed row DataTableColumnRadioRendererComponent');
    }

    isDisabled(): Boolean {
        return false;
    }

    @HostListener('click', ['$event'])
    onclick(event: Event) {
        if (this.row['dbAction'] === 'd') {
            event.preventDefault();
            return;
        }
    }
}
