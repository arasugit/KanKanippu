// $Id$
import {
  Component,
  EventEmitter,
  ViewChild,
  forwardRef,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ChangeDetectorRef,
  ChangeDetectionStrategy
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { T21Base } from './t21-base';
import { WorkField, WorkRequest } from '../ist-components/work-request-model';
import { StringUtil } from '../common/ist-string-util';
import { LabelAndValue, LabelsAndValues } from '../common/labels-and-values';
import { InstService } from '../services/inst.service';
import {MatOption} from '@angular/material/core';
import { MonConfigService } from '../services';
const noop = () => {};

export const MON_MULTI_SELECT_VALUE_ACCESSOR_COMBO: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => MonComboBoxMultiSelectComponent),
  multi: true
};
export const MON_MULTI_T21BASE_ACCESSOR_COMBO: any = {
  provide: T21Base,
  useExisting: forwardRef(() => MonComboBoxMultiSelectComponent),
  multi: true
};
@Component({
  selector: 'mon-comboboxmultiselect',
  templateUrl: './mon-comboboxmultiselect.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [MON_MULTI_SELECT_VALUE_ACCESSOR_COMBO, MON_MULTI_T21BASE_ACCESSOR_COMBO]
})
export class MonComboBoxMultiSelectComponent extends T21Base implements ControlValueAccessor, OnInit, OnChanges {
  constructor(protected instService: InstService, protected monConfService: MonConfigService,protected ref: ChangeDetectorRef) {
    super();
    this.changeDetectRef = ref;
    this.componentType = 'MonComboBoxMultiSelectComponent';
    this.mandatorySymbol = '';
    this.requiredColon = ' : ';
  }

  @ViewChild('focusControl', { static: false })
  focusControl: any;

  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;
  @Output() onSelectedValueChange = new EventEmitter<any>();

  maxWidth: number;
  private _requestProvider: WorkRequest;
  _dataProvider: LabelsAndValues = new LabelsAndValues();
  private _workField: WorkField;
  private _errorString: string;
  @Input() public cntrlLabel:string='';

  @Input() chooseString: string = '--select--';
  @Input() option: boolean = false;
  @Input() fromGlobalValueCtrl: boolean;
  @Input() fromMonGlobalValueCtrl: boolean;
  @Input() institutionID: string;
  @Input() cardScheme;
  _staticDataProvider: any;
  @Input() siteId;
  @Input() optionalField: boolean = true;
  @Input() integerValue: boolean = false;
  @Input() cntryCode;
  @Input() currCode;
  @Input() reset: boolean = false;
  @Input() wildCardRequired: boolean = false;
  @Input() plainDataList:boolean = false;
  @Input() disableClickEvent:boolean = false;
  @Input() public type: string = 'combobox';
  @Input() public isCellEditor: boolean=false;
  @Input() public isDisabled: boolean=false;
  // public bgColor: string;
  _selectedValue = '';
  get selectedValue() {
    return this._selectedValue;
  }

  @Input()
  set staticDataProvider(v: any) {
    this._staticDataProvider = v;
    this.filterMerchantType(this.cardScheme);
  }

  get staticDataProvider() {
    return this._staticDataProvider;
  }
  onComboBoxClick(event: Event) {
    if (this.disableClickEvent) {
      event.stopPropagation();
      console.log(' combo ctrl clicked stopped', this.tag, this.disableClickEvent);
    }
  }

  @Input()
  set dataProvider(v: any) {
    if (this.plainDataList) {
      this._dataProvider = new LabelsAndValues();
      this._dataProvider.convertToLabelValues(v);
      this.addEmptyRow();
      this.ref.markForCheck();
      return;
    }
    this._dataProvider = v;
    if (this.integerValue && v !== null) {
      for (let pos = 0; pos < this._dataProvider.array.length; pos++) {
        if (
          this._dataProvider.array[pos].value !== undefined &&
          this._dataProvider.array[pos].value !== null
        ) {
          this._dataProvider.array[pos].value =
            this._dataProvider.array[pos].value + '';
        }
      }
    }

    this.addEmptyRow();
    this.ref.markForCheck();
  }

  get dataProvider() {
    return this._dataProvider;
  }
  @Input()
  set selectedValue(v: any) {
    let val = v;
    let selectedVal = this._selectedValue;

    if (this.integerValue && selectedVal !== null) {
      selectedVal = selectedVal + '';
    }
    if (this.integerValue && val !== null) {
      val = val + '';
    }
   
    if (val !== selectedVal) {
      this._selectedValue = v;

      if (
        this._requestProvider != null &&
        this._requestProvider.fields[this.tag] != null
      ) {
        this._requestProvider.fields[this.tag].value = this._selectedValue;
      }
      this.onChangeCallback(v);
      
    }
    this.ref.markForCheck();
  }

  @Input()
  set requestProvider(value: WorkRequest) {
    this._requestProvider = value;
    if (
      this.tag != null &&
      this._requestProvider != null &&
      this._requestProvider.fields[this.tag] != null
    ) {
      this.setWorkField(this._requestProvider.fields[this.tag]);
      this.setFirstItemSelected(this._workField.value);
    }
  }
  get requestProvider(): WorkRequest {
    return this._requestProvider;
  }


  setWorkField(value: WorkField) {
    this._workField = value;
    if (this._workField != null) {
      if (
        this._workField.value !== undefined &&
        this._workField.value !== null
      ) {
        this.selectedValue = this._workField.value + '';
      } else {
        this.selectedValue = this._workField.value;
      }
      this.selectedValue = this._workField.value;

      this.includeNewValueInList();
      if (
        this._workField.style !== undefined &&
        this._workField.style === 'mkcStyle'
      ) {
        // this.bgColor = 'yellow';
        this.isMkcChange = true;
        this.toolTipMsg = this._workField.oldValue;
        this.setToolTip();
      } else {
        this.isMkcChange = false;
        this._workField.oldValue = this._workField.value;
      }

      if (this._workField.modifyable === 'N') {
        this.isDisabled = true;
      }
      // set errorString
      if (this._workField.errorInfo !== '') {
        this._errorString = this._.errorInfo;
        this.toolTipMsg = this._errorString;
      } else {
        this._errorString = '';
        this.toolTipMsg = '';
      }
    }
  }
  /*** Method for Dynamically Adding the value for not configured in Global value ctrl ***/
  includeNewValueInList()  {
    if (this.fromGlobalValueCtrl && StringUtil.isNotEmpty(this.selectedValue)) {
      if(this._dataProvider.mapValueToDataProvider(this.selectedValue+'')){
          }else{
        this._dataProvider.array.push(new LabelAndValue(this.selectedValue, this.selectedValue));
         }
    }
  }
  ngOnChanges(changes: SimpleChanges) {
    if (this.fromGlobalValueCtrl || this.fromMonGlobalValueCtrl ) {
    if (this.fromMonGlobalValueCtrl) {
      if (StringUtil.isNotEmpty(this.type)) {
        this.monConfService
          .getMonGlobalFieldValueList(this.type)
          .subscribe((x: LabelsAndValues) => {
            this.dataProvider = x;
          });
      }
    }else
    if (this.fromGlobalValueCtrl) {
      if (StringUtil.isNotEmpty(this.type)) {
        this.instService
          .getGlobalValueCtrlList(this.type)
          .subscribe((x: LabelsAndValues) => {
            this.dataProvider = x;
          });
      }
    }} else {
      if (this.institutionID !== undefined) {
        if (
          StringUtil.isNotEmpty(this.institutionID) &&
          StringUtil.isNotEmpty(this.type)
        ) {
          this.instService
            .getComboBoxListByInstitution(this.institutionID, this.type)
            .subscribe((x: LabelsAndValues) => {

              this.dataProvider = x;
            });
        } else {
          // don't do anything
        }
      } else if (StringUtil.isNotEmpty(this.cardScheme)) {
        if (!this.staticDataProvider) {
          this.instService
            .getMerchantTypeList(this.cardScheme)
            .subscribe((x: LabelsAndValues) => {
              this.dataProvider = x;
            });
        } else {
          this.filterMerchantType(this.cardScheme);
        }
      } else if (StringUtil.isNotEmpty(this.siteId)) {
        this.instService
          .getNodeNameList(this.siteId)
          .subscribe((x: LabelsAndValues) => {
            this.dataProvider = x;
          });
      } else if (StringUtil.isNotEmpty(this.cntryCode)) {
        this.instService
          .getComboBoxListByParameter(this.cntryCode, this.type)
          .subscribe((x: LabelsAndValues) => {
            this.dataProvider = x;
          });
      } else if (StringUtil.isNotEmpty(this.currCode)) {
          this.instService
            .getComboBoxListByParameter(this.currCode, this.type)
            .subscribe((x: LabelsAndValues) => {
              this.dataProvider = x;
       });
      } else if (StringUtil.isNotEmpty(this.type) && this.type !== 'combobox') {
        this.instService
          .getDBRecords(this.type)
          .subscribe((x: LabelsAndValues) => {
            this.dataProvider = x;
          });
      } else if (this.type === 'combobox' && !this.dataProvider) {
        this.instService
          .getDBRecords(this.type)
          .subscribe((x: LabelsAndValues) => {
            this.dataProvider = x;
          });
      } else {
      }
    }
    if (changes['reset'] !== undefined && changes['reset'] !== null) {
     
      // so reset the status to Submit i.e 'S'
      this.reset = changes['reset'].currentValue;
      if (this.reset === true) {
        this.selectedValue = 'S';
      }
    }
  }

  filterMerchantType(cardScheme: string) {
    if (this._staticDataProvider === undefined) {
      return;
    }

    let entry: LabelAndValue;
    const res = new LabelsAndValues();
    for (entry of this.staticDataProvider.array) {
      if (entry.record[2] === cardScheme || cardScheme === undefined) {
        res.array.push(
          new LabelAndValue(entry.record[1], entry.record[0], entry.record)
        );
      }
    }
    this.dataProvider = res;
  }
  ngOnInit() {
    this._errorString = '';
  }

  addEmptyRow() {
    if ( this.wildCardRequired && this.dataProvider && this.dataProvider !== null) {
      this.dataProvider.addWildCardForBIN();
    }
    if (String(this.optionalField) === 'true' && this.dataProvider && this.dataProvider !== null) {
      this.dataProvider.addEmptyRow();
    }
    if (!this.isCellEditor) {
      this.width = this.width ? Number(this.width) : 0;
      if (this.width === 0 && this.dataProvider && this.dataProvider !== null) {
        this.resizeComponentWidth();
      } else if (this.width > 0) {
        this.maxWidth = this.width;
      }
    }
    this.setFirstItemSelected(undefined);
  }

  setFirstItemSelected(val?:any) {
     // Set selected index to 1 if only one item there
     if (
      String(this.optionalField) === 'false' &&
      this.dataProvider &&
      this.dataProvider !== null &&
      this.dataProvider.array !== undefined &&
      this.dataProvider.array.length === 1
    ) {
      if (StringUtil.isEmpty(val))  // if value ie empty, set the first item selected
          this.selectedValue = this.dataProvider.array[0].value;
    }
  }

  writeValue(value: any) {
    this.selectedValue = value;
    this.emit();
  }

  onBlur() {
    this.onTouchedCallback();
  }

  registerOnChange(fn: any) {
    this.onChangeCallback = fn;
  }

  registerOnTouched(fn: any) {
    this.onTouchedCallback = fn;
  }

  emit() {
   // console.log('emit called in dropdown', this.selectedValue);
    this.onSelectedValueChange.emit(this.selectedValue); // This is for custom renderers
  }

  clearValue(): void {
    this.errorString = '';
    this.selectedValue = '';
    this.onChangeCallback(this.selectedValue);
  }

  getValue(): any {
    return this._selectedValue;
  }
  resizeComponentWidth() {
    let maxLabelLength = 0;
    if (this.dataProvider) {
      const listOfItems: LabelAndValue[] = this.dataProvider.array;
      if (listOfItems !== undefined) {
        for (let i = 0; i < listOfItems.length; i++) {
          const item = listOfItems[i];
          if (item.label) {
            if (maxLabelLength < item.label.length) {
              maxLabelLength = item.label.length;
            }
          }
        }
      }
    }
    this.width = this.width ? Number(this.width) : 0;
    if (this.width > 0) {
      this.maxWidth = this.width;
    } else {
      this.maxWidth = maxLabelLength * 15;
      if (this.maxWidth < 50) {
        this.maxWidth = 50;
      } else if (this.maxWidth > 300) {
        this.maxWidth = 300;
      }
    }
  }

  set errorString(errStr: string) {
    this._errorString = errStr;
  }

  get errorString(): string {
    return this._errorString;
  }
  getDataProvider(): LabelsAndValues {
    return this.dataProvider;
  }
  trackByList(index, item) {
    return item.value;
  }
  setFocus() {
    setTimeout(() =>  this.focusControl.nativeElement.focus());
  }

  disableTooltip(element: MatOption) {
    if(element != undefined)
    return element?._getHostElement()?.firstElementChild?.scrollWidth === element?._getHostElement()?.firstElementChild?.clientWidth;
  }

  getLabel(val: string): string |undefined {
    if (this.dataProvider) {
      const listOfItems: LabelAndValue[] = this.dataProvider.array;
      if (listOfItems !== undefined) {
        for (let i = 0; i < listOfItems.length; i++) {
          const item = listOfItems[i];
          if (item.value === val) {
            return item.label;
          }
        }
      }
     }
  }
}
