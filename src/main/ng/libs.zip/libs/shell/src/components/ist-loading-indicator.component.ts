import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'ist-loading-indicator',
  templateUrl: 'ist-loading-indicator.template.html'
})
export class IstLoadingIndicatorComponent implements OnChanges {
  @Input() show = false;
  @Input() message: string = 'Loading';

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['show'] !== undefined && changes['show'] !== null) {
      this.show = changes['show'].currentValue;
    }
    if (changes['message'] !== undefined && changes['message'] !== null) {
      const msg: String = changes['message'].currentValue;
      if (msg !== '' && msg !== undefined && msg !== null) {
        this.message = msg as string;
      }
    }
  }
}
