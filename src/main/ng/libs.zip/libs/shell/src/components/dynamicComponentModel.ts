import { LabelsAndValues } from '../common/labels-and-values';

export class DynamicComponent {
  public type: string;
  public name: string;
  public label: string;
  public maxChar: number;
  public width: number;
  public restrict: string;
  public paramValue: string;
  public optionList: any;
  public dataProvider: LabelsAndValues;
  public disable: Boolean = false;
  public fromGlobalValueCtrl: Boolean = false;
  public comboboxtype: string;
  public inputType: string;
  public isDriver: Boolean;
  constructor(type, name, label, maxChar, width, restrict, paramValue?: string, optionList?: any,
              dataProvider?: LabelsAndValues, fromGlobalValueCtrl?: any, comboboxtype?: any,
              inputType?: any, disable?: boolean, isDriver?: boolean) {
    this.type = type;
    this.name = name;
    this.label = label;
    this.maxChar = maxChar;
    this.width = width;
    this.restrict = restrict;
    if (paramValue !== undefined) {
      this.paramValue = paramValue;
      this.disable = true;
    } else {
      this.paramValue = '';
      this.disable = false;
    }
    if (optionList !== undefined && optionList !== null) {
      this.optionList = optionList;
    }
    if (dataProvider !== undefined && dataProvider !== null) {
      this.dataProvider = dataProvider;
    }
    if (fromGlobalValueCtrl) {
      this.fromGlobalValueCtrl = fromGlobalValueCtrl;
    }
    if (comboboxtype !== undefined && comboboxtype !== null) {
      this.comboboxtype = comboboxtype;
    }
    if (inputType !== undefined && inputType !== null) {
      this.inputType = inputType;
    }
    if (disable) {
      this.disable = true;
    } else {
      this.disable = false;
    }
    if (isDriver) {
      this.isDriver = true;
    } else {
      this.isDriver = false;
    }
  }
}
