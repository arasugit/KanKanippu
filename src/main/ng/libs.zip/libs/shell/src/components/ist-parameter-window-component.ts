import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { MatLegacyDialog as MatDialog, MatLegacyDialogRef as MatDialogRef, MAT_LEGACY_DIALOG_DATA as MAT_DIALOG_DATA } from '@angular/material/legacy-dialog';
import { NodeListComponent } from '../ist-components/node-list.component';
import { CommonConstants } from '../common/ist.common.constants';
import { CommandList } from '../ist-components/command-list';
import { FormBusinessService } from '../services/formbusiness.service';
import { GlobalsService } from '../services/globals.service';
import { InstService } from '../services/inst.service';
import { ParameterWindow } from '../components/atmCommandList-model';
import { DynamicComponent } from '../components/dynamicComponentModel';

declare var require: any;
@Component(
    {
        selector: 'ist-parameter-window',
        templateUrl: './ist-parameter-window-template.html'
    }
)
export class IstParameterWindowComponent implements OnInit {
    public title: string;
    nodeWindowTitle: string;
    public assignedNode: string;    
    private cmdName: string;
    private cmdTobeProcessed: string;    
    public myCompList: DynamicComponent[];
    public myCompCls: ParameterWindow;
    dbParam: any;
    isCustomCommand: boolean;
    oldCustomCommand: string;
    oldCustomCommandDesc: string;
    closeIcon: any = require('../assets/close.png');
    commandList = [];
    constructor(private dialogRef: MatDialogRef<IstParameterWindowComponent>,
        private globals: GlobalsService,
        private instService: InstService,
        private formService: FormBusinessService,
        private changeDetector: ChangeDetectorRef,        
        @Inject(MAT_DIALOG_DATA) private data: {
            commandClass: any, cmdName: string,
            cmdTobeProcessed: string, comboType: string, manager: string
        },
        public dialog: MatDialog) {
        // dialogRef.disableClose = true;
    }
    ngOnInit() {
        this.cmdTobeProcessed = this.data ? this.data.cmdTobeProcessed : '';
        this.cmdName = this.data ? this.data.cmdName : '';
        this.nodeWindowTitle = this.data ? this.data.manager : '';
        this.myCompList = [];
        this.myCompCls = new ParameterWindow();
        // console.log('Command to be processed...', this.cmdTobeProcessed);
        if (this.data.comboType === 'ISTControl-Custom') {
            this.myCompCls = this.data.commandClass.getParameterClsList('add_command');
        } else {
            this.myCompCls = this.data.commandClass.getParameterClsList(this.cmdName);
        }
        this.myCompList = this.myCompCls.componentList;
        this.title = this.myCompCls.title;
         if (this.myCompCls.height === undefined) { this.myCompCls.height = 500; }
         if (this.myCompCls.width === undefined) { this.myCompCls.width = 500; }
        this.dialogRef.updateSize('' + this.myCompCls.width + 'px', '' + this.myCompCls.height + 'px');
        this.data.commandClass.populateComponentList();
        if (this.data.comboType === 'ISTControl-Custom' && this.data.cmdTobeProcessed !== 'custom_command') {
            if (this.data.commandClass.commandName === 'send_custom_command') {
                this.oldCustomCommand = this.data.commandClass.commandValue;
                this.oldCustomCommandDesc = this.data.commandClass.buttonNameValue;
                this.data.commandClass.populateComponentList();
            }
            this.isCustomCommand = true;
        } else {
            this.isCustomCommand = false;
        }
    }

    closeWindow() {
        this.dialogRef.close();
    }

    onComboItemChange(event: any, isDriver: boolean) {
        if (isDriver) {
            this.instService.getUserBinIDList(event).subscribe(
                x => this.onGotUserBinIDList(x),
                error => this.onErrorGotRecords(error),
                () => this.onCompleteGotRecords()
            );
        }
    }

    onGotUserBinIDList(x: any): void {
       
    }

    onSendClick() {
        let arrangeParam: string;
        let ctrl: DynamicComponent;
        if (this.myCompCls.commandName === 'clrStatus' || this.myCompCls.commandName === 'clrFitness') {
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                if (ctrl !== undefined) {
                    if (ctrl.paramValue === 'A') {
                        arrangeParam = arrangeParam + ' all';
                        break;
                    } else if (ctrl.paramValue === 'G') {
                        ctrl = this.myCompList[i + 1];
                        if (ctrl !== undefined) {
                            arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                        }
                        ctrl = this.myCompList[i + 2];
                        if (ctrl !== undefined) {
                            arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                        }
                        break;
                    }
                } else {
                    alert('Something wrong in organizing command');
                    return;
                }
                this.openNodeListComponent(arrangeParam, 0); // 0 - execute in all nodes;
            }
        } else if (this.myCompCls.commandName === 'valpkcs7') {
            const instVal: string = this.myCompList[0].paramValue;
            const keyVal: string = this.myCompList[1].paramValue;
            const levelVal: string = this.myCompList[2].paramValue;
            const pkcs7Val: string = this.myCompList[3].paramValue;

            arrangeParam = this.cmdTobeProcessed;

            arrangeParam += ' ' + instVal + '.' + keyVal + ' ' + levelVal + ' ' + pkcs7Val;
            this.openNodeListComponent(arrangeParam, 0); // 0 - execute in all nodes;
        } else if (this.myCompCls.commandName === 'valpkintsign') {
            const pkfileVal: string = this.myCompList[0].paramValue;
            const extInst: string = this.myCompList[1].paramValue;
            const filename: string = this.myCompList[2].paramValue;
            arrangeParam = this.cmdTobeProcessed;

            arrangeParam += ' ' + pkfileVal + ' -ei' + extInst + ' ' + filename;
            this.openNodeListComponent(arrangeParam, 0); // 0 - execute in all nodes;
        } else if (this.myCompCls.commandName === 'val_pk_inst_signature') {
            const pkfileVal: string = this.myCompList[0].paramValue;
            const extInst: string = this.myCompList[1].paramValue;
            const filename: string = this.myCompList[2].paramValue;
            arrangeParam = this.cmdTobeProcessed;

            arrangeParam += ' ' + pkfileVal + ' -ei' + extInst + ' ' + filename;
            this.openNodeListComponent(arrangeParam, 0); // 0 - execute in all nodes;
        } else if (this.myCompCls.commandName === 'val_ext_pk_inst_signature') {
            const instID: string = this.myCompList[0].paramValue;
            const extInst: string = this.myCompList[1].paramValue;
            const filename: string = this.myCompList[2].paramValue;
            const hashfile: string = this.myCompList[3].paramValue;
            arrangeParam = this.cmdTobeProcessed;

            arrangeParam += ' ' + instID + ' ' + extInst + ' ' + filename + ' ' + hashfile;
            this.openNodeListComponent(arrangeParam, 0); // 0 - execute in all nodes;
        } else if (this.myCompCls.commandName === 'certexc') {
            const intcert: string = this.myCompList[0].paramValue;
            const extcert: string = this.myCompList[1].paramValue;
            const unitNoVal: string = this.myCompList[2].paramValue;
            arrangeParam = this.cmdTobeProcessed;

            arrangeParam += ' ' + intcert + ' ' + extcert + ' ' + unitNoVal;
            this.openNodeListComponent(arrangeParam, 0); // 0 - execute in all nodes;
        } else if (this.myCompCls.commandName === 'remkeytrans') {
            const atmcert: string = this.myCompList[0].paramValue;
            const intcert: string = this.myCompList[1].paramValue;
            const extcert: string = this.myCompList[2].paramValue;
            const unitVal: string = this.myCompList[3].paramValue;
            arrangeParam = this.cmdTobeProcessed;

            arrangeParam += ' ' + atmcert + ' ' + intcert + ' ' + extcert + ' ' + unitVal;
            this.openNodeListComponent(arrangeParam, 0); // 0 - execute in all nodes;
        } else if (this.myCompCls.commandName === 'pos_closeterminal') {
            arrangeParam = this.cmdTobeProcessed;
            let instid: string = this.myCompList[0].paramValue;
            let entityID: string = this.myCompList[1].paramValue;
            let group: string = this.myCompList[2].paramValue;
            let terminal: string = this.myCompList[3].paramValue;
            let dateVal: string = this.myCompList[4].paramValue;
            let batchNum: string = this.myCompList[5].paramValue;
            let closeFlag: string = this.myCompList[6].paramValue;
            let extractFlag: string = this.myCompList[7].paramValue;
            let siteID: string = this.myCompList[8].paramValue;
            let argNew:string;
            arrangeParam = this.cmdTobeProcessed;

            if (instid !== undefined && instid !== '' && instid !== null) {
                instid = ' -i ' + instid;
                arrangeParam += instid;
            }
            if (entityID !== undefined && entityID !== '' && entityID !== null) {
                entityID = ' -e ' + entityID;
                arrangeParam += entityID;
            }
            if (group !== undefined && group !== '' && group !== null) {
                group = ' -g ' + group;
                arrangeParam += group;
            }
            if (terminal !== undefined && terminal !== '' && terminal !== null) {
                terminal = ' -t ' + terminal;
                arrangeParam += terminal;
            }
            if (dateVal !== undefined && dateVal !== '' && dateVal !== null) {
                dateVal = ' -d ' + dateVal;
                arrangeParam += dateVal;
            }
            if (batchNum !== undefined && batchNum !== '' && batchNum !== null) {
                batchNum = ' -b ' + batchNum;
                arrangeParam += batchNum;
            }
            if (closeFlag !== undefined && closeFlag !== '' && closeFlag !== null) {
                closeFlag = ' -c ' + closeFlag;
                arrangeParam += closeFlag;
            }
            if (extractFlag !== undefined && extractFlag !== '' && extractFlag !== null) {
                extractFlag = ' -x ' + extractFlag;
                arrangeParam += extractFlag;
            }            
            arrangeParam += ' -N  C';
            if (siteID !== undefined && siteID !== '' && siteID !== null) {
                siteID = ' -s ' + siteID;
                arrangeParam += siteID;
            }
           // arrangeParam+=' -N C'
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'pos_extract') {
            arrangeParam = this.cmdTobeProcessed;
            let noOfProc: string = this.myCompList[0].paramValue;
            let siteID: string = this.myCompList[1].paramValue;
            if (noOfProc !== undefined && noOfProc !== '' && noOfProc !== null) {
                noOfProc = ' -p' + noOfProc;
                arrangeParam += noOfProc;
            }
            if (siteID !== undefined && siteID !== '' && siteID !== null) {
                siteID = ' -s' + siteID;
                arrangeParam += siteID;
            }
            this.openNodeListComponent(arrangeParam, 1);
        } else if (this.myCompCls.commandName === 'pos_dispatcher') {
            arrangeParam = this.cmdTobeProcessed;
            let msgType: string = this.myCompList[0].paramValue;
            let noOfProc: string = this.myCompList[1].paramValue;
            let dateVal: string = this.myCompList[2].paramValue;
            let instID: string = this.myCompList[3].paramValue;
            let siteID: string = this.myCompList[4].paramValue;
            if (msgType !== undefined && msgType !== '' && msgType !== null) {
                msgType = ' -m' + msgType;
                arrangeParam += msgType;
            }
            if (noOfProc !== undefined && noOfProc !== '' && noOfProc !== null) {
                noOfProc = ' -p' + noOfProc;
                arrangeParam += noOfProc;
            }
            if (dateVal !== undefined && dateVal !== '' && dateVal !== null) {
                dateVal = ' -d' + dateVal;
                arrangeParam += dateVal;
            }
            if (instID !== undefined && instID !== '' && instID !== null) {
                instID = ' -i' + instID;
                arrangeParam += instID;
            }
            if (siteID !== undefined && siteID !== '' && siteID !== null) {
                siteID = ' -s' + siteID;
                arrangeParam += siteID;
            }
            this.openNodeListComponent(arrangeParam, 1);
        } else if (this.myCompCls.commandName === 'pos_tc57') {
            arrangeParam = this.cmdTobeProcessed;
            let fileFormat: string = this.myCompList[0].paramValue;
            let instID: string = this.myCompList[1].paramValue;
            let msgType: string = this.myCompList[2].paramValue;
            let optionFlag: string = this.myCompList[3].paramValue;
            let dateVal: string = this.myCompList[4].paramValue;
            let siteID: string = this.myCompList[5].paramValue;
            if (fileFormat !== undefined && fileFormat !== '' && fileFormat !== null) {
                fileFormat = ' -f' + fileFormat;
                arrangeParam += fileFormat;
            }
            if (instID !== undefined && instID !== '' && instID !== null) {
                instID = ' -i' + instID;
                arrangeParam += instID;
            }
            if (msgType !== undefined && msgType !== '' && msgType !== null) {
                msgType = ' -m' + msgType;
                arrangeParam += msgType;
            }
            if (optionFlag !== undefined && optionFlag !== '' && optionFlag !== null) {
                optionFlag = ' -o' + optionFlag;
                arrangeParam += optionFlag;
            }
            if (dateVal !== undefined && dateVal !== '' && dateVal !== null) {
                dateVal = ' -d' + dateVal;
                arrangeParam += dateVal;
            }
            if (siteID !== undefined && siteID !== '' && siteID !== null) {
                siteID = ' -s' + siteID;
                arrangeParam += siteID;
            }
            this.openNodeListComponent(arrangeParam, 1);
        } else if (this.myCompCls.commandName === 'pos_tc57') {
            arrangeParam = this.cmdTobeProcessed;
            const instID: string = this.myCompList[0].paramValue;
            if (instID !== undefined && instID !== '' && instID !== null) {
                arrangeParam += instID;
            }
            this.openNodeListComponent(arrangeParam, 1);
        } else if (this.myCompCls.commandName === 'pos_ocs') {
            arrangeParam = this.cmdTobeProcessed;
            let fileFormat: string = this.myCompList[0].paramValue;
            let instID: string = this.myCompList[1].paramValue;
            const isCortexOnly: string = this.myCompList[2].paramValue;
            let destInstID: string = this.myCompList[3].paramValue;
            let msgType: string = this.myCompList[4].paramValue;
            let optionFlag: string = this.myCompList[5].paramValue;
            let dateVal: string = this.myCompList[6].paramValue;
            if (fileFormat !== undefined && fileFormat !== '' && fileFormat !== null) {
                fileFormat = ' -f' + fileFormat;
                arrangeParam += fileFormat;
            }
            if (instID !== undefined && instID !== '' && instID !== null) {
                instID = ' -i' + instID;
                arrangeParam += instID;
            }
            if (isCortexOnly !== undefined && isCortexOnly !== '' && isCortexOnly !== null) {
                if (isCortexOnly === 'true') {
                    arrangeParam += 'y';
                }
            }
            if (destInstID !== undefined && destInstID !== '' && destInstID !== null) {
                destInstID = ' -i' + destInstID;
                arrangeParam += destInstID;
            }
            if (msgType !== undefined && msgType !== '' && msgType !== null) {
                msgType = ' -m' + msgType;
                arrangeParam += msgType;
            }
            if (optionFlag !== undefined && optionFlag !== '' && optionFlag !== null) {
                optionFlag = ' -o' + optionFlag;
                arrangeParam += optionFlag;
            }
            if (dateVal !== undefined && dateVal !== '' && dateVal !== null) {
                dateVal = ' -d' + dateVal;
                arrangeParam += dateVal;
            }
            this.openNodeListComponent(arrangeParam, 1);
        } else if (this.myCompCls.commandName === 'rec_format') {
            arrangeParam = this.cmdTobeProcessed;
            let destInstID: string = this.myCompList[0].paramValue;
            let procBusDay: string = this.myCompList[1].paramValue;
            if (destInstID !== undefined && destInstID !== '' && destInstID !== null) {
                destInstID = ' -D' + destInstID;
                arrangeParam += destInstID;
            }
            if (procBusDay !== undefined && procBusDay !== '' && procBusDay !== null) {
                procBusDay = ' -d' + procBusDay;
                arrangeParam += procBusDay;
            }
            this.openNodeListComponent(arrangeParam, 1);
        } else if (this.myCompCls.commandName === 'updategrp' || this.myCompCls.commandName === 'intoserv'
            || this.myCompCls.commandName === 'outserv' || this.myCompCls.commandName === 'authreq'
            || this.myCompCls.commandName === 'initkeyload' || this.myCompCls.commandName === 'remkeyload') {
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                if (ctrl !== undefined) {
                    if (ctrl.paramValue === 'A') {
                        arrangeParam = arrangeParam + ' all';
                        break;
                    } else if (ctrl.paramValue === 'G') {
                        ctrl = this.myCompList[i + 1];
                        if (ctrl !== undefined) {
                            arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                        }
                        break;
                    }
                } else {
                    alert('Something wrong in organizing command');
                    return;
                }
                this.openNodeListComponent(arrangeParam, 0); // 0 - execute in all nodes;
            }
        } else if (this.cmdTobeProcessed === 'custom_command') {
            const commandStr: string = this.myCompList[0].paramValue;
            const authID: string = this.myCompList[1].paramValue;
            const buttonName: string = this.myCompList[2].paramValue;

            if (commandStr === undefined || commandStr === '') {
                this.globals.showDialog(CommonConstants.ERROR, 'Command name should not be empty',
                    CommonConstants.ALERT_OK).subscribe(result => {

                    });
                return;
            } else if (authID === undefined || authID === '') {
                this.globals.showDialog(CommonConstants.ERROR, 'Auth ID should not be empty',
                    CommonConstants.ALERT_OK).subscribe(result => {

                    });
                return;
            } else if (buttonName === undefined || buttonName === '') {
                this.globals.showDialog(CommonConstants.ERROR, 'Button name should not be empty',
                    CommonConstants.ALERT_OK).subscribe(result => {

                    });
                return;
            }
            this.dbParam = {};
            this.dbParam['type'] = 'ADD_CUSTOM_COMMAND';
            this.dbParam['field_name'] = 'ist_custom_manager';
            this.dbParam['field_value'] = commandStr;
            this.dbParam['field_value_desc'] = buttonName;
            this.dbParam['auth_id'] = authID;
            this.instService.getDatabaseRecords('CUSTOM_COMMAND_LIST', this.dbParam).subscribe(
                x => this.onCustomRecordSave(x),
                error => this.onErrorGotRecords(error),
                () => this.onCompleteGotRecords()
            );
            return;
        } else if (this.cmdTobeProcessed === 'custom_command' || this.isCustomCommand) {
            if (this.isCustomCommand) {
                arrangeParam = this.cmdTobeProcessed;
            }
            this.globals.showDialog(CommonConstants.INFORMATION, 'Do you want to send this command?',
                CommonConstants.ALERT_YES_NO).subscribe(result => {
                    if ('Yes' === result) {
                        this.dialogRef.close(arrangeParam);
                        this.openNodeListComponent(arrangeParam, 2); // 0 - execute in all nodes
                        return;
                    }
                });
        } else if (this.cmdTobeProcessed === 'cct_force') {
            this.globals.showDialog(CommonConstants.INFORMATION, 'Do you want to send this command?',
                CommonConstants.ALERT_YES_NO).subscribe(result => {
                    if ('Yes' === result) {
                        for (let i = 0; i < this.myCompList.length; i++) {
                            ctrl = this.myCompList[i];
                            if (ctrl !== undefined) {
                                if (ctrl.paramValue === 'A') {
                                    arrangeParam = arrangeParam + ' ALL';
                                    break;
                                } else if (ctrl.paramValue === 'C') {
                                    ctrl = this.myCompList[i + 1];
                                    if (ctrl !== undefined) {
                                        arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                                    }
                                    break;
                                }
                            } else {
                                alert('Something wrong in organizing command');
                            }
                        }
                        this.dialogRef.close(arrangeParam);
                        this.openNodeListComponent(arrangeParam, 1);
                        return;
                    }
                });
        } else if (this.myCompCls.commandName === 'mb_start_stop') {
            arrangeParam = this.cmdTobeProcessed;
            const credential: string = this.myCompList[0].paramValue;
            if (credential === undefined || credential === null || credential.length === 0) {
                this.globals.showDialog(CommonConstants.ERROR, 'Password cannot be blank. Please enter the password',
                    CommonConstants.ALERT_OK);
                return;
            }
            this.formService.reAuthenticateUser('reAuthenticateUser',
                this.globals.userContext.userID, this.globals.encryptPassword(credential))
                .subscribe((x: any) => {
                    if (x[0] === true) {
                        this.dialogRef.close(x);
                        this.openNodeListComponent(this.cmdTobeProcessed, 2);
                    } else {
                        this.globals.showDialog(CommonConstants.ERROR, 'Authentication failed. Not allowed to proceed!',
                            CommonConstants.ALERT_OK);
                        return;
                    }
                });
        } else if (this.myCompCls.commandName === 'inst_sendroute') {
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                if (i === 4) {
                    arrangeParam = arrangeParam + ' ' + ctrl.paramValue + ' ';
                } else if (i === 7) {
                    if (ctrl.paramValue !== undefined) {
                        arrangeParam = arrangeParam + ' for ' + ctrl.paramValue;
                    }
                } else if (i === 8) {
                    if (ctrl.paramValue !== undefined) {
                        arrangeParam = arrangeParam + ' with ' + ctrl.paramValue;
                    }
                }
                if (ctrl !== undefined) {
                    arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                } else {
                    alert('Something wrong in organizing command');
                }
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'inst_netcode') {
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                if (i === 7) {
                    arrangeParam = arrangeParam + ' for ' + ctrl.paramValue;
                } else if (i === 8) {
                    arrangeParam = arrangeParam + ' with ' + ctrl.paramValue;
                }
                if (ctrl !== undefined) {
                    arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                } else {
                    alert('Something wrong in organizing command');
                }
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'shc_netcode') {
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                if (i === 7) {
                    arrangeParam = arrangeParam + ' for ' + ctrl.paramValue;
                } else if (i === 8) {
                    arrangeParam = arrangeParam + ' with ' + ctrl.paramValue;
                }
                if (ctrl !== undefined) {
                    arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                } else {
                    alert('Something wrong in organizing command');
                }
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'interval') { // Advice Manager commands
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                if (ctrl.paramValue === 'retran') {
                    ctrl.paramValue = 'retran=';
                } else if (ctrl.paramValue === 'fast') {
                    ctrl.paramValue = 'fast=';
                } else if (ctrl.paramValue === 'slow') {
                    ctrl.paramValue = 'slow=';
                }
                if (ctrl !== undefined) {
                    arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                } else {
                    alert('Something wrong in organizing command');
                }
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'percent') {
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                if (ctrl.paramValue === 'normal') {
                    ctrl.paramValue = 'normal=';
                } else if (ctrl.paramValue === 'forward') {
                    ctrl.paramValue = 'forward=';
                }
                if (ctrl !== undefined) {
                    arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                } else {
                    alert('Something wrong in organizing command');
                }
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'set') {
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                if (ctrl.paramValue === 'normal') {
                    ctrl.paramValue = 'normal=';
                } else if (ctrl.paramValue === 'forward') {
                    ctrl.paramValue = 'forward=';
                }
                if (ctrl !== undefined) {
                    arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                } else {
                    alert('Something wrong in organizing command');
                }
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'Trace_setlvl') { // Trace Manager Commands
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];

                if (i === 2 && ctrl.paramValue === 'true') {
                    arrangeParam += ' fielddump';
                } else if (i === 3 && ctrl.paramValue === 'true') {
                    arrangeParam += ' hexdump';
                } else if (i === 4 && ctrl.paramValue === 'true') {
                    arrangeParam += ' stats';
                } else {
                    arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                }
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'Trace_cmmttracelist') {
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                let insName = arrangeParam;
                if (arrangeParam.indexOf(':') > -1) {
                    insName = insName.substring(insName.indexOf(':'), insName.length);
                    insName = '127.0.0.1' + insName;
                }

                arrangeParam = CommandList.cmmt_traceinfo + ' ' + insName + ' -c traceinfo';
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'Trace_cmmtarchive') {
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                let insName = arrangeParam;
                if (arrangeParam.indexOf(':') > -1) {
                    insName = insName.substring(insName.indexOf(':'), insName.length);
                    insName = '127.0.0.1' + insName;
                }

                arrangeParam = CommandList.cmmt_tracearchive + ' ' + insName + ' -c tracearchive ';
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'shcextbin_load'
            || this.myCompCls.commandName === 'shcextbin_update') { // SHC EXT BIN Load Stats
            arrangeParam = this.cmdTobeProcessed;
            let fileName: string = this.myCompList[0].paramValue;
            let network: string = this.myCompList[1].paramValue;
            let instID: string = this.myCompList[2].paramValue;
            let optCheck: string = this.myCompList[3].paramValue;
            let forceLoad: string = this.myCompList[4].paramValue;
            let entityID: string = this.myCompList[5].paramValue;
            let cardPdtCode: string = this.myCompList[6].paramValue;
            let version: string = this.myCompList[7].paramValue;
            let date: string = this.myCompList[8].paramValue;
            let description: string = this.myCompList[9].paramValue;
            if (fileName !== undefined && fileName !== '' && fileName !== null) {
                fileName = ' ' + fileName;
                arrangeParam += fileName;
            } else {
                this.globals.showDialog(CommonConstants.ERROR, 'Filename should not be empty',
                    CommonConstants.ALERT_OK).subscribe(result => {

                    });
                return;
            }
            if (network !== undefined && network !== '' && network !== null) {
                network = ' -n' + network;
                arrangeParam += network;
            } else {
                this.globals.showDialog(CommonConstants.ERROR, 'Network should not be empty',
                    CommonConstants.ALERT_OK).subscribe(result => {

                    });
                return;
            }
            if (instID !== undefined && instID !== '' && instID !== null) {
                instID = ' -i' + instID;
                arrangeParam += instID;
            }
            if (optCheck !== undefined && optCheck !== '' && optCheck !== null) {
                if (this.myCompCls.commandName === 'shcextbin_update' && (optCheck === 'Y' || optCheck === 'y')) {
                    optCheck = ' -d ,';
                    arrangeParam += optCheck;
                }
            }
            if (forceLoad !== undefined && forceLoad !== '' && forceLoad !== null) {
                if (forceLoad === 'Y' || forceLoad === 'y') {
                    forceLoad = ' -f' + forceLoad;
                    arrangeParam += forceLoad;
                }
            }
            if (entityID !== undefined && entityID !== '' && entityID !== null) {
                entityID = ' -e' + entityID;
                arrangeParam += entityID;
            }
            if (cardPdtCode !== undefined && cardPdtCode !== '' && cardPdtCode !== null) {
                cardPdtCode = ' -c' + cardPdtCode;
                arrangeParam += cardPdtCode;
            }
            if (version !== undefined && version !== '' && version !== null) {
                version = ' -v' + version;
                arrangeParam += version;
            }
            if (date !== undefined && date !== '' && date !== null) {
                date = ' -t' + date;
                arrangeParam += date;
            }
            if (description !== undefined && description !== '' && description !== null) {
                description = ' -m' + description;
                arrangeParam += description;
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'shcextbin_remove') {
            arrangeParam = this.cmdTobeProcessed;
            let fileName: string = this.myCompList[0].paramValue;
            let network: string = this.myCompList[1].paramValue;
            if (fileName !== undefined && fileName !== '' && fileName !== null) {
                fileName = ' ' + fileName;
                arrangeParam += fileName;
            } else {
                this.globals.showDialog(CommonConstants.ERROR, 'Filename should not be empty',
                    CommonConstants.ALERT_OK).subscribe(result => {

                    });
                return;
            }
            if (network !== undefined && network !== '' && network !== null) {
                network = ' -n' + network;
                arrangeParam += network;
            } else {
                this.globals.showDialog(CommonConstants.ERROR, 'Network should not be empty',
                    CommonConstants.ALERT_OK).subscribe(result => {

                    });
                return;
            }
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'icm_displayrule') { // Shared Mem Manager - Display
            arrangeParam = this.cmdTobeProcessed;
            const checkValue = this.myCompList[0].paramValue;
            if ('' + checkValue === 'true') {
                arrangeParam = arrangeParam + ' -d';
            }
            this.openNodeListComponent(arrangeParam, 0);
        } else if (this.myCompCls.commandName === 'smm_create' ||
            this.myCompCls.commandName === 'smm_current' ||
            this.myCompCls.commandName === 'smm_delete' ||
            this.myCompCls.commandName === 'smm_update' ||
            this.myCompCls.commandName === 'icm_displayrule' ||
            this.myCompCls.commandName === 'icm_rulelevel') { // Shared Mem Manager commands
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                if (ctrl !== undefined) {
                    arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                } else {
                    alert('Something wrong in organizing command');
                }
            }
            this.openNodeListComponent(arrangeParam, 0);
        } else if (this.myCompCls.commandName === 'smm_scheduleUpdate') { // SMM Schedule update
            arrangeParam = 'sch_cmd 800 -i1';
            const rule = this.myCompList[0].paramValue;
            const usage = this.myCompList[1].paramValue;
            const timeout = this.myCompList[2].paramValue;
            const checkSchNow = this.myCompList[3].paramValue;
            const shcDate = this.myCompList[4].paramValue;
            if (usage !== undefined && usage !== '' && usage !== null) {
                arrangeParam = arrangeParam + ' -u' + usage;
            }
            if (timeout !== undefined && timeout !== '' && timeout !== null) {
                arrangeParam = arrangeParam + ' -t' + timeout;
            }
            if ('' + checkSchNow === 'false') {
                if (shcDate !== undefined && shcDate !== '' && shcDate !== null) {
                    if (shcDate.length > 0 || shcDate.length < 8) {
                        this.globals.showDialog(CommonConstants.ERROR, 'Please enter the schedule datetime value in MMDDHHmm format',
                            CommonConstants.ALERT_OK);
                        return;
                    }
                    let shcDateStr = shcDate.substring(0, 2);
                    if (Number(shcDateStr) < 1 || Number(shcDateStr) > 12) {
                        this.globals.showDialog(CommonConstants.ERROR, 'Please enter MM value in schedule datetime value between 1-12',
                            CommonConstants.ALERT_OK);
                        return;
                    }
                    shcDateStr = shcDate.substring(2, 4);
                    if (Number(shcDateStr) < 1 || Number(shcDateStr) > 31) {
                        this.globals.showDialog(CommonConstants.ERROR, 'Please enter DD value in schedule datetime value between 1-31',
                            CommonConstants.ALERT_OK);
                        return;
                    }
                    shcDateStr = shcDate.substring(4, 6);
                    if (Number(shcDateStr) > 24) {
                        this.globals.showDialog(CommonConstants.ERROR, 'Please enter HH value in schedule datetime value between 00-24',
                            CommonConstants.ALERT_OK);
                        return;
                    }
                    shcDateStr = shcDate.substring(6, 8);
                    if (Number(shcDateStr) > 60) {
                        this.globals.showDialog(CommonConstants.ERROR, 'Please enter  mm value in schedule datetime value between 0-60',
                            CommonConstants.ALERT_OK);
                        return;
                    }
                    arrangeParam = arrangeParam + ' -s' + shcDate;
                }
            }
            arrangeParam = arrangeParam + ' -p' + rule;
            this.openNodeListComponent(arrangeParam, 2);
        } else if (this.myCompCls.commandName === 'tsf_balance') { // TSF Balance
            const instValue = this.myCompList[0].paramValue;
            this.dialogRef.close(instValue);
        } else {
            arrangeParam = this.cmdTobeProcessed;
            for (let i = 0; i < this.myCompList.length; i++) {
                ctrl = this.myCompList[i];
                if (ctrl !== undefined) {
                    arrangeParam = arrangeParam + ' ' + ctrl.paramValue;
                } else {
                    alert('Something wrong in organizing command');
                }
            }
            this.openNodeListComponent(arrangeParam, 2);
        }
    }

    onCustomRecordSave(x: any): void {
        if (x[0] !== undefined && x[0] === 'UPDATE_SUCCESS') {
            this.globals.showDialog(CommonConstants.CONFIRMATION, 'Do you want to execute the command?',
                CommonConstants.ALERT_YES_NO).subscribe(result => {
                    if ('Yes' === result) {
                        this.openNodeListComponent(this.dbParam['field_value'], 2);
                    }
                });
        }
        this.dialogRef.close(x);
    }

    onErrorGotRecords(error: Object): void {
        console.error('Something wrong in retrieving data from server', error);
    }

    onCompleteGotRecords(): void {
        this.changeDetector.detectChanges();
    }

    openNodeListComponent(command: string, execlevel: number): void {
        const dialogRef = this.dialog.open(NodeListComponent, {
            height: '100%',
            width: '100%',
        });
        const instance = dialogRef.componentInstance;
        instance.commandList = [];
        if (this.nodeWindowTitle !== undefined && this.nodeWindowTitle !== null && this.nodeWindowTitle !== '') {
            instance.manager = this.nodeWindowTitle;
        } else {
            instance.manager = 'Not Applicable';
        }
        // instance.command = command;
        instance.commandList.push(command);
        instance.isTable = false;
        instance.logAudit = false;
        instance.authId = this.cmdName; // Auth ID for each command
        if (this.isCustomCommand) {
            instance.isCustomCommand = true;
        } else {
            instance.isCustomCommand = false;
        }
        if (this.assignedNode) {
            instance.assignedNode = this.assignedNode;
        }
        instance.execLevel = execlevel;
        if (instance.execLevel === 2) {
            instance.isAllNode = true;
        }
        instance.nodeType = 'Switch';
    }

    onCancelClick() {
        this.dialogRef.close('Cancel');
    }

    updateDeleteCustomCommand(action: string) {
        const commandStr: string = this.myCompList[0].paramValue;
        const authID: string = this.myCompList[1].paramValue;
        const buttonName: string = this.myCompList[2].paramValue;

        if (commandStr === undefined || commandStr === '') {
            this.globals.showDialog(CommonConstants.ERROR, 'Command name should not be empty',
                CommonConstants.ALERT_OK);
            return;
        } else if (authID === undefined || authID === '') {
            this.globals.showDialog(CommonConstants.ERROR, 'Auth ID should not be empty',
                CommonConstants.ALERT_OK);
            return;
        } else if (buttonName === undefined || buttonName === '') {
            this.globals.showDialog(CommonConstants.ERROR, 'Button name should not be empty',
                CommonConstants.ALERT_OK);
            return;
        }

        this.dbParam = {};
        if (action === 'update') {
            if (commandStr === this.oldCustomCommand && buttonName === this.oldCustomCommandDesc) {
                this.globals.showDialog(CommonConstants.INFORMATION, 'Nothing to update',
                    CommonConstants.ALERT_OK);
                return;
            }
            this.dbParam['type'] = 'UPDATE_CUSTOM_COMMAND';
            this.dbParam['old_field_value'] = this.oldCustomCommand;
        } else if (action === 'delete') {
            this.dbParam['type'] = 'DEL_CUSTOM_COMMAND';
        }

        this.dbParam['field_name'] = 'ist_custom_manager';
        this.dbParam['field_value'] = commandStr;
        this.dbParam['field_value_desc'] = buttonName;
        this.dbParam['auth_id'] = authID;
        this.cmdName = authID;
        if (action === 'update') {
            this.globals.showDialog(CommonConstants.CONFIRMATION, 'Do you want to update the command?',
                CommonConstants.ALERT_OK_CANCEL).subscribe(result => {
                    if ('Ok' === result) {
                        this.instService.getDatabaseRecords('CUSTOM_COMMAND_LIST', this.dbParam).subscribe(
                            x => this.onCustomRecordSave(x),
                            error => this.onErrorGotRecords(error),
                            () => this.onCompleteGotRecords()
                        );
                    }
                });
        } else if (action === 'delete') {
            this.globals.showDialog(CommonConstants.CONFIRMATION,
                'The command and all permission records for this command will be removed!',
                CommonConstants.ALERT_OK_CANCEL).subscribe(result => {
                    if ('Ok' === result) {
                        this.instService.getDatabaseRecords('CUSTOM_COMMAND_LIST', this.dbParam).subscribe(
                            x => this.onCustomRecordSave(x),
                            error => this.onErrorGotRecords(error),
                            () => this.onCompleteGotRecords()
                        );
                    }
                });
        }
    }
}

