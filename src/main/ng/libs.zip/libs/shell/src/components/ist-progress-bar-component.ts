import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StringUtil } from '../common/ist-string-util';
import { NgxSpinnerService } from 'ngx-spinner';
import { GlobalsService } from '../services';

@Component({
  selector: 'ist-progress-bar',
  templateUrl: './ist-progress-bar-template.html'
})


export class IstProgressBarComponent implements OnInit {

  displayMessage = 'Loading...';

  constructor(public istDialogRef: MatDialogRef<IstProgressBarComponent>, @Inject(MAT_DIALOG_DATA) public data: any,private globals: GlobalsService) {
    this.globals.showLoadingBar();
    if (this.data !== undefined && this.data !== null && this.data.message !== undefined && StringUtil.isNotEmpty(this.data.message) ) {
      this.displayMessage = this.data.message;
      this.globals.hideLoadingBar();
    }   else { this.displayMessage = 'Loading...';
    }
}

ngOnInit(): void {
  
}

}
