import { Injectable } from '@angular/core';
import { FormBusinessService } from '../services/formbusiness.service';
import { DynamicComponent } from './dynamicComponentModel';

export class ParameterWindow {
    public commandName: string;
    public title: string;
    public height: number;
    public width: number;
    public componentList: DynamicComponent[];
}
@Injectable()
export class ATMMonitorCommandList {
    public commandName: string;
    private cmdComponentList: Map<string, DynamicComponent[]> = new Map<string, DynamicComponent[]>();
    private paramWindowClsList: Map<string, ParameterWindow> = new Map<string, ParameterWindow>();
    private compList: DynamicComponent[];

    constructor(private mformService: FormBusinessService) {
        this.populateComponentList();
    }
    
    populateComponentList(): void {
        // startej
        this.commandName = 'startej';
        this.compList = [
            new DynamicComponent('textinput', 'field1', 'NCR block size', 10, null, '0-9'),
            new DynamicComponent('textinput', 'field1', 'Group/Unit', 5, null, 'A-Z a-z . 0-9'),
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Start EJ', 300, 400, this.compList);

        // loadscrset
        this.commandName = 'loadscrset';
        this.compList = [
            new DynamicComponent('textinput', 'field1', 'Number', 10, null, '0-9'),
            new DynamicComponent('textinput', 'field1', 'Group/Unit', 5, null, 'A-Z a-z . 0-9'),
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Load screen set', 400, 400, this.compList);

        // updategrp, intoserv, outserv, authreq, initkeyload, remkeyload
        this.commandName = 'updategrp';
        this.compList = [
            new DynamicComponent('radiogroup', 'field1', '', null, null, null, null, [{ label: 'All', value: 'A' },
            { label: 'Group', value: 'G' }]),
            new DynamicComponent('textinput', 'field1', 'Group/Unit',
                null, null, 'A-Z a-z . 0-9') // Group value should be set and disabled
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Update grp', 400, 400, this.compList);
        this.commandName = 'intoserv';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Into service', 400, 400, this.compList);
        this.commandName = 'outserv';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Out service', 400, 400, this.compList);
        this.commandName = 'authreq';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Auth request', 400, 400, this.compList);
        this.commandName = 'initkeyload';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Init key load', 400, 400, this.compList);
        this.commandName = 'remkeyload';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Remote key load', 400, 400, this.compList);

        // clrStatus
        this.commandName = 'clrStatus';
        this.compList = [
            new DynamicComponent('radiogroup', 'field1', '', null, null, null, null, [{ label: 'All statuses', value: 'A' },
            { label: 'User specified', value: 'G' }]),
            new DynamicComponent('textinput', 'field1', 'Status number', null, null, '0-9'),
            new DynamicComponent('textinput', 'field1', 'Group/Unit',
                null, null, 'A-Z a-z . 0-9') // Group value should be set and disabled
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Clear status', 500, 400, this.compList);

        // clrFitness
        this.commandName = 'clrFitness';
        this.compList = [
            new DynamicComponent('radiogroup', 'field1', '', null, null, null, null, [{ label: 'All fitnesses', value: 'A' },
            { label: 'User specified', value: 'G' }]),
            new DynamicComponent('textinput', 'field1', 'Status number', null, null, 'a-z'),
            new DynamicComponent('textinput', 'field1', 'Group/Unit',
                null, null, 'A-Z a-z . 0-9') // Group value should be set and disabled
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Clear fitness', 400, 400, this.compList);

        // loadall, loaddate, loademv, loadfit, loadmisc, loadscreen, loadstate
        this.commandName = 'loadall';
        this.compList = [
            new DynamicComponent('textinput', 'field1', 'State table', null, null, 'A-Z a-z 0-9 . _'),
            new DynamicComponent('textinput', 'field1', 'Version', 5, null, '. 0-9'),
            new DynamicComponent('textinput', 'field1', 'Group/Unit', 5,
                null, 'A-Z a-z . 0-9') // Group value should be set and disabled
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Load all', 400, 400, this.compList);
        this.commandName = 'loaddate';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Load date', 400, 400, this.compList);
        this.commandName = 'loademv';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Load EMV', 400, 400, this.compList);
        this.commandName = 'loadfit';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Load fit', 400, 400, this.compList);
        this.commandName = 'loadmisc';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Load misc', 400, 400, this.compList);
        this.commandName = 'loadscreen';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Load screen', 400, 400, this.compList);
        this.commandName = 'loadstate';
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Load state', 400, 400, this.compList);

        // valpkcs7
        this.commandName = 'valpkcs7';
        this.compList = [
            new DynamicComponent('textinput', 'field1', 'Institution ID', null, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'Key version', 5, null, '. 0-9'),
            new DynamicComponent('textinput', 'field1', 'Level', 5, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'PKCS7 file', 5, null, 'A-Z a-z . 0-9 _')
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Val PKCS7', 400, 400, this.compList);

        // valpkintsign
        this.commandName = 'valpkintsign';
        this.compList = [
            new DynamicComponent('textinput', 'field1', 'PK file name', 5, null, '. 0-9'),
            new DynamicComponent('textinput', 'field1', 'External inst ID', 5, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'PK hash file name', 5, null, 'A-Z a-z . 0-9 _')
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Val PK int sign', 400, 400, this.compList);

        // valpkextsign
        this.commandName = 'valpkextsign';
        this.compList = [
            new DynamicComponent('textinput', 'field1', 'Institution ID', null, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'External inst ID', 5, null, '. 0-9'),
            new DynamicComponent('textinput', 'field1', 'Signature file name', 5, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'Hash file', 5, null, 'A-Z a-z . 0-9 _')
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Val PK ext sign', 400, 400, this.compList);

        // valcertreq
        this.commandName = 'valcertreq';
        this.compList = [
            new DynamicComponent('textinput', 'field1', 'Institution ID', null, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'External institution ID', null, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'Level', 5, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'PKCS7 file', 5, null, 'A-Z a-z . 0-9 _')
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Val cert request', 400, 400, this.compList);

        // certexc
        this.commandName = 'certexc';
        this.compList = [
            new DynamicComponent('textinput', 'field1', 'Internal certificate', null, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'External certificate', null, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'Group/Unit', null, null, 'A-Z a-z . 0-9')
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Cert exchange', 400, 400, this.compList);

        // remkeytrans
        this.commandName = 'remkeytrans';
        this.compList = [
            new DynamicComponent('textinput', 'field1', 'ATM certificate', null, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'Internal certificate', null, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'External certificate', null, null, 'A-Z a-z . 0-9'),
            new DynamicComponent('textinput', 'field1', 'Group/Unit', null, null, 'A-Z a-z . 0-9')
        ];
        this.cmdComponentList.set(this.commandName, this.compList);
        this.setParameterWindowProperties(this.commandName, 'Remote key trans', 400, 400, this.compList);
    }
    setParameterWindowProperties(command: string, title: string, height: number, width: number, componentList: DynamicComponent[]): void {
        const paramCls: ParameterWindow = new ParameterWindow();
        paramCls.commandName = command;
        paramCls.title = title;
        paramCls.width = 500;
        paramCls.componentList = this.compList;
        this.paramWindowClsList.set(this.commandName, paramCls);
    }
    getComponentList(cmd: string): DynamicComponent[] {
        if (cmd !== '') {
            return this.cmdComponentList.get(cmd);
        }
    }
    getParameterClsList(cmd: string): ParameterWindow {
        if (cmd !== '') {
            return this.paramWindowClsList.get(cmd);
        }
    }
    getCommandString(cls: ParameterWindow): string {
        switch (cls.commandName) {
            case 'loadscrset': {
                return '';
            }
            default: {
                return '';
            }
        }
    }
}
