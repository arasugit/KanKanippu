import {
  Component,
  ElementRef,
  EventEmitter,
  forwardRef,
  Input,
  OnInit,
  Output,
  ViewChild,
  ChangeDetectorRef,
  ChangeDetectionStrategy
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { CustomFormatter } from '../common/ist-formatter';
import { UIMetaField } from '../common/vo/ui-metadata-model';
import { T21Base } from './t21-base';
import { GlobalsService } from '../services/globals.service';
import { WorkField, WorkRequest } from '../ist-components/work-request-model';
import { StringUtil } from '../common/ist-string-util';
const noop = () => {};

export const MON_INPUT_CONTROL_VALUE_ACCESSOR_INPUT: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => MonInputComponent),
  multi: true
};

export const MON_T21BASE_ACCESSOR_INPUT: any = {
  provide: T21Base,
  useExisting: forwardRef(() => MonInputComponent),
  multi: true
};


@Component({
  selector: 'mon-input',
  templateUrl: './mon-input.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [MON_INPUT_CONTROL_VALUE_ACCESSOR_INPUT, MON_T21BASE_ACCESSOR_INPUT]
})
 
  export class MonInputComponent extends T21Base implements ControlValueAccessor, OnInit {
  constructor(
    elem: ElementRef,
    protected globalService: GlobalsService,
    protected ref: ChangeDetectorRef
  ) {
    super();
    this.changeDetectRef = ref;
    this.componentType = 'MonInputComponent';
    this._selfreference = this;
    this.mandatorySymbol = '';
    this.requiredColon = ' : ';
    this.toolTipMsg = '';
  }

  @ViewChild('focusControl', { static: false })
  focusControl: ElementRef;

  private _requestProvider: WorkRequest;
  private _workField: WorkField;

  private _errorString: string;
  /**
 * Maximum Allowable Length
 */
  @Input() public maxAllowedLen: number;

  @Input() public cntrlLabel:string='';
  
  _adjustWidth: boolean;
  @Input() set adjustWidth(v:boolean) {
    if (this.maxAllowedLen > 0) {
      this.adjustControlWidth();
    }
  }
  get adjustWidth():boolean {
    return this._adjustWidth;
  }
  maxWidth: number;
  innerValue: String = '';
  customFormatDate : boolean = false;
  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;
  @Input() updatePerm: Boolean = false;
  @Input() size: String;
  @Input() wildCardAllowed: boolean;
  @Input() cellWidth: String; // Used to set width in the Datatable.
  @Output() onValueChange = new EventEmitter();
  @Output() onValueCommit = new EventEmitter();
  @Input() inputDataUpperCase: Boolean = false;
  @Input() public contentAlign: String;
  @Input() public name:string;
  @Input() public type:string='text';

  _formatAmount: Boolean;
  @Input()
  set formatAmount(value: Boolean) {
    this._formatAmount = value;
    if (this._formatAmount) {
      this.contentAlign = 'right';
    }
  }
  get formatAmount(): Boolean {
    return this._formatAmount;
  }

  keyPressEvent(event: KeyboardEvent) {   
    if (this.restrict === '') {
      // do nothing
    } else {
      const patternStr = '^[' + this.restrict + ']*$';
      const pattern = new RegExp(patternStr);

      const inputChar = String.fromCharCode(event.charCode);      
      if (event.keyCode !== 8 && !pattern.test(inputChar)) {
        event.preventDefault();
      }
    }
  }

  @Input()
  set requestProvider(value: WorkRequest) {
    //  console.log('set requestProvider called');
    this._requestProvider = value;
    if (
      this.tag != null &&
      this._requestProvider != null &&
      this._requestProvider.fields[this.tag] !== null && this._requestProvider.fields[this.tag] !==undefined
    ) 
    {
      this.setWorkField(this._requestProvider.fields[this.tag]);     
    }
  }
  get requestProvider(): WorkRequest {
    return this._requestProvider;
  }
  setWorkField(value: WorkField) {
    this.focusOut = false;
    this.toolTipMsg = '';
    this._workField = value;    
    if (this._workField != null) {
      this.innerValue = this._workField.value;
      if (this._workField.style !== undefined && this._workField.style === 'mkcStyle') 
      {
          this.toolTipMsg =this._workField.oldValue === undefined? '': this._workField.oldValue;
          this.setToolTip();
          this.isMkcChange = true;
      } else {
        this.isMkcChange = false;
        this._workField.oldValue = this._workField.value; 
      }
      
      this.applyFormatter();
      this.onChangeCallback(this.innerValue);
      if (this._workField.modifyable === 'N') {
        this.isDisabled = true;
      }
      // set errorString
      if (this._workField.errorInfo !== '') {
        this._errorString = this._workField.errorInfo;
        this.toolTipMsg = this._errorString;
      } else {
        this._errorString = '';
        this.toolTipMsg = '';
      }
      this.ref.markForCheck();
    }
  }
  get value(): any {
    return this.innerValue;
  }
  // set accessor including call the onchange callback
  @Input()
  set value(v: any) {
     if (v !== this.innerValue) {
      this.innerValue =this.inputDataUpperCase && v !== null ? v.toUpperCase() : v;
      if (this._requestProvider != null && this._requestProvider.fields[this.tag] != null) {
          this._requestProvider.fields[this.tag].value = this.innerValue+"";
      }       
      this.onChangeCallback(v);
      this.onValueChange.emit(this.innerValue);
    }
    this.ref.markForCheck();
  }
  
  writeValue(v: any) {
    
    this.value = v;
    this.ref.markForCheck();
  }

  ngOnInit() {  
    this.customFormatDate = this.globalService.customDateMask;
    if (this.width !== null && Number(this.width)) {
      this.maxWidth = this.width;
    }
    this._errorString = '';
  }
  registerOnChange(fn: (_: any) => void): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: () => void): void {
    this.onTouchedCallback = fn;
  }

  setContentAlignment() {
    if (this._metadataProvider && this._metadataProvider.editType) {
      if (
        this._metadataProvider.editType === 'NUMBER' ||
        this._metadataProvider.editType === 'AMOUNT'
      ) {
        this.contentAlign = 'right';
      }
    }
  }
   
  /**
 * Setting metadata for collection fields
 */
  @Input()
  set metadataProviderForCollections(fields: UIMetaField[]) {
    if (fields) {
      this._metadataProvider = fields[this.tag];
      if (this._metadataProvider !== undefined) {
        this.maxAllowedLen = this._metadataProvider.maxLength;
        this.setRestrict();
        this.setContentAlignment();
      }
    }
  }
  clearValue() {
    this.errorString = '';
    this.innerValue = '';
    this.ref.markForCheck();
    this.onChangeCallback(this.innerValue);
  }

  setDefaultValue(v: any): void {
    this.innerValue = v;
  }
  getValue(): any {   
    return this.innerValue;
  }
  set setWidth(v: number) {
    this.maxWidth = this.width = v;
  }

  set errorString(errStr: string) {
    this._errorString = errStr;
  }

  get errorString(): string {
    return this._errorString;
  }
  focusOut :boolean = false;
  // focusout need to be changed to fire only when value changed
  focusOutEvent(event: any) {   
    this.focusOut = true;
    this.applyFormatter();
    this.onValueCommit.emit(event);
  }

  setPattern(): void {
    let editType:string|undefined;
    if (this._metadataProvider !== undefined) {
        editType = this._metadataProvider.editType;
    }
    else {
      if (this._editType !== undefined && this._editType !=='') {
        editType = this._editType;
      }
    }
    if (editType === undefined || editType === '') {
      this.restrict = '';
    }
    switch (editType) {
      case 'AMOUNT':
        this.restrict = '"0-9\\-.,';
        break;
      case 'PHONE':
        this.restrict = '';
        break;
      case 'PHONEX':
        this.restrict = '';
        break;
      case 'NUMBER':
        this.restrict = '0-9';
        break;
      case 'NBRWDECPOINT':
        this.restrict = '0-9.';
        break;
      case 'TEXT':
        this.restrict = this.globalService.systemAllowedChars;
        break;
      case 'ALPHANUM':
        if (this._metadataProvider.upshift) {
          this.restrict = 'A-Z 0-9';
        } else {
          this.restrict = 'a-z A-Z0-9';
        }
        break;
      case 'ALPHANUM*':
        if (this._metadataProvider.upshift) {
          this.restrict = 'A-Z0-9*';
        } else {
          this.restrict = 'a-zA-Z0-9*';
        }
        break;
      case 'ALPHANUM$':
        if (this._metadataProvider.upshift) {
          this.restrict = 'A-Z0-9$';
        } else {
          this.restrict = 'a-zA-Z0-9$';
        }
        break;
      case 'ALPHANUM$*':
        if (this._metadataProvider.upshift) {
          this.restrict = 'A-Z0-9$*';
        } else {
          this.restrict = 'a-zA-Z0-9$*';
        }
        break;
      case 'EMAIL':
        this.restrict = 'a-zA-Z0-9.@';
        break;
      default:
        break;
    }
   
  }
  applyFormatter() {
    let formatDateType = false;
    this.setContentAlignment();
    if (this.value === undefined || this.value === '' || this.value === null) {
      return;
    }
    let isAmountType = this.formatAmount;  
    if (
      this._metadataProvider != null &&
      this._metadataProvider.editType != null
    ) {
      if (
        this._metadataProvider.editType === 'AMOUNT' ||
        (this._metadataProvider.mask !== undefined &&
          this._metadataProvider.mask.indexOf('#') > -1 &&
          this._metadataProvider.mask.indexOf('.') > -1)
      ) {
        isAmountType = true;
      }
      if (this._metadataProvider.editType === 'DATE' || (this.globalService.customDateMask && this._metadataProvider.editType === 'DATE')) {
          formatDateType = true;
      }
      if(formatDateType && !this.focusOut){   
        let mask =  this.changeMask(this._metadataProvider.mask);           
        this.value = CustomFormatter.formatDateString(this.value,mask );      
      }
      if (isAmountType) {
        let strVal: string = this.value.toString();
        strVal = strVal.replace(new RegExp(',', 'g'), ''); // this logic need to be revisited during localization
        this.value = strVal;

        let amtArr = strVal.split(".");

        let mask = (this._metadataProvider ) ? this._metadataProvider.mask : null;
        let  maskArr =  StringUtil.isNotEmpty(mask)  ? mask.split(".") : null ;
        
        let maskDec = (maskArr && maskArr.length > 1) ? maskArr[1].length : 2; 
        

      if(StringUtil.isNotEmpty(amtArr[0]) && (amtArr[0].length > 15 )){  //To avoid round off value for digits > 15 like 123456789012345678.123456 
                 
        this.value = this.amountMask(amtArr,maskDec);       

      }
      else
      {
      // the value will be formatted based on the selected locale   
       this.value = CustomFormatter.formatAmount(this.value,maskDec);        
      }
        this.contentAlign = 'right';
      }
    }
    
  }

  changeMask(mask:string)  : string{  
    let maskFormatArr:any[] = [];
    let maskFormat = "";
    if(StringUtil.isNotEmpty(mask)){
        let maskArr = mask.split("/");
        if(maskArr && maskArr.length == 3){
          maskFormatArr = maskArr.map( x => {          
            if(x.includes("DD") || x.includes("YY")){
                return x.toLowerCase();
            }
            return x;        
          })      
          maskFormat = maskFormatArr.join("/");          
          return maskFormat;
        }
      }
    return "";
  }

  setFocus() {
    setTimeout(() => this.focusControl.nativeElement.focus());
  }

  amountMask(amtArr , maskDec) : string{

    amtArr[0] =amtArr[0].replace(/\B(?=(\d{3})+(?!\d))/g, ","); 
    if(amtArr[1]){
      amtArr[1] = amtArr[1].slice(0,maskDec);
    }
    else{
      amtArr[1] = "00";
    }

    return amtArr.join(".");

}
}
