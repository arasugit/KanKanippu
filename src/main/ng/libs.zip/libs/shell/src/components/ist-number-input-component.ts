import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, EventEmitter, forwardRef, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { StringUtil } from '../common/ist-string-util';
import { CustomFormatter } from '../common/ist-formatter';
import { UIMetaField } from '../common/vo/ui-metadata-model';
import { T21Base } from './t21-base';
import { GlobalsService } from '../services/globals.service';
import { WorkField, WorkRequest } from '../ist-components/work-request-model';
import { Subscription } from 'rxjs';
import { MessageService } from '../services/message.event.services';
const noop = () => { };

export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_INPUT_NUMBER: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => IstNumberInputComponent),
  multi: true
};

export const T21BASE_ACCESSOR_INPUT_NUMBER: any = {
  provide: T21Base,
  useExisting: forwardRef(() => IstNumberInputComponent),
  multi: true
};

@Component({
  selector: 'ist-number-input',
  templateUrl: './ist-number-input-template.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_INPUT_NUMBER, T21BASE_ACCESSOR_INPUT_NUMBER]
})
export class IstNumberInputComponent extends T21Base
  implements ControlValueAccessor, OnInit, OnDestroy {
  constructor(
    elem: ElementRef,
    protected globalService: GlobalsService,
    protected ref: ChangeDetectorRef,
    private msgService: MessageService
  ) {
    super();
    this.changeDetectRef = ref;
    this.componentType = 'IstInputComponent';
    this._selfreference = this;
    this.mandatorySymbol = '';
    this.requiredColon = ' : ';
    this.toolTipMsg = '';
    // The below subscription was added to detect the locale change.
    this.subscription = this.msgService.getMessage().subscribe(message => {
      if (message.text === 'localechanged') {
        this.refreshData(); // This will change the value to current selected locale.
      }
    });
  }

  @ViewChild('focusControl', { static: false })
  focusControl: ElementRef;
  groupSeparator = ','; // set with default value
  decimalSeparator = '.'; // set with default value
  defFractionDigits = 2; // set with default value
  private _requestProvider: WorkRequest;
  private _workField: WorkField;

  private _errorString: string;
  @Input() public maxAllowedLen: number;
  maxWidth: number;
  innerValue: String = '';
  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;
  @Input() updatePerm: Boolean = false;
  @Input() size: String;
  @Input() wildCardAllowed: boolean;
  @Input() cellWidth: String; // Used to set width in the Datatable.
  @Output() onValueChange = new EventEmitter();
  @Output() onValueCommit = new EventEmitter();
  @Input() inputDataUpperCase: Boolean = false;
  @Input() scaleRequired: Boolean = true;
  @Input() expBasedAmount: Boolean = false;

  @Input() public contentAlign: String;
  subscription: Subscription;
  _formatAmount: Boolean;
  @Input()
  set formatAmount(value: Boolean) {
    this._formatAmount = value;
    if (this._formatAmount) {
      this.contentAlign = 'right';
    }
  }
  get formatAmount(): Boolean {
    return this._formatAmount;
  }

  _expValue: number;
  @Input()
  set expValue(value: number) {
    this._expValue = value;
    if (this._expValue > -1) {
      this.applyFormatter();
    }
  }
  get expValue(): number {
    return this._expValue;
  }

  keyPressEvent(event: KeyboardEvent) {
    // console.log(' key pressed called for ', this.tag);
    if (this.restrict === '') {
      // do nothing
    } else {
      const patternStr = '^[' + this.restrict + ']*$';
      const pattern = new RegExp(patternStr);

      const inputChar = String.fromCharCode(event.charCode);
      //  console.log('keypress event is called inputChar', inputChar, ' - ', patternStr);
      if (event.keyCode !== 8 && !pattern.test(inputChar)) {
        event.preventDefault();
      }
    }
  }

  @Input()
  set requestProvider(value: WorkRequest) {
    //  console.log('set requestProvider called');
    this._requestProvider = value;
    if (
      this.tag != null &&
      this._requestProvider != null &&
      this._requestProvider.fields[this.tag] != null
    ) {
      this.setWorkField(this._requestProvider.fields[this.tag]);
      // this.ref.markForCheck();
    }
  }
  get requestProvider(): WorkRequest {
    return this._requestProvider;
  }
  setWorkField(value: WorkField) {
    this.toolTipMsg = '';
    this._workField = value;
    //  console.log('setWorkField called', this._workField.value);
    if (this._workField != null) {
      this.innerValue = this._workField.value;
      if (
        this._workField.style !== undefined &&
        this._workField.style === 'mkcStyle'
      ) {
        // console.log('mkc old value ', this._workField.oldValue, this.tag);
        this.toolTipMsg =
          this._workField.oldValue === undefined
            ? ''
            : this._workField.oldValue;
        this.setToolTip();
        this.isMkcChange = true;
      } else {
        this.isMkcChange = false;
        this._workField.oldValue = this._workField.value; // old value copied here for comparison
      }
      // console.log('this.tooltipmsg', this.toolTipMsg, this.tag);
      this.applyFormatter();
      this.onChangeCallback(this.innerValue);
      if (this._workField.modifyable === 'N') {
        this.isDisabled = true;
      }
      // set errorString
      if (this._workField.errorInfo !== '') {
        this._errorString = this._workField.errorInfo;
        this.toolTipMsg = this._errorString;
      } else {
        this._errorString = '';
        this.toolTipMsg = '';
      }
      this.ref.markForCheck();
    }
  }
  // propagateChange: any = () => {};
  get value(): any {
    return this.innerValue;
  }
  // set accessor including call the onchange callback
  @Input()
  set value(v: any) {
    // console.log(' ist-input set value same value:', this.tag);
    if (v !== this.innerValue) {
      this.innerValue =
        this.inputDataUpperCase && v !== null ? v.toUpperCase() : v;
      if (
        this._requestProvider != null &&
        this._requestProvider.fields[this.tag] != null
      ) {
        this._requestProvider.fields[
          this.tag
        ].value = this.formatToNative(this.innerValue.toString(), this.globalService.decimalSeparator,
          this.globalService.groupSeparator);
      } 
      if (this.tag === undefined || this.tag === null) {
        this.applyFormatter();
      }
      this.onChangeCallback(v);
      this.onValueChange.emit(this.innerValue);
    }
    this.ref.markForCheck();
  }
  // called when ngmodel changes to update the view
  writeValue(v: any) {
    //  console.log('write value called from textInput', value);
    this.value = v;
    this.ref.markForCheck();
  }

  ngOnInit() {
    this.defFractionDigits = this.globalService.defFractionDigits;
    this.groupSeparator = this.globalService.groupSeparator;
    this.decimalSeparator = this.globalService.decimalSeparator;
    if (this.width !== null && Number(this.width)) {
      this.maxWidth = this.width;
    }
    this._errorString = '';
  }
  registerOnChange(fn: (_: any) => void): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: () => void): void {
    this.onTouchedCallback = fn;
  }

  setContentAlignment() {
    if (this._metadataProvider && this._metadataProvider.editType) {
      if (
        this._metadataProvider.editType === 'NUMBER' ||
        this._metadataProvider.editType === 'AMOUNT'
      ) {
        this.contentAlign = 'right';
      }
    }
  }

  // Setting metadata for collection fields
  @Input()
  set metadataProviderForCollections(fields: UIMetaField[]) {
    if (fields) {
      this._metadataProvider = fields[this.tag];
      if (this._metadataProvider !== undefined) {
        this.maxAllowedLen = this._metadataProvider.maxLength;
        this.setRestrict();
        this.applyFormatter();
      } else {
        this.applyFormatter();
      }
    }
  }
  clearValue() {
    this.errorString = '';
    this.innerValue = '';
    this.ref.markForCheck();
    this.onChangeCallback(this.innerValue);
  }

  setDefaultValue(v: any): void {
    this.innerValue = v;
  }
  getValue(): any {
    // console.log(' ist-input get value same value:', this.tag);
    return this.innerValue;
  }
  set setWidth(v: number) {
    this.maxWidth = this.width = v;
  }

  set errorString(errStr: string) {
    this._errorString = errStr;
  }

  get errorString(): string {
    return this._errorString;
  }
  // focusout need to be changed to fire only when value changed
  focusOutEvent(event: any) {
    // console.log('focus out from ist input');
    this.applyFormatter();
    this.onValueCommit.emit(event);
  }

  setPattern(): void {
    let editType = undefined;
    if (this._metadataProvider !== undefined) {
      editType = this._metadataProvider.editType;
    }
    else {
      if (this._editType !== undefined && this._editType !== '') {
        editType = this._editType;
      }
    }
    if (editType === undefined || editType === '') {
      this.restrict = '';
    }
    switch (editType) {
      case 'AMOUNT':
        this.restrict = '"0-9\\-.,';
        break;
      case 'PHONE':
        this.restrict = '';
        break;
      case 'PHONEX':
        this.restrict = '';
        break;
      case 'NUMBER':
        this.restrict = '0-9';
        break;
      case 'NBRWDECPOINT':
        this.restrict = '0-9.';
        break;
      case 'TEXT':
        this.restrict = this.globalService.systemAllowedChars;
        break;
      case 'ALPHANUM':
        if (this._metadataProvider.upshift) {
          this.restrict = 'A-Z 0-9';
        } else {
          this.restrict = 'a-z A-Z0-9';
        }
        break;
      case 'ALPHANUM*':
        if (this._metadataProvider.upshift) {
          this.restrict = 'A-Z0-9*';
        } else {
          this.restrict = 'a-zA-Z0-9*';
        }
        break;
      case 'ALPHANUM$':
        if (this._metadataProvider.upshift) {
          this.restrict = 'A-Z0-9$';
        } else {
          this.restrict = 'a-zA-Z0-9$';
        }
        break;
      case 'ALPHANUM$*':
        if (this._metadataProvider.upshift) {
          this.restrict = 'A-Z0-9$*';
        } else {
          this.restrict = 'a-zA-Z0-9$*';
        }
        break;
      case 'EMAIL':
        this.restrict = 'a-zA-Z0-9.@';
        break;
      default:
        break;
    }
    //   console.log(this.tag, ' Edit Type - ', editType, ':', this.restrict);
  }
  applyFormatter() {
    this.setContentAlignment();
    if (this.value === undefined || this.value === '' || this.value === null) {
      return;
    }
    let isAmountType = this.formatAmount;
    if (
      this._metadataProvider &&
      this._metadataProvider != null &&
      this._metadataProvider.editType != null
    ) {
      if (
        this._metadataProvider.editType === 'AMOUNT' ||
        (this._metadataProvider.mask !== undefined &&
          this._metadataProvider.mask.indexOf('#') > -1 &&
          this._metadataProvider.mask.indexOf('.') > -1)
      ) {
        isAmountType = true;
      }
    }
    if (isAmountType) {
      // the below method call is used to convert the value to the selected locale
      let maskArr = (this._metadataProvider && StringUtil.isNotEmpty(this._metadataProvider.mask)) ? this._metadataProvider.mask.split(".") : null;
      let maskDec = (maskArr && maskArr.length > 1) ? maskArr[1].length : this.globalService.defFractionDigits;

      this.formatToLocale(this.value, this.globalService.decimalSeparator, this.globalService.groupSeparator, maskDec);
      this.contentAlign = 'right';
    }

    if (this.expBasedAmount && this._expValue != undefined && this._expValue != null && this._expValue > -1) {
      let maskArr = (this._metadataProvider && StringUtil.isNotEmpty(this._metadataProvider.mask)) ? this._metadataProvider.mask.split(".") : null;
      let maskDec = (maskArr && maskArr.length > 1) ? maskArr[1].length : this.globalService.defFractionDigits;
      maskDec = this._expValue;
      this.formatToLocale(this.value, this.globalService.decimalSeparator, this.globalService.groupSeparator, maskDec);
      this.contentAlign = 'right';
    }
  }
  setFocus() {
    setTimeout(() => this.focusControl.nativeElement.focus());
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  refreshData() { // This will be called whenerver the locale is changed
    // the below method call is used to convert the value to the US format before converting to the target locale
    this.formatToLocale(this.value, this.decimalSeparator, this.groupSeparator);
    this.decimalSeparator = this.globalService.decimalSeparator; // updating with the currenct locale
    this.groupSeparator = this.globalService.groupSeparator; // updating with the currenct locale
  }
  formatToLocale(value, decimalSeparator, groupSeparator, decimalDigit?) {
    const nativeValue = this.formatToNative(value, decimalSeparator, groupSeparator);
    const decimalVal = (decimalDigit) ? decimalDigit : this.globalService.defFractionDigits;
    this.value = CustomFormatter.formatToLocaleAmount(nativeValue,
      this.globalService.currentLanguage, (this.scaleRequired === true) ? decimalVal : 0); // it will convert the value the selected locale
  }
  formatToNative(value, decimalSeparator, groupSeparator) {
    // This method will replace the group and decimal separator and it will return just plain number(like 12323123.12) 
    // irrespective of the currenct locale.
    let strVal: string = value.toString();
    strVal = strVal.replace(new RegExp('\\' + groupSeparator, 'g'), '').replace(new RegExp('\\' + decimalSeparator, 'g'), '.');
    return strVal;
  }
}
