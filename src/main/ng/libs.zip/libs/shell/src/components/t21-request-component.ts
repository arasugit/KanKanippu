import { AfterContentInit, Component, ContentChildren, EventEmitter, Input, OnInit, Output, QueryList } from '@angular/core';
import { UIMetadata } from '../common/vo/ui-metadata-model';
import { T21Base } from './t21-base';
import { BizService } from '../services/biz.service';
import { GlobalsService } from '../services/globals.service';
import { WorkRequest } from '../ist-components/work-request-model';


@Component( {
        selector: 'ist-t21request',
        templateUrl: './t21-request-template.html',
    }
)
export class T21RequestComponent  implements OnInit , AfterContentInit {
constructor(private globals: GlobalsService,
    private bizService: BizService) {
    }
private _requestProvider: WorkRequest;
private _metadataProvider: UIMetadata;
private _metadataId: string;
private childElements: [any];
@Output() onMetaDataAvailable = new EventEmitter();
@Input() sectionId: string;
@Input() tabId: string;
@ContentChildren (T21Base, {descendants: true}) inputChildren: QueryList<any>;
@Input() set metadataId(value: string) {
    this._metadataId = value;
}
get metadataId(): string {
    return this._metadataId;
}
@Input()
set metadataProvider(value: UIMetadata) {
    this.setMetdataProvider(value);
}
setMetdataProvider(value: UIMetadata) {
    let cnt = 0;
    this._metadataProvider = value;
    if (this.inputChildren != null) {
        this.inputChildren.forEach(child => {
            cnt = cnt + 1;
         child.tabId = this.tabId;
         child.sectionId = this.sectionId;
         child.metadataProvider = this._metadataProvider ;
        }
        );
    }
    this.onMetaDataAvailable.emit(value);
}
get metadataProvider(): UIMetadata {
    return this._metadataProvider;
}

@Input() set requestProvider(value: WorkRequest) {
       this._requestProvider = value;
      if (this.inputChildren != null) {
        this.inputChildren.forEach(childControl =>
         childControl.requestProvider = this._requestProvider
        );
    }
    }
get requestProvider(): WorkRequest {
    return this._requestProvider;
}

ngOnInit(): void {
   // nothing as of now
}
ngAfterContentInit() {
    this.inputChildren.forEach(childControl => {
         childControl.tabId = this.tabId;
         childControl.sectionId = this.sectionId; }
        );
  }
}
