import { AfterContentInit, ChangeDetectorRef, Component, ComponentFactoryResolver, ContentChildren, EventEmitter, forwardRef, Input, OnChanges, OnDestroy, OnInit, Output, QueryList, SimpleChanges, ViewChild, ViewContainerRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ColumnOnDemand } from './column-on-demand.component';
import { CommonConstants } from '../common/ist.common.constants';
import { Permissions } from '../common/permissions';
import { DataTableColumnComponent, RendererItem } from '../components/data-table-column.component';
import { T21Base } from '../components/t21-base';
import { DataTableService } from '../services/data-table.service';
import { GlobalsService } from '../services/globals.service';
import { WorkCollection, WorkCollectionCollection, WorkField, WorkRequest } from '../ist-components/work-request-model';
import { Subscription } from 'rxjs';
import * as XLSX from 'xlsx';
import { AutoRefreshService, ResponseBase } from '../services';
import { AbstractDataTableComponent, DataTableSource } from './abstract-data-table.component';
import { DataDetailTablePaginatorComponent } from './data-detail-table.paginator.component';
import { PageEvent } from '@angular/material/paginator';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

export const T21BASE_ACCESSOR_TABLE_EDITABLE: any = {
  provide: T21Base,
  useExisting: forwardRef(() => DataTableEditableDetailComponent),
  multi: true
};

export const ISTDATATABLE_ACCESSOR_TABLE_EDITABLE: any = {
  provide: AbstractDataTableComponent,
  useExisting: forwardRef(() => DataTableEditableDetailComponent),
  multi: true
};

@Component({
  selector: 'app-data-table-editable-detail',
  templateUrl: 'data-table-editable-detail.component.html',
  providers: [T21BASE_ACCESSOR_TABLE_EDITABLE, ISTDATATABLE_ACCESSOR_TABLE_EDITABLE],
  styles: [
    `
      .highlight {
        background: #fef8cc;
      }
      .delete {
        background: #a9a9a9;
      }
      .error {
        background: #a9a9a9;
      }.redFlag {
        background: #fee7e7;
      }
    `
  ]
})
export class DataTableEditableDetailComponent extends AbstractDataTableComponent
  implements OnInit, AfterContentInit, OnDestroy, OnChanges {
    @ViewChild(DataDetailTablePaginatorComponent, { static: true }) paginator: DataDetailTablePaginatorComponent;

  criteria: {};
  length = 0;
  isLoadingResults = false;
  loadingMessage: string;
  workRequest: WorkRequest;
  changedRecords: any[] = [];
  subscription: Subscription;
  tempLength = 0;
  pageSize: number;
  singleViewButtonRenderer: RendererItem;
  @Output() onDatatableDetailsClear = new EventEmitter<any>();

  @Input() showPaginator = true; // By default show paginator
  @Input() allowPagination = false;
  @Input() isDetailData = false;
  @Output() itemClick = new EventEmitter<any>();
  @Output() itemEditEnd = new EventEmitter<any>();
  @Output() rowAdded = new EventEmitter<any>();
  @Output() getWorkRequest = new EventEmitter<WorkRequest>();
  @Output() pageIndexChanged = new EventEmitter<PageEvent>();

  @Input() action: string='';
  @Input() requestType: string='';
  @Input() collectionTag: string='';
  @Input() remoteClass: string; // Did not find another way to get it for now
  @Input() screenTypePrefix: string = '';

  @Input() query = false; // Not permitted by default; this input is not required here as search button is at the form level itself.
  @Input() insert = false; // Not permitted by default; expecting input from the actual form
  @Input() update = false; // Not permitted by default; expecting input from the actual form
  @Input() delete = false; // Not permitted by default; expecting input from the actual form
  @Input() checker = false; // Not permitted by default; expecting input from the actual form
  @Input() mkc = false; // Not permitted by default; expecting input from the actual form

  @Input() showAdd = true;
  @Input() showDelete = true;
  @Input() showExport = true;

  @Input() refreshAfterSave = false;
  @Input() exportFileName: string = '';
  @Input() checkAutoRefreshTime: boolean;

  istCtrlPage: Number = 1;
  totalDisplayingRecords: Number = 0;

  // To keep the entitlement permissions to pass on to column level (may be find another way of doing this later)
  permissions: Permissions;

  @Input() width: string=''; // Total width of the table (can be set by the user as needed)

  /**
   * list of column names which are to be displayed. Can be modified; must be a subset of the
   * names of columns in allColumns.
   * Will take a string which is a comma-separated list of names (no quotes), or an array of names.
   */
  displayedColumns: string[] = [];
  exportTypeFromCLick: string;

  @Input()
  set columnsToDisplay(val: string | string[]) {
    if (typeof val === 'string') {
      this.displayedColumns = val.split(/\s*,\s*/);
    } else {
      this.displayedColumns = val;
    }
  }

  @Input() dataTableId: String;

  @ContentChildren(DataTableColumnComponent)
  protected columnElements: QueryList<DataTableColumnComponent>;

  rowToBeHighlighted: object;

  protected columnsOndemand: ColumnOnDemand[] = [];

  userID: string;

  constructor(
    private dataTableService: DataTableService,
    private changeDetector: ChangeDetectorRef,
    public autoRefreshService: AutoRefreshService,
    public globals: GlobalsService,
    public componentFactoryResolver: ComponentFactoryResolver,
    public viewContainerRef: ViewContainerRef,
    public dialog: MatDialog){
    super(globals, componentFactoryResolver, viewContainerRef, dialog);
    this.changedRecords = [];
    // Subscribe to row changes from the data table column level
    this.subscription = this.dataTableService.changedRowObservable$.subscribe(
      event => {
        this.gatherChangedRow(event);
      }
    );

    const pagesize = this.globals.configOptions['ist.default_page_size'];
    this.pageSize = pagesize ? Number(pagesize) : 0;
    if (this.pageSize === 0) {
      this.pageSize = 5;
    }

    this.permissions = {};
  }

  ngOnInit() {
    this.userID = this.globals.userContext.userID;
  }

  ngAfterContentInit() {
    if (this.columnElements && this.columnElements.length > 0) {
      this.allColumns = this.columnElements.toArray();
    }
    if (this.displayedColumns.length === 0) {
      this.displayedColumns = this.allColumns.map((col: DataTableColumnComponent) => col.name);
    }
    this.allColumns.forEach(element => {
      if (element.visible === true) {
        if (element.editable === undefined) {
          // If nothing is set at column level, set editable to true
          element.editable = true;
        }
      } else {
        const index = this.displayedColumns.indexOf(element.name);
        if (index > -1) {
          this.displayedColumns.splice(index, 1);
        }
      }
    });
    if (this.paginator) {
      this.paginator.pageSizeOptions = [this.pageSize];
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    try {
      this.consolidatePermissions(changes);
      this.setOtherInputs(changes);

      if(this.allowPagination && (this.dataSource!=null && this.dataSource !==undefined &&
        this.dataSource.data!=null)){
        this.showPaginator=true;
        this.length= this.dataSource.data.length;
        this.tempLength = DataTableEditableDetailComponent.totalDTLRecords;
        this.paginator.length=this.tempLength;
        this.paginator.pageSizeOptions = [this.pageSize];
        this.totalDisplayingRecords = this.dataSource.data.length;
      }

      if (changes['metadataProvider'] !== undefined && changes['metadataProvider'] !== null) {
        if (changes['metadataProvider'].currentValue) {
          super.collectUIMetaDataFieldInformation(changes['metadataProvider'].currentValue);
        }
      }
      let records: any[];
      if (changes['dataProvider'] !== undefined && changes['dataProvider'] !== null) {
        if (Array.isArray(changes['dataProvider'].currentValue)) {
          records = changes['dataProvider'].currentValue;
        } else {
          // Try with WorkRequest
          this.workRequest = changes['dataProvider'].currentValue;
          records = this.workRequest.collections['' + this.collectionTag].rows;
          this.addColumn();
          this.setMKCRequest();
        }
        // Load the datatable records
        this.loadRecords(records);
      }
    } catch (e) {
      // ignore
    } finally {
      this.clearFlags();
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  // Decide on whether it is a MKC/Rework request??
  setMKCRequest() {
    if (this.workRequest && this.mkc) {
      if (this.workRequest.mkcId && this.workRequest.mkcId > 0) {
        this.isMKCRequest = true;
        if (
          this.workRequest.mkcStatus &&
          this.workRequest.mkcStatus === 'W' &&
          this.action === CommonConstants.MKC_ACTION_REWORK_EDIT
        ) {
          this.isReworkRequest = true;
        } else {
          this.isReworkRequest = false;
        }
      } else {
        this.isMKCRequest = false;
      }
    }
  }

  isChecker(): Boolean {
    if (this.workRequest && this.isMKCRequest && this.checker) {
      if ( this.workRequest.mkcStatus && this.workRequest.mkcStatus === CommonConstants.MKC_STATUS_SUBMIT &&
          this.workRequest.makerId && this.workRequest.makerId !== this.globals.userContext.userID ) {
        return true;
      }
    }
    return false;
  }

  evaluateAdd(): Boolean {
    if (!(this.insert) || this.isChecker() || (this.isMKCRequest && !this.isReworkRequest)) {
      return true;
    }

    return false;
  }

  evaluateDelete(): Boolean {
    if (!(this.delete) || this.rowToBeHighlighted === undefined || this.rowToBeHighlighted === null) {
      return true;
    }

    if ((!(this.insert) && !(this.update)) || this.isChecker() || (this.isMKCRequest && !this.isReworkRequest)) {
      return true;
    }
    return false;
  }

  // This method will be called when there is a change in the dataProvider.
  protected loadRecords(records: any[]) {
    try {
      if (records && records !== undefined) {
        if (records.length <= 0) {
          this.showDummy();
        } else {
          records.forEach(record => {
            record['remoteClass'] = this.remoteClass;
          });
          this.dataSource = new DataTableSource(records);
          this.dataSource.sort = this.sort;
          this.length = records.length;
          this.totalRecords = this.length;
        }
      }
    } catch (e) {
      // Ignore
    }
  }

  protected addColumn() {
    this.columnsOndemand.forEach ((column:any) => {
      const columnFactory = this.componentFactoryResolver.resolveComponentFactory(DataTableColumnComponent);
      const col:any = this.viewContainerRef.createComponent(columnFactory);
      col.instance.itemRenderer = column.renderer;
      col.location.nativeElement.innerHTML = '';
      col.instance.editable = column.editable;
      col.instance.header = column.header ? column.header : 'Header';
      col.instance.name = column.name ? column.name : 'name';
      col.instance.dataField = column.dataField ? column.dataField : 'dataField';
      col.instance.labelFunction = column.expression;
      this.allColumns.push(col.instance);
      this.displayedColumns.push(col.instance.name);
    });
  }

  addColumnsOnDemand(col: ColumnOnDemand) {
    if (col) {
      this.columnsOndemand.push(col);
    }
  }

  highlightRow(row): void {
    if (row) {
      if (row['dbAction'] !== 'd' && row.dbAction !== 'dummy') {
        this.rowToBeHighlighted = row;
      }
      if (row.dbAction !== 'dummy') {
        this.itemClick.emit(row);
      }
    }
  }

  deleteRow(): void {
    if (!this.rowToBeHighlighted) {
      this.globals.showDialog(
        CommonConstants.WARNING,
        'ERR34',
        CommonConstants.ALERT_OK
      );
      return;
    }

    if (
      this.rowToBeHighlighted['dbAction'] === 'a' ||
      this.rowToBeHighlighted['dbAction'] === '' ||
      this.rowToBeHighlighted['dbAction'] === undefined ||
      this.rowToBeHighlighted['dbAction'] === null
    ) {
      // Remove it from the grid.
      if (this.workRequest) {
        const rows = this.workRequest.collections['' + this.collectionTag].rows;
        if (rows.indexOf(this.rowToBeHighlighted) > -1) {
          rows.splice(rows.indexOf(this.rowToBeHighlighted), 1);
          this.workRequest.collections['' + this.collectionTag].rows = rows;
          this.loadRecords(this.workRequest.collections['' + this.collectionTag].rows);
        }
      }
      if (this.changedRecords.indexOf(this.rowToBeHighlighted) > -1) {
        this.changedRecords.splice(this.changedRecords.indexOf(this.rowToBeHighlighted), 1);
      }
      this.changeDetector.detectChanges();
      this.rowToBeHighlighted = {};
      return;
    }

    if (this.rowToBeHighlighted['dbAction'] !== 'd') {
      this.globals.showDialog(CommonConstants.WARNING,'MSG11',CommonConstants.ALERT_YES_NO)?.subscribe(result => {
          if ('Yes' === result) {
            this.rowToBeHighlighted['dbAction'] = 'd';
            this.rowToBeHighlighted['remoteClass'] = this.remoteClass; // Add the remote class set by the actual form
            const index = this.changedRecords.indexOf(this.rowToBeHighlighted);
            if (index > -1) {
              this.changedRecords.splice(index, 1); // Remove old changes
            }
            this.changedRecords.push(this.rowToBeHighlighted); // Add the fresh changes
            this.changeDetector.detectChanges();
            this.rowToBeHighlighted = {};
          }
        });
    }
  }

  deleteSpecificRow(rowRowToBeDeleted: any) {
    if (rowRowToBeDeleted) {
      this.rowToBeHighlighted = rowRowToBeDeleted;
      this.deleteRow();
    }
  }

  addRow(): any {
    const newRecord = this.newRow();
    if (!this.workRequest) {
      this.workRequest = new WorkRequest();
      const collections: WorkCollectionCollection = {};
      collections['' + this.collectionTag] = new WorkCollection(); // Normal set method of map is not working
      this.workRequest.collections = collections;
      // Single page save method expects workRequest.getFields(); but actually no use for this
      this.addWorkFields(this.workRequest, this.fields);
    }

    // Adding the new row as first record
    if (this.workRequest.collections === undefined) {
      const collections: WorkCollectionCollection = {};
      this.workRequest.collections = collections;
    }

    if (this.workRequest.collections['' + this.collectionTag] === undefined) {
      this.workRequest.collections['' + this.collectionTag] = new WorkCollection();
    }

    if (this.workRequest.collections['' + this.collectionTag].rows === undefined) {
      this.workRequest.collections['' + this.collectionTag].rows = [];
    }

    this.workRequest.collections['' + this.collectionTag].rows.splice(0, 0, newRecord);
    this.loadRecords(this.workRequest.collections['' + this.collectionTag].rows);
    this.rowAdded.emit(newRecord); // Used in IST MAS GUI
    this.highlightRow(newRecord);
    this.changeDetector.detectChanges();
    return newRecord;
  }

  newRow(forNewRecord: Boolean = true): any {
    let newRecord = {};
    if (forNewRecord) {
      // For dummy row we do not need default values to be populated.
      newRecord = {
        remoteClass: this.remoteClass,
        inactive: '',
        dbAction: 'a',
        errorFlag: null,
        errorMessage: null
      };
      this.allColumns.map((col: DataTableColumnComponent) => {
        newRecord[col.dataField] = col.defaultValue;
        if (col.labelFunction) {
          newRecord[col.dataField] = col.labelFunction(newRecord, col);
        }
      });
    }
    return newRecord;
  }

  gatherChangedRow(event: any) {
    if (event.collectionTag && event.requestType && event.row) {
      if (this.requestType === event.requestType && this.collectionTag === event.collectionTag) {
        const index = this.changedRecords.indexOf(event.row);
        if (index > -1) {
          this.changedRecords.splice(index, 1); // Remove old changes for this record
        }
        if (event.row['remoteClass'] === undefined || event.row['remoteClass'] === null) {
          event.row['remoteClass'] = this.remoteClass; // Add the remote class set by the actual form
        }
        this.changedRecords.push(event.row); // Add the fresh changes for this record
        this.changeDetector.detectChanges();
        this.addOldRow(event);
        this.itemEditEnd.emit(event);
      }
    }
  }

  addWorkFields(wr: WorkRequest, fields: any) {
    // Adding dummy work field to the workrequest; save method in java just checks whether
    // workRequest.getFields() is not null before continuing to save
    const wf: WorkField = new WorkField();
    wf.tag = 'dummy';
    const flds: { [fieldName: string]: WorkField } = {};
    flds[wf.tag] = wf;
    wr.fields[wf.tag] = wf;
  }

  consolidatePermissions(changes: SimpleChanges): void {
    if (changes['insert'] !== undefined && changes['insert'] !== null) {
      this.insert = changes['insert'].currentValue;
      this.permissions['I'] = this.insert;
    }
    if (changes['update'] !== undefined && changes['update'] !== null) {
      this.update = changes['update'].currentValue;
      this.permissions['U'] = this.update;
    }
    if (changes['delete'] !== undefined && changes['delete'] !== null) {
      this.delete = changes['delete'].currentValue;
      this.permissions['D'] = this.delete;
    }
    if (changes['checker'] !== undefined && changes['checker'] !== null) {
      this.checker = changes['checker'].currentValue;
      this.permissions['C'] = this.checker;
    }
    if (changes['mkc'] !== undefined && changes['mkc'] !== null) {
      this.mkc = changes['mkc'].currentValue;
      this.permissions['mkc'] = this.mkc;
    }
  }

  setOtherInputs(changes: SimpleChanges) {
    if (changes['action'] !== undefined && changes['action'] !== null) {
      this.action = changes['action'].currentValue;
      this.dataTableService.action = this.action;
    }

    if (changes['requestType'] !== undefined && changes['requestType'] !== null) {
      this.requestType = changes['requestType'].currentValue;
      this.dataTableService.requestType = this.requestType;
    }

    if (changes['collectionTag'] !== undefined && changes['collectionTag'] !== null) {
      this.collectionTag = changes['collectionTag'].currentValue;
      this.dataTableService.collectionTag = this.collectionTag;
    }
  }

  checkChange(): boolean {
    return (
      this.changedRecords !== undefined &&
      this.changedRecords !== null &&
      this.changedRecords.length > 0
    );
  }

  showDummy(): void {
    const row = this.newRow(false);
    row.dbAction = 'dummy'; // No need to edit this row.
    row.remoteClass=this.remoteClass; // // added to resolve pymy adjustment screen issue
    const newRow = [].concat(row);
    this.dataSource = new DataTableSource(newRow);
    this.length = newRow.length;
    this.totalRecords = 0;
  }
  resetTotal():void {
    console.log('resetTotal called', this.dataSource.data.length);
    this.length = this.dataSource.data.length;
    this.totalRecords = this.dataSource.data.length
  }

  protected addOldRow(event) {
    if (this.workRequest && event.originalRow) {
      // Add originalRow as 'OLDCOLLECTIONS' so that the ISTAudit record stores the original record
      // for comparison (old and new data) later on the ISTAuditResearchScreen
      const collections: WorkCollectionCollection = this.workRequest
        .collections;
      if (collections.OLDCOLLECTIONS === undefined) {
        collections.OLDCOLLECTIONS = new WorkCollection();
      } else {
        collections.OLDCOLLECTIONS.remoteClass = WorkCollection.remoteClassName;
      }
      const oldRows: any[] = this.workRequest.collections.OLDCOLLECTIONS.rows;
      if (oldRows.indexOf(event.originalRow) === -1) {
        if (event.originalRow.dbAction === 'x') {
          oldRows.push(event.originalRow);
        }
      }
    }
  }

  clearFlags() {
    // this.isLoadingResults = false;
    // this.loadingMessage = '';
    this.globals.hideLoadingBar();
  }

  refreshTableColumns() {
    const mkcStatusIndex = this.displayedColumns.indexOf('mkcStatus');
    let mkcRemarksIndex = this.displayedColumns.indexOf('mkcRemarks');

    if (this.isMKCRequest) {
      if (this.checker) {
        if (!this.isReworkRequest) {
          if (mkcRemarksIndex > -1) {
            this.displayedColumns.splice(mkcRemarksIndex);
            mkcRemarksIndex = -1;
          }
          if (mkcStatusIndex < 0) {
            this.displayedColumns.push('mkcStatus');
          }
        } else {
          if (mkcStatusIndex > -1) {
            this.displayedColumns.splice(mkcStatusIndex);
          }
        }
      }
      if (mkcRemarksIndex < 0) {
        this.displayedColumns.push('mkcRemarks');
      }
    } else {
      if (mkcStatusIndex > -1) {
        this.displayedColumns.splice(mkcStatusIndex);
      }
      if (mkcRemarksIndex > -1) {
        this.displayedColumns.splice(mkcRemarksIndex);
      }
    }
  }

  load(criteria: any, fresh: Boolean, overWriteMsg: Boolean= true): void {
    this.changeDetector.markForCheck();
    this.dataTableService.requestType = this.requestType;
    this.dataTableService.collectionTag = this.collectionTag;
    if (criteria !== undefined && criteria['COMMAND'] !== undefined) {
       this.dataTableService.action = criteria['COMMAND'];
       this.action = criteria['COMMAND'];
    } else {
      this.dataTableService.action = 'query';
      this.action = this.dataTableService.action+'';
    }
    this.dataTableService.criteria = criteria;
    if (this.checkChange() && 'mkc_rework_query' !== this.action && 'mkc_pending_query' !== this.action) {
      this.globals.showDialog(CommonConstants.WARNING, 'MSG94', CommonConstants.ALERT_YES_NO)?.subscribe(result => {
        if ('Yes' === result) {
          this.changedRecords = [];
          this.rowToBeHighlighted ={};
          if (fresh === true) {
            this.resetParametersInternal();
            this.resetRequest();
            this.clearStatusMessage();
          }
          this.loadDataInternal(fresh, overWriteMsg);
        } else {
          if (this.paginator) {
            if (!fresh) {
              this.paginator.pageIndex = this.paginator.prevPageIndex;
            }
          }
        }
      });
    } else {
      if (fresh === true) {
        this.resetParametersInternal();
        this.resetRequest();
        if(!this.refreshAfterSave){
            this.clearStatusMessage();
        }

      }
      this.loadDataInternal(fresh, overWriteMsg);
    }
    // For MKC - adding columns mkcStatus and mkcRemarks based on condition
    this.setMKCRequest();
  }


  onGotRecords(wr: WorkRequest, save: Boolean, add: Boolean = false, overWriteMsg: Boolean= true): void {
    if (this.dataTableService.criteria["ist_page_ctrl"] == -1){
      this.exportToExcel(this.collectionTag, wr);
        return;
    }
    this.istCtrlPage = this.dataTableService.criteria["ist_page_ctrl"];
    this.globals.hideLoadingBar();
    if (this.paginator) {
      this.paginator.length = wr.total;
    }
    this.length = wr.total;
    this.totalDisplayingRecords = this.length;
    this.workRequest = new WorkRequest();
    this.workRequest = wr;
    try {
      this.dataSource = new DataTableSource(this.workRequest.collections['' + this.collectionTag].rows);
      this.dataSource.sort = this.sort;
     } catch (e) {
      // Ignore
    }

    if (!save) {
      this.getWorkRequest.emit(this.workRequest);
    }
  }

  onCompleteGotRecords(): void {
    if(!this.refreshAfterSave){
      this.globals.hideLoadingBar();
    }
    this.changeDetector.markForCheck();
    this.autoRefreshService.updateLastRefreshTime();
    if (this.checkAutoRefreshTime) {
      this.autoRefreshService.updateAutoRefreshInterval();
    }
  }

  private loadDataInternal(fresh: Boolean, overWriteMsg: Boolean= true): void {
   this.globals.showLoadingBar();
   this.dataTableService.loadData(fresh, true).subscribe(
       x => this.onGotRecords(x, false, false, overWriteMsg),
       error => this.onErrorGotRecords(error),
       () => this.onCompleteGotRecords())
       .add(() => this.globals.hideLoadingBar());
 }

  // To Export data
  exportIt(name: string, type: string) {
    this.exportTypeFromCLick = type;
    this.dataTableService.criteria["ist_total"] = "y";
    this.dataTableService.criteria["ist_page_ctrl"] = "-1";
    this.dataTableService.criteria["ist_export_ctrl"] = "y";

    if (this.isDetailData) {
      this.dataTableService.criteria["isTxnDetailReq"] = "true";
    }

    if (this.screenTypePrefix !== '' && this.dataTableService.criteria['screenType'] != null && !this.dataTableService.criteria['screenType'].includes(this.screenTypePrefix))
      this.dataTableService.criteria['screenType'] = this.screenTypePrefix + this.dataTableService.criteria['screenType'];

    this.globals.showLoadingBar();
    this.load( this.dataTableService.criteria,true);
  }

  exportToExcel(collectionName: string, wr: WorkRequest) {
    const customHeader = [];
    const columnsToluIncde = [];
    let exportTitle: any[] = [];
    exportTitle[0] = this.exportFileName;
    let counter = 0;
    this.columnElements.forEach(element => {
      columnsToluIncde.push(element.name.toUpperCase());
      customHeader[counter] = element.header;
      exportTitle[counter+1] = [];
      counter++;
    });

    const dataToExport = wr.collections['' + this.collectionTag].rows.map(item => {
      const filteredItem = {};
      for (const key in item) {
        if (columnsToluIncde.includes(key.toUpperCase())) {
      filteredItem[key] = item[key];
      }
      }

      const sortedFilteredItem = {};
      columnsToluIncde.forEach(outerlement => {
        for (const innerelement in filteredItem) {
          if (outerlement == innerelement.toUpperCase()) {
            sortedFilteredItem[columnsToluIncde.indexOf(innerelement.toUpperCase())] = item[innerelement];

        }
        }
      })

      return sortedFilteredItem;
    });

    const onlyNameAndSymbolArr: Partial<DataTableSource>[] = dataToExport;
    const getFileName = (name: string) => {
      let timeSpan = new Date().toISOString();
      let sheetName = name || "ExportResult";
      let fileName = `${sheetName}-${timeSpan}`;
      return {
        sheetName,
        fileName
      };
    };
    let { sheetName, fileName } = getFileName(collectionName);
    var wb = XLSX.utils.book_new();
    var ws = XLSX.utils.json_to_sheet(onlyNameAndSymbolArr);

   XLSX.utils.sheet_add_aoa(ws, [exportTitle], { origin: -1 });
   XLSX.utils.sheet_add_aoa(ws, [customHeader], { origin: 'A1' });
   XLSX.utils.book_append_sheet(wb, ws, sheetName);

  if (this.exportTypeFromCLick === '.pdf') {
    const doc = new jsPDF('l', 'pt', (customHeader.length > 13 && customHeader.length < 18) ? "a3" : customHeader.length > 18 ? "a2" : "a4");
    const data = dataToExport;
    const columns = customHeader;
    doc.text('FIS PAYMON EXPORTED '+sheetName, 50, 15);
    (doc as any).autoTable({
      head: [columns],
      body: data,
      theme: 'grid',
      startY: 18,
      styles: { overflow: 'linebreak', cellWidth: 'wrap', cellPadding: 1, fontSize: 6 },
      columnStyles: { text: { cellWidth: 'auto' } },
    });
    doc.save(fileName + this.exportTypeFromCLick);
  }
  else {
    XLSX.writeFile(wb, fileName + this.exportTypeFromCLick);
  }
    this.resetParameters();
    this.dataTableService.criteria["ist_total"] = "y";
    this.dataTableService.criteria["ist_page_ctrl"] =''+ this.istCtrlPage;
    this.dataTableService.criteria["ist_export_ctrl"] = 'n';

    this.load( this.dataTableService.criteria,true);
  }

  exportToExcelColumns(data: any[], fileName: string, columnsToExclude: string[]): void {
    // Create a copy of the data and exclude the specified columns
    const dataToExport = data.map(item => {
    const filteredItem = {};
    for (const key in item) {
    if (!columnsToExclude.includes(key)) {
    filteredItem[key] = item[key];
    }
    }
    return filteredItem;
    });

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveExcelFile(excelBuffer, fileName);
    }

    saveExcelFile(buffer: any, fileName: string): void {
      const data: Blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = window.URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      let timeSpan = new Date().toISOString();
      let efName = this.exportFileName || "ExportResult";
      let fName = `${efName}-${timeSpan}`;
      a.download = fName + '.xlsx';
      a.click();
      window.URL.revokeObjectURL(url);
      }

      exportButtonDisable(): Boolean {
        if (this.totalRecords <= 0) {
           return true;
        }
        return false;
      }

      clearStatusMessage(): void {
        this.globals.setStatusMessage('');
      }

      private resetParametersInternal() {
        this.changedRecords = [];
        if (this.paginator) {
          this.paginator.pageIndex = 0;
        }
        this.length = 0;
        this.workRequest = {} as WorkRequest;
        this.showPaginator = true;
        this.rowToBeHighlighted = {};
        //this.globals.hideLoadingBar();
        this.isMKCRequest = false;
        this.isReworkRequest = false;
        this.onDatatableDetailsClear.emit();
        this.refreshTableColumns();
      }

      private resetRequest(): void {
        if (this.workRequest) {
          this.workRequest.errorDetail = '';
          this.workRequest.messageId = '';
          this.workRequest.requestResult = ResponseBase.REQUEST_RESULT_SUCCESS;
        }
      }

      navigateToPage(pageEvent: PageEvent): void {
        if (this.paginator) {
        this.pageIndexChanged.emit(pageEvent);
      }
  }
}

// This is just an interface for defining columns that needs to be created and attached
// to an already realized table at runtime

