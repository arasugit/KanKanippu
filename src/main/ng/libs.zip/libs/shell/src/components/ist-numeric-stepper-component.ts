// $Id$
import { Component, forwardRef, Input, OnInit, ChangeDetectorRef,
    ChangeDetectionStrategy, ViewChild, ElementRef  } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { T21Base } from './t21-base';
import { StringUtil } from '../common/ist-string-util';
import { WorkField, WorkRequest } from '../ist-components/work-request-model';
const noop = () => {
};

export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_NUMERIC_STEPPER: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => IstNumericStepperComponent),
    multi: true
};

export const T21BASE_ACCESSOR_NUMERIC_STEPPER: any = {
    provide: T21Base,
    useExisting: forwardRef(() => IstNumericStepperComponent),
    multi: true
};

@Component(
    {
        selector: 'ist-numeric-stepper',
        templateUrl: './ist-numeric-stepper-template.html',
        changeDetection: ChangeDetectionStrategy.OnPush,
        providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_NUMERIC_STEPPER, T21BASE_ACCESSOR_NUMERIC_STEPPER]
    }
)

export class IstNumericStepperComponent extends T21Base implements ControlValueAccessor, OnInit {
    constructor(protected ref: ChangeDetectorRef) {
        super();
        this.changeDetectRef = ref;
        this.componentType = 'IstNumericStepperComponent';
        this.mandatorySymbol = ''; 
        this.requiredColon = ' : ';
        this._selfreference = this;
        this.width='15%';
    }
    private _requestProvider: WorkRequest;
    private _workField: WorkField;
    private innerValue: Number;
    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;
    private message: string;
    maxWidth: number;
    @Input() public maxAllowedLen: number;
    @Input() cfgsv: Boolean = false;
    @Input() istcontrol: Boolean = false;
    @Input() isfeepkg: Boolean = false;
    @Input() nonactfeepkg: Boolean = false;
    public bgColor: string;
    @Input() minimum: number = Number.MIN_VALUE;
    @Input() maximum: number = Number.MAX_VALUE;
    @Input() set requestProvider(value: WorkRequest) {
        this._requestProvider = value;
        if (this.tag != null && this._requestProvider != null && this._requestProvider.fields[this.tag] != null) {
            this.setWorkField(this._requestProvider.fields[this.tag]);
        }
    }
    @ViewChild('focusControl', { static: false })
    focusControl: ElementRef;

    get requestProvider(): WorkRequest {
        return this._requestProvider;
    }
    setWorkField(value: WorkField) {
        this._workField = value;
        if (this._workField != null) {
            if (StringUtil.isNotEmpty(this._workField.value)) {
                this._workField.value = this._workField.value.trim();
                this.innerValue = Number(this._workField.value);
            } else {
                if (this._workField.style === undefined || this._workField.style === null) {
                    this.innerValue = Number(this.minimum);
                    this._workField.value = this.innerValue + ''; // In case if no default value set
                }
            }
            if (this._workField.style !== undefined && this._workField.style === 'mkcStyle') {
                if (this._workField.value === null || this._workField.value === undefined) {
                    this.innerValue ={} as Number;
                }
                this.toolTipMsg = (this._workField.oldValue === undefined ? '' : this._workField.oldValue);
                this.isMkcChange = true;
            } else {
                this.isMkcChange = false;
                this.toolTipMsg = '';
                this._workField.oldValue = this._workField.value;
         }
            if (this._workField.modifyable === 'N') {
                this.isDisabled = true;
            }
        }
        this.ref.markForCheck();
    }

    propagateChange: any = () => { };
    get value(): any {
        return this.innerValue;
    }
    keyPressEvent(event: KeyboardEvent) {
        if (this.restrict === '') {
            // do nothing
        } else {
            const patternStr = '^[' + this.restrict + ']*$';
            const pattern = new RegExp(patternStr);

            const inputChar = String.fromCharCode(event.charCode);
            //  console.log('keypress event is called inputChar', inputChar, ' - ', patternStr);
            if (event.keyCode !== 8 && !pattern.test(inputChar)) {
                event.preventDefault();
            }
        }
    }

    // set accessor including call the onchange callback
    set value(v: any) {
        if (v !== this.innerValue) {
            this.innerValue = v;
            if ( this.innerValue!=undefined && this.innerValue!=null && Number(this.innerValue) > this.maximum!=null && this.maximum!=undefined && Number(this.maximum)) {
                this.innerValue = this.maximum;
            }
            if (this.innerValue!=undefined && this.innerValue!=null && Number(this.innerValue) < this.maximum!=null && this.maximum!=undefined && this.minimum) {
                this.innerValue = this.minimum;
            }
            if (this._requestProvider != null && this._requestProvider.fields[this.tag] != null) {
                this._requestProvider.fields[this.tag].value = (this.innerValue === undefined || this.innerValue === null) ? '' : this.innerValue.toString();
            }
            this.onChangeCallback(v);
        }
        this.ref.markForCheck();
    }
    // called when ngmodel changes to update the view
    writeValue(value: any) {
        this.value = value;
    }


    registerOnChange(fn: (_: any) => void): void { this.onChangeCallback = fn; }
    registerOnTouched(fn: () => void): void { this.onTouchedCallback = fn; }

    ngOnInit() {
        //  console.log(' minimum value passed ' , this.minimum);
        this.value = Number(this.minimum);
        if (this.width !== null && Number(this.width)) {
            this.maxWidth = this.width;
        }
    }

    incrementValue() {
        //  console.log(' maximum value passed ' , this.maximum);
        if (this.value === null || this.value === '' || this.value === undefined) {
            this.value = Number(this.minimum);
        } else if (this.value >= Number(this.maximum)) {
            this.value = Number(this.maximum);
        } else {
            this.value = Number.parseInt(this.value) + 1;
        }
    }

    decrementValue() {
        if (this.value === null || this.value === '' || this.value === undefined) {
            this.value = Number(this.minimum);
        } else if (this.value <= Number(this.minimum)) {
            this.value = Number(this.minimum);
        } else {
            this.value = Number.parseInt(this.value) - 1;
        }
    }
    setFocus() {
        setTimeout(() => this.focusControl.nativeElement.focus());
      }
}
