// $Id$
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, TemplateRef, ViewChild } from '@angular/core';
import { UIMetaField } from '../common/vo/ui-metadata-model';
import { DataTableService } from '../services/data-table.service';
import { RendererItem } from './data-table-column.component';
import { GlobalsService } from '../services/globals.service';

@Component({
    selector: 'app-inquiry-data-column',
    templateUrl: 'inquiry-data-table-column.component.html'
})
export class InquiryDataTableColumnComponent implements OnInit, OnChanges {
    constructor(private dataTableService: DataTableService, 
                private globals : GlobalsService) {}
    customFormatDate : boolean = false;
    @Output() cellClick = new EventEmitter<any>();
    @Output() singlViewButtonClicked = new EventEmitter<any>();
    @Input() rowIndex: any;
    @Input() name: string;

    /**
     * text to display in the table header for this column. Defaults to the column name
     */
    private _header: string;
    @Input() set header(val: string) { this._header = val; }
    get header(): string { return this._header ? this._header : this.name; }

    /**
     * name of the field in the data row which holds the volumn value. Defaults to the column name
     */
    private _dataField: string;
    @Input() set dataField(val: string) { this._dataField = val; }
    get dataField(): string {
        return this._dataField ? this._dataField : this.name;
    }

    @Input() editable;
    @Input() visible: Boolean = true;

   // @Input()
   // itemRenderer: RendererItem;

   _dataProvider: any;
    @Input()
    set dataProvider(v: any) {
        this._dataProvider = v;
        this.formatOptions[0] = String('DISPLAY-LABEL');
        this.formatOptions[1] = v;
    }

    get dataProvider (): any {
        return this._dataProvider;
    }
    @Input()
    tag: string;

    @Input()
    defaultValue;

   /*
    * Column width
    */
    @Input()
    width: String;

   /*
    * Header column width
    */
   @Input()
   headerWidth: String;

   @Input()textAlign: String;

   @Input()
   summaryField: String;

   formatOptions: any = [];
   _formatAmount: Boolean;
   @Input() set formatAmount(value: Boolean) {
       this._formatAmount = true;
       this.textAlign = 'flex-end';
       this.formatOptions[0] = 'AMOUNT';
   }
   get formatAmount(): Boolean {
       return this._formatAmount;
   }

   _formatTime: String;
   @Input() set formatTime(value: String) {
    if (value !== undefined) {
        this.formatOptions[0] = 'HH:MM:SS';
    }
    this._formatTime = value;
   }

   get formatTime(): String {
       return this._formatTime;
   }

   _dateMask : UIMetaField[];
   @Input() set dateMask(fields : UIMetaField[] ){  

    let metaDataProvider = fields[this.tag];

    if (this.globals.customDateMask && metaDataProvider != undefined) {       
        this.formatOptions[4] = metaDataProvider["mask"];   
      }      
        
   }

   get dateMask(): UIMetaField[] {
        return this._dateMask;
   }

   _formatDate: Boolean;   
   @Input() set formatDate(value: Boolean) {
   
       this.formatOptions[0] = 'DATE';
   }
   get formatDate(): Boolean {
       return this._formatDate;
   } 

   _formatDateTime: Boolean;
   @Input() set formatDateTime(value: Boolean) {
       this.formatOptions[0] = 'DATETIME';
   }
   get formatDateTime(): Boolean {
       return this._formatDateTime;
   }

   _decryptData: Boolean;
   @Input() set decryptData(value: Boolean) {
       this.formatOptions[0] = 'DECRYPT';
   }
   get decryptData(): Boolean {
       return this._decryptData;
   }

   @Input() formattedText: any;
   @Input() fields: UIMetaField;
   @Input() viewButtonTemplate: RendererItem;

   @ViewChild('cellTemplate', { static: false })
    public cellTemplate: TemplateRef<any>;

   @ViewChild('singleViewTemplate', { static: false })
    public singleViewTemplate: TemplateRef<any>;

    bgColor: string; // Set this for indicating change in data for MKC requests
    isMkcChange: boolean;
    toolTip: string; // Set this for showing old and new value for this column for MKC requests

    ngOnInit() {
        this.customFormatDate = this.globals.customDateMask;       
       // this.customFormatDate = (this.globals.currentLanguage === "en-US");
        if(this.customFormatDate){
            this.formatOptions[2] = 'CUSTOMDATE';      
            this.formatOptions[3] = this.tag;      

        }
    }
    ngOnChanges(changes: SimpleChanges): void {        
        if (changes['dataProvider'] !== undefined && changes['dataProvider'] !== null) {
            this.dataProvider = changes['dataProvider'].currentValue;
        }
    }   

   
    alignText(tag: any, fields: any) {
        // console.log('alignText called');
        let alignStyle;
        if (this.textAlign === undefined) {
        if (fields && tag) {
            const tagMetaData = fields[tag];
            if (tagMetaData) {
                const editType = tagMetaData['editType'];
                const mask = tagMetaData['mask'];
                if ((mask !== undefined && mask.indexOf('#')) > -1 && mask.indexOf('.') > -1) {
                    // this.textAlign = 'right';
                    this.formatAmount = true;
                }
                if (editType) {
                    if (editType === 'NUMBER' || editType === 'AMOUNT') {
                        this.textAlign = 'right';
                    }
                    if (editType === 'AMOUNT') {
                        this.formatAmount = true;
                    }
                }
            }
        }
    }
    alignStyle = {'justify-content': this.textAlign === 'right' ? 'flex-end' : 'flex-start'};
        return alignStyle;
    }

    gatherChangedRows(event: any) {
       // console.log ('gatherChangedRows');
        this.dataTableService.rowChanged(event);
    }

    cellClicked(item: any) {
        this.cellClick.emit(item);
    }

    loadTemplate(rowIndex) {
        this.singlViewButtonClicked.emit({ 'viewButtonTemplate': this.viewButtonTemplate, 'rowIndex': rowIndex });
    } 
    
}
