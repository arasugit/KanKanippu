// $Id$
import { Component, ElementRef, forwardRef, Input, OnInit, Renderer2 } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { T21Base } from './t21-base';
import { WorkField, WorkRequest } from '../ist-components/work-request-model';

const noop = () => {
};

export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_TA: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => IstTextAreaComponent),
    multi: true
};

export const T21BASE_ACCESSOR_TA: any = {
    provide: T21Base,
    useExisting: forwardRef(() => IstTextAreaComponent),
    multi: true
};

@Component(
    {
        selector: 'ist-textarea',
        templateUrl: './ist-textarea-template.html',
        providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_TA, T21BASE_ACCESSOR_TA]
    }
)
export class IstTextAreaComponent extends T21Base implements ControlValueAccessor, OnInit {

    constructor(protected element: ElementRef, protected renderer: Renderer2) {
        super();
        this.componentType = 'IstTextAreaComponent';
        this._selfreference = this;
        this.mandatorySymbol = '';
        this.requiredColon = ' : ';
        this.toolTipMsg = '';
    }
    private _requestProvider: WorkRequest;
    private _workField: WorkField;
    @Input() isDisabled: boolean = false;
    @Input() public width: string='0';
    private message: string;
    private innerValue: String = '';
    // Placeholders for the callbacks which are later providesd
    // by the Control Value Accessor
    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;
    @Input() size: String;
    @Input() set requestProvider(value: WorkRequest) {
        this._requestProvider = value;
        if (this.tag != null && this._requestProvider != null && this._requestProvider.fields[this.tag] != null) {
            this.setWorkField(this._requestProvider.fields[this.tag]);
        }
    }
    get requestProvider(): WorkRequest {
        return this._requestProvider;
    }
    ngOnInit() { }
    setWorkField(value: WorkField) {
        // //  console.log("textinput set workField");
        this._workField = value;
        if (this._workField != null) {
            this.innerValue = this._workField.value;
            // //  console.log("textinput set workField modifyable", this._workField.modifyable);
            if (this._workField.modifyable === 'N') {
                this.isDisabled = true;
            }
        }
    }
    propagateChange: any = () => { };
    // From ControlValueAccessor interface
    // get accessor
    get value(): any {
        return this.innerValue;
    }
    // set accessor including call the onchange callback
    set value(v: any) {
        // //  console.log ("set value called");
        if (v !== this.innerValue) {
            //   //  console.log ("set value inside");
            this.innerValue = v;
            if (this._requestProvider != null && this._requestProvider.fields[this.tag] != null) {
                this._requestProvider.fields[this.tag].value = this.innerValue.toString();
                //  //  console.log ("after update " , this._requestProvider.fields[this.tag].value);
            }
            this.onChangeCallback(v);
        }
    }
    // called when ngmodel changes to update the view
    writeValue(value: any) {
        this.value = value;
    }
    registerOnChange(fn: (_: any) => void): void { this.onChangeCallback = fn; }
    registerOnTouched(fn: () => void): void { this.onTouchedCallback = fn; }
    updateRequestProvider(msg: string): void {
        //  console.log('updateRequestProvider event received in textInput', msg);
    }
    clearValue() {
      this.innerValue = '';
      this.onChangeCallback(this.innerValue);
    }
    onFocusout() {
    }
}
