// $Id$
import {
  Component,
  EventEmitter,
  ExistingProvider,
  forwardRef,
  Input,
  OnInit,
  Output,
  ChangeDetectorRef,
  AfterViewInit,
  ChangeDetectionStrategy
} from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { T21Base } from './t21-base';
import { WorkField, WorkRequest } from '../ist-components/work-request-model';
const noop = () => {};

const CUSTOM_CHECKBOX_VALUE_ACCESSOR: ExistingProvider = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => IstCheckBoxComponent),
  multi: true
};
const T21BASE_ACCESSOR: ExistingProvider = {
  provide: T21Base,
  useExisting: forwardRef(() => IstCheckBoxComponent),
  multi: true
};
@Component({
  selector: 'ist-checkbox',
  templateUrl: './ist-checkbox-template.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [CUSTOM_CHECKBOX_VALUE_ACCESSOR, T21BASE_ACCESSOR]
})
export class IstCheckBoxComponent extends T21Base
  implements OnInit, AfterViewInit {
  private innerChecked: Boolean = false;
  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;

  @Output() onClicked = new EventEmitter<any>();
  @Output() onChange = new EventEmitter<MatCheckboxChange>();

  constructor(private ref: ChangeDetectorRef) {
    super();
    this.componentType = 'IstCheckBoxComponent';
  }

  @Input() alignControl: string;
  private _requestProvider: WorkRequest;
  private _workField: WorkField;
  @Input() isHidden: Boolean = false;

  @Input() checkedValue: string = 'Y';
  @Input() unCheckedValue: string = 'N';

  ngOnInit() {
    //  console.log('ISTCheckBox from ngOnInit: ', this.tag);
  }

  ngAfterViewInit() {
    // this.ref.detach();
  }
  registerOnChange(fn): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn): void {
    this.onTouchedCallback = fn;
  }
  writeValue(value) {
    //  console.log('ISTCheckBox from writeValue: ', value);
    this.checked = value;
    this.ref.markForCheck();
  }

  // get accessor
  get checked(): any {
    // console.log('get value called from ISTCheckBox: ', this.tag, this.innerChecked);
    return this.innerChecked;
  }
  @Input()
  set checked(v: any) {
    //  console.log('set value called ISTCheckBox: ', this.innerChecked);
    if (v !== this.innerChecked) {
      this.innerChecked = v;
      if (
        this._requestProvider != null &&
        this._requestProvider.fields[this.tag] != null
      ) {
        if (this.innerChecked) {
          this._requestProvider.fields[this.tag].value = this.checkedValue;
        } else {
          this._requestProvider.fields[this.tag].value = this.unCheckedValue;
        }
      }
      this.onChangeCallback(v);
      this.ref.markForCheck();
    }
  }
  @Input()
  set requestProvider(value: WorkRequest) {
    this._requestProvider = value;
    if (
      this.tag != null &&
      this._requestProvider != null &&
      this._requestProvider.fields[this.tag] != null
    ) {
      this.setWorkField(this._requestProvider.fields[this.tag]);
      // console.log('calling mark for check in requestProvider');
      this.ref.markForCheck();
    }
  }

  get requestProvider(): WorkRequest {
    return this._requestProvider;
  }
  setWorkField(value: WorkField) {
    //  console.log('setWorkField in checkBox', value , ' for ' , this.tag);
    this._workField = value;
    if (this._workField != null) {
      if (
        this._workField.value != null &&
        (this._workField.value.toLocaleUpperCase() === this.checkedValue ||
          this._workField.value.toLocaleUpperCase() === 'YES')
      ) {
        this.innerChecked = true;
      } else {
        this.innerChecked = false;
      }
      if (this._workField.modifyable === 'N') {
        this.isDisabled = true;
      }

      if (
        this._workField.style !== undefined &&
        this._workField.style === 'mkcStyle'
      ) {
        // this.bgColor = 'yellow';
        this.isMkcChange = true;
      } else {
        this.isMkcChange = false;
        this._workField.oldValue = this._workField.value; // old value copied here for comparison
      }
      this.ref.markForCheck();
      this.onChangeCallback(this.innerChecked);
    }
  }
  emit(event: MatCheckboxChange) {
    this.onClicked.emit(this.innerChecked); // This is for custom renderers
    this.onChange.emit(event); // So that consuming components can get the MatCheckbox itself of this event
  }
  clearValue(): void {
    this.innerChecked = false;
    this.ref.markForCheck();
    this.onChangeCallback(this.innerChecked);
  }

  getValue(): any {
    return this.innerChecked ? this.checkedValue : this.unCheckedValue;
  }
}
