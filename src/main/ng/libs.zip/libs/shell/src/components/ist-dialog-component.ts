import { Component, Input, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { CommonConstants } from '../common/ist.common.constants';

@Component({
  selector: 'ist-dialog',
  templateUrl: './ist-dialog-template.html'
})

export class IstDialogComponent implements OnInit {
  constructor(public istDialogRef: MatDialogRef<IstDialogComponent>) {

  }
  public confirmMessages: any;
  public confirmMessage: String = 'Please set an appropriate message';
  public type: String; // I - information, W - Warning, E - Error, else - default (just message alone will be shown without title)
  typeDescription?: string;
  @Input() ok: Boolean = false;
  @Input() yes: Boolean = false;
  @Input() no: Boolean = false;
  @Input() cancel: Boolean = false;
  @Input() yesLabel: string = 'Yes';
  @Input() noLabel: string = 'No';
@Input()
set buttonFlags(flags: number) {
  //  console.log(' Alert buttonFlags : ', flags.toString(2));
  this.ok = false;
  this.yes = false;
  this.no = false;
  this.cancel = false;
  let bitString: string = flags.toString(2);

  if (bitString !== undefined && bitString.length > 0 && bitString.length <= 4)   {
  const zeroStr = '0';
  const zeros: string = zeroStr.repeat(4 - bitString.length);
    

  bitString = zeros + bitString;

  for (let i = 0 ; i < bitString.length; i++) {
    if (bitString[i] === '1')     {
      switch (i)  {
        case 0 : this.cancel = true; break;
        case 1 : this.ok = true; break;
        case 2 : this.no = true; break;
        case 3 : this.yes = true; break;
      }
   }
}
  }
}
get buttonFlags() {
  return this.buttonFlags;
}
  ngOnInit(): void {
    if (CommonConstants.INFORMATION === this.type) {
      this.typeDescription = 'Information';
    } else if (CommonConstants.WARNING === this.type) {
      this.typeDescription = 'Warning';
    } else if (CommonConstants.ERROR === this.type) {
      this.typeDescription = 'Error';
    } else if (CommonConstants.CONFIRMATION === this.type) {
      this.typeDescription = 'Confirmation';
    } else {
      this.typeDescription = undefined;
    }
    this.confirmMessages = this.confirmMessage.split('\\n');
  }

  onCloseYes() {
    this.istDialogRef.close('Yes');
  }
  onCloseNo() {
    this.istDialogRef.close('No');
  }
  onCloseOk() {
    this.istDialogRef.close('Ok');
  }
  onCloseCancel() {
    this.istDialogRef.close('Cancel');
  }
}