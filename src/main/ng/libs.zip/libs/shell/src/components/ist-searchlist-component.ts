import { AfterViewInit, Component, Inject, OnInit, QueryList, ViewChildren } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DataTableDetailComponent } from './data-table.detail.component';
import { IstInputComponent } from './ist-input-component';
import { GlobalsService } from '../services/globals.service';
import { InstService } from '../services/inst.service';
import { SearchListComponent } from './base-searchlist-component';
import { StringUtil } from '../common/ist-string-util';
import { CommonConstants } from '../common/ist.common.constants';
import { MenuService } from '../services/menu.service';

  @Component({
    selector: 'ist-searchlist',
    templateUrl: './ist-searchlist-template.html',
  })
  export class IstSearchListComponent extends SearchListComponent implements OnInit , AfterViewInit {
    constructor( private windowRef: MatDialogRef<IstSearchListComponent>,
      @Inject(MAT_DIALOG_DATA) public data: any,
      public instService: InstService,
      public globalsService: GlobalsService,
      public menuServices: MenuService
      ) {
      super(data);
      windowRef.disableClose = false;
      }
  

  authModeFlg = false;
  istcmsappFlg = false;

  filterSlData: any[];
  screenName; screenId;
  showFirstNineDigitsOfEntityId = false;
  showAdditionalColumns = false; // this is for  EntityGroupDetail screen acqentityidpopup column visible

  deleteAllOption: boolean;  // delete popup

  ngOnInit() {
      super.ngOnInit();
      this.setTemplateReference();
  }

  setTemplateReference(): void  {
    super.setTemplateReference();
    switch (this.type) {
      case 'CHILD_TABLES_POPUP':
      this.DIALOG_TITLE = 'Delete Information';
      this.deleteTableMsg = 'There are constraints with one or more records.To delete the $tablename and all the ' +
      ' records click the Delete button and confirm';
        this.SLTemplate = this.childTablePopup;
        this.showChildTablePopup();
        break;
      case 'MKC_REMARKS_POPUP':
      this.windowRef.updateSize('400px', '200px');
      this.DIALOG_TITLE = 'Remarks';
      this.SLTemplate = this.mkcRemarksPopup;
      this.showMKCRemarksPopup();
      break;
      }
  //  if (this.type === 'CHILD_TABLES_POPUP') {   // there is no need for db call, try to assign orgSlData here itself to avoid errors
  //    this.showChildTablePopup(); }
  }


clearFields(): void {
  super.clearFields();
      if (this.type === 'SCREENNAMEPOPUP') {
        this.filterSlData = [];
      }
    return;
  }

  findScreenNames() {
    this.menuServices.getScreenNames().subscribe((slData: any[]) => {
    this.orgSlData = slData;
    this.filterSlData = slData;
    } );
    }

  getDataFromGblCtrl() {
    this.instService.getSearchListfromGblVal(this.type).subscribe((slData) => {
    this.updateResults(slData as []);
    });
    return;
  }

  filterScreenNames() {
      this.searchFields.forEach(childControl => {
          const comp: IstInputComponent = childControl;
              if (comp.paramName === 'screen_name') {
              this.screenName = comp.getValue();
              } else if (comp.paramName === 'screen_id') {
                this.screenId = comp.getValue();
              }
          });
    if (StringUtil.isNotEmpty(this.screenName) || StringUtil.isNotEmpty(this.screenId)) {
    this.filterSlData = this.orgSlData.filter(item =>
        this.filterScreen(item.description, this.screenName) ||
        this.filterScreen(item.auth_id, this.screenId));
    } else {
    this.filterSlData = this.orgSlData;
    }
  }

filterScreen(data: any, filter: string): boolean {
  let val = false;
  if (StringUtil.isNotEmpty(filter) && data.toLowerCase().indexOf(filter.toLowerCase()) !== -1) {
    val = true;
  }
return val;
}

findRecords(): void {
    if (this.type === 'SCREENNAMEPOPUP') {
      this.filterScreenNames();
      return;
    }
    super.findRecords();
        return;
  }

updateResults(slData: any[]): void {
      super.updateResults(slData);
        if (this.type === 'KEY_ID_POPUP') {
          if (slData === null || slData.length === 0) {
            this.windowRef.close();
            this.globalsService.showDialog(CommonConstants.INFORMATION, 'MSG82',CommonConstants.ALERT_OK)?.subscribe(result => {
                if ('Ok' === result) {
                  return;
                }
              });
          }
        }
   }
ngAfterViewInit() {
      // console.log('ngAfterViewInit searchFields', this.searchFields);
      if (this.type === 'SCREENNAMEPOPUP') {
      this.findScreenNames();
      } else if (this.type === 'LIMIT_TRAN_TYPE_VAL') {
      this.getDataFromGblCtrl();
    } else if (this.type === 'CHILD_TABLES_POPUP' || this.type === 'MKC_REMARKS_POPUP') {
      return;
    } else {
      super.ngAfterViewInit();
    }
}

onItemClick(selectedItem: any) {
      this.selectedItem = selectedItem;
      this.windowRef.close(selectedItem);
    }

showEntityId = (item: any, column: DataTableDetailComponent) => {
  if (item == null) {
  return '';
  }
const temp: string = item.entityId;
if (StringUtil.isNotEmpty(temp) && temp.length > 9 && this.showFirstNineDigitsOfEntityId) {
  return(temp.substring(0 , 9));
}
return temp;
}

showChildTablePopup(): void {
    if (this.data.defaultParams) {
     if (this.data.defaultParams.deleteAllOption !== undefined && this.data.defaultParams.deleteAllOption === 'Y') {
       this.deleteAllOption = true;
       if (this.data.defaultParams.parentTableName !== undefined) {
        this.deleteTableMsg = this.deleteTableMsg.replace('$tablename', this.data.defaultParams.parentTableName);
      }
     }  else { this.deleteAllOption = false;
      this.deleteTableMsg = 'There are constraints with one or more records'; }
    }

     if (this.data.defaultParams.tableList !== undefined) {
     //  console.log('this.data.defaultParams.tableList', this.data.defaultParams.tableList);
      this.orgSlData = this.data.defaultParams.tableList;
     }
  }

 // this method is for child table popup
  delete() {
    this.windowRef.close('delete');
  }
  // this method is for child table popup
  close() {
    this.windowRef.close('close');
  }
// the method is added for MKC
showMKCRemarksPopup(): void {
  // console.log(' mkc remarks popup', this.data.defaultParams);
  if (this.data.defaultParams) {
    if (this.data.defaultParams.remarks !== undefined) {
      this.remarksText = this.data.defaultParams.remarks;
    }
    if (this.data.defaultParams.disableFlag !== undefined) {
      this.disableRemarks = this.data.defaultParams.disableFlag;
    }
    if (this.data.defaultParams.mkcBtnAction !== undefined) {
      this.mkcBtnAction = this.data.defaultParams.mkcBtnAction;
    }
  }
}
mkcDone() {
  const returnObj = {
    remarks: this.remarksText,
    btnAction: 'DONE',
    mkcBtnAction : this.mkcBtnAction,
  } ;
  this.windowRef.close(returnObj);
}
mkcCancel() {
  const returnObj = {
    btnAction: 'CANCEL'
  };
  // console.log('mkcCancel called');
  this.windowRef.close(returnObj);
}
closeDialog(): void {
  this.windowRef.close();
}
}
