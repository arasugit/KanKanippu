// $Id$
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, TemplateRef, Type, ViewChild, ComponentRef, ViewContainerRef, ComponentFactoryResolver, Injector } from '@angular/core';
import { UIMetaField } from '../common/vo/ui-metadata-model';
import { DataTableService } from '../services/data-table.service';
import { Permissions } from '../common/permissions';
import { GlobalsService } from '../services/globals.service';
import { MatDialog } from '@angular/material/dialog';

@Component({
    selector: 'app-data-column',
    templateUrl: 'data-table-column.component.html'
})
export class DataTableColumnComponent implements OnInit, OnChanges {

    constructor(private dataTableService: DataTableService, public globals: GlobalsService, public dialog?: MatDialog, public viewContainerRef?: ViewContainerRef,
        public componentFactoryResolver?: ComponentFactoryResolver) {
      }
    @Output() cellClick = new EventEmitter<any>();
    @Output() singlViewButtonClicked = new EventEmitter<any>();
    @Output() fieldChange = new EventEmitter<any>();
    @Input() rowIndex: any;
    @Input() name: string;

    /**
     * text to display in the table header for this column. Defaults to the column name
     */
    private _header: string;
    @Input() set header(val: string) { this._header = val; }
    get header(): string { return this._header ? this._header : this.name; }

    /**
     * name of the field in the data row which holds the volumn value. Defaults to the column name
     */
    private _dataField: string;
    @Input() set dataField(val: string) { this._dataField = val; }
    get dataField(): string {
        return this._dataField ? this._dataField : this.name;
    }

    @Input() editable;
    @Input() visible: Boolean = true;
    @Input() readonly: Boolean = false; // Always readonly if set to true

    @Input()
    labelFunction: (item: any, column: DataTableColumnComponent) => string;

    @Input()
    itemRenderer: RendererItem;

    @Input()
    cntrlType:string;

    _dataProvider: any;
    @Input()
    set dataProvider(provider: any) {
        this._dataProvider = provider;
        this.formatOptions[0] = String('DISPLAY-LABEL');
        this.formatOptions[1] = provider;
    }

    get dataProvider (): any {
        return this._dataProvider;
    }

    @Input()
    tag: string;

    @Input()
    defaultValue;

   /*
    * Column width
    */
    @Input()
    width: String;

   /*
    * Header column width
    */
   @Input()
   headerWidth: String;

   @Input()textAlign: String;

   formatOptions: any = [];
   _formatAmount: Boolean;
   @Input() set formatAmount(value: Boolean) {
       this._formatAmount = true;
       this.textAlign = 'flex-end';
       this.formatOptions[0] = 'AMOUNT';
   }
   get formatAmount(): Boolean {
       return this._formatAmount;
   }

   _formatTime: String;
   @Input() set formatTime(value: String) {
    if (value !== undefined) {
        this.formatOptions[0] = value;
    }
    this._formatTime = value;
   }

   get formatTime(): String {
       return this._formatTime;
   }

   _formatDate: Boolean;
   @Input() set formatDate(value: Boolean) {
       this.formatOptions[0] = 'DATE';
   }
   get formatDate(): Boolean {
       return this._formatDate;
   }

   _decryptData: Boolean;
   @Input() set decryptData(value: Boolean) {
       this.formatOptions[0] = 'DECRYPT';
   }
   get decryptData(): Boolean {
       return this._decryptData;
   }

   _dateMask : UIMetaField[];
   @Input() set dateMask(fields : UIMetaField[] ){

    let metaDataProvider = fields[this.tag];

    if (this.globals.customDateMask && metaDataProvider != undefined) {
        this.formatOptions[4] = metaDataProvider["mask"];
      }

   }

   get dateMask(): UIMetaField[] {
        return this._dateMask;
   }


   @Input() formattedText: any;
   @Input() fields: UIMetaField;
   @Input() viewButtonTemplate: RendererItem;

   @ViewChild('cellTemplate', { static: false })
    public cellTemplate: TemplateRef<any>;

    @ViewChild('headerCellTemplate', { static: false })
    public headerCellTemplate: TemplateRef<any>;

    @ViewChild('customCellTemplate', { static: false })
    public customCellTemplate: TemplateRef<any>;

    @ViewChild('singleViewTemplate', { static: false })
    public singleViewTemplate: TemplateRef<any>;

    bgColor: string; // Set this for indicating change in data for MKC requests
    isMkcChange: boolean;
    toolTip: string; // Set this for showing old and new value for this column for MKC requests
    customFormatDate: boolean = false;
    ngOnInit() {
        this.customFormatDate = this.globals.customDateMask;
        // this.customFormatDate = (this.globals.currentLanguage === "en-US");
         if(this.customFormatDate){
             this.formatOptions[2] = 'CUSTOMDATE';
            this.formatOptions[3] = this.tag;


         }
    }
    ngOnChanges(changes: SimpleChanges): void {
        if (changes['dataProvider'] !== undefined && changes['dataProvider'] !== null) {
            this.dataProvider = changes['dataProvider'].currentValue;
        }
    }


    alignText(tag: any, fields: any) {
        let alignStyle;
        if (this.textAlign === undefined) {
        if (fields && tag) {
            const tagMetaData = fields[tag];
            if (tagMetaData) {
                const editType = tagMetaData['editType'];
                const mask = tagMetaData['mask'];
                if ((mask !== undefined && mask.indexOf('#')) > -1 && mask.indexOf('.') > -1) {
                    this.formatAmount = true;
                }
                if (editType) {
                    if (editType === 'NUMBER' || editType === 'AMOUNT') {
                        this.textAlign = 'right';
                    }
                    if (editType === 'AMOUNT') {
                        this.formatAmount = true;
                    }
                }
            }
        }
    }
    alignStyle = {'justify-content': this.textAlign === 'right' ? 'flex-end' : 'flex-start'};
        return alignStyle;
    }

    gatherChangedRows(event: any) {
        this.dataTableService.rowChanged(event);
        this.fieldChange.emit(event);
    }

    cellClicked(item: any) {
        this.cellClick.emit(item);
    }
    // This is only for OAS Entitlement Control single page form as a special case scenario; may be we can do it with a renderer but
    // this functionality is only for a particular column and value. Hence adding here for now.
    // TODO: May be we can have a conditional renderer (for DataTableColumnComponent) - i.e. based on some
    // expression either render the column using the user defined renderer or the standard way. Hence this logic
    // can be put in the rederer itself.
    isDisabled (row: any, column: DataTableColumnComponent,  permissions: Permissions): Boolean {
         console.log('isDisabled', row.fieldName, column.dataField);
        if (row.fieldName === 'pan_mask_pattern' && column.dataField === 'fieldValue') {
            const panMaskPermission = permissions.PMP;
            if (panMaskPermission !== undefined && panMaskPermission && row.updateAllowed !== undefined &&
                 row['updateAllowed'].toUpperCase() === 'Y') {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    isEditable(column: DataTableColumnComponent, permissions: Permissions, row: any, isReworkRequest: Boolean,
         isMKCRequest: Boolean, isCheckerView: Boolean, userID: string): Boolean {
            column.isMkcChange = false;
            column.toolTip = '';
            column.bgColor = '';
            if (column.readonly) {
                return false;
            }

            if (permissions) {
                if (permissions.mkc) {
                    if (column.dataField !== 'mkcStatus' && column.dataField !== 'mkcRemarks') {
                        let actualRow: any;
                        if (row.orignalRow) {
                            actualRow = row.orignalRow;
                        } else if (row.originalRow) {
                            actualRow = row.originalRow;
                        }
                        if (row.mkcStatus && row.mkcStatus === 'S' || row.mkcStatus === 'W' ||
                             (permissions.C && isMKCRequest && !(isReworkRequest))) {
                            if (actualRow && actualRow[column.dataField]) {
                                if (row.dbAction === 'd') {
                                    column.toolTip = 'Deleted record';
                                } else if (typeof row[column.dataField] === 'string' &&
                                             row[column.dataField].trim() !== actualRow[column.dataField].trim()) {
                                    column.isMkcChange = true;
                                    column.toolTip = 'Old value : ' + actualRow[column.dataField];
                                } else if (row[column.dataField] !== actualRow[column.dataField]) {
                                   column.isMkcChange = true;
                                    column.toolTip = 'Old value : ' + actualRow[column.dataField];
                                }
                            } else { // Not sure this is needed; but replicating flex code here. To be discussed
                                if (row.dbAction === 'a' && !actualRow) {
                                    column.toolTip = 'New record';
                                } else if (row.dbAction === 'd' && actualRow) {
                                    column.toolTip = 'Deleted record';
                                } else if ((row.dbAction === 'c' || row.dbAction === 'x')
                                            && (actualRow && !(actualRow[column.dataField]) && row[column.dataField])) {
                                    column.isMkcChange = true;
                                    column.toolTip = 'New value';
                                }
                            }
                        }
                    }
                    if (column.isMkcChange === true) {
                        column.bgColor = 'inset 0 0 30px yellow';
                    }
                }
                if (row.inactive !== undefined && row.inactive.toLowerCase() === 'y') {
                    return false;
                }
                if (row.mkcId !== undefined) {
                    if ((permissions.mkc && !(permissions.C) && isMKCRequest && !(isReworkRequest))) {
                        return false;
                    }
                    if (permissions.mkc && permissions.C && isMKCRequest && !(isReworkRequest)) {
                        if (userID && row.makerId === userID) {
                            return false;
                        }
                        if (column.dataField !== 'mkcStatus' && column.dataField !== 'mkcRemarks') {
                            return false;
                        } else {
                            return true;
                        }
                    }
                    if (permissions.mkc && row.mkcStatus === 'W') {
                        // Maker Rework MKC record - should not be editable
                        if (((row.dbAction === 'a') && !(permissions.I)) || ((row.dbAction === 'c')
                            && !(permissions.U)) || ((row.dbAction === 'd') && !(permissions.D))) {
                            return false;
                        }
                        if (row.dbAction === 'c' && (!(column.editable) || column.dataField === 'mkcRemarks')) {
                            return false;
                        }
                        if (row.dbAction === 'a' && column.dataField === 'mkcRemarks') {
                            return false;
                        }
                    }
                }

            if (!isCheckerView && !isReworkRequest && isMKCRequest) {
                return false;
            }

            if (isCheckerView) {
                return false;
            }

            if (row.dbAction !== null && row.dbAction !== undefined
                && ((column.editable === true && permissions.U) || (row.dbAction.toLowerCase() === 'a'))
                    && (row.dbAction.toLowerCase() !== 'd' && row.dbAction.toLowerCase() !== 'dummy')) {
                    return true;
                }
            }
        return false;
    }

    loadTemplate(rowIndex) {
        this.singlViewButtonClicked.emit({'viewButtonTemplate': this.viewButtonTemplate, 'rowIndex':rowIndex});
    }

}

export class RendererItem {
   constructor(public component: Type<CustomRenderer>, public comboBoxType?: String, public isGlbVal?: Boolean, public dataProvider?: any, public size?: any) {}
     // dataProvider and size for SingleView page
}

export abstract class CustomRenderer {
    constructor() {
        // All permissions are set to false by default
        this.permissions.I = false;
        this.permissions.U = false;
        this.permissions.D = false;
        this.permissions.Q = false;
        this.permissions.C = false;
        this.permissions.mkc = false;
    }
    comboBoxType: String;
    isGlbVal: Boolean;
    row: any;
    rowIndex: any;
    column: DataTableColumnComponent;
    value: any;
    onSelectedRowChange: EventEmitter<any>;
    cellClick: EventEmitter<any>;
    permissions: Permissions = {};
    dataProvider: any;
    isMKCRequest: Boolean;
    isReworkRequest: Boolean;
    isCheckerView: Boolean;
    userID: string;
    viewButtonTemplate: Type<any>;
    fields: any; // Metadata prvider for collections

    abstract propagateChangedRow(row: any): void;

    // Default implementation for renderers; override as necessary for special/additional business cases.
    public isDisabled(): Boolean {
        return (!(this.column.isEditable(this.column, this.permissions, this.row, this.isReworkRequest,
             this.isMKCRequest, this.isCheckerView, this.userID)));
    }


}
