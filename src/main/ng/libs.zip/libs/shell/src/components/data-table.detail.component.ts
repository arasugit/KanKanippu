import { ChangeDetectorRef, Component, ComponentFactoryResolver, ElementRef, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewContainerRef } from '@angular/core';
import { DataTableService } from '../services/data-table.service';
import { GlobalsService } from '../services/globals.service';
import { WorkCollection} from '../ist-components/work-request-model';
import { DataTableSource } from './abstract-data-table.component';
import { DataTableColumnComponent } from './data-table-column.component';
import { DataTableEditableComponent } from './data-table-editable.component';
import { MatDialog } from '@angular/material/dialog';
import { ColumnOnDemand } from './column-on-demand.component';
import { AutoRefreshService, InstService } from '../services';

@Component({
  selector: 'app-data-table-detail',
  templateUrl: 'data-table-editable.component.html',
  styles: [`.highlight{background: #fef8cc;}
            .delete{background: #a9a9a9;}
            .error{background: #a9a9a9;}
          `]
})

export class DataTableDetailComponent extends DataTableEditableComponent implements OnChanges {
  @Input() showEmptyRows: Boolean = false; // Certain screens require a empty row to be shown incase of no records

  public columnsOndemand: ColumnOnDemand[] = [];
  showSave = false;
  showCancel = false;
  @Output() itemEditEnd = new EventEmitter<any>();

  constructor(private dts: DataTableService, public cd: ChangeDetectorRef,
    private gbs: GlobalsService,
    public autoRefreshService: AutoRefreshService,
    private vcr: ViewContainerRef,
    private cfr1: ComponentFactoryResolver,dlg:MatDialog,public elementRef: ElementRef,public instService: InstService) {
    super(dts, cd, gbs, autoRefreshService, vcr, cfr1,dlg,elementRef,instService);
    //  console.log('calling super from DataTableDetailComponent');
  }

  ngOnChanges(changes: SimpleChanges) {
    try {
      this.consolidatePermissions(changes);
      this.setOtherInputs(changes);
      let records: any[]=[];
      if (changes['dataProvider'] !== undefined && changes['dataProvider'] !== null) {
        if (Array.isArray(changes['dataProvider'].currentValue)) { // For search list result it is not a workrequest but an array
            records = changes['dataProvider'].currentValue;
        } else { // Try with WorkRequest
          this.workRequest = changes['dataProvider'].currentValue;
          if (this.workRequest && this.workRequest !== undefined && this.workRequest.collections
             && this.workRequest.collections !== undefined) {
            if (this.workRequest.collections[this.collectionTag] && this.workRequest.collections[this.collectionTag] !== undefined) {
              if (this.editable) {
                const localWc: WorkCollection = this.workRequest.collections[this.collectionTag];
                localWc.remoteClass = WorkCollection.remoteClassName;
              }
              records = this.workRequest.collections['' + this.collectionTag].rows;
            }
          }
        }
        // Load the datatable records
        this.loadRecords(records);
      }
      // Now add any columns if defined on the runtime
      this.addColumn();
    } catch (e) {
      // ignore
      this.clear();
    }
  }

  protected loadRecords(records: any[]) {
    if (records && records !== undefined) {
      if (records.length <= 0) {
        if (this.showEmptyRows) {
          this.addDummyRow();
          this.length = 1; // Just adding an empty row
        } else {
          // Clear the table
          this.length = records.length;
        }
      } else {
        if (this.editable) {
          records.forEach(record => {
            record['remoteClass'] = this.remoteClass;
          });
        }
        this.dataSource = new DataTableSource(records);
        this.length = records.length;
        this.dataSource.sort = this.sort;
      }
    }
  }

  private addDummyRow() {
    const row = super.addRow();
    row['dbAction'] = ''; // No need to edit this row.
    this.rowToBeHighlighted = {}; // No need to highlight as this is a dummy row to show no data retrieved
  }

  deleteRow() {
    super.deleteRow();
    this.showPaginator = false;
  }

  protected addColumn() {
    this.columnsOndemand.forEach (column => {
      const columnFactory = this.cfr.resolveComponentFactory(DataTableColumnComponent);
      const col = this.vcr.createComponent(columnFactory);
      col.instance.itemRenderer = column.renderer;
      col.location.nativeElement.innerHTML = '';
      col.instance.editable = column.editable;
      col.instance.header = column.header ? column.header : 'Header';
      col.instance.name = column.name ? column.name : 'name';
      col.instance.dataField = column.dataField ? column.dataField : 'dataField';
      col.instance.labelFunction = column.expression;
      this.allColumns.push(col.instance);
      this.displayedColumns.push(col.instance.name);
    });
  }

  protected clear() {
    // this.isLoadingResults = false;
    // this.loadingMessage = '';
    this.globals.hideLoadingBar();
    this.length = 0;
  }

  addColumnsOnDemand(col: ColumnOnDemand) {
    if (col) {
      this.columnsOndemand.push(col);
    }
  }

  gatherChangedRow(event: any) {
    super.gatherChangedRow(event);
    this.itemEditEnd.emit(event);
  }

  showDummy() {
    return;
  }

  clearColumnsOnDemand() {
    // Yet to implement
  }
}

