
import { AfterViewInit, Component, ElementRef, HostListener, OnInit, Renderer2, ViewChild ,Input,
    Output, EventEmitter, ContentChildren, QueryList, AfterContentInit} from '@angular/core';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { PageEvent} from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { BehaviorSubject, Observable } from 'rxjs';
import { CdkVirtualScrollViewport,FixedSizeVirtualScrollStrategy,VIRTUAL_SCROLL_STRATEGY} from "@angular/cdk/scrolling";
import { WorkRequest } from '../ist-components/work-request-model';
import { DataTablePaginatorComponent } from './data-table.paginator.component';
import { GlobalsService } from '../services/globals.service';
import { SLDataTableColumnComponent } from './sl-data-table-column.component';


 
 // datatables source
 class DataTableSource extends MatTableDataSource<any[]> {
   get allData(): any[] {
     return this.data.slice();
   }
 
   set allData(data: any[]) {
     this.data = data;
     this.viewport.scrollToOffset(0);
     this.viewport.setTotalContentSize(this.itemSize * data.length);
     this.visibleData.next(this.data.slice(0, PAGESIZE));
   }
   offset = 0;
   offsetChange = new BehaviorSubject(0);
   constructor(private records: any[], private viewport: CdkVirtualScrollViewport, private itemSize: number) {
       super();
   this.data = records;
   this.viewport.elementScrolled().subscribe((ev: any) => {
     const start = Math.floor(ev.currentTarget.scrollTop / ROW_HEIGHT);
     const prevExtraData = start > 5 ? 5 : 0;
     // const prevExtraData = 0;
     const slicedData = this.data.slice(start - prevExtraData, start + (PAGESIZE - prevExtraData));
     this.offset = ROW_HEIGHT * (start - prevExtraData);
     this.viewport.setRenderedContentOffset(this.offset);
     this.offsetChange.next(this.offset)
     this.visibleData.next(slicedData);
   });
 }
 private readonly visibleData: BehaviorSubject<any[]> = new BehaviorSubject([]);
 }
 const PAGESIZE = 20;
 const ROW_HEIGHT = 48;
 /**
  * Virtual Scroll Strategy
  */
 export class CustomVirtualScrollStrategy extends FixedSizeVirtualScrollStrategy {
   constructor() {
     super(ROW_HEIGHT, 1000, 2000);
   }
 
   attach(viewport: CdkVirtualScrollViewport): void {
     this.onDataLengthChanged();
   }
 }
 
 
 @Component({
   selector: 'app-sl-data-table',
   templateUrl: 'sl-data-table.component.html'
   ,
   styleUrls: ['./sl-data-table.component.scss'],
   providers: [{provide: VIRTUAL_SCROLL_STRATEGY, useClass: CustomVirtualScrollStrategy}],
  
 })
 
 // This component will be used for list screen non-editable datatgrid, search list and detail page non-editable datagrid
 export class SLDataTableComponent implements  OnInit, AfterViewInit, AfterContentInit {

   
   @ViewChild(CdkVirtualScrollViewport, { static: true }) viewport: CdkVirtualScrollViewport; 
   @ViewChild(MatTable, {read: ElementRef , static: false }) private matTableRef: ElementRef;
   @ViewChild(MatSort, { static: true }) sort: MatSort;
   @ContentChildren(SLDataTableColumnComponent)
   protected columnElements: QueryList<SLDataTableColumnComponent>;


   @Input() collectionTag: string;
   @Input() width: String; 
   @Input() minWidth: String;
   @Input() maxViewWidth: String = '97vw';
   @Input() needsTotal:boolean = false; //needs_total to decide find a new record or More in the pagination
   @Output() itemClick = new EventEmitter<any>();
   @Output() pageIndexChanged = new EventEmitter<PageEvent>();
   @Input() textAlign: String;
    
   formatOptions: any = [];
    _formatAmount: Boolean; 
   placeholderHeight = 0;
   itemSize = 48;
   totalRecords:number = 0; 
   displayedColumns: string[] = [];
   _records: any[] ;
   _dataProvider: any[];
   _workRequest:WorkRequest;
   dataSource: DataTableSource;
   showTotal = true;
   pressed = false;
   currentResizeIndex: number;
   startX: number;
   startWidth: number;
   isResizingRight: boolean;
   resizableMousemove: () => void;
   resizableMouseup: () => void; 
   pageSize:number;
   public selection = new SelectionModel(true, []);

   ngAfterContentInit() {
     if (this.columnElements && this.columnElements.length > 0) {
       this._columns = this.columnElements.toArray();
     }
    this.setDisplayedColumns();
   }
 
 _columns: any[];
 
 @Input()
 set columns(v:any[]) {
   this._columns =v;
 }
 
 get columns():any[] {
   return this._columns;
 }
 
   @Input() set records(v:any[]) {
     this._records = v;
     if (this._records !== undefined)
   this.dataSource = new DataTableSource(this._records,this.viewport, this.itemSize);
   this.dataSource.offsetChange.subscribe(offset => {
     this.placeholderHeight = offset
   })
   this.dataSource.allData = this._records;
   this.dataSource.sort = this.sort;
 }
   get records():any[] {
     return this._records;
 }


 
 @Input() set dataProvider(w:any) {
    if (w !== undefined){
      console.log(w);
     //Condition for searchlist with checkbox
     if((Array.isArray(w[0] ) ) && ( w[1] && (typeof w[1] === "number" )  ) ){
       this._dataProvider = w[0];
       this.totalRecords = w[1];
       this.needsTotal = w[2];
     }
    else if(!(Array.isArray(w[0])) || !(typeof w[1] === "number")){    
       //Condition for normal searchlist
       this._dataProvider = w;
       this.totalRecords = w.length;
     }else{
       this._dataProvider = [];
      }
     
     if(this.dataProvider !== undefined && this.dataProvider.length > 0){
      this.records = this.dataProvider;   
      this.showTotal = true;
     
     } else{
      this._records=[];
      this.showTotal = false;
      this.totalRecords = 0;
      this.dataSource = new DataTableSource(this._records,this.viewport, this.itemSize);
      this.selection = new SelectionModel(true, []);
      }

      if(this.needsTotal){
        this.reInitializePaginator();
      }
  
 }
 }
 get dataProvider():any{
   return this._dataProvider;
 }
 
 @Input() set workRequest(w:WorkRequest) {
   this._workRequest = w;
   if (this.workRequest !== undefined && this.workRequest.collections[this.collectionTag] !== undefined && this.workRequest.collections[this.collectionTag].rows !==undefined)
   { 
     this.records = this.workRequest.collections[this.collectionTag].rows;
    
   }
 }
 get workRequest():WorkRequest{
   return this._workRequest;
 }
 
 
 sortChange(sort: MatSort) {
   console.log('sort data called');
 }
 
   
   constructor(
     private renderer: Renderer2,
     private globals:GlobalsService
   ) { 
 
   const pgSize = this.globals.configOptions['ist.search_list_page_size'];
   this.pageSize = pgSize ? Number(pgSize) : 0;
   if (this.pageSize === 0) {
     this.pageSize = 5;
   }
 
   }
   
   placeholderWhen(index: number, _: any) {
     return index == 0;
   }
 
 
   ngOnInit() {
    // this.setDisplayedColumns();
    
   }
 
   public get inverseTranslation(): string {
     console.log('header cell :: ', this.viewport.getOffsetToRenderedContentStart());
     return `-${this.viewport.getOffsetToRenderedContentStart()}px`;
   }
   ngAfterViewInit() {
     this.setTableResize(this.matTableRef.nativeElement.clientWidth);
     if(this.dataSource !== undefined)
     this.dataSource.sort = this.sort;
   }
 
   setTableResize(tableWidth: number) {
     let totWidth:number = 0;
     this.columns.forEach(( column) => {
       totWidth += Number(column.width);
     });
     const scale:number = (tableWidth - 6) / totWidth;   // 6==> no of columns + 1
     this.columns.forEach(( column) => {
       column.width *= scale;
       this.setColumnWidth(column);
     });
    
   }
 
   setDisplayedColumns() {
     this.columns.forEach(( column, index) => {
       column.index = index;
       this.displayedColumns[index] = column.dataField;
       if(column.header === 'Select'){
        this.displayedColumns[index] = 'select' ;
      }
     });
   }
 
   onResizeColumn(event: any, index: number) {
     console.log('onResizeColumn evet is called ');
     this.checkResizing(event, index);
     this.currentResizeIndex = index;
     this.pressed = true;
     this.startX = event.pageX;
     this.startWidth = event.target.clientWidth;
     event.preventDefault();
     this.mouseMove(index);
   }
 
   private checkResizing(event, index) {
     const cellData = this.getCellData(index);
     if ( ( index === 0 ) || ( Math.abs(event.pageX - cellData.right) < cellData.width / 2 &&  index !== this.columns.length - 1 ) ) {
       this.isResizingRight = true;
     } else {
       this.isResizingRight = false;
     }
   }
 
   private getCellData(index: number) {
     const headerRow = this.matTableRef.nativeElement.children[0];
   const cell = headerRow.children[0].children[index];
     return cell.getBoundingClientRect();
   }
 
   mouseMove(index: number) {
    // console.log('movemove');
     this.resizableMousemove = this.renderer.listen('document', 'mousemove', (event) => {
       if (this.pressed && event.buttons ) {
         const dx = (this.isResizingRight) ? (event.pageX - this.startX) : (-event.pageX + this.startX);
         const width = this.startWidth + dx;
         console.log(' move move  index  curr index', index, this.currentResizeIndex);
         if ( this.currentResizeIndex === index && width > 50 ) {
           this.setColumnWidthChanges(index, width);
         }
       }
     });
     this.resizableMouseup = this.renderer.listen('document', 'mouseup', (event) => {
       if (this.pressed) {
         this.pressed = false;
         this.currentResizeIndex = -1;
         this.resizableMousemove();
         this.resizableMouseup();
       }
     });
   }
  
   setColumnWidthChanges(index: number, width: number) {
     const orgWidth = this.columns[index].width;
     //console.log('setColumnWidthChanges orgWidth', orgWidth);
     const dx = width - orgWidth;
     if ( dx !== 0 ) {
       const j = ( this.isResizingRight ) ? index + 1 : index - 1;
       const newWidth = this.columns[j].width - dx;
      // console.log('setColumnWidthChanges new width', index, width, newWidth)
       if ( newWidth > 50 ) {
           this.columns[index].width = width;
           this.setColumnWidth(this.columns[index]);
           this.columns[j].width = newWidth;
           this.setColumnWidth(this.columns[j]);
         }
     }
   }
 
   setColumnWidth(column: any) {
    // console.log('setColumnWidth ', column);
     const columnEls = Array.from( document.getElementsByClassName('mat-column-' + column.dataField) );
     columnEls.forEach(( el: HTMLDivElement ) => {
       el.style.width = column.width + 'px';
     });
   }
 
   @HostListener('window:resize', ['$event'])
   onResize(event) {
     this.setTableResize(this.matTableRef.nativeElement.clientWidth);
   }
 
   paginator: DataTablePaginatorComponent;
   @ViewChild(DataTablePaginatorComponent, { static: false }) set initialize(paginator: DataTablePaginatorComponent) {
     this.paginator = paginator;
     this.setPaginator();
   }
   
   setPaginator(): void {
     if (this.paginator) {
       this.paginator.length = this.totalRecords;
       this.paginator.pageSize = this.pageSize;
       this.paginator.pageSizeOptions = [this.pageSize];
     }
   }
 
   //Re-Initialize the Paginator after the more click
   public reInitializePaginator(): void {
     if (this.paginator) {
       this.paginator.pageIndex = 0;
       this.paginator.length = 0;
       }
   }
 
   highlightRow(row): void {
     if (row) {
      // this.rowToBeHighlighted = row;
       this.itemClick.emit(row);
     }
   }
 
  
  
    onPageIndexChange(pageEvent:PageEvent):void{
      console.log('nagivate is called');
      this.pageIndexChanged.emit(pageEvent);
    }
 }
 