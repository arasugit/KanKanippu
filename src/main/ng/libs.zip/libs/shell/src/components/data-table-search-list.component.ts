import { ChangeDetectorRef, Component, ComponentFactoryResolver, ElementRef, Input, OnInit, ViewContainerRef } from '@angular/core';
import { DataTableService } from '../services/data-table.service';
import { GlobalsService } from '../services/globals.service';
import { DataTableDetailComponent } from './data-table.detail.component';
import { DataTableSource } from './abstract-data-table.component';
import { MatDialog } from '@angular/material/dialog';
import { AutoRefreshService, InstService } from '../services';

@Component({
  selector: 'app-search-list-data-table',
  templateUrl: 'data-table-search-list.component.html',
  styles: [`.highlight{background: #fef8cc;}`]
})

export class DataTableSearchListDetailComponent extends DataTableDetailComponent implements OnInit {
  @Input() showEmptyTable: Boolean = true; // introduced to show empty table
  showTotal = true;

  constructor(private dts1: DataTableService, private cd1: ChangeDetectorRef,
    private gbs1: GlobalsService,
    public autoRefreshService: AutoRefreshService,
    private vcr1: ViewContainerRef, private cfr2: ComponentFactoryResolver,dlg:MatDialog,public elementRef: ElementRef,public instService: InstService) {
    super(dts1, cd1, gbs1, autoRefreshService, vcr1, cfr2,dlg,elementRef,instService);
  }

  ngOnInit() {
    // this.isLoadingResults = true;
    // this.loadingMessage = 'Loading search list';
    this.globals.showLoadingBar();
  }

  loadRecords(records: any[]) {
    if (records && records !== undefined) {
      if (records.length <= 0) {
        if (this.showEmptyTable) {
          this.showDummy();
        } else {
          // Clear the table
          this.length = records.length;
        }
      } else {
        this.dataSource = new DataTableSource(records);
        this.dataSource.sort = this.sort;
        this.length = records.length;
      }
    }
    this.clear();
  }

  protected clear() {
    // this.isLoadingResults = false;
    // this.loadingMessage = '';
    this.globals.hideLoadingBar();
  }

  showDummy(): void {
    const row = this.newRow(false);
    row.dbAction = 'dummy'; // No need to edit this row.
    const newRow = [].concat(row);
    this.dataSource = new DataTableSource(newRow);
    this.length = 0;
  }
}
