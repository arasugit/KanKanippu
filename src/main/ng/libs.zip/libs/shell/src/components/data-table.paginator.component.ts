import { ChangeDetectorRef, Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-data-table-paginator',
  templateUrl: 'data-table.paginator.component.html'
})
export class DataTablePaginatorComponent {
  prevPageIndex: number;
  pageIndex: number;
  length: number;
  pageSize: number;
  pageSizeOptions: number[];
  _itemsPerPageLabel;
  @ViewChild('paginator', { static: false }) paginator: MatPaginator;
  constructor(private changeDetectRef:ChangeDetectorRef) {
    this.pageIndex = 0;
    this.prevPageIndex = this.pageIndex;
    this.length = 0;
    this.changeDetectRef.markForCheck();
  }

  @Output() pageIndexChanged = new EventEmitter<PageEvent>();
  @Input()
  set itemsPerPageLabel( value) {
    if (this.paginator !== null && this.paginator !== undefined) {
      this.paginator._intl.itemsPerPageLabel = value;
    }
    this._itemsPerPageLabel =value;
  }
  get itemsPerPageLabel() {
    return this._itemsPerPageLabel;
  }
  onPaginateChange(pageEvent): void {
    this.prevPageIndex = this.pageIndex;
    this.pageIndex = pageEvent.pageIndex;
    this.pageSize = pageEvent.pageSize;
    this.length = pageEvent.length;
    this.pageSizeOptions = [this.pageSize];
    this.pageIndexChanged.emit(pageEvent);
  }
}
