import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, EventEmitter,
         forwardRef, Inject, Injectable, Input, LOCALE_ID, OnInit, Output, PLATFORM_ID, ViewChild } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { CustomFormatter } from '../common/ist-formatter';
import { T21Base } from './t21-base';
import { WorkField, WorkRequest } from '../ist-components/work-request-model';
import { StringUtil } from '../common/ist-string-util';
import { NativeDateAdapter, MAT_DATE_FORMATS, DateAdapter } from "@angular/material/core";
import { formatDate } from '@angular/common';
import { GlobalsService } from '../services/globals.service';
import { UIMetaField } from '../common/vo/ui-metadata-model';
import { CustomValidators } from '../common/ist-validators';
import { MatDatepicker } from '@angular/material/datepicker';

@Injectable()
export class AppDateAdapter extends NativeDateAdapter {

  constructor(
    private globals : GlobalsService,
    @Inject(LOCALE_ID) public locale,
    @Inject(PLATFORM_ID) platformId) {
    super(locale, platformId);
  }

  mask : string;

  format(date: Date, displayFormat: Object): string {

    let compareMonth = { year: 'numeric', month: 'numeric' };
    if(typeof(displayFormat) == "object"){
      this.mask = displayFormat[0];
      if(JSON.stringify(displayFormat) ===  JSON.stringify(compareMonth) ){
        return CustomFormatter.formatDateString(date,"MMM yyyy")
      }
    }
   else if( displayFormat == "input"){
    if(this.mask != null && StringUtil.isNotEmpty(this.mask)){
      return formatDate(date,this.mask,this.locale);
    }
   }
    else{
    let mask = displayFormat[0];
      if(mask != null && StringUtil.isNotEmpty(this.mask)){
        return formatDate(date,this.mask,this.locale);
      }
    }

    return CustomFormatter.serverFormatDate(date, this.globals.dateFormat);
  }

  override parse(value: any): Date | null {
    return CustomValidators.convertToDate(value, this.globals.dateFormat);
  }
}


const noop = () => {
};
export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_DATE_PICKER: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => IstInlineDatePickerComponent),
  multi: true
};
export const T21BASE_ACCESSOR_DATE_PICKER: any = {
  provide: T21Base,
  useExisting: forwardRef(() => IstInlineDatePickerComponent),
  multi: true
};

export const APP_DATE_FORMATS =
{
  parse: {
    dateInput: { month: 'short', year: 'numeric', day: 'numeric' },
  },
  display: {
    dateInput: 'input',
    monthYearLabel: { year: 'numeric', month: 'numeric' },
    dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
    monthYearA11yLabel: { year: 'numeric', month: 'long' },
  }
};

@Component({
  selector: 'ist-inline-datepicker',
  templateUrl: './ist-inline-datepicker-template.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_DATE_PICKER, T21BASE_ACCESSOR_DATE_PICKER,
  {
    provide: DateAdapter, useClass: AppDateAdapter
  }
   ,
  {
    provide: MAT_DATE_FORMATS , useValue: APP_DATE_FORMATS
  },
  {
    provide: LOCALE_ID, useValue: "en-US"
  }
]
})
export class IstInlineDatePickerComponent extends T21Base implements  ControlValueAccessor, OnInit {
    private selectedDate: Date |null;
    private serverDateString: string;
    private _requestProvider: WorkRequest;
    private _workField: WorkField;
    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;
    private _errorString: string|undefined;
    @Output() onSelectedDateChange = new EventEmitter<any>();
    @Output() itemClick = new EventEmitter<any>();
    @Output() onValueChange = new EventEmitter();
    @Output() onValueCommit = new EventEmitter();
    @Input() minDate: Date;
    @Input() maxDate: Date;
    @Input() showPastOnly: boolean = false;
    @Input() disablePastDate: boolean = false;
    @Input() defaultTodaysDate: boolean = false;
    @Input() row:any;
    @ViewChild('picker', { static: false }) datePicker: any;
    @ViewChild('focusControl', { static: false })

    focusControl: ElementRef;
    editFlag: boolean = false; //Edit flag initially set to false
    onEditCheck : string ="";
    formatOptions: any = [];
    //customFormatDate : boolean = false;
    tempDateVal : any;
  editing: boolean = false;
  preValue: string;

    constructor(protected ref: ChangeDetectorRef, private dateAdapter: DateAdapter<Date>, private globals : GlobalsService) {
       super();
       this.changeDetectRef = ref;
       this.componentType = 'IstInlineDatePickerComponent';
        this.mandatorySymbol = '';
        this.preValue = '';
    }

    ngAfterViewInit(){
      if(this.datePicker){
        this.datePicker.closedStream.subscribe(()=>{
          this.editing =false;
        })
      }
    }
  ngOnInit() {
    if (this.defaultTodaysDate){
      this.value= new Date();
      }
  // this.customFormatDate = (this.globals.currentLanguage === "en-US");
    //this.customFormatDate = this.globals.customDateMask;

    // this.selectedDate = new Date();
    if (this.showPastOnly === true) {
      this.maxDate = new Date();
     }
     if (this.disablePastDate === true) {
      this.minDate = new Date();
     }
     this._errorString = undefined;
     this.requiredColon = ' : ';
    }
    onDateSelect(){
      if(this.datePicker){
        this.datePicker.closedStream.subscribe(()=>{
          this.editing =false;
        })
      }
      this.editing =false;
    }
  @Input() set requestProvider(value: WorkRequest) {
    this._requestProvider = value;
    if (this.tag != null && this._requestProvider != null && this._requestProvider.fields[this.tag] != null) {
     this.setWorkField(this._requestProvider.fields[this.tag]);
  }
 }
 get requestProvider(): WorkRequest {
     return this._requestProvider;
 }
 setWorkField(value: WorkField) {
  this._workField = value;
  this._errorString = undefined;
  if (this._workField != null) {
    if (this._workField.value !== null && this._workField.value !== undefined) {
      this.selectedDate = new Date(this._workField.value);
      this.serverDateString = this._workField.value;
      if (this._workField.style !== undefined && this._workField.style === 'mkcStyle') {
        // this.bgColor = 'yellow';
        this.isMkcChange = true;
        this.toolTipMsg = this._workField.oldValue;
        this.setToolTip();
      } else {
        this._workField.oldValue = this._workField.value;
        this.isMkcChange = false;
        }
    }
    this.applyFormatter();
    if (this._workField.modifyable === 'N') {
      this.isDisabled = true;
    }
   // set errorString
        if (this._workField.errorInfo !== '') {
          this._errorString = this._workField.errorInfo;
          this.toolTipMsg = this._errorString;
      } else {
          this._errorString = '';
          this.toolTipMsg = '';
      }
    
    this.ref.markForCheck();
  }
}

set errorString(errStr: string) {
  this._errorString = errStr;
}

get errorString(): string|undefined {
  return this._errorString;
}
registerOnChange(fn: (_: any) => void): void { this.onChangeCallback = fn; }
registerOnTouched(fn: () => void): void {  this.onTouchedCallback = fn; }
get value(): any {
//  console.log(' dt get value called', this.selectedDate);
  return this.selectedDate;
}
@Input()
set value(v: any) {
  this.tempDateVal =  v;
  //editFlag is introduced to avoid Calling set value for every key press, this condition only gets satisfied when focus out happens
  if (!this.editFlag && v !== this.selectedDate  && (v !== null && v !== '')) {

    if (this.globals.customDateMask && (this._metadataProvider != null)  ) {

        let mask:string = this.changeMask(this._metadataProvider.mask);

        if(typeof(v) == "object"){
          this.selectedDate = new Date(v);
        }
        else if(typeof(v) == "string" ){
          if(this.onEditCheck == "yes")   {
            this.selectedDate = this.dateChange(v,mask);
          }
          else{
            this.selectedDate = new Date(v);
          }

        }
        let arr:any = [];
        arr.push(mask);
        let selDate:any= this.selectedDate!=null?this.selectedDate:null;
        if(selDate!=null)
         this.dateAdapter.format(selDate,arr);
        this._metadataProvider.value = this.serverDateString;
    }
    else {
      this.selectedDate = CustomValidators.convertToDate(v, this.globals.dateFormat);
    }

    // this.onEditCheck = "";
    this.serverDateString = CustomFormatter.serverFormatDate(this.selectedDate, this.globals.dateFormat);
    if ( this._requestProvider != null &&  this._requestProvider.fields[this.tag] != null) {
      this._requestProvider.fields[this.tag].value = this.serverDateString;
  }
  }
  else if (this.editFlag){
      this.serverDateString = "";
  }
  this.onChangeCallback(v);
  this.onValueChange.emit(this.selectedDate);
  this.ref.markForCheck();
  //console.log(' dt set value called', v, this.selectedDate);
}

writeValue(value: any) {
   // console.log('write value dt ', this.value);
  this.value = value;
}
 /**
 * Setting metadata for collection fields
 */
@Input()
set metadataProviderForCollections(fields: UIMetaField[]) {
  if (fields) {
    this._metadataProvider = fields[this.tag];
    this.value = this.tempDateVal;
  }
}

changeMask(mask:string)  : string{
  let maskFormatArr:any = [];
  let maskFormat = "";
  if(StringUtil.isNotEmpty(mask)){
      let maskArr = mask.split("/");
      if(maskArr && maskArr.length == 3){
        maskFormatArr = maskArr.map( x => {
          if(x.includes("DD") || x.includes("YY")){
              return x.toLowerCase();
          }
          return x;
        })
        maskFormat = maskFormatArr.join("/");
        if(!maskFormat.endsWith("yyyy"))   {
           maskFormat = maskFormat.slice(0,9);
        }
        return maskFormat;
      }
    }
  return "";
}

emit() {
  this.onSelectedDateChange.emit(this.serverDateString); // This is for custom renderers
}
clearValue()   {
  this.selectedDate = null;
  this.serverDateString = '';
  this.ref.markForCheck();
  this.onChangeCallback(this.selectedDate);
}
setDefaultValue(v: any): void {
  this.selectedDate = v;
}
getValue(): any {
  return this.serverDateString;
}
setFocus() {
  setTimeout(() => this.focusControl.nativeElement.focus());
}

dateFormat() {
  return this.globals.dateFormat;
}
onBlur(){
  this.editing = !this.editing;
}
focusOutEvent(event: any) {
  this.editFlag = false; // Set to false,when the field gets out of focus
 this.editing = !this.editing;
  if (event ) {
    if (event === null || event == '') {
        this.value = undefined;
        this.selectedDate = null;
        this.clearValue();
    }
    else {
        //console.log ('event.target.value else ', event.target.value)
        this.value = event;
      }
      this.onSelectedDateChange.emit(this.serverDateString);
  
     //   console.log('focus cout dt', event.target.value);
     this.applyFormatter();
     this.onValueCommit.emit(event);
    this.ref.markForCheck();
    this.emit();
    const inputChange = this.focusControl.nativeElement;
    const newEvent = new Event('change',{bubbles: true});
    inputChange.dispatchEvent(newEvent);
  }
}
dateClosed(event){
if(event === undefined){
  this.editFlag = false; // Set to false,when the field gets out of focus
  this.editing = !this.editing;
}
}
editControl(){
  //When user tries to Key in , flag should be set to true

  this.editFlag = true;
  this.onEditCheck ="yes";
  if(this.datePicker){
    this.datePicker.open()
  }

}

applyFormatter(){
  if(this.globals.customDateMask){
   // let mask = this._metadataProvider.mask;
   let mask:string= this.changeMask(this._workField.mask);
   let arr:any = [];
   arr.push(mask);
   let selDate:any=this.selectedDate!=null?this.selectedDate:null;
   if(selDate!=null){
    this.dateAdapter.format(selDate,arr);
    this.value = this.selectedDate;
   }
  }
}

dateChange(val,mask){

  let dateSplit = val.split("/");
  let year:any; let month:any;let day:any;

  if(StringUtil.isNotEmpty(mask)){
  let maskSplit = mask.split("/");
  for(let i=0;i < maskSplit.length;i++){
    let bit = maskSplit[i].toLowerCase();
    if(  bit.includes("yy") ){
      year = dateSplit[i];
    }
    else if(bit.includes("mm")){
      let monthInt = (Number(dateSplit[i]) - 1).toString();
      month = monthInt;
    }
    else if(bit.includes("dd")){
      day = dateSplit[i];
    }
  }
}
else{
  let monthInt = (Number(dateSplit[0]) - 1).toString();

  month = monthInt ;
  day=dateSplit[1];
  year = dateSplit[2];
}
  let date = new Date(year,month,day);
  return date;
}


// onBlur($event: Event) {
//   // this.applyFormatter();
//   this.editing = false;
//  }

 // Start the editting process for the input element
 edit(value) {
   if (this.isDisabled) {
     return;
   }
   if (this.row) {
     if (this.row['dbAction'] !== 'd' && this.row.dbAction !== 'dummy') {
       this.globals.setRowToBeHighlighted(this.row);
     }
     if (this.row.dbAction !== 'dummy') {
       this.itemClick.emit(this.row);
     }
   }
   this.preValue = value;
   this.editing = true;
   this.editFlag = true;

   setTimeout(() => {
     this.focusControl.nativeElement.focus();
     if(this.datePicker){
      this.datePicker.open();
     }
   }, 2);
 }

}
