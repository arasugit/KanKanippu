import { Pipe, PipeTransform } from '@angular/core';
import { CustomFormatter } from '../common/ist-formatter';

@Pipe({ name: 'formatCurrency' })
export class FormatCurrencyPipe implements PipeTransform {
 transform(value: any, ...args: any[]): string {
     const isAmountType = args[0];
     if (isAmountType) {
        let strVal: string = String(value);
        strVal = strVal.replace(new RegExp(',', 'g'), '');  // this logic need to be revisited during localization
        value = strVal;
        return CustomFormatter.formatAmount(value);
     }
   
    return value;
  }
}
