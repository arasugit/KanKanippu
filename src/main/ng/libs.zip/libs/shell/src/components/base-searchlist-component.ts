import {
  AfterViewInit,
  Component,
  EventEmitter,
  Inject,
  OnInit,
  Output,
  QueryList,
  TemplateRef,
  ViewChild,
  ViewChildren
} from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { IstInputComponent } from './ist-input-component';
import { StringMap } from '../common/criteria';
import { GlobalsService } from '../services/globals.service';
import { InstService } from '../services/inst.service';
import { MenuService } from '../services/menu.service';
import { PageEvent } from '@angular/material/paginator';
import { IstComboBoxComponent } from './ist-combobox-component';
import { IstDatePickerComponent } from './ist-datepicker-component';
import { IstDatePickerMonthComponent } from './ist-datepicker-month-component';
import { IstInlineDatePickerComponent } from './ist-inline-datepicker-component';

@Component({
  template:''
})
export class SearchListComponent implements OnInit, AfterViewInit {
  public instService: InstService;
  public menuServices: MenuService;
  public globalsService: GlobalsService;
  public DIALOG_TITLE: string;
  public isLoadingResults = false;
  public loadingMessage: string;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) { }

  @ViewChildren(IstInputComponent) public searchFields: QueryList<any>;
  @ViewChildren(IstDatePickerComponent) public searchDateFields: QueryList<any>;
  @ViewChildren(IstDatePickerMonthComponent) public searchDateMonthFields: QueryList<any>;
  @ViewChildren(IstInlineDatePickerComponent) public searchInlineDateFields: QueryList<any>;

  @ViewChildren(IstComboBoxComponent) public cbSearchFields: QueryList<any>;
  @ViewChild('CHILD_TABLES_POPUP', { static: true }) public childTablePopup: TemplateRef<any>;
  @ViewChild('MKC_REMARKS_POPUP', { static: true }) public mkcRemarksPopup: TemplateRef<any>;
  public SLTemplate: TemplateRef<any>;
  public deleteTableMsg: string;
  public remarksText: string;
  public disableRemarks: boolean;
  public mkcBtnAction: string;
  public type: string;
  public fromGblValCtrl = false;
  public dbParam: StringMap = {};
  authModeFlg = false;
  istcmsappFlg = false;
  protected pageCtrl = 'ist_page_ctrl';
  @Output() onSelectedsearchlistChange = new EventEmitter<any>();
  public selectedItem: any;
  orgSlData: any[];
  totalcount:number=0; // for AppInquiry2 datatable
  showAdditionalColumns = false;
  ngOnInit() {
    this.deleteTableMsg = '';
    if (this.data.type) {
      this.type = this.data.type;
    }
    if (this.data.fromGblValCtrl) {
      this.fromGblValCtrl = this.data.fromGblValCtrl;
    }
    console.log(' popup ' , this.data);
  }
  setTemplateReference(): void { }

  clearFields(): void {
    this.searchFields.forEach(childControl => {
      const comp: IstInputComponent = childControl;
      comp.clearValue();
    });
    this.orgSlData = [];
    return;
  }

  findRecords(): void {

    this.showLoading();
    this.dbParam = {};
    for (const key in this.data.defaultParams) {
      // set default parameters
      if (this.data.defaultParams) {
        this.dbParam[key] = this.data.defaultParams[key];
      }
    }

    if (this.type === 'POS_ACQENTITY_POPUP') {
      this.dbParam['type'] = this.type;
      if (this.showAdditionalColumns) {
        this.dbParam['showAdditionalColumns'] = this.showAdditionalColumns.toString();
      }
    }

    if (this.type === 'MESSAGE_BRAND') {
      this.dbParam['type'] = this.type;
    }
    // iterate textinput to add it to param object
    if (this.searchFields !== undefined) {
      // set the values from the search fields
      this.searchFields.forEach(childControl => {
        const comp: any = childControl;
        if (comp.wildCardAllowed) {
          let str: string = comp.getValue();
          if (str !== undefined && str !== '') {
            str = str.replace(/\*/g, '%');
          }
          this.dbParam[comp.paramName] = String(str);
        } else {
          this.dbParam[comp.paramName] = comp.getValue();
        }

      });
    }
     // iterate combo box  to add it to param object
    if(this.cbSearchFields !== undefined){
      this.cbSearchFields.forEach(childControl => {
        const comp: IstComboBoxComponent = childControl;
         this.dbParam[comp.paramName] = comp.getValue();

      });
    }
       // iterate date picker  to add it to param object
    if(this.searchDateFields !== undefined){
        this.searchDateFields.forEach(childControl => {
          const comp: IstDatePickerComponent = childControl;
           this.dbParam[comp.paramName] = comp.getValue();
        });
      }
      if(this.searchInlineDateFields !== undefined){
        this.searchInlineDateFields.forEach(childControl => {
          const comp: IstInlineDatePickerComponent = childControl;
           this.dbParam[comp.paramName] = comp.getValue();
        });
      }
      if(this.searchDateMonthFields !== undefined){
        this.searchDateMonthFields.forEach(childControl => {
          const comp: IstDatePickerMonthComponent = childControl;
           this.dbParam[comp.paramName] = comp.getValue();
        });
      }

    if (this.type === 'TERMINAL_REC_SEQ' || this.type === 'FEE_PKG_ID_POPUP'
    ||  this.type === 'NON_ACT_FEE_PKG_ID_POPUP' ) {
    this.dbParam[this.pageCtrl] = '1';
    this.dbParam['ist_total'] = 'y';
    }
    console.log(' find records called ', this.type, this.dbParam, this.getSSMM());
    this.instService
      .getSearchListData(this.type, this.dbParam)
      .subscribe((slData:any) => this.updateResults(slData), error =>this.ongotErrorRecords(error)
      );
    return;
  }
  more(pageEvent: PageEvent): void {
    console.log('more button clicked : ' + pageEvent.pageIndex + pageEvent.length
   + pageEvent.pageSize);
   this.showLoading();
   this.dbParam[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
   this.dbParam['ist_total'] = 'n';
   this.dbParam['totalCount'] =  '' + pageEvent.length;
   this.instService
   .getSearchListData(this.type, this.dbParam)
   .subscribe((slData:any) => this.updateResults(slData), error =>this.ongotErrorRecords(error)
   );
 return;
 }

  ongotErrorRecords (err: any) {
    this.globalsService.checkErrorResponse(err);
  }
  ngAfterViewInit() {
      this.findRecords();
  }

  updateResults(slData: any[]): void {
    console.log(' updateResults called ', this.getSSMM());
    this.orgSlData = slData;
    this.hideLoading();
  }

  private showLoading() {
    setTimeout(() => {
      this.isLoadingResults = true;
      this.globalsService.showLoadingBar();
    });
  }

  private hideLoading() {
    setTimeout(() => {
      this.isLoadingResults = false;
      this.globalsService.hideLoadingBar();
    });
  }

  public  getSSMM(): string {
      const dt = new Date();
    return dt.getSeconds() + " : " + dt.getMilliseconds().toFixed(3);
  }
}