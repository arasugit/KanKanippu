import { Component, ElementRef, forwardRef, OnInit, Input , ViewChild, Renderer2, ChangeDetectorRef, EventEmitter, Output  } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { T21Base } from './t21-base';
import { IstComboBoxComponent } from './ist-combobox-component';
import { InstService } from '../services/inst.service';
import { GlobalsService } from '../services';

const noop = () => {
};

export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_INLINE_COMBO: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => IstInlineComboComponent),
  multi: true
};

export const T21BASE_ACCESSOR_INLINE_COMBO: any = {
  provide: T21Base,
  useExisting: forwardRef(() => IstInlineComboComponent),
  multi: true
};

@Component({
  selector: 'ist-inline-combo',
  templateUrl: './ist-inline-combo-template.html',
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_INLINE_COMBO, T21BASE_ACCESSOR_INLINE_COMBO]
})
export class IstInlineComboComponent extends IstComboBoxComponent
  implements ControlValueAccessor, OnInit {
  constructor(public _renderer: Renderer2, public elem: ElementRef,
    protected instService: InstService, public globals: GlobalsService,
       ref: ChangeDetectorRef) {
    super( instService, ref);
    this.componentType = 'IstInlineComboComponent';
    this._selfreference = this;
    this.mandatorySymbol = '';
    this.requiredColon = ' : ';
    this.required = false;
    this.disabled = false;
    this.preValue = '';
    this.editing = false;
  }

  @ViewChild('inlineEditControl', { static: false }) inlineEditControl; // select DOM element
  @Input() required: boolean; // Is input requried?
  @Input() disabled: boolean; // Is input disabled?
  @Input() formatOptions: any = [];
  @Input() row: any;

  value = '';
  // @Input() formatAmount: Boolean; // required for cell editor & edit type is Text for amount fields
  private preValue: string; // The value before clicking to edit
  public editing: boolean; // Is Component in edit mode?

  @Input('requestType') requestType: string = '';

ngOnInit() {


}
  // Do stuff when the input element loses focus
  focusOutEvent() {
    // this.applyFormatter();
    this.editing = false;
    // console.log ('finished the editting process for the input element', this.value);
  }

  /*onBlur1($event: Event) {
    console.log('focus out from inline combo box', this.tag, this.selectedValue);
   // this.applyFormatter();
   this.editing = false;
   // console.log ('finished the editting process for the input element', this.value);
 }*/

  // Start the editting process for the input element
  edit(selectedValue) {
    if (this.disabled) {
      return;
    }

    this.preValue = selectedValue;
    this.editing = true;

    setTimeout(() => {
      this.inlineEditControl._focused = true;
    }, 2);

  }

  emitChange(event:any,index?:any) {

    //Set condition for Data Ret Config Screen & if tag = tableName only
    this.selectedValue = event;
    if(this.requestType === 'DATARTCONF' && this.tag === 'tableName'){
      let selValIndex = {
        selectedValue : this.selectedValue,
        index : index
      }
      this.globals.setRetCnfTableName(selValIndex);
    }
    this.emit();
    const inputChange = this.inlineEditControl.trigger.nativeElement;
    const newEvent = new Event('change',{bubbles: true});
    inputChange.dispatchEvent(newEvent);

    this.editing = false;
  //  this.value = this.selectedValue;
   // this.onSelectedValueChange.emit(this.selectedValue); // This is for custom renderers

  }

  getValueOnClick(event:any){
    //console.log('emit', event);
    //Set condition for Data Ret Config Screen & if tag = tableName only
    if(this.requestType === 'DATARTCONF' && this.tag === 'tableName'){
      this.globals.setRetCnfTableName(this.selectedValue);
    }
    this.emit();
  }

  closedCBox(event:any) {
    console.log('closeCBOX called with the value ', event);
    this.editing = false;
  }

  checkCondition(dp : any){
    if(this.requestType === 'DATARTCONF' && this.tag === 'tableName'){
      //Set the table name value here
      //this.globals.setRetCnfTableName(this.selectedValue);
    }
    else
      return;
  }
}
