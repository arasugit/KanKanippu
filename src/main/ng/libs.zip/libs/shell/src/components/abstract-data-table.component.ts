import { AfterContentInit, ComponentFactoryResolver, ComponentRef, EventEmitter, Injector, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild, ViewContainerRef, Output, Injectable, Component, ElementRef } from '@angular/core';
import { MatDialog, MatDialogRef,  MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import {  MatTableDataSource} from '@angular/material/table';
import { CommonConstants } from '../common/ist.common.constants';
import { UIMetaCollection, UIMetadata, UIMetaField, UIMetaSection, UIMetaTab } from '../common/vo/ui-metadata-model';
import { GlobalsService } from '../services/globals.service';
import { StringUtil } from '../common/ist-string-util';
import { CustomRenderer } from './data-table-column.component';
import { T21Base } from './t21-base';
import { InstService } from '../services';
@Component({
    template:''
})
export class AbstractDataTableComponent extends T21Base implements OnInit, AfterContentInit, OnDestroy, OnChanges {
    constructor(public glbl: GlobalsService,
        public cfr: ComponentFactoryResolver,
        public vcf: ViewContainerRef,
        public dlg: MatDialog,
        public elementRef?: ElementRef,
        public instService?: InstService
    ) {
        super();
    }

    /**
     * Contains definitions of all table columns (whether displayed or not)
     */
    allColumns: any[] = [];
    requestType: string;
    collectionTag: string;
    length = 0;
    totalRecords = 0; // To be used for total number of records message.
    static totalDTLRecords = 0; // To be used for total number of records message of Txn details table.
    static isTxnDetailScreen = false;
    changedRecords:any = [];
    isMKCRequest = false;
    isReworkRequest = false;
    dataSource: DataTableSource;
    fields: any; // Only the metafields to be passed to the editor directive
    summaryRow: any = {};
    summaryColTag = 'TOTALROWCOLL';
    dateFields :UIMetaField[] =[];
    arrCheck:any = [];
    @Input() showSummary = false;

    @Input() minWidth: String;
    @Input() maxViewWidth: String = '97vw';
    @Input() dataProvider: any;
    @Output() onChange = new EventEmitter(); // this field is used by Fee & Payment adjustment screens

    @ViewChild(MatSort, { static: false }) sort: MatSort;

    resetParameters(): void {
        // Extending class to implement this
    }

    load(criteria: any, fresh: Boolean, overWriteMsg: Boolean = true): void {
        // Extending class to implement this
    }

    onErrorGotRecords(error: Object): void {
        if (error && error.hasOwnProperty('url')) {
            const url: string = error['url'];
            if (StringUtil.isNotEmpty(url)) {
                if (url.indexOf('timeout.jsp') > -1 || url.indexOf('login.jsp') > -1) {
                    window.location.href = url;
                }
            }
        }
    }

    ngOnInit(): void {
    }
    ngAfterContentInit(): void {
    }
    ngOnDestroy(): void {
        AbstractDataTableComponent.isTxnDetailScreen=false;
        AbstractDataTableComponent.totalDTLRecords=0;
    }
    ngOnChanges(changes: SimpleChanges): void {
    }
    set metadataProvider(value: any) {
        this.collectUIMetaDataFieldInformation(value);
    }

    protected collectUIMetaDataFieldInformation(metaData: UIMetadata) {
        // this is used for validation and alignment of contents of the column when data table is editable.
        try {
            if (metaData) {
                const tab: UIMetaTab[] = metaData.tabs;
                const sections: UIMetaSection[] = tab[this.tabId].sections;
                const collections: UIMetaCollection[] =
                    sections[this.sectionId].collections;
                const fields: UIMetaField[] = collections[this.collectionTag].fields;

                const otherFields : UIMetaField[] = sections[this.sectionId].fields;
                const result = {};
                 Object.keys(fields).forEach(key => result[key] = fields[key]);
                Object.keys(otherFields).forEach(key => result[key] = otherFields[key]);

                this.fields  =  result;
               for (const key in result) {
                let dateFieldVal = result[key]['editType'];
                let renderval = result[key]['renderer'];
                let maskCheck = result[key]['mask'];
                if(dateFieldVal == "DATE" || dateFieldVal == "Date" || renderval == "DATE"
                || dateFieldVal == "AMOUNT"  ||  maskCheck.indexOf('#') > -1){
                        let element = result[key];
                        this.arrCheck.push(element);
                     }
                }
                this.dateFields = Array.from(new Map<string,UIMetaField>(this.arrCheck.map((item:any) =>[item["tag"], item])).values());
                this.setColumnAlignment();
            }
        } catch (e) {
            //  console.log('collectUIMetaDataFieldInformation error: ', e);
        }
    }

    private setColumnAlignment() {
        this.allColumns.forEach(element => {
            if (element.textAlign === undefined) {
                element.textAlign = 'flex-start';
            }
            if (this.fields && element.tag) {
                const tagMetaData = this.fields[element.tag];
                if (tagMetaData) {
                    const editType = tagMetaData['editType'];
                    const mask = tagMetaData['mask'];
                    if ((mask !== undefined && mask.indexOf('#')) > -1 && mask.indexOf('.') > -1) {
                        // this.textAlign = 'right';
                        element.formatAmount = true;
                    }
                    if (editType) {
                        if (editType === 'NUMBER' || editType === 'AMOUNT') {
                            element.textAlign = 'flex-end';
                        }
                        if (editType === 'AMOUNT') {
                            element.formatAmount = true;
                        }
                    }
                }
            }
            // console.log('setColumnAlignment() - from AbstractDataTableComponent called for ', element.dataField, element.tag);
        });
    }

    loadTemplate(event,flag:boolean = false) {
        try {
            if (event.viewButtonTemplate && event.rowIndex !== undefined && (event.rowIndex > -1 || event.row)) {
                let comp: ComponentRef<CustomRenderer> = this.vcf.createComponent(this.cfr.resolveComponentFactory(event.viewButtonTemplate.component), undefined, this.createInjector());
                let rows;
                // This validation may not be required; as the sort is already added in refresh() method
                if (this.sort && this.dataSource.sort === undefined) {
                    this.dataSource.sort = this.sort;
                }

                if (this.dataSource.sort) {
                    rows = this.dataSource.sortData(this.dataSource.data, this.dataSource.sort);
                } else {
                    rows = this.dataSource.data;
                }

                let originalRow = event.rowIndex > -1 ? rows[event.rowIndex] : event.row;
                let clonedRow = originalRow ? JSON.parse(JSON.stringify(originalRow)) : undefined;
                //Cloned collection and cloned row index are used for readonly singlepage view
                //having first, next, previous, last navigation
                const clonedCollection = JSON.parse(JSON.stringify(this.dataSource.data));
                const clonedRowIndex = JSON.parse(JSON.stringify(event.rowIndex));


                const onSelectedRowChange: EventEmitter<any> = new EventEmitter<any>();
                onSelectedRowChange.subscribe(data => {
                     if (data && data.event) {
                        if ('save' === data.event) {
                            data.row.dbAction = data.row.dbAction ? (data.row.dbAction !== 'a' && data.row.dbAction !== 'd' ? 'c' : data.row.dbAction) : 'c';
                            const index = this.changedRecords.indexOf(data.row);
                            if (index > -1) {
                                this.changedRecords.splice(index, 1); // Remove old changes
                            }
                            this.changedRecords.push(data.row); // Add the fresh changes
                            viewDialogRef.close(data);
                        } else if ('delete' === data.event) {
                                this.glbl.showDialog(CommonConstants.WARNING,'MSG11',CommonConstants.ALERT_YES_NO)?.subscribe(result => {
                                    if ('Yes' === result) {
                                        data.row.dbAction = data.row.dbAction && data.row.dbAction !== 'a' ? 'd' : data.row.dbAction;
                                        if (data.row.dbAction === 'd') {
                                            const index = this.changedRecords.indexOf(data.row);
                                            if (index > -1) {
                                                this.changedRecords.splice(index, 1); // Remove old changes
                                            }
                                            this.changedRecords.push(data.row); // Add the fresh changes
                                        }
                                        viewDialogRef.close(data);
                                    }
                                });
                        } else if ('cancel' === data.event) {
                            viewDialogRef.close();
                        }
                    }
                });
                let injectionData = { 'row': clonedRow, 'dataProvider': event.dataProvider, 'workRequest': this.dataProvider, 'metadataProviderForCollections': this.fields, 'onSelectedRowChange': onSelectedRowChange, 'metadataProvider': this.metadataProvider, 'rowIndex': clonedRowIndex, 'collection': clonedCollection, 'title': event.title };
                this.vcf.clear();
                let viewDialogRef: MatDialogRef<any> = this.dlg.open(comp.componentType, { data: injectionData });
                viewDialogRef.updateSize(event.viewButtonTemplate.size);
                viewDialogRef.disableClose = true;
                viewDialogRef.afterClosed().subscribe(result => {
                      if (result) {
                        if ('save' === result.event) {
                            this.dataSource.data.splice(event.rowIndex, 1);
                            this.dataSource.data.splice(event.rowIndex, 0, result.row);
                            this.refreshData();
                            this.onChange.emit(this.dataSource.data);
                        } else if ('delete' === result.event) {
                            this.dataSource.data.splice(event.rowIndex, 1);
                            if (result.row.dbAction === 'd') {
                                this.dataSource.data.splice(event.rowIndex, 0, result.row);
                            }
                            this.refreshData();
                        }
                        if( flag && ('save' === result.event || 'delete' === result.event)){
                        this.updateWorkCollection(event.rowIndex,result.row)
                        }
                    }
                });
            }
        } catch (error) {
            console.log('Single view button functioning error', error);
        }
    }
    updateWorkCollection(rowIndex:any, rowData:any){
    }
    createInjector() {
        return Injector.create({
            providers: [{ provide: MAT_DIALOG_DATA, useValue: {} }]
        });
    }

    refreshData() {
        // the method will just refresh the data.
        const temp = JSON.parse(JSON.stringify(this.dataSource.data));
        this.dataSource = new DataTableSource([]);
        this.dataSource = new DataTableSource(temp);
        if (this.sort) {
            this.dataSource.sort = this.sort;
        }
    }

    filterRows(search: string) {
        this.dataSource.filter = search;
    }
    public scrollToSelectedRow() {
        // override in the individual data table
    }
}

export class DataTableSource extends MatTableDataSource<any[]> {
    constructor(private records: any[]) {
        super(records);
    }
}
