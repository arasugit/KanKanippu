import { AfterContentInit, ChangeDetectorRef, Component, ComponentFactoryResolver, ContentChildren, EventEmitter, forwardRef, Input, OnChanges, OnDestroy, Output, QueryList, SimpleChanges, ViewChild, ViewContainerRef } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { DataTableColumnComponent } from './data-table-column.component';
import { DataTablePaginatorComponent } from './data-table.paginator.component';
import { T21Base } from './t21-base';
import { DataTableService } from '../services/data-table.service';
import { GlobalsService } from '../services/globals.service';
import { ResponseBase } from '../services/response-base';
import { WorkRequest } from '../ist-components/work-request-model';

import { StringUtil } from '../common/ist-string-util';
import { AbstractDataTableComponent, DataTableSource } from './abstract-data-table.component';
import { MatDialog } from '@angular/material/dialog';

export const T21BASE_ACCESSOR: any = {
  provide: T21Base,
  useExisting: forwardRef(() => DataTableComponent),
  multi: true
};

export const ISTDATATABLE_ACCESSOR: any = {
  provide: AbstractDataTableComponent,
  useExisting: forwardRef(() => DataTableComponent),
  multi: true
};

@Component({
  selector: 'app-data-table',
  templateUrl: 'data-table.component.html',
  providers: [T21BASE_ACCESSOR, ISTDATATABLE_ACCESSOR],
  styles: [`.highlight {background: #fef8cc;}`]
})

// This component will be used for list screen non-editable datatgrid, search list and detail page non-editable datagrid
export class DataTableComponent extends AbstractDataTableComponent
  implements AfterContentInit, OnDestroy, OnChanges {
  paginator: DataTablePaginatorComponent;

  // ViewChild doesn't consider elements with *ngIf in ngAfterViewInit;
  // Moreover this is an angular issue so live with this work around for now.
  @ViewChild(DataTablePaginatorComponent, { static: false }) set initialize(paginator: DataTablePaginatorComponent) {
    this.paginator = paginator;
    this.setPaginator();
  }
  criteria: {};
  length = 0;
  totalRecords = 0; 
  isLoadingResults = false;
  loadingMessage: string;
  workRequest: WorkRequest;
  errorId: string;

  pageSize: number;
  @Output() itemClick = new EventEmitter<any>();
  @Output() itemDblclick = new EventEmitter<any>();
  @Output() pageIndexChanged = new EventEmitter<PageEvent>();
  @Output() getWorkRequest = new EventEmitter<WorkRequest>();
  @Input() action: string;
  @Input() requestType: string='';
  @Input() collectionTag: string='';
  @Input() showPaginator = true; // By default show paginator
  @Input() showEmptyTable: Boolean = false; // By default do not show empty table

  togglePaginator = false;

  // This is for showing 'Total number of records: ' used in search list
  @Input() showTotal = false;

  // Do not manipulate this variable as this is used in combination with the @Input showTotal to hide/show
  // the total records message.
  toggleShowTotal = false;

  @Input() width: string=''; // Total width of the table (can be set by the user as needed)

  displayedColumns: string[] = [];

  @Input()
  set columnsToDisplay(val: string | string[]) {
    if (typeof val === 'string') {
      this.displayedColumns = val.split(/\s*,\s*/);
    } else {
      this.displayedColumns = val;
    }
  }

  @Input() dataTableId: String;

  @ContentChildren(DataTableColumnComponent)
  protected columnElements: QueryList<DataTableColumnComponent>;

  rowToBeHighlighted: object;

  constructor(
    private dataTableService: DataTableService,
    private changeDetector: ChangeDetectorRef,
    public globals: GlobalsService,
    public cfr: ComponentFactoryResolver,
    public vcf: ViewContainerRef,
    public dlg:MatDialog) {
    super(globals,cfr,vcf,dlg);
    const pagesize = this.globals.configOptions['ist.default_page_size'];
    this.pageSize = pagesize ? Number(pagesize) : 0;
    if (this.pageSize === 0) {
      this.pageSize = 5;
    }
  }

  ngAfterContentInit() {
    if (this.columnElements && this.columnElements.length > 0) {
      this.allColumns = this.columnElements.toArray();
    }
    if (this.displayedColumns.length === 0) {
      this.displayedColumns = this.allColumns.map(
        (col: DataTableColumnComponent) => col.name
      );
    }
    this.allColumns.forEach(element => {
      if (element.visible === true) {
        element.editable = false; // This is a inquiry datatable
      } else {
        const index = this.displayedColumns.indexOf(element.name);
        if (index > -1) {
          this.displayedColumns.splice(index, 1);
        }
      }
    });
    this.showDummy();
  }

  ngOnChanges(changes: SimpleChanges): void {
    try {
      this.setOtherInputs(changes);
      let records: any[]=[];
      if (changes['dataProvider'] !== undefined && changes['dataProvider'] !== null) {
        if (Array.isArray(changes['dataProvider'].currentValue)) {
          // For search list result it is not a workrequest but an array
          records = changes['dataProvider'].currentValue;
        } else {
          // Try with WorkRequest
          this.workRequest = changes['dataProvider'].currentValue;
          if (this.workRequest && this.workRequest !== null) {
            this.emitWorkRequest();
            records = this.workRequest.collections['' + this.collectionTag].rows;
          }
        }
        // Load the datatable records
        this.loadRecords(records);
      }
    } catch (e) {
      // ignore
    } finally {
      this.clearFlags();
    }
  }

  ngOnDestroy(): void {}

  load(criteria: any, fresh: Boolean, overWriteMsg: Boolean = true): void {
    this.dataTableService.requestType = this.requestType;
    this.dataTableService.collectionTag = this.collectionTag;
    if (criteria !== undefined && criteria['COMMAND'] !== undefined) {
      this.dataTableService.action = criteria['COMMAND'];
    } else {
      this.dataTableService.action = 'query';
    }
    this.dataTableService.criteria = criteria;
    if (fresh === true) {
      this.resetParametersInternal();
      this.resetRequest();
      this.clearStatusMessage();
    }
    this.loadDataInternal(fresh, overWriteMsg);
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = new WorkRequest();
    this.workRequest = wr;
    this.togglePaginator = true;
    this.toggleShowTotal = true;
    // The following sequence of method calls are only for search button click action result where the workrequest
    // is populated with proper information.
    this.setLength();
    this.setRecords();
    this.emitWorkRequest();
    this.onInquiry(overWriteMsg);
  }

  // This method will be called when there is a change in the dataProvider.
  protected loadRecords(records: any[]) {
    // Loading records in detail page datagrid / searchList
    try {
      if (records && records !== undefined) {
        this.togglePaginator = true;
        this.toggleShowTotal = true;
        if (records.length <= 0) {
          this.showDummy();
          } else {
          this.dataSource = new DataTableSource(records);
          this.dataSource.sort = this.sort;
          this.length = records.length;
          this.totalRecords = this.length;
        }
        if (this.paginator) {
          this.paginator.length = records.length;
        }
      }
    } catch (e) {
      // Ignore
    }
  }

  // Setting the paginator properties. Override this method as needed.
  setPaginator(): void {
    if (this.paginator) {
      this.paginator.length = this.length;
      this.paginator.pageSize = this.pageSize;
      this.paginator.pageSizeOptions = [this.pageSize];
    }
  }

  // Setting length; this is used to show/hide the datatable itself. Override this method to change the behaviour.
  setLength(): void {
    this.length = this.workRequest.total;
  }

  // This will populate the datasource and load records into the table.
  setRecords(): void {
    try {
      this.dataSource = new DataTableSource(this.workRequest.collections['' + this.collectionTag].rows);
      this.dataSource.sort = this.sort;
    } catch (e) {
      // Ignore ??
    }
  }

  // Emit the workrequest itself if action is not save
  emitWorkRequest() {
    this.getWorkRequest.emit(this.workRequest);
  }

  inspectForError(): Boolean {
    let error: Boolean = false;
    if (this.workRequest.requestResult === ResponseBase.REQUEST_RESULT_ERROR) {
      this.errorId = this.workRequest.errorDetail;
      this.errorId = StringUtil.isEmpty(this.errorId)
        ? this.workRequest.messageId
        : this.errorId;
      this.globals.setErrorMessage(this.errorId);
      error = true;
    }
    return error;
  }

  getLastErrorId(): string {
    return this.errorId;
  }

  onInquiry(overWriteMsg: Boolean): void {
    let error: Boolean = false;
    error = this.inspectForError();
    if (error) {
      this.resetParametersInternal();
      this.globals.setErrorMessage(this.getLastErrorId());
    } else {
      if (this.length <= 0) {
        // No data found.
        this.resetParametersInternal();
        // this.globals.setStatusMessage('MSG14');
        if (overWriteMsg) {
          this.globals.setStatusMessage('MSG02');
        }
        this.showDummy();
      }
    }
  }

  onErrorGotRecords(error: Object): void {
    //  console.log('Could not fetch data from database (Exception DataTableComponent.load()): ' + JSON.stringify(error, null, 2));
    this.resetParametersInternal();
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
      super.onErrorGotRecords(error);
    }
  }

  onCompleteGotRecords(): void {
    // this.isLoadingResults = false;
    // this.loadingMessage = '';
    this.globals.hideLoadingBar();
    this.changeDetector.detectChanges();
  }

  private loadDataInternal(fresh: Boolean, overWriteMsg: Boolean = true): void {
    //  console.log('Setting criteria:(from parent form): ' + JSON.stringify(this.dataTableService.criteria, null, 2));
    // this.isLoadingResults = true;
    // this.loadingMessage = 'Loading';
    this.globals.showLoadingBar();
    this.dataTableService
      .loadData(fresh)
      .subscribe(
        x => this.onGotRecords(x, overWriteMsg),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }

  highlightRow(row): void {
    if (row) {
      this.rowToBeHighlighted = row;
      this.itemClick.emit(row);
    }
  }
  onDblClick(row): void {
    if (row) {
      this.rowToBeHighlighted = row;
      this.itemDblclick.emit(row);
    }
  }

  newRow(): any {
    const newRecord = {};
    return newRecord;
  }

  navigateToPage(pageEvent: PageEvent): void {
    if (this.paginator) {
      // Emit the page event here for now; let the corresponding form handle the criteria setting.
      // Later may be we can pass the criteria parameters like 'ist_page_ctrl' and 'ist_total' (or whatever
      // used in the form as an @input variable to this component and set the same here it self like below
      // (which is set in the actual form as of now); no need of emitting page event then.
      // this.criteria['ist_page_ctrl'] = '' + ((pageEvent.pageIndex) + 1);
      // this.criteria['ist_total'] = 'n';
      // Update: (as of 11th April, 2018): the above functionality is moved to the ListComponent;
      // so still this emitting is required which will be processed by ListComponent which is the parent class
      // for all the list screens
      this.pageIndexChanged.emit(pageEvent);
    }
  }

  resetParameters(): void {
    this.resetParametersInternal();
    this.clearStatusMessage();
    this.showDummy();
  }

  private resetParametersInternal() {
    if (this.paginator) {
      this.paginator.pageIndex = 0;
    }
    this.length = 0;
    this.totalRecords = 0;
    this.workRequest = null;
    this.togglePaginator = false;
    this.toggleShowTotal = false;
    this.rowToBeHighlighted = {};
    // this.isLoadingResults = false;
    // this.loadingMessage = '';
    this.globals.hideLoadingBar();
  }

  clearStatusMessage(): void {
    this.globals.setStatusMessage('');
  }

  setOtherInputs(changes: SimpleChanges) {
    if (changes['action'] !== undefined && changes['action'] !== null) {
      this.action = changes['action'].currentValue;
      this.dataTableService.action = this.action;
    }

    if (changes['requestType'] !== undefined && changes['requestType'] !== null) {
      this.requestType = changes['requestType'].currentValue;
      this.dataTableService.requestType = this.requestType;
    }

    if (changes['collectionTag'] !== undefined && changes['collectionTag'] !== null ) {
      this.collectionTag = changes['collectionTag'].currentValue;
      this.dataTableService.collectionTag = this.collectionTag;
    }
  }

  private resetRequest(): void {
    if (this.workRequest) {
      this.workRequest.errorDetail = '';
      this.workRequest.messageId = '';
      this.workRequest.requestResult = ResponseBase.REQUEST_RESULT_SUCCESS;
    }
  }

  showDummy(): void {
    if (!this.showEmptyTable) {
      return;
    }
    const row = this.newRow();
    row.dbAction = 'dummy'; // No need to edit this row.
    const newRow = [].concat(row);
    this.dataSource = new DataTableSource(newRow);
    this.length = newRow.length;
    this.totalRecords = 0;
  }

  clearFlags() {
    // this.isLoadingResults = false;
    // this.loadingMessage = '';
    this.globals.hideLoadingBar();
  }
}
