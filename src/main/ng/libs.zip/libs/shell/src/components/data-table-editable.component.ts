import { AfterContentInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, ComponentFactoryResolver, ContentChildren, ElementRef, EventEmitter, forwardRef, Input, OnChanges, OnDestroy, OnInit, Output, QueryList, SimpleChanges, ViewChild, ViewContainerRef } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { CommonConstants } from '../common/ist.common.constants';
import { Permissions } from '../common/permissions';
import { DataTableColumnComponent, RendererItem } from '../components/data-table-column.component';
import { DataTablePaginatorComponent } from '../components/data-table.paginator.component';
import { T21Base } from './t21-base';
import { DataTableService } from '../services/data-table.service';
import { GlobalsService } from '../services/globals.service';
import { ResponseBase } from '../services/response-base';
import { WorkCollection, WorkCollectionCollection, WorkField, WorkRequest } from '../ist-components/work-request-model';
import { Subscription } from 'rxjs';
import { LabelAndValue, LabelsAndValues } from '../common/labels-and-values';
import { AbstractDataTableComponent, DataTableSource } from './abstract-data-table.component';
import { ColumnOnDemand } from './column-on-demand.component';
import { MatDialog } from '@angular/material/dialog';
import * as XLSX from 'xlsx';
import { AutoRefreshService, InstService } from '../services';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
export const T21BASE_ACCESSOR_EDITABLE: any = {
  provide: T21Base,
  useExisting: forwardRef(() => DataTableEditableComponent),
  multi: true
};
export const ISTDATATABLE_ACCESSOR_EDITABLE: any = {
  provide: AbstractDataTableComponent,
  useExisting: forwardRef(() => DataTableEditableComponent),
  multi: true
};

@Component({
  selector: 'app-data-table-editable',
  templateUrl: 'data-table-editable.component.html',
  providers: [T21BASE_ACCESSOR_EDITABLE, ISTDATATABLE_ACCESSOR_EDITABLE],
  styles: [`.highlight{background: #fef8cc;}
            .delete{background: #a9a9a9;}
            .error{background: #a9a9a9;}
            .highlightRed{background: #f9a29a85;}
            .highlightOrange{background: #ffb57373;}
          `],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class DataTableEditableComponent extends AbstractDataTableComponent implements OnInit, AfterContentInit, OnDestroy, OnChanges {
  @ViewChild(DataTablePaginatorComponent, { static: true }) paginator: DataTablePaginatorComponent;

  criteria: {};
  length = 0;
  isLoadingResults = false;
  loadingMessage: string;
  workRequest: WorkRequest;
  changedRecords: any[] = [];
  subscription: Subscription;
  tempLength = 0;
  pageSize: number;
  @Output() onDatatableClear = new EventEmitter<any>();

  @Output() itemClick = new EventEmitter<any>();
  @Output() pageIndexChanged = new EventEmitter<PageEvent>();
  // Some screens (like dispense table etc.) need to have the already loaded work request by means of search
  // for further processing. Hence emitting the same once loaded here. As of now emitted only for query.
  @Output() getWorkRequest = new EventEmitter<WorkRequest>();

  @Input() action: string;
  @Input() requestType: string = '';
  @Input() collectionTag: string = '';
  @Input() remoteClass: string; // Did not find another way to get it for now
  @Input() showPaginator = true; // By default no paginator
  @Input() isDetailTable = true;
  @Input() autoShowPaginator = true;
  @Input() screenType: string = '';

  @Input() query = false; // Not permitted by default; this input is not required here as search button is at the form level itself.
  @Input() insert = false; // Not permitted by default; expecting input from the actual form
  @Input() update = false; // Not permitted by default; expecting input from the actual form
  @Input() delete = false; // Not permitted by default; expecting input from the actual form
  @Input() checker = false; // Not permitted by default; expecting input from the actual form
  @Input() mkc = false; // Not permitted by default; expecting input from the actual form

  @Input() panMaskPattern = false; // Not permitted by default; this is required by OASEntControl form
  @Input() deleteHidden = false; // Some single page screens do not need delete functionality
  @Input() addHidden = false; // Some single page screens do not need add functionality
  @Input() exportHidden = false; // Some single page screens do not need add functionality
  @Input() saveHidden = false; // Some single page screens do not need add functionality
  // This is for showing 'Total number of records: ' in datatable detail used in search list
  @Input() showTotal = false;
  // This is used to get mandatory fields list to validate for mandatory check
  @Input() mandatoryFieldArr: LabelsAndValues = new LabelsAndValues();
  @ViewChild('content') content: ElementRef;
  // Need to override save and cancel button visibility (Used in detail page datatable)
  showSave: Boolean = true;
  @Input() showCancel: Boolean = true;
  showExport: Boolean = true;
  istCtrlPage: Number = 1;
  redirectedFrmExport: Boolean = false;
  totalDisplayingRecords: any = 0;

  // To keep the entitlement permissions to pass on to column level (may be find another way of doing this later)
  permissions: Permissions;

  @Input() width: string = ''; // Total width of the table (can be set by the user as needed)
  /**
   * list of column names which are to be displayed. Can be modified; must be a subset of the
   * names of columns in allColumns.
   * Will take a string which is a comma-separated list of names (no quotes), or an array of names.
   */
  displayedColumns: string[] = [];
  returnFlag: boolean;
  addBeepError: any;
  beepPlayed: boolean = false;
  audioContext: AudioContext;
  exportTypeFromCLick: string;
  returnData: LabelAndValue[];
  columnNameResArray: any[] = [];
  updatedColumnNameResArray: any[] = [];
  arrayData : LabelsAndValues = new LabelsAndValues();
  data: any[];
  @Input() set columnsToDisplay(val: string | string[]) {
    if (typeof val === 'string') {
      this.displayedColumns = val.split(/\s*,\s*/);
    } else {
      this.displayedColumns = val;
    }
  }

  @Input() dataTableId: String;
  @Input() editable = true;

  //To Show Trigger errors from database, ignoreResetParam set to be true to show Datatable rows.
  @Input() ignoreResetParam = false;

  //refreshTable set to be true , to requery after successful save operation.
  @Input() refreshAfterSave = false;
  @Input() exportFileName: string = '';
  @Input() checkAutoRefreshTime: boolean;
  @Input() actCollectionName: string = '';
  @Input() isExportCollChnaged = false;
  @ContentChildren(DataTableColumnComponent) protected columnElements: QueryList<DataTableColumnComponent>;

  rowToBeHighlighted: object;

  mkcCols: ColumnOnDemand[] = [];

  mkcStatus: LabelsAndValues = new LabelsAndValues();
  mkcStatusRenderer: RendererItem;
  singleViewButtonRenderer: RendererItem;
  userID: string;

  columnLookArray = ["flags", "taskName", "taskType", "field8", "status"];
  columnLookValue = ["Stopped", "Down", "down", "open"];

  columnLookArrayOrg = ["status"];
  columnLookValueOrg = ["progress"];
  tableNamesList : LabelsAndValues = new LabelsAndValues();
  selectedTableNameValue : string = '';
  colNamesList : LabelsAndValues = new LabelsAndValues();
  constructor(private dataTableService: DataTableService, private changeDetector: ChangeDetectorRef,
    public globals: GlobalsService,
    public autoRefreshService: AutoRefreshService,
    private viewContainerRef: ViewContainerRef,
    private componentFactoryResolver: ComponentFactoryResolver, public dlg: MatDialog, public elementRef: ElementRef,public instService: InstService) {
    super(globals, componentFactoryResolver, viewContainerRef, dlg, elementRef,instService);
    this.changedRecords = [];
    // Subscribe to row changes from the data table column level
    this.subscription = this.dataTableService.changedRowObservable$.subscribe(event => {
      this.gatherChangedRow(event);
    });
    const pagesize = this.globals.configOptions['ist.default_page_size'];
    this.pageSize = pagesize ? Number(pagesize) : 0;
    if (this.pageSize === 0) {
      this.pageSize = 5;
    }
    this.permissions = {};
    this.mkcStatus.array = [new LabelAndValue('Approved', 'A'), new LabelAndValue('Reject', 'R'),
    new LabelAndValue('Rework', 'W'), new LabelAndValue('Submitted', 'S')];
    this.audioContext = new AudioContext();
  }

  ngOnInit() {
    this.userID = this.globals.userContext.userID;
    this.getRowHighlighted();
    if(this.requestType === 'DATARTCONF'){
      this.instService.getDatabaseRecords("TABLE_NAMES_LIST",null).subscribe((x: any[]) => { this.loadTableNamesList(x); })
    }
  }

  ngAfterContentInit() {
    if (this.columnElements && this.columnElements.length > 0) {
      this.allColumns = this.columnElements.toArray();
    }
    if (this.displayedColumns.length === 0) {
      this.displayedColumns = this.allColumns.map((col: DataTableColumnComponent) => col.name);
    }
    if (this.editable) {
      this.addMkcColumns();
    }

    this.allColumns.forEach(element => {
      if (element.visible === true) {
        if (element.editable === undefined) { // If nothing is set at column level, use the table level value
          element.editable = this.editable;
        }
      } else {
        const index = this.displayedColumns.indexOf(element.name);
        if (index > -1) {
          this.displayedColumns.splice(index, 1);
        }
      }
    });
    if (this.paginator) {
      this.paginator.pageSizeOptions = [this.pageSize];
    }
    this.refreshTableColumns();
    this.showDummy();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.consolidatePermissions(changes);
    this.setOtherInputs(changes);

    if (DataTableEditableComponent.isTxnDetailScreen && (this.dataSource != null && this.dataSource !== undefined &&
      this.dataSource.data != null)) {
      this.showPaginator = true;
      this.length = this.dataSource.data.length;
      this.tempLength = DataTableEditableComponent.totalDTLRecords;
      this.paginator.length = this.tempLength;
      this.paginator.pageSizeOptions = [this.pageSize];
      this.totalDisplayingRecords = this.dataSource.data.length;
    }

  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.resetParametersInternal();
  }

  private addMkcColumns() {
    let mkcCol = new ColumnOnDemand();
    mkcCol.editable = true;
    mkcCol.header = 'Checker action';
    mkcCol.name = 'mkcStatus';
    mkcCol.dataField = mkcCol.name;
    mkcCol.visible = false;
    mkcCol.renderer = this.mkcStatusRenderer;
    mkcCol.dataProvider = this.mkcStatus;
    this.mkcCols.push(mkcCol);
    mkcCol = new ColumnOnDemand();
    mkcCol.editable = true;
    mkcCol.header = 'Remarks';
    mkcCol.name = 'mkcRemarks';
    mkcCol.dataField = mkcCol.name;
    mkcCol.visible = true;
    this.mkcCols.push(mkcCol);
    this.addColumn();
  }

  protected addColumn() {
    this.mkcCols.forEach(column => {
      const columnFactory = this.componentFactoryResolver.resolveComponentFactory(DataTableColumnComponent);
      const col = this.viewContainerRef.createComponent(columnFactory);
      col.instance.itemRenderer = column.renderer;
      col.location.nativeElement.innerHTML = '';
      col.instance.editable = column.editable;
      col.instance.header = column.header ? column.header : 'Header';
      col.instance.name = column.name ? column.name : 'name';
      col.instance.dataField = column.dataField ? column.dataField : 'dataField';
      col.instance.labelFunction = column.expression;
      col.instance.visible = column.visible;
      col.instance.dataProvider = column.dataProvider;
      this.allColumns.push(col.instance);
      this.displayedColumns.push(col.instance.name);
    });
  }

  refreshTableColumns() {
    const mkcStatusIndex = this.displayedColumns.indexOf('mkcStatus');
    let mkcRemarksIndex = this.displayedColumns.indexOf('mkcRemarks');

    if (this.isMKCRequest) {
      if (this.checker) {
        if (!this.isReworkRequest) {
          if (mkcRemarksIndex > -1) {
            this.displayedColumns.splice(mkcRemarksIndex);
            mkcRemarksIndex = -1;
          }
          if (mkcStatusIndex < 0) {
            this.displayedColumns.push('mkcStatus');
          }
        } else {
          if (mkcStatusIndex > -1) {
            this.displayedColumns.splice(mkcStatusIndex);
          }
        }
      }
      if (mkcRemarksIndex < 0) {
        this.displayedColumns.push('mkcRemarks');
      }
    } else {
      if (mkcStatusIndex > -1) {
        this.displayedColumns.splice(mkcStatusIndex);
      }
      if (mkcRemarksIndex > -1) {
        this.displayedColumns.splice(mkcRemarksIndex);
      }
    }
  }

  load(criteria: any, fresh: Boolean, overWriteMsg: Boolean = true): void {
    this.changeDetector.markForCheck();
    this.dataTableService.requestType = this.requestType;
    this.dataTableService.collectionTag = this.collectionTag;
    if (criteria !== undefined && criteria['COMMAND'] !== undefined) {
      this.dataTableService.action = criteria['COMMAND'];
      this.action = criteria['COMMAND'];
    } else {
      this.dataTableService.action = 'query';
      this.action = this.dataTableService.action + '';
    }
    this.dataTableService.criteria = criteria;
    if (this.checkChange() && 'mkc_rework_query' !== this.action && 'mkc_pending_query' !== this.action) {
      this.globals.showDialog(CommonConstants.WARNING, 'MSG94', CommonConstants.ALERT_YES_NO)?.subscribe(result => {
        if ('Yes' === result) {
          this.changedRecords = [];
          this.rowToBeHighlighted = {};
          if (fresh === true) {
            this.resetParametersInternal();
            this.resetRequest();
            this.clearStatusMessage();
          }
          this.loadDataInternal(fresh, overWriteMsg);
        } else {
          if (this.paginator) {
            if (!fresh) {
              this.paginator.pageIndex = this.paginator.prevPageIndex;
            }
          }
        }
      });
    } else {
      if (fresh === true) {
        this.resetParametersInternal();
        this.resetRequest();
        if (!this.refreshAfterSave) {
          this.clearStatusMessage();
        }

      }
      this.loadDataInternal(fresh, overWriteMsg);
    }
    // For MKC - adding columns mkcStatus and mkcRemarks based on condition
    this.setMKCRequest();
    this.refreshTableColumns();
  }

  setMKCRequest() {
    if ('query' === this.action) {
      this.isMKCRequest = false;
      this.isReworkRequest = false;
      return;
    }

    if ('mkc_rework_query' === this.action || 'mkc_pending_query' === this.action) {
      this.isMKCRequest = true;
      if ('mkc_rework_query' === this.action) {
        this.isReworkRequest = true;
      } else {
        this.isReworkRequest = false;
      }
    }
  }

  loadTableNamesList(result: string[]): void {
    this.tableNamesList.array = result.map((y: string): LabelAndValue => {
      return new LabelAndValue(y, y);
    });
  }


 loadColumnNamesList(result: string[]) {
  // this.columnNameResArray.push(result);


  this.colNamesList.array =result.map((y: string): LabelAndValue => {
    return new LabelAndValue(y, y)

  });

  this.columnNameResArray.push({
    arr:this.colNamesList.array,
    list:[]
  }) ;
//  this.columnNameResArray = this.arrayData.array;
if(this.columnNameResArray.length){
  this.data = this.workRequest.collections['' + this.collectionTag].rows.map((item,i)=>({
    ...item,
    index:i,
    optionArray1:this.tableNamesList,
    optionArray2:new LabelsAndValues(this.columnNameResArray[i]),
  }));
  this.workRequest.collections['' + this.collectionTag].rows = this.data;
  ///when click on array1
  this.globals.tableNameRetCnfSubject$.subscribe({
    next: (response: any) => {
      if (response) {
        this.selectedTableNameValue = response.selectedValue;
        let dbParam = {};
        dbParam['selectedTableNameValue'] = response.selectedValue;
      this.instService.getDatabaseRecords("COLUMN_NAMES_LIST",dbParam).subscribe((x: any[]) =>
         {
          if(x){
            this.colNamesList.array =x.map((y: string): LabelAndValue => {
              return new LabelAndValue(y, y)

            });
            this.updatedColumnNameResArray = [];
            this.updatedColumnNameResArray.push({
              arr:this.colNamesList.array,
              list:[]
            }) ;
            this.data= this.updatedDataRetConfig(this.data,this.updatedColumnNameResArray,response.index,response.selectedValue);
            this.workRequest.collections['' + this.collectionTag].rows = this.data;
            this.dataSource = new DataTableSource(this.workRequest.collections['' + this.collectionTag].rows);
          }
          });
      }
    },
    error: (error: Error) => {
    }
  });

  ////////
  this.dataSource = new DataTableSource(this.workRequest.collections['' + this.collectionTag].rows);
}
}

getColumnName(selectedTableNameValue){
  let dbParam = {};
    dbParam['selectedTableNameValue'] = selectedTableNameValue;
  this.instService.getDatabaseRecords("COLUMN_NAMES_LIST",dbParam).subscribe((x: any[]) =>
     {
     this.loadColumnNamesList(x);
      });
}
  onGotRecords(wr: WorkRequest, save: Boolean, add: Boolean = false, overWriteMsg: Boolean = true): void {
    if (this.dataTableService.criteria["ist_page_ctrl"] == -1) {
      this.exportToExcel(this.collectionTag, wr);
      return;
    }
    this.istCtrlPage = this.dataTableService.criteria["ist_page_ctrl"];
    this.globals.hideLoadingBar();
    if (this.paginator) {
      this.paginator.length = wr.total;
    }
    this.length = wr.total;
    this.totalDisplayingRecords = this.length;
    this.workRequest = new WorkRequest();
    this.workRequest = wr;
    try {
      if (this.redirectedFrmExport && this.isExportCollChnaged) {
        console.log('Manoj Kumar redirectedFrmExport :::' + this.redirectedFrmExport);
        this.dataSource = new DataTableSource(this.workRequest.collections['TRANS_DTL_COL'].rows);
        this.redirectedFrmExport = false;
      } else {
        console.log('Manoj Kumar redirectedFrmExport :::' + this.redirectedFrmExport);
        if(this.requestType === 'DATARTCONF'){

          // this.instService.getDatabaseRecords("TABLE_NAMES_LIST",null).subscribe((x: any[]) => { this.loadTableNamesList(x); })
          this.columnNameResArray =[];
          this.workRequest.collections['' + this.collectionTag].rows.forEach((res,i)=>{
            let dbParam = {};
            dbParam['selectedTableNameValue'] = res.tableName;
          this.instService.getDatabaseRecords("COLUMN_NAMES_LIST",dbParam).subscribe((x: any[]) =>
             {
             this.loadColumnNamesList(x);
              });
          })
        }
        else{
          this.dataSource = new DataTableSource(this.workRequest.collections['' + this.collectionTag].rows);
        }
      }
      this.dataSource.sort = this.sort;
    } catch (e) {
      // Ignore
    }
    if (!save) {
      this.getWorkRequest.emit(this.workRequest);
    }
    let error: Boolean = false;
    let errorId = '';
    if (this.workRequest.requestResult === ResponseBase.REQUEST_RESULT_ERROR) {
      errorId = this.workRequest.errorDetail;
      errorId = (errorId === null || errorId.trim().length <= 0) ? this.workRequest.messageId : errorId;
      this.globals.setErrorMessage(errorId);
      error = true;
    }
    if (save === true && this.length > 0 && error) {
      this.showPaginator = false;
      this.changedRecords = [];
    } else if (save === true && this.length <= 0 && !error) {
      this.resetParametersInternal();
      this.globals.setStatusMessage('MSG14');
      this.showDummy();
    } else if (save === true && this.length <= 0 && error) {
      this.resetParametersInternal();
      this.globals.setErrorMessage(errorId);
    } else if (save === true && this.length > 0 && !error) {
      this.resetParametersInternal();
      this.globals.setStatusMessage('MSG14');
    } else {
      if (!error) {
        if (this.length <= 0) {
          if (overWriteMsg) {
            this.globals.setStatusMessage('MSG02');
          }
          this.showDummy();
        } else {
          if (add) {
            this.showPaginator = false;
          } else {
            this.showPaginator = this.autoShowPaginator;
          }
        }
      }
    }

    if (save === true && !error && this.refreshAfterSave) {
      if ((this.dataTableService != null || this.dataTableService != undefined) && (this.dataTableService.criteria != undefined || this.dataTableService.criteria != null)) {
        this.dataTableService.criteria["ist_total"] = "y";
        this.dataTableService.criteria["ist_page_ctrl"] = "1";
        this.load(this.dataTableService.criteria, true);
      }

    }
  }
  updatedDataRetConfig(array: any[],columnUpdateArray:any,index:number,selectedTableName):any{
if(index <0 || index >= array.length){
  throw new Error ('Index out of bounds');
}
const updatedArray = [...array];
const currentObject = updatedArray[index];

updatedArray[index] = {
  ...currentObject,
  optionArray2:new LabelsAndValues(columnUpdateArray[0]),
  tableName:selectedTableName
}
return updatedArray;
  }
  exportIt(name: string, type: string) {
    this.exportTypeFromCLick = type;
    this.dataTableService.criteria["ist_total"] = "y";
    this.dataTableService.criteria["ist_page_ctrl"] = "-1";
    this.dataTableService.criteria["ist_export_detail"] = "y";
    this.dataTableService.criteria['eventName']=   GlobalsService.eventName;
    this.dataTableService.criteria['txnSrcAcq']= GlobalsService.txnSrcAcq;

    if (!this.isDetailTable) {
      this.dataTableService.criteria["isTxnDetailReq"] = "false";
    }

    if (this.screenType !== '')
      this.dataTableService.criteria['screenType'] = this.screenType;

    this.globals.showLoadingBar();
    this.load(this.dataTableService.criteria, true);
  }

  exportToExcel(collectionName: string, wr: WorkRequest) {
    const customHeader = [];
    const columnsToluIncde = [];
    let exportTitle: any[] = [];
    exportTitle[0] = this.exportFileName;
    let counter = 0;
    this.columnElements.forEach(element => {
      columnsToluIncde.push(element.name.toUpperCase());
      customHeader[counter] = element.header;
      exportTitle[counter + 1] = [];
      counter++;
    });
    console.log('Manoj Kumar export to excel::::' + this.collectionTag);
    console.log('Manoj Kumar export to excel actCollectionName ::::' + this.actCollectionName);
    if (this.isExportCollChnaged) {
      this.dataSource = new DataTableSource(wr.collections['' + this.actCollectionName].rows);
    } else {
      this.dataSource = new DataTableSource(wr.collections['' + this.collectionTag].rows);
    }

    this.dataSource.sort = this.sort;
    const dataToExport = this.dataSource['records'].map(item => {
      const filteredItem = {};
      for (const key in item) {
        if (columnsToluIncde.includes(key.toUpperCase())) {
          filteredItem[key] = item[key];
        }
      }
      //console.log("FilteredItem"+filteredItem);
      const sortedFilteredItem = {};
      columnsToluIncde.forEach(outerlement => {
        for (const innerelement in filteredItem) {
          if (outerlement == innerelement.toUpperCase()) {
            sortedFilteredItem[columnsToluIncde.indexOf(innerelement.toUpperCase())] = item[innerelement];

          }
        }
      })
      //console.log("sortedFilteredItem"+sortedFilteredItem);
      return sortedFilteredItem;
    });

    const onlyNameAndSymbolArr: Partial<DataTableSource>[] = dataToExport;
    const getFileName = (name: string) => {
      let timeSpan = new Date().toISOString();
      let sheetName = name || "ExportResult";
      let fileName = `${sheetName}-${timeSpan}`;
      return {
        sheetName,
        fileName
      };
    };

    var tmpSheetName = collectionName;
    if (this.exportFileName != null && this.exportFileName != '' && this.exportFileName.length <= 31)
      tmpSheetName = this.exportFileName;

    let { sheetName, fileName } = getFileName(tmpSheetName);

    var wb = XLSX.utils.book_new();
    var ws = XLSX.utils.json_to_sheet(onlyNameAndSymbolArr);

    XLSX.utils.sheet_add_aoa(ws, [exportTitle], { origin: -1 });
    XLSX.utils.sheet_add_aoa(ws, [customHeader], { origin: 'A1' });
    XLSX.utils.book_append_sheet(wb, ws, sheetName);

    // const excelBuffer: any = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    // this.saveExcelFile(excelBuffer, fileName);
    if (this.exportTypeFromCLick === '.pdf') {
      const doc = new jsPDF('l', 'pt', (customHeader.length > 13 && customHeader.length < 18) ? "a3" : customHeader.length > 18 ? "a2" : "a4");
      const data = dataToExport;
      const columns = customHeader;
      doc.text('FIS PAYMON EXPORTED '+sheetName, 50, 15);
      (doc as any).autoTable({
        head: [columns],
        body: data,
        theme: 'grid',
        startY: 18,
        styles: { overflow: 'linebreak', cellWidth: 'wrap', cellPadding: 1, fontSize: 6 },
        columnStyles: { text: { cellWidth: 'auto' } },
      });
      doc.save(fileName + this.exportTypeFromCLick);
    }
    else {
      XLSX.writeFile(wb, fileName + this.exportTypeFromCLick);
    }
    this.resetParameters();
    this.dataTableService.criteria["ist_total"] = "y";
    this.dataTableService.criteria["ist_page_ctrl"] = '' + this.istCtrlPage;
    this.dataTableService.criteria["ist_export_detail"] = "n";
    this.redirectedFrmExport = true;
    this.load(this.dataTableService.criteria, true);
  }

  exportToExcelColumns(data: any[], fileName: string, columnsToExclude: string[]): void {
    // Create a copy of the data and exclude the specified columns
    const dataToExport = data.map(item => {
      const filteredItem = {};
      for (const key in item) {
        if (!columnsToExclude.includes(key)) {
          filteredItem[key] = item[key];
        }
      }
      return filteredItem;
    });

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveExcelFile(excelBuffer, fileName);
  }


  saveExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(data);
    const a = document.createElement('a');
    a.href = url;
    let timeSpan = new Date().toISOString();
    let efName = this.exportFileName || "ExportResult";
    let fName = `${efName}-${timeSpan}`;
    a.download = fName + '.xlsx';
    a.click();
    window.URL.revokeObjectURL(url);
  }

  onErrorGotRecords(error: Object): void {
    if (!this.ignoreResetParam) {
      this.resetParametersInternal();
    }
    else {
      this.globals.hideLoadingBar();
    }
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
      this.changeDetector.markForCheck();
      super.onErrorGotRecords(error);
    }
    this.autoRefreshService.updateLastRefreshTime();
  }

  onCompleteGotRecords(): void {
    if (!this.refreshAfterSave) {
      this.globals.hideLoadingBar();
    }
    this.changeDetector.markForCheck();
    this.autoRefreshService.updateLastRefreshTime();
    if (this.checkAutoRefreshTime) {
      this.autoRefreshService.updateAutoRefreshInterval();
    }
  }

  private loadDataInternal(fresh: Boolean, overWriteMsg: Boolean = true): void {
    this.globals.showLoadingBar();
    this.dataTableService.loadData(fresh).subscribe(
      x => this.onGotRecords(x, false, false, overWriteMsg),
      error => this.onErrorGotRecords(error),
      () => this.onCompleteGotRecords()
    ).add(() => this.globals.hideLoadingBar());
  }

  highlightRow(row): void {
    this.addBeepError = 'fromClick';
    if (row) {
      if (row['dbAction'] !== 'd' && row.dbAction !== 'dummy') {
        this.rowToBeHighlighted = row;
      }
      if (row.dbAction !== 'dummy') {
        this.itemClick.emit(row);
      }
    }
  }

  highlightRed(row) {
    if (row) {
      this.returnFlag = false;
      Object.keys(row).forEach(ele => {
        if ((row[ele]) !== undefined) {
          if (this.columnLookArray.includes(ele) && this.columnLookValue.includes(row[ele])) {
            this.returnFlag = true;
          }
        }
        const table: any = this.dataTableService.criteria;
        if(ele === 'taskType' && table.CommandType === "mbrulecmd list"){
          if(row[ele] !== null){
            this.returnFlag = row[ele].search("Ready") === -1 ? true :false;
          }
      }
      if(ele === 'taskName' && table.CommandType === "dbconn"){
        if(row[ele] !== null){
          this.returnFlag = row[ele].search("up") === -1 ? true :false;
        }
    }
      })
      if (this.addBeepError !== 'fromClick' && this.returnFlag && !this.beepPlayed) {
        const oscillator = this.audioContext.createOscillator();
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(200, this.audioContext.currentTime);
        oscillator.connect(this.audioContext.destination);
        oscillator.start();
        setTimeout(() => {
          oscillator.stop();
        }, 50)
        this.beepPlayed = true;
      }
    }
    return this.returnFlag;
  }

  highlightOrange(row) {
    if (row) {
      this.returnFlag = false;
      Object.keys(row).forEach(ele => {
        if ((row[ele]) !== undefined) {
          if (this.columnLookArrayOrg.includes(ele) && this.columnLookValueOrg.includes(row[ele])) {
            this.returnFlag = true;
          }
        }
      })
      if (this.addBeepError !== 'fromClick' && this.returnFlag && !this.beepPlayed) {
        const oscillator = this.audioContext.createOscillator();
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(200, this.audioContext.currentTime);
        oscillator.connect(this.audioContext.destination);
        oscillator.start();
        setTimeout(() => {
          oscillator.stop();
        }, 50)
        this.beepPlayed = true;
      }
    }
    return this.returnFlag;
  }

  deleteRow(): void {
    console.log(this.rowToBeHighlighted);
    if (Object.keys(this.rowToBeHighlighted).length === 0) {
      this.globals.showDialog(CommonConstants.WARNING, 'ERR34', CommonConstants.ALERT_OK);
      return;
    }

    if (this.rowToBeHighlighted['dbAction'] === 'a' || this.rowToBeHighlighted['dbAction'] === ''
      || this.rowToBeHighlighted['dbAction'] === undefined || this.rowToBeHighlighted['dbAction'] === null) {
      // Remove it from the grid.
      if (this.workRequest) {
        const rows: any = this.workRequest.collections['' + this.collectionTag].rows;
        if (rows.indexOf(this.rowToBeHighlighted) > -1) {
          rows.splice(rows.indexOf(this.rowToBeHighlighted), 1);
          this.workRequest.collections['' + this.collectionTag].rows = rows;
          this.onGotRecords(this.workRequest, false);
          let paginatorRequired = false;
          for (let index = 0; index < rows.length; index++) {
            const element = rows[index];
            if (element.dbAction !== 'a') {
              paginatorRequired = true;
              break;
            }
          }
          this.showPaginator = paginatorRequired;
        }
      }
      if (this.changedRecords.indexOf(this.rowToBeHighlighted) > -1) {
        this.changedRecords.splice(this.changedRecords.indexOf(this.rowToBeHighlighted), 1);
      }
      this.changeDetector.markForCheck();
      this.rowToBeHighlighted = {};
      return;
    }

    if (this.rowToBeHighlighted['dbAction'] !== 'd') {
      this.globals.showDialog(CommonConstants.WARNING, 'MSG11', CommonConstants.ALERT_YES_NO)?.subscribe(result => {
        if ('Yes' === result) {
          this.rowToBeHighlighted['dbAction'] = 'd';
          this.rowToBeHighlighted['remoteClass'] = this.remoteClass; // Add the remote class set by the actual form
          const index = this.changedRecords.indexOf(this.rowToBeHighlighted);
          if (index > -1) {
            this.changedRecords.splice(index, 1); // Remove old changes
          }
          this.changedRecords.push(this.rowToBeHighlighted); // Add the fresh changes
          this.rowToBeHighlighted = {};
          this.changeDetector.markForCheck();
        }
      });
    }
  }

  addRow(): any {
    // We do not need mkcRemarks column if not a mkcRequest
    this.refreshTableColumns();
    if (!this.refreshAfterSave) {
      this.clearStatusMessage();
    }
    const newRecord = this.newRow();
    if (!this.workRequest) {
      this.workRequest = new WorkRequest();
      const collections: WorkCollectionCollection = {};
      collections['' + this.collectionTag] = new WorkCollection(); // Normal set method of map is not working
      this.workRequest.collections = collections;
      // Single page save method expects workRequest.getFields(); but actually no use for this
      this.addWorkFields(this.workRequest, this.fields);
    }

    // Adding the new row as first record
    if (this.workRequest.collections === undefined) {
      const collections: WorkCollectionCollection = {};
      this.workRequest.collections = collections;
    }

    if (this.workRequest.collections['' + this.collectionTag] === undefined) {
      this.workRequest.collections['' + this.collectionTag] = new WorkCollection();
    }

    if (this.workRequest.collections['' + this.collectionTag].rows === undefined) {
      this.workRequest.collections['' + this.collectionTag].rows = [];
    }
    this.workRequest.collections['' + this.collectionTag].rows.splice(0, 0, newRecord);
    if (this.workRequest.total === undefined || this.workRequest.total <= 0) {
      this.workRequest.total = this.workRequest.collections['' + this.collectionTag].rows.length;
    }
    this.onGotRecords(this.workRequest, false, true);
    if (this.collectionTag !== undefined) {
      // In case of search list where showEmptyRows is set to true; the highlightrow will emit itemClick for a dummy row
      // which is shown incase of there are no records. itemClick output emitter in turn is captured by the
      // corresponding searchlist and the window is closed prematurely by the time table is updated with an empty
      // row which results in "ExpressionChangedAfterItHasBeenCheckedError:
      // Expression has changed after it was checked. Previous value: 'role: enter'.
      // Current value: 'role: exit'." exception. So incase of searchList do not call hightlightrow()
      this.highlightRow(newRecord);
      const firstRow = this.elementRef.nativeElement.querySelector('.mat-header-row');
      if (firstRow) {
        firstRow.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
    this.changeDetector.markForCheck();
    return newRecord;
  }

  newRow(forNewRecord: Boolean = true): any {
    const newRecord = { 'remoteClass': this.remoteClass, 'inactive': '', 'dbAction': 'a', 'errorFlag': null, 'errorMessage': null };
    if (forNewRecord) { // For dummy row we do not need default values to be populated.
      this.allColumns.map((col: DataTableColumnComponent) => {
        newRecord[col.dataField] = col.defaultValue;
        if (col.labelFunction) {
          newRecord[col.dataField] = col.labelFunction(newRecord, col);
        }
      });
    }
    return newRecord;
  }

  gatherChangedRow(event: any) {
    if (event.collectionTag && event.requestType && event.row) {
      if (this.requestType === event.requestType && this.collectionTag === event.collectionTag) {
        const index = this.changedRecords.indexOf(event.row);
        if (index > -1) {
          this.changedRecords.splice(index, 1); // Remove old changes for this record
        }
        if (event.row['remoteClass'] === undefined || event.row['remoteClass'] === null) {
          event.row['remoteClass'] = this.remoteClass; // Add the remote class set by the actual form
        }
        if (this.checker && this.isMKCRequest && !(this.isReworkRequest) && this.mkc) {
          if (event.row.dbAction === 'd' && event.row.mkcStatus === 'W') {
            this.globals.showDialog(CommonConstants.WARNING, 'MKC07', CommonConstants.ALERT_OK);
            return;
          }
          if (event.row.mkcStatus !== 'S') {
            this.changedRecords.push(event.row); // Add the fresh changes for this record
            this.addOldRow(event);
          }
        } else {
          if (this.mkc && event.row.mkcStatus === 'W' && event.column && event.column.dataField !== 'mkcStatus'
            && event.column.dataField !== 'mkcRemarks') {
            event.row.reworkModified = 'Y';
          }
          this.changedRecords.push(event.row); // Add the fresh changes for this record
          this.addOldRow(event);
        }
      }
    }
  }

  validateMandatoryFields(): boolean {
    for (let i = 0; i < this.changedRecords.length; i++) {
      var row: any[] = this.changedRecords[i];
      if (this.mandatoryFieldArr !== undefined) {
        if (this.mandatoryFieldArr.array !== undefined && this.mandatoryFieldArr.array.length > 0) {
          for (let j = 0; j < this.mandatoryFieldArr.array.length; j++) {
            var columnKey: string = this.mandatoryFieldArr.array[j].label;
            var columnLabel: string = this.mandatoryFieldArr.array[j].value;
            if (row[columnKey] === undefined || row[columnKey] === '') {
              this.globals.setErrorMessage('E0106');
              row['errorFlag'] = true;
              row['errorMessage'] = columnLabel + ' is mandatory';
              return false;
            }
          }
        }
      }
    }
    return true;
  }
  save(): any {
    this.resetRequest();
    this.dataTableService.collectionTag = this.collectionTag;
    this.dataTableService.requestType = this.requestType;
    if (this.mkc && this.checker && this.isMKCRequest && !(this.isReworkRequest)) {
      this.dataTableService.action = 'checkerbatchsave';
    } else {
      this.dataTableService.action = 'save';
    }
    if (this.changedRecords.length > 0) {
      this.globals.showDialog(CommonConstants.CONFIRMATION, 'MSG10', CommonConstants.ALERT_YES_NO,
        null, null, null, '25%', '20%')?.subscribe(result => {
          if ('Yes' === result) {
            if (!this.validateMandatoryFields())
              return; // if validate fails
            this.globals.showLoadingBar();
            this.changeDetector.markForCheck();
            if (!this.workRequest) {
              this.workRequest = new WorkRequest();
              // This condition should not happen now.
            } else {
              const changedRows = this.collectChangedRows();
              for (let index = 0; changedRows && index < changedRows.length; index++) {
                const element = changedRows[index];
                if (element.dbAction !== 'd') {
                  continue;
                }
                if (element.mkcStatus) {
                  if (element.mkcStatus === 'S') {
                    continue;
                  }
                  if (element.mkcStatus === 'W') {
                    this.globals.showDialog(CommonConstants.WARNING, 'MKC07', CommonConstants.ALERT_OK);
                    this.globals.hideLoadingBar();
                    this.changeDetector.markForCheck();
                    return;
                  }
                }
              }
              this.workRequest.requestTypeId = this.requestType; // FormAuditHandler.java expects this

              this.workRequest.collections['' + this.collectionTag].rows = changedRows;
              this.workRequest.collections['' + this.collectionTag].tabId = this.tabId;
              this.workRequest.collections['' + this.collectionTag].sectionId = this.sectionId;
              this.dataTableService.save(this.workRequest).subscribe((x: any) => this.onGotRecords(x, true), // set true to indicate save action
                error => this.onErrorGotRecords(error),
                () => this.onCompleteGotRecords()
              );
            }
          }
        });
    } else {
      this.globals.showDialog(CommonConstants.INFORMATION, 'MSG22', CommonConstants.ALERT_OK,
        null, null, null, '25%', '20%');
    }
  }

  protected collectChangedRows(): any[] {
    const changedRows: any[] = [];
    this.workRequest.collections[this.collectionTag].rows.forEach((row: any) => {
      row['remoteClass'] = this.remoteClass; // Add the remote class set by the actual form
      if (this.checker && this.isMKCRequest && !(this.isReworkRequest) && this.mkc) {
        if (row.mkcStatus && row.mkcStatus !== 'S') {
          changedRows.push(row);
        } else {
          row.inactive = 'y';
        }
      } else {
        if (row.mkcStatus && row.mkcStatus === 'W') {
          if ((row.dbAction === 'c' || row.dbAction === 'd' || row.dbAction === 'a') &&
            row.reworkModified && row.reworkModified === 'Y') {
            changedRows.push(row);
          } else {
            row.inactive = 'y';
          }
        } else {
          if (row.dbAction === 'c' || row.dbAction === 'a' || row.dbAction === 'd') {
            changedRows.push(row);
          } else {
            row.inactive = 'y';
          }
        }
      }
    });
    return changedRows;
  }
  navigateToPage(pageEvent: PageEvent): void {
    if (this.paginator) {
      this.globals.showLoadingBar();
      setTimeout(() => {
        this.globals.showLoadingBar();
      }, 5);
      // Emit the page event here for now; let the corresponding form handle the criteria setting.
      // Later may be we can pass the criteria parameters like 'ist_page_ctrl' and 'ist_total' (or whatever
      // used in the form as an @input variable to this component and set the same here it self like below
      // (which is set in the actual form as of now); no need of emitting page event then.
      // this.criteria['ist_page_ctrl'] = '' + ((pageEvent.pageIndex) + 1);
      // this.criteria['ist_total'] = 'n';
      // Update: (as of 11th April, 2018): the above functionality is moved to the ListComponent;
      // so still this emitting is required which will be processed by ListComponent which is the parent class
      // for all the list screens
      this.pageIndexChanged.emit(pageEvent);
      this.globals.hideLoadingBar();
    }
  }

  resetParameters(): void {
    if (this.checkChange()) {
      this.globals.showDialog(CommonConstants.WARNING, 'MSG94', CommonConstants.ALERT_YES_NO)?.subscribe(result => {
        if ('Yes' === result) {
          this.resetParametersInternal();
          this.clearStatusMessage();
          this.showDummy();
        }
      });
    } else {
      this.resetParametersInternal();
      this.clearStatusMessage();
      this.showDummy();
    }
    this.changeDetector.markForCheck();
  }

  private resetParametersInternal() {
    this.changedRecords = [];
    if (this.paginator) {
      this.paginator.pageIndex = 0;
    }
    this.length = 0;
    this.totalDisplayingRecords = 0;
    this.workRequest = {} as WorkRequest;
    this.showPaginator = true;
    this.rowToBeHighlighted = {};
    //this.globals.hideLoadingBar();
    this.isMKCRequest = false;
    this.isReworkRequest = false;
    this.onDatatableClear.emit();
    this.refreshTableColumns();
    this.exportButtonDisable();
  }

  clearStatusMessage(): void {
    this.globals.setStatusMessage('');
  }

  addWorkFields(wr: WorkRequest, fields: any) {
    // Adding dummy work field to the workrequest; save method in java just checks whether
    // workRequest.getFields() is not null before continuing to save
    const wf: WorkField = new WorkField();
    wf.tag = 'dummy';
    const flds: { [fieldName: string]: WorkField } = {};
    flds[wf.tag] = wf;
    wr.fields[wf.tag] = wf;
  }

  consolidatePermissions(changes: SimpleChanges): void {
    if (changes['insert'] !== undefined && changes['insert'] !== null) {
      this.insert = changes['insert'].currentValue;
      this.permissions['I'] = this.insert;
    }
    if (changes['update'] !== undefined && changes['update'] !== null) {
      this.update = changes['update'].currentValue;
      this.permissions['U'] = this.update;
    }
    if (changes['delete'] !== undefined && changes['delete'] !== null) {
      this.delete = changes['delete'].currentValue;
      this.permissions['D'] = this.delete;
    }
    if (changes['checker'] !== undefined && changes['checker'] !== null) {
      this.checker = changes['checker'].currentValue;
      this.permissions['C'] = this.checker;
      if ('mkc_pending_query' === this.action) {
        this.refreshTableColumns();
      }
    }
    if (changes['mkc'] !== undefined && changes['mkc'] !== null) {
      this.mkc = changes['mkc'].currentValue;
      this.permissions['mkc'] = this.mkc;
    }
    if (changes['panMaskPattern'] !== undefined && changes['panMaskPattern'] !== null) {
      this.panMaskPattern = changes['panMaskPattern'].currentValue;
      this.permissions['PMP'] = this.panMaskPattern;
    }
  }

  setOtherInputs(changes: SimpleChanges) {
    if (changes['action'] !== undefined && changes['action'] !== null) {
      this.action = changes['action'].currentValue;
      this.dataTableService.action = this.action;
    }

    if (changes['requestType'] !== undefined && changes['requestType'] !== null) {
      this.requestType = changes['requestType'].currentValue;
      this.dataTableService.requestType = this.requestType;
    }

    if (changes['collectionTag'] !== undefined && changes['collectionTag'] !== null) {
      this.collectionTag = changes['collectionTag'].currentValue;
      this.dataTableService.collectionTag = this.collectionTag;
    }
  }

  private resetRequest(): void {
    if (this.workRequest) {
      this.workRequest.errorDetail = '';
      this.workRequest.messageId = '';
      this.workRequest.requestResult = ResponseBase.REQUEST_RESULT_SUCCESS;
    }
  }

  protected checkChange(): Boolean {
    return (this.changedRecords !== undefined && this.changedRecords !== null && this.changedRecords.length > 0);
  }

  showDummy(): void {
    if (this.editable) {
      const row = this.newRow(false);
      row.dbAction = 'dummy'; // No need to edit this row.
      const newRow = [].concat(row);
      this.dataSource = new DataTableSource(newRow);
      this.length = newRow.length;
      this.showPaginator = false;
      this.changeDetector.markForCheck();
    }
  }

  protected addOldRow(event) {
    if (this.workRequest && event.originalRow) {
      // Add originalRow as 'OLDCOLLECTIONS' so that the ISTAudit record stores the original record
      // for comparison (old and new data) later on the ISTAuditResearchScreen
      const collections: WorkCollectionCollection = this.workRequest.collections;
      if (collections.OLDCOLLECTIONS === undefined) {
        collections.OLDCOLLECTIONS = new WorkCollection();
      }
      const oldRows: any[] = this.workRequest.collections.OLDCOLLECTIONS.rows;
      if (oldRows.indexOf(event.originalRow) === -1) {
        if (event.originalRow.dbAction === 'x') {
          oldRows.push(event.originalRow);
        }
      }
    }
  }

  evaluateSaveButtonPermission(): Boolean {
    if ((((this.insert || this.update || this.delete || this.checker) && ((!this.isMKCRequest && !this.isReworkRequest)
      || (this.isMKCRequest && this.isReworkRequest))) || (this.checker && this.isMKCRequest && !this.isReworkRequest))) {
      return false;
    }
    return true;
  }

  exportButtonDisable(): Boolean {

    if (+this.totalDisplayingRecords <= 0) {
      return true;
    }

    return false;
  }

  getRowHighlighted() {
    this.globals.rowHighlightedSubject$.subscribe({
      next: (response: any) => {
        if (response) {
          this.rowToBeHighlighted = response;
        }
      },
      error: (error: Error) => {
      }
    });
  }

}
