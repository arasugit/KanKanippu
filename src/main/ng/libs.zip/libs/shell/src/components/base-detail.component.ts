import { Component,Injector, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { BaseForm } from './base-form';
import { StringUtil } from '../common/ist-string-util';
import { CommonConstants } from '../common/ist.common.constants';
import { IstProgressBarComponent } from '../components/ist-progress-bar-component';
import { IstSearchListComponent } from '../components/ist-searchlist-component';
import { ResponseBase } from '../services/response-base';
import { WorkCollection, WorkField, WorkFieldCollection, WorkRequest } from '../ist-components/work-request-model';
import { merge, Observable, throwError as observableThrowError } from 'rxjs';
import { catchError, last, map } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector:'base-list-component$',
  template:''
})
export class DetailComponent extends BaseForm implements OnInit {
  public savePermission: Boolean;
  public clonePermission: Boolean;
  private cloneToBePerformed: Boolean;
  public navigationScreenPath: string;
  protected returnToList: Boolean;
  public currentRequest: WorkRequest = new WorkRequest();

  protected oldCurrentRequest: WorkRequest;
  protected stayOnScreenFlag: boolean; // flag to check to stay on the same screen after save
  protected delChildTableChk: boolean; // flag to check if the child table popup to be shown
  public mkcData = {};
  public permsArrList: any;
  public progressBarRef: MatDialogRef<IstProgressBarComponent>;
  slDialogRef: MatDialogRef<IstSearchListComponent>;
  public ignoreWorkFieldList: string[] = [];
  protected permissionRetrived: Boolean = false;
  protected dropdownListRetrived: Boolean = false;
  protected dataRetrived: Boolean = false;
  protected overWriteMsg: Boolean = false;
  public detailParams = {};

  constructor(public injector: Injector,private spinner: NgxSpinnerService) {
    super(injector);
    this.stayOnScreenFlag = false;
    this.cloneToBePerformed = false;
    this.delChildTableChk = false;
    this.returnToList = true;
    this.setIngoreWorkFieldsList();
    this.setSenstiveFields();
    this.setT21Tags();
    this.getMetaData(false);
  }

  // Query section panel

  ngOnInit() {
    this.initialize();
    this.permsArrList = this.getEntPermList(); // it must be intitialized first
    this.route.params.subscribe(m => {
      this.params = this.formNavigation.retrieveFormParams(m);
      this.action = this.params['COMMAND'];
      if (StringUtil.isNotEmpty(this.action) && this.action !== 'return') {
        this.getAllDropDownList();
      } else {
        const isChanged: boolean = this.params['changed'];
        if(this.requestTypeId === 'SUSTXNREPD' && this.action === 'return'){
          this.action = 'update';
          this.params = this.detailParams;
          if (isChanged) {
            this.overWriteMsg = true; // Setting this flag to display Record Updated Successfully msg from Txn Edit screen after update action.
          }
          this.getAllDropDownList();
        }else if(this.requestTypeId === 'BOACQFEEQ' || this.requestTypeId === 'BOISSFEEQ'){
          this.action = 'query';
          this.getAllDropDownList();

        }
         else {
          this.setRecordAction(); // don't do anything just update the action.
          this.emptyService();
        }
      }
    });
  }
  getAllDropDownList(): void {
    this.showProgressBar('Loading...');
    const dropdownList: any = this.getAllDropdowns();
    if (dropdownList !== undefined && dropdownList !== null) {
      merge(dropdownList).pipe(last()).subscribe(result => this.getEntAndDbRecords(), err => this.getEntAndDbRecords());
    } else {
      this.getEntAndDbRecords();
    }
  }
  getEntAndDbRecords(): void {
    if (this.permsArrList !== undefined && this.permsArrList !== null && this.permsArrList.length > 0 ) {
        this.requestPerms.permsArr = this.permsArrList;
        const getPermision = this.requestPerms.getPermission2(this.router.url).pipe( map(x => { this.permissionRetrived = x; }));
        const getDetailData = this.getDetailRecord();
        merge(getPermision, getDetailData).pipe(last()).subscribe(result => this.onDBComplete(), err => this.onDBComplete());
    } else {
      this.getDetail();
    }
  }
  getDetail() {
    this.getDetailRecord().subscribe( result => this.onDBComplete(), err => this.onDBComplete());
  }
  onDBComplete() {
    setTimeout(() => {
      this.globals.hideLoadingBar();
      this.setFocusToControl();
    });
  }

  initialize(): void {
    this.mkcData = {};
    this.isCurrentRequestReady = false;
  }
  // assign the entitlement permission at the sub class level
  getEntPermList(): any[] {
    return undefined;
  }
  getAllDropdowns(): any {
    return undefined;
  }

  setRecordAction() {
    this.action = 'detail';
  }
  emptyService(): Observable<any> {  // this is required for navigation to avoid undefined promise error
    const simpleObservable = new Observable((observer) => {
      observer.next('EMPTY');
      observer.complete();
    });
    return simpleObservable;
  }
  // get detail record based on action and request type
  getDetailRecord(): Observable<void> {
    this.isCurrentRequestReady = false;
    this.globals.showLoadingBar();
    return this.bizService
      .getService(
        this.globals.userContext,
        this.requestTypeId,
        this.action,
        this.params
      )
      .pipe(
        map(this.onGetServiceResult),
        catchError((error:any)=>this.onGetServiceFalut(error))
      );
  }
  private onGetServiceFalut(error: any) {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage('Got error in processing the getService request');
      console.log('Got onGetServiceFalut', JSON.stringify(error, null, 2));
      this.returnToListModule(false);
      return observableThrowError('got error');
    }
  }

  onGetServiceResult = (resp: WorkRequest) => {
    if(resp){
      this.globals.hideLoadingBar();
    }
    this.isCurrentRequestReady = true;
    this.currentRequest = resp;
    this.decryptSenstiveData();
    this.populateMKCData();
    this.checkResultMessage(
      this.currentRequest['messageId'],
      this.currentRequest['requestResult'],
      this.currentRequest['messageSubstitutions'],
      this.currentRequest['errorDetail']
    );
    if (resp.requestResult === ResponseBase.REQUEST_RESULT_ERROR) {
      // we should return back to query screen when original record/record not found
      if (StringUtil.isNotEmpty(this.currentRequest.errorDetail) &&
        (this.currentRequest.errorDetail === 'MKC08' || this.currentRequest.errorDetail === 'ER244')) {
        this.returnToListModule(true);
      }
      this.globals.setErrorMessage(resp.errorDetail);
      return;
    }
    this.setSavePermission();
    this.setClonePermission();
    this.updateQueryResults();
    this.copyWorkRequest();
    this.setFocusToControl();
  }
  setFocusToControl() {
    if (this.action === CommonConstants.ACTION_INSERT ||
      (this.action === CommonConstants.MKC_ACTION_REWORK_EDIT &&
        this.currentRequest.mkcId !== undefined && this.currentRequest.mkcId !== null &&
        StringUtil.isNotEmpty(this.currentRequest.mkcRecordAction) && this.currentRequest.mkcRecordAction === 'insert')) {
      this.setFocusToFirstField();
    } else if (this.action === CommonConstants.ACTION_UPDATE ||
      (this.action === CommonConstants.MKC_ACTION_REWORK_EDIT &&
        this.currentRequest.mkcId !== undefined && this.currentRequest.mkcId !== null &&
        StringUtil.isNotEmpty(this.currentRequest.mkcRecordAction) && this.currentRequest.mkcRecordAction === 'update')) {
      this.setFocusToFirstUpdateField();
    }
  }
  copyWorkRequest(): void {
    this.oldCurrentRequest = this.deepCopy(this.currentRequest); // copy the workrequest for comparison
  }

  updateQueryResults(): void {
    return;
  }
  // validate the data in the workrequest
  validateWorkField(fieldTag: string, errMsg: string, focusField: any = null): boolean {
    let flg = true;
    const val = this.getFieldValue(fieldTag);
    if (StringUtil.isNotEmpty(val)) {
      this.globals.setErrorMessage('');
    } else {
      this.globals.setErrorMessage(errMsg);
      if (focusField !== undefined && focusField !== null) {
        focusField.setFocus();
      }
      flg = false;
    }
    return flg;
  }

  // get value from WorkField
  getFieldValue(tag: string): string {
    const wrField: WorkField = this.currentRequest.fields[tag];
    const val =
      wrField !== undefined &&
        wrField !== null &&
        wrField.value !== undefined &&
        wrField.value !== null
        ? wrField.value
        : '';
    return val;
  }
  // get value from WorkField
  getFieldOldValue(tag: string): string {
    const wrField: WorkField = this.currentRequest.fields[tag];
    const val =
      wrField !== undefined &&
        wrField !== null &&
        wrField.oldValue !== undefined &&
        wrField.oldValue !== null
        ? wrField.oldValue
        : '';
    return val;
  }
  //get the label of the Workfield
  getFieldLabel(tag: string): string {
    const wrField: WorkField = this.currentRequest.fields[tag];
    const val =
      wrField !== undefined &&
        wrField !== null &&
        wrField.label !== undefined &&
        wrField.label !== null
        ? wrField.label
        : '';
    return val;
  }
  setFieldValue(tag: string, value: string) {
    const wrField: WorkField = this.currentRequest.fields[tag];
    if (wrField !== undefined && wrField !== null) {
      wrField.value = value;
    } else {
    }
  }

  setFieldModifyable(tag: string, modifyable: string) {
    const wrField: WorkField = this.currentRequest.fields[tag];
    if (wrField !== undefined && wrField !== null) {
      wrField.modifyable =
        modifyable !== undefined && (modifyable === 'Y' || modifyable === 'y')
          ? 'Y'
          : 'N';
    } else {
    }
  }

  getDisableFlag(tag: string): boolean {
    const wrField: WorkField = this.currentRequest.fields[tag];
    if (wrField !== undefined && wrField !== null) {
      if (wrField.modifyable !== undefined && (wrField.modifyable === 'Y' || wrField.modifyable === 'y')) {
        return false;
      } else {
        return true;
      }
    }
    return true;
  }

  workFieldEquals(
    tag: string,
    inputValue: string,
    ignoreCase: boolean
  ): boolean {
    const wrField: WorkField = this.currentRequest.fields[tag];
    if (wrField === undefined) {
      return false;
    }
    if (inputValue === undefined) {
      return false;
    }
    const val =
      wrField !== undefined &&
        wrField !== null &&
        wrField.value !== undefined &&
        wrField.value !== null
        ? wrField.value
        : '';
    let result: boolean;
    result = false;
    if (ignoreCase) {
      result = (wrField.value !== null ? wrField.value.toLocaleLowerCase : '') === inputValue.toLocaleLowerCase;
    } else {
      result = wrField.value === inputValue;
    }

    return result;
  }

  workFieldNotEmpty(tag: string): boolean {
    const wrField: WorkField = this.currentRequest.fields[tag];
    const val =
      wrField !== undefined &&
        wrField !== null &&
        wrField.value !== undefined &&
        wrField.value !== null
        ? wrField.value
        : '';
    const result: boolean = val === '' ? false : true;
    return result;
  }
  // called when Save button is clicked
  onSaveClick() {
    if (!this.validateBeforeSave()) {
      // if mandatory check fails then return
      return;
    }
    if (!this.updateWorkRequest()) {
      // if mandatory check fails then return
      return;
    }

    if (this.compareWorkRequest() === true) {
      // true if data is modified
      if (this.stayOnScreenFlag && !this.isMKCEnabled()) {
        // stay on the screen dialog based on the flag
        this.globals.showDialog(CommonConstants.CONFIRMATION,'ER262', CommonConstants.ALERT_YES_NO)?.subscribe(result => {
            if ('Yes' === result) {
              this.returnToList = false;
              this.onSaveRecord();
            } else {
              this.returnToList = true;
              this.onSaveRecord();
            }
          });
      } else {
        // default behaviour
        this.onSaveRecord();
      }
    } else {
      // if no data change,dispay nothing to save message
      this.displayNothingChanged();
    }
  }
  // called to display nothing to save message
  displayNothingChanged() {
    this.globals.showDialog(CommonConstants.INFORMATION,'MSG22',CommonConstants.ALERT_OK)?.subscribe(result => {
        if ('Ok' === result) {
          return;
        }
      });
  }

  updateWorkRequest(): boolean {
    return true;
  }
  validateBeforeSave(): boolean {
    return true;
  }
  // Compare the data and return true if data is modified
  compareWorkRequest(): boolean {
    for (const fieldName in this.currentRequest.fields) {
      if (
        this.oldCurrentRequest !== undefined &&
        this.oldCurrentRequest.fields !== undefined &&
        this.oldCurrentRequest.fields.hasOwnProperty(fieldName)
      ) {
        const wrField = this.currentRequest.fields[fieldName];
        const oldwrField = this.oldCurrentRequest.fields[fieldName];

        if (wrField.editType === 'NUMBER' || wrField.editType === 'AMOUNT') {
          if ((oldwrField.value === undefined || oldwrField === null || oldwrField.value === '')
          && (wrField.value === '' || wrField.value === undefined)) { continue; }
          if (oldwrField.value === null && wrField.value === null) { continue; }
          let currentValue = wrField.value;
          let oldValue = oldwrField.value;
          let strVal: string = String(currentValue);
           strVal = strVal.replace(new RegExp(',', 'g'), '');  // this logic need to be revisited during localization
           currentValue = strVal;

           strVal = String(oldValue);
           strVal = strVal.replace(new RegExp(',', 'g'), '');  // this logic need to be revisited during localization
           oldValue = strVal;

          if (Math.abs(Number(oldValue)) !== Math.abs(Number(currentValue))) {
            return true;
          }
        } else {  // non numeric fields
        if (oldwrField.value !== wrField.value) {
            if ((oldwrField.value === undefined || oldwrField.value === null || oldwrField === null || oldwrField.value === '') &&
                (wrField.value === undefined || wrField.value === null || wrField.value === ''
                  || wrField.value === 'null')) { continue; }
          if (!this.checkIgnoreField(fieldName)) { return true; }
        }
      }
      } else {
        // if field is not found in current request, then compare old and new value fields of workfield
        const wrField: WorkField = this.currentRequest.fields[fieldName];
        let flag: boolean;
        flag = false;
        for (let i = 0; i < this.ignoreWorkFieldList.length; i++) {
          flag = this.ignoreWorkFieldList[i] === fieldName;
          if (flag) {
            break;
          }
        }
        if (flag) {
          continue;
        }
        if (wrField.oldValue !== wrField.value) {
          return true;
        }
      }
    }
    if (this.checkCollectionChanged()) {
      return true;
    }
    return false;
  }

  // this method need to be overriden in the sub classes to check if there any data changed in Data table
  checkCollectionChanged(): boolean {
    return false;
  }
  checkIgnoreField(fieldName: string): boolean {
    if (this.ignoreWorkFieldList === undefined || this.ignoreWorkFieldList === null) {
      return false;
    }
    for (let i = 0; i < this.ignoreWorkFieldList.length; i++) {
      const flag = this.ignoreWorkFieldList[i] === fieldName;
      if (flag) {
        return true;
      }
    }
    return false;
  }

  // if all the validation successful, onSaveRecord method is called
  onSaveRecord() {
    this.showProgressBar('Processing');
    this.encryptSenstiveData();
    this.resetWorkRequest();
    this.setActionBeforeSave();
    this.bizService
      .setService(
        this.globals.userContext,
        this.requestTypeId,
        this.action,
        this.currentRequest
      )
      .subscribe(this.onSetServiceResult, this.onServiceFault);
  }

  setActionBeforeSave() {
    this.action = (this.action !== 'insert' && this.action !== 'mkc_rework_edit') ? 'update' : this.action;
  }

  // Called when Delete button is clicked
  onDeleteClick() {
    this.resetWorkRequest();
    this.globals.showDialog(CommonConstants.WARNING,'MSG23',CommonConstants.ALERT_YES_NO)?.subscribe(result => {
        if ('Yes' === result) {
          this.onDeleteRecord();
        }
      });
  }

  // if user clicks "Yes" to delete the record, onDeleteRecord is called
  onDeleteRecord() {
    this.showProgressBar('Processing');
    this.encryptSenstiveData();
    this.action = 'delete';
    this.bizService
      .setService(
        this.globals.userContext,
        this.requestTypeId,
        this.action,
        this.currentRequest
      )
      .subscribe(this.onSetServiceResult, this.onServiceFault);
  }

  // resetting workrequest fields before sending it backend for processing
  resetWorkRequest() {
    this.currentRequest.errorDetail = '';
    this.currentRequest.messageId = '';
    this.currentRequest.requestResult = ResponseBase.REQUEST_RESULT_SUCCESS;
  }

  // called on return from backend for save/delete opereation

  onSetServiceResult = (resp: any) => {
    // expecting a workrequest
    this.hideProgressBar();
    this.currentRequest = resp as WorkRequest;
    this.decryptSenstiveData();
    this.oldCurrentRequest = this.deepCopy(this.currentRequest);
    if (this.currentRequest.requestResult === ResponseBase.REQUEST_RESULT_ERROR) {
      if (this.delChildTableChk) {
        const childTableList: any[] = this.currentRequest.messageSubstitutions;
        if (childTableList !== null && childTableList.length > 0) {
          this.showChildTablePopup(childTableList);
          return;
        }
      }
      // we should return back to query screen if system failure case
      if (this.isMKCEnabled() && this.isChecker() && this.currentRequest.systemFailure) {
        this.returnToListModule(false);
      }
     this.globals.setErrorMessage(resp.errorDetail);
      return;
    } else if (
      this.currentRequest.requestResult === ResponseBase.REQUEST_RESULT_SUCCESS
    ) {
      let msg = '';
      if ('OASUSERDET' === this.requestTypeId) {
        // user admin is different case
        msg = this.currentRequest.errorDetail;
        if (msg !== null && msg.length === 5) {
          msg = this.getSuccessStatusCode();
          this.globals.setStatusMessage(msg); // record saved successfully
        } else {
          this.globals.showDialog(CommonConstants.INFORMATION, msg,CommonConstants.ALERT_OK)?.subscribe(result => {
            if (this.isMKCEnabled()) {
              this.returnToListModule(true);
              return;
            }
          }); // password generated
          if (this.isMKCEnabled()) {
            return;
          }
        }
      } else {
        msg = this.getSuccessStatusCode();
        this.globals.setStatusMessage(msg);
      }

      if (this.cloneToBePerformed) {
        this.cloneWorkRequest();
        return;
      } else {
        if (
          this.stayOnScreenFlag &&
          this.action === CommonConstants.ACTION_INSERT
        ) {
          this.action = this.updatePerm.allowed
            ? CommonConstants.ACTION_UPDATE
            : CommonConstants.ACTION_QUERY_DETAIL;
        }
        this.setClonePermission();
      }
      if (this.returnToList === true) {
        if (this.isMKCEnabled() &&
          (this.action === CommonConstants.ACTION_UPDATE || this.action === CommonConstants.ACTION_DELETE)) {
          this.returnToListModule(false);
        } else {
          this.returnToListModule(true);
        }
      } else {
        this.setRecordAction();
      }
      this.setFocusToControl();
      this.onSetServiceComplete();
    }
  }
  // error handling
  onServiceFault = (err: any) => {
    this.hideProgressBar();
    if (this.globals.checkErrorResponse(err)) {
      this.globals.statusMessage = 'Got error!';
    }
  }

  // Do nothing; but overridden by implementing screens to retrieve information if any set from the backend
  // through work request fields to show in the GUI after the successful setService call.
  onSetServiceComplete(): void {
    return;
  }

  // called when Cancel button is clicked
  cancel() {
    this.globals.setStatusMessage('');
    if (this.compareWorkRequest() === true) {
      this.globals.showDialog(CommonConstants.WARNING,'MSG24',CommonConstants.ALERT_YES_NO)?.subscribe(result => {
          if ('Yes' === result) {
            this.returnToListModule(false);
          }
        });
    } else {
      this.returnToListModule(false);
    }
  }

  // return to list screen. boolean flag indicates whether refresh data table in the list screen required or not
  // return true for save and return false if cancel is called
  returnToListModule(changed: boolean): void {
    this.setSenstiveFields(); // to reset the fields
       this.formNavigation.returnFromForm(changed,this.getAdditionalParams());
    return;
  }

  getAdditionalParams():any {
    return undefined;
  }

  // called to display the error message if there is any errors in current request
  checkResultMessage(
    messageId: String,
    requestResult: String,
    messageSubstitutions: any[],
    messageText: String
  ): void {
    if (!messageId) {
      if(this.overWriteMsg) {
        this.globals.setStatusMessage('MSG04');
        this.overWriteMsg = false;
      } else {
        this.globals.setStatusMessage('');
      }
    } else {
      // TODO get application messages
      const newText = messageText || 'error ' + messageId;
      this.globals.setStatusMessage(newText);
    }
  }
  back() {
    this.returnToListModule(false);
  }

   getCollectionRows(collection: string): any {
    if (StringUtil.isNotEmpty(collection)) {
      if (
        this.currentRequest !== undefined &&
        this.currentRequest.collections !== undefined &&
        this.currentRequest.collections[collection] !== undefined
      ) {
        return this.currentRequest.collections[collection].rows;
      }
    }
  }

  deepCopy<T>(obj: T): T {
    if (obj !==undefined && obj !== null)
      return JSON.parse(JSON.stringify(obj));
    else
      return obj;
  }

  getCollectionFromWR(wrkRequest: WorkRequest, collection: string): any {
    if (StringUtil.isNotEmpty(collection)) {
      if (wrkRequest !== undefined && wrkRequest.collections !== undefined  && wrkRequest.collections[collection] !== undefined
        && wrkRequest.collections[collection].rows !== undefined) {
        return wrkRequest.collections[collection].rows;
      }
    }
  }


  setCollectionToWR(collection: string, modifiedCollion: any): void {
    if (StringUtil.isNotEmpty(collection)) {
      if (this.currentRequest !== undefined && this.currentRequest.collections !== undefined
        && this.currentRequest.collections[collection] !== undefined) {
        this.currentRequest.collections[collection].rows = modifiedCollion;
      }
    }
  }
  loadNewForm(command: any, path: string) {
    this.formNavigation.callForm(
      this.route.snapshot,
      path,
      command,
      this.breadcrumbText
    );
  }

  addWorkField(tag: string, value: any) {
    if (StringUtil.isEmpty(tag)) {
      return;
    }

    const wfc: WorkFieldCollection = this.currentRequest.fields;
    if (wfc !== undefined) {
      const wf: WorkField = new WorkField();
      wf.tag = tag;
      wf.value = value;
      wf.oldValue = value;
      wfc[tag] = wf;
    }
  }

  jsonEqual(object1: any, object2: any) {
    return !(JSON.stringify(object1) === JSON.stringify(object2));
  }

  setRemoteClassToWC(collection: string, remoteClass: string) {
    let wc: WorkCollection = this.currentRequest.collections[collection];
    if (wc === undefined) {
      wc = new WorkCollection();
      wc.remoteClass = WorkCollection.remoteClassName;
    } else {
      wc.remoteClass = WorkCollection.remoteClassName;
      const wcRows = wc.rows;
      if (wcRows && wcRows !== undefined) {
        wcRows.forEach(record => {
          record['remoteClass'] = remoteClass;
        });
      }
    }
  }

  setIngoreWorkFieldsList(): void {
    this.ignoreWorkFieldList = [];
  }
  // display list of child tables which are affected due to the delete
  showChildTablePopup(tablist: any[]) {
    const data: any[] = [];
    for (let i = 0; i < tablist.length; i++) {
      const obj: Object = {};
      obj['tableName'] = tablist[i];
      data.push(obj);
    }

    this.slDialogRef = this.dialog.open(IstSearchListComponent, {
      panelClass: 'sl-mat-dialog-container',
      data: {
        type: 'CHILD_TABLES_POPUP',
        defaultParams: {
          tableList: data,
          parentTableName: this.getParentTableName(),
          deleteAllOption: this.getDeleteAllOption()
        }
      }
    });
    this.slDialogRef.updateSize('700px');
    this.slDialogRef.afterClosed().subscribe(result => {
      if ('delete' === result) {
        this.action = CommonConstants.ACTION_DELETE_ALL;
        this.bizService
          .setService(
            this.globals.userContext,
            this.requestTypeId,
            this.action,
            this.currentRequest
          )
          .subscribe(this.onSetServiceResult, this.onServiceFault);
      }
    });
    return;
  }

  getParentTableName(): string {
    return 'aaaaa';
  }
  getDeleteAllOption(): string {
    return 'N';
  }


  encryptSenstiveData(): void {
    if (this.sensitiveFldList.length === 0) {
      return;
    }
    for (let i = 0; i < this.sensitiveFldList.length; i++) {
      this.setFieldValue(
        this.sensitiveFldList[i],
        this.globals.encryptData(this.getFieldValue(this.sensitiveFldList[i]))
      );
    }
  }

  decryptSenstiveData(): void {
    if (this.sensitiveFldList.length === 0) {
      return;
    }
    for (let i = 0; i < this.sensitiveFldList.length; i++) {
      this.setFieldValue(
        this.sensitiveFldList[i],
        this.globals.decryptData(this.getFieldValue(this.sensitiveFldList[i]))
      );
    }
  }

  setSavePermission(): void {
    this.savePermission =
      this.action === CommonConstants.ACTION_INSERT ||
        this.action === CommonConstants.ACTION_UPDATE ||
        this.action === CommonConstants.MKC_ACTION_REWORK_EDIT
        ? true
        : false;
  }

  setClonePermission(): void {
    this.clonePermission =
      this.action === CommonConstants.ACTION_UPDATE ||
        this.action === CommonConstants.ACTION_QUERY_DETAIL
        ? this.insertPerm
          ? this.insertPerm.allowed
          : false
        : false;
  }

  // MKC related changes goes here
  viewRemarks(): void {
    this.showMKCRemarksPopup('REMARKS', true);
  }

  onCheckerAction(btnAction: string) {
    this.encryptSenstiveData();
    this.resetWorkRequest();
    if (
      btnAction !== undefined &&
      !(
        btnAction === 'APPROVE' ||
        btnAction === 'REJECT' ||
        btnAction === 'REWORK'
      )
    ) {
      return;
    }
    if (btnAction === 'REWORK') {
      if (
        this.currentRequest.mkcRecordAction === CommonConstants.ACTION_DELETE
      ) {
        this.globals.showDialog(CommonConstants.WARNING,'MKC07',CommonConstants.ALERT_OK)?.subscribe(result => {
            if ('Ok' === result) {
              return;
            }
          });
        return;
      }
    }
    this.showMKCRemarksPopup(btnAction, false);
  }

  showMKCRemarksPopup(btnAction: string, disableFlag: boolean): void {
    this.slDialogRef = this.dialog.open(IstSearchListComponent, {
      panelClass: 'sl-mat-dialog-container',
      data: {
        type: 'MKC_REMARKS_POPUP',
        defaultParams: {
          remarks: this.currentRequest.mkcRemarks,
          disableFlag: disableFlag,
          mkcBtnAction: btnAction
        }
      }
    });
    this.slDialogRef.updateSize('400px', '200px');
    this.slDialogRef.afterClosed().subscribe(result => {
      let updatedRemarks = '';
      if (result === undefined || result['btnAction'] === 'CANCEL') {
        return;
      }
      if (result['remarks'] !== undefined && result['remarks'] !== undefined) {
        updatedRemarks = result['remarks'];
      }
      switch (result['mkcBtnAction']) {
        case 'REJECT':
          this.action = CommonConstants.MKC_ACTION_REJECT;
          this.currentRequest.mkcRemarks = updatedRemarks;
          break;
        case 'REWORK':
          this.action = CommonConstants.MKC_ACTION_REWORK;
          this.currentRequest.mkcRemarks = updatedRemarks;
          break;
        case 'APPROVE':
          {
            this.currentRequest.mkcRemarks = updatedRemarks;
            if (
              this.currentRequest.mkcRecordAction !==
              CommonConstants.ACTION_DELETE
            ) {
              if (!this.validateBeforeSave()) {
                return;
              }
            }
            this.action = CommonConstants.MKC_ACTION_APPROVE;
          }
          break;
        default:
          return;
      }
      this.bizService
        .setService(
          this.globals.userContext,
          this.requestTypeId,
          this.action,
          this.currentRequest
        )
        .subscribe(this.onSetServiceResult, this.onServiceFault);
    });
    return;
  }
  populateMKCData(): void {
    this.mkcData = [];
    this.mkcData['mkcId'] = this.currentRequest.mkcId;
    this.mkcData['mkcRecordAction'] = this.currentRequest.mkcRecordAction;
    this.mkcData['mkcStatus'] = this.currentRequest.mkcStatus;
    this.mkcData['makerId'] = this.currentRequest.makerId;
  }

  isChecker(): boolean {
    if (this.isMKCRecord() && this.checkerPerm.allowed) {
      if (
        this.currentRequest.mkcStatus !== undefined &&
        this.currentRequest.mkcStatus === CommonConstants.MKC_STATUS_SUBMIT &&
        this.currentRequest.makerId !== this.globals.userContext.userID
      ) {
        return true;
      }
    }
    return false;
  }
  isMKCRecord(): boolean {
    if (this.currentRequest !== null && this.currentRequest.mkcId > 0) {
      return true;
    } else {
      return false;
    }
  }
  isReworkRecord(): boolean {
    if (this.currentRequest !== null && this.currentRequest.mkcId > 0 &&
      this.currentRequest.mkcStatus === CommonConstants.MKC_STATUS_REWORK) {
      return true;
    } else {
      return false;
    }
  }
  isMKCEnabled(): boolean {
    if (this.mkcPerm !== undefined) {
      return this.mkcPerm.allowed;
    }
    return false;
  }

  getSuccessStatusCode(): string {
    let msgCode = '';
    msgCode = this.getActionBaseCode(this.action);
    if (this.isMKCEnabled()) {
      switch (this.action) {
        case CommonConstants.ACTION_INSERT:
        case CommonConstants.ACTION_UPDATE:
        case CommonConstants.ACTION_DELETE:
        case CommonConstants.ACTION_DELETE_ALL:
        case CommonConstants.MKC_ACTION_REWORK_EDIT:
          msgCode = 'MKC01';
          break;
        case CommonConstants.MKC_ACTION_APPROVE:
          {
            msgCode = this.getActionBaseCode(
              this.currentRequest.mkcRecordAction
            );
          }
          break;
        case CommonConstants.MKC_ACTION_REJECT:
        case CommonConstants.MKC_ACTION_REWORK:
          msgCode = this.currentRequest.errorDetail;
          break;
        default:
          msgCode = 'default';
          break;
      }
    }
    return msgCode;
  }
  getActionBaseCode(tempAction: string) {
    let msg =
      'insert' === tempAction
        ? 'MSG03'
        : 'update' === tempAction
          ? 'MSG04'
          : 'save' === tempAction
            ? 'MSG73'
            : 'MSG05';
    msg = msg !== undefined && msg !== '' ? msg : 'status code not set';
    return msg;
  }
  onCloneClick() {
    if (this.compareWorkRequest() === true) {
      this.globals.showDialog(CommonConstants.WARNING,'MSG44',CommonConstants.ALERT_YES_NO)?.subscribe(result => {
          if ('Yes' === result) {
            this.saveBeforeClone();
          }
        });
    } else {
      this.cloneWorkRequest();
    }
  }
  saveBeforeClone(): void {
    if (!this.validateBeforeSave()) {
      // if mandatory check fails then return
      return;
    }
    if (!this.updateWorkRequest()) {
      // if mandatory check fails then return
      return;
    }
    this.cloneToBePerformed = true;
    this.returnToList = false;
    this.onSaveRecord();
  }
  cloneWorkRequest(): void {
    this.cloneToBePerformed = false;
    this.action = CommonConstants.ACTION_INSERT;
    this.setClonePermission();
    this.currentRequest = this.currentRequest;
    this.oldCurrentRequest = this.deepCopy(this.currentRequest);
  }
  showProgressBar(msg: any = null): void {
    setTimeout(() => {
      this.globals.showLoadingBar();
    },20);
  }

  hideProgressBar(): Observable<any> {

    setTimeout(() => {
      this.globals.hideLoadingBar();
    },10);
    return {} as Observable<any>;
  }

}
