import { AfterContentInit, ChangeDetectorRef, Component, ContentChildren, EventEmitter, ViewContainerRef,
  ComponentFactoryResolver, forwardRef, Input, OnChanges, OnDestroy, Output, QueryList, SimpleChanges,
   ViewChild, ViewChildren, ElementRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { DataTablePaginatorComponent } from './data-table.paginator.component';
import { T21Base } from './t21-base';
import { DataTableService } from '../services/data-table.service';
import { GlobalsService } from '../services/globals.service';
import { ResponseBase } from '../services/response-base';
import { WorkRequest } from '../ist-components/work-request-model';
import { Subscription } from 'rxjs';
import { StringUtil } from '../common/ist-string-util';
import { MessageService } from '../services/message.event.services';
import { AbstractDataTableComponent, DataTableSource } from './abstract-data-table.component';
import { InquiryDataTableColumnComponent } from './inquiry-data-table-column.component';

export const T21BASE_ACCESSOR_INQUIRY: any = {
  provide: T21Base,
  useExisting: forwardRef(() => InquiryDataTableComponent),
  multi: true
};

export const ISTDATATABLE_ACCESSOR_INQUIRY: any = {
  provide: AbstractDataTableComponent,
  useExisting: forwardRef(() => InquiryDataTableComponent),
  multi: true
};

@Component({
  selector: 'app-inquiry-data-table',
  templateUrl: 'inquiry-data-table.component.html',
  providers: [T21BASE_ACCESSOR_INQUIRY, ISTDATATABLE_ACCESSOR_INQUIRY],
  styles: [`.highlight {background: #fef8cc;}`]
})

// This component will be used for list screen non-editable datatgrid, search list and detail page non-editable datagrid
export class InquiryDataTableComponent extends AbstractDataTableComponent
  implements AfterContentInit, OnDestroy, OnChanges {
  paginator: DataTablePaginatorComponent;

  @ViewChild(DataTablePaginatorComponent, { static: false }) set initialize(paginator: DataTablePaginatorComponent) {
    this.paginator = paginator;
    this.setPaginator();
  }

  // added
  @ViewChildren('matrow', { read: ViewContainerRef }) matrows: QueryList<ViewContainerRef>;
  //
  criteria: {};
  length = 0;
  totalRecords = 0; // To be used for total number of records message.
  isLoadingResults = false;
  loadingMessage: string;
  workRequest: WorkRequest;
  errorId: string;
  subscription: Subscription;
  pageSize: number;
  @Output() onDatatableClear = new EventEmitter<any>();
  @Output() itemClick = new EventEmitter<any>();
  @Output() itemDblclick = new EventEmitter<any>();
  @Output() pageIndexChanged = new EventEmitter<PageEvent>();
  // Some screens (like dispense table etc.) need to have the already loaded work request by means of search
  // for further processing. Hence emitting the same once loaded here. As of now emitted only for query.
  @Output() getWorkRequest = new EventEmitter<WorkRequest>();
  @Input() action: String;
  @Input() showPaginator = true; // By default show paginator
  @Input() showEmptyTable: Boolean = false; // By default do not show empty table
  @Input() ignoreMsg: Boolean = false; // By default the error msg or success msg will be displayed

  // Do not manipulate this variable as this is used in combination with the @Input showPaginator to hide/show
  // the paginator.
  togglePaginator = false;

  // This is for showing 'Total number of records: ' used in search list
  @Input() showTotal = false;

  // Do not manipulate this variable as this is used in combination with the @Input showTotal to hide/show
  // the total records message.
  toggleShowTotal = false;

  displayedColumns: string[] = [];

  @Input()
  set columnsToDisplay(val: string | string[]) {
    if (typeof val === 'string') {
      this.displayedColumns = val.split(/\s*,\s*/);
    } else {
      this.displayedColumns = val;
    }
  }

  @Input() dataTableId: String;

  @ContentChildren(InquiryDataTableColumnComponent)
  protected columnElements: QueryList<InquiryDataTableColumnComponent>;

  rowToBeHighlighted: object;
  selectedRowIndex = -1;

  constructor(
    private dataTableService: DataTableService,
    private changeDetector: ChangeDetectorRef,
    private globals: GlobalsService,
    private msgService: MessageService,
    public componentFactoryResolver: ComponentFactoryResolver,
    public viewContainerRef: ViewContainerRef,
    public dialog?: MatDialog,
    public elementRef?:ElementRef
  ) {
    super(globals, componentFactoryResolver, viewContainerRef, dialog,elementRef);
    const pagesize = this.globals.configOptions['ist.default_page_size'];
    this.pageSize = pagesize ? Number(pagesize) : 0;
    if (this.pageSize === 0) {
      this.pageSize = 5;
    }
    this.subscription = this.msgService.getMessage().subscribe(message => {
      if (message.text === 'localechanged') {
        this.refreshData(); // the data will be refreshed whenever the locale change happens.
      }
    });
  }

  ngAfterContentInit() {
    if (this.columnElements && this.columnElements.length > 0) {
      this.allColumns = this.columnElements.toArray();
    }
    if (this.displayedColumns.length === 0) {
      this.displayedColumns = this.allColumns.map(
        (col: InquiryDataTableColumnComponent) => col.name
      );
    }
    this.allColumns.forEach(element => {
      if (element.visible === true) {
        element.editable = false; // This is a inquiry datatable
      } else {
        const index = this.displayedColumns.indexOf(element.name);
        if (index > -1) {
          this.displayedColumns.splice(index, 1);
        }
      }
    });
    this.showDummy();
    this.listenToTableStructureChanges();
  }

  private listenToTableStructureChanges() {
    try {
      if (this.columnElements) {
        this.columnElements.changes.subscribe(() => {
          if (this.dataSource && this.dataSource.data) {
            if (this.columnElements && this.columnElements.length > 0) {
              this.allColumns = this.columnElements.toArray();
            }
            this.displayedColumns = this.allColumns.map(
              (col: InquiryDataTableColumnComponent) => col.name
            );
            this.allColumns.forEach(element => {
              if (element.visible === true) {
                element.editable = false; // This is a inquiry datatable
              } else {
                const index = this.displayedColumns.indexOf(element.name);
                if (index > -1) {
                  this.displayedColumns.splice(index, 1);
                }
              }
            });
            // this.showDummy();
          }
        });
      }
    } catch (e) {
      // Ignore
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    try {
      this.setOtherInputs(changes);
      let records: any[];
      if (changes['dataProvider'] !== undefined && changes['dataProvider'] !== null) {
        if (Array.isArray(changes['dataProvider'].currentValue)) {
          records = changes['dataProvider'].currentValue;
        } else {
          this.workRequest = changes['dataProvider'].currentValue;
          this.emitWorkRequest();
          records = this.workRequest.collections['' + this.collectionTag].rows;
        }
        // Load the datatable records
        this.loadRecords(records);
      }
    } catch (e) {
      // ignore
    } finally {
      this.clearFlags();
    }
  }

  load(criteria: any, fresh: Boolean, overWriteMsg: Boolean = true): void {
    this.dataTableService.requestType = this.requestType;
    this.dataTableService.collectionTag = this.collectionTag;
    if (criteria !== undefined && criteria['COMMAND'] !== undefined) {
      this.dataTableService.action = criteria['COMMAND'];
    } else {
      this.dataTableService.action = 'query';
    }
    this.dataTableService.criteria = criteria;
    if (fresh === true) {
      this.resetParametersInternal();
      this.resetRequest();
      this.clearStatusMessage();
    }
    this.loadDataInternal(fresh, overWriteMsg);
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = new WorkRequest();
    this.workRequest = wr;
    this.togglePaginator = true;
    this.toggleShowTotal = true;
    // The following sequence of method calls are only for search button click action result where the workrequest
    // is populated with proper information.
    this.setLength();
    this.setRecords();
    this.setSummaryRow();
    this.emitWorkRequest();
    if (!this.ignoreMsg) {
      this.onInquiry(overWriteMsg);
    }
    this.onDatatableClear.emit();
    try {
      this.rowToBeHighlighted = this.selectedRowIndex > -1 ? this.workRequest.collections['' + this.collectionTag].rows[this.selectedRowIndex] : undefined;
      this.scrollToSelectedRow();
    } catch (error) {
      // Ignore
    }
  }
  public scrollToSelectedRow() {
    console.log('inquiry data table scrollToSelectedRow', this.selectedRowIndex);
    if (this.selectedRowIndex !== undefined && this.selectedRowIndex > -1) {
      this.changeDetector.detectChanges();
      this.matrows.forEach(r => {
      if (Number(r.element.nativeElement.getAttribute('rowIndex')) === Number(this.selectedRowIndex)) {
          //console.log(' row found ', Number(r.element.nativeElement.getAttribute('rowIndex')));
           setTimeout(() => {
            r.element.nativeElement.scrollIntoView( {behavior: 'smooth', block: 'center', inline : 'center'});
          }, 2)
          return true;
        }
     } );
    }
  }
  setSummaryRow() {
    if (this.workRequest.collections[this.summaryColTag] && this.workRequest.collections[this.summaryColTag].rows) {
      let summaryObj:{};

      let totalRows = this.workRequest.collections[this.summaryColTag].rows;

      if (totalRows && totalRows !== undefined) {
        if (totalRows.length >= 0) {
          summaryObj = totalRows[0];
          for (const fieldName in summaryObj) {
            this.summaryRow[fieldName] = '' + (null !== summaryObj[fieldName] && 'null' !== summaryObj[fieldName] ? summaryObj[fieldName] : '');
          }
        }
      }
    }
  }

  // This method will be called when there is a change in the dataProvider.
  protected loadRecords(records: any[]) {
    // Loading records in detail page datagrid / searchList
    try {
      if (records && records !== undefined) {
        this.togglePaginator = true;
        this.toggleShowTotal = true;
        if (records.length <= 0) {
          this.showDummy();
        } else {
          this.dataSource = new DataTableSource(records);
          this.dataSource.sort = this.sort;
          if (this.workRequest && this.workRequest.lastModified && this.workRequest.lastModified > 0) {
            this.length = this.workRequest.lastModified;
          } else {
           // if (this.length <= 0) { // If length is not set already
              this.length = records.length;
           //}
          }
          this.totalRecords = this.length;
          console.log('total no of records', this.totalRecords, records.length);
        }
        this.columnElements.notifyOnChanges();
      }
    } catch (e) {
      // Ignore
    }
  }

  // Setting the paginator properties. Override this method as needed.
  setPaginator(): void {
    if (this.paginator) {
      this.paginator.length = this.length;
      this.paginator.pageSize = this.pageSize;
      this.paginator.pageSizeOptions = [this.pageSize];
    }
  }

  // Setting length; this is used to show/hide the datatable itself. Override this method to change the behaviour.
  setLength(): void {
    this.length = this.workRequest.total;
  }

  // This will populate the datasource and load records into the table.
  setRecords(): void {
    try {
      this.dataSource = new DataTableSource(this.workRequest.collections['' + this.collectionTag].rows);
      this.dataSource.sort = this.sort;
    } catch (e) {
      // Ignore ??
    }
  }

  // Emit the workrequest itself if action is not save
  emitWorkRequest() {
    this.getWorkRequest.emit(this.workRequest);
  }

  inspectForError(): Boolean {
    let error: Boolean = false;
    if (this.workRequest.requestResult === ResponseBase.REQUEST_RESULT_ERROR) {
      this.errorId = this.workRequest.errorDetail;
      this.errorId = StringUtil.isEmpty(this.errorId)
        ? this.workRequest.messageId
        : this.errorId;
      this.globals.setErrorMessage(this.errorId);
      error = true;
    }
    return error;
  }

  getLastErrorId(): string {
    return this.errorId;
  }

  onInquiry(overWriteMsg: Boolean): void {
    let error: Boolean = false;
    error = this.inspectForError();
    if (error) {
      this.resetParametersInternal();
      this.globals.setErrorMessage(this.getLastErrorId());
    } else {
      if (this.length <= 0) {
        // No data found.
        this.resetParametersInternal();
        // this.globals.setStatusMessage('MSG14');
        if (overWriteMsg) {
          this.globals.setStatusMessage('MSG02');
        }
        this.showDummy();
      }
    }
  }

  onErrorGotRecords(error: Object): void {
    //  console.log('Could not fetch data from database (Exception DataTableComponent.load()): ' + JSON.stringify(error, null, 2));
    this.resetParametersInternal();
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
      super.onErrorGotRecords(error);
    }
  }

  onCompleteGotRecords(): void {
    // this.isLoadingResults = false;
    // this.loadingMessage = '';
    this.globals.hideLoadingBar();
    this.columnElements.notifyOnChanges();
    this.changeDetector.detectChanges();
  }

  private loadDataInternal(fresh: Boolean, overWriteMsg: Boolean = true): void {
    //  console.log('Setting criteria:(from parent form): ' + JSON.stringify(this.dataTableService.criteria, null, 2));
    // this.isLoadingResults = true;
    // this.loadingMessage = 'Loading';
    this.globals.showLoadingBar();
    this.dataTableService
      .loadData(fresh)
      .subscribe(
        x => this.onGotRecords(x, overWriteMsg),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }

  highlightRow(row, index): void {
    if (row) {
      this.rowToBeHighlighted = row;
      this.itemClick.emit(row);
    }
    this.selectedRowIndex = index > -1 ? index : -1;
  }
  onDblClick(row): void {
    if (row) {
      this.rowToBeHighlighted = row;
      this.itemDblclick.emit(row);
    }
  }

  newRow(): any {
    const newRecord = {};
    return newRecord;
  }
  navigateToPage(pageEvent: PageEvent): void {
    if (this.paginator) {
      this.pageIndexChanged.emit(pageEvent);
    }
  }

  resetParameters(): void {
    this.resetParametersInternal();
    this.clearStatusMessage();
    this.showDummy();
    this.onDatatableClear.emit();
  }

  private resetParametersInternal() {
    if (this.paginator) {
      this.paginator.pageIndex = 0;
    }
    this.length = 0;
    this.totalRecords = 0;
    this.workRequest = null;
    this.togglePaginator = false;
    this.toggleShowTotal = false;
    this.rowToBeHighlighted = null;
    // this.isLoadingResults = false;
    // this.loadingMessage = '';
    this.globals.hideLoadingBar();
    this.selectedRowIndex = -1;
  }

  clearStatusMessage(): void {
    this.globals.setStatusMessage('');
  }

  setOtherInputs(changes: SimpleChanges) {
    if (changes['action'] !== undefined && changes['action'] !== null) {
      this.action = changes['action'].currentValue;
      this.dataTableService.action = this.action;
    }

    if (changes['requestType'] !== undefined && changes['requestType'] !== null) {
      this.requestType = changes['requestType'].currentValue;
      this.dataTableService.requestType = this.requestType;
    }

    if (changes['collectionTag'] !== undefined && changes['collectionTag'] !== null ) {
      this.collectionTag = changes['collectionTag'].currentValue;
      this.dataTableService.collectionTag = this.collectionTag;
    }
  }

  private resetRequest(): void {
    if (this.workRequest) {
      this.workRequest.errorDetail = '';
      this.workRequest.messageId = '';
      this.workRequest.requestResult = ResponseBase.REQUEST_RESULT_SUCCESS;
    }
  }

  showDummy(): void {
    if (!this.showEmptyTable) {
      return;
    }
    const row = this.newRow();
    row.dbAction = 'dummy'; // No need to edit this row.
    const newRow = [].concat(row);
    this.dataSource = new DataTableSource(newRow);
    this.dataSource.sort = this.sort;
    this.length = newRow.length;
    this.totalRecords = 0;
  }

  clearFlags() {
    // this.isLoadingResults = false;
    // this.loadingMessage = '';
    this.globals.hideLoadingBar();
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
