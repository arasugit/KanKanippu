// $Id$
import { Component,OnInit, ViewChild, Injector, OnDestroy} from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { Params} from '@angular/router';
import { CommonConstants } from '../common/ist.common.constants';
import { BaseForm } from '../components/base-form';
import { QuerySectionComponent } from './querysection-component';
import { AbstractDataTableComponent } from './abstract-data-table.component';
import { merge } from 'rxjs';
import { last ,  map } from 'rxjs/operators';
import { DataTableEditableComponent } from './data-table-editable.component';
import { GlobalsService } from '../services';


@Component({
  selector:'base-list-component$',
  template:''
})
export class ListComponent extends BaseForm implements OnInit, OnDestroy {
  protected DETAIL_FORM_PATH: string;  // for navigation
  protected pageCtrl = 'ist_page_ctrl';  // default pageCtrl parameter name
  protected isNavigation: Boolean = false;
  protected permissionRetrived: Boolean = false;
  protected metaDataRetrived: Boolean = false;
  protected isRedirected: Boolean = false;
  protected showBackBtn: Boolean = false;
  url: string;
  displayProgressBar = false;
  displayMessage = '';
  constructor(injector: Injector) {
    super(injector);
    this.setSenstiveFields();
    this.clearErrorFlags();
    this.setT21Tags();
    this.getPermAndMetaData();
    DataTableEditableComponent.isTxnDetailScreen=false;
  }
  @ViewChild(AbstractDataTableComponent, { static: false })
  dataTableComponent: AbstractDataTableComponent;

  criteria = {};

  // Query section panel
  @ViewChild(QuerySectionComponent, { static: false })
  querySection: QuerySectionComponent;
  ngOnInit() {
   this.setFocusOnShow();
   this.updateLastRefreshTime();
   this.autoRefreshService.setCurrentComponent(this);
  }

  getEntPermList(): any[] {
    return [];
  }
  getPermAndMetaData(): void {
    this.globals.showLoadingBar();
    this.requestPerms.permsArr = this.getEntPermList();
    const getPermision = this.requestPerms.getPermission2(this.router.url).pipe(
      map(x => { this.permissionRetrived = x; }));
    const getMetaData = this.getMetaData2().pipe(map(y => { this.metaDataRetrived = y; this.globals.hideLoadingBar()}));
    merge(getPermision, getMetaData).pipe(last()).subscribe(
      result => this.hideProgress(), err => this.hideProgress());
  }

  // hide progress bar and set the focus to the first field
  hideProgress():void {
    this.setFocusToFirstField();
    this.globals.hideLoadingBar();
  }

  // Called when Clear button is clicked and clears all the search controls which has paramName attribute
  clear(): void {
    this.clearErrorFlags();
    this.querySection.clearFields();
    this.dataTableComponent.resetParameters();
    this.setFocusOnShow();
    // this.search();
  }

  // called to construct search criteria based on paramName
  doSearch(): void {
    // console.log('doSearch is called');
    this.action = 'query';
    this.criteria = {};
    this.setCriteria();
    this.adjustCriteria();
    this.encryptCriteria();
    this.criteria['COMMAND'] = this.action;
    this.criteria[this.pageCtrl] = '1';
    this.criteria['ist_total'] = 'y';
    this.dataTableComponent.requestType = this.requestTypeId; // required for navigation
    this.dataTableComponent.collectionTag = this.collectionId; // required for navigation
    this.dataTableComponent.isMKCRequest = false;

    this.dataTableComponent.load(this.criteria, true);


  }

  // this method is used to add extra parameters to the criteria before sending the request
  adjustCriteria(): void {
    return;
  }

  // this method is used to encrypt sensitive data criteria before sending the request
  encryptCriteria(): void {
    if (this.getSenstiveFields().length === 0) { return; }
    for (let i = 0; i < this.sensitiveFldList.length; i++) {
      if (this.criteria[this.sensitiveFldList[i]] !== undefined) {
        this.criteria[this.sensitiveFldList[i]] = this.globals.encryptData(this.criteria[this.sensitiveFldList[i]]);
      }
    }
    return;
  }

  // construct query criteria map based on paramName attribute
  setCriteria(): void {
    if (this.querySection !== undefined && this.querySection !== null) {
      this.querySection.setSearchCondition(this.criteria);
    }
  }

  // called for data table pagination
  more(pageEvent: PageEvent): void {
    //  console.log('more button clicked : ' + pageEvent.pageIndex + pageEvent.length + pageEvent.pageSize);
    this.criteria[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
    this.criteria['ist_total'] = 'n';
    this.dataTableComponent.load(this.criteria, false);
  }

  // called to perform any search field validation before constructing criteria map
  validateBeforeQuery(): boolean {
    return true;
  }

  // called when Search button is clicked
  search(): void {
    // console.log('search clicked from the basselist component');
    this.clearErrorMessage();
    if (this.validateBeforeQuery()) {
      this.clearErrorFlags();
      this.doSearch();
      this.autoRefreshService.setAutoRefreshSearchInterval(this);
    }
  }

  getCommand(selectedItem: any): string {
    if (selectedItem.mkcId !== undefined && selectedItem.mkcId > 0) {
      if ((this.insertPerm && this.insertPerm.allowed && selectedItem.mkcRecordAction === 'I')
        || (this.updatePerm && this.updatePerm.allowed && selectedItem.mkcRecordAction === 'U')) {
        return CommonConstants.MKC_ACTION_REWORK_EDIT;
      } else { return CommonConstants.ACTION_QUERY_DETAIL; }
    } else {
      if (this.updatePerm && this.updatePerm.allowed) { return CommonConstants.ACTION_UPDATE; } else { return CommonConstants.ACTION_QUERY_DETAIL; }
    }
  }

  onItemClick(selectedItem: any, command: any) {
    if (this.mkcPerm !== undefined && this.mkcPerm.allowed) {
      // console.log('mkcPerm enabled ', this.mkcPerm.allowed);
      if (selectedItem.mkcId > 0) {
        const mkcParam = {
          mkc_id: selectedItem.mkcId + '',
          mkc_record_action: selectedItem.mkcRecordAction,
          mkc_status: selectedItem.mkcStatus
        };
        command = Object.assign(command, mkcParam);
      }
    }
    command['COMMAND'] = this.getCommand(selectedItem);
    this.goToDetailForm(command);
  }

  // navigate to detail screen
  goToDetailForm(command: any) {
    if (this.loadNewFormWithDelay) {
      setTimeout(() => {
        // console.log('loading screen with delay');
        this.formNavigation.callForm(
          this.route.snapshot,
          this.DETAIL_FORM_PATH,
          command,
          this.breadcrumbText
        );
      }, 100);
    } else {
      // onsole.log(' loading detail form from base list ', new Date());
      this.formNavigation.callForm(
        this.route.snapshot,
        this.DETAIL_FORM_PATH,
        command,
        this.breadcrumbText
      );
    }
  }

  // called when add button is clicked
  add(): void {
    this.goToDetailForm({ COMMAND: 'insert' });
  }

  // To return the values to the list screen, you can add the values in the object and return
  // Refer Adjustments screens for more detail
  setAdditionalParamsToCntrl() {
    return;
  }

  // called while returning from the detail screen
  handleParams(m: Params) {
    this.params = this.formNavigation.retrieveFormParams(m);
    if (this.params) {
      if (this.params['COMMAND'] === 'return') {
        this.setAdditionalParamsToCntrl();
        if (this.params['changed'] !== undefined && !this.params['changed']) {   // false -- cancel clicked
             this.scrollToView();
        } else {
          if (Object.keys(this.criteria).length > 0) {
            this.refreshList();
          }
        }
      } else if (true === this.params['NAVIGATION'] || 'true' === this.params['NAVIGATION']) {
        if (this.params['mkc_id'] !== null && this.params['mkc_id'] !== undefined && this.params['mkc_id'] !== '' ) {
          this.isNavigation = true;
          this.mkcSearch(this.params['COMMAND']);
        } else {
        this.isNavigation = true;
        this.setQueryParameters(this.params);
        }
      } else if ('query' === this.params['COMMAND']) {  // this is used for navigation from detail to list
        this.isNavigation = true;
      }
    }
    this.returnToForm(); // if you want override anything at the form level, make use of this method
  }
  returnToForm(): void {
    return;
  }
  setQueryParameters(params: Params): void {
    return;
  }
  scrollToView(){
    if (this.dataTableComponent !== undefined) {
        this.dataTableComponent.scrollToSelectedRow();
    }
  }
  refreshList(): void {
    if (Object.keys(this.criteria).length > 0) {
      this.criteria['ist_total'] = 'y';
      const overWriteMsg = (this.dataTableComponent !== null && this.dataTableComponent.length <= 1) ? false : true;
      this.dataTableComponent.load(this.criteria, false, overWriteMsg);
    }
  }

  mkcSearch(reqType: string): void {
    this.criteria = {};
    if (reqType === 'rework') {
      this.action = CommonConstants.MKC_ACTION_REWORK_REQ;
    } else {
      this.action = CommonConstants.MKC_ACTION_PENDING_REQ;
    }
    this.criteria['COMMAND'] = this.action;
    this.criteria[this.pageCtrl] = '1';
    this.criteria['ist_total'] = 'y';
    this.dataTableComponent.requestType = this.requestTypeId; // required for navigation
    this.dataTableComponent.collectionTag = this.collectionId; // required for navigation
    this.dataTableComponent.isMKCRequest = true;
    this.dataTableComponent.load(this.criteria, true);
  }
  back() {
    this.returnToListModule(false);
  }
  returnToListModule(changed: boolean) {
    if(changed === false){ // it will clear the 'No data found' message when query screen to another query screen navigation
      this.globals.setErrorMessage('');
    }
    this.setSenstiveFields(); // to reset the fields
    this.formNavigation.returnFromForm(changed);
  }

  loadNewForm(command: any, path: string) {

    this.formNavigation.callForm(
      this.route.snapshot,
      path,
      command,
      this.breadcrumbText
    );
  }
  clearErrorFlags(): void {
   // this.firstFocusField = false;  // clear including
    this.clearErrorMessage();
  }
  setFocusOnShow(): void {
    this.setFocusToFirstField();
    this.clearErrorMessage();
  }

  retriveData():void{

  }

  setAutoRefreshInterval() {
    this.autoRefreshService.setAutoRefreshInterval(this);
  }

  clearAutoRefreshInterval() {
    this.autoRefreshService.clearAutoRefreshInterval();
  }

  setAutoRefreshSearch(autoRefreshSearch: boolean) {
    this.autoRefreshService.setAutoRefreshSearch(autoRefreshSearch);
  }

  setAutoRefreshRetriveDataInterval(seconds?: number) {
    this.autoRefreshService.setAutoRefreshRetriveDataInterval(this, seconds);
  }

  clearAutoRefreshRetriveDataInterval() {
    this.autoRefreshService.clearAutoRefreshRetriveDataInterval();
  }

  ngOnDestroy(): void {
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
  }
  updateLastRefreshTime() {
    this.autoRefreshService.updateLastRefreshTime();
  }
  redirectTopage(command: any, path: string) {

    this.formNavigation.redirectToPage(
      this.route.snapshot,
      path,
      command,
      this.breadcrumbText
    );
  }
  goBack() {
    this.globals.setErrorMessage('');
  }
}
