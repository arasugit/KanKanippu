// $Id$
import { AfterContentInit, Directive, ElementRef, EventEmitter, Input, OnInit, Output, Renderer2 } from '@angular/core';
import { UIMetaField } from '../common/vo/ui-metadata-model';
import { DataTableColumnComponent } from './data-table-column.component';
import { GlobalsService } from '../services';
import { DatePipe } from '@angular/common';


@Directive({
  selector: '[appEditCell]'
})
export class CellEditorDirective implements OnInit, AfterContentInit {
  @Input() column: DataTableColumnComponent;
  @Input() row: any;
  @Input() fields: UIMetaField;
  @Input() requestType: String;
  @Input() collectionTag: String;
  @Input() selectedvalue:any;
  @Output() collectionChanged = new EventEmitter<any>();
  formatDate = new DatePipe('en_US');
  value: object;
  header: string;
  editable: boolean;
  originalRow: object;
  editedValue: any;

  maxAllowedLen: number;

  constructor(private element: ElementRef, private renderer: Renderer2, private globals:GlobalsService) {}
  ngOnInit() {
    this.renderer.setStyle(this.element.nativeElement, 'border', 'none');
  }

  ngAfterContentInit() {
    //console.log('app cell edit entered for ' , this.column.dataField, this.column.header);
    this.originalRow = Object.assign(new Object(), this.row);
    this.value = this.row[this.column.dataField];
    this.header = this.column.header;
    this.editable = this.column.editable;
    this.renderer.setProperty(this.element.nativeElement, 'value', this.value);
    this.renderer.setProperty(this.element.nativeElement, 'title', this.getTitle(this.value));

    if (this.column.cntrlType === undefined || this.column.cntrlType === 'CBOX' || this.column.cntrlType === 'RTCNF1' || this.column.cntrlType === 'RTCNF2' ) {

    this.renderer.listen(this.element.nativeElement, 'change', (event) => {
      //console.log('text input app cell edit change event triggered for ' , this.column.dataField, this.column.header);
        // This is only for OAS Entitlement Control single page form
        if (this.row['fieldName'] === 'pan_mask_pattern' && this.column.dataField === 'fieldValue') {
          if (this.row[this.column.dataField] && this.row[this.column.dataField].length > this.maxAllowedLen) {
            this.row[this.column.dataField] = this.editedValue === undefined ? event.currentTarget.value : this.editedValue;
            event.preventDefault(); // May be this has no effect here !!!!
          }
        }
        if(this.column.dataField.includes('Date')){
          this.editedValue = this.formatDate.transform(this.row[this.column.dataField], this.globals.dateFormat)
        }
        else{
          this.editedValue = this.row[this.column.dataField];
        }
        this.renderer.setProperty(this.element.nativeElement, 'title', 'Original value: ' + this.getTitle(this.value) +
        'Current value: ' + this.editedValue);
        if (this.value === this.editedValue) {
          this.renderer.setProperty(this.element.nativeElement, 'title', this.getTitle(this.value));
        } else {
          const editedRow: any = {}; // TODO: define an interface EditedRow
          if ( this.column.dataField !== 'mkcRemarks' ) {
            this.row['dbAction'] = (this.row['dbAction'] === 'a' || this.row['dbAction'] === ''
            || this.row['dbAction'] === undefined || this.row['dbAction'] === null) ? 'a' : 'c';
          }
          editedRow.value = this.value;
          this.row[this.column.dataField] = this.editedValue;
          editedRow.originalRow = this.originalRow;
          editedRow.row = this.row;
          editedRow.column = this.column;
          editedRow.editedValue = this.editedValue;
          editedRow.requestType = this.requestType;
          editedRow.collectionTag = this.collectionTag;
          editedRow.itemEditorInstance = this.element.nativeElement;
          editedRow.renderer = this.renderer;
          this.collectionChanged.emit(editedRow);
          //console.log('collection changed emit editedValue', this.editedValue);
          //console.log('collection changed emit', editedRow);
          if (this.column.dataField !== 'mkcStatus') {
            if (this.row.hasOwnProperty('dbAction')) {
              if (this.row['dbAction'] !== 'd') {   // added by yuva for acq entity
                this.row['dbAction'] = (this.row['dbAction'] === 'a') ? 'a' : 'c';
               // console.log(' row is changed for combobox');
              }
            }
          }
        }
    });
  }
    // This is only for OAS Entitlement Control single page form
    if (this.row['fieldName'] === 'pan_mask_pattern' && this.column.dataField === 'fieldValue') {
     // console.log('key press event from cell edition ---> ', this.row['fieldname']);
      this.renderer.listen(this.element.nativeElement, 'keypress', (e) => {
        //  console.log('key pressed was: ', e);
        const val: String = this.row[this.column.dataField];
        let restrict = '0-6*';
        this.maxAllowedLen = 3;
        if (val) {
          if (val.length === 1 && val === '*') {
            restrict = '0-4';
          } else if (val.length === 1 && val !== '*') {
            restrict = '*';
            this.maxAllowedLen = 3;
          } else if (val.length === 2) {
            const firstChar: String = val.substr(0, 1);
            const secondChar: String = val.substr(1, 2);
            if (firstChar.match(/^\d+$/) && secondChar === '*') {
              restrict = '0-4';
              this.maxAllowedLen = 3;
            } else if (firstChar === '*' && secondChar.match(/^\d+$/)) {
              restrict = '0-4';
              this.maxAllowedLen = 2;
            } else {
              e.preventDefault();
            }
          }
        }
        if (this.checkPattern(restrict, e)) {
          e.preventDefault();
        }
        //  console.log('PAN mask pattern: ', restrict, 'for PAN: ', val, 'for length: ', this.maxAllowedLen);
      });
    }
    // The following not used now; but may be useful in future.
    // this.renderer.listen(this.element.nativeElement, 'focus', (event) => {
    //   this.renderer.setStyle(this.element.nativeElement, 'border', '1px solid');
    // });

    // this.renderer.listen(this.element.nativeElement, 'blur', (event) => {
    //   this.renderer.setStyle(this.element.nativeElement, 'border', 'none');
    // });

    if (this.fields) {
        const tag = this.column.tag;
        if (tag) {
          const tagMetaData = this.fields[tag];
          if (tagMetaData) {
            const editType = tagMetaData['editType'];
            // for each type set the alignment
            if (editType) {
              if (editType === 'NUMBER') {
                // Align the content to the right
                // this.element.nativeElement.getElementsByTagName('input')[0].style
                // if (this.element.nativeElement.getElementsByTagName('input')) {
                //  if (this.element.nativeElement.getElementsByTagName('input')[0]) {
                //    this.renderer.setStyle(this.element.nativeElement.getElementsByTagName('input')[0], 'text-align', 'right');
                //  }
              //  }
              }
            }
          }
        }
    }

  }

  private checkPattern(restrict: String, event: KeyboardEvent): Boolean {
    const patternStr = '^[' + restrict + ']*$';
    const pattern = new RegExp(patternStr);

    const inputChar = String.fromCharCode(event.keyCode);
    //  console.log('(CellEditorDirective) keypress event is called inputChar', inputChar, ' - ', patternStr);

    return (event.keyCode !== 8 && !pattern.test(inputChar));
  }

  private getTitle(value: any): String {
    if (value !== null && value !== undefined) {
      return value;
    }
    return '';
  }
}
