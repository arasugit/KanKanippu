// $Id$
import { Component, EventEmitter, forwardRef, Input, Output, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { T21Base } from './t21-base';
import { WorkField, WorkRequest } from '../ist-components/work-request-model';
const noop = () => { };

export const CUSTOM_SELECT_VALUE_ACCESSOR_RG: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => IstRadioGroupComponent),
    multi: true
};

export const T21BASE_ACCESSOR_RG: any = {
    provide: T21Base,
    useExisting: forwardRef(() => IstRadioGroupComponent),
    multi: true
};

@Component(
    {
        selector: 'ist-radio-group',
        templateUrl: './ist-radiogroup-template.html',
        changeDetection: ChangeDetectionStrategy.OnPush,
        providers: [CUSTOM_SELECT_VALUE_ACCESSOR_RG, T21BASE_ACCESSOR_RG]
    }
)
export class IstRadioGroupComponent extends T21Base implements ControlValueAccessor {
    constructor(private ref: ChangeDetectorRef) {
        super();
        this.componentType = 'IstRadioGroupComponent';
        this.alignControl = '';
        this.mandatorySymbol = '';
        this.requiredColon = ' : ';
    }
    private _requestProvider: WorkRequest;
    private _workField: WorkField;
    @Output() onChange = new EventEmitter();
    @Input() optionsList: [any] = [{ label: 'Winter', value: 'W' }];
    @Input() alignControl: string;
     _selectedValue = '';
    get selectedValue() {
        //  console.log ('get selectedValue called from RADIOBUTTON ', this._selectedValue, this.tag);
        return this._selectedValue;
    }
    @Input()
    set selectedValue(v: any) {
        if (v !== this._selectedValue) {
            this._selectedValue = v;
            if (this._requestProvider != null && this._requestProvider.fields[this.tag] != null) {
                this._requestProvider.fields[this.tag].value = this._selectedValue;
                //  console.log('after update ', this._requestProvider.fields[this.tag].value);
            }
            this.ref.markForCheck();
            this.onChangeCallback(v);
            this.onChange.emit(this.selectedValue);
        }
    }

    @Input() set requestProvider(value: WorkRequest) {
        this._requestProvider = value;
        if (this.tag != null && this._requestProvider != null && this._requestProvider.fields[this.tag] != null) {
            this.setWorkField(this._requestProvider.fields[this.tag]);
        }
    }
    get requestProvider(): WorkRequest {
        return this._requestProvider;
    }

    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;
    setWorkField(value: WorkField) {
        // //  console.log("textinput set workField");
        this._workField = value;
        if (this._workField != null) {
            this._selectedValue = this._workField.value;
            if (this._workField.modifyable === 'N') {
                this.isDisabled = true;
            }
            if (this._workField.style !== undefined && this._workField.style === 'mkcStyle') {
                this.isMkcChange = true;
             } else { this.isMkcChange = false ;
                this._workField.oldValue = this._workField.value; // old value copied here for comparison
            }
             this.ref.markForCheck();
            this.onChangeCallback(this._selectedValue);
            this.onChange.emit(this.selectedValue);
        }
    }
    writeValue(value: any) {
       // console.log('radio button write value', this.tag, event);
        this.selectedValue = value;
    }

    onBlur() {
        this.onTouchedCallback();
    }
    registerOnChange(fn: any) {
        this.onChangeCallback = fn;
    }
    registerOnTouched(fn: any) {
        this.onTouchedCallback = fn;
    }
    emit(event) {
        // console.log('radio button emit called', this.tag, event);
        this.selectedValue = event.value;
        this.ref.markForCheck();
    }
    getValue() {
        return this._selectedValue;
    }
    clearValue() {
    
    }
    trackByList (index, item) {
        return item.value;
    }
}
