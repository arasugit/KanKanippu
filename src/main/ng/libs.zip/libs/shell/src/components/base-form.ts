import { Component,ViewChild, Injector } from '@angular/core';
import { CustomFormatter } from '../common/ist-formatter';
import { CommonConstants } from '../common/ist.common.constants';
import { LabelsAndValues } from '../common/labels-and-values';
import { UIMetadata } from '../common/vo/ui-metadata-model';
import { DataTableColumnComponent } from './data-table-column.component';
import { GlobalsService } from '../services/globals.service';
import { T21Base } from './t21-base';
import { Observable} from 'rxjs';
import { map , tap } from 'rxjs/operators';
import { InstService } from '../services/inst.service';
import { FormNavigationService } from '../services/form-navigation.service';
import { RequestedPermissions } from '../permission/requested.permissions';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog} from '@angular/material/dialog';
import { BizService } from '../services/biz.service';
import { FormBusinessService } from '../services/formbusiness.service';
import { MessageService } from '../services/message.event.services';
import { MenuService } from '../services/menu.service';
import { AutoRefreshService } from '../services';


@Component({
  selector:'base-form$',
  template:''

})
export class BaseForm {
  public FORM_TITLE: string;
  public requestTypeId: string;  // current screen requestType Id
  public metaDataId: string;
  public tabId: string;
  public sectionId: string;
  public collectionId: string;
  public metaDataProvider: UIMetadata;
  public EXPAND_STRING: string = CommonConstants.EXPAND_STRING;
  public COLLAPSE_STRING: string = CommonConstants.COLLAPSE_STRING;
  public NEWLINE_CHAR: string = CommonConstants.NEWLINE_CHAR;
  public entObjectId;
  public queryPerm;
  public insertPerm;
  public updatePerm;
  public deletePerm;
  public mkcPerm;
  public checkerPerm;
  public action: string;  // current action
  public params = {};
  public errorMsg: String;
  public loadNewFormWithDelay: Boolean;
  public sensitiveFldList: string[] = [];
  public globals: GlobalsService;
  public instService: InstService;
  public formNavigation: FormNavigationService;
  public route: ActivatedRoute;
  public router: Router;
  public requestPerms: RequestedPermissions;
  public dialog: MatDialog;
  public bizService: BizService;
  public mformService: FormBusinessService;
  public msgService: MessageService;
  public menuService: MenuService;
  public autoRefreshService: AutoRefreshService;
  public isMedataReady:boolean = false;
  public isCurrentRequestReady:boolean = false;  // indicate whether currentrequest received or not
  public metadataTimeout = 10000;  // default timeout
  public exportFileName: string;
  constructor(injector: Injector) {
    this.globals = injector.get(GlobalsService);
    this.instService = injector.get(InstService);
    this.formNavigation = injector.get(FormNavigationService);
    this.route = injector.get(ActivatedRoute);
    this.router = injector.get(Router);
    this.requestPerms = injector.get(RequestedPermissions);
    this.dialog = injector.get(MatDialog);
    this.bizService = injector.get(BizService);
    this.mformService = injector.get(FormBusinessService);
    this.msgService = injector.get(MessageService);
    this.menuService = injector.get(MenuService);
    this.autoRefreshService = injector.get(AutoRefreshService);
    this.loadNewFormWithDelay = false;
    this.FORM_TITLE = 'form title';
    this.isMedataReady = false;
    this.isCurrentRequestReady = false;
  }
  @ViewChild('firstFocusField', { static: false })
  firstFocusField: T21Base;
  @ViewChild('firstUpdateField', { static: false })
  firstUpdateField: T21Base;
  @ViewChild('toDateFocusField', { static: false })
  toDateFocusField: T21Base;

  protected get breadcrumbText() { 
    return this.FORM_TITLE;
  }

  setT21Tags(): void {
    this.requestTypeId = '';
    this.metaDataId = '';
    this.tabId = '';
    this.sectionId = '';
    this.collectionId = '';
  }

  setSenstiveFields(): void {
    this.sensitiveFldList = [];
  }
  getSenstiveFields(): string[] {  
    return this.sensitiveFldList;
  }

  // used for LabelFunction
  displayLabelDescription = (item: any, dataField: string, dataProvider: LabelsAndValues) => {
    const val = (item && item[dataField]) ? item[dataField] + '' : '';
    const label = dataProvider.mapValueToLabel(val) || val || '';
    return label;
  }
  updateMetaData(event) {
    this.metaDataProvider = event;
  }

  formatAmount = (item: any, column: DataTableColumnComponent) => {
    const value = item[column.name];
    if (value !== null && value !== undefined) {
      return CustomFormatter.formatAmount(value);
    } else {
      return '';
    }
  }
  formatDateString = (item: any, column: DataTableColumnComponent) => {
    let value = item[column.name];
    if (value !== null && value !== undefined) {
      value = CustomFormatter.formatDateString(value, this.globals.dateFormat);
    } else {
      return '';
    }
    return value;
  }

  formatHHMMSS = (item: any, column: DataTableColumnComponent) => {
    let value = item[column.name];
    if (value !== null && value !== undefined) {
      value = CustomFormatter.formatHHMMSS(value);
    } else {
      return '';
    }
    return value;
  }

  decryptData = (item: any, column: DataTableColumnComponent) => {
    let value = item[column.name];
    if (value !== null && value !== undefined) {
      value = this.globals.decryptData(value);
    } else {
      return '';
    }
    return value;
  }

  clearErrorMessage(): void {
    this.errorMsg = '';
    this.globals.setErrorMessage('');
  }

  getMetaData(showProgress: boolean) {
    this.globals.getMetaData(this.metaDataId, showProgress).subscribe(
      (result: UIMetadata) => { this.metaDataProvider = result;
        if (this.isCurrentRequestReady === false)
           this.metadataTimeout = 10;
        setTimeout(() => {
          this.isMedataReady = true;
          this.metaDataProvider = result;
          this.emitModuleReady();
           }, this.metadataTimeout);  // 10000 is added for testing, while check in reduce it

       console.log(' getMetaData:: base form received metadata ', new Date());
       // console.log(' base form receied metadata ', new Date());
    }
    );
  }

  getMetaData2(): Observable<boolean> {
    let response = false;
    return this.globals.getMetaData2(this.metaDataId).pipe(
        tap(
          (result: UIMetadata) => {this.metaDataProvider = result; response = true;  },
          err => { this.onGotErrorMetaData(err); response = false;  }
        ),
        map(() => { this.emitModuleReady(); return response; })
      );
  }
  onGotErrorMetaData(error: Object): void {
    //  console.log('Failed to get the meta data:-', JSON.stringify(error, null, 2));
  }

setFocusToFirstField() {
  if (this.firstFocusField !== undefined) {
    this.firstFocusField.setFocus();
  }
}
setFocusToFirstUpdateField() {
  if (this.firstUpdateField !== undefined) {
      this.firstUpdateField.setFocus();
  }
}
emitModuleReady() {}
getModuleName() { return ''; }
}
