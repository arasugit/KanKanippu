import { Component, ContentChildren, QueryList } from '@angular/core';
import { Params } from '@angular/router';
import { T21Base } from '../components/t21-base';

@Component( {
        selector: 'ist-querysection',
        templateUrl: './querysection-template.html',
    }
)
export class QuerySectionComponent  {
constructor() {
    }

@ContentChildren (T21Base, {descendants: true}) inputChildren: QueryList<any>;

clearFields(): void {
    this.inputChildren.forEach(childControl => {
         //  console.log('querysection clearFeilds clearing fields');
         childControl.clearValue(); }
        );
}
setQueryParameters(params: Params, criteria: {}) {
  if (this.inputChildren === undefined  || this.inputChildren === null ) {
    // do nothing;
  } else {
   this.inputChildren.forEach(childControl => {
    const comp: any = childControl;
    if (comp  !== undefined) {
      // console.log ('before construction parameter', comp.paramName , 'value :', params[comp.paramName]);
          if (comp.wildCardAllowed) {
              let str: string = params[comp.paramName];
              str = str.replace(/\*/g, '%');
              criteria[comp.paramName] = str;
            } else {
              let compvalue: String = '';
                 if ( params[comp.paramName] === undefined  ||  params[comp.paramName] === null ) {
                  compvalue = '';
                  } else {
                compvalue = params[comp.paramName];
                 }
                 //  console.log ('parameter', comp.paramName , 'value :', compvalue);
                 criteria[comp.paramName] = compvalue;
              }
        }
          }
     );
    }

}
setSearchCondition(criteria: {}): void {
    // console.log ('querysection setSearchCondition is called');
    if (this.inputChildren === undefined  || this.inputChildren === null ) {
      // do nothing;
    } else {
     this.inputChildren.forEach(childControl => {
      const comp: any = childControl;
      if (comp  !== undefined) {
        // console.log ('before construction parameter', comp.paramName , 'value :', comp.getValue());
            if (comp.wildCardAllowed) {
                let str: string = comp.getValue();
                str = str.replace(/\*/g, '%');
                criteria[comp.paramName] = str;
              } else {
                let compvalue: String = '';
                   if ( comp.getValue() === undefined  ||  comp.getValue() === null ) {
                    compvalue = '';
                    } else {
                  compvalue = comp.getValue();
                   }
                   //  console.log ('parameter', comp.paramName , 'value :', compvalue);
                   criteria[comp.paramName] = compvalue;
                }
          }
            }
       );
      }
    }
}

