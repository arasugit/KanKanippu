import {Component , Input } from '@angular/core';
import { IstInputComponent } from './ist-input-component';


@Component({
  selector: 'ist-searchfield',
  templateUrl: './ist-input-template.html'
})
export class IstSearchInputComponent extends IstInputComponent {}
