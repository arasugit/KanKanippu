import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { CommonConstants } from '../common/ist.common.constants';
import { GlobalsService } from '../services/globals.service';

@Component(
    {
        selector: 'ist-button',
        templateUrl: 'ist-button-template.html',
    }
)
export class IstButtonComponent implements OnInit, OnChanges  {
constructor(public globals: GlobalsService) {}

private _buttonType: string;
private _permission: boolean;
private _action: string;
private _userId: string;
private _mkcData: object;
private checkerRole: boolean;
private isMKCRecord: boolean;
private makerRole: boolean;
private makerId: string;
@Input() visible: boolean;

@Output() btnClick = new EventEmitter();

@Input() btnLabel: string;
@Input() isDisabled: Boolean = false;

ngOnInit() {
    if (this.visible === undefined) {
        this.visible = true;
    }
    this.initializeFlags();
}
ngOnChanges(changes: SimpleChanges): void {
    if (changes['action'] !== undefined && changes['action'] !== null) {
        this.isDisabled = !this._permission; // check the permission first
        this.action = changes['action'].currentValue;
    }
}
@Input()
set mkcData(value: object) {
    this._mkcData = value;
    this.initializeFlags();
    if (this._mkcData['mkcId'] !== undefined && this._mkcData['mkcId'] > 0) {
        this.isMKCRecord = true;
        this.setCheckerRole();
    }
    this.conditionalDisable();
}
get mkcData (): object {
 return this._mkcData;
}

@Input()
set action(value: string) {
   this._action = value;
   this.conditionalDisable();
}
get action(): string {
  return this._action;
}

@Input()
set buttonType(value: string) {
 this._buttonType = value;
 switch (value)  {
     case 'add': this.btnLabel = 'Add'; this.visible = true; break;
     case 'search': this.btnLabel = 'Search'; this.visible = true; break;
     case 'clear': this.btnLabel = 'Clear'; this.visible = true; break;
     case 'cancel': this.btnLabel = 'Cancel'; this.visible = true; break;
     case 'goback': this.btnLabel = 'Go back'; this.visible = true; break;
     case 'delete': { this.btnLabel = 'Delete'; this.visible = true;
                this.conditionalDisable();  break;
    }
    case 'clone': this.btnLabel = 'Clone'; this.conditionalDisable(); break;
    case 'save': this.btnLabel = 'Save'; this.visible = true; break;
     case 'mkcRework': this.btnLabel = 'Rework Requests'; this.conditionalDisable(); break;
     case 'mkcSubmit': this.btnLabel = 'Submitted Requests'; this.conditionalDisable(); break;
     case 'mkcApprove': this.btnLabel = 'Approve'; this.conditionalDisable(); break;
     case 'mkcReject': this.btnLabel = 'Reject'; this.conditionalDisable(); break;
     case 'mkcReworkReturn': this.btnLabel = 'Rework'; this.conditionalDisable(); break;
     case 'mkcRemarks': this.btnLabel = 'View Remarks'; this.conditionalDisable(); break;
     case 'navigation': this.visible = true; this.conditionalDisable(); break;
     default: this.visible = true;
 }
}
get buttonType(): string {
    return this._buttonType;
}

@Input()
set permission (value: boolean) {
  this._permission = value;
  this.isDisabled = !this._permission;
  if (this._buttonType === 'mkcApprove' || this._buttonType === 'mkcReject' || this._buttonType === 'mkcReworkReturn'
|| this._buttonType === 'mkcRemarks') {
    this.setCheckerRole();
  }
  this.conditionalDisable();
}

get permission(): boolean {
    return this._permission;
}
@Input()
setAction(value: string) {
this._action = value;
}
getAction(): string {
    return this._action;
}
@Input()
setUserId(value: string) {
    this._userId = value;
}
getUserId(): string {
 return this._userId;
}

setCheckerRole() {
    if (this._mkcData['mkcId'] !== undefined && this._mkcData['mkcId'] > 0) {
        if ( (this._mkcData['makerId'] !== undefined && this._mkcData['makerId'] !== this.globals.userContext.userID)
         && (this._mkcData['mkcStatus'] !== undefined && this._mkcData['mkcStatus'] === 'S') ) {
             if (this._permission !== undefined && this._permission) {
             this.checkerRole = true;
             }
    }
    this.makerRole = !this.checkerRole;
}
}

conditionalDisable(): void {
    switch (this._buttonType) {
        case 'delete' : {
              if (this._action === CommonConstants.ACTION_INSERT  ||
                this._action === CommonConstants.MKC_ACTION_REWORK_EDIT || this.isMKCRecord ) { this.isDisabled = true; }
              } break;
        case 'save' : {
           if (this._mkcData !== undefined && this._mkcData['mkcStatus'] === CommonConstants.MKC_STATUS_SUBMIT && this.makerRole) {
               this.isDisabled = true;
           }
        } break;
        case 'clone' : {
            if (!this.isMKCRecord &&
                (this._action === CommonConstants.ACTION_UPDATE || this._action === CommonConstants.ACTION_QUERY_DETAIL)) {
                this.isDisabled = !this._permission;
            } else {
                this.isDisabled = true;
            }
        } break;
        case 'navigation' :
        if (this._action === CommonConstants.ACTION_INSERT || this._action === CommonConstants.MKC_ACTION_REWORK_EDIT || this.checkerRole) {
            this.isDisabled = true; }
              break;
        case 'mkcRemarks':  { if (this.isMKCRecord) { this.visible = true; this.isDisabled = false;
                               } else { this.visible = false; }
            } break;
        case 'mkcRework':
        case 'mkcSubmit': {
                if ( this._permission !== undefined && this._permission) { this.visible = true; } else { this.visible = false; }
            }  break;
        case 'mkcApprove': {
            if (this._permission !== undefined && this._permission && this.checkerRole ) {
                this.visible = true;
            } else { this.visible = false; }
        }
        break;
        case 'mkcReject': {
            if (this._permission !== undefined && this._permission && this.checkerRole) {
                this.visible = true;
            } else { this.visible = false; }
        }
        break;
        case 'mkcReworkReturn':
            {
                if (this._permission !== undefined && this._permission && this.checkerRole &&
                    (this._action === CommonConstants.MKC_ACTION_REWORK_EDIT)) {
                    this.visible = true;
                } else { this.visible = false; }
            }
         break;
    }
}

initializeFlags(): void {
    this.checkerRole = false;
    this.makerRole = false;
    this.isMKCRecord = false;
}

onBtnClick(event: Event) {
    if (this.isDisabled) {
        event.stopPropagation();
    // this.click.next(this._buttonType);
        return;
    } else {
    this.btnClick.emit();
    }
}
}
