import { DataTableColumnComponent, RendererItem } from "./data-table-column.component";

export class ColumnOnDemand {
    editable: Boolean = false;
    header: string;
    name: string;
    dataField: string;
    tag: string;
    editType: string;
    renderer: RendererItem;
    expression: (item: any, column: DataTableColumnComponent) => any;
    visible: Boolean = true;
    dataProvider: any;
  }