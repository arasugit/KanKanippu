export * from './tranlog.module';
export * from './tranlog.component';