
import { Params } from '@angular/router';
import { StringUtil } from '../common/ist-string-util';
import { DataTableColumnComponent } from '../components/data-table-column.component';
import { merge } from 'rxjs';
import { last, map } from 'rxjs/operators';
import { CustomFormatter } from '../common/ist-formatter';
import { Component, Injector, OnInit } from '@angular/core';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { LabelsAndValues } from '../common/labels-and-values';
import { StringMap } from '../common';

@Component({
    selector: 'app-tran-log',
    templateUrl: 'tranlog.component.html',
    styleUrls: ['./tranlog.component.scss'],
  })
export class TranLogComponent extends ListComponent
  implements OnInit {
  constructor(injector: Injector) {
    super(injector);
    this.DETAIL_FORM_PATH = '/forms/TRANLOGDET';
  }
  FORM_TITLE = 'Transaction Log';
  exportFileName = 'Transaction Log';

  shcRcResponseCodeList: LabelsAndValues = new LabelsAndValues();
  shcResponseMessageTypeList: LabelsAndValues = new LabelsAndValues();
  siteIdList: LabelsAndValues = new LabelsAndValues();
  issuingList :any[] = [];
  acquiringList :any[] = [];
  dbParam: StringMap = {};
  commandToExecute  = '';

  optionsList = [
    { label: 'Tran source', value: 'S' },
    { label: 'Tran destination', value: 'D' },
    { label: 'Both', value: 'B' }
  ];

  isDualSite = false;
  ist_inst_Id = '';
  ist_search_by = 'S';
  ist_term_id = '';
  ist_pan = '';
  ist_local_date = '';
  ist_local_date_to = '';
  ist_trace = '';
  ist_authnum = '';
  ist_refnum = '';
  ist_processor_busday = '';
  ist_processor_busday_to = '';
  ist_settlement_date = '';
  ist_settlement_date_to = '';
  ist_trans_date = '';
  ist_trans_date_to = '';
  ist_cap_date = '';
  ist_acquirer = '';
  expandEsc = false;
  issuerList = '';
  acquirerList = '';
  ist_pcode = '';

  ngOnInit() {
    super.ngOnInit();
    this.dbParam['type'] = 'MonGlbValListQuery';
    this.dbParam['insertCommand'] = this.commandToExecute;
    this.dbParam['user'] = this.globals.userContext.userID;

    const getSiteIdList = this.instService.getDBRecords('SITE_ID_COMBO').pipe(
      map(x => {
        this.siteIdList = x;
      })
    );
    const getShcRcResponseCodeList = this.instService
      .getGlobalValueCtrlList('shc_rc_respcode')
      .pipe(
        map(y => {
          this.shcRcResponseCodeList = y;
        })
      );
    const getShcResponseMessageTypeList = this.instService
      .getGlobalValueCtrlList('shclog_resp_msgtype')
      .pipe(
        map(y => {
          this.shcResponseMessageTypeList = y;
        })
      );
    const getSearchByList = this.instService
      .getGlobalValueCtrlList('shc_search_by')
      .pipe(
        map((y: LabelsAndValues) => {
          if (y !== undefined && y.array.length > 0) {
            this.ist_search_by = y.array[0].value;
          }
        })
      );
    merge(
      getSiteIdList,
      getShcRcResponseCodeList,
      getShcResponseMessageTypeList,
      getSearchByList
    )
      .pipe(last())
      .subscribe();
    this.route.params.subscribe((m: Params) => {
      this.handleParams(m);
    });
    this.isDualSite = this.globals.isDualSite;
  }
  getEntPermList(): any[] {
    this.entObjectId = 'TransLog';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    return new Array(this.queryPerm);
  }
  setT21Tags(): void {
    this.requestTypeId = 'TRANLOGQR';
    this.metaDataId = 'TRANLOGQR';
    this.tabId = 'TRANSLOGTAB';
    this.sectionId = 'TRANSLOGSEC';
    this.collectionId = 'TRANSLOGCOL';
  }

  setSenstiveFields(): void {
    this.sensitiveFldList.push('ist_pan');
  }

  onItemClick(selectedItem: any) {
    this.goToDetailForm({
      COMMAND: 'detail',
      ist_inst_Id: selectedItem.txnsrc,
      ist_txndest: selectedItem.txndest,
      ist_pan: this.globals.encryptData(selectedItem.pan),
      ist_msgtype: selectedItem.msgtype,
      ist_pcode: selectedItem.pcode,
      ist_trace: selectedItem.trace,
      ist_authnum: selectedItem.authnum,
      ist_refnum: selectedItem.refnum,
      ist_respcode: selectedItem.respcode,
      ist_chipIndex: selectedItem.chipIndex,
      ist_site_id: selectedItem.siteId + ''
    });
  }

  validateBeforeQuery(): boolean {
    if (StringUtil.isEmpty(this.ist_inst_Id)) {
      this.globals.setErrorMessage('ERR01');
      this.firstFocusField.setFocus();
      return false;
    }
    this.ist_local_date = this.ist_local_date? this.ist_local_date + ''
      : this.ist_local_date;
    this.ist_local_date_to = this.ist_local_date_to? this.ist_local_date_to + ''
      : this.ist_local_date_to;
    this.ist_settlement_date = this.ist_settlement_date? this.ist_settlement_date + ''
      : this.ist_settlement_date;
    this.ist_settlement_date_to = this.ist_settlement_date_to? this.ist_settlement_date_to + ''
      : this.ist_settlement_date_to;
    this.ist_processor_busday = this.ist_processor_busday? this.ist_processor_busday + ''
      : this.ist_processor_busday;
    this.ist_processor_busday_to = this.ist_processor_busday_to? this.ist_processor_busday_to + ''
      : this.ist_processor_busday_to;
    this.ist_trans_date = this.ist_trans_date? this.ist_trans_date + ''
      : this.ist_trans_date;
    this.ist_trans_date_to = this.ist_trans_date_to? this.ist_trans_date_to + ''
      : this.ist_trans_date_to;
    this.ist_cap_date = this.ist_cap_date? this.ist_cap_date + ''
      : this.ist_cap_date;
    if (
      StringUtil.isEmpty(this.ist_local_date) &&
      StringUtil.isEmpty(this.ist_local_date_to) &&
      StringUtil.isEmpty(this.ist_pan) &&
      StringUtil.isEmpty(this.ist_trace) &&
      StringUtil.isEmpty(this.ist_term_id) &&
      StringUtil.isEmpty(this.ist_refnum) &&
      StringUtil.isEmpty(this.ist_acquirer) &&
      StringUtil.isEmpty(this.ist_pcode)
    ) {
      this.globals.setErrorMessage(
        'At least one of the following must be selected; Local date, Card number, Trace, Acquirer, Account type, Reference #, Terminal ID'
      );
      return false;
    }

    // Below validations to be added later
    if (StringUtil.isNotEmpty(this.ist_local_date) &&
      StringUtil.isEmpty(
        CustomFormatter.serverFormatDate(this.ist_local_date, this.globals.dateFormat)
      )
    ) {
      this.globals.setErrorMessage('ER112');
      return false;
    }

    if (
      StringUtil.isNotEmpty(this.ist_local_date_to) &&
      StringUtil.isEmpty(
        CustomFormatter.serverFormatDate(this.ist_local_date_to, this.globals.dateFormat)
      )
    ) {
      this.globals.setErrorMessage('ER112');
      return false;
    }

    if (
      StringUtil.isNotEmpty(this.ist_settlement_date) &&
      StringUtil.isEmpty(
        CustomFormatter.serverFormatDate(this.ist_settlement_date, this.globals.dateFormat)
      )
    ) {
      this.globals.setErrorMessage('ER112');
      return false;
    }
    if (
      StringUtil.isNotEmpty(this.ist_settlement_date_to) &&
      StringUtil.isEmpty(
        CustomFormatter.serverFormatDate(this.ist_settlement_date_to, this.globals.dateFormat)
      )
    ) {
      this.globals.setErrorMessage('ER112');
      return false;
    }
    if (
      StringUtil.isNotEmpty(this.ist_processor_busday) &&
      StringUtil.isEmpty(
        CustomFormatter.serverFormatDate(this.ist_processor_busday, this.globals.dateFormat)
      )
    ) {
      this.globals.setErrorMessage('ER112');
      return false;
    }
    if (
      StringUtil.isNotEmpty(this.ist_processor_busday_to) &&
      StringUtil.isEmpty(
        CustomFormatter.serverFormatDate(this.ist_processor_busday_to, this.globals.dateFormat)
      )
    ) {
      this.globals.setErrorMessage('ER112');
      return false;
    }
    if (
      StringUtil.isNotEmpty(this.ist_trans_date) &&
      StringUtil.isEmpty(
        CustomFormatter.serverFormatDate(this.ist_trans_date, this.globals.dateFormat)
      )
    ) {
      this.globals.setErrorMessage('ER112');
      return false;
    }
    if (
      StringUtil.isNotEmpty(this.ist_trans_date_to) &&
      StringUtil.isEmpty(
        CustomFormatter.serverFormatDate(this.ist_trans_date_to, this.globals.dateFormat)
      )
    ) {
      this.globals.setErrorMessage('ER112');
      return false;
    }
    if (
      StringUtil.isNotEmpty(this.ist_cap_date) &&
      StringUtil.isEmpty(
        CustomFormatter.serverFormatDate(this.ist_cap_date, this.globals.dateFormat)
      )
    ) {
      this.globals.setErrorMessage('ER112');
      return false;
    }
    return true;
  }

  displaySiteId = (item: any, column: DataTableColumnComponent) => {
    return this.displayLabelDescription(
      item,
      column.dataField,
      this.siteIdList
    );
  }

  displayShcRcResponseCode = (item: any, column: DataTableColumnComponent) => {
    return this.displayLabelDescription(
      item,
      column.dataField,
      this.shcRcResponseCodeList
    );
  }

  displayShcResponseMessageType = (
    item: any,
    column: DataTableColumnComponent
  ) => {
    const val = item[column.dataField];
    return this.displayLabelDescription(
      item,
      column.dataField,
      this.shcResponseMessageTypeList
    );
  }
  getModuleName() { return 'IST-SHC'; }
  emitModuleReady() { this.msgService.sendMessage(this.getModuleName() ); }
}
