import { NgModule,NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TranLogComponent } from './tranlog.component';
import { RufCardModule } from '@ruf/shell';



export const tranLogData: MonitorComponentData = {
  title: 'Incident Monitoring',
  icon: 'home',
  examples: {
      'TRANLOG': {
          label: 'Transaction Log',
          title: 'Transaction Log',
          description: 'Transaction Log',
          rufId: 'TRANLOG',
          component: TranLogComponent
      }
  }
};

@NgModule({
    imports :[
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    RufCardModule,
    ISTComponentModule
  ],
  declarations: [TranLogComponent],
  exports:[TranLogComponent],
  providers: [{ provide: MON_TOOL, useValue: tranLogData }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]

})
export class TranLogModule {}
