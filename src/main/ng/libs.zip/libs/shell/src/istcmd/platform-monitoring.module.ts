import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { FiSysUsageComponent } from './fisys-usage.component';
import { SyCPUUsageComponent } from './sycpu-usage.component';
import { SyCPUUsage2Component } from './sycpu-usage2.component';
import { IpcDetailsComponent } from './ipc-details.component';
import { TranslateModule } from '@ngx-translate/core';
import { MatLegacyProgressBarModule as MatProgressBarModule } from '@angular/material/legacy-progress-bar'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { PlatformDashboardComponent } from './dashboard/platform-dashboard.component';
import { RufCardModule } from '@ruf/shell';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HighchartsChartModule } from 'highcharts-angular';

export const platformMonitoringData: MonitorComponentData = {
  title: 'Switch Task Command',
  icon: 'home',
  examples: {
    'PLTFDASH': {
      label: 'Overall Platform Status',
      title: 'Overall Platform Status',
      description: 'Overall Platform Status',
      rufId: 'mon_platform_dashboard',
      component: PlatformDashboardComponent
    },
    'FISYUSAGE': {
      label: 'IST File System Usage',
      title: 'IST File System Usage',
      description: 'IST File System Usage',
      rufId: 'mon_fissys_data',
      component: FiSysUsageComponent
    },
    'SYCPUUSAGE': {
      label: 'IST System/Memory Utilization',
      title: 'IST System/Memory Utilization',
      description: 'IST System/Memory Utilization',
      rufId: 'mon_sycpu_usage',
      component: SyCPUUsageComponent
    },
    'SYCPUUSAGE2': {
      label: 'IST System/Memory Utilization Root Info',
      title: 'IST System/Memory Utilization Root Info',
      description: 'IST System/Memory Utilization Root Info',
      rufId: 'mon_sycpu_usage',
      component: SyCPUUsage2Component
    },
    'IPCADTLS': {
      label: 'IST IPC Details Message Queue',
      title: 'IST IPC Details Message Queue',
      description: 'IST IPC Details Message Queue',
      rufId: 'mon_ipca_details',
      component: IpcDetailsComponent
    },
  }
};

@NgModule({
    imports :[
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    ISTComponentModule,
    TranslateModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressBarModule,
    FlexLayoutModule,
    RufCardModule,
    HighchartsChartModule
  ],
  declarations: [
    FiSysUsageComponent,
    SyCPUUsageComponent,
    IpcDetailsComponent,
    SyCPUUsage2Component,
    PlatformDashboardComponent
  ],
  providers: [{ provide: MON_TOOL, useValue: platformMonitoringData }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[],
})
export class PlatformMonitoringModule {}
