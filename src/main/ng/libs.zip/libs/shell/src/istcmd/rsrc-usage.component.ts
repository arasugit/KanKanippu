import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';
import { Location } from '@angular/common';


@Component({
  selector: 'rsrc-usage-app',
  templateUrl: './rsrc-usage.component.html',
  styleUrls: ['./istCommandStyle.scss'],
  encapsulation: ViewEncapsulation.None
 })
export class RsrcUsageComponent extends ListComponent implements OnInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, private location: Location) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'mbcmd usage';
  }

  FORM_TITLE = 'IST Resource Usage ';
  exportFileName = 'IST Resource Usage';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';
   param :  string = '';
   paramValue :  string = ''
   showBackBtn = false;

   queryPerm = new FormActionPermission('RSRCUSG', 'Q');
   checkerPerm = new FormActionPermission('RSRCUSG', 'C');
   mkcPerm = new MKCPermission('RSRCUSG');


   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);

    this.param = history.state.paramKey;
    this.paramValue = history.state.paramKeyValue;

    if(this.param && this.param === 'ValueForUsedResourceCount') {
      this.showBackBtn = true;
    }

  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'RSRCUSG';
    this.metaDataId = 'RSRCUSG';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }

  goBack() {
    this.clearErrorMessage();
    this.globals.setErrorMessage('');
    this.location.back();
  }
}

