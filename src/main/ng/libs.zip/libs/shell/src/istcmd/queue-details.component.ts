import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';

@Component({
  selector: 'queue-details-app',
  templateUrl: './queue-details.component.html',
  styleUrls: ['./istCommandStyle.scss'],
  encapsulation: ViewEncapsulation.None
 })
export class QueueDetailsComponent extends ListComponent implements OnInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'mbcmd mon';
  }

  FORM_TITLE = 'IST Queue Details';
  exportFileName = 'IST Queue Details';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   queryPerm = new FormActionPermission('QUEUEDTLS', 'Q');
   checkerPerm = new FormActionPermission('QUEUEDTLS', 'C');
   mkcPerm = new MKCPermission('QUEUEDTLS');


   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'QUEUEDTLS';
    this.metaDataId = 'QUEUEDTLS';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }
}

