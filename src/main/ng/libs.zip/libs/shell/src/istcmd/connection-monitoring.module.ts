import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { PortDetailsComponent } from './port-details.component';
import { PortDashboardComponent } from '../port-dashboard/port-dashboard.component'
import { TranslateModule } from '@ngx-translate/core';
import { MatLegacyProgressBarModule as MatProgressBarModule } from '@angular/material/legacy-progress-bar'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { DatabaseConnDetailsComponent } from './database-connection-details.component';
import { CommonModule } from '@angular/common';
import { HighchartsChartModule } from 'highcharts-angular';


export const connectionMonitoringData: MonitorComponentData = {
  title: 'Switch Task Command',
  icon: 'home',
  examples: {
    'PORTDASH': {
        label: 'Port Dashboard',
        title: 'Port Dashboard',
        description: 'PORT Dashboard',
        rufId: 'mon_prt_dash',
        component: PortDashboardComponent
      },
    'PRTDTLS': {
        label: 'Port Details',
        title: 'Port Details',
        description: 'PORT Details',
        rufId: 'mon_prt_dtls',
        component: PortDetailsComponent
      },
      'DBCONNDTLS': {
        label: 'Database Details',
        title: 'Database Details',
        description: 'Database Details',
        rufId: 'mon_dbconn_details',
        component: DatabaseConnDetailsComponent
      }
  }
};

@NgModule({
    imports :[
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    ISTComponentModule,
    TranslateModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressBarModule,
    HighchartsChartModule
  ],
  declarations: [PortDashboardComponent,PortDetailsComponent, DatabaseConnDetailsComponent],
  providers: [{ provide: MON_TOOL, useValue: connectionMonitoringData }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[],
})
export class ConnectionMonitoringModule {}
