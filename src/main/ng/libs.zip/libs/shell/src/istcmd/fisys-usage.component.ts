import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';


@Component({
  selector: 'fisys-usage-app',
  templateUrl: './fisys-usage.component.html',
  styleUrls: ['./istCommandStyle.scss'],
  encapsulation: ViewEncapsulation.None
 })
export class FiSysUsageComponent extends ListComponent implements OnInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'df -h';
  }

  FORM_TITLE = 'IST File System Usage';
  exportFileName = 'IST File System Usage';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   queryPerm = new FormActionPermission('FISYUSAGE', 'Q');
   checkerPerm = new FormActionPermission('FISYUSAGE', 'C');
   mkcPerm = new MKCPermission('FISYUSAGE');


   ngOnInit() {
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'FISYUSAGE';
    this.metaDataId = 'FISYUSAGE';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }
}

