import { Component, ViewEncapsulation, OnInit, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef } from '@angular/core';
import { MON_ATM_COLOR_SETS } from '../../home/ngx-charts-color-sets';
import { ListComponent } from '../../components';
import { FormActionPermission, MKCPermission } from '../../permission';
import { DataTableService } from '../../services';
import { WorkRequest } from '../../ist-components';
import { ChartDto } from './chart-dto';
import { HighChartDto } from './chart-dto';
import { finalize, first } from 'rxjs/operators';
import { CommonConstants } from '../../common/ist.common.constants';
import * as Highcharts from 'highcharts';
import Highcharts3d from "highcharts/highcharts-3d";
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
Highcharts3d(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);
@Component({
  selector: 'platform-dashboard',
  templateUrl: './platform-dashboard.component.html',
  styleUrls: ['./platform-dashboard.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class PlatformDashboardComponent extends ListComponent implements OnInit,OnDestroy {
  public fileSystemUsageView: any[] = [1000, 350];
  public processCpuUsageView: any[] = [500, 350];
  public processRamUsageView: any[] = [500, 250];
  public memoryStatusView: any[] = [350, 250];
  public swapSpaceStatusView: any[] = [350, 250];
  public fileSystemUsageData:any[];
  public processCpuUsageData:any[];
  public processRamUsageData:any[];
  public memoryStatusData:any[];
  public swapSpaceStatusData:any[];
  public dataLoaded: boolean=false;
  public fileSystemUsageColorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };
  public cpuUsageColorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };
  public ramUsageColorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };
  public memoryStatusColorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };
  public swapSpaceStatusColorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };

  public fileSystemUsageLegendValues: string[] = [];
  public cpuUsageLegendValues: string[] = [];
  public memoryStatusLegendValues: string[] = [];
  public swapSpaceStatusLegendValues: string[] = [];
  // public usageLegendColors: ColorHelper;
  // public memoryStatusLegendColors: ColorHelper;
  // public swapSpaceStatusLegendColors: ColorHelper;

  public fileSystemUsageCardTitle: string = "";
  public cpuUsageCardTitle: string = "";
  public ramUsageCardTitle: string = "";
  public systemMemoryStatusCardTitle: string = "";
  public swapSpaceStatusCardTitle: string = "";

  // readonly LegendPosition = LegendPosition;
  // readonly LegendType = LegendType;
  private readonly redColor1 = "rgb(230, 0, 0)";
  private readonly redColor2 = "rgb(255, 51, 51)";
  private readonly redColor3 = "rgb(250, 95, 85)";
  private readonly yellowColor = "rgb(255, 192, 76)";
  private readonly greenColor = "rgb(75, 205, 62)";
  private fileSystemUsages: any;
  private runningProcesses: any;
  private memoryStatus: any;
  private swapSpaceStatus: any;
  private fileSystemUsageLogDate: any;
  private runningProcessLogDate: any;
  FORM_TITLE = 'Overall Platform Status';
  Highcharts: typeof Highcharts = Highcharts;
  fileUsageChart: Highcharts.Options;
  processCPUUsage: Highcharts.Options;
  processRamUsageDataUsage: Highcharts.Options;
  processmemoryStatusDataUsage: Highcharts.Options;
  processSwapStatusUsage: Highcharts.Options;

  cpuUsageTuple: [string, number];
  cpuUsageArray: any[] = [];

  processMemoryUsageTuple: [string, number];
  processMemoryUsageArray: any[] = [];

  processRamUsageDataTuple:  [string, number];
  processRamUsageDataArray: any[] = [];

  memoryStatusDataArray: any[] = [];
  swapSpaceDataArray: any[] = [];

  constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker){
      super(injector);
      this.adjustCriteria();
      this.retriveData();
  }

  adjustCriteria(): void {
    this.globals.setErrorMessage('');
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }

  search(): void {
    this.adjustCriteria();
    this.retriveData();
  }

  retriveData(): void {
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;

    this.dataService
    .loadData(false)
    .pipe(
      first(),
      finalize(() => this.globals.hideLoadingBar())
    )
    .subscribe(
      {
        next: (atmData: any) => this.onGotRecords(atmData),
        error: (error: any) => this.onErrorGotRecords(error)
      }
    );
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnInit(){
    super.ngOnInit();
    this.setAutoRefreshRetriveDataInterval();
  }

  onGotRecords(wr: WorkRequest): void {
    const workRequest = wr;

    if(workRequest.lastModified == -1){
      this.globals.setErrorMessage('No Data found');
      //return;
    }

    // if (workRequest == null || workRequest == undefined
    //   || workRequest.collections == null || workRequest.collections[this.collectionId] == null
    //   || workRequest.collections[this.collectionId].rows == null
    //   || workRequest.collections[this.collectionId].rows == undefined
    //   || workRequest.collections[this.collectionId].rows.length == 0) {
    //     return;
    // }
    this.fileSystemUsageData = [];
    this.cpuUsageArray = [];
    this.processRamUsageDataArray = [];
    this.memoryStatusDataArray = [];
    this.swapSpaceDataArray = [];

    const platformData = workRequest.collections[this.collectionId].rows[0];
    this.setFileSystemUsage(platformData);
    this.setCpuUsage(platformData);
    this.setRamUsage();
    this.setMemoryStatus(platformData);
    this.setSwapSpaceStatus(platformData);

    this.dataLoaded = true;
    this.cdr.markForCheck();

    //Chart - 1 (File System Usage)
    this.fileUsageChart= {
      
      chart: {
        renderTo: 'container',
        type: 'column',
        margin: 75,
        options3d: {
          enabled: true,
          alpha: 20,
          beta: 0,
          depth: 50,
          viewDistance: 50
      }
      },
      credits:{
        enabled: false,
      },
      legend:{
        enabled:false
      },
      
      title: {
          text: this.fileSystemUsageCardTitle,
           align: 'left'
      },
      
      xAxis: {
          type: 'category',
          labels: {
              autoRotation: [-45, -90],
              style: {
                  fontSize: '13px',
                  fontFamily: 'Verdana, sans-serif'
              }
          }
      },
      yAxis: {
          min: 0,
          title: {
              text: 'Used Percentage'
          }
      },
      tooltip: {
          pointFormat: 'Used Items: <b>{point.y:.1f} %</b>'
      },
      plotOptions: {
        column: {
          depth: 25
        }
      },
      series: [{
          // pointWidth: 10,
          name: 'Population ',
          cursor: 'pointer',
          // colorByPoint: true,
          groupPadding: 0,
          data: this.fileSystemUsageData,
            zones: [{
              value: 0,
              color: '#abffff'
            },
            {
              value: 10,
              color: '#78ffff'
            },
            {
              value: 30,
              color: '#FF0000'
            },
            {
              value: 50,
              color: '#3be5e2'
            },
            {
              value: 70,
              color: '#3be5c1'
            },
            {
              value: 90,
              color: '#35e17e'
            },
            {
              value: 100,
              color: '#2dc06b'
            },
            {
              value: 110,
              color: '#0000FF'
            }],
            point: {
              events: {
                  click:  (event)=> {
                    this.onFileSystemUsageBarStatus({event});
                  }
                }
             },
            dataLabels: {
              enabled: true,
              rotation: -90,
              color: '#FFFFFF',
              inside: true,
              verticalAlign: 'top',
              y: 10, // 10 pixels down from the top
              style: {
                  fontSize: '13px',
                  fontFamily: 'Verdana, sans-serif'
              }
            }
      }] as any
    }

    //Chart - 2 (Process CPU Usage )
    this.processCPUUsage = {
      chart: {
          type: 'column',
          options3d: {
            enabled: true,
            alpha: 20,
            beta: 0,
            depth: 50,
            viewDistance: 50
        }
      },
      credits:{
        enabled: false,
      },
      title: {
          text: this.cpuUsageCardTitle,
           align: 'left'
      },
      legend:{
        enabled:false
      },
      plotOptions: {
          column: {
              depth: 35,
              colorByPoint: true
          }
      },
      xAxis: {
          type: 'category',
          labels: {
              skew3d: true,
              style: {
                  fontSize: '16px',
              }
          },
          title: {
            text: 'Process Id',
            margin: 20,
            style: {
              fontSize: '16px',
          }
        }
      },
      yAxis: {
          title: {
              text: 'Used Percentage',
              margin: 20
          }
      },
      tooltip: {
          pointFormat: 'CPU Usage: <b>{point.y:.2f}%</b>'
      },
      series: [{
          name: 'Usage ',
          data: this.cpuUsageArray,
          colorByPoint: true,
          cursor: 'pointer',
          point: {
            events: {
              click:  (event)=> {
                this.onCpuUsageBarSelect({event});
              }
            }
          },
      }] as any
    }

  //Chart - 3 (Process Memory Usage)
  this.processRamUsageDataUsage = {
    chart: {
        type: 'column',
        options3d: {
          enabled: true,
          alpha: 20,
          beta: 0,
          depth: 50,
          viewDistance: 50
      }
    },
    credits:{
      enabled: false,
    },
    title: {
        text: this.ramUsageCardTitle,
         align: 'left'
    },
    legend:{
      enabled:false
    },
    
    plotOptions: {
        column: {
            depth: 35,
            colorByPoint: true
        }
    },
    xAxis: {
        type: 'category',
        labels: {
            skew3d: true,
            style: {
                fontSize: '16px',
            }
        },
        title: {
          text: 'Process Id',
          margin: 20,
          style: {
            fontSize: '16px',
        }
      }
    },
    yAxis: {
        title: {
            text: 'Used Percentage',
            margin: 20
        }
    },
    tooltip: {
        pointFormat: 'Memory Usage: <b>{point.y:.2f}%</b>'
    },
    series: [{
        name: 'Usage ',
        data: this.processRamUsageDataArray,
        cursor: 'pointer',
        point: {
          events: {
            click:  (event)=> {
              this.onRamUsageBarSelect({event});
            }
          }
        }
    }] as any
  }

    //Chart - 4 (System Memory Usage)
    this.processmemoryStatusDataUsage = {
      tooltip: { 
      pointFormat: '<b>{series.name}</b>'
    },
    
      chart: {
          type: 'pie',
          options3d: {
              enabled: true,
              alpha: 55
          }
      },
      credits:{
        enabled: false,
      },
      title: {
          text: this.systemMemoryStatusCardTitle,
          align: 'left'
      },
      legend:{
        enabled:false
      },
      subtitle: {
          text: '',
          align: 'left'
      },
      plotOptions: {
          pie: {
              innerSize: 100,
              depth: 45
          }
      },
      series: [{
          name: ' ',
          data: this.memoryStatusDataArray,
          cursor: 'pointer',
          point: {
            events: {
              click:  (event)=> {
                this.onMemoryStatusSliceSelect({event});
              }
            }
          },
          
      }] as any
    }

    //Chart - 5 (Swap Space Usage)
    this.processSwapStatusUsage = {
      tooltip: { 
      pointFormat: '<b>{series.name}</b>'      
    },
      chart: {
          type: 'pie',
          options3d: {
              enabled: true,
              alpha: 55
          }
      },
      credits:{
        enabled: false,
      },
      title: {
          text: this.swapSpaceStatusCardTitle,
          align: 'left'
      },
      legend:{
        enabled:false
      },
      subtitle: {
          text: '',
          align: 'left'
      },
      plotOptions: {
          pie: {
              innerSize: 100,
              depth: 45
          }
      },
      series: [{
          name: ' ',
          data: this.swapSpaceDataArray,
          cursor: 'pointer',
          point: {
            events: {
              click:  (event)=> {
                this.onSwapSpaceStatusSliceSelect({event});
              }
            }
          },
          // data: [
          //     ['Used 5.85 GB (25.03%)', 25.03],
          //     ['Cached 7.71 GB (33%)', 33],
          //     ['Free 9.81 GB (41.97%)', 41.97]
          // ]
      }] as any
    }
  }
  //############################################

  setFileSystemUsage(platformData: any) {
    if(platformData.fileSystemUsages != null) {
    this.fileSystemUsages = platformData.fileSystemUsages;
    this.fileSystemUsageLogDate = platformData.fileSystemUsageLogDate;

    let chartDtoList: HighChartDto[] = [];
    let backgroundColor: any[] = [];

    this.sortFileSystemUsageByUsedPercent();
    let count = 0;
    this.fileSystemUsages.forEach(c => {
      var usedPercent = String(c.usedPercent).replace('%', '');
      var mountedFile = c.mountedOn;

      if (+usedPercent == 0)
        return;

      this.addColorToFileSystemUsageBgColor(+usedPercent, backgroundColor);

      let chartDto = new HighChartDto(mountedFile, parseFloat(usedPercent));
      if(count < 15) {
        chartDtoList.push(chartDto);
      }
      count++;
    })

    this.fileSystemUsageData = chartDtoList;

    console.log(this.fileSystemUsageData)
    this.adjustFileSystemUsageChartWidth(this.fileSystemUsageData.length);
    this.addFileSystemUsageLegendValues();
    this.setFileSystemUsageColorScheme(backgroundColor);
    this.setUsageLegendColours();
    this.fileSystemUsageCardTitle = `File System Usage - On ${this.fileSystemUsageLogDate}`;
  }
  }

  setCpuUsage(platformData: any) {
    this.runningProcesses = platformData.runningProcesses;
    if(platformData.runningProcesses != null || platformData.runningProcessLogDate != null) {
    this.runningProcessLogDate = platformData.runningProcessLogDate;

    let chartDtoList: ChartDto[] = [];
    let backgroundColor: any[] = [];

    this.sortRunningProcessByCpuUsage();

    this.runningProcesses.forEach(c => {
      var usedPercent = c.cpuUsagePercent;

      if (+usedPercent < 1)
        return;

      this.addColorToCpuUsageBgColor(+usedPercent, backgroundColor);

      let chartDto = new ChartDto(c.processId, usedPercent);
      chartDtoList.push(chartDto);
      this.cpuUsageTuple = [c.processId, parseFloat(usedPercent)];
      this.cpuUsageArray.push(this.cpuUsageTuple);

    })

    console.log(this.cpuUsageArray);

    this.processCpuUsageData = JSON.parse(JSON.stringify(chartDtoList));
    this.adjustProcessCpuUsageChartWidth(this.processCpuUsageData.length);
    this.addCpuUsageLegendValues();
    this.setCpuUsageColorScheme(backgroundColor);
    this.cpuUsageCardTitle = `Process CPU Usage - On ${this.runningProcessLogDate}`;
  }
  }

  setRamUsage() {
    let chartDtoList: ChartDto[] = [];
    let backgroundColor: any[] = [];
    if(this.runningProcesses != null) {
    this.sortRunningProcessByRamUsage();

    this.runningProcesses.forEach(c => {
      var usedPercent = c.memoryUsagePercent;

      if (+usedPercent < 1)
        return;

      this.addColorToCpuUsageBgColor(+usedPercent, backgroundColor);

      let chartDto = new ChartDto(c.processId, usedPercent);
      chartDtoList.push(chartDto);

      this.processRamUsageDataTuple = [c.processId, parseFloat(usedPercent)];
      this.processRamUsageDataArray.push(this.processRamUsageDataTuple);

    })

    console.log(this.processRamUsageDataArray);

    this.processRamUsageData = JSON.parse(JSON.stringify(chartDtoList));
    this.adjustProcessRamUsageChartWidth(this.processRamUsageData.length);
    this.setRamUsageColorScheme(backgroundColor);
    this.ramUsageCardTitle = `Process Memory Usage - On ${this.runningProcessLogDate}`;
  }
  }

  setMemoryStatus(platformData: any) {
    this.memoryStatusLegendValues.length = 0;
    if(platformData.memoryStatus != null) {
    this.memoryStatus = platformData.memoryStatus;

    let chartDtoList: ChartDto[] = [];
    let backgroundColor: any[] = [];

    let used = new ChartDto(`Used ${this.memoryStatus.used} GB`, this.memoryStatus.usedPercent);
    let cached = new ChartDto(`Cached ${this.memoryStatus.usedForCache} GB`, this.memoryStatus.usedForCachePercent);
    let free = new ChartDto(`Free ${this.memoryStatus.free} GB`, this.memoryStatus.freePercent);

    chartDtoList.push(used);
    chartDtoList.push(cached);
    chartDtoList.push(free);

    this.memoryStatusLegendValues.push(`Used ${this.memoryStatus.used} GB (${this.memoryStatus.usedPercent}%)`);
    this.memoryStatusLegendValues.push(`Cached ${this.memoryStatus.usedForCache} GB (${this.memoryStatus.usedForCachePercent}%)`);
    this.memoryStatusLegendValues.push(`Free ${this.memoryStatus.free} GB (${this.memoryStatus.freePercent}%)`);

    backgroundColor.push(this.redColor2);
    backgroundColor.push(this.yellowColor);
    backgroundColor.push(this.greenColor);

    this.memoryStatusData = JSON.parse(JSON.stringify(chartDtoList));
    this.setMemoryStatusColorScheme(backgroundColor);
    this.setMemoryStatusLegendColours();
    this.systemMemoryStatusCardTitle = `System Memory Usage - On ${this.runningProcessLogDate}`;

    let memoryStatusDataTuple:  [string, number];

    let tempDat = 'Used ' + this.memoryStatus.used + ' GB (' + this.memoryStatus.usedPercent + '%);'
    memoryStatusDataTuple = [tempDat,  parseFloat(this.memoryStatus.usedPercent)];
    this.memoryStatusDataArray.push(memoryStatusDataTuple);

    tempDat = 'Cached ' + this.memoryStatus.usedForCache + ' GB (' + this.memoryStatus.usedForCachePercent + '%);'
    memoryStatusDataTuple = [tempDat, parseFloat(this.memoryStatus.usedForCachePercent)];
    this.memoryStatusDataArray.push(memoryStatusDataTuple);

    tempDat = 'Free ' + this.memoryStatus.free + ' GB (' + this.memoryStatus.freePercent + '%);'
    memoryStatusDataTuple = [tempDat,  parseFloat(this.memoryStatus.usedForCachePercent)];
    this.memoryStatusDataArray.push(memoryStatusDataTuple);
  }
  }

  setSwapSpaceStatus(platformData: any) {
    this.swapSpaceStatusLegendValues.length = 0;
    if(platformData.swapSpaceStatus != null) {
    this.swapSpaceStatus = platformData.swapSpaceStatus;

    let chartDtoList: ChartDto[] = [];
    let backgroundColor: any[] = [];

    let used = new ChartDto(`Used ${this.swapSpaceStatus.used} GB`, this.swapSpaceStatus.usedPercent);
    let free = new ChartDto(`Free ${this.swapSpaceStatus.free} GB`, this.swapSpaceStatus.freePercent);

    chartDtoList.push(used);
    chartDtoList.push(free);

    this.swapSpaceStatusLegendValues.push(`Used ${this.swapSpaceStatus.used} GB (${this.swapSpaceStatus.usedPercent}%)`);
    this.swapSpaceStatusLegendValues.push(`Free ${this.swapSpaceStatus.free} GB (${this.swapSpaceStatus.freePercent}%)`);

    if (+this.swapSpaceStatus.usedAndCachePercent > 50) {
      backgroundColor.push(this.redColor2);
      backgroundColor.push(this.greenColor);
    }
    else {
      backgroundColor.push(this.yellowColor);
      backgroundColor.push(this.greenColor);
    }

    this.swapSpaceStatusData = JSON.parse(JSON.stringify(chartDtoList));
    this.setSwapSpaceStatusColorScheme(backgroundColor);
    this.setSwapSpaceStatusLegendColours();
    this.swapSpaceStatusCardTitle = `Swap Space Usage - On ${this.runningProcessLogDate}`;

    let swapSpaceDataTuple:  [string, number];

    let tempDat = 'Used ' + this.swapSpaceStatus.used + ' GB (' + this.swapSpaceStatus.usedPercent + '%);'
    swapSpaceDataTuple = [tempDat,  parseFloat(this.swapSpaceStatus.usedPercent)];
    this.swapSpaceDataArray.push(swapSpaceDataTuple);

    tempDat = 'Free ' + this.swapSpaceStatus.free + ' GB (' + this.swapSpaceStatus.freePercent + '%);'
    swapSpaceDataTuple = [tempDat,  parseFloat(this.swapSpaceStatus.freePercent)];
    this.swapSpaceDataArray.push(swapSpaceDataTuple);
    }
  }

  sortFileSystemUsageByUsedPercent() {
    this.fileSystemUsages.sort((a, b) => {
      const valueA = parseFloat(a.usedPercent.replace('%', ''));
      const valueB = parseFloat(b.usedPercent.replace('%', ''));
      return valueB - valueA;
    });
  }

  sortRunningProcessByCpuUsage() {
    this.runningProcesses.sort((a, b) => {
      const valueA = a.cpuUsagePercent;
      const valueB = b.cpuUsagePercent;
      return valueB - valueA;
    });
  }

  sortRunningProcessByRamUsage() {
    if(this.runningProcesses != null) {
    this.runningProcesses.sort((a, b) => {
      const valueA = a.memoryUsagePercent;
      const valueB = b.memoryUsagePercent;
      return valueB - valueA;
    });
  }
  }

  addColorToFileSystemUsageBgColor(usedPercent: number, backgroundColor: any[]) {
    if (usedPercent >= 90)
        backgroundColor.push(this.redColor1);
      else if (+usedPercent >= 80)
        backgroundColor.push(this.redColor2);
      else if (+usedPercent >= 70)
        backgroundColor.push(this.redColor3);
      else if (+usedPercent >= 50)
        backgroundColor.push(this.yellowColor);
      else
        backgroundColor.push(this.greenColor);
  }

  addColorToCpuUsageBgColor(usedPercent: number, backgroundColor: any[]) {
    if (+usedPercent >= 80)
      backgroundColor.push(this.redColor1);
    else if (+usedPercent >= 60)
      backgroundColor.push(this.redColor2);
    else if (+usedPercent >= 40)
      backgroundColor.push(this.redColor3);
    else if (+usedPercent >= 20)
      backgroundColor.push(this.yellowColor);
    else
      backgroundColor.push(this.greenColor);
  }

  addFileSystemUsageLegendValues(): void {
    this.fileSystemUsageLegendValues.push("70% - 100%");
    this.fileSystemUsageLegendValues.push("50% - 69%");
    this.fileSystemUsageLegendValues.push("1% - 49%");
  }

  addCpuUsageLegendValues(): void {
    this.cpuUsageLegendValues.push("40% - 100%");
    this.cpuUsageLegendValues.push("20% - 39%");
    this.cpuUsageLegendValues.push("1% - 19%");
  }

  setFileSystemUsageColorScheme(backgroundColor: any[]) {
    this.fileSystemUsageColorScheme = {
      name: 'Variation',
      selectable: true,
      // group: ScaleType.Ordinal,
      domain: backgroundColor
    };
  }

  setCpuUsageColorScheme(backgroundColor: any[]) {
    this.cpuUsageColorScheme = {
      name: 'Variation',
      selectable: true,
      // group: ScaleType.Ordinal,
      domain: backgroundColor
    };
  }

  setRamUsageColorScheme(backgroundColor: any[]) {
    this.ramUsageColorScheme = {
      name: 'Variation',
      selectable: true,
      // group: ScaleType.Ordinal,
      domain: backgroundColor
    };
  }

  setMemoryStatusColorScheme(backgroundColor: any[]) {
    this.memoryStatusColorScheme = {
      name: 'Variation',
      selectable: true,
      // group: ScaleType.Ordinal,
      domain: backgroundColor
    };
  }

  setSwapSpaceStatusColorScheme(backgroundColor: any[]) {
    this.swapSpaceStatusColorScheme = {
      name: 'Variation',
      selectable: true,
      // group: ScaleType.Ordinal,
      domain: backgroundColor
    };
  }

  setUsageLegendColours(): void {
    let legendBackgroundColor: any[] = [];

    legendBackgroundColor.push(this.redColor2);
    legendBackgroundColor.push(this.yellowColor);
    legendBackgroundColor.push(this.greenColor);

    // let legendColorScheme: Color = {
    //   name: 'Variation',
    //   selectable: true,
    //   group: ScaleType.Ordinal,
    //   domain: legendBackgroundColor
    // };

    // this.usageLegendColors = new ColorHelper(legendColorScheme as Color, ScaleType.Ordinal, this.fileSystemUsageLegendValues, legendColorScheme);
  }

  setMemoryStatusLegendColours(): void {
    let legendBackgroundColor: any[] = this.memoryStatusColorScheme.domain;

    // let legendColorScheme: Color = {
    //   name: 'Variation',
    //   selectable: true,
    //   group: ScaleType.Ordinal,
    //   domain: legendBackgroundColor
    // };

    // this.memoryStatusLegendColors = new ColorHelper(legendColorScheme as Color, ScaleType.Ordinal, this.memoryStatusLegendValues, legendColorScheme);
  }

  setSwapSpaceStatusLegendColours(): void {
    let legendBackgroundColor: any[] = this.swapSpaceStatusColorScheme.domain;

    // let legendColorScheme: Color = {
    //   name: 'Variation',
    //   selectable: true,
    //   group: ScaleType.Ordinal,
    //   domain: legendBackgroundColor
    // };

    // this.swapSpaceStatusLegendColors = new ColorHelper(legendColorScheme as Color, ScaleType.Ordinal, this.swapSpaceStatusLegendValues, legendColorScheme);
  }

  adjustFileSystemUsageChartWidth(rowCount: number) {
    if(rowCount > 20)
      this.fileSystemUsageView = [rowCount * 50, 350];
  }

  adjustProcessCpuUsageChartWidth(rowCount: number) {
    if(rowCount > 10)
      this.processCpuUsageView = [rowCount * 50, 350];
  }

  adjustProcessRamUsageChartWidth(rowCount: number) {
    if(rowCount > 10)
      this.processRamUsageView = [rowCount * 50, 300];
  }

  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  getEntPermList(): any[] {
    this.entObjectId = 'PLTFDASH';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm, this.mkcPerm);
  }

  setT21Tags(): void {
    this.requestTypeId = 'PLTFDASH';
    this.metaDataId = 'PLTFDASH';
    this.tabId = 'PLTFDASH_TAB';
    this.sectionId = 'PLTFDASH_SEC';
    this.collectionId = 'PLTFDASH_COL';
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
    this.clearErrorMessage();
  }

  onFileSystemUsageBarStatus(event) {

    console.log("EVent " + event.name);
    console.log("EVent " + this.fileSystemUsages);

    //const fileSystemUsage = this.fileSystemUsages.find(item => item.mountedOn == event.name);
    const fileSystemUsage = this.fileSystemUsages.find(item => item.mountedOn == event.event.point.name);

    console.log("fileSystemUsage  " + fileSystemUsage);

    var fileSystemUsageDetail = `
    -------------------------------------------------------------------------------
    File System Name: ${fileSystemUsage.fileSystem}
    Mounted On:       ${fileSystemUsage.mountedOn}
    -------------------------------------------------------------------------------
    Size:             ${fileSystemUsage.size}
    Percent Used:     ${fileSystemUsage.usedPercent}
    Size Used:        ${fileSystemUsage.usedSize}
    Size Available:   ${fileSystemUsage.availableSize}
    Log Date:         ${this.fileSystemUsageLogDate}
    -------------------------------------------------------------------------------
    `;

    this.globals.showDialog(CommonConstants.INFORMATION, fileSystemUsageDetail, CommonConstants.ALERT_OK);
  }

  onMemoryStatusSliceSelect(event) {
    var memoryStatusDetail = `
    -------------------------------------------------------------------------------
    Total:          ${this.memoryStatus.totalSize} GB
    Used:           ${this.memoryStatus.used} GB (${this.memoryStatus.usedPercent}%)
    Used For Cache: ${this.memoryStatus.usedForCache} GB (${this.memoryStatus.usedForCachePercent}%)
    Free:           ${this.memoryStatus.free} GB (${this.memoryStatus.freePercent}%)
    -------------------------------------------------------------------------------
    `;

    this.globals.showDialog(CommonConstants.INFORMATION, memoryStatusDetail, CommonConstants.ALERT_OK);
  }

  onSwapSpaceStatusSliceSelect(event) {
    var swapSpaceStatusDetail = `
    -------------------------------------------------------------------------------
    Total:          ${this.swapSpaceStatus.totalSize} GB
    Used:           ${this.swapSpaceStatus.used} GB (${this.swapSpaceStatus.usedPercent}%)
    Free:           ${this.swapSpaceStatus.free} GB (${this.swapSpaceStatus.freePercent}%)
    -------------------------------------------------------------------------------
    `;

    this.globals.showDialog(CommonConstants.INFORMATION, swapSpaceStatusDetail, CommonConstants.ALERT_OK);
  }

  onCpuUsageBarSelect(event) {
    this.showProcessDetail(event);
  }

  onRamUsageBarSelect(event) {
    this.showProcessDetail(event);
  }

  //showProcessDetail(processId: any) {
  showProcessDetail(event: any) {
    //const process = this.runningProcesses.find(item => item.processId == processId);
    const process = this.runningProcesses.find(item => item.processId == event.event.point.name);

    var processDetail = `
    -------------------------------------------------------------------------------
    Process Id:             ${process.processId}
    -------------------------------------------------------------------------------
    User:                   ${process.user}
    Priority:               ${process.processPriority}
    Nice Value:             ${process.niceValue}
    Virtual Memory Used:    ${process.virtualMemorySize}
    Resident Memory Usage:  ${process.residentMemorySize}
    Shared Memory:          ${process.sharedMemorySize}
    Process Status:         ${this.getProcessStatusDesc(process.processStatus)}
    CPU Usage:              ${process.cpuUsagePercent}%
    Memory Usage            ${process.memoryUsagePercent}%
    CPU Time Used:          ${process.cpuTimeUsed}
    Command:                ${process.command}
    Log Date:               ${this.fileSystemUsageLogDate}
    -------------------------------------------------------------------------------
    `;

    this.globals.showDialog(CommonConstants.INFORMATION, processDetail, CommonConstants.ALERT_OK);
  }

  getProcessStatusDesc(statusCode: string): string {
    if (statusCode == "S")
      return "Sleeping";
    if (statusCode == "R")
      return "Running";
    return statusCode;
  }
}
