import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TaskCommandComponent } from './task-command.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { BinDetailsComponent } from './bin-details.component';
import { MemrDetailsComponent } from './memr-details.component';
import { TrceDetailsComponent } from './trce-details.component';
import { RsrcUsageComponent } from './rsrc-usage.component';
import { EvntDetailsComponent } from './evnt.details.component';
import { MbcdOptionsComponent } from './mbcd-options.component';
import { MblookStComponent } from './mblook-st.component';
import { MbcdUptimeComponent } from './mbcd-uptime.component';
import { SafTxnDataComponent } from './safTxn-data.component';
import { ProcDetailsComponent } from './proc-details.component';
import { QueueDetailsComponent } from './queue-details.component';
import { DebugMonitoringComponent } from './debug-monitoring.component';
import { TranslateModule } from '@ngx-translate/core';
import { MatLegacyProgressBarModule as MatProgressBarModule } from '@angular/material/legacy-progress-bar'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { CaPsrComponent } from './ca-psr.component';
import { CaPcpComponent } from './ca-pcp.component';
import { CaPscComponent } from './ca-psc.component';
import { CaPqComponent } from './ca-pq.component';
import { DatePipe } from '@angular/common';
import { HighchartsChartModule } from 'highcharts-angular';


export const tskCmdData: MonitorComponentData = {
  title: 'Switch Task Command',
  icon: 'home',
  examples: {
      'TSKCMD': {
          label: 'Task Command',
          title: 'Task Command',
          description: 'Task Command',
          rufId: 'mon_task_cmd',
          component: TaskCommandComponent
      },
      'BINDTLS': {
        label: 'Bin Details',
        title: 'Bin Details',
        description: 'BIN Details',
        rufId: 'mon_bin_dtls',
        component: BinDetailsComponent
      },
      "MEMDTLS": {
        label: 'Memory Rule Details',
        title: 'Memory Rule Details',
        description: 'Memory Rule Details',
        rufId: 'mon_memr_dtls',
        component: MemrDetailsComponent
      },
      'TRCDTLS': {
        label: 'Trace Details List',
        title: 'Trace Details',
        description: 'Trace Details',
        rufId: 'mon_trce_dtls',
        component: TrceDetailsComponent
      },
      'RSRCUSG': {
        label: 'IST Resource Usage Info',
        title: 'IST Resource Info',
        description: 'IST Resource Info',
        rufId: 'mon_rsrc_dtls',
        component: RsrcUsageComponent
      },
      'EVNTDTLS': {
        label: 'IST Event Details',
        title: 'IST Event Details',
        description: 'IST Event Details',
        rufId: 'mon_event_dtls',
        component: EvntDetailsComponent
      },
      'MBCDOPTS': {
        label: 'IST Basic Configurations',
        title: 'IST  Basic Configurations',
        description: 'IST  Basic Configurations',
        rufId: 'mon_mbcd_opts',
        component: MbcdOptionsComponent
      },
      'MBLOOKTS': {
        label: 'IST Mail Box Info',
        title: 'IST Mail Box Info',
        description: 'IST Mail Box Info',
        rufId: 'mon_mblook_st',
        component: MblookStComponent
      },
      'MBCDUPTME': {
        label: 'IST MBCD Uptime',
        title: 'IST MBCD Uptime',
        description: 'IST MBCD Uptime',
        rufId: 'mon_mbcd_uptime',
        component: MbcdUptimeComponent
      },
      'SAFTXNDATA': {
        label: 'IST SAF and Transactions',
        title: 'IST SAF and Transactions',
        description: 'IST SAF and Transactions',
        rufId: 'mon_saftxn_data',
        component: SafTxnDataComponent
      },
      'PROCDTLS': {
        label: 'IST Procedure Details',
        title: 'IST Procedure Details',
        description: 'IST Procedure Details',
        rufId: 'mon_proc_details',
        component: ProcDetailsComponent
      },
      'QUEUEDTLS': {
        label: 'IST Queue Details',
        title: 'IST Queue Details',
        description: 'IST Queue Details',
        rufId: 'mon_queue_details',
        component: QueueDetailsComponent
      },
      'DEBUGM_REQ': {
        label: 'Debug Monitoring',
        title: 'Debug Monitoring',
        description: 'Debug Monitoring',
        rufId: 'mon_debug_monitoring',
        component: DebugMonitoringComponent
      },
      'CA_PSR': {
        label: 'Print Server Details',
        title: 'Print Server Details',
        description: 'Print Server Details',
        rufId: 'ca_psr',
        component: CaPsrComponent
      },
      'CA_PCP': {
        label: 'Print Client Details',
        title: 'Print Client Details',
        description: 'Print Client Details',
        rufId: 'ca_pcp',
        component: CaPcpComponent
      },
      'CA_PSC': {
        label: 'Print Service Details',
        title: 'Print Service Details',
        description: 'Print Service Details',
        rufId: 'ca_psc',
        component: CaPscComponent
      },
      'CA_PQ': {
        label: 'Print Queue Details',
        title: 'Print Queue Details',
        description: 'Print Queue Details',
        rufId: 'ca pq',
        component: CaPqComponent
      }
  }
};

@NgModule({
    imports :[
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    ISTComponentModule,
    TranslateModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressBarModule,
    HighchartsChartModule
  ],
  declarations: [TaskCommandComponent, BinDetailsComponent, MemrDetailsComponent,
                  TrceDetailsComponent, RsrcUsageComponent, EvntDetailsComponent, MbcdOptionsComponent,
                  MblookStComponent, MbcdUptimeComponent, SafTxnDataComponent, ProcDetailsComponent, QueueDetailsComponent,
                  DebugMonitoringComponent, CaPsrComponent, CaPcpComponent, CaPscComponent, CaPqComponent],
  providers: [{ provide: MON_TOOL, useValue: tskCmdData },  DatePipe],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[],
})
export class ISTCommandModule {}
