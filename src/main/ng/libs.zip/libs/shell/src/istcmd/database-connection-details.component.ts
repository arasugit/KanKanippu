import { Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';
import { GlobalsService } from '../services';
import { Location } from '@angular/common';



@Component({
  selector: 'database-conn-details-app',
  templateUrl: './database-conn-details.component.html'
 })
export class DatabaseConnDetailsComponent extends ListComponent implements OnInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent
  constructor(injector: Injector, private location: Location) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'dbconn';

    if(this.param && this.param === 'ValueForSwitchBoardDBState') {
      if(this.paramValue.includes('Up')) {
        this.criteria['fieldName'] = 'Up';
      } else if(this.paramValue.includes('Down')) {
        this.criteria['fieldName'] = 'Down';
      }
    }
  }

  FORM_TITLE = 'Database Details';
  exportFileName = 'Database Details';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';
   param : string = '';
   paramValue : string = '';

   queryPerm = new FormActionPermission('DBCONNDTLS', 'Q');
   checkerPerm = new FormActionPermission('DBCONNDTLS', 'C');
   mkcPerm = new MKCPermission('DBCONNDTLS');


   ngOnInit() {


    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);

    this.param = history.state.paramKey;
    this.paramValue = history.state.paramKeyValue;

    if(this.param && this.param === 'ValueForSwitchBoardDBState') {
      this.showBackBtn = true;
    }
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'DBCONNDTLS';
    this.metaDataId = 'DBCONNDTLS';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }

  goBack() {
    this.clearErrorMessage();
    this.globals.setErrorMessage('');
    this.location.back();
  }
}

