import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableService, GlobalsService } from '../services';
import { StringMap } from '../common/criteria';
import { LabelAndValue, LabelsAndValues } from '../common';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { DataTableEditableComponent } from '../components';
import { WorkRequest } from '../ist-components';

@Component({
  selector: "bin-details-app",
  templateUrl: "./bin-details.component.html",
})
export class BinDetailsComponent
  extends ListComponent
  implements OnInit, AfterViewInit
{
  @ViewChild("binTable", { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(
    injector: Injector,
    private dataService: DataTableService,
    private cdr: ChangeDetectorRef,
    private location: Location,
    private activatedRoute: ActivatedRoute
  ) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria["CommandType"] = "shccmd list";
    this.criteria["fieldName"] = this.fieldName;
    this.criteria["binRouteNode"] = this.binRouteNode;
    this.criteria["instId"] = this.instId;
    this.criteria["binStatus"] = this.binStatus;
  }

  FORM_TITLE = "BIN Details";
  exportFileName = "BIN Details";

  fileNamesList: LabelsAndValues = new LabelsAndValues();

  product = "";
  nodeId = "";
  taskName = "";
  istCommand = "";
  pId = "";
  count = "";
  lastStart = "";
  port = "";
  fieldName = "";
  workRequest: WorkRequest;
  instId = "";

  param: string = "";
  paramValue: any;
  binStatus: string = "";
  binStatusList: LabelsAndValues = new LabelsAndValues();
  binRouteNode: string = "";

  displayProgressBar = false;
  displayMessage = "";

  forceUpButton: boolean = true;
  forceDownButton: boolean = true;
  forceAllUpButton: boolean = true;
  forceAllDownButton: boolean = true;
  forceUpdateButton: boolean = true;
  forceRoutesetUpButton: boolean = true;
  forceRoutesetDownButton: boolean = true;
  echoStartButton: boolean = true;
  signOnButton: boolean = true;
  signOffButton: boolean = true;
  signOnStartButton: boolean = true;
  signOffStartButton: boolean = true;
  signOnGroupButton: boolean = true;
  signOffGroupButton: boolean = true;
  safStartButton: boolean = true;
  safStopButton: boolean = true;

  waitingCount: Number = 3;

  dbParam: StringMap = {};

  queryPerm = new FormActionPermission("BINDTLS", "Q");
  checkerPerm = new FormActionPermission("BINDTLS", "C");
  mkcPerm = new MKCPermission("BINDTLS");

  ngOnInit() {
    this.param = history.state.paramKey;
    this.paramValue = history.state.paramKeyValue;

    this.showBackBtn = false;

    this.binStatusList.array = [
      new LabelAndValue("", ""),
      new LabelAndValue("Up", "Up"),
      new LabelAndValue("Down", "Down"),
    ];

    super.ngOnInit();

    if (this.param && this.param === "ValueForSwitchBoardTBinStatus") {
      this.showBackBtn = true;
      this.binStatus = this.paramValue;
    }

    if (this.param && this.param === "ValueForSwitchBoardTBinStatusByInstId") {
      this.showBackBtn = true;
      this.instId = this.paramValue.instId;
      this.binStatus = this.paramValue.status;
    }

    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.insertPerm);
    this.requestPerms.permsArr.push(this.updatePerm);
    this.requestPerms.permsArr.push(this.deletePerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  loadFileNamesList(result: string[]): void {
    this.fileNamesList.array[0] = new LabelAndValue("", "");
    result.forEach((c) => {
      this.fileNamesList.array.push(new LabelAndValue(c, c));
    });
  }

  execute(): void {
    this.doSearch();
    this.setAutoRefreshInterval();
  }

  ngAfterViewInit(): void {
    this.doSearch();
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = "BINDTLS";
    this.metaDataId = "BINDTLS";
    this.tabId = "TSKCMDTAB";
    this.sectionId = "TSKCMDSEC";
    this.collectionId = "TSKCMDCOL";
  }

  toggleButtons(buttonStateDisable: boolean) {
    this.forceUpButton = buttonStateDisable;
    this.forceDownButton = buttonStateDisable;
    this.forceAllUpButton = buttonStateDisable;
    this.forceAllDownButton = buttonStateDisable;
    this.forceUpdateButton = buttonStateDisable;
    this.forceRoutesetUpButton = buttonStateDisable;
    this.forceRoutesetDownButton = buttonStateDisable;
    this.echoStartButton = buttonStateDisable;
    this.signOnButton = buttonStateDisable;
    this.signOffButton = buttonStateDisable;
    this.signOnStartButton = buttonStateDisable;
    this.signOffStartButton = buttonStateDisable;
    this.signOnGroupButton = buttonStateDisable;
    this.signOffGroupButton = buttonStateDisable;
    this.safStartButton = buttonStateDisable;
    this.safStopButton = buttonStateDisable;
  }

  onRowClick(event: any) {
    this.displayProgressBar = false;
    this.displayMessage = "";

    this.taskName = event.taskName ? event.taskName : "";
    this.product = event.product ? event.product : "";
    this.nodeId = event.nodeId ? event.nodeId : "";
    this.pId = event.pId ? event.pId : "";
    this.count = event.count ? event.count : "";
    this.lastStart = event.lastStart ? event.lastStart : "";
    this.port = event.field7 ? event.field7 : "";

    this.dataTableComponent.changedRecords = event;

    this.toggleButtons(false);
  }

  forceUp() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "FORCE UP process on BIN Id '" + this.taskName + "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd force " + this.pId + " " + this.taskName + " up";
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "FORCE UP");
      });
  }

  forceDown() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "FORCE DOWN process on BIN Id '" +
      this.taskName +
      "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd force " + this.pId + " " + this.taskName + " down";
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "FORCE DOWN");
      });
  }

  forceAllUp() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "FORCE All UP process on BIN Id '" +
      this.taskName +
      "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] = "shccmd force ALL up";
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "FORCE ALL UP");
      });
  }

  forceAllDown() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "FORCE All DOWN process on BIN Id '" +
      this.taskName +
      "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] = "shccmd force ALL down";
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "FORCE ALL DOWN");
      });
  }

  forceUpdate() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "UPDATE process on BIN Id '" + this.taskName + "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd update " + this.pId + " " + this.taskName + " update";
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "UPDATE");
      });
  }

  forceRoutesetUp() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "ROUTESET UP process on BIN Id '" +
      this.taskName +
      "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd routeset " +
      this.pId +
      " " +
      this.taskName +
      " " +
      this.count +
      " " +
      this.lastStart +
      " " +
      this.port +
      " up";
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "ROUTESET UP");
      });
  }

  forceRoutesetDown() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "ROUTESET DOWN process on BIN Id '" +
      this.taskName +
      "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd routeset " +
      this.pId +
      " " +
      this.taskName +
      " " +
      this.count +
      " " +
      this.lastStart +
      " " +
      this.port +
      " down";
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "ROUTESET DOWN");
      });
  }

  echoStart() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "ECHO-START process on BIN Id '" +
      this.taskName +
      "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd send echo-start to " + this.pId + " " + this.taskName;
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "ECHO-START");
      });
  }

  signOn() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "SIGN ON process on BIN Id '" + this.taskName + "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd send signon to " + this.pId + " " + this.taskName;
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "SIGN ON");
      });
  }

  signOff() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "SIGN OFF process on BIN Id '" + this.taskName + "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd send signoff to " + this.pId + " " + this.taskName;
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "SIGN OFF");
      });
  }

  signOnStart() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "SIGN ON START process on BIN Id '" +
      this.taskName +
      "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd send signon-start to " + this.pId + " " + this.taskName;
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "SIGN ON START");
      });
  }

  signOffStart() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "SIGN OFF START process on BIN Id '" +
      this.taskName +
      "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd send signoff-start to " + this.pId + " " + this.taskName;
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "SIGN OFF START");
      });
  }

  signOnGroup() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "SIGN ON GROUP process on BIN Id '" +
      this.taskName +
      "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd send signon-group to " + this.pId + " " + this.taskName;
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "SIGN ON GROUP");
      });
  }

  signOffGroup() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "SIGN OFF GROUP process on BIN Id '" +
      this.taskName +
      "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd send signoff-group to " + this.pId + " " + this.taskName;
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "SIGN OFF GROUP");
      });
  }

  safStart() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "SAF START process on BIN Id '" + this.taskName + "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd send saf-start to " + this.pId + " " + this.taskName;
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "SAF START");
      });
  }

  safStop() {
    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage =
      "SAF STOP process on BIN Id '" + this.taskName + "'  is in progress ...";

    this.dbParam["type"] = "TSKCMDCommandExecutionInsert";
    this.dbParam["insertCommand"] =
      "shccmd send saf-stop to " + this.pId + " " + this.taskName;
    this.dbParam["user"] = this.globals.userContext.userID;
    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.updateInsertProcess(x, this.taskName, "SAF STOP");
      });
  }

  updateInsertProcess(result: any[], excutedCommand: any, process: any): void {
    if (result !== undefined && result !== null && result.length > 0) {
      if (result && result[1] != 0) {
        this.waitingCount = Number(result[1]);
      }

      let count = 0;
      let intervalrun = setInterval(() => {
        count++;

        if (count == this.waitingCount) {
          this.fetchProcessAfterCommandExecution(excutedCommand, process);
        }

        if (count == Number(this.waitingCount) + 5) {
          this.displayProgressBar = false;
          this.displayMessage = "";
          this.cdr.detectChanges();
          clearInterval(intervalrun);
        }
      }, 5000);
    }
  }

  fetchProcessAfterCommandExecution(excutedCommand: any, process: any) {
    this.dbParam["type"] = "TSKCMDCommandExecutionFetchAfterInsert";
    this.dbParam["executedCommand"] = this.dbParam["insertCommand"];
    this.dbParam["user"] = this.globals.userContext.userID;

    this.instService
      .getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam)
      .subscribe((x: any[]) => {
        this.fetchProcessAfterCommandExecutionResult(
          x,
          excutedCommand,
          process
        );
      });
  }

  fetchProcessAfterCommandExecutionResult(
    result: any[],
    excutedCommand: any,
    process: any
  ): void {
    let messagetToDisp = "";

    if (result !== undefined && result !== null && result.length > 0) {
      if (result && result[0] == " ") {
        messagetToDisp =
          process +
          " process on BIN Id '" +
          excutedCommand +
          "' Execution is failed...";
      } else if (result[0] == "X") {
        messagetToDisp =
          process +
          " process on BIN Id '" +
          excutedCommand +
          "' Execution is success...";
      }

      this.displayMessage = messagetToDisp;
      this.displayProgressBar = true;

      this.cdr.detectChanges();
    }
  }

  goBack() {
    this.clearErrorMessage();
    this.globals.setErrorMessage("");
    this.location.back();
  }
}

