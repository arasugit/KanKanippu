import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';


@Component({
  selector: 'ca-pq-app',
  templateUrl: './ca-pq.component.html',
  styleUrls: ['./istCommandStyle.scss'],
  encapsulation: ViewEncapsulation.None
 })
export class CaPqComponent extends ListComponent implements OnInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'ca pq';
    this.criteria['product_id']= this.globals.productId;
    this.criteria['node_name']= this.globals.nodeName;
  }

  FORM_TITLE = 'Print Queue Details';
  exportFileName = 'Print Queue Details';

   taskName = '';
   istCommand = '';
   pId = '';

   queryPerm = new FormActionPermission('CA_PQ', 'Q');
   checkerPerm = new FormActionPermission('CA_PQ', 'C');
   mkcPerm = new MKCPermission('CA_PQ');


   ngOnInit() {
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'CA_PQ';
    this.metaDataId = 'CA_PQ';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }
}

