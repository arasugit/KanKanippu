import { AfterViewInit, Component, Injector, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent } from '../components/base-list.component';
import { StringMap } from '../common/criteria';
import { DataTableEditableComponent } from '../components';
import { DataTableService, GlobalsService } from '../services';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'trce-details-app',
  templateUrl: './trce-details.component.html'
 })
export class TrceDetailsComponent extends ListComponent implements OnInit, AfterViewInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  rowClicked: boolean = false;
  captureEvent: any;
  flag:any;
  param : string = '';
  paramValue : string = '';

  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef, private location:Location) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'otracecmd list';

    if(this.param && this.param === 'ValueForSwitchBoardTraceLevel') {
        this.criteria['fieldName'] = this.paramValue;
    }
  }

  FORM_TITLE = 'Trace Level Details';
  exportFileName = 'Trace Level Details';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   setAllButton: boolean = false;
   setTraceButton: boolean = true;

   waitingCount: Number = 3;

   displayProgressBar = false;
   displayMessage = '';
   dbParam: StringMap = {};
   commandEnteredByInpuText: any = '';

   queryPerm = new FormActionPermission('TRCDTLS', 'Q');
   checkerPerm = new FormActionPermission('TRCDTLS', 'C');
   mkcPerm = new MKCPermission('TRCDTLS');


   ngOnInit() {


    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);

    this.param = history.state.paramKey;
    this.paramValue = history.state.paramKeyValue;

    if(this.param && this.param === 'ValueForSwitchBoardTraceLevel') {
      this.showBackBtn = true;
    }
  }

  ngAfterViewInit(): void {
    this.doSearch();
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'TRCDTLS';
    this.metaDataId = 'TRCDTLS';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }

  onRowClick(event:any) {

    this.rowClicked = true;
    this.displayProgressBar = false;
    this.displayMessage = '';

    this.taskName = event.taskName?event.taskName:'';
    this.product = event.product?event.product:'';
    this.nodeId = event.nodeId?event.nodeId:'';

    this.captureEvent = event;
    this.dataTableComponent.changedRecords = event;

    this.setTraceButton = false;
  }

  setAll() {

    if(this.commandEnteredByInpuText == '' || this.commandEnteredByInpuText == 'none') {
      return;
    } else {
      this.displayProgressBar = true;
      this.displayMessage = "SET ALL process on command '" + this.commandEnteredByInpuText  + "' is in progress ...";

      this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
      this.dbParam['insertCommand'] = "otracecmd set ALL " + this.commandEnteredByInpuText;
      this.dbParam['user'] = this.globals.userContext.userID;

      this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
        this.updateInsertProcess(x, "SET ALL process on command '" + this.commandEnteredByInpuText  + "'");
      });
    }
  }

  setTrace() {

    if(this.commandEnteredByInpuText == '' || this.commandEnteredByInpuText == 'none') {
      return;
    } else {

      this.setTraceButton = true;

      this.displayProgressBar = true;
      this.displayMessage = "SET TRACE process on command '" + ' ' + this.taskName + ' & ' + this.commandEnteredByInpuText  + "' is in progress ...";

      this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
      this.dbParam['insertCommand'] = "otracecmd set " + this.taskName  + ' ' + this.commandEnteredByInpuText;
      this.dbParam['user'] = this.globals.userContext.userID;

      this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
        this.updateInsertProcess(x, "SET TRACE process on command '" + ' ' + this.taskName + ' & ' + this.commandEnteredByInpuText  + "'");
      });
    }
  }

  updateInsertProcess(result: any[], excutedCommand: any): void {
    if (result !== undefined && result !== null && result.length > 0) {

      if(result && result[1] != 0 ) {
        this.waitingCount = Number(result[1]);
      }

      let count = 0;
      let intervalrun = setInterval(() => {
        count++;

        if(count == this.waitingCount) {
          this.fetchProcessAfterCommandExecution(excutedCommand);
        }

        if(count == (Number(this.waitingCount)+5)) {
          this.displayProgressBar = false;
          this.displayMessage = '';
          this.cdr.detectChanges();
          clearInterval(intervalrun);
        }

      }, 5000)
    }
  }

  fetchProcessAfterCommandExecution(excutedCommand: any) {

    this.dbParam['type'] = 'TSKCMDCommandExecutionFetchAfterInsert';
    this.dbParam['executedCommand'] = "otracecmd set ALL " + this.commandEnteredByInpuText;
    this.dbParam['user'] = this.globals.userContext.userID;

    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.fetchProcessAfterCommandExecutionResult(x, excutedCommand);
    });

  }

  fetchProcessAfterCommandExecutionResult(result: any[], excutedCommand: any): void {

    let messagetToDisp = '';

    if (result !== undefined && result !== null && result.length > 0) {

      if(result  && result[0] == ' ') {
        messagetToDisp = excutedCommand + " Execution is failed...";
      } else if(result[0] == 'X') {
        messagetToDisp = excutedCommand + " Execution is success...";
      }

      this.displayMessage = messagetToDisp;
      this.displayProgressBar = true;

      this.cdr.detectChanges();
    }

  }

  onKey(event: any) { // without type info
    this.commandEnteredByInpuText = event.target.value;
  }

  goBack() {
    this.clearErrorMessage();
    this.globals.setErrorMessage('');
    this.location.back();
  }

}

