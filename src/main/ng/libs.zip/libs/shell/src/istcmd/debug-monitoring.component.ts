import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent} from '../components/base-list.component';
import { CustomValidators, LabelsAndValues, LabelAndValue, StringMap, StringUtil } from '../common';
import { T21Base } from '../components';
import { Location, DatePipe } from '@angular/common';

@Component({
    selector: 'debug-monitoring-app',
    templateUrl : './debug-monitoring.component.html',
    encapsulation: ViewEncapsulation.None
})

export class DebugMonitoringComponent extends ListComponent implements OnInit {

  constructor(injector: Injector, private location: Location, private datePipe: DatePipe) {
    super(injector);
  }

  FORM_TITLE = 'Debug Monitoring';
  exportFileName = 'Debug Monitoring';

   fileName : string = '';
   debugLevel : string = '';
   fromTime :  string = '';
   fromDate : string = '';
   dateTo : string = '';
   toTime : string = '';
   selectedInput : any = '';
   param :  string = '';
   paramValue :  string = '';
   currentDateTime: any;

   fileNamesList : LabelsAndValues = new LabelsAndValues();
   debugLevelsList : LabelsAndValues = new LabelsAndValues();
   debugLevelValues : string[] = ["FATAL","LOG","ERROR","WARNING","INFO","DUMP","DEBUG"];

  @ViewChild('toDateFocusField', { static: false })
  toDateFocusField: T21Base;

   queryPerm = new FormActionPermission('DEBUGM_REQ', 'Q');
   checkerPerm = new FormActionPermission('DEBUGM_REQ', 'C');
   mkcPerm = new MKCPermission('DEBUGM_REQ');

  onFileNameChange(event : any){
    this.selectedInput = event.target.value;
    this.fileName = this.selectedInput;
    console.log(` Selected fileName = ${this.fileName} `);
  }

  onDebugLevelChange(event : any){
    this.selectedInput = event.target.value;
    this.debugLevel = this.selectedInput;
    console.log(` Selected debugLevel = ${this.debugLevel}`);
  }

   adjustCriteria(): void {
    this.criteria['fromTime']= this.fromTime;
    this.criteria['toTime']=this.toTime;
    this.criteria['fileName']=this.fileName;
    this.criteria['debugLevel']=this.debugLevel;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';

    console.log(`Selected Params :: fileName = ${this.fileName} debugLevel = ${this.debugLevel}`);

    if(this.param && this.param === 'ValueForDebugOnFileName') {
      this.criteria['fileName'] = this.paramValue;
      this.criteria['fromDate']= this.currentDateTime;
      this.criteria['toDate'] = this.currentDateTime;
      this.criteria['fromTime']= "00:00:00";
      this.criteria['toTime'] = "23:59:59";
      this.showBackBtn = true;
    }
  }

  ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.instService.getDatabaseRecords("DEBUG_MTR_FILENAME_POPUP",null).subscribe((x: any[]) => { this.loadFileNamesList(x); });
    this.assignDebugLevelsList(this.debugLevelValues);

    this.setAutoRefreshSearch(true);

    this.currentDateTime = this.datePipe.transform((new Date), 'MM/dd/yyyy');
    console.log(this.currentDateTime);

    this.param = history.state.paramKey;
    this.paramValue = history.state.paramKeyValue;

    this.showBackBtn = false;

    if(this.paramValue.includes(" - ")) {
      this.paramValue = this.paramValue.replace(" - ", "");
    }

    let currentDateAndTime = this.datePipe.transform(new Date(), 'yyyy-MM-dd HH:mm:ss');

    if(this.param && this.param === 'ValueForDebugOnFileName') {
      this.fileName = this.paramValue;
      this.fromDate= this.currentDateTime;
      this.dateTo = this.currentDateTime;
      this.fromTime= "00:00:00";
      this.toTime = "23:59:59";
      this.showBackBtn = true;
    }
  }

  loadFileNamesList(result: string[]): void {
    this.fileNamesList.array = result.map((y: string): LabelAndValue => {
      return new LabelAndValue(y, y);
    });
  }

  assignDebugLevelsList(values: string[]): void {
    this.debugLevelsList.array = values.map((y: string): LabelAndValue => {
      return new LabelAndValue(y, y);
    });
  }

  ngAfterViewInit(): void {
    if(this.param && this.param === 'ValueForDebugOnFileName') {
      this.criteria['fileName'] = this.paramValue;
      this.doSearch();
    }

    console.log(this);
    this.setAutoRefreshInterval();

  }

  setT21Tags(): void {
	this.requestTypeId = 'DEBUGM_REQ';
	this.metaDataId = 'DEBUG_MTR_TAB';
	this.tabId = 'DEBUG_MTR_TAB';
	this.sectionId = 'DEBUG_MTR_SEC';
	this.collectionId = 'DEBUG_MTR_COL';
	}

  validateBeforeQuery(): boolean {
    CustomValidators.globals=this.globals;

    this.fromDate=CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo=CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat);
    let result:boolean;
    result= CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField);
  if(result){
    result= CustomValidators.validateTimeField(this.fromTime);
  }

  if(result){
   result= CustomValidators.validateTimeField(this.toTime);
  }

  if(result){
    result= CustomValidators.isFileNameEmpty(this.fileName);
   }

  return result;
}

goBack() {
  this.clearErrorMessage();
  this.globals.setErrorMessage('');
  this.location.back();
}

validateFromTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
validateToTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
getModuleName() { return 'IST-MONITORING'; }
emitModuleReady() { this.msgService.sendMessage(this.getModuleName()); }
}
