import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';


@Component({
  selector: 'mblook-st-app',
  templateUrl: './mblook-st.component.html',
  styleUrls: ['./istCommandStyle.scss'],
  encapsulation: ViewEncapsulation.None
 })
export class MblookStComponent extends ListComponent implements OnInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'mblook -t -s';
  }

  FORM_TITLE = 'IST Mail Box Info';
  exportFileName = 'IST Mail Box Info';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   queryPerm = new FormActionPermission('MBLOOKTS', 'Q');
   checkerPerm = new FormActionPermission('MBLOOKTS', 'C');
   mkcPerm = new MKCPermission('MBLOOKTS');


   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'MBLOOKTS';
    this.metaDataId = 'MBLOOKTS';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }
}

