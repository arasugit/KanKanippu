import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';
import { DataTableService, GlobalsService } from '../services';
import { Location } from '@angular/common';
import { WorkRequest } from '../ist-components';
import { StringMap } from '../common/criteria';

@Component({
  selector: 'task-cmd-app',
  templateUrl: './task-command.component.html'
 })
export class TaskCommandComponent extends ListComponent implements OnInit, AfterViewInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  captureEvent: any;
  displayProgressBar = false;
  displayMessage = '';

  commandEnteredByInpuText: any = '';

  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef, private location: Location) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'tskcmd';
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';

    if(this.param && this.param === 'ValueForTaskCommand') {
      if(this.paramValue.includes('Perm')) {
        this.criteria['fieldName'] = 'permanent';
      } else if(this.paramValue.includes('Temp')) {
        this.criteria['fieldName'] = 'temporary';
      }
    }
  }

  FORM_TITLE = 'Task Command List';
  exportFileName = 'Task Command List';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';
   killButton: boolean = true;
   runButton: boolean = true;
   workRequest:WorkRequest;
   isCompleted: any = false;
   waitingCount: Number = 3;
   rowClicked: boolean = false;
   param : string = '';
   paramValue : string = '';

   queryPerm = new FormActionPermission('TSKCMD', 'Q');
   checkerPerm = new FormActionPermission('TSKCMD', 'C');
   mkcPerm = new MKCPermission('TSKCMD');
   dbParam: StringMap = {};

   noExecuteCommand = ['istcomgr', 'oasisvm', 'mb', 'mblima', 'mbtm 0', 'mbrns',
                      'mbport', 'mbpiped', 'mbrm', 'mbStatMgr', 'mbPtmMgr', 'txnstatmgr'];

   ngOnInit() {

    super.ngOnInit();

    this.showBackBtn = false;

    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);

    this.param = history.state.paramKey;
    this.paramValue = history.state.paramKeyValue;

    if(this.param && this.param === 'ValueForTaskCommand') {
      this.showBackBtn = true;
    }


  }

  ngAfterViewInit(): void {
    this.doSearch();
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'TSKCMD';
    this.metaDataId = 'TSKCMD';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }


  onRowClick(event:any) {

    this.rowClicked = true;
    this.displayProgressBar = false;
    this.displayMessage = '';

    this.taskName = event.taskName?event.taskName:'';
    this.product = event.product?event.product:'';
    this.nodeId = event.nodeId?event.nodeId:'';

    this.captureEvent = event;
    this.dataTableComponent.changedRecords = event;

    this.runButton = false;
    this.killButton = false;

  }

  kill() {
    this.killButton = true;
    this.runButton = true;
    this.rowClicked = false;

    this.displayProgressBar = true;

    if(this.noExecuteCommand.includes(this.taskName)) {
      this.displayMessage = "This command '" + this.taskName + "' cannot be executed...";
      return;
    } else {
      this.displayMessage = "KILL process on command '" + this.taskName  + "' is in progress ...";
    }

    this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
    this.dbParam['insertCommand'] = "mbcmd kill " + this.taskName;
    this.dbParam['user'] = this.globals.userContext.userID;
    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.updateInsertProcess(x, this.taskName, "KILL");
    });
  }

  updateInsertProcess(result: any[], excutedCommand: any, process: any): void {
    if (result !== undefined && result !== null && result.length > 0) {

      if(result && result[1] != 0 ) {
        this.waitingCount = Number(result[1]);
      }

      let count = 0;
      let intervalrun = setInterval(() => {
        count++;

        if(count == this.waitingCount) {
          this.fetchProcessAfterCommandExecution(excutedCommand, process);
        }

        if(count == (Number(this.waitingCount)+5)) {
          this.displayProgressBar = false;
          this.displayMessage = '';
          this.cdr.detectChanges();
          clearInterval(intervalrun);
        }

      }, 5000)
    }
  }

  fetchProcessAfterCommandExecution(excutedCommand: any, process: any) {

    this.dbParam['type'] = 'TSKCMDCommandExecutionFetchAfterInsert';
    this.dbParam['executedCommand'] = this.dbParam['insertCommand'];
    this.dbParam['user'] = this.globals.userContext.userID;

    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.fetchProcessAfterCommandExecutionResult(x, excutedCommand, process);
    });

  }

  fetchProcessAfterCommandExecutionResult(result: any[], excutedCommand: any, process: any): void {
    let messagetToDisp = '';

    if (result !== undefined && result !== null && result.length > 0) {
      if(result  && result[0] == ' ') {
        messagetToDisp = process + " Command '" + excutedCommand + "' Execution is failed...";
      } else if(result[0] == 'X') {
        messagetToDisp = process + " Command '" + excutedCommand + "' Execution is success...";
      }

      this.displayMessage = messagetToDisp;
      this.displayProgressBar = true;

      this.cdr.detectChanges();
    }

  }

  run() {

    let specifiedCommand = '';
    let commandToExecute  = '';
    this.displayProgressBar = true;

    specifiedCommand = this.taskName;
    commandToExecute = "mbcmd run " + this.taskName;

    if(!this.rowClicked) {
      if(this.commandEnteredByInpuText && this.commandEnteredByInpuText !== '') {
        specifiedCommand = this.commandEnteredByInpuText;
        commandToExecute = "mbcmd run " + this.commandEnteredByInpuText;
      }
    }

    if(this.noExecuteCommand.includes(specifiedCommand)) {
      this.displayMessage = "This command '" + specifiedCommand + "' cannot be executed...";
      return;
    } else {
      this.displayMessage = "RUN process on command '" + specifiedCommand  + "' is in progress ...";
      this.commandEnteredByInpuText = '';
    }

    this.killButton = true;
    this.runButton = true;
    this.rowClicked = false;

    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='insert';

    this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
    this.dbParam['insertCommand'] = commandToExecute;
    this.dbParam['user'] = this.globals.userContext.userID;

    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.updateInsertProcess(x, specifiedCommand, "RUN");
    });

  }

  onKey(event: any) { // without type info
    this.commandEnteredByInpuText = event.target.value;

    if(event.target.value && event.target.value.length > 0) {
      this.runButton = false;
    } else {
      this.runButton = true;
    }
  }

  goBack() {
    this.clearErrorMessage();
    this.globals.setErrorMessage('');
    this.location.back();
  }

}



