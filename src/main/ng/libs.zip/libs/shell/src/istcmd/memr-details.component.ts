import { Component, Injector, OnInit, ChangeDetectorRef } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { StringMap } from '../common/criteria';


@Component({
  selector: 'memr-details-app',
  templateUrl: './memr-details.component.html'
 })
export class MemrDetailsComponent extends ListComponent implements OnInit {
  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'mbrulecmd list';
  }

  FORM_TITLE = 'Memory Rule based Information';
  exportFileName = 'emory Rule based Information';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';
   updateButton: boolean = true;
   workRequest:WorkRequest;
   displayProgressBar = false;
   displayMessage = '';
   dbParam: StringMap = {};

   waitingCount: Number = 3;

   queryPerm = new FormActionPermission('MEMDTLS', 'Q');
   checkerPerm = new FormActionPermission('MEMDTLS', 'C');
   mkcPerm = new MKCPermission('MEMDTLS');


   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    this.doSearch();
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'MEMDTLS';
    this.metaDataId = 'MEMDTLS';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }


  onRowClick(event:any) {

    this.taskName = event.taskName?event.taskName:'';
    this.product = event.product?event.product:'';
    this.nodeId = event.nodeId?event.nodeId:'';

    this.updateButton = false;
    this.displayProgressBar = false;
    this.displayMessage = '';

  }

  update() {
    this.updateButton = true;
    this.displayProgressBar = true;
    this.displayMessage = "UPDATE process on command '" + this.taskName  + "' is in progress ...";

    this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
    this.dbParam['insertCommand'] = "mbrulecmd update " + this.taskName;
    this.dbParam['user'] = this.globals.userContext.userID;

    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.updateInsertProcess(x, this.taskName);
    });
  }

  updateInsertProcess(result: any[], excutedCommand: any): void {
    if (result !== undefined && result !== null && result.length > 0) {

      if(result && result[1] != 0 ) {
        this.waitingCount = Number(result[1]);
      }

      let count = 0;
      let intervalrun = setInterval(() => {
        count++;

        if(count == this.waitingCount) {
          this.fetchProcessAfterCommandExecution(excutedCommand);
        }

        if(count == (Number(this.waitingCount)+5)) {
          this.displayProgressBar = false;
          this.displayMessage = '';
          this.cdr.detectChanges();
          clearInterval(intervalrun);
        }

      }, 5000)
    }
  }

  fetchProcessAfterCommandExecution(excutedCommand: any) {

    this.dbParam['type'] = 'TSKCMDCommandExecutionFetchAfterInsert';
    this.dbParam['executedCommand'] = this.dbParam['insertCommand'];
    this.dbParam['user'] = this.globals.userContext.userID;

    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.fetchProcessAfterCommandExecutionResult(x, excutedCommand);
    });

  }

  fetchProcessAfterCommandExecutionResult(result: any[], excutedCommand: any): void {

    let messagetToDisp = '';

    if (result !== undefined && result !== null && result.length > 0) {

      if(result  && result[0] == ' ') {
        messagetToDisp = "UPDATE Command '" + excutedCommand + "' Execution is failed...";
      } else if(result[0] == 'X') {
        messagetToDisp = "UPDATE Command '" + excutedCommand + "' Execution is success...";
      }

      this.displayMessage = messagetToDisp;
      this.displayProgressBar = true;

      this.cdr.detectChanges();
    }

  }


}

