import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';
import { Location } from '@angular/common';

@Component({
  selector: 'mbcd-options-app',
  templateUrl: './mbcd-options.component.html',
  styleUrls: ['./istCommandStyle.scss'],
  encapsulation: ViewEncapsulation.None
 })
export class MbcdOptionsComponent extends ListComponent implements OnInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, private location: Location) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'mbcmd options';
  }

  FORM_TITLE = 'IST Basic Configurations';
  exportFileName = 'IST Basic Configurations';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';
   output = '';
   param :  string = '';
   paramValue :  string = ''
   showBackBtn = false;

   queryPerm = new FormActionPermission('MBCDOPTS', 'Q');
   checkerPerm = new FormActionPermission('MBCDOPTS', 'C');
   mkcPerm = new MKCPermission('MBCDOPTS');


   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);   
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);

    this.param = history.state.paramKey;
    this.paramValue = history.state.paramKeyValue;

    if(this.param && this.param === 'ValueForAllocatedBasicConfigurations') {
      this.showBackBtn = true;
    }
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'MBCDOPTS';
    this.metaDataId = 'MBCDOPTS';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }

  goBack() {
    this.clearErrorMessage();
    this.globals.setErrorMessage('');
    this.location.back();
  }
}

