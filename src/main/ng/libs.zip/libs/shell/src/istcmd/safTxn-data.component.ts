import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';


@Component({
  selector: 'saftxn-data-app',
  templateUrl: './saftxn-data.component.html',
  styleUrls: ['./istCommandStyle.scss'],
  encapsulation: ViewEncapsulation.None
 })
export class SafTxnDataComponent extends ListComponent implements OnInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'istadvicecmd list';
  }

  FORM_TITLE = 'IST SAF and Transactions';
  exportFileName = 'IST SAF and Transactions';
   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   queryPerm = new FormActionPermission('SAFTXNDATA', 'Q');
   checkerPerm = new FormActionPermission('SAFTXNDATA', 'C');
   mkcPerm = new MKCPermission('SAFTXNDATA');


   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'SAFTXNDATA';
    this.metaDataId = 'SAFTXNDATA';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }
}

