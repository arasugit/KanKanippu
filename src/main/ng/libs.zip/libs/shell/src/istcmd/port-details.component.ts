import { AfterViewInit, Component, Injector, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { GlobalsService } from '../services';
import { StringMap } from '../common/criteria';
import { LabelAndValue, LabelsAndValues } from '../common';
import { Location } from '@angular/common';
import { DataTableEditableComponent } from '../components';

@Component({
  selector: 'port-details-app',
  templateUrl: './port-details.component.html'
 })
export class PortDetailsComponent extends ListComponent implements OnInit, AfterViewInit {

  @ViewChild('tskcmdTable', { static: false })
  dataTableComponent: DataTableEditableComponent

  constructor(injector: Injector, private cdr: ChangeDetectorRef, private location:Location ) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['CommandType']= 'mbportcmd list';
    this.criteria['serverMail'] = this.serverMail;
    this.criteria['fieldName'] = this.fieldName;

    if(this.portFlags) {
      this.criteria['portFlags'] = this.portFlags;
    }
  }

  FORM_TITLE = 'PORT Details on BIN, ATM, Device, network';
  exportFileName = 'PORT Details';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';
   taskType = '';
   fieldName = '';
   serverMail = '';
   portFlags : string = '';
   portFlagsList : LabelsAndValues = new LabelsAndValues();

  addButton: boolean = true;
  updateButton: boolean = true;
  startButton: boolean = true;
  stopButton: boolean = true;
  traceButton: boolean = true;
  reconnectButton: boolean = true;

  waitingCount: Number = 3;

  displayProgressBar = false;
  displayMessage = '';

  commandEnteredByInpuText: any = '';
  rowClicked: boolean = false;

  dbParam: StringMap = {};

   queryPerm = new FormActionPermission('PRTDTLS', 'Q');
   checkerPerm = new FormActionPermission('PRTDTLS', 'C');
   mkcPerm = new MKCPermission('PRTDTLS');


   ngOnInit() {
    this.portFlagsList.array = [new LabelAndValue('', ''), new LabelAndValue('Down', 'Down'), new LabelAndValue('Stopped', 'Stopped'), new LabelAndValue('Active listen', 'Active listen'),
    new LabelAndValue('Passive listen', 'Passive listen'),new LabelAndValue('Connected', 'Connected'), new LabelAndValue('Connected|Active listen', 'Connected|Active listen'), new LabelAndValue('Connected|Passive listen', 'Connected|Passive listen')];

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);

    this.isRedirected=GlobalsService.isRedirected;
    this.showBackBtn=GlobalsService.isRedirected;
    GlobalsService.param='';

    const param = history.state.paramKey;
    const paramValue = history.state.paramKeyValue;

    if (param == 'ServerMailBoxId') {
      this.serverMail = paramValue;
      this.showBackBtn = true;
    }
    else if (param == 'PortStatus') {
      this.portFlags = paramValue;
      this.showBackBtn = true;
    }
  }

  ngAfterViewInit(): void {
    this.doSearch();
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'PRTDTLS';
    this.metaDataId = 'PRTDTLS';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  }

  toggleButtons(buttonStateDisable: boolean) {
    this.addButton = buttonStateDisable;
    this.updateButton = buttonStateDisable;
    this.startButton = buttonStateDisable;
    this.stopButton = buttonStateDisable;
    this.traceButton = buttonStateDisable;
    this.reconnectButton = buttonStateDisable;
  }

  onRowClick(event:any) {
    this.displayProgressBar = false;
    this.displayMessage = '';
    this.rowClicked = true;

    this.taskName = event.taskName?event.taskName:'';
    this.product = event.product?event.product:'';
    this.nodeId = event.nodeId?event.nodeId:'';
    this.taskType = event.taskType?event.taskType:'';

    this.toggleButtons(false);

  }

  add() {

    this.toggleButtons(true);

    let specifiedCommand = '';
    specifiedCommand = this.taskType;

    if(!this.rowClicked) {
      if(this.commandEnteredByInpuText && this.commandEnteredByInpuText !== '') {
        specifiedCommand = this.commandEnteredByInpuText;
      }
    }

    this.displayProgressBar = true;
    this.displayMessage = "ADD process on command '" + specifiedCommand  + "' is in progress ...";

    this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
    this.dbParam['insertCommand'] = "mbportcmd add " + specifiedCommand;
    this.dbParam['user'] = this.globals.userContext.userID;
    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.updateInsertProcess(x, specifiedCommand, "ADD");
    });

  }

  update() {

    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage = "UPDATE process on command '" + this.taskType  + "' is in progress ...";

    this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
    this.dbParam['insertCommand'] = "mbportcmd update " + this.taskType;
    this.dbParam['user'] = this.globals.userContext.userID;
    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.updateInsertProcess(x, this.taskType, "UPDATE");
    });

  }

  start() {

    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage = "START process on command '" + this.taskType  + "' is in progress ...";

    this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
    this.dbParam['insertCommand'] = "mbportcmd start " + this.taskType;
    this.dbParam['user'] = this.globals.userContext.userID;
    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.updateInsertProcess(x, this.taskType, "START");
    });
  }

  stop() {

    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage = "STOP process on command '" + this.taskType  + "' is in progress ...";

    this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
    this.dbParam['insertCommand'] = "mbportcmd stop " + this.taskType;
    this.dbParam['user'] = this.globals.userContext.userID;
    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.updateInsertProcess(x, this.taskType, "STOP");
    });
  }

  trace() {

    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage = "TRACE process on command '" + this.taskType  + "' is in progress ...";

    this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
    this.dbParam['insertCommand'] = "mbportcmd trace " + this.taskType + " on";
    this.dbParam['user'] = this.globals.userContext.userID;
    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.updateInsertProcess(x, this.taskType, "TRACE");
    });
  }

  reconnect() {

    this.toggleButtons(true);

    this.displayProgressBar = true;
    this.displayMessage = "RECONNECT process on command '" + this.taskType  + "' is in progress ...";

    this.dbParam['type'] = 'TSKCMDCommandExecutionInsert';
    this.dbParam['insertCommand'] = "mbportcmd reconnect " + this.taskType;
    this.dbParam['user'] = this.globals.userContext.userID;
    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.updateInsertProcess(x, this.taskType, "RECONNECT");
    });
  }

  updateInsertProcess(result: any[], excutedCommand: any, process: any): void {
    if (result !== undefined && result !== null && result.length > 0) {

      if(result && result[1] != 0 ) {
        this.waitingCount = Number(result[1]);
      }

      let count = 0;
      let intervalrun = setInterval(() => {
        count++;

        if(count == this.waitingCount) {
          this.fetchProcessAfterCommandExecution(excutedCommand, process);
        }

        if(count == (Number(this.waitingCount)+5)) {
          this.displayProgressBar = false;
          this.displayMessage = '';
          this.cdr.detectChanges();
          clearInterval(intervalrun);
        }

      }, 5000)
    }
  }

  fetchProcessAfterCommandExecution(excutedCommand: any, process: any) {

    this.dbParam['type'] = 'TSKCMDCommandExecutionFetchAfterInsert';
    this.dbParam['executedCommand'] = this.dbParam['insertCommand'];
    this.dbParam['user'] = this.globals.userContext.userID;

    this.instService.getDatabaseRecords("CMDEXECUTION-INSERT", this.dbParam).subscribe((x: any[]) => {
      this.fetchProcessAfterCommandExecutionResult(x, excutedCommand, process);
    });

  }


  fetchProcessAfterCommandExecutionResult(result: any[], excutedCommand: any, process: any): void {
    let messagetToDisp = '';

    if (result !== undefined && result !== null && result.length > 0) {
      if(result  && result[0] == ' ') {
        messagetToDisp = process + " Command '" + excutedCommand + "' Execution is failed...";
      } else if(result[0] == 'X') {
        messagetToDisp = process + " Command '" + excutedCommand + "' Execution is success...";
      }

      this.displayMessage = messagetToDisp;
      this.displayProgressBar = true;

      this.cdr.detectChanges();
    }

  }

  onKey(event: any) { // without type info
    this.commandEnteredByInpuText = event.target.value;

    if(event.target.value && event.target.value.length > 0) {
      this.addButton = false;
    } else {
      this.addButton = true;
    }
  }

  goBack() {
    this.clearErrorMessage();
    this.globals.setErrorMessage('');
    this.location.back();
  }
}

