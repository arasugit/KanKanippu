import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class ISTMonManagerPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.ISTMonManagerPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
