import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class FormActionPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.FormActionPermission';

  constructor(name: string, action: string) {
    super();
    this.name = name;
    this.action = action;
  }
}
