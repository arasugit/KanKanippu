import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class GenKlcKeysPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.GenKlcKeysPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
