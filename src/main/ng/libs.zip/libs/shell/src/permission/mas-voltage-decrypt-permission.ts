import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class VoltageDecryptPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.VoltageDecryptPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
