import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class FormTabPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.FormTabPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
