import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class MBStartStopPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.MBStartStopPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
