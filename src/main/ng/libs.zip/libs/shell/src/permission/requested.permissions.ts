// $Id$
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map ,  tap } from 'rxjs/operators';
import { MenuService } from '../services/menu.service';
import { RequestedPermission } from './requested.permission';

@Injectable()
export class RequestedPermissions {
  public permsArr: RequestedPermission[] = [];

  constructor(private menuService: MenuService) { }

  getPermission(url: String): void {
    //  console.log('Request Screen Permission' + JSON.stringify(this.permsArr, null, 2));
    this.menuService.checkPermissions(url, this.permsArr).subscribe(
      (result: RequestedPermission[]) => this.onGotPermission(result),
      err => this.onErrorGotPermission(err)
    );
  }

  // called in base list and detail classess
  getPermission2(url: String): Observable<boolean> {
    let statusMsg = false;
    return this.menuService.checkPermissions(url, this.permsArr).pipe(
      tap(
        (result: RequestedPermission[]) => { this.onGotPermission(result); statusMsg = true; },
        err => { this.onErrorGotPermission(err); statusMsg = false; }
      ),
      map(() => statusMsg)
    );
  }

  /**
   * Copies the 'allowed' flag to the original array of requested permissions
   * Expects to receive the permissions in the same sequence in which they were sent
   * @param result
   * Array of received permisisons, with the allowed flag set
   */
  onGotPermission(result: RequestedPermission[]): void {
    // console.log('Response Screen Permission ', JSON.stringify(result, null, 2));
    const n1 = this.permsArr.length;
    const n2 = result.length;
    if (n1 !== n2) {
      throw new Error('Number of permissions returned different from number requested');
    }
    for (let i = 0; i < n1; ++i) {
      this.permsArr[i].allowed = !!result[i].allowed;
    }
  }

  onErrorGotPermission(error: Object): void {
  }

}
