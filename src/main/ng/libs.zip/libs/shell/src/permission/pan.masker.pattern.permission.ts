import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class PanMaskerPatternPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.PanMaskerPatternPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
