
import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class MKCPermission extends RequestedPermission {
  private readonly remoteClass = 'com.fis.ist.services.vo.MKCPermission';
  constructor(name: string) {
    super();
    this.name = name;
  }
}
