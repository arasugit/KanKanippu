import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class ISTMonCommandPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.ISTMonCommandPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
