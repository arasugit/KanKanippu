import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class VolumeLicensePermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.VolumeLicensePermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
