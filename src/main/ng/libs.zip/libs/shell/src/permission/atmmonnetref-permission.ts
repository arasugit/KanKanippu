import { RequestedPermission } from './requested.permission';

export class AtmMonNetAutoRefreshPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.AtmMonNetAutoRefreshPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
