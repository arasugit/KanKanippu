import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class FormPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.FormPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
