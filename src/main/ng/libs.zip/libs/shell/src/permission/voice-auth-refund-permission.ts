import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class VoiceAuthRefundPermission extends RequestedPermission {

  private readonly remoteClass = 'com.fis.ist.services.vo.VoiceAuthRefundPermission';
  constructor() {
    super();
  }
}
