// $Id$
import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class FormButtonPermission extends RequestedPermission {

  private action: String;
  private remoteClass: String = 'com.fis.ist.services.vo.FormButtonPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
