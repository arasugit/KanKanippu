import { Injectable } from '@angular/core';
import { RequestedPermission } from './requested.permission';

export class ISTUnixCommandPermission extends RequestedPermission {

  private action: string;
  private readonly remoteClass = 'com.fis.ist.services.vo.ISTUnixCommandPermission';

  constructor(name: string) {
    super();
    this.name = name;
  }
}
