import { Injectable } from '@angular/core';

export class RequestedPermission {
    public name: string;
    public allowed?: boolean;
}
