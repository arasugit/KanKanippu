import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent, RendererItem } from '../components';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { IstDatePickerColumnRendererComponent } from '../ist-components';
import { LabelsAndValues } from '../common/labels-and-values';


@Component({
  selector: 'mon-glbVal-app',
  templateUrl: './mon-glbVal.component.html'
 })
export class MonGlbValComponent extends ListComponent implements OnInit, AfterViewInit {
  [x: string]: any;

  @ViewChild('monGlbValTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['COMMAND']='query';
  }

  FORM_TITLE = 'Global Value View';
  exportFileName= 'Global Value View';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   workRequest:WorkRequest;

   queryPerm = new FormActionPermission('MONGLBVAL', 'Q');
   insertPerm = new FormActionPermission('MONGLBVAL', 'I');
   updatePerm = new FormActionPermission('MONGLBVAL', 'U');
   deletePerm = new FormActionPermission('MONGLBVAL', 'D');
   checkerPerm = new FormActionPermission('MONGLBVAL', 'C');
   mkcPerm = new MKCPermission('MONGLBVAL');

   startDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
   endDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
   deptList: LabelsAndValues = new LabelsAndValues();

   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.insertPerm);
    this.requestPerms.permsArr.push(this.updatePerm);
    this.requestPerms.permsArr.push(this.deletePerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  validateBeforeQuery(): boolean {
    return true;
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'MONGLBVAL';
    this.metaDataId = 'MONGLBVAL';
    this.tabId = 'MONGLBVALTAB';
    this.sectionId = 'MONGLBVALSEC';
    this.collectionId = 'MONGLBVALCOL';
  }


  onRowClick(event:any) {
    console.log("Inside OnRowClick " + event);
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
  }
}



