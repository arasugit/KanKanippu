export * from './mon-glbVal.module';
export * from './mon-glbVal.component';
