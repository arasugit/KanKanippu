import { ChartDTO } from "./chart-dto";

export class ChartMultiDTO {
  name: string;
  series: ChartDTO[];

  constructor(name: string, value: ChartDTO[]) {
    this.name = name;
    this.series = value;
  }
}
