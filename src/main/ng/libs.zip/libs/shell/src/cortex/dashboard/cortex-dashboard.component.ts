import { Component, ViewEncapsulation, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef } from '@angular/core';
import { finalize, first } from 'rxjs/operators';
import { MON_ATM_COLOR_SETS } from '../../home/ngx-charts-color-sets';
import { ListComponent } from '../../components';
import { DataTableService } from '../../services';
import { WorkRequest } from '../../ist-components';
import { ChartDTO } from '../chart-dto';
import { HighChartDto } from '../chart-dto';
import { ChartMultiDTO } from '../chart-multi-dto';
import { LabelAndValue, LabelsAndValues } from '../../common/labels-and-values';
import { CustomValidators } from '../../common';
import { FormActionPermission, MKCPermission } from '../../permission';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);

@Component({
  selector: 'cortex-dashboard',
  templateUrl: './cortex-dashboard.component.html',
  styleUrls: ['../../transaction/transaction.scss', './cortex-dashboard.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class CortexDashboardComponent extends ListComponent implements OnDestroy {
  view: any[] = [850, 300];
  screenType: any;
  dashboardData: any[];
  showChart: boolean = false;
  cardDetails: any = [];
  timeRangeData: LabelsAndValues = new LabelsAndValues();
  range: string;
  isSearchReq: boolean = false;
  fromDate: string = '';
  dateTo: string = '';
  public activeCardData:any[];
  public inactiveCardData:any[];
  public totalCardData:any[];
  public logDateData:any[] =[];
  Highcharts: typeof Highcharts = Highcharts;
  cardUsageChart: Highcharts.Options;
  colorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };

  constructor(private injector: Injector, private dataService: DataTableService, private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker) {
    super(injector);
  }

  ngOnInit() {
    this.range = "1MON";
    super.ngOnInit();

    this.requestPerms.permsArr = [];
    this.queryPerm = new FormActionPermission('CTXDASH', 'Q');
    this.mkcPerm = new MKCPermission('CTXDASH');

    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.getPermission(this.router.url);

    this.timeRangeData.array = [new LabelAndValue('1 Month', '1MON'), new LabelAndValue('Custom', 'custom')];

    this.route
      .data
      .pipe(first())
      .subscribe(v => this.screenType = v['module']);

    this.setAutoRefreshSearch(true);
  }

  adjustCriteria(): void {
    this.globals.setErrorMessage('');
    this.criteria['dateRange'] = this.range;
    this.criteria['fromDate'] = this.fromDate;
    this.criteria['toDate'] = this.dateTo;
   // this.criteria['productId'] = 'ISTSWT';
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
  }

  retriveData(): void {
    this.dataService.requestType = this.requestTypeId;
    this.dataService.collectionTag = this.collectionId;
    this.dataService.action = 'query';
    this.dataService.criteria = this.criteria;

    this.dataService
      .loadData(false)
      .pipe(
        first(),
        finalize(() => this.globals.hideLoadingBar())
      )
      .subscribe(
        {
          next: (atmData: any) => this.onGotRecords(atmData),
          error: (error: any) => this.onErrorGotRecords(error)
        }
      );
      this.cdr.detectChanges();
  }





  onGotRecords(wr: WorkRequest): void {
    const workRequest = wr;

    if (workRequest.lastModified == -1) {
      this.globals.setErrorMessage('No Data found');
      this.cdr.detectChanges();
      return;
    }

    if (workRequest == null || workRequest == undefined
      || workRequest.collections == null || workRequest.collections[this.collectionId] == null
      || workRequest.collections[this.collectionId].rows == null
      || workRequest.collections[this.collectionId].rows == undefined
      || workRequest.collections[this.collectionId].rows.length == 0) {
      return;
    }

    this.showChart = true;
    const rows = workRequest.collections[this.collectionId].rows;

    let multiDtoList: ChartMultiDTO[] = [];
    let activeCardDtoList: ChartDTO[] = [];
    let inactiveCardDtoList: ChartDTO[] = [];
    let totalCardDtoList: ChartDTO[] = [];

    rows.forEach((c, index) => {
      let activeCardDto = new ChartDTO(c.logDate, c.activeCount);
      let inactiveCardDto = new ChartDTO(c.logDate, c.inactiveCount);
      let totalCardDto = new ChartDTO(c.logDate, c.activeCount + c.inactiveCount);
      this.logDateData.push(c.logDate);
      activeCardDtoList.push(activeCardDto);
      inactiveCardDtoList.push(inactiveCardDto);
      totalCardDtoList.push(totalCardDto);
    });

    multiDtoList.push(new ChartMultiDTO("Active", activeCardDtoList));
    multiDtoList.push(new ChartMultiDTO("Inactive", inactiveCardDtoList));
    multiDtoList.push(new ChartMultiDTO("Total", totalCardDtoList));
    this.dashboardData = JSON.parse(JSON.stringify(multiDtoList));

    this.adjustChartViewWidth(rows.length);
    this.cdr.markForCheck();

    //****High Chart implementation ****
    let activeCount = 0;
    let inactiveCount = 0;
    let totalCount = 0;
    let activeChartDtoList: HighChartDto[] = [];
    let inactiveChartDtoList: HighChartDto[] = [];
    let totalChartDtoList: HighChartDto[] = [];
    activeCardDtoList.forEach(c => {
      var activeCards = c.value;
      var activeCardsLogDate = c.name;
      if (+activeCards == 0)
        return;
      let activeChartDto = new HighChartDto(activeCardsLogDate, parseInt(activeCards));
      if(activeCount < activeCardDtoList.length) {
        activeChartDtoList.push(activeChartDto);
      }
      activeCount++;
    })
    inactiveCardDtoList.forEach(c => {
      var inactiveCards = c.value;
      var inactiveCardsLogDate = c.name;
      if (+inactiveCards == 0)
        return;
      let inactiveChartDto = new HighChartDto(inactiveCardsLogDate, parseInt(inactiveCards));
      if(inactiveCount < inactiveCardDtoList.length) {
        inactiveChartDtoList.push(inactiveChartDto);
      }
      inactiveCount++;
    })
    totalCardDtoList.forEach(c => {
      var totalCards = c.value;
      var totalCardsLogDate = c.name;
      if (+totalCards == 0)
        return;
      let totalChartDto = new HighChartDto(totalCardsLogDate, parseInt(totalCards));
      if(totalCount < totalCardDtoList.length) {
        totalChartDtoList.push(totalChartDto);
      }
      totalCount++;
    })
    this.activeCardData =  activeChartDtoList;
    this.inactiveCardData = inactiveChartDtoList;
    this.totalCardData = totalChartDtoList;
    //Chart - (Cortex Dashboard)
    this.cardUsageChart= {
      chart: {
        // height: 350,
        inverted: false,
      },
      credits:{
        enabled: false,
      },
      title: {
        text: 'Cortex Dashboard',
        align: 'left'
    },
    yAxis: {
        title: {
            text: 'Number of Cards'
        }
    },
    xAxis: {
      categories: this.logDateData,
      title: {
        text: 'Log Date'
    }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },
    plotOptions: {
      spline: {
          marker: {
              radius: 4,
              lineColor: '#666666',
              lineWidth: 1
          }
      }
  },
    series: [{
        name: 'Active Card Data',
        data: this.activeCardData
    }, {
        name: 'Inactive Card Data',
        data: this.inactiveCardData
    }, {
        name: 'Total Card Data',
        data: this.totalCardData
    }] as any,
    responsive: {
        rules: [{
            condition: {
                // maxWidth: 500
            },
            chartOptions: {
                legend: {
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom'
                }
            }
        }]
    }
}
  }

  getChartMultiItem(logDate: string, count: any, status: any) {
    let cardDto = new ChartDTO(logDate, count);
    let chartDtoList = [cardDto];
    return new ChartMultiDTO(status, chartDtoList);
  }

  adjustChartViewWidth(rowCount: number) {
    if (rowCount > 16)
      this.view = [rowCount * 50, 300];
    else
      this.view = [850, 300];
  }

  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  setT21Tags(): void {
    this.requestTypeId = 'CTXDASH';
    this.metaDataId = 'CTXDASH';
    this.tabId = 'CTXDASH_TAB';
    this.sectionId = 'CTXDASH_SEC';
    this.collectionId = 'CTXDASH_COL';
  }

  get darkMode(): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
    this.clearErrorMessage();
  }

  validateBeforeQuery(): boolean {
    CustomValidators.globals = this.globals;
    let result: boolean = true;
    if(this.range != "1MON") {
      this.fromDate = CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
      this.dateTo = CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat);


      if (CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField)) {
        if (CustomValidators.isFutureDate(CustomValidators.convertToDate(this.fromDate, this.globals.dateFormat)) ||
          CustomValidators.isFutureDate(CustomValidators.convertToDate(this.dateTo, this.globals.dateFormat))) {
          this.globals.setErrorMessage('Future Dates are not allowed!');
          result = false;
        }
      } else {
        result = false;
      }
    }
    return result;
  }

  changeHandler(event: any) {
    this.globals.setErrorMessage('');
    this.showChart = false;

    if (event === null) return;

    this.range = event;
    if (event == '1MON') {
      this.isSearchReq = false;
      this.fromDate = '';
      this.dateTo = '';
      this.adjustCriteria();
      this.retriveData();
    } else {
      this.isSearchReq = true;
    }
  }

  search(): void {
    this.showChart = false;
    this.cdr.detectChanges();
    if (this.validateBeforeQuery()) {
      this.adjustCriteria();
      this.retriveData();
    }
  }

  clear(): void {
    this.globals.setErrorMessage('');
    this.fromDate = "MM/dd/yyyy";
    this.dateTo = "MM/dd/yyyy";
  }
}
