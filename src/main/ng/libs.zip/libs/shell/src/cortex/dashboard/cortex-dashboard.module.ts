import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RufCardModule } from '@ruf/shell';
import { ISTComponentModule } from '../../ist-components';
import { MON_TOOL, MonitorComponentData } from '../../monitor-components/common-object';
import { CortexDashboardComponent } from './cortex-dashboard.component';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HighchartsChartModule } from 'highcharts-angular';

export const cortexDashboardData: MonitorComponentData = {
  title: 'Cortex Dashboard',
  icon: 'table',
  examples: {
      'CTXDASH': {
          label: 'Cortex Dashboard',
          title: 'Cortex Dashboard',
          description: 'Cortex Dashboard',
          rufId: 'cortex_dashboard',
          component: CortexDashboardComponent
      }
  }
};

@NgModule({
  declarations:[CortexDashboardComponent],
  imports: [
    ISTComponentModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatInputModule,
    RufCardModule,
    HighchartsChartModule
   ],
  exports:[CortexDashboardComponent],
  providers: [{ provide: MON_TOOL, useValue: cortexDashboardData }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})

export class CortexDashboardModule {}
