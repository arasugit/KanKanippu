import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { CustomValidators } from '../common';

@Component({
  selector: 'atm-rltm-cash-history',
  templateUrl: './atm-rltm-cash-history.component.html'
 })

export class ATMRltmCashHistoryComponent extends ListComponent implements OnInit, AfterViewInit {
  [x: string]: any;

  fromTime:  string = '';
  fromDate: string = '';
  dateTo: string = '';
  toTime: string = '';
  instId = '*';
  terminalId = '';
  grpName = '';
  unit = '';

  @ViewChild('rltmCashHistoryTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';

    this.criteria['fromTime'] = this.fromTime;
    this.criteria['toTime'] =this.toTime;
    this.criteria['instId'] = this.instId;
    this.criteria['grpName'] = this.grpName;
    this.criteria['unit'] = this.unit;
  }

  FORM_TITLE = 'ATM Datasource Real Time Cash Position';
  exportFileName = 'ATM Real Time Cash Position History'

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   workRequest:WorkRequest;

   queryPerm = new FormActionPermission('ATMRTCASHH', 'Q');
   mkcPerm = new MKCPermission('ATMRTCASHH');

   ngOnInit() {

    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'ATMRTCASHH';
    this.metaDataId = 'ATMRTCASHH';
    this.tabId = 'ATMRTCASHH_TAB';
    this.sectionId = 'ATMRTCASHH_SEC';
    this.collectionId = 'ATMRTCASHH_COL';
  }

  onRowClick(event:any) {
  }

  validateBeforeQuery(): boolean {
    CustomValidators.globals=this.globals;
    this.fromDate=CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo=CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat);
    let result:boolean;
    result= CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField);

    if(result) {
      result= CustomValidators.validateTimeField(this.fromTime);
    }

    if(result) {
      result= CustomValidators.validateTimeField(this.toTime);
    }

    return result;
  }

  validateFromTime(event: any) {
    CustomValidators.globals=this.globals;
    return CustomValidators.formatTimeField(event);
  }

  validateToTime(event: any) {
    CustomValidators.globals=this.globals;
    return CustomValidators.formatTimeField(event);
  }
}
