

export class ChartDTO {
  name: string;
  value: string;

  constructor (name: string, value: string) {
      this.name = name;
      this.value = value;
  }
}

export class ChartHighChartDTO {
  name: string;
  y: number;

  constructor (name: string, value: number) {
      this.name = name;
      this.y = value;
  }
}
