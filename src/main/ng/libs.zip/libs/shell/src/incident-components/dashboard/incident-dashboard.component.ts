import {Component, ViewEncapsulation, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef } from '@angular/core';
import { finalize, first } from 'rxjs/operators';
import { MON_ATM_COLOR_SETS } from '../../home/ngx-charts-color-sets';
import { ListComponent } from '../../components';
import { DataTableService, GlobalsService } from '../../services';
import { WorkRequest } from '../../ist-components';
import { ChartDTO, ChartHighChartDTO } from './chart-dto';
import { ChartMultiDTO } from './chart-multi-dto';
import { LabelAndValue, LabelsAndValues } from '@ist-custom-project/shell';
import { Params } from '@angular/router';
import { IncidentDTO } from './incident-tdo';
import * as Highcharts from 'highcharts';
import timeline from 'highcharts/modules/timeline';
timeline(Highcharts);
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);
@Component({
  selector: 'incident-dashboard',
  templateUrl: './incident-dashboard.component.html',
  encapsulation: ViewEncapsulation.None
})

export class IncidentDashboardComponent extends ListComponent implements OnDestroy {
  view: any[] = [300, 300];
  screenType: any;
  incidentStatusData: any[] = [];
  incidentStatusLegendValues: string[] = [];
  incidentDaysData: any[] = [];
  incidentDaysLegendValues: string[] = [];
  incidentHoursData: any[] = [];
  incidentHoursLegendValues: string[] = [];
  incidentPriorityData: any[] = [];
  incidentPriorityLegendValues: string[] = [];
  // incidentStatusLegendColors: ColorHelper;
  // incidentDaysLegendColors: ColorHelper;
  // incidentHoursLegendColors: ColorHelper;
  // incidentPriorityLegendColors: ColorHelper;
  timeRangeData: LabelsAndValues = new LabelsAndValues();
  isSearchReq: boolean = false;
  statusFromDate: string;
  statusToDate: string;
  priorityFromDate: string;
  priorityToDate: string;
  hoursFromDate: string;
  hoursToDate: string;
  daywiseFromDate: string;
  daywiseToDate: string;
  animations = true;
  showLegend = false;
  legendWidth:number=80;
  legendHeight:number=20;
  maxLabelLength:number=20;
  doughnut = true;
  arcWidth = 0.50;
  // readonly LegendPosition = LegendPosition;
  Highcharts: typeof Highcharts = Highcharts;
  chartOptionsOpenIncident: Highcharts.Options;
  chartOptions: Highcharts.Options;
  colorScheme: any = {
    domain: MON_ATM_COLOR_SETS['rufBarChartLightColorScheme']
  };
  columnDataAcqCategory: any;
  columnAcqData: { name: string; data: any[]; }[];
  lineChartData: any[];
  chartOptionsIncidentStatus: Highcharts.Options;
  chartOptionsPriority: Highcharts.Options;

  constructor(private injector: Injector, private dataService: DataTableService, private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker) {
      super(injector);


  }

  ngOnInit(): void {
    super.ngOnInit();

    this.route
      .data
      .pipe(first())
      .subscribe(v => this.screenType=v['module']);

      this.adjustCriteria();
      this.retriveData();
  }

  adjustCriteria(): void {
    this.globals.setErrorMessage('');
  //  this.criteria['productId'] = 'ISTSWT';
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
  }

  retriveData(): void {
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;

    this.incidentStatusLegendValues = [];
    this.incidentDaysLegendValues = [];
    this.incidentHoursLegendValues = [];
    this.incidentPriorityLegendValues = [];
    this.globals.showLoadingBar();
    this.dataService
    .loadData(false)
    .pipe(
      first(),
      finalize(() => this.globals.hideLoadingBar())
    )
    .subscribe(
      {
        next: (data: any) => this.onGotRecords(data),
        error: (error: any) => this.onErrorGotRecords(error)
      }
    );
  }

  onGotRecords(wr: WorkRequest): void {
    this.globals.hideLoaderBar();
    const workRequest = wr;
    let multiStatusList: ChartHighChartDTO[] = [],
        multiPriorityList: ChartHighChartDTO[] = [];
    if(workRequest.lastModified == -1){
      this.globals.setErrorMessage('No Data found');
      return;
    }
    if (workRequest == null || workRequest == undefined
      || workRequest.collections == null || workRequest.collections[this.collectionId] == null
      || workRequest.collections[this.collectionId].rows == null
      || workRequest.collections[this.collectionId].rows == undefined
      || workRequest.collections[this.collectionId].rows.length == 0) {
        return;
      }
      const rows = workRequest.collections[this.collectionId].rows;
      let multiDtoList: ChartMultiDTO[] = [];
      rows.forEach((c) => {
        let statusList = c.statusList;
        statusList.forEach(s => {
          let dto = new ChartHighChartDTO(s.status, s.count);
          multiStatusList.push(dto);
          this.incidentStatusLegendValues.push(s.status + '-' + s.count);
          this.statusFromDate = s.fromDate;
          this.statusToDate = s.toDate;
        });
        // this.incidentStatusLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.incidentStatusLegendValues, this.colorScheme);
        this.incidentStatusData = multiStatusList;

        console.log('pie1',this.incidentStatusData);
        let priorityList = c.priorityList;
        priorityList.forEach(p => {
          let dto = new ChartHighChartDTO(p.priority, p.count);
          multiPriorityList.push(dto);
          this.incidentPriorityLegendValues.push(p.priority + '-' + p.count);
          this.priorityFromDate = p.fromDate;
          this.priorityToDate = p.toDate;
        });
        // this.incidentPriorityLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.incidentPriorityLegendValues, this.colorScheme);
        this.incidentPriorityData = multiPriorityList;
        let daysList = c.dayList;
        daysList.forEach(d => {
          let openDto = new IncidentDTO('Open', d.openCount, d.rpDate);
          let closedDto = new IncidentDTO('Closed', d.closedCount, d.rpDate);
          let inprogressDto = new IncidentDTO('In-Progress', d.inprogressCount, d.rpDate);
          let chartDtoList = [openDto, closedDto, inprogressDto];
          let multiDto = new ChartMultiDTO(d.dayDate, chartDtoList);
          multiDtoList.push(multiDto);
          this.incidentDaysLegendValues.push('Open');
          this.incidentDaysLegendValues.push('Closed');
          this.incidentDaysLegendValues.push('In-Progress');
          this.daywiseFromDate = d.fromDate;
          this.daywiseToDate = d.toDate;
        });
        if (multiDtoList !== undefined) {
          // this.incidentDaysLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.incidentDaysLegendValues, this.colorScheme);
          this.incidentDaysData = JSON.parse(JSON.stringify(multiDtoList));
          console.log('barchart',this.incidentDaysData);
        }
        let hoursList = c.hoursList, multiDtoHoursList: any[] = [];
        let openHourDtoList: ChartDTO[] = [];
        this.lineChartData = [];
        hoursList.forEach(h => {
          let openCountDto = new ChartDTO(h.hours, h.openCount);
          openHourDtoList.push(openCountDto);
          this.incidentHoursLegendValues.push(h.hours + '-' + h.openCount);
          this.hoursFromDate = h.fromDate;
          this.hoursToDate = h.toDate;
          this.lineChartData.push({name:h.hours,label:h.openCount,description:h.openCount});
        });
        multiDtoHoursList.push(new ChartMultiDTO('Open' , openHourDtoList));
        // this.incidentHoursLegendColors = new ColorHelper(this.colorScheme as Color, ScaleType.Ordinal, this.incidentHoursLegendValues, this.colorScheme);
        this.incidentHoursData = JSON.parse(JSON.stringify(multiDtoHoursList));
        console.log('line chart', this.incidentHoursData);
      });
      this.getIncidentStatusChart();
      this.getPriorityStatusChart();
      this.getIncidentDaysChart();
      this.getIncidentHourChart();
      this.adjustChartViewWidth(rows.length);
      this.cdr.markForCheck();
  }

  adjustChartViewWidth(rowCount: number) {
    if(rowCount > 2)
      this.view = [300, 300];
  }
  getIncidentDaysChart(){
    this.columnDataAcqCategory = [];
    let apprData = [];
    let decData = [];
    let revData = [];
    this.incidentDaysData.forEach(res=>{
      this.columnDataAcqCategory.push(res.name);
        res.series.forEach(element => {
          if(element.name === 'Open'){
            apprData.push(parseInt(element.value));
          }
          if(element.name === 'Closed'){
            decData.push(parseInt(element.value));
          }
          if(element.name === 'In-Progress'){
            revData.push(parseInt(element.value));
          }
        });
      })
      this.columnAcqData = [
        { name:'Open',
        data:apprData
      },
      { name:'Closed',
        data:decData
      },
      { name:'In-Progress',
        data:revData
      },
    ]

    this.chartOptions= {
      chart: {
        type: 'column',
    },
    credits:{
      enabled: false,
    },
    title: {
        text: 'Open/Closed/In-Progress Incidents (Daywise)',
        // align: 'left'
    },
    // subtitle: {
    //     text:
    //         'Source: <a target="_blank" ' ,
    //     align: 'left'
    // },
    xAxis: {
        categories: this.columnDataAcqCategory,
        crosshair: true,
        accessibility: {
            description: 'Countries'
        },
        type: 'datetime',
        labels: {
          formatter: function(){
            const datestr = this.value;
            const [d, m, y] = datestr.toString().split('/');
            const mIndex = parseInt(m)-1;
            const date = new Date(+y, mIndex, +d);
            const day = String(date.getDate()).padStart(2,'0');
            const mon = date.toLocaleString('en-US', {month: 'short'});
            return `${day}-${mon}`;
          }
        }
    },
    yAxis: {
        min: 0,
        // max:50000,
        title: {
            // text: '1000 metric tons (MT)'
        },
        stackLabels: {
          enabled: true
      }
    },
    tooltip: {
        // valueSuffix: ' (1000 MT)'
    },
    legend: {
      // layout: 'vertical',
      // align: 'right',
      // verticalAlign: 'top',
      // x: -40,
      // y: 80,
      // floating: true,
      // borderWidth: 1,
      // backgroundColor:
      //     Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF',
      // shadow: true,
      labelFormatter: function(){
        const series: any = this as Highcharts.Series;
        const seriesSum = (series.yData || []).reduce((sum,point)=> sum+(point || 0),0);
        return this.name+'(Total:'+seriesSum+')';
      }
  },
    plotOptions: {
        column: {
          stacking: 'normal',
          dataLabels: {
              enabled: true
          }
      },
        series: {
          cursor: 'pointer',

          point: {
              events: {
                  click:  (event)=> {
                    this.onDaywiseChartSelect({
                      x:event.point.x,
                      value:event.point.y,
                      name: event.point.series.name,
                      rpDate:event.point.category,
                      label: event.point.series.name,
                      series:event.point.category
                    });
                  }
                }
          }
      },
    },
    series: this.columnAcqData as any
  }
  }

  getIncidentHourChart(){
    this.chartOptionsOpenIncident = {
      chart: { type: 'timeline'},
      credits:{
        enabled: false,
      },
      title: { text: 'Open Incidents (By hrs)' },
      xAxis: {
        title: {
          text: 'Time (Hrs)'
      },
    },
    yAxis: {
        visible: false
    },
    plotOptions: {
      series: {
          dataLabels: {
              enabled: true
          }
      }
  },
  tooltip: {
    format: '<span ' +
              'style="font-weight: bold;" > ' +
              'Open Count</span><br/>{point.label}'
},
      series: [{
        dataLabels: {
          allowOverlap: false,
          format: '<span style="color:{point.color}">● </span><span ' +
              'style="font-weight: bold;" > ' +
              '{point.label}</span><br/>{point.name}'
      },
      marker: {
          
      },          
          data: this.lineChartData,
		  point: {
            events: {
                click:  (event)=> {
                  this.onHoursChartSelect({
                    x:event.point.x,
                    value:event.point.y,
                    name: event.point.name,
                    label: event.point.series.name,
                    series:event.point.category
                    });
                  }
                }
          },
        },
      ]as any,
    };
  }
  getIncidentStatusChart(){
    this.chartOptionsIncidentStatus={

      chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45
        },
        // width:200

    },
    credits:{
      enabled: false,
    },
    title: {
        text: 'Open/Closed Incidents (Current Day)',
        margin:0,
    },
    tooltip: {
        pointFormat: '<b>{point.y}</b>'
    },
    legend: {
      align: "center",
      verticalAlign: "bottom",
      layout: "horizontal",
      labelFormatter: function () {
      return this.name + " - " + ((this as Highcharts.Point).y ?? 0);
    },
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.y}',
                style: {
                    // color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            },
            size: '50%',
            innerSize: '60%',
            depth: 45,
            showInLegend: true
        }
    },
    series: [{
        name: 'Open/Closed Incidents (Current Day)',
        colorByPoint: true,
        type:'pie',
        data:this.incidentStatusData,
        point: {
          events: {
              click:  (event)=> {
                this.onStatusBarChartSelect({
                  x:event.point.x,
                  value:event.point.y,
                  name: event.point.name,
                  label: event.point.series.name,
                  series:event.point.category
                });
              }
            }
      },
    }as any],

    }

  }

  getPriorityStatusChart(){
    this.chartOptionsPriority= {

      chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45
        }
    },
    credits:{
      enabled: false,
    },

    title: {
        text: 'Open Incidents By Priority (Current Day)',
        margin:0,
    },
    tooltip: {
        pointFormat: '<b>{point.y}</b>'
    },
    legend: {
      // align: "center",
      verticalAlign: "bottom",
      layout: "horizontal",
      labelFormatter: function () {
      return this.name + " - " + ((this as Highcharts.Point).y ?? 0);
    },
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.y} ',
                style: {
                    // color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            },
            size: '60%',
            depth: 45,
            showInLegend: true
        }
    },
    series: [{
        name:'Open Incidents By Priority (Current Day)',
        colorByPoint: true,
        type:'pie',
        data:this.incidentPriorityData,
        point: {
          events: {
              click:  (event)=> {
                this.onPriorityChartSelect({
                  x:event.point.x,
                  value:event.point.y,
                  name: event.point.series.name,
                  label: event.point.series.name,
                  series:event.point.category
                });
              }
            }
      },
    }as any],
  
    };
  }
  convert(timeString) {
    let regExTime = /([0-9]?[0-9]):([0-9][0-9])/;
    let regExTimeArr : any = regExTime.exec(timeString);
    let timeHr = regExTimeArr[1] * 3600 * 1000;
    let timeMin = regExTimeArr[2] * 60 * 1000;
    // let timeSec = regExTimeArr[3] * 1000;
    let timeMs = timeHr + timeMin;
    console.log(timeMs);
    return timeMs;
  }
  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  setT21Tags(): void {
    this.requestTypeId = 'INCDASH';
    this.metaDataId = 'INCDASH';
    this.tabId = 'INCDASH_TAB';
    this.sectionId = 'INCDASH_SEC';
    this.collectionId = 'INCDASH_COL';
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
    this.clearErrorMessage();
  }

  onStatusBarChartSelect(event: any) {
    let newParam = {};
    newParam['COMMAND'] = 'query';
    newParam['NAVIGATION'] = true;
    newParam['status_code'] = {
      'status': event.name,
      'fromDate': this.statusFromDate,
      'toDate': this.statusToDate
    };
    this.DETAIL_FORM_PATH = 'monitor/INCALERT/INCALERT';
    this.goToDetailForm(newParam);
  }

  onPriorityChartSelect(event: any) {
    let newParam = {};
    newParam['COMMAND'] = 'query';
    newParam['NAVIGATION'] = true;
    newParam['status_code'] = {
      'status': 'open',
      'fromDate': this.priorityFromDate,
      'toDate': this.priorityToDate,
      NAVIGATION: true
    };
    this.DETAIL_FORM_PATH = 'monitor/INCALERT/INCALERT';
    this.goToDetailForm(newParam);
  }

  onHoursChartSelect(event: any) {
    let newParam = {};
    newParam['COMMAND'] = 'query';
    newParam['NAVIGATION'] = true;
    newParam['status_code'] = {
      //'status': event.name,
	  'status': 'open',
      'fromDate': this.hoursFromDate,
      'toDate': this.hoursToDate
    };
    this.DETAIL_FORM_PATH = 'monitor/INCALERT/INCALERT';
    this.goToDetailForm(newParam);
  }

  onDaywiseChartSelect(event: any) {
    let newParam = {};
    let incStatus;
    newParam['COMMAND'] = 'query';
    newParam['NAVIGATION'] = true;

    if(event.name === 'Open'){
      incStatus = 'open';
    }else if(event.name === 'Closed'){
      incStatus = 'closed';
    }else{
      incStatus = 'progress';
    }

    newParam['status_code'] = {
      'status': incStatus,
      'fromDate': event.rpDate,
      'toDate': event.rpDate
    };
    this.DETAIL_FORM_PATH = 'monitor/INCALERT/INCALERT';
    this.goToDetailForm(newParam);
  }

  setQueryParameters(params: Params): void {
    this.params = params;
    this.querySection.setQueryParameters(this.params, this.criteria);
  }

  changeHandler(event: any) {
    this.globals.setErrorMessage('');
    if(null == event) return;
    this.adjustCriteria();
    this.retriveData();
  }

  search(){

    //super.search();
    this.adjustCriteria();
    this.retriveData();
  }

doSearch(){

}

}
