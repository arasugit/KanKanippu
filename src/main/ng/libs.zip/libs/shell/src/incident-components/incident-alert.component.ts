import { Component, Injector, OnInit, ViewChild,  Input, ElementRef , ChangeDetectorRef, AfterContentChecked, ChangeDetectionStrategy, AfterViewInit, AfterContentInit, AfterViewChecked} from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent} from '../components/base-list.component';
import { LabelsAndValues } from '../common/labels-and-values';
import { CustomFormatter } from '../common';
import { Params } from '@angular/router';


@Component({
    selector: 'app-incident-alert',
    templateUrl: 'incident-alert.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class IncidentAlertComponent extends ListComponent implements OnInit, AfterViewInit{
    
    cd: ChangeDetectorRef;    

    constructor(public injector: Injector, private changeDetector: ChangeDetectorRef) {
        super(injector);
      }

    exportFileName = 'Incident Updates';
    upddate = '';
    comments = '';
    cfgId = '';
    incId = '';
    cfgIdBeforeTrim = '';
    incIdBeforeTrim = '';
    queryPerm = new FormActionPermission('INCALERT', 'Q');
    insertPerm = new FormActionPermission('INCALERT', 'I');
    updatePerm = new FormActionPermission('INCALERT', 'U');
    deletePerm = new FormActionPermission('INCALERT', 'D');
    checkerPerm = new FormActionPermission('INCALERT', 'C');
    mkcPerm = new MKCPermission('INCALERT');
    incident_report = '';
    incidentoutputtype = '';
    FORM_TITLE = 'Incident Updates';
    incidentList: LabelsAndValues = new LabelsAndValues();
    outputTypeList: LabelsAndValues = new LabelsAndValues();
    ist_inst_Id = '';

    ngOnInit() {

      super.ngOnInit();
      
      this.criteria = {};
      this.requestPerms.permsArr = [];
      this.requestPerms.permsArr.push(this.queryPerm);
      this.requestPerms.permsArr.push(this.insertPerm);
      this.requestPerms.permsArr.push(this.updatePerm);
      this.requestPerms.permsArr.push(this.deletePerm);
      this.requestPerms.permsArr.push(this.mkcPerm);
      this.requestPerms.permsArr.push(this.checkerPerm);
      this.requestPerms.getPermission(this.router.url);
      // super.ngOnInit();
      this.requestTypeId = 'INCALERT';
      this.metaDataId = 'INCALERT';
      this.tabId = 'INCALERTTAB';
      this.sectionId = 'INCALERTSECTION';
      this.collectionId = 'INCALERTCOL';
      this.setAutoRefreshSearch(true);

    }

    ngAfterViewInit() :void {
      this.doSearch();
      console.log(this);
      this.setAutoRefreshInterval();      

         if (this.isNavigation) {       
             setTimeout(() => {
                this.searchCfg();
            }, 0);
         }
    }

   searchCfg() {
    super.search();
   }

   setT21Tags(): void {
        this.requestTypeId = 'INCALERT';
        this.metaDataId = 'INCALERT';
        this.tabId = 'INCALERTTAB';
        this.sectionId = 'INCALERTSECTION';
        this.collectionId = 'INCALERTCOL';
    }

    validateBeforeQuery(): boolean {
        this.cfgIdBeforeTrim = this.cfgId;
        this.incIdBeforeTrim = this.incId;
        let regex = new RegExp(/^[A-Z@~`!@#$%^&*()_=+\\\\';:\"\\/?>.<,-]*$/i);
        if (this.cfgId !== ''){
        if (this.cfgIdBeforeTrim !== this.cfgId.trim()){
          this.globals.setErrorMessage('Remove leading/trailing spaces in Configuration Id');
          return false;
        }
        
        if (regex.test(this.cfgId) == true){
          this.globals.setErrorMessage('Please enter a numeric value for Configuration Id');
          return false;
        }
      }
    
      if (this.incId !== ''){
        if (this.incIdBeforeTrim !== this.incId.trim()){
          this.globals.setErrorMessage('Remove leading/trailing spaces in Incident Id');
          return false;
        }
        
        if (regex.test(this.incId) == true){
          this.globals.setErrorMessage('Please enter a numeric value for Incident Id');
          return false;
        }
      }        
        return true;
      }  
   
    getModuleName() { return 'IST-CustomProject'; }
    emitModuleReady() { this.msgService.sendMessage(this.getModuleName()); }
}
