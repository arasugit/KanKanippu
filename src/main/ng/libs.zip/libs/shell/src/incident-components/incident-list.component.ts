

import { Component, Injector, OnInit } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { IstDatePickerColumnRendererComponent } from '../ist-components';
import { IstDatePickerComponent, RendererItem } from '../components';
import { LabelAndValue, LabelsAndValues } from '../common/labels-and-values';
import { CustomValidators, StringUtil } from '../common';



@Component({
  selector: 'app-incident-list',
  templateUrl: 'incident-list.component.html'
})

export class IncidentListComponent extends ListComponent implements OnInit {
  constructor(injector: Injector) {
    super(injector);
  }
  exportFileName = 'Incident Configuration';
  FORM_TITLE = 'Incident Configuration';
  cfgId = '';
  description = '';
  product = '';
  nodeId = '';
  cmd = '';
  subcmd = '';
  condition = '';
  priority = '';
  alertType = '';
  startDate = '';
  endDate = '';
  message = '';
  smsnumber = '';
  emailId = '';
  queryPerm = new FormActionPermission('INCLIST', 'Q');
  insertPerm = new FormActionPermission('INCLIST', 'I');
  updatePerm = new FormActionPermission('INCLIST', 'U');
  deletePerm = new FormActionPermission('INCLIST', 'D');
  checkerPerm = new FormActionPermission('INCLIST', 'C');
  mkcPerm = new MKCPermission('INCLIST');

  startDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
  endDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
  deptList: LabelsAndValues = new LabelsAndValues();
  txnTypeList: LabelsAndValues = new LabelsAndValues();
  cntrlType = 'CBOX';
  ngOnInit() {
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.insertPerm);
    this.requestPerms.permsArr.push(this.updatePerm);
    this.requestPerms.permsArr.push(this.deletePerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.setAutoRefreshSearch(true);

    this.txnTypeList.array = [new LabelAndValue('ACP', 'ACP'), new LabelAndValue('TXN', 'TXN'), new LabelAndValue('ATM', 'ATM'), new LabelAndValue('LOG', 'LOG')];
    //console.log("Type List " + this.txnTypeList);
  }

  ngAfterViewInit(): void {
    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  // Below method should be implemented if the query criteria validation is needed.
  // Example if employee id is mandatory for search
  validateBeforeQuery(): boolean {
    if(StringUtil.isNotEmpty(this.cfgId)){
      if(isNaN(Number(this.cfgId.toString().replace(/\*/g, '')))) {
        this.globals.setErrorMessage('Cfg Id must be a numeric');
        return false;
      }
    }

    if (this.startDate)
    if(!CustomValidators.isValidDate(this.startDate, this.globals.dateFormat)) {
      this.globals.setErrorMessage('Please enter the valid start date');
      return false;
    }

    if (this.endDate)
    if(!CustomValidators.isValidDate(this.endDate, this.globals.dateFormat)){
      this.globals.setErrorMessage('Please enter the valid end date');
      return false;
    }

    if(this.startDate && this.endDate)
    if(this.endDate < this.startDate) {
      this.globals.setErrorMessage('End date should be greater or equals than start date');
      return false;
    }

    return true;
  }

  setT21Tags(): void {
    this.requestTypeId = 'INCLIST';
    this.metaDataId = 'INCLIST';
    this.tabId = 'INCLISTTAB';
    this.sectionId = 'INCLISTSECTION';
    this.collectionId = 'INCLISTCOL';
  }

}
