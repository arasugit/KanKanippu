

export class IncidentDTO {
  name: string;
  value: string;
  rpDate: string;

  constructor (name: string, value: string, rpDate: string) {
    this.name = name;
    this.value = value;
    this.rpDate = rpDate;
}
}
