import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RufCardModule } from '@ruf/shell';
import { ISTComponentModule } from '../../ist-components';
import { MON_TOOL, MonitorComponentData } from '../../monitor-components/common-object';
import { IncidentDashboardComponent } from './incident-dashboard.component';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HighchartsChartModule } from 'highcharts-angular';

export const incDashboardData: MonitorComponentData = {
  title: 'Incident Dashboard',
  icon: 'table',
  examples: {
      'INCDASH': {
          label: 'Incident Dashboard',
          title: 'Incident Dashboard',
          description: 'Incident Dashboard',
          rufId: 'inc_dashboard',
          component: IncidentDashboardComponent
      }
  }
};

@NgModule({
  declarations:[IncidentDashboardComponent],
  imports: [
    FlexLayoutModule,
    RufCardModule,
    MatCardModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    ISTComponentModule,
    HighchartsChartModule,
   ],
  exports:[IncidentDashboardComponent],
  providers: [{ provide: MON_TOOL, useValue:  incDashboardData}],
})

export class IncidentDashboardModule {}
