import { Component, Injector, OnInit, ViewChild } from '@angular/core';
import { IncidentAlertComponent } from './incident-alert.component';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { IstDatePickerColumnRendererComponent } from '../ist-components';
import { IstDatePickerComponent, RendererItem } from '../components';
import { LabelAndValue, LabelsAndValues } from '../common/labels-and-values';
import { DataTableEditableComponent } from '../components';
import { Params } from '@angular/router';
import { GlobalsService } from '../services';
import { globalAgent } from 'http';
import { Location } from '@angular/common';
import { CustomValidators } from '../common';
import * as path from 'path';

@Component({
  selector: 'app-incident-action',
  templateUrl: 'incident-action.component.html'
})

export class IncidentActionComponent extends ListComponent implements OnInit {

  constructor(injector: Injector, private location: Location) {
    super(injector);
  }
  exportFileName = 'Incident Alerts';
  FORM_TITLE = 'Incident Alerts';
  cfgId = '';
  incId = '';
  cfgIdBeforeTrim = '';
  incIdBeforeTrim = '';
  incDateFrom = '';
  incDateTo = '';
  status = '';
  statusList: LabelsAndValues = new LabelsAndValues();
  statusListColumnData: LabelsAndValues = new LabelsAndValues();
  smsStatusList: LabelsAndValues = new LabelsAndValues();
  emailStatusList: LabelsAndValues = new LabelsAndValues();
  smsStatus = '';
  emailStatus = '';
  selectedItem: any = null;
  moduleName: any;
  configDesc = '';
  cntrlType = 'CBOX';
  statusCode: string = '';
  showBackBtn: boolean = false;

  queryPerm = new FormActionPermission('INCACTION', 'Q');
  insertPerm = new FormActionPermission('INCACTION', 'I');
  updatePerm = new FormActionPermission('INCACTION', 'U');
  deletePerm = new FormActionPermission('INCACTION', 'D');
  checkerPerm = new FormActionPermission('INCACTION', 'C');
  mkcPerm = new MKCPermission('INCACTION');
  startDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
  endDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
  deptList: LabelsAndValues = new LabelsAndValues();

  @ViewChild(IncidentAlertComponent, { static: false }) incAlert: IncidentAlertComponent;


  ngOnInit() {
    super.ngOnInit();

    //this.showBackBtn = GlobalsService.isRedirected;
    this.isRedirected=GlobalsService.isRedirected;
    this.showBackBtn=GlobalsService.isRedirected;
    //GlobalsService.isRedirected=false;
    //GlobalsService.param='';

    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.insertPerm);
    this.requestPerms.permsArr.push(this.updatePerm);
    this.requestPerms.permsArr.push(this.deletePerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.setAutoRefreshSearch(true);

    this.statusList.array = [new LabelAndValue('', ''), new LabelAndValue('Open', 'open'), new LabelAndValue('Closed', 'closed'), new LabelAndValue('Progress', 'progress')];
    this.statusListColumnData.array = [new LabelAndValue('Open', 'open'), new LabelAndValue('Closed', 'closed'), new LabelAndValue('Progress', 'progress')];
    this.smsStatusList.array = [new LabelAndValue('', ''), new LabelAndValue('Success', 'success'), new LabelAndValue('Failed', 'failed')];
    this.emailStatusList.array =  [new LabelAndValue('', ''), new LabelAndValue('Success', 'success'), new LabelAndValue('Failed', 'failed')];

    if (GlobalsService.param !== undefined && GlobalsService.param !== '' && GlobalsService.param !== null) {
      this.status = GlobalsService.param['status'];
      this.incDateFrom = GlobalsService.param['fromDate'];
      this.incDateTo = GlobalsService.param['toDate'];
      this.showBackBtn = GlobalsService.isRedirected;
    }

    GlobalsService.param = '';
  }

  ngAfterViewInit(): void {
    if (GlobalsService.isRedirected == undefined || !GlobalsService.isRedirected) {
      return;
    }

    GlobalsService.isRedirected = false;
    GlobalsService.param = null;

    this.doSearch();
    console.log(this);
    this.setAutoRefreshInterval();
  }

  openScreen(event: any) {
    let newParam = {};
    let path = '';
    newParam = {

      COMMAND: 'query',

      cfgId: '52',

      incId: '61',

    };

    newParam['COMMAND'] = 'query';
    path = 'monitor/INCALERT/INCALERT';
    newParam['NAVIGATION'] = true;
    newParam['cfgId'] = event.cfgId;
    newParam['incId'] = event.incId;
    this.handleParams(newParam);
    this.DETAIL_FORM_PATH = 'monitor/INCALERT/INCALERT';
    this.goToDetailForm(newParam);
  }

  onItemClick(selectedItem: any) {
    console.log("Selected " + selectedItem.cfgId + "command " + selectedItem.command);
    selectedItem.command = 'detail';
    console.log("Selected " + selectedItem.cfgId + "command " + selectedItem.command);
    super.onItemClick(selectedItem, {
      COMMAND: 'detail', DETAIL_FORM_PATH: 'forms/INCALERT',
      cfgId: selectedItem.cfgId + ''
    });
  }

  // Below method should be implemented if the query criteria validation is needed.
  // Example if employee id is mandatory for search
  validateBeforeQuery(): boolean {
    this.cfgIdBeforeTrim = this.cfgId;
    this.incIdBeforeTrim = this.incId;
    CustomValidators.globals=this.globals;
    this.incDateFrom=CustomValidators.formatDateString(this.incDateFrom, this.globals.dateFormat);
    this.incDateTo=CustomValidators.formatDateString(this.incDateTo, this.globals.dateFormat);
    let regex = new RegExp(/^[A-Z@~`!@#$%^&*()_=+\\\\';:\"\\/?>.<,-]*$/i);
    if (this.cfgId !== ''){
    if (this.cfgIdBeforeTrim !== this.cfgId.trim()){
      this.globals.setErrorMessage('Remove leading/trailing spaces in Configuration Id');
      return false;
    }

    if (regex.test(this.cfgId) == true){
      this.globals.setErrorMessage('Please enter a numeric value for Configuration Id');
      return false;
    }
  }

  if (this.incId !== ''){
    if (this.incIdBeforeTrim !== this.incId.trim()){
      this.globals.setErrorMessage('Remove leading/trailing spaces in Incident Id');
      return false;
    }

    if (regex.test(this.incId) == true){
      this.globals.setErrorMessage('Please enter a numeric value for Incident Id');
      return false;
    }
  }
    return true;
  }

  setT21Tags(): void {
    this.requestTypeId = 'INCACTION';
    this.metaDataId = 'INCACTION';
    this.tabId = 'INCACTIONTAB';
    this.sectionId = 'INCACTIONSECTION';
    this.collectionId = 'INCACTIONCOL';
  }

  adjustCriteria(): void {
    this.criteria['status'] = this.status;
    this.criteria['incDateFrom'] = this.incDateFrom;
    this.criteria['incDateTo'] = this.incDateTo;
  }

  goBack() {
    this.globals.setErrorMessage('');
    this.clearErrorMessage();

    if (window.history.length > 1) {
      console.log('History found');
      this.router.navigateByUrl('monitor/INCDASH/INCDASH', {});
    } else {
      console.log('No history found');
    }
  }

}
