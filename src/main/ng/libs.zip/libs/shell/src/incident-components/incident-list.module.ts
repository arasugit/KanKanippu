import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IncidentListComponent } from './incident-list.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { IncidentActionComponent } from './incident-action.component';
import { IncidentAlertComponent } from './incident-alert.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { CommonModule } from '@angular/common';

export const incListData: MonitorComponentData = {
  title: 'Incident Monitoring',
  icon: 'home',
  examples: {
      'INCALERT': {
        label: 'Incident Alerts',
        title: 'Incident Alerts',
        description: 'Incident Alerts',
        rufId: 'INCACTION',
        component: IncidentActionComponent
    },
    'INCUPDATE': {
      label: 'Incident Updates',
      title: 'Incident Updates',
      description: 'Incident Updates',
      rufId: 'INCALERT',
      component: IncidentAlertComponent
  },
  'INCCONFIG': {
    label: 'Incident Configuration',
    title: 'Incident Configuration',
    description: 'Incident Configuration',
    rufId: 'INCLIST',
    component: IncidentListComponent
},

  },
};

@NgModule({
    imports :[
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    ISTComponentModule,
    MatFormFieldModule,
    CommonModule
  ],
  declarations: [IncidentListComponent, IncidentActionComponent, IncidentAlertComponent],
  providers: [{ provide: MON_TOOL, useValue: incListData }],
  exports:[],
})
export class IncidentListModule {}
