import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';

@Component({
  selector: 'enCash-app',
  templateUrl: './enCash.component.html'
 })
export class EnCashComponent extends ListComponent implements OnInit, AfterViewInit {
  [x: string]: any;

  @ViewChild('enCashTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
    this.criteria['statusCode'] = this.statusCode;
  }

  FORM_TITLE = 'Data Points Encash';
  exportFileName = 'Encash';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   workRequest:WorkRequest;

   queryPerm = new FormActionPermission('DPENCASH', 'Q');
   checkerPerm = new FormActionPermission('DPENCASH', 'C');
   mkcPerm = new MKCPermission('DPENCASH');

   ngOnInit() {

    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    this.doSearch();
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'DPENCASH';
    this.metaDataId = 'DPENCASH';
    this.tabId = 'DPENCASHTAB';
    this.sectionId = 'DPENCASHSEC';
    this.collectionId = 'DPENCASHCOL';
  }


  onRowClick(event:any) {
  }
}



