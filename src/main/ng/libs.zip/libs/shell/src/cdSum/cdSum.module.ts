import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TranslateModule } from '@ngx-translate/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { CdSumComponent } from './cdSum.component';


export const cdSumView: MonitorComponentData = {
  title: 'Data Points cdSum',
  icon: 'home',
  examples: {
    'DPCDSUM': {
      label: 'Credit Summary',
      title: 'Data Points CdSum',
      description:  'CdSum',
      rufId: 'cdsum_view',
      component: CdSumComponent
    }
  }
};

@NgModule({
    imports :[
    CommonModule,
    ISTComponentModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    TranslateModule,
    MatFormFieldModule,
    MatInputModule

    ],
  declarations: [ CdSumComponent ],
  providers: [{ provide: MON_TOOL, useValue: cdSumView }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[],
})
export class CdSumModule {}
