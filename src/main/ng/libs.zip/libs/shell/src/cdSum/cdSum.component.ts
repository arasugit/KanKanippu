import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';

@Component({
  selector: 'cdSum-app',
  templateUrl: './cdSum.component.html'
})
export class CdSumComponent extends ListComponent implements OnInit, AfterViewInit {
  [x: string]: any;

  @ViewChild('cdSumTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, private dataService: DataTableService, private cdr: ChangeDetectorRef) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
    this.criteria['statusCode'] = this.statusCode;
  }

  FORM_TITLE = 'Data Points Credit Summary';
  fromTime: string = '';
  fromDate: string = '';
  dateTo: string = '';
  toTime: string = '';
  workRequest: WorkRequest;

  queryPerm = new FormActionPermission('DPCDSUM', 'Q');
  checkerPerm = new FormActionPermission('DPCDSUM', 'C');
  mkcPerm = new MKCPermission('DPCDSUM');

  ngOnInit() {
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
  }

  ngAfterViewInit(): void {
    this.doSearch();
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'DPCDSUM';
    this.metaDataId = 'DPCDSUM';
    this.tabId = 'DPCDSUMTAB';
    this.sectionId = 'DPCDSUMSEC';
    this.collectionId = 'DPCDSUMCOL';
  }


  onRowClick(event: any) {
  }
}



