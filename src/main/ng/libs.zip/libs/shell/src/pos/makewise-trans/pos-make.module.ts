import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RufCommonModule } from '@ruf/shell';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RufCardModule } from '@ruf/shell';
import { ISTComponentModule } from '../../ist-components';
import { MON_TOOL, MonitorComponentData } from '../../monitor-components/common-object';
import { POSMakewiseTxnsComponent } from './pos-make.component';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { HighchartsChartModule } from "highcharts-angular";

export const posMakewiseTxnsData: MonitorComponentData = {
  title: 'POS Makewise Transactions',
  icon: 'table',
  examples: {
    'POSMAKE': {
      label: 'POS Makewise Transactions - 5 Min',
      title: 'POS Makewise Transactions - 5 Min',
      description: 'POS Makewise Transactions - 5 Min',
      rufId: 'pos_makewise_txns',
      component: POSMakewiseTxnsComponent
    },
    'HOURLY': {
      label: 'POS Makewise Transactions - Hourly ',
      title: 'POS Makewise Transactions - Hourly',
      description: 'POS Makewise Transactions - Hourly',
      rufId: 'pos_makewise_txns_hourly',
      component: POSMakewiseTxnsComponent
    },
    'DAILY': {
      label: 'POS Makewise Transactions - Daily',
      title: 'POS Makewise Transactions - Daily',
      description: 'POS Makewise Transactions - Daily',
      rufId: 'pos_makewise_txns_daily',
      component: POSMakewiseTxnsComponent
    },
    'WEEKLY': {
      label: 'POS Makewise Transactions - Weekly',
      title: 'POS Makewise Transactions - Weekly',
      description: 'POS Makewise Transactions - Weekly',
      rufId: 'pos_makewise_txns_weekly',
      component: POSMakewiseTxnsComponent
    },
    'MONTHLY': {
      label: 'POS Makewise Transactions - Monthly',
      title: 'POS Makewise Transactions - Monthly',
      description: 'POS Makewise Transactions - MONTHLY',
      rufId: 'pos_makewise_txns_monthly',
      component: POSMakewiseTxnsComponent
    }
  },
};

@NgModule({
  declarations:[POSMakewiseTxnsComponent],
  imports: [
    CommonModule,
    MatTableModule,
    FormsModule,
    FlexLayoutModule,
    RufCardModule,
    ReactiveFormsModule,
    ISTComponentModule,
    MatCardModule,
    RufCommonModule,
    MatButtonToggleModule,
    MatTabsModule,
    HighchartsChartModule
   ],
  exports:[POSMakewiseTxnsComponent],
  providers: [{ provide: MON_TOOL, useValue: posMakewiseTxnsData }],
})
export class POSMakewiseTxnsModule {}
