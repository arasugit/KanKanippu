import { Component, ViewEncapsulation, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef, ViewChild } from '@angular/core';
import { finalize, first } from 'rxjs/operators';
import { ListComponent } from '../../components';
import { DataTableService } from '../../services';
import { WorkRequest } from '../../ist-components';
import { ChartDTO } from '../chart-dto';
import { ChartMultiDTO } from '../chart-multi-dto';
import { CustomValidators } from '../../common';
import { FormActionPermission, MKCPermission } from '../../permission';
import { PageEvent } from '@angular/material/paginator';
import { DataTableEditableDetailComponent } from "../../components";
import { DatePipe } from '@angular/common';
import * as Highcharts from "highcharts";
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);
@Component({
  selector: 'pos-sales-trans-overview',
  templateUrl: './pos-trans-overview.component.html',
  styleUrls: ['./pos-trans-overview.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class PosTransOverviewComponent extends ListComponent implements OnDestroy {
  dashboardData: any[];
  showChart: boolean = false;
  txnDetailDataList: any = [];
  tranRange: string;
  tranType: string;
  isSearchReq: boolean = false;
  showTrans: boolean = false;
  fromDate: string = '';
  dateTo: string = '';
  cardTitle: string = '';
  txnDetailCardTitle: string = '';
  chartLabelText: string = '';

  private HourlyTranRange: string = "1HR";
  private TodayTranRange: string = "Today";
  private YesterdayTranRange: string = "Yesterday";
  private WeeklyTranRange: string = "Weekly";
  private MonthlyTranRange: string = "Monthly";
  private QuartelyTranRange: string = "Quartely";
  private CustomTranRange: string = "custom";
  private SalesTranType: string = "Sales";
  private tranPeriod: String = '';
  private tranStatus: String = '';

  public Highcharts: typeof Highcharts = Highcharts;
  public posTransChartOptions: Highcharts.Options;

  @ViewChild("txnTableDataTable", { static: false })
  private txnTableDataTable: DataTableEditableDetailComponent;

  constructor(private injector: Injector,
    private dataService: DataTableService,
    private cdr: ChangeDetectorRef,
    @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker,
    private datePipe: DatePipe)
    {
      super(injector);
    }

  ngOnInit() {
    this.tranRange = this.HourlyTranRange;
    this.tranType = this.SalesTranType;
    //super.ngOnInit();

    this.requestPerms.permsArr = [];
    this.queryPerm = new FormActionPermission('POSTRANVW', 'Q');
    this.mkcPerm = new MKCPermission('POSTRANVW');

    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.getPermission(this.router.url);

    this.route
      .data
      .pipe(first())
      .subscribe(v => {
        const screenType : string = v['module'];
        this.tranType = v['tranType'] ?? this.SalesTranType;
        this.setTranRangeFromScreenType(screenType);
      });

    if (this.tranRange == this.CustomTranRange) {
      this.isSearchReq = true;
      return;
    }

    this.adjustCriteria();
    this.retriveData();
  }

  ngAfterViewInit() {
    super.criteria = this.criteria;
    this.setAutoRefreshInterval();
    this.setAutoRefreshRetriveDataInterval();
  }

  setTranRangeFromScreenType(screenType: string) {
    if (screenType == 'HOURLY')
      screenType = this.HourlyTranRange;
    else if (screenType == 'DAILY')
      screenType = this.TodayTranRange;
    else if (screenType == this.YesterdayTranRange.toUpperCase())
      screenType = this.YesterdayTranRange;
    else if (screenType == this.WeeklyTranRange.toUpperCase())
      screenType = this.WeeklyTranRange;
    else if (screenType == this.MonthlyTranRange.toUpperCase())
      screenType = this.MonthlyTranRange;
    else if (screenType == this.QuartelyTranRange.toUpperCase())
      screenType = this.QuartelyTranRange;
    else if (screenType == this.CustomTranRange.toUpperCase())
      screenType = this.CustomTranRange;

    this.tranRange = screenType;
  }

  adjustCriteria(): void {
    this.globals.setErrorMessage('');
    this.criteria['tranRange'] = this.tranRange;
    this.criteria['fromDate'] = this.fromDate;
    this.criteria['toDate'] = this.dateTo;
    this.criteria['tranType'] = this.tranType;
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
  }

  retriveData(): void {
    this.dataService.requestType = this.requestTypeId;
    this.dataService.collectionTag = this.collectionId;
    this.dataService.action = 'query';
    this.dataService.criteria = this.criteria;
    this.showTrans = false;

    this.globals.hideLoadingBar();
    this.globals.showLoadingBar();

    this.dataService
      .loadData(false)
      .pipe(
        first(),
        finalize(() => {this.globals.hideLoadingBar();})
      )
      .subscribe(
        {
          next: (tranData: any) => this.onGotRecords(tranData),
          error: (error: any) => this.onErrorGotRecords(error)
        }
      );
  }

  getPieChartSeries(): Highcharts.SeriesOptionsType[] {
    let series: Highcharts.SeriesOptionsType[] = [];

    const total = this.getTotal('Total');

    if (this.tranType == 'Fraudulent' || this.tranType == 'Rejection') {
      return series;
    }

    const showChart = total > 0;

    series.push({
      type: 'pie',
      visible: showChart,
      name: 'Total',
      data: [{
        name: 'Approved',
          y: this.getTotal('Approved'),
          color: '#4BCD3E',
          dataLabels: {
            enabled: true,
            distance: -55,
            y: -20,
            useHTML: true,
            format: '<div style="text-align: center; font-weight: normal;">Total</div><div style="text-align: center;">{point.total}</div>',
            style: {
              fontSize: '15px',
            }
          }
        }, {
          name: 'Declined',
          y: this.getTotal('Declined'),
          color: 'red'
        }, {
          name: 'Reversed',
          y: this.getTotal('Reversed'),
          color: '#C46210'
        }],
        center: [70, 0],
        size: 110,
        innerSize: '70%',
        showInLegend: false,
        dataLabels: {
          enabled: false
        },
    });

    return series;
  }

  getLineChartSeriesOptions(tranType: string): Highcharts.SeriesOptionsType {
    var data = this.getPosTrans(tranType);
    if (data == null) return null;

    var showLegent = true;
    let color: string, symbol: string;

    if (tranType == 'Approved') {
      color = '#4BCD3E';
      symbol = 'square';
    }
    if (tranType == 'Reversed') {
      color = '#C46210';
      symbol = 'triangle-down';
    }
    else if (tranType == 'Declined') {
      color = 'red';
      symbol = 'diamond';
    }
    else if (tranType == 'Total') {
      color = '#2CAFFE';
      symbol = 'circle';
    }

    if (this.tranType == 'Fraudulent' || this.tranType == 'Rejection') {
      showLegent = false;
    }

    return {
      type: 'spline',
      name: tranType,
      cursor: 'pointer',
      color: color,
      marker: {
        symbol: symbol
      },
      showInLegend: showLegent,
      data: data,
      events: {
        click: (event) => {
          this.onLineChartClick(event);
        },
      }
    }
  }

  getLineChartSeries(): Highcharts.SeriesOptionsType[] {
    let series: Highcharts.SeriesOptionsType[] = [];

    const approvedTransOption = this.getLineChartSeriesOptions('Approved');
    const declinedTransOption = this.getLineChartSeriesOptions('Declined');
    const reversedTransOption = this.getLineChartSeriesOptions('Reversed');
    const totalTransOption = this.getLineChartSeriesOptions('Total');

    if (approvedTransOption != null) series.push(approvedTransOption);
    if (declinedTransOption != null) series.push(declinedTransOption);
    if (reversedTransOption != null) series.push(reversedTransOption);
    if (totalTransOption != null) series.push(totalTransOption);

    return series;
  }

  setPosTransChartOptions(): void {
    this.posTransChartOptions = {
      chart: {
        type: 'spline',
        scrollablePlotArea: {
          minWidth: this.getMinWidth()
        }
      },
      title: {
          text: this.cardTitle
      },
      credits:{enabled:false},
      //subtitle: this.getChartSubtitle(),
      xAxis: {
        categories: [...this.dashboardData.filter((item) => item.name == 'Total').map((item) => item.series.map((c) => c.name))[0]],
        crosshair: true,
        labels: {
          formatter: function () {
            const label = this.axis.defaultLabelFormatter.call(this);
            if (label.length > 15 && label.includes('-')) {
              var labelParts = label.split("-");
              return `${labelParts[0].trim()}<BR>To<BR>${labelParts[1].trim()}`
            }
            return label;
          }
        },
        scrollbar: {
            enabled: true
        },
      },
      yAxis: [{ // left y axis
        title: {
            text: null
        },
        labels: {
            align: 'left',
            x: 3,
            y: -3,
            format: '{value:.,0f}'
        },
      }, { // right y axis
          linkedTo: 0,
          gridLineWidth: 0,
          opposite: true,
          title: {
              text: null
          },
          labels: {
              align: 'right',
              x: -10,
              y: -3,
              format: '{value:.,0f}'
          },
      }],
      tooltip: {
        shared: true,
        useHTML: true,
        borderColor: 'black',
        style: {
          fontSize: '14px'
        },
        headerFormat: '<table style="width: 150px;"><tr><th colspan="2">{point.key}</th></tr>',
        pointFormat: '<tr><td style="color: {point.color}">{series.name} ' +
            '</td>' +
            '<td style="text-align: right"><b>{point.y}</b></td></tr>',
        footerFormat: '</table>',
      },
      legend: {
        labelFormatter: function() {
          const series: any = this as Highcharts.Series;
          const seriesSum = (series.yData || []).reduce((sum,point)=> sum+(point || 0),0);
          return `${series.name} (Total: ${seriesSum})`;
        }
      },
      plotOptions: {
        spline: {
          marker: {
            radius: 4,
            lineColor: '#666666',
            lineWidth: 1
          }
        }
      },
      series: [
        ...this.getLineChartSeries(),
        ...this.getPieChartSeries()
      ],
    };
  }

  getTotal(tranType: string): number {
    if (this.dashboardData.filter((item) => item.name == tranType).length == 0) {
      return null;
    }

    return this.dashboardData.filter((item) => item.name == tranType).map((item) => item.series.map((c) => c.value))[0].reduce(function(a, b) { return a + b; })
  }

  getSubtitle(): string {
    const total: number = this.getTotal('Total');
    return total == 0 ? `No Transaction Exists` : `Total Transactions: ${total}`;
  }

  getChartSubtitle(): Highcharts.SubtitleOptions {
    const total: number = this.getTotal('Total');
    const title = total == 0 ? `No Transaction Exists` : `Total Transactions: ${total}`;
    const color = total == 0 ? 'red' : 'black';
    const fontWeight = total == 0 ? 'bold' : 'medium';
    return {
      useHTML: true,
      text: title,
      floating: true,
      verticalAlign: 'top',
      style: { color: color, fontSize: 15, fontWeight: fontWeight},
    };
  }

  getMinWidth(): number {
    const minWidth = 550;
    const calculatedWidth = this.dashboardData.filter((item) => item.name == 'Total').map((item) => item.series.map((c) => c.name))[0].length * 70;
    return calculatedWidth < minWidth ? minWidth : calculatedWidth;
  }

  getPosTrans(tranType: string): any[] {
    if (this.dashboardData.filter((item) => item.name == tranType).length == 0)
      return null;

    return this.dashboardData.filter((item) => item.name == tranType).map((item) => item.series.map((c) => c.value))[0]
  }

  onGotRecords(wr: WorkRequest): void {
    const workRequest = wr;
    this.globals.setErrorMessage('');

    if (!this.responseCollectionHasData(wr)) return;

    if (wr.collections["POSTRANVW_DTL_COL"] != null && wr.collections["POSTRANVW_DTL_COL"].rows != null) {
      this.txnDetailDataList = wr.collections["POSTRANVW_DTL_COL"].rows;
      this.txnTableDataTable.dataSource.data = this.txnDetailDataList;
      this.showTrans = true;
      this.setDetailTablePaginationData(wr);
      return;
    }

    if (wr.collections[this.collectionId] == null || wr.collections[this.collectionId].rows == null) {
      this.globals.setErrorMessage('No Data found');
      return;
    }

    this.showChart = true;
    const rows = workRequest.collections[this.collectionId].rows;

    let multiDtoList: ChartMultiDTO[] = [];

    let approvedTransDtoList: ChartDTO[] = [];
    let declinedTransDtoList: ChartDTO[] = [];
    let reversedTransDtoList: ChartDTO[] = [];
    let totalTransDtoList: ChartDTO[] = [];

    rows.forEach((c, index) => {
      let approvedTransDto = new ChartDTO(c.transactionDate + ' ', c.approvedTrans);
      let declinedTransDto = new ChartDTO(c.transactionDate + ' ', c.declinedTrans);
      let reversedTransDto = new ChartDTO(c.transactionDate + ' ', c.reversedTrans);
      let totalTransDto = new ChartDTO(c.transactionDate + ' ', c.totalTrans);

      approvedTransDtoList.push(approvedTransDto);
      declinedTransDtoList.push(declinedTransDto);
      reversedTransDtoList.push(reversedTransDto);
      totalTransDtoList.push(totalTransDto);
    });

    let approvedLegendLabelValue = "Approved";
    let declinedLegendLabelValue = "Declined";
    let reversedLegendLabelValue = "Reversed";
    let totalLegendLabelValue = "Total";

    if (this.tranRange != this.WeeklyTranRange && this.tranRange != this.MonthlyTranRange && this.tranRange != this.QuartelyTranRange) {
      let approvedTotal = approvedTransDtoList.map(a => a.value).reduce(function(a, b) { return a + b; });
      let declinedTotal = declinedTransDtoList.map(a => a.value).reduce(function(a, b) { return a + b; });
      let reversedTotal = reversedTransDtoList.map(a => a.value).reduce(function(a, b) { return a + b; });
      let total = totalTransDtoList.map(a => a.value).reduce(function(a, b) { return a + b; });

      approvedLegendLabelValue = `${approvedLegendLabelValue} - ${approvedTotal}`
      declinedLegendLabelValue = `${declinedLegendLabelValue} - ${declinedTotal}`
      reversedLegendLabelValue = `${reversedLegendLabelValue} - ${reversedTotal}`
      totalLegendLabelValue = `${totalLegendLabelValue} - ${total}`
    }

    if (this.tranType == this.SalesTranType || this.tranType == "Chargeback") {
      multiDtoList.push(new ChartMultiDTO("Approved", approvedTransDtoList));
      multiDtoList.push(new ChartMultiDTO("Declined", declinedTransDtoList));
    }
    if (this.tranType == this.SalesTranType) {
      multiDtoList.push(new ChartMultiDTO("Reversed", reversedTransDtoList));
    }
    if (this.tranType == this.SalesTranType || this.tranType == "Chargeback") {
    }
    multiDtoList.push(new ChartMultiDTO("Total", totalTransDtoList));

    this.dashboardData = JSON.parse(JSON.stringify(multiDtoList));

    this.setCardTitle();
    this.setChartLabelText();
    this.setPosTransChartOptions();
    this.cdr.markForCheck();

    const totalTrans: number = this.getTotal('Total');

    if(totalTrans == 0){
      this.globals.setErrorMessage('No Data found');
    }
  }

  setChartLabelText(): void {
    switch(this.tranRange) {
      case this.HourlyTranRange: {
        this.chartLabelText = "5 Minutes Interval (HH:MM:SS - HH:MM:SS)";
        break;
      }
      case this.TodayTranRange: {
        this.chartLabelText = "1 Hour Interval (HH:MM:SS - HH:MM:SS)";
        break;
      }
      case this.YesterdayTranRange: {
        this.chartLabelText = "1 Hour Interval (HH:MM:SS - HH:MM:SS)";
        break;
      }
      case this.WeeklyTranRange: {
        this.chartLabelText = "Week Number";
        break;
      }
      case this.MonthlyTranRange: {
        this.chartLabelText = "Month And Year";
        break;
      }
      case this.QuartelyTranRange: {
        this.chartLabelText = "Quarter";
        break;
      }
      case this.CustomTranRange: {
        this.chartLabelText = "Date";
        break;
      }
    }
  }

  setCardTitle(): void {
    let tranRange = this.tranRange == this.CustomTranRange ? '' : `${this.tranRange} `;

    if (tranRange.includes(this.HourlyTranRange)) {
      tranRange = `Last ${tranRange}`
    }
    else if (tranRange.includes(this.TodayTranRange)) {
      tranRange = `${tranRange}(${this.datePipe.transform(new Date(), 'dd-MMM-yyyy')}) `
    }
    else if (tranRange.includes(this.YesterdayTranRange)) {
      const yesterdayDate = this.getPastDate(1);
      tranRange = `${tranRange}(${yesterdayDate}) `
    }
    if (tranRange.includes(this.WeeklyTranRange)) {
      tranRange = `${tranRange}(Last 12 Weeks) `
    }
    else if (tranRange.includes(this.MonthlyTranRange)) {
      tranRange = `${tranRange}(Last 12 Months) `
    }
    else if (tranRange.includes(this.QuartelyTranRange)) {
      tranRange = `${tranRange}(Current Year) `
    }

    this.cardTitle = `${tranRange}${this.tranType} Transactions`

    if (this.tranRange == this.CustomTranRange) {
      this.cardTitle = `${this.cardTitle} From: ${this.fromDate} To: ${this.dateTo}`
    }
  }

  getPastDate(dayCount: number): string {
    const yesterday = new Date(new Date());
    yesterday.setDate(yesterday.getDate() - dayCount);
    return this.datePipe.transform(yesterday, 'dd-MMM-yyyy');
  }

  setTxnDetailCardTitle() {
    const tranStatus = this.tranStatus == "Total" ? "" : `${this.tranStatus} `;
    if (this.tranRange == this.HourlyTranRange || this.tranRange == this.TodayTranRange) {
      const tranPeriods = this.tranPeriod.trim().split("-");
      const currentDate = this.datePipe.transform(new Date(), 'dd-MMM-yyyy');
      this.txnDetailCardTitle = `${tranStatus}${this.tranType} Transactions From ${currentDate} ${tranPeriods[0]} To ${currentDate} ${tranPeriods[1]}`
    }
    else if (this.tranRange == this.YesterdayTranRange) {
      const tranPeriods = this.tranPeriod.trim().split("-");
      const yesterdayDate = this.getPastDate(1);
      var toDate = yesterdayDate;
      if (tranPeriods[1] == '00:00:00') {
        toDate = this.getPastDate(0);
      }
      this.txnDetailCardTitle = `${tranStatus}${this.tranType} Transactions From ${yesterdayDate} ${tranPeriods[0]} To ${toDate} ${tranPeriods[1]}`
    }
    else if (this.tranRange == this.WeeklyTranRange) {
      this.txnDetailCardTitle = `${tranStatus}${this.tranType} Transactions For Week ${this.tranPeriod}`
    }
    else if (this.tranRange == this.MonthlyTranRange) {
      this.txnDetailCardTitle = `${tranStatus}${this.tranType} Transactions For Month ${this.tranPeriod}`
    }
    else if (this.tranRange == this.QuartelyTranRange) {
      this.txnDetailCardTitle = `${tranStatus}${this.tranType} Transactions For Quarter ${this.tranPeriod}`
    }
    else if (this.tranRange == this.CustomTranRange) {
      this.txnDetailCardTitle = `${tranStatus}${this.tranType} Transactions For Date ${this.tranPeriod}`
    }
  }

  getChartMultiItem(logDate: string, count: any, status: any) {
    let cardDto = new ChartDTO(logDate, count);
    let chartDtoList = [cardDto];
    return new ChartMultiDTO(status, chartDtoList);
  }

  responseCollectionHasData(wr: WorkRequest): boolean {
    return (
      wr != null
      && wr !== undefined
      && wr.collections != null
    );
  }

  setDetailTablePaginationData(wr: WorkRequest): void {
      if (this.criteria["ist_total"] !== "y") {
        return;
      }

      DataTableEditableDetailComponent.totalDTLRecords = +wr.lastModified;
      this.txnTableDataTable.length = +wr.lastModified;
      this.txnTableDataTable.totalRecords = +wr.lastModified;
  }

  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  setT21Tags(): void {
    this.requestTypeId = 'POSTRANVW';
    this.metaDataId = 'POSTRANVW';
    this.tabId = 'POSTRANVW_TAB';
    this.sectionId = 'POSTRANVW_SEC';
    this.collectionId = 'POSTRANVW_COL';
  }

  get darkMode(): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
    this.clearErrorMessage();
  }

  validateBeforeQuery(): boolean {
    CustomValidators.globals = this.globals;
    this.fromDate = CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo = CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat);

    let result: boolean = true;
    if (CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField)) {
      if (CustomValidators.isFutureDate(CustomValidators.convertToDate(this.fromDate, this.globals.dateFormat)) ||
        CustomValidators.isFutureDate(CustomValidators.convertToDate(this.dateTo, this.globals.dateFormat))) {
        this.globals.setErrorMessage('Future Dates are not allowed!');
        result = false;
      }
    } else {
      result = false;
    }
    return result;
  }

  search(): void {
    this.showChart = false;
    this.showTrans = false;
    if (this.validateBeforeQuery()) {
      this.removeTransDetailSearchCriteria();
      this.adjustCriteria();
      this.retriveData();
    }
  }

  removeTransDetailSearchCriteria(): void {
    this.criteria["isTxnDetailReq"] = "false";
    this.criteria["ist_total"] = "n";
    this.criteria["tranPeriod"] = "";
    this.criteria["tranStatus"] = "";
  }

  clear(): void {
    this.globals.setErrorMessage('');
    this.fromDate = "MM/dd/yyyy";
    this.dateTo = "MM/dd/yyyy";
    this.resetDetailTable();
    this.showChart = false;
    this.showTrans = false;
    //super.clear();
  }

  onLineChartClick(event: Highcharts.SeriesClickEventObject) {
    this.globals.setErrorMessage('');

    this.setCriteriaFromEventData(event);
    this.setTxnDetailCardTitle();

    if (event.point.y == 0) {
      this.showTrans = false;
      this.globals.setErrorMessage(`${this.txnDetailCardTitle} not exists.`)
      return;
    }

    super.criteria = this.criteria;
    this.criteria["isTxnDetailReq"] = "true";
    this.criteria["ist_total"] = "y";
    this.criteria["tranPeriod"] = this.tranPeriod;
    this.criteria["tranStatus"] = this.tranStatus;
    this.criteria[this.pageCtrl] = "1";

    this.txnTableDataTable.paginator.pageIndex = 0;
    this.resetDetailTable();
    this.retriveData();

    this.showTrans = true;
    this.txnTableDataTable.dataSource.data = this.txnDetailDataList;
  }

  setCriteriaFromEventData(event: Highcharts.SeriesClickEventObject) {
    this.tranPeriod = event.point.category.toString();
    this.tranStatus = event.point.series.name;
  }

  resetDetailTable(): void {
    this.txnDetailDataList = null;
    this.txnTableDataTable.dataSource.data = this.txnDetailDataList;
  }

  moreDetails(pageEvent: PageEvent): void {
    this.criteria["isTxnDetailReq"] = "true";
    this.criteria["ist_total"] = "n";
    this.criteria[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
    this.globals.showLoadingBar();
    this.retriveData();
  }
}
