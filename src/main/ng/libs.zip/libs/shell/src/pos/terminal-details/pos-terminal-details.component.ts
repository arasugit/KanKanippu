import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../../permission/mkcform.permission';
import { FormActionPermission } from '../../permission/form.action.permission';
import { ListComponent } from '../../components/base-list.component';
import { CustomValidators, StringUtil } from '../../common';
import { T21Base } from '../../components';
import { LabelAndValue, LabelsAndValues } from '../../common/labels-and-values';
import { GlobalsService } from '../../services';
import { Location } from '@angular/common';

@Component({
    selector: 'pos-details-app',
    templateUrl : './pos-terminal-details.component.html',
    styleUrls: ['./pos-terminal-details.component.scss'],
    encapsulation: ViewEncapsulation.None
})

export class PosTerminalDetailsComponent extends ListComponent implements OnInit {
  constructor(injector: Injector, private location: Location) {
    super(injector);
    this.type="A";
    this.ist_status=this.type;
  }
   FORM_TITLE = 'POS Terminal Details';
   exportFileName = 'POS Terminal Details';
   product = '';

   terminalRecord ='';
   terminalId = '';
   entityId = '';
   terminalType = '';
   entityName = '';
   ist_status = '';
   statusList: LabelsAndValues = new LabelsAndValues();
   ist_inst_Id = '*';

  @ViewChild('toDateFocusField', { static: false })
  toDateFocusField: T21Base;

   queryPerm = new FormActionPermission('POSTERDETA', 'Q');
   checkerPerm = new FormActionPermission('POSTERDETA', 'C');
   mkcPerm = new MKCPermission('POSTERDETA');

   adjustCriteria(): void {
  //  this.criteria['productId']= 'ISTSWT';

    this.criteria['ist_inst_Id'] = this.ist_inst_Id;
    this.criteria['ist_status']= this.ist_status;
    this.criteria['terminalRecord']=this.terminalRecord;
    this.criteria['terminalId']=this.terminalId;
    this.criteria['terminalType']=this.terminalType;
    this.criteria['entityId']=this.entityId;

    this.criteria['COMMAND']='query';
   }

    type = '';

   ngOnInit() {
    super.ngOnInit();

    this.type="A";
    this.ist_status = this.type;

    this.showBackBtn=GlobalsService.isRedirected;
    this.ist_inst_Id = GlobalsService.param?.InstitutionId ?? this.ist_inst_Id;
    this.ist_status = GlobalsService.param?.StatusCode ?? this.ist_status;
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.FORM_TITLE='POS Terminal Details';
    this.exportFileName = 'POS Terminal Details';
    this.setAutoRefreshSearch(true);

    this.statusList.array = [new LabelAndValue('All', 'A'), new LabelAndValue('Normal', 'N'), new LabelAndValue('Reject all request', 'Y')];
   }

   ngAfterViewInit(): void {
    if (GlobalsService.isRedirected == undefined || !GlobalsService.isRedirected) {
      return;
    }

    GlobalsService.isRedirected = false;
    GlobalsService.param = null;

    this.adjustCriteria();
    this.doSearch();
   }

  setT21Tags(): void {
    this.requestTypeId = 'POSTERDETA';
    this.metaDataId = 'POSTERDETA';
    this.tabId = 'POSTERDETA_TAB';
    this.sectionId = 'POSTERDETA_SEC';
    this.collectionId = 'POSTERDETA_COL';
	}

  validateBeforeQuery(): boolean {
    this.globals.setErrorMessage('');
    CustomValidators.globals=this.globals;

    if (StringUtil.isEmpty(this.ist_inst_Id)) {
      this.globals.setErrorMessage('Select Institution Id');
      this.setFocusToFirstField();
      return false;
    }

    return true;
  }

  getModuleName() { return 'IST-MONITORING'; }
  emitModuleReady() { this.msgService.sendMessage(this.getModuleName()); }

  goBack() {
    this.clearErrorMessage();
    this.globals.setErrorMessage('');
    this.location.back();
  }
}
