import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../../ist-components/ist-components.module';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule, RufScrollbarModule } from '@ruf/shell';
import { PosTerminalDetailsComponent } from './pos-terminal-details.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TranslateLazyLoadModule } from '../../ist-components/ist-translate-lazyload-module';
import { MatDividerModule } from '@angular/material/divider';

export const posDetailsData: MonitorComponentData = {
  title: 'POS Terminal Details',
  icon: 'POS Terminal Details',
  examples: {
      'POSTERDETA': {
          label: 'POS Terminal Details',
          title: 'POS Terminal Details',
          description: 'POS Terminal Details',
          rufId: 'pos_details',
          component: PosTerminalDetailsComponent
      }
  }
};

@NgModule({
    imports :[
      CommonModule,
      CdkScrollable,
      MatTableModule,
      FormsModule,
      FlexLayoutModule,
      ReactiveFormsModule,
      TranslateLazyLoadModule,
      ISTComponentModule,
      MatDividerModule,
      MatCardModule,
      RufScrollbarModule,
      RufCommonModule,
      RufCardModule,
  ],
  declarations: [PosTerminalDetailsComponent],
  providers: [{ provide: MON_TOOL, useValue: posDetailsData }],
  exports:[],
})
export class PosTerminalDetailsModule {}
