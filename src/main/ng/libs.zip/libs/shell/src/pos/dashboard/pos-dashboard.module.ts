import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RufCardModule } from '@ruf/shell';
import { ISTComponentModule } from '../../ist-components';
import { MON_TOOL, MonitorComponentData } from '../../monitor-components/common-object';
import { PosDashboardComponent } from './pos-dashboard.component';
import { HighchartsChartModule } from 'highcharts-angular';

export const posDashboardData: MonitorComponentData = {
  title: 'POS Dashboard',
  icon: 'table',
  examples: {
      'POSDASH': {
          label: 'POS Dashboard',
          title: 'POS Dashboard',
          description: 'POS Dashboard',
          rufId: 'pos_dashboard',
          component: PosDashboardComponent
      }
  }
};

@NgModule({
  declarations:[PosDashboardComponent],
  imports: [
    FlexLayoutModule,
    RufCardModule,
    ISTComponentModule,
    HighchartsChartModule
   ],
  exports:[PosDashboardComponent],
  providers: [{ provide: MON_TOOL, useValue: posDashboardData }],
})

export class PosDashboardModule {}
