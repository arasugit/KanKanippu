export * from './pos-dashboard.component';
export * from './pos-dashboard.module';
