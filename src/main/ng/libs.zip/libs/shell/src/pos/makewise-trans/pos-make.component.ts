import {Component, ViewEncapsulation, OnInit, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef, ViewChild, ElementRef} from '@angular/core';
import { Subject, takeUntil} from 'rxjs';
import { DataTableEditableComponent, ListComponent, T21Base } from '../../components';
import { FormActionPermission, MKCPermission } from '../../permission';
import { DataTableService } from '../../services';
import { WorkRequest } from '../../ist-components';
import { PageEvent } from '@angular/material/paginator';
import * as Highcharts from "highcharts";
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import HighchartsMore from "highcharts/highcharts-more";
HighchartsMore(Highcharts)
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);
@Component({
  selector: 'pos-makewise-txns',
  templateUrl: './pos-make.component.html',
  styleUrls: ['./pos-make.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class POSMakewiseTxnsComponent extends ListComponent implements OnInit,OnDestroy {
  private unsubscribe = new Subject();
  private transByMakeData: any[] = [];
  private successPercent: number = 0;
  private failurePercent: number = 0;

  chartType : any = 'pie-chart';
  screenType: any;
  dataLoaded: boolean = false;
  cardTitle: any;
  cardTitleKPI: any;
  cardTitleTxn: any="POS Makewise Transactions";
  isDetailsTab: boolean = true;
  txnDetailDataList: any=[];
  txnSrcAcq: any;
  eventName: any;
  @ViewChild('firstUpdateField', { static: false })
  firstUpdateField: T21Base;
  @ViewChild('txntableDataTable', { static: false }) private txntableDataTable: DataTableEditableComponent;

  public Highcharts: typeof Highcharts = Highcharts;
  public transByMakeChartOptions: Highcharts.Options;
  public transKpiChartOptions: Highcharts.Options;

  constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker, @Inject(ElementRef) private element: ElementRef){
      super(injector);
      this.route
      .data
      .subscribe(v => this.screenType=v['module']);
      this.adjustCriteria();
      this.retriveData();
  }

  ngAfterViewInit() {
    super.criteria = this.criteria;
    this.setAutoRefreshInterval();
    this.setAutoRefreshRetriveDataInterval();
  }

  adjustCriteria(): void {
    this.globals.setErrorMessage('');
  //  this.criteria['productId']= 'ISTSWT';
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['isDetailReq']= 'false';
    this.criteria['ist_page_ctrl'] = '1';
    this.criteria['ist_total'] = 'Y';
    this.criteria['COMMAND']='query';
  }

  retriveData():void{
    this.dataService.requestType = this.requestTypeId;
    this.dataService.collectionTag = this.collectionId;
    this.dataService.action = 'query';
    this.dataService.criteria = this.criteria;

    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        atmData => this.onGotRecords(atmData),
        error => this.onRetriveDataError(error),
        () => this.globals.hideLoadingBar()
      );
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnInit(){
    super.ngOnInit();
    if(this.screenType == 'POSMAKE'){
      this.cardTitle='POS Makewise Transactions - 5 Mins';
      this.exportFileName='POS Makewise Transactions - 5 Mins';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'HOURLY'){
      this.cardTitle='POS Makewise Transactions - Hourly';
      this.exportFileName='POS Makewise Transactions - Hourly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'DAILY'){
      this.cardTitle='POS Makewise Transactions - Daily';
      this.exportFileName='POS Makewise Transactions - Daily';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'WEEKLY'){
      this.cardTitle='POS Makewise Transactions - Weekly';
      this.exportFileName='POS Makewise Transactions - Weekly';
      this.cardTitleKPI='Percentage KPIs';
    }else  if(this.screenType == 'MONTHLY'){
      this.cardTitle='POS Makewise Transactions - Monthly';
      this.exportFileName='POS Makewise Transactions - Monthly';
      this.cardTitleKPI='Percentage KPIs';
    }
  }

  onGotRecords(wr: WorkRequest): void {
    this.dataLoaded = false;
    this.transByMakeData.length = 0;

    if(wr.lastModified == -1){
      this.globals.setErrorMessage('No Data found');
    }

    if(wr == null
      || wr === undefined
      || wr.collections == null
      || wr.collections[this.collectionId] == null) {
        return;
    }

    if(wr.collections['POSMAKE_DTL_COL'] !=null && wr.collections['POSMAKE_DTL_COL'].rows != null) {
      this.txnDetailDataList = wr.collections['POSMAKE_DTL_COL'].rows;
      this.txntableDataTable.dataSource.data = this.txnDetailDataList;
      DataTableEditableComponent.isTxnDetailScreen = true;
      this.setDetailTablePaginationData(wr);
    }

    const rows = wr.collections[this.collectionId].rows ?? [];
    let totalCnt: number, successCnt: number, failureCnt: number = 0;

    rows.forEach((c) => {
      this.transByMakeData.push({
        name: c.posTerminalType,
        fail: c.failureTxnsCount,
        success: c.successfulTxnsCount,
      });

      successCnt =+ c.successfulTxnsCount;
      failureCnt =+ c.failureTxnsCount;
      totalCnt =+ successCnt + +failureCnt;
    });

    if (rows.length > 0) {
      this.successPercent = +((successCnt/totalCnt)*100).toFixed(2);
      this.failurePercent = +((failureCnt/totalCnt)*100).toFixed(2);
    }

    this.dataLoaded = true;

    this.cdr.markForCheck();
    this.setTransByMakeChartOptions();
    this.setTransKpiChartOptions();
  }

  setDetailTablePaginationData(wr: WorkRequest): void {
      if (this.criteria["ist_total"] !== "Y") {
        return;
      }

      DataTableEditableComponent.totalDTLRecords = +wr.lastModified;
      this.txntableDataTable.length = +wr.lastModified;
      this.txntableDataTable.totalRecords = +wr.lastModified;
  }

  setTransByMakeChartOptions(): void {
    this.transByMakeChartOptions = {
      credits: this.getChartCreditOptions(),
      chart: {
        type: "column",
        height: 350,
      },
      ...this.getColumnChartLegendOptions(),
      legend: {
        labelFormatter: function() {
          const series: any = this as Highcharts.Series;
          const seriesSum = (series.yData || []).reduce((sum,point)=> sum+(point || 0),0);
          return `${series.name} (Total: ${seriesSum})`;
        }
      },
      ...this.getChartTitle("Makewise Transactions"),
      tooltip: {
        style: { fontSize: '14px' },
        useHTML: true,
        followPointer: true,
        headerFormat: '<table><tr><th colspan="2">{point.x}</th></tr>',
        pointFormat: '<tr><td style="color: {point.color};">{series.name}&nbsp;&nbsp;&nbsp;&nbsp;' +
            '</td>' +
            '<td style="text-align: left;"><b>{point.y}</b> ({point.percentage:.0f}%)</td></tr>' +
            '<tr><td>Total: </td><td style="text-align: left;"><b>{point.stackTotal}</b></td></tr>',
        footerFormat: '</table>',
      },
      plotOptions: {
        column: {
          stacking: "normal",
          cursor: "pointer",
          dataLabels: {
            enabled: true,
          },
          events: {
            click: (event) => {
              this.onTransByMakeChartClick(event);
            },
          },
        },
      },
      xAxis: {
        categories: [
          ...new Set(this.transByMakeData.map((item) => item.name)),
        ],
      },
      yAxis: {
        min: 0,
        title: {
          text: "Transaction Count",
        },
        stackLabels: {
          enabled: true,
        },
      },
      series: [
        {
          name: "Successful",
          color: Highcharts.getOptions().colors[2],
          data: [
            ...this.transByMakeData.map(function (a) {
              return a.success;
            }),
          ],
        },
        {
          name: "Failure",
          color: Highcharts.getOptions().colors[3],
          data: [
            ...this.transByMakeData.map(function (a) {
              return a.fail;
            }),
          ],
        },
      ],
    };
  }

  setTransKpiChartOptions(): void {
    this.transKpiChartOptions= {
      chart: {
        type: 'solidgauge',
        height: 350
      },
      credits:{
        enabled: false,
      },
      title: {
        text: "Percentage KPIs",
      },
      tooltip: {
        borderWidth: 0,
        backgroundColor: 'none',
        shadow: false,
        style: {
          fontSize: '14px'
        },
        valueSuffix: '%',
        useHTML: true,
        pointFormat: '<div style="text-align: center;">{series.name}</div>' +
          '<div style="text-align: center; font-weight: normal;"><span style="font-size: 2em; color: {point.color}; ' +
          'font-weight: bold">{point.y}</span></div>',
        positioner: function (labelWidth) {
          return {
            x: (this.chart.chartWidth - labelWidth) / 2 + 2,
            y: (this.chart.plotHeight / 2) + 17
          };
        }
      },
      pane: {
        startAngle: 0,
        endAngle: 360,
        background: [{
          outerRadius: '112%',
          innerRadius: '88%',
          backgroundColor: this.trackColors[2],
          borderWidth: 0
        }, {
          outerRadius: '87%',
          innerRadius: '63%',
          backgroundColor: this.trackColors[3],
          borderWidth: 0
        }]
      },
      legend: {
        labelFormatter: function() {
          const series: any = this as Highcharts.Series;
          return `${series.name} - ${series.yData} %`;
        }
      },
      yAxis: {
        min: 0,
        max: 100,
        lineWidth: 0,
        tickPositions: []
      },
      plotOptions: {
        solidgauge: {
          colorByPoint: false,
          dataLabels: {
            enabled: false,
          },
          linecap: 'round',
          stickyTracking: false,
          rounded: true,
        },
      },
      series: [{
        name: 'Success',
        showInLegend: true,
        color: Highcharts.getOptions().colors[2],
        data: [{
          color: Highcharts.getOptions().colors[2],
          radius: '112%',
          innerRadius: '88%',
          y: this.successPercent
        }],
      }, {
      name: 'Failure',
      showInLegend: true,
      color: Highcharts.getOptions().colors[3],
      data: [{
        color: Highcharts.getOptions().colors[3],
        radius: '87%',
        innerRadius: '63%',
        y: this.failurePercent
      }],
    }] as any
  }}

  trackColors = Highcharts.getOptions().colors.map(color =>
      new Highcharts.Color(color).setOpacity(0.3).get()
  );

  getChartTitle(text: string): Highcharts.Options {
    return {
      title: {
        text: text,
        margin: 0,
      },
    };
  }

  getChartCreditOptions(): Highcharts.CreditsOptions {
    return { enabled: false };
  }

  getColumnChartLegendOptions(): any {
    return {
      legend: {
        align: "center",
        verticalAlign: "bottom",
        backgroundColor:
          Highcharts.defaultOptions.legend.backgroundColor || "white",
        borderColor: "#CCC",
        borderWidth: 1,
        shadow: false,
      },
    };
  }

  onRetriveDataError(error: Object): void {
    this.globals.hideLoadingBar();
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  getEntPermList(): any[] {
    this.entObjectId = 'POSMAKE';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

  setT21Tags(): void {
    this.requestTypeId = 'POSMAKE';
    this.metaDataId = 'POSMAKE';
    this.tabId = 'POSMAKE_TAB';
    this.sectionId = 'POSMAKE_SEC';
    this.collectionId = 'POSMAKE_COL';
  }

  ngOnDestroy() {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
    this.clearErrorMessage();
  }

  onTransByMakeChartClick(event: Highcharts.SeriesClickEventObject){
    this.globals.showLoadingBar();
    this.adjustCriteria();

    this.eventName = event.point.series.name;
    this.txnSrcAcq = event.point.category;

    this.criteria['isDetailReq']= 'true';
    this.criteria['eventName'] = this.eventName;
    this.criteria['txnSrcAcq'] = this.txnSrcAcq;

    this.txntableDataTable.paginator.pageIndex = 0;

    this.retriveData();

    this.cardTitleTxn = `${this.eventName} Transaction Details for ${this.txnSrcAcq}`;
    this.isDetailsTab = false;
    this.setFocusToFirstUpdateField();
  }


  moreDetails(pageEvent: PageEvent): void {
    this.criteria["isTxnDetailReq"] = "true";
    this.criteria["ist_total"] = "n";
    this.criteria[this.pageCtrl] = '' + ((pageEvent.pageIndex) + 1);
    this.globals.showLoadingBar();
    this.retriveData();
  }
}
