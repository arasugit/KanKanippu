import { NgModule } from '@angular/core';
import { MON_TOOL, MonitorComponentData } from '../../monitor-components/common-object';
import { PosTransOverviewComponent } from './pos-trans-overview.component';
import { PosSalesTransOverviewModule } from './pos-sales-trans-overview.module';

const pageName = 'POS Chargeback Transactions';

export const posChargebackTransOverviewData: MonitorComponentData = {
  title: pageName,
  icon: 'table',
  examples: {
    'HOURLY': {
        label: `${pageName} - 1 HR`,
        title: `${pageName} - 1 HR`,
        description: `${pageName} - 1 HR`,
        rufId: 'pos_trans_1hr',
        component: PosTransOverviewComponent
    },
    'DAILY': {
      label: `${pageName} - Today`,
      title: `${pageName} - Today`,
      description: `${pageName} - Today`,
      rufId: 'pos_trans_today',
      component: PosTransOverviewComponent
    },
    'YESTERDAY': {
      label: `${pageName} - Yesterday`,
      title: `${pageName} - Yesterday`,
      description: `${pageName} - Yesterday`,
      rufId: 'pos_trans_yesterday',
      component: PosTransOverviewComponent
    },
    'WEEKLY': {
      label: `${pageName} - Weekly`,
      title: `${pageName} - Weekly`,
      description: `${pageName} - Weekly`,
      rufId: 'pos_trans_weekly',
      component: PosTransOverviewComponent
    },
    'MONTHLY': {
      label: `${pageName} - Monthly`,
      title: `${pageName} - Monthly`,
      description: `${pageName} - Monthly`,
      rufId: 'pos_trans_monthly',
      component: PosTransOverviewComponent
    },
    'QUARTELY': {
      label: `${pageName} - Quartely`,
      title: `${pageName} - Quartely`,
      description: `${pageName} - Quartely`,
      rufId: 'pos_trans_quartely',
      component: PosTransOverviewComponent
    },
    'CUSTOM': {
      label: `${pageName} - Custom`,
      title: `${pageName} - Custom`,
      description: `${pageName} - Custom`,
      rufId: 'pos_trans_custom',
      component: PosTransOverviewComponent
    }
  },
};

@NgModule({
  imports: [
    PosSalesTransOverviewModule
   ],
  providers: [{ provide: MON_TOOL, useValue: posChargebackTransOverviewData }],
})

export class PosChargebackTransOverviewModule {}
