import { Component, Injector, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../../permission/mkcform.permission';
import { FormActionPermission } from '../../permission/form.action.permission';
import { ListComponent } from '../../components/base-list.component';
import { CustomValidators, LabelAndValue, LabelsAndValues, StringUtil } from '../../common';
import { GlobalsService } from '../../services';
import { Location } from '@angular/common';
import { T21Base } from '../../components';

@Component({
  selector: 'pos-merch',
  templateUrl: './pos-merch.component.html',
  styleUrls: ['./pos-merch.component.scss'],
  encapsulation: ViewEncapsulation.None
 })

export class POSMerchantComponent extends ListComponent implements OnInit {
  constructor(injector: Injector, private location: Location) {
    super(injector);
  }

  creationDateFrom:  string = '';
  creationDateTo: string = '';
  terminationDateFrom: string = '';
  terminationDateTo: string = '';
  ist_inst_Id = '';
  entityLevel = '';
  entityId = '';
  entityStatus = '';
  entityStatusList : LabelsAndValues = new LabelsAndValues();
  parentEntityId = '';
  dbaName = '';
  externalEntityId = '';

  @ViewChild('firstFocusField', { static: false })
  firstFocusField: T21Base;

  queryPerm = new FormActionPermission('POSMERCHNT', 'Q');
  checkerPerm = new FormActionPermission('POSMERCHNT', 'C');
  mkcPerm = new MKCPermission('POSMERCHNT');


  adjustCriteria(): void {
    this.criteria['ist_inst_Id'] = this.ist_inst_Id;
    this.criteria['parentEntityId'] = this.parentEntityId;
    this.criteria['entityLevel'] =this.entityLevel;
    this.criteria['entityId'] = this.entityId;
    this.criteria['dbaName'] = this.dbaName;
    this.criteria['entityStatus'] = this.entityStatus;
    this.criteria['externalEntityId'] = this.externalEntityId;
    this.criteria['creationDateFrom'] =this.creationDateFrom;
    this.criteria['creationDateTo'] = this.creationDateTo;
    this.criteria['terminationDateFrom'] = this.terminationDateFrom;
    this.criteria['terminationDateTo'] = this.terminationDateTo;

    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
  }

  ngAfterViewInit(): void {
    this.setAutoRefreshInterval();

    if (GlobalsService.isRedirected == undefined || !GlobalsService.isRedirected) {
      return;
    }

    GlobalsService.isRedirected = false;
    GlobalsService.param = null;

    this.adjustCriteria();
    this.doSearch();
  }

  ngOnInit() {
    super.ngOnInit();

    this.showBackBtn = GlobalsService.isRedirected;
    this.ist_inst_Id = GlobalsService.param ?? this.ist_inst_Id;

    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.FORM_TITLE = 'Merchant Details';
    this.exportFileName = 'Merchant Details'
    this.setAutoRefreshSearch(true);

    this.entityStatusList.array = [
      new LabelAndValue('Active', 'A'),
      new LabelAndValue('Closed', 'C'),
      new LabelAndValue('Seasonal', 'E'),
      new LabelAndValue('Fraud', 'F'),
      new LabelAndValue('Inactive', 'I'),
      new LabelAndValue('NonActive', 'N'),
      new LabelAndValue('Pending', 'P'),
      new LabelAndValue('Risk', 'R'),
      new LabelAndValue('Suspended', 'S'),
      new LabelAndValue('Terminated', 'T')
    ];
  }

  setT21Tags(): void {
    this.requestTypeId = 'POSMERCHNT';
    this.metaDataId = 'POSMERCHNT';
    this.tabId = 'POSMERCHNT_TAB';
    this.sectionId = 'POSMERCHNT_SEC';
    this.collectionId = 'POSMERCHNT_COL';
  }

  validateBeforeQuery(): boolean {
    this.globals.setErrorMessage('');
    CustomValidators.globals=this.globals;

    this.creationDateFrom=CustomValidators.formatDateString(this.creationDateFrom, this.globals.dateFormat);
    this.creationDateTo=CustomValidators.formatDateString(this.creationDateTo, this.globals.dateFormat);
    this.terminationDateFrom=CustomValidators.formatDateString(this.terminationDateFrom, this.globals.dateFormat);
    this.terminationDateTo=CustomValidators.formatDateString(this.terminationDateTo, this.globals.dateFormat);


    if (StringUtil.isEmpty(this.ist_inst_Id)) {
      this.globals.setErrorMessage('Select Institution Id');
      this.setFocusToFirstField();
      return false;
    }

    if((!StringUtil.isEmpty(this.creationDateFrom) && StringUtil.isEmpty(this.creationDateTo)) || (StringUtil.isEmpty(this.creationDateFrom) && !StringUtil.isEmpty(this.creationDateTo))){
      this.globals.setErrorMessage('Both set of creation date must be passed.');
      this.setFocusToFirstField();
      return false;
    }

    if((!StringUtil.isEmpty(this.terminationDateFrom) && StringUtil.isEmpty(this.terminationDateTo)) || (StringUtil.isEmpty(this.terminationDateFrom) && !StringUtil.isEmpty(this.terminationDateTo))){
      this.globals.setErrorMessage('Both set of termination date must be passed.');
      this.setFocusToFirstField();
      return false;
    }

    return true;
  }

  getModuleName() { return 'IST-MONITORING'; }
  emitModuleReady() { this.msgService.sendMessage(this.getModuleName()); }

  goBack() {
    this.clearErrorMessage();
    this.globals.setErrorMessage('');
    this.location.back();
  }
}
