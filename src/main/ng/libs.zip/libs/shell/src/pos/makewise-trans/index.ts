export * from './pos-make.component';
export * from './pos-make.module';
