import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ISTComponentModule } from '../../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../../monitor-components';
import { TranslateModule } from '@ngx-translate/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { POSMerchantComponent } from './pos-merch.component';


export const posMerchantDetails: MonitorComponentData = {
  title: 'POS Merchant Details',
  icon: 'home',
  examples: {
    'POSMERCHNT': {
      label: 'POS Merchant Details',
      title: 'POS Merchant Details',
      description: 'POS Merchant Details',
      rufId: 'posh_merch',
      component: POSMerchantComponent
    }
  }
};

@NgModule({
    imports :[
    CommonModule,
    ISTComponentModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    TranslateModule,
    MatFormFieldModule,
    MatInputModule

    ],
  declarations: [ POSMerchantComponent ],
  providers: [{ provide: MON_TOOL, useValue: posMerchantDetails }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[],
})
export class POSMerchantHomeModule {}
