export * from './pos-terminal-details.module';
export * from './pos-terminal-details.component';
