import { NgModule } from '@angular/core';
import { RufCardModule } from '@ruf/shell';
import { ISTComponentModule } from '../../ist-components';
import { MON_TOOL, MonitorComponentData } from '../../monitor-components/common-object';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PosTransOverviewComponent } from './pos-trans-overview.component';
import { DatePipe } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HighchartsChartModule } from "highcharts-angular";
import { CommonModule } from '@angular/common';

const pageName = 'POS Sales Transactions';

export const posSalesTransOverviewData: MonitorComponentData = {
  title: pageName,
  icon: 'table',
  examples: {
    'HOURLY': {
        label: `${pageName} - 1 HR`,
        title: `${pageName} - 1 HR`,
        description: `${pageName} - 1 HR`,
        rufId: 'pos_trans_1hr',
        component: PosTransOverviewComponent
    },
    'DAILY': {
      label: `${pageName} - Today`,
      title: `${pageName} - Today`,
      description: `${pageName} - Today`,
      rufId: 'pos_trans_today',
      component: PosTransOverviewComponent
    },
    'YESTERDAY': {
      label: `${pageName} - Yesterday`,
      title: `${pageName} - Yesterday`,
      description: `${pageName} - Yesterday`,
      rufId: 'pos_trans_yesterday',
      component: PosTransOverviewComponent
    },
    'WEEKLY': {
      label: `${pageName} - Weekly`,
      title: `${pageName} - Weekly`,
      description: `${pageName} - Weekly`,
      rufId: 'pos_trans_weekly',
      component: PosTransOverviewComponent
    },
    'MONTHLY': {
      label: `${pageName} - Monthly`,
      title: `${pageName} - Monthly`,
      description: `${pageName} - Monthly`,
      rufId: 'pos_trans_monthly',
      component: PosTransOverviewComponent
    },
    'QUARTELY': {
      label: `${pageName} - Quartely`,
      title: `${pageName} - Quartely`,
      description: `${pageName} - Quartely`,
      rufId: 'pos_trans_quartely',
      component: PosTransOverviewComponent
    },
    'CUSTOM': {
      label: `${pageName} - Custom`,
      title: `${pageName} - Custom`,
      description: `${pageName} - Custom`,
      rufId: 'pos_trans_custom',
      component: PosTransOverviewComponent
    }
  },
};

@NgModule({
  declarations:[PosTransOverviewComponent],
  imports: [
    CommonModule,
    ISTComponentModule,
    FormsModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    MatCardModule,
    MatInputModule,
    RufCardModule,
    MatButtonToggleModule,
    MatTabsModule,
    HighchartsChartModule
   ],
  exports:[PosTransOverviewComponent],
  providers: [{ provide: MON_TOOL, useValue: posSalesTransOverviewData }, DatePipe],
})

export class PosSalesTransOverviewModule {}
