import {Component, ViewEncapsulation, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef } from '@angular/core';
import { finalize, first } from 'rxjs/operators';
import { ListComponent } from '../../components';
import { DataTableService } from '../../services';
import { WorkRequest } from '../../ist-components';
import { ChartDTO } from '../chart-dto';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
import cylinder from 'highcharts/modules/cylinder';
cylinder(Highcharts);
import dumbbell from 'highcharts/modules/dumbbell';
dumbbell(Highcharts);
import lollipop from 'highcharts/modules/lollipop';
lollipop(Highcharts);
import highcharts3d from 'highcharts/highcharts-3d';
highcharts3d(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);

@Component({
  selector: 'pos-dashboard',
  templateUrl: './pos-dashboard.component.html',
  styleUrls: ['../../transaction/transaction.scss', 'pos-dashboard.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class PosDashboardComponent extends ListComponent implements OnDestroy {
  screenType: any;
  merchantData: any[];
  terminalData: any[];
  termFunctionalStatusData:any[];
  Highcharts: typeof Highcharts = Highcharts;
  chartOptionsmerchant: Highcharts.Options;
  chartOptionsTerminal: Highcharts.Options;
  chartOptionsTermFunctional: Highcharts.Options;
  merchantChartData: any[];
  terminalChartData: any[];
  termFunctionalChartData: any[];

  constructor(private injector: Injector, private dataService: DataTableService, private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker) {
      super(injector);

      this.route
      .data
      .pipe(first())
      .subscribe(v => this.screenType=v['module']);

      this.adjustCriteria();
      this.retriveData();
  }

  adjustCriteria(): void {
    this.globals.setErrorMessage('');
  //  this.criteria['productId'] = 'ISTSWT';
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
  }

  retriveData(): void {
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;

    this.dataService
    .loadData(false)
    .pipe(
      first(),
      finalize(() => this.globals.hideLoadingBar())
    )
    .subscribe(
      {
        next: (atmData: any) => this.onGotRecords(atmData),
        error: (error: any) => this.onErrorGotRecords(error)
      }
    );
  }

  onGotRecords(wr: WorkRequest): void {
    const workRequest = wr;

    if(workRequest.lastModified == -1){
      this.globals.setErrorMessage('No Data found');
      return;
    }

    if (workRequest == null || workRequest == undefined
      || workRequest.collections == null || workRequest.collections[this.collectionId] == null
      || workRequest.collections[this.collectionId].rows == null
      || workRequest.collections[this.collectionId].rows == undefined
      || workRequest.collections[this.collectionId].rows.length == 0) {
        return;
      }

      const rows = workRequest.collections[this.collectionId].rows;

      let multiDtoList: ChartDTO[] = [];

      this.orderByMerchantCount(rows);
      rows.filter((v, i) => v.merchantCount != null).forEach((c,index) => {
        let chartDto = new ChartDTO(c.institutionId, c.merchantCount);
        multiDtoList.push(chartDto);
      });
      this.merchantData = JSON.parse(JSON.stringify(multiDtoList));
      this.getMerchantDataChart(rows);
      multiDtoList.length = 0;

      this.orderByTerminalCount(rows);
      rows.filter((v, i) => v.terminalCount != null).forEach((c,index) => {
        let chartDto = new ChartDTO(c.institutionId, c.terminalCount);
        multiDtoList.push(chartDto);
      });

      this.terminalData = JSON.parse(JSON.stringify(multiDtoList));
      this.getTerminalDataChart(rows);
      this.setTermFunctionalStatus(rows);

      this.cdr.markForCheck();
  }

  getMerchantDataChart(rows: any){
    this.merchantChartData = [];
    rows.filter((v, i) => v.merchantCount != null).forEach((c) => {
     this.merchantChartData.push({name:c.institutionId, y:c.merchantCount});
    });
     this.chartOptionsmerchant ={
      chart: {
        renderTo: 'container',
        type: 'cylinder',
        options3d: {
            enabled: true,
            alpha: 20,
            beta: 0,
            depth: 50,
            viewDistance: 50
        }
    },
    credits:{
      enabled: false,
    },
    xAxis: {
      type: 'category',
      title: {
        text: 'Institution'
    }
  },
  yAxis: {
    title: {
      text: 'Merchant Count'
  }
},
      title: {
          text: 'Institution Merchant Count'
      },
      tooltip: {
        pointFormat: '<b>{point.name}</b> - {point.y}'
    },
      accessibility: {
          screenReaderSection: {
              beforeChartFormat: '<{headingTagName}>' +
                  '{chartTitle}</{headingTagName}><div>{typeDescription}</div>' +
                  '<div>{chartSubtitle}</div><div>{chartLongdesc}</div>'
          }
      },
      legend: {
        enabled: false
    },
      plotOptions: {
        cylinder: {
            depth: 25,
            dataLabels: {
              enabled: true
          }
        }
    },
      series: [{
          data: this.merchantChartData,
          colorByPoint: true,
          events: {
            click:  (event)=> {
              this.onMerchantBarChartSelect(event);
            }
          }
      }] as any
  }
  }

  getTerminalDataChart(rows: any){
    this.terminalChartData = [];
    rows.filter((v, i) => v.terminalCount != null).forEach((c) => {
     this.terminalChartData.push({name:c.institutionId, y:c.terminalCount});
    });
     this.chartOptionsTerminal ={
      chart: {
        renderTo: 'container',
        type: 'bar',
        options3d: {
            enabled: true,
            alpha: 20,
            beta: 0,
            depth: 50,
            viewDistance: 50
        }
    },
    credits:{
      enabled: false,
    },
    xAxis: {
      type: 'category',
      title: {
        text: 'Institution'
    }
  },
  yAxis: {
    title: {
      text: 'Terminal Count'
  }
},
      title: {
          text: 'Institution Terminal Count'
      },
      tooltip: {
        pointFormat: '<b>{point.name}</b> - {point.y}'
    },
      accessibility: {
          screenReaderSection: {
              beforeChartFormat: '<{headingTagName}>' +
                  '{chartTitle}</{headingTagName}><div>{typeDescription}</div>' +
                  '<div>{chartSubtitle}</div><div>{chartLongdesc}</div>'
          }
      },
      legend: {
        enabled: false
    },
      plotOptions: {
        bar: {
          depth: 25,
          dataLabels: {
            enabled: true
          }
        }
    },
      series: [{
          data: this.terminalChartData,
          colorByPoint: true,
          events: {
            click:  (event)=> {
              this.onTerminalBarChartSelect(event);
            }
          }
      }] as any
  }
  }

  setTermFunctionalStatus(rows: any[]) {
    let chartDtoList: ChartDTO[] = [];
    this.termFunctionalChartData = [];

    const functionalTerminals = rows.filter((v, i) => v.functionalTerminalCount != null).map(a => a.functionalTerminalCount).reduce(function(a, b) { return a + b; });
    const nonfunctionalTerminals = rows.filter((v, i) => v.nonfunctionalTerminalCount != null).map(a => a.nonfunctionalTerminalCount).reduce(function(a, b) { return a + b; });

    const functional = new ChartDTO(`Functional - ${functionalTerminals}`, functionalTerminals);
    const nonfunctional = new ChartDTO(`Nonfunctional - ${nonfunctionalTerminals}`, nonfunctionalTerminals);

    this.termFunctionalChartData.push({name:`Functional - ${functionalTerminals}`,y:functionalTerminals});
    this.termFunctionalChartData.push({name:`Nonfunctional - ${nonfunctionalTerminals}`,y:nonfunctionalTerminals});
    chartDtoList.push(functional);
    chartDtoList.push(nonfunctional);

    this.termFunctionalStatusData = JSON.parse(JSON.stringify(chartDtoList));
    this.chartOptionsTermFunctional= {

      chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45
        }
    },
    credits:{
      enabled: false,
    },

    title: {
        text: 'Status By Make',
        margin:0,
    },
    tooltip: {
        pointFormat: '<b>{point.percentage:.0f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.0f} %',
                style: {
                    // color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            },
            size: '60%',
            depth: 45,
            showInLegend: true
        }
    },
    series: [{
        name:'Status By Make',
        colorByPoint: true,
        type:'pie',
        data:this.termFunctionalChartData,
        point: {
          events: {
              click:  (event)=> {
                this.onTermFunctionalStatusSliceSelect({
                  x:event.point.x,
                  value:event.point.y,
                  name: event.point.name,
                  label: event.point.series.name,
                  series:event.point.category,
                });
              }
            }
      },
    }as any],
    };
  }

  orderByMerchantCount(data: any) {
    data.sort((a, b) => {
      const valueA = a.merchantCount;
      const valueB = b.merchantCount;
      return valueB - valueA;
    });
  }

  orderByTerminalCount(data: any) {
    data.sort((a, b) => {
      const valueA = a.terminalCount;
      const valueB = b.terminalCount;
      return valueB - valueA;
    });
  }

  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  setT21Tags(): void {
    this.requestTypeId = 'POSDASH';
    this.metaDataId = 'POSDASH';
    this.tabId = 'POSDASH_TAB';
    this.sectionId = 'POSDASH_SEC';
    this.collectionId = 'POSDASH_COL';
  }

  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
    this.clearErrorMessage();
  }

  onMerchantBarChartSelect(event: any) {
    let newParam = {
      COMMAND: 'query',
      "status_code": event.point.name,
      NAVIGATION: true
    };
    const path = 'monitor/POSMERCHNT';
    this.loadNewForm(newParam, path);
  }

  onTerminalBarChartSelect(event: any) {
    let newParam = {
      COMMAND: 'query',
      "status_code": { InstitutionId: event.point.name, StatusCode: null },
      NAVIGATION: true
    };
    const path = 'monitor/POSTERDETA';
    this.loadNewForm(newParam, path);
  }

  onTermFunctionalStatusSliceSelect(event: any) {
    if (event == null) return;
    const statusCode = event.name.includes('Nonfunctional') ? 'Y' : 'N';
    let newParam = {
      COMMAND: 'query',
      "status_code": { InstitutionId: null, StatusCode: statusCode },
      NAVIGATION: true
    };
    const path = 'monitor/POSTERDETA';
    this.loadNewForm(newParam, path);
  }
}
