import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TranslateModule } from '@ngx-translate/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { RetentionConfigComponent } from './retention-config.component'


export const retentionConfig: MonitorComponentData = {
  title: 'Data Retention Config',
  icon: 'home',
  examples: {
    'DATARTCONF': {
      label: 'Data Retention Config',
      title: 'Data Retention Config',
      description: 'Data Retention Config',
      rufId: 'retention_config',
      component: RetentionConfigComponent
    }
  }
};

@NgModule({
    imports :[
    CommonModule,
    ISTComponentModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    TranslateModule,
    MatFormFieldModule,
    MatInputModule

    ],
  declarations: [ RetentionConfigComponent ],
  providers: [{ provide: MON_TOOL, useValue: retentionConfig }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[],
})
export class RetentionConfigModule {
}
