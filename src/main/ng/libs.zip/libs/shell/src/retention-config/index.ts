export * from './retention-config.module';
export * from './retention-config.component';
