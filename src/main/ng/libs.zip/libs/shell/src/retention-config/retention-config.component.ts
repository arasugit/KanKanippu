import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild, EventEmitter, Output } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent, RendererItem } from '../components';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { IstDatePickerColumnRendererComponent } from '../ist-components';
import { LabelAndValue, LabelsAndValues } from '../common/labels-and-values';


@Component({
  selector: 'retention-config-app',
  templateUrl: './retention-config.component.html'
 })
export class RetentionConfigComponent extends ListComponent implements OnInit, AfterViewInit {
  [x: string]: any;

  //@ViewChild('RetentionConfigTable', { static: false }) dataTableComponent: DataTableEditableComponent;
  private preValue: string; // The value before clicking to edit

  constructor(injector: Injector, private dataService  :DataTableService, private cdr: ChangeDetectorRef) {
    super(injector);
    this.preValue = '';
  }

  adjustCriteria(): void {
    this.criteria['COMMAND']='query';
    this.criteria['product_id']=this.globals.productId;
    this.criteria['node_name']= this.globals.nodeName;
    this.criteria['tableName']=this.tableName;
    this.criteria['selectedTableNameValue']=this.selectedTableNameValue;
  }

  FORM_TITLE = 'Data Retention Config';
  exportFileName= 'Data Retention Config';

   cntrlType = 'CBOX';
   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';
   tableName : string = '';
   tableNamesList : LabelsAndValues = new LabelsAndValues();
   selectedTableNameValue : string = '';
   colNamesList : LabelsAndValues = new LabelsAndValues();
   workRequest:WorkRequest;

   queryPerm = new FormActionPermission('DATARTCONF', 'Q');
   insertPerm = new FormActionPermission('DATARTCONF', 'I');
   updatePerm = new FormActionPermission('DATARTCONF', 'U');
   deletePerm = new FormActionPermission('DATARTCONF', 'D');
   checkerPerm = new FormActionPermission('DATARTCONF', 'C');
   mkcPerm = new MKCPermission('DATARTCONF');

   startDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
   endDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
   deptList: LabelsAndValues = new LabelsAndValues();

   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.insertPerm);
    this.requestPerms.permsArr.push(this.updatePerm);
    this.requestPerms.permsArr.push(this.deletePerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.setAutoRefreshSearch(true);

    this.instService.getDatabaseRecords("TABLE_NAMES_LIST",null).subscribe((x: any[]) => { this.loadTableNamesList(x); });

    this.globals.tableNameRetCnfSubject$.subscribe({
      next: (response: any) => {
        if (response) {
          this.selectedTableNameValue = response.selectedValue;
        }
      },
      error: (error: Error) => {
      }
    });
  }

  loadTableNamesList(result: string[]): void {
    this.tableNamesList.array = result.map((y: string): LabelAndValue => {
      return new LabelAndValue(y, y);
    });
  }

  // onClickFetchCols() {
  //   console.log("Calling onClickFetchCols() :: ", this.selectedTableNameValue);
  //   this.dbParam = {};
  //   this.dbParam['selectedTableNameValue'] = this.selectedTableNameValue;

  //   this.instService.getDatabaseRecords("COLUMN_NAMES_LIST",this.dbParam).subscribe((x: any[]) => { this.loadColumnNamesList(x); });
  // }

  loadColumnNamesList(result: string[]): void {
    // this.colNamesList.array = [new LabelAndValue('', '')];
    this.colNamesList.array = result.map((y: string): LabelAndValue => {
      return new LabelAndValue(y, y);
    });
  }

  validateBeforeQuery(): boolean {
    return true;
  }

  ngAfterViewInit(): void {
    this.doSearch();
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'DATARTCONF';
    this.metaDataId = 'DATARTCONF';
    this.tabId = 'DATARTCONFTAB';
    this.sectionId = 'DATARTCONFSEC';
    this.collectionId = 'DATARTCONFCOL';
  }


  onRowClick(event:any) {
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
  }
}



