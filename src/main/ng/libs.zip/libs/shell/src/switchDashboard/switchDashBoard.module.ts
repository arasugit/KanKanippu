import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCardModule } from "@angular/material/card";
import { MON_TOOL, MonitorComponentData } from "../monitor-components";
import { SwitchDashBoardComponent } from "./switchDashboard.component";
import { CommonModule } from "@angular/common";
import { RufCommonModule } from "@ruf/shell";
import { FlexLayoutModule } from "@angular/flex-layout";
import { RufCardModule } from "@ruf/shell";
import { HighchartsChartModule } from "highcharts-angular";

export const switchDashBoardData: MonitorComponentData = {
  title: "Switch DashBoard",
  icon: "home",
  examples: {
    ATMNTWRKDS: {
      label: "Overall Switch network status",
      title: "Overall Switch Application Network Status",
      description: "Overall Switch Application Network Status",
      rufId: "mon_switch_dashboard",
      component: SwitchDashBoardComponent,
    },
  },
};

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    FormsModule,
    FlexLayoutModule,
    RufCardModule,
    ReactiveFormsModule,
    MatCardModule,
    RufCommonModule,
    HighchartsChartModule,
  ],
  declarations: [SwitchDashBoardComponent],
  providers: [{ provide: MON_TOOL, useValue: switchDashBoardData }],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [],
})
export class SwitchDashBoardModule {}
