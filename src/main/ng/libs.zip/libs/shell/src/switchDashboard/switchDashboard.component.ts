import {Component, ViewEncapsulation, OnInit, OnDestroy, Optional, Inject, Injector, ChangeDetectorRef} from '@angular/core';
import { Subject, takeUntil } from "rxjs";
import { ListComponent } from "../components";
import { FormActionPermission, MKCPermission } from "../permission";
import { DataTableService } from "../services";
import { WorkRequest } from "../ist-components";
import * as Highcharts from "highcharts";
import Highcharts3d from "highcharts/highcharts-3d";
import exporting from 'highcharts/modules/exporting';
import offlineExporting from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offlineExporting(Highcharts);
Highcharts3d(Highcharts);
import noData from 'highcharts/modules/no-data-to-display';
noData(Highcharts);
@Component({
  selector: "switch-dashboard",
  templateUrl: "./switchDashBoard.component.html",
  styleUrls: ["./switchDashBoard.component.scss"],
  encapsulation: ViewEncapsulation.None,
})
export class SwitchDashBoardComponent
  extends ListComponent
  implements OnInit, OnDestroy
{
  private unsubscribe = new Subject();

  workRequest: WorkRequest;
  private taskCmdStatusData: any[] = [];
  private binStatusData: any[] = [];
  private dbStatusData: any[] = [];
  private binStatusByInstData: any[] = [];
  private portStatusData: any[] = [];
  private resourceUsageData: any[] = [];
  private resourceAllocationData: any[] = [];
  private traceLevelData: any[] = [];

  public Highcharts: typeof Highcharts = Highcharts;
  public taskCmdStatusChartOptions: Highcharts.Options;
  public binStatusChartOptions: Highcharts.Options;
  public dbStatusChartOptions: Highcharts.Options;
  public dbBinStatusByInstChartOptions: Highcharts.Options;
  public portStatusChartOptions: Highcharts.Options;
  public resourceUsageChartOptions: Highcharts.Options;
  public resourceAllocationChartOptions: Highcharts.Options;
  public traceLevelChartOptions: Highcharts.Options;

  dataLoaded: boolean = false;
  atmFaultStats: FormActionPermission;
  FORM_TITLE = "ATM Dashboard";

  constructor(
    private injector: Injector,
    private dataService: DataTableService,
    private cdr: ChangeDetectorRef,
    @Optional() @Inject("THEME_PICKER_SERVICE") private themePicker
  ) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria["requestTypeId"] = this.requestTypeId;
    this.criteria["collectionId"] = this.collectionId;
    this.criteria["COMMAND"] = "query";
  }

  retriveData(): void {
    this.dataService.requestType = this.requestTypeId;
    this.dataService.collectionTag = this.collectionId;
    this.dataService.action = "query";
    this.dataService.criteria = this.criteria;
    this.globals.showLoadingBar();
    this.dataService
      .loadData(false)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(
        (atmData) => this.onGotRecords(atmData),
        (error) => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }

  get darkMode(): boolean {
    return this.themePicker.darkTheme;
  }

  ngOnInit() {
    super.ngOnInit();
    //this.setAutoRefreshRetriveDataInterval();
    this.setAutoRefreshSearch(true);
  }

  ngAfterViewInit(): void {
    this.setAutoRefreshInterval();
    this.retriveData();
  }

  setTaskCmdStatusChartOptions(): void {
    this.taskCmdStatusChartOptions = {
      credits: this.getChartCreditOptions(),
      chart: {
        ...this.getPieChartSize(350),
      },
      ...this.getChartTitle("Task Command Status"),
      subtitle: this.getPieChartSubtitle(
        `Total - ${this.getYValueSum(this.taskCmdStatusData)}`
      ),
      tooltip: this.getCustomPieChartTooltip(),
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: "pointer",
          size: "75%",
          showInLegend: true,
          events: {
            click: (event) => {
              this.onTaskCmdStatusChartClick(event);
            },
          },
        },
      },
      series: [
        {
          ...this.getPieChartDefaultSeriesOption("Task Count"),
          innerSize: "60%",
          dataLabels: [
            { enabled: true, distance: 20, format: "<b>{point.name}</b>" },
            { enabled: true, distance: -15, format: "<b>{point.y}</b>" },
          ],
          data: this.taskCmdStatusData,
        } as any,
      ],
    };
  }

  setBinStatusChartOptions(): void {
    this.binStatusChartOptions = {
      credits: this.getChartCreditOptions(),
      chart: {
        ...this.getPieChartSize(300),
        ...this.getPieChart3dOptions(),
      },
      legend: {
        ...this.getPieChartDefultLegendOptions(),
      },
      ...this.getChartTitle("Bin Availability"),
      subtitle: this.getPieChartSubtitle(
        `Total Bins - ${this.getYValueSum(this.binStatusData)}`,
        "top"
      ),
      tooltip: this.getCustomPieChartTooltip(),
      plotOptions: {
        pie: {
          ...this.getUpDownColorOption(),
          allowPointSelect: true,
          depth: 50,
          cursor: "pointer",
          size: "60%",
          showInLegend: true,
          events: {
            click: (event) => {
              this.onBinStatusChartClick(event);
            },
          },
        },
      },
      series: [
        {
          ...this.getPieChartDefaultSeriesOption("Bin Count"),
          dataLabels: [
            {
              enabled: true,
              distance: 20,
              format: "<b>{point.name}</b><br>({point.y})",
            },
          ],
          data: this.binStatusData,
        } as any,
      ],
    };
  }

  setDbStatusChartOptions(): void {
    this.dbStatusChartOptions = {
      credits: this.getChartCreditOptions(),
      chart: {
        ...this.getPieChartSize(300),
        ...this.getPieChart3dOptions(),
      },
      legend: {
        ...this.getPieChartDefultLegendOptions(),
      },
      ...this.getChartTitle("Database Availability"),
      subtitle: this.getPieChartSubtitle(
        `Total DBs - ${this.getYValueSum(this.dbStatusData)}`,
        "top"
      ),
      tooltip: this.getCustomPieChartTooltip(),
      plotOptions: {
        pie: {
          ...this.getUpDownColorOption(),
          allowPointSelect: true,
          depth: 50,
          cursor: "pointer",
          size: "60%",
          showInLegend: true,
          events: {
            click: (event) => {
              this.onDbStatusChartClick(event);
            },
          },
        },
      },
      series: [
        {
          ...this.getPieChartDefaultSeriesOption("DB Count"),
          dataLabels: [
            {
              enabled: true,
              distance: 20,
              format: "<b>{point.name}</b><br>({point.y})",
            },
          ],
          data: this.dbStatusData,
        } as any,
      ],
    };
  }

  setBinStatusByInstChartOptions(): void {
    this.dbBinStatusByInstChartOptions = {
      credits: this.getChartCreditOptions(),
      chart: {
        type: "column",
        height: 300,
      },
      ...this.getBinStatusColumnChartLegendOptions(),
      ...this.getChartTitle("Bin Availability by Institution"),
      subtitle: this.getPieChartSubtitle(
        `Total Bins - ${this.getYValueSum(this.binStatusData)}`,
        "top"
      ),
      tooltip: {
        headerFormat: "<b>{point.x}</b><br/>",
        pointFormat: "{series.name}: {point.y}<br/>Total: {point.stackTotal}",
      },
      plotOptions: {
        column: {
          stacking: "normal",
          cursor: "pointer",
          dataLabels: {
            enabled: true,
          },
          events: {
            click: (event) => {
              this.onBinStatusByInstChartClick(event);
            },
          },
        },
      },
      xAxis: {
        categories: [
          ...new Set(this.binStatusByInstData.map((item) => item.name)),
        ],
      },
      yAxis: {
        min: 0,
        title: {
          text: "Bin Count",
        },
        stackLabels: {
          enabled: true,
        },
      },
      series: [
        {
          name: "Up",
          color: "rgb(75, 205, 62)",
          data: [
            ...this.binStatusByInstData.map(function (a) {
              return a.up;
            }),
          ],
        },
        {
          name: "Down",
          color: "red",
          data: [
            ...this.binStatusByInstData.map(function (a) {
              return a.down;
            }),
          ],
        },
      ],
    };
  }

  setPortStatusChartOptions(): void {
    this.portStatusChartOptions = {
      credits: this.getChartCreditOptions(),
      chart: {
        type: "bar",
        height: 300,
      },
      ...this.getChartTitle("Port Status"),
      tooltip: {
        ...this.getBarChartTooltipOptions(),
        formatter: function () {
          return getBarChartCustomFormatter(this);
        },
      },
      plotOptions: {
        bar: {
          borderRadius: "50%",
          cursor: "pointer",
          colorByPoint: true,
          dataLabels: {
            enabled: true,
          },
        },
        series: {
          events: {
            click: (event) => {
              this.onPortStatusChartClick(event);
            },
          },
        },
      },
      legend: {
        enabled: false,
      },
      xAxis: {
        categories: [...new Set(this.portStatusData.map((item) => item.name))],
        title: {
          text: null,
        },
        lineWidth: 0,
      },
      yAxis: {
        min: 0,
        title: {
          text: null,
        },
        labels: {
          overflow: "justify",
          enabled: true,
        },
        gridLineWidth: 1,
      },
      series: [
        {
          type: "bar",
          name: "Port Count",
          data: this.portStatusData,
        },
      ],
    };
  }

  setResourceUsageChartOptions(): void {
    this.resourceUsageChartOptions = {
      credits: this.getChartCreditOptions(),
      chart: {
        type: "bar",
        height: 300,
      },
      ...this.getChartTitle("Resource Usage"),
      tooltip: {
        ...this.getBarChartTooltipOptions(),
        formatter: function () {
          return getBarChartCustomFormatter(this);
        },
      },
      plotOptions: {
        bar: {
          minPointLength: 5,
          borderRadius: "50%",
          cursor: "pointer",
          dataLabels: {
            enabled: true,
          },
        },
        series: {
          events: {
            click: (event) => {
              this.onResourceUsageChartClick(event);
            },
          },
        },
      },
      legend: {
        enabled: false,
      },
      xAxis: {
        categories: [
          ...new Set(this.resourceUsageData.map((item) => item.name)),
        ],
        title: {
          text: null,
        },
        lineWidth: 0,
      },
      yAxis: {
        min: 0,
        title: {
          text: null,
        },
        labels: {
          overflow: "justify",
          enabled: true,
        },
        gridLineWidth: 1,
      },
      series: [
        {
          type: "bar",
          name: "Count",
          data: this.resourceUsageData,
        },
      ],
    };
  }

  setResourceAllocationChartOptions(): void {
    this.resourceAllocationChartOptions = {
      credits: this.getChartCreditOptions(),
      chart: {
        type: "bar",
        height: 300,
      },
      ...this.getChartTitle("Resource Allocation Configuration"),
      tooltip: {
        ...this.getBarChartTooltipOptions(),
        formatter: function () {
          return getBarChartCustomFormatter(this);
        },
      },
      plotOptions: {
        bar: {
          colorByPoint: true,
          minPointLength: 5,
          borderRadius: "50%",
          cursor: "pointer",
          dataLabels: {
            enabled: true,
          },
        },
        series: {
          events: {
            click: (event) => {
              this.onResourceAllocationChartClick(event);
            },
          },
        },
      },
      legend: {
        enabled: false,
      },
      xAxis: {
        categories: [
          ...new Set(this.resourceAllocationData.map((item) => item.name)),
        ],
        title: {
          text: null,
        },
        lineWidth: 0,
      },
      yAxis: {
        min: 0,
        title: {
          text: null,
        },
        labels: {
          overflow: "justify",
          enabled: true,
        },
        gridLineWidth: 1,
      },
      series: [
        {
          type: "bar",
          name: "Count",
          data: this.resourceAllocationData,
        },
      ],
    };
  }

  setTraceLevelChartOptions(): void {
    this.traceLevelChartOptions = {
      credits: this.getChartCreditOptions(),
      chart: {
        ...this.getPieChartSize(400),
        ...this.getPieChart3dOptions(),
      },
      legend: {
        ...this.getPieChartDefultLegendOptions(),
      },
      ...this.getChartTitle("Trace Level Configuration"),
      tooltip: this.getCustomPieChartTooltip(),
      plotOptions: {
        pie: {
          allowPointSelect: true,
          depth: 50,
          cursor: "pointer",
          size: "70%",
          showInLegend: true,
          events: {
            click: (event) => {
              this.onTraceLevelChartClick(event);
            },
          },
        },
      },
      series: [
        {
          ...this.getPieChartDefaultSeriesOption("Count"),
          dataLabels: [
            {
              enabled: true,
              distance: 20,
              format: "<b>{point.name}</b><br>({point.y})",
            },
          ],
          data: this.traceLevelData,
        } as any,
      ],
    };
  }

  onTaskCmdStatusChartClick(event: Highcharts.SeriesClickEventObject) {
    const path = "monitor/TSKCMD";
    const paramVal = "ValueForTaskCommand";
    this.router.navigateByUrl(path, {
      state: { paramKey: paramVal, paramKeyValue: event.point.name },
    });
  }

  onBinStatusChartClick(event: Highcharts.SeriesClickEventObject) {
    const path = "monitor/BINDTLS";
    const paramVal = "ValueForSwitchBoardTBinStatus";
    this.router.navigateByUrl(path, {
      state: { paramKey: paramVal, paramKeyValue: event.point.name },
    });
  }

  onDbStatusChartClick(event: Highcharts.SeriesClickEventObject) {
    const path = "monitor/DBCONNDTLS";
    const paramVal = "ValueForSwitchBoardDBState";
    this.router.navigateByUrl(path, {
      state: { paramKey: paramVal, paramKeyValue: event.point.name },
    });
  }

  onBinStatusByInstChartClick(event: Highcharts.SeriesClickEventObject) {
    const path = "monitor/BINDTLS";
    const paramVal = "ValueForSwitchBoardTBinStatusByInstId";
    this.router.navigateByUrl(path, {
      state: { paramKey: paramVal, paramKeyValue: {instId: event.point.category, status: event.point.series.name} },
    });
  }

  onPortStatusChartClick(event: Highcharts.SeriesClickEventObject) {
    const path = "monitor/PRTDTLS";
    const paramVal = "PortStatus";
    this.router.navigateByUrl(path, {
      state: { paramKey: paramVal, paramKeyValue: event.point.name },
    });
  }

  onResourceUsageChartClick(event: Highcharts.SeriesClickEventObject) {
    const path = "monitor/RSRCUSG";
    const paramVal = "ValueForUsedResourceCount";
    this.router.navigateByUrl(path, {
      state: { paramKey: paramVal, paramKeyValue: event.point.name },
    });
  }

  onResourceAllocationChartClick(event: Highcharts.SeriesClickEventObject) {
    const path = "monitor/MBCDOPTS";
    const paramVal = "ValueForAllocatedBasicConfigurations";
    this.router.navigateByUrl(path, {
      state: { paramKey: paramVal, paramKeyValue: event.point.name },
    });
  }

  onTraceLevelChartClick(event: Highcharts.SeriesClickEventObject) {
    const path = "monitor/TRCDTLS";
    const paramVal = "ValueForSwitchBoardTraceLevel";
    this.router.navigateByUrl(path, {
      state: { paramKey: paramVal, paramKeyValue: event.point.name },
    });
  }

  onTraceErrorChartClick(event: Highcharts.SeriesClickEventObject) {
    const path = "monitor/DEBUGM_REQ";
    const paramVal = "ValueForDebugOnFileName";
    this.router.navigateByUrl(path, {
      state: { paramKey: paramVal, paramKeyValue: event.point.name },
    });
  }

  setTaskCmdStatusData(c: any): void {
    this.taskCmdStatusData.length = 0;
    this.taskCmdStatusData = [];
    this.taskCmdStatusData.push({
      name: "Temporary",
      y: c.countTemp == "" ? null : c.countTemp,
    });
    this.taskCmdStatusData.push({
      name: "Permanent",
      y: c.countPerm == "" ? null : c.countPerm,
    });
  }

  setBinStatusData(c: any): void {
    this.binStatusData.length = 0;
    this.binStatusData = [];
    this.binStatusData.push({
      name: "Up",
      y: c.binStatusUpCount == "" ? null : c.binStatusUpCount,
    });
    this.binStatusData.push({
      name: "Down",
      y: c.binStatusDownCount == "" ? null : c.binStatusDownCount,
    });
  }

  setDbStatusData(c: any): void {
    this.dbStatusData.length = 0;
    this.dbStatusData = [];
    this.dbStatusData.push({
      name: "Up",
      y: c.dbUpCount == "" ? null : c.dbUpCount,
    });
    this.dbStatusData.push({
      name: "Down",
      y: c.dbDownCount == "" ? null : c.dbDownCount,
    });
  }

  setBinStatusByInstIdData(c: any): void {
    this.binStatusByInstData.length = 0;
    this.binStatusByInstData = [];
    if (c.binStateInstId == null) return;

    for (let i = 0; i < c.binStateInstId.length; i++) {
      const institution = c.binStateInstId[i];
      const status = c.binStateStatus[i];
      const count = c.binStateBinId[i];

      if (
        this.binStatusByInstData.filter((item) => item.name == institution)
          .length == 0
      ) {
        this.binStatusByInstData.push({
          name: institution,
          up: null,
          down: null,
        });
      }

      if (status === "Up") {
        this.binStatusByInstData.find((item) => item.name == institution).up =
          count;
      } else if (status === "Down") {
        this.binStatusByInstData.find((item) => item.name == institution).down =
          count;
      }
    }
  }

  setPortStatusData(c: any): void {
    this.portStatusData.length = 0;
    this.portStatusData = [];
    if (c.portField3Array == null) return;

    for (let i = 0; i < c.portField3Array.length; i++) {
      const status = c.portField3Array[i];
      const count = c.portField3ArrayCount[i];
      if (status == null) continue;
      this.portStatusData.push({
        name: status,
        y: count,
        color: this.getChartColor(i, status),
      });
    }
  }

  setResourceUsageData(c: any): void {
    this.resourceUsageData.length = 0;
    this.resourceUsageData = [];
    if (c.resourcesArray == null) return;

    for (let i = 0; i < c.resourcesArray.length; i++) {
      const resource = c.resourcesArray[i];
      const count = c.resourcesArrayCount[i];
      if (resource == null) continue;
      this.resourceUsageData.push({
        name: resource,
        y: count,
        color: this.getChartColor(i),
      });
    }
  }

  setResourceAllocationData(c: any): void {
    this.resourceAllocationData.length = 0;
    this.resourceAllocationData = [];
    if (c.alloactedBasicConfigsArray == null) return;

    for (let i = 0; i < c.alloactedBasicConfigsArray.length; i++) {
      const resource = c.alloactedBasicConfigsArray[i];
      var count = c.alloactedBasicConfigsArrayCount[i];
      if (resource.includes("Size")) {
        count = count / (1024 * 1024);
      }
      if (resource == null) continue;
      this.resourceAllocationData.push({ name: resource.trim(), y: count });
    }
  }

  setTraceLevelData(c: any): void {
    this.traceLevelData.length = 0;
    this.traceLevelData = [];
    if (c.traceLevelArray == null) return;

    for (let i = 0; i < c.traceLevelArray.length; i++) {
      let level = c.traceLevelArray[i];
      const count = c.traceLevelArrayCount[i];
      if (level == null) continue;
      level = this.toTitelCase(level);
      this.traceLevelData.push({
        name: level,
        y: count,
        color: this.getChartColor(i, level),
      });
    }
  }

  getChartColor(i: number, status: string = ""): string {
    const chartColors = [
      "#1aadce",
      "green",
      "#8bbc21",
      "orange",
      "teal",
      "#2CAFFE",
      "orchid",
      "#873260",
      "#2f7ed8",
      "#1aadce",
      "green",
      "#8bbc21",
    ];
    if (status == "Stopped" || status == "Error") return "red";
    if (status.includes("Passive")) return "orange";
    if (status == "Connected") return "rgb(75, 205, 62)";
    if (chartColors.length <= i) return chartColors[chartColors.length - 1];

    return chartColors[i];
  }

  toTitelCase(str: string): string {
    if (!str) return str;

    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }

  getYValueSum(data: any): number {
    return data
      .map((a) => a.y)
      .reduce(function (a, b) {
        return a + b;
      });
  }

  getCustomPieChartTooltip(): Highcharts.TooltipOptions {
    return {
      useHTML: true,
      style: {
        fontSize: '14px'
      },
      headerFormat: "<b>{point.key}</b><br/>",
    };
  }

  getBarChartTooltipOptions(): Highcharts.TooltipOptions {
    return {
      useHTML: true,
      style: {
        fontSize: '14px'
      }
    };
  }

  getPieChartSubtitle(
    text: string,
    verticalAlign: Highcharts.VerticalAlignValue = "middle"
  ): Highcharts.SubtitleOptions {
    return {
      useHTML: true,
      text: text,
      floating: true,
      verticalAlign: verticalAlign,
      style: { color: "#000000", fontSize: 15 },
    };
  }

  getPieChartSize(width: number = 350): any {
    return { height: "280px", width: width };
  }

  getPieChart3dOptions(): Highcharts.ChartOptions {
    return {
      options3d: {
        enabled: true,
        alpha: 45,
        beta: 0,
      },
    };
  }

  getChartTitle(text: string): Highcharts.Options {
    return {
      title: {
        text: text,
        margin: 0,
      },
    };
  }

  getChartCreditOptions(): Highcharts.CreditsOptions {
    return { enabled: false };
  }

  getPieChartDefaultSeriesOption(seriesName: string): any {
    return {
      name: "Task Count",
      colorByPoint: true,
      type: "pie",
    };
  }

  getPieChartDefultLegendOptions(): Highcharts.LegendOptions {
    return {
      align: "center",
      verticalAlign: "bottom",
      layout: "horizontal",
      labelFormatter: function () {
        return this.name + " - " + ((this as Highcharts.Point).y ?? 0);
      },
    };
  }

  getUpDownColorOption(): any {
    return { colors: ["rgb(75, 205, 62)", "red"] };
  }

  getBinStatusColumnChartLegendOptions(): any {
    return {
      legend: {
        align: "left",
        x: 70,
        verticalAlign: "top",
        y: 70,
        floating: true,
        backgroundColor:
          Highcharts.defaultOptions.legend.backgroundColor || "white",
        borderColor: "#CCC",
        borderWidth: 1,
        shadow: false,
      },
    };
  }

  onGotRecords(wr: WorkRequest): void {
    this.globals.hideLoaderBar();
    this.workRequest = wr;
    if (
      this.workRequest == null ||
      this.workRequest === undefined ||
      this.workRequest.collections == null ||
      this.workRequest.collections[this.collectionId] == null ||
      this.workRequest.collections[this.collectionId].rows == null ||
      this.workRequest.collections[this.collectionId].rows === undefined
    ) {
      return;
    }

    const rows = this.workRequest.collections[this.collectionId].rows;

    rows.forEach((c) => {
      this.setTaskCmdStatusData(c);
      this.setBinStatusData(c);
      this.setDbStatusData(c);
      this.setBinStatusByInstIdData(c);
      this.setPortStatusData(c);
      this.setResourceUsageData(c);
      this.setResourceAllocationData(c);
      this.setTraceLevelData(c);

      this.setTaskCmdStatusChartOptions();
      this.setBinStatusChartOptions();
      this.setDbStatusChartOptions();
      this.setBinStatusByInstChartOptions();
      this.setPortStatusChartOptions();
      this.setResourceUsageChartOptions();
      this.setResourceAllocationChartOptions();
      this.setTraceLevelChartOptions();
      this.dataLoaded = true;
      this.cdr.markForCheck();
    });
  }

  onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
  }

  onCompleteGotRecords(): void {}

  getEntPermList(): any[] {
    this.entObjectId = "OVERALL_NETW_STATUS";
    this.queryPerm = new FormActionPermission(this.entObjectId, "Q");
    this.insertPerm = new FormActionPermission(this.entObjectId, "I");
    this.updatePerm = new FormActionPermission(this.entObjectId, "U");
    this.deletePerm = new FormActionPermission(this.entObjectId, "D");
    this.checkerPerm = new FormActionPermission(this.entObjectId, "C");
    this.mkcPerm = new MKCPermission(this.entObjectId);
    this.atmFaultStats = new FormActionPermission("ATMFLTVIEW", "Q");
    return new Array(
      this.queryPerm,
      this.insertPerm,
      this.updatePerm,
      this.deletePerm,
      this.mkcPerm,
      this.checkerPerm,
      this.atmFaultStats
    );
  }

  setT21Tags(): void {
    this.requestTypeId = "ATMNTWRKDS";
    this.metaDataId = "ATMNTWRKDS";
    this.tabId = "ATMNTWRKDSTAB";
    this.sectionId = "ATMNTWRKDSSEC";
    this.collectionId = "ATMNTWRKDSCOL";
  }

  ngOnDestroy() {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshRetriveDataInterval();
  }

  search(): void {
    this.adjustCriteria();
    this.retriveData();
  }
}

function getBarChartCustomFormatter(context) {
  var label = "Count";
  if (context.x.toString().includes("Size")) {
    label = "Size (in KB)";
  }
  const header = `<span style="color: ${context.color};"><b>${context.x}</b></span><br/>`;
  return (
    header +
    `<span style="color: ${context.color};">●</span> ${label}: <b>${context.y}</b>`
  );
}

