import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { TranslateModule } from '@ngx-translate/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { DbSumComponent } from './dbSum.component';


export const dbSumView: MonitorComponentData = {
  title: 'Data Points dbSum',
  icon: 'home',
  examples: {
    'DPDBSUM': {
      label: 'Debit/Credit Summary',
      title: 'Data Points DbSum',
      description:  'DbSum',
      rufId: 'dbsum_view',
      component: DbSumComponent
    }
  }
};

@NgModule({
    imports :[
    CommonModule,
    ISTComponentModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    TranslateModule,
    MatFormFieldModule,
    MatInputModule

    ],
  declarations: [ DbSumComponent ],
  providers: [{ provide: MON_TOOL, useValue: dbSumView }],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports:[],
})
export class DbSumModule {}
