import { AfterViewInit, ChangeDetectorRef, Component, Injector, OnInit, ViewChild } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableEditableComponent } from '../components';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';
import { LabelAndValue, LabelsAndValues } from '../common/labels-and-values';
import { filter, finalize, first, map } from 'rxjs';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'dbSum-app',
  templateUrl: './dbSum.component.html'
})
export class DbSumComponent extends ListComponent implements OnInit, AfterViewInit {
  [x: string]: any;
  dcSummary = 'DebitSummary'
  timeRangeData: LabelsAndValues = new LabelsAndValues();


  @ViewChild('dbSumTable', { static: false })
  dataTableComponent: DataTableEditableComponent;

  constructor(injector: Injector, public dataService: DataTableService, private cdr: ChangeDetectorRef) {
    super(injector);
  }

  adjustCriteria(): void {
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
    this.criteria['statusCode'] = this.statusCode;
  }

  FORM_TITLE = 'Data Points Debit/Credit Summary';

  fromTime: string = '';
  fromDate: string = '';
  dateTo: string = '';
  toTime: string = '';



  workRequest: WorkRequest;

  queryPerm = new FormActionPermission('DPDBSUM', 'Q');
  mkcPerm = new MKCPermission('DPDBSUM');


  ngOnInit() {

    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.timeRangeData.array = [new LabelAndValue('Debit Summary', 'Debit Summary'), new LabelAndValue('Credit Summary', 'Credit Summary')];

  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.dcSummary = 'Debit Summary';
      this.doSearch();
    }, 10);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'DPDBSUM';
    this.metaDataId = 'DPDBSUM';
    this.tabId = 'DPDBSUMTAB';
    this.sectionId = 'DPDBSUMSEC';
    this.collectionId = 'DPDBSUMCOL';
  }


  onRowClick(event: any) {
  }



  changeHandler(event: any) {
    this.globals.setErrorMessage('');
    if (null == event) return;
    if (event == 'Debit Summary') {
      this.changeEvent = 'Debit Summary';
      this.requestTypeId = "DPDBSUM";
      this.collectionId = "DPDBSUMCOL";

    } else if (event == 'Credit Summary') {
      this.changeEvent = 'Credit Summary';
      this.requestTypeId = "DPCDSUM";
      this.collectionId = "DPCDSUMCOL";
      this.count = this.count + 1;
    }
    this.adjustCriteria();
    this.retriveData();
  }

  retriveData(): void {
    this.dataService.requestType = this.requestTypeId;
    this.dataService.collectionTag = this.collectionId;
    this.dataService.action = 'query';
    this.dataService.criteria = this.criteria;
    this.doSearch();
  }
}

function Route(url: any, arg1: string, path: string, arg3: string): ActivatedRoute {
  throw new Error('Function not implemented.');
}

