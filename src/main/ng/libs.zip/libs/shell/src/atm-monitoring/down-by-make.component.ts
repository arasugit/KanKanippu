import { Component, Injector, OnInit,ChangeDetectorRef, ViewEncapsulation, OnDestroy } from '@angular/core';
import { Subject,takeUntil } from 'rxjs';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableService, GlobalsService } from '../services';
import { WorkRequest } from '../ist-components';
import { Location } from '@angular/common';

@Component({
    selector: 'down-by-make-app',
    templateUrl : './down-by-make.component.html',
    styleUrls: ['./transaction.scss'],
    encapsulation: ViewEncapsulation.None
})

export class DownByMakeComponent extends ListComponent implements OnInit, OnDestroy{
	private unsubscribe = new Subject();
  view: any[] =[300, 250];
  animations = true;
  screenType: any;
  dataLoaded:boolean=false;
  workRequest:WorkRequest;
  autoRefreshRetriveDataTimer: any;

	constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef,private location: Location){
    super(injector); 
  }

	ngAfterViewInit() {
    super.criteria=this.criteria;
    super.search();
    this.setAutoRefreshInterval();
    //this.setAutoRefreshRetriveDataInterval();
  }

	adjustCriteria(): void {
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }

	retriveData2():void{
    super.search();
  }

	retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        atmData => this.onGotRecords(atmData),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }

	FORM_TITLE = 'ATM Down by Make';
  exportFileName = 'ATM Down by Make';

	ngOnInit() {
    this.showBackBtn=GlobalsService.isRedirected;
    GlobalsService.isRedirected=false;
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    console.log('screenType::'+this.screenType);
	}

	onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    if(this.workRequest!=null && this.workRequest !==undefined && this.workRequest.collections!=null && this.workRequest.collections[this.collectionId] !=null && this.workRequest.collections[this.collectionId].rows!=null){
      const rows = this.workRequest.collections[this.collectionId].rows;
      console.log("Row Size Make::"+rows.length);
      console.log("Rows Data Make:: "+ rows);
      let statusData:any = [];
      rows.forEach(c =>{
        statusData.push({name: c.terminalId,value: c.terminalId})
        statusData.push({name: c.statusDown,value: c.atmOutOfService})
      })
      this.dataLoaded=true;
      this.cdr.markForCheck();
    }
  }
	onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
	}
	onCompleteGotRecords(): void {
  }
	getEntPermList(): any[] {
    this.entObjectId = 'ATMDWM_REQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

	onSelect(event){
		console.log(event);
	}

	gatherDataChanged(event:any):void{
    console.log(this.dataService.data);
 	}

 setT21Tags(): void {
	this.requestTypeId = 'ATMDWM_REQ';
	this.metaDataId = 'ATMDWM_REQ';
	this.tabId = 'ATM_DWM_TAB';
	this.sectionId = 'ATM_DWM_SEC';
	this.collectionId = 'ATM_DWM_COL';
	}

	ngOnDestroy(): void {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
  }
  goBack() {
    this.globals.setErrorMessage('');
    this.clearErrorMessage();
    this.location.back();


  }

}
