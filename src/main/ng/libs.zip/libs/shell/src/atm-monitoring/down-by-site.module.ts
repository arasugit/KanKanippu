import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DownBySiteComponent } from './down-by-site.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule } from '@ruf/shell';

export const downBySite: MonitorComponentData = {
  title: 'ATM Down By Site List',
  icon: 'table',
  examples: {  
      'ATMDWS_REQ': {
          label: 'ATM Down By Site List',
          title: 'ATM Down By Site List',
          description: 'ATM Down By Site List',
          rufId: 'atm_down_by_site',
          component: DownBySiteComponent
      }
  }
};

@NgModule({ 
    imports :[ 
    CommonModule,
    FormsModule,
    ReactiveFormsModule,  
    MatTableModule, 
    MatCardModule,  
    RufCommonModule,   
    RufCardModule, 
    ISTComponentModule
  ], 
  declarations: [DownBySiteComponent],
  providers: [{ provide: MON_TOOL, useValue: downBySite }],
  exports:[],
})
export class DownBySiteModule {}
