export  class TransactionDTO {
    name: string;
    value: string;
    constructor(name: string, value: string){
        this.name=name;
        this.value=value;
    }
}

export  class TransactionList {
    private arr;
    private list;
    array: TransactionDTO[];
    records: TransactionDTO[];
}
