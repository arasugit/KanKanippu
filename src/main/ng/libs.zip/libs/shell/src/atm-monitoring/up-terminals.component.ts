import { Component, Injector, OnInit,ChangeDetectorRef, ViewEncapsulation, OnDestroy } from '@angular/core';
import { Subject,takeUntil } from 'rxjs';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableService } from '../services';
import { WorkRequest } from '../ist-components';

@Component({
    selector: 'up-terminals-app',
    templateUrl : './up-terminals.component.html',
    styleUrls: ['./transaction.scss'],
    encapsulation: ViewEncapsulation.None
})

export class UpTerminalsComponent extends ListComponent implements OnInit, OnDestroy{
	private unsubscribe = new Subject();
  view: any[] =[300, 250];
  animations = true;
  screenType: any;
  dataLoaded:boolean=false;
  workRequest:WorkRequest;
  autoRefreshRetriveDataTimer: any;

	constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef){
    super(injector);
    this.retriveData();
  }

	ngAfterViewInit() {
    super.criteria=this.criteria;
    super.search();
    this.setAutoRefreshInterval();
    //this.setAutoRefreshRetriveDataInterval();
  }

	adjustCriteria(): void {
    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }

	retriveData2():void{
    super.search();
  }

	retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        atmData => this.onGotRecords(atmData),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }

	FORM_TITLE = 'ATM Up Terminals';
  exportFileName = 'ATM Up Terminals';

	ngOnInit() {
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    console.log('screenType::'+this.screenType);
	}

	onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    if(this.workRequest!=null && this.workRequest !==undefined && this.workRequest.collections!=null && this.workRequest.collections[this.collectionId] !=null && this.workRequest.collections[this.collectionId].rows!=null){
      const rows = this.workRequest.collections[this.collectionId].rows;
      console.log("Row Size ::"+rows.length);
      console.log("Rows Data :: "+ rows);
      let statusData:any = [];
      rows.forEach(c =>{
        statusData.push({name: c.terminalId,value: c.terminalId})
        statusData.push({name: c.statusDown,value: c.atmOutOfService})
      })
      this.dataLoaded=true;
      this.cdr.markForCheck();
    }
  }
	onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
	}
	onCompleteGotRecords(): void {
  }
	getEntPermList(): any[] {
    this.entObjectId = 'ATMUPT_REQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }
	onSelect(event){
		console.log(event);
	}

	gatherDataChanged(event:any):void{
    console.log(this.dataService.data);
 	}

 setT21Tags(): void {
	this.requestTypeId = 'ATMUPT_REQ';
	this.metaDataId = 'ATMUPT_REQ';
	this.tabId = 'ATM_UPT_TAB';
	this.sectionId = 'ATM_UPT_SEC';
	this.collectionId = 'ATM_UPT_COL';
	}

	ngOnDestroy(): void {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
  }
}
