import { Component, Injector, OnInit,ChangeDetectorRef, ViewEncapsulation, OnDestroy, ViewChild } from '@angular/core';
import { Subject,takeUntil } from 'rxjs';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { DataTableService, GlobalsService } from '../services';
import { WorkRequest } from '../ist-components';
import { DataTableEditableDetailComponent } from '../components';
import { Location } from '@angular/common';

@Component({
    selector: 'down-by-site-app',
    templateUrl : './down-by-site.component.html',
    styleUrls: ['./transaction.scss'],
    encapsulation: ViewEncapsulation.None
})

export class DownBySiteComponent extends ListComponent implements OnInit, OnDestroy{
	private unsubscribe = new Subject();
  view: any[] =[300, 250];
  animations = true;
  screenType: any;
  dataLoaded:boolean=false;
  workRequest:WorkRequest;
  autoRefreshRetriveDataTimer: any;
  @ViewChild('tableData', { static: false }) private tableData: DataTableEditableDetailComponent;
	constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, private location: Location){
    super(injector); 
  }

	ngAfterViewInit() {
    super.criteria=this.criteria;
    super.search();

    this.setAutoRefreshInterval();
    //this.setAutoRefreshRetriveDataInterval();
  }

	adjustCriteria(): void {

    this.criteria['screenType']=this.screenType;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['COMMAND']='query';
  }

	retriveData2():void{
    super.search();
  }

	retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';
    this.dataService.criteria=this.criteria;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        atmData => this.onGotRecords(atmData),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );
  }

	FORM_TITLE = 'ATM Down by Site';
  exportFileName = 'ATM Down by Site';

	ngOnInit() {
    this.showBackBtn=GlobalsService.isRedirected;
    GlobalsService.isRedirected=false;
    this.route
    .data
    .subscribe(v => this.screenType=v['module']);
    console.log('screenType::'+this.screenType);
	}

	onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    this.workRequest = wr;
    if(this.workRequest!=null && this.workRequest !==undefined && this.workRequest.collections!=null && this.workRequest.collections[this.collectionId] !=null && this.workRequest.collections[this.collectionId].rows!=null){
      const rows = this.workRequest.collections[this.collectionId].rows;
      this.tableData.dataSource.data=rows;
      this.tableData.length=this.workRequest.lastModified;
      this.cdr.markForCheck();
    }
  }
	onErrorGotRecords(error: Object): void {
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
	}
	onCompleteGotRecords(): void {
  }
	getEntPermList(): any[] {
    this.entObjectId = 'ATMDWS_REQ';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm,this.mkcPerm,this.checkerPerm);
  }

	onSelect(event){
		console.log(event);
	}

	gatherDataChanged(event:any):void{
    console.log(this.dataService.data);
 	}

 setT21Tags(): void {
	this.requestTypeId = 'ATMDWS_REQ';
	this.metaDataId = 'ATMDWS_REQ';
	this.tabId = 'ATM_DWS_TAB';
	this.sectionId = 'ATM_DWS_SEC';
	this.collectionId = 'ATM_DWS_COL';
	}

	ngOnDestroy(): void {
    this.unsubscribe.next({});
    this.unsubscribe.complete();
    this.clearAutoRefreshInterval();
    this.clearAutoRefreshRetriveDataInterval();
  }
  goBack() {
    this.globals.setErrorMessage('');
    this.clearErrorMessage();
    this.location.back();
  }

}
