import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DownByBranchComponent } from './down-by-branch.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule } from '@ruf/shell';

export const downByBranch: MonitorComponentData = {
  title: 'ATM Down By Branch List',
  icon: 'table',
  examples: {  
      'ATMDWB_REQ': {
          label: 'ATM Down By Branch List',
          title: 'ATM Down By Branch List',
          description: 'ATM Down By Branch List',
          rufId: 'atm_down_by_branch',
          component: DownByBranchComponent
      }
  }
};

@NgModule({ 
    imports :[ 
    CommonModule,
    FormsModule,
    ReactiveFormsModule,  
    MatTableModule, 
    MatCardModule,  
    RufCommonModule,   
    RufCardModule, 
    ISTComponentModule
  ], 
  declarations: [DownByBranchComponent],
  providers: [{ provide: MON_TOOL, useValue: downByBranch }],
  exports:[],
})
export class DownByBranchModule {}
