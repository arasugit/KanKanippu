import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DownByMakeComponent } from './down-by-make.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule } from '@ruf/shell';

export const downByMake: MonitorComponentData = {
  title: 'ATM Down By Make List',
  icon: 'table',
  examples: {  
      'ATMDWM_REQ': {
          label: 'ATM Down By Make List',
          title: 'ATM Down By Make List',
          description: 'ATM Down By Make List',
          rufId: 'atm_down_by_make',
          component: DownByMakeComponent
      }
  }
};

@NgModule({ 
    imports :[ 
    CommonModule,
    FormsModule,
    ReactiveFormsModule,  
    MatTableModule, 
    MatCardModule,  
    RufCommonModule,   
    RufCardModule, 
    ISTComponentModule
  ], 
  declarations: [DownByMakeComponent],
  providers: [{ provide: MON_TOOL, useValue: downByMake }],
  exports:[],
})
export class DownByMakeModule {}
