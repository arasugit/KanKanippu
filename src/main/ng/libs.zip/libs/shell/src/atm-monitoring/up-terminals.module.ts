import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpTerminalsComponent } from './up-terminals.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';
import { CommonModule } from '@angular/common';
import { RufCardModule, RufCommonModule } from '@ruf/shell';

export const upTerminals: MonitorComponentData = {
  title: 'ATM Overall Up Terminals List',
  icon: 'table',
  examples: {  
      'ATMUPT_REQ': {
          label: 'ATM Up Terminals List',
          title: 'ATM Up Terminals List',
          description: 'ATM Up Terminals List',
          rufId: 'atm_up_terminals',
          component: UpTerminalsComponent
      }
  }
};

@NgModule({ 
    imports :[ 
    CommonModule,
    FormsModule,
    ReactiveFormsModule,  
    MatTableModule, 
    MatCardModule,  
    RufCommonModule,   
    RufCardModule, 
    ISTComponentModule
  ], 
  declarations: [UpTerminalsComponent],
  providers: [{ provide: MON_TOOL, useValue: upTerminals }],
  exports:[],
})
export class UpTerminalsModule {}
