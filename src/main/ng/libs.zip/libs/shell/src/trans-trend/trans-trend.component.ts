import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, Inject, Injector, OnDestroy, OnInit, Optional, ViewChild, ViewEncapsulation } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import { ListComponent } from '../components/base-list.component';
import { AbstractDataTableComponent, DataTableEditableComponent, DataTableEditableDetailComponent, RendererItem } from '../components';
import { DataTableService, ResponseBase } from '../services';
import { WorkRequest } from '../ist-components';
import { IstDatePickerColumnRendererComponent } from '../ist-components';
import { LabelAndValue, LabelsAndValues } from '../common/labels-and-values';
import { Subject, takeUntil } from 'rxjs';
import { CustomValidators, StringUtil } from '../common';
import { PageEvent } from '@angular/material/paginator';


@Component({
  selector: 'trans-trend-app',
  templateUrl: './trans-trend.component.html',
  styleUrls: ['../transaction/transaction.scss'],
  encapsulation: ViewEncapsulation.None
 })
export class TransTrendComponent extends ListComponent implements OnInit, OnDestroy,AfterViewInit {
  [x: string]: any;

  @ViewChild('transTrendDataTable', { static: false }) private transTrendDataTable: DataTableEditableComponent;
  dataTableComponent: DataTableEditableComponent;
  private unsubscribe = new Subject();
  constructor(private injector:Injector,private dataService  :DataTableService,private cdr: ChangeDetectorRef, @Optional() @Inject('THEME_PICKER_SERVICE') private themePicker, @Inject(ElementRef) private element: ElementRef) {
    super(injector);
  }

  FORM_TITLE='Transaction Trend Report';
  exportFileName= 'Transaction Trend Report';
  cardTitle="Transaction Trend"
  isDetailsTab=true;
  multi: any[];
  width=1000;
  widthTps=1000;
  view: any[] = [this.width, 300];
  viewTps: any[] = [this.widthTps, 300];
  screenType ='';

  // options
  fromTime : string = '';
  fromDate : string = '';
  dateTo : string = '';
  toTime : string = '';
  year : string = '';
  rows = 1;
  ist_inst_Id = '';
  terminalId = '';
  fieldTitle = '';
  yearsList : LabelsAndValues = new LabelsAndValues();
  yearsListValues : string[] = [];
  currYear = new Date().getFullYear();
  baseYear = this.currYear - 10;

   // line, area
  autoScale = true;
  timeRangeData: LabelsAndValues = new LabelsAndValues();
  colorScheme = {
    domain: ['#5AA454', '#E44D25', '#CFC0BB', '#7aa3e5', '#a8385d', '#aae3f5']
  };

   workRequest:WorkRequest;

   queryPerm = new FormActionPermission('TXNTREND', 'Q');
   checkerPerm = new FormActionPermission('TXNTREND', 'C');
   mkcPerm = new MKCPermission('TXNTREND');

   startDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);
   endDateRenderer: RendererItem = new RendererItem(IstDatePickerColumnRendererComponent);

   ngOnInit() {
    this.type="";
    this.range=this.type;
    this.month="";
    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);
    this.requestPerms.getPermission(this.router.url);
    this.timeRangeData.array = [new LabelAndValue('Month', 'Month'),new LabelAndValue('Year', 'Year'), new LabelAndValue('Custom', 'Custom')];
    this.setAutoRefreshSearch(true);
  }

  ngAfterViewInit(): void {
    console.log("Inside ngAfterViewInit :: "+this);
    this.setAutoRefreshInterval();
  }

  setT21Tags(): void {
    this.requestTypeId = 'TXNTREND';
    this.metaDataId = 'TXNTREND';
    this.tabId = 'TXNTREND_TAB';
    this.sectionId = 'TXNTREND_SEC';
    this.collectionId = 'TXNTREND_COL';
  }
  retriveData():void{
    this.dataService.requestType=this.requestTypeId;
    this.dataService.collectionTag=this.collectionId;
    this.dataService.action='query';

    this.dataService.criteria=this.criteria;
    this.dataService.loadData(false).pipe(takeUntil(this.unsubscribe)).subscribe(
        data => this.onGotRecords(data),
        error => this.onErrorGotRecords(error),
        () => this.onCompleteGotRecords()
      );

  }
  get darkMode (): boolean {
    return this.themePicker.darkTheme;
  }

  onGotRecords(wr: WorkRequest, overWriteMsg: Boolean = true): void {
    console.log('Inside onGotRecords   ::');
    this.workRequest = wr;
    this.dataLoaded=false;
    if(this.workRequest.lastModified == -1)
      this.globals.setErrorMessage('No Data found');

    let error: Boolean = false;
    let errorId = '';
    if (this.workRequest.requestResult === ResponseBase.REQUEST_RESULT_ERROR) {
      errorId = this.workRequest.errorDetail;
      errorId = (errorId === null || errorId.trim().length <= 0) ? this.workRequest.messageId : errorId;
      this.globals.setErrorMessage(errorId);
      error = true;
    }
    if(this.workRequest!=null && this.workRequest !==undefined &&
      this.workRequest.collections!=null && this.workRequest.collections[this.collectionId]
       !=null && this.workRequest.collections[this.collectionId].rows!=null){
      const rows = this.workRequest.collections[this.collectionId].rows;
      const rowspage = this.workRequest.collections['TXNTREND_COL'].rows;
      console.log("onGotRecords rowspage:: " + rowspage);
      this.rows=rows.length;
      this.view=[1000,300];
        this.width=(rows.length*1000)/40;
        if(this.rows>38)
        this.view=[this.width,300];

    if(this.workRequest.collections['TXNTREND_COL']
    !=null && this.workRequest.collections['TXNTREND_COL'].rows!=null){
        this.transTrendDataTable.dataSource.data=rowspage;
        DataTableEditableComponent.totalDTLRecords=rows.length;
        this.transTrendDataTable.length=rows.length;
        DataTableEditableComponent.isTxnDetailScreen=true;
        this.transTrendDataList=rowspage;
        this.dataLoaded = true;
      }
    else {
        this.dataLoaded = false;
      }
    }
    this.globals.hideLoadingBar();
  }
  onErrorGotRecords(error: Object): void {
    console.log(' onErrorGotRecords   ::');
    if (this.globals.checkErrorResponse(error)) {
      this.globals.setErrorMessage(JSON.stringify(error, null, 2));
    }
    this.globals.hideLoadingBar();
  }
   onCompleteGotRecords(): void {
    console.log(' onCompleteGotRecords   ::');
    this.globals.hideLoadingBar();
  }
  adjustCriteria(): void {
    this.criteria['type']=this.type;
    this.criteria['requestTypeId']=this.requestTypeId;
    this.criteria['collectionId']=this.collectionId;
    this.criteria['ist_page_ctrl'] = '1';
    this.criteria['ist_total'] = 'Y';
    this.criteria['COMMAND']='query';
    this.criteria['ist_inst_Id']= this.ist_inst_Id;
    this.criteria['termId'] = this.terminalId;
    this.criteria['year']=this.year;
  }
  changeHandler(event: any) {

    this.globals.setErrorMessage('');
    this.globals.setStatusMessage('');
    this.dataLoaded=false;
    console.log("Date n Time data : "+this.fromDate + this.dateTo + this.fromTime + this.toTime );
    // this.fromDate='';
    // this.dateTo='';
    // this.fromTime='';
    // this.toTime='';
    if(null != event){
    this.type=event;
    if(this.type != 'Custom'){
      this.fieldTitle = this.type === "Month" ? "Select Month" : "Select Year";

      if(this.type == 'Year'){
        this.addLast10Years(this.baseYear,this.currYearYear);
        this.assignYearsList(this.yearsListValues);
        console.log("Years List : "+this.yearsList.records.length);
        console.log("Years List : "+this.yearsList.records);
      }
    }
    else{
      this.fieldTitle = 'Date from';
    }
    console.log("Inside changeHandler " + event)
    this.globals.hideLoadingBar();
    this.isSearchReq=true;
    }
  }
  onRowClick(event:any) {
    //console.log("Inside OnRowClick " + event);
  }

  ngOnDestroy() {
    this.clearAutoRefreshInterval();
   this.transTrendDataTable.paginator.length=0;
   this.transTrendDataTable.paginator.pageSizeOptions=null;
   AbstractDataTableComponent.totalDTLRecords=0;
   //AbstractDataTableComponent.totalTpsDTLRecords=0;
   this.transTrendDataTable.totalDisplayingRecords=0;

  }
  onActivate(data): void {
   // console.log('Activate', JSON.parse(JSON.stringify(data)));
  }

  onDeactivate(data): void {
    //console.log('Deactivate', JSON.parse(JSON.stringify(data)));
  }
  dateTickFormatting(val: any): string {
    console.log('dateTickFormatting....'+val);
    if (val instanceof Date) {
      return (<Date>val).toLocaleString('de-DE');
    }
  }

  search() : void{
  this.dataLoaded=false;

  this.clearErrorMessage();
  if (this.validateBeforeQuery()) {
    this.globals.showLoadingBar();
    this.clearErrorFlags();
    this.encryptCriteria();
  this.adjustCriteria();
    this.criteria['fromDate']=this.fromDate;
    this.criteria['toDate']=this.dateTo;
    this.criteria['fromTime']=this.fromTime;
    this.criteria['toTime']=this.toTime;
    this.retriveData();
  this.autoRefreshService.setAutoRefreshSearchInterval(this);
  }
  }

  clear() : void{
    this.fromDate = 'null';
    this.dateTo   = 'null';
    this.fromTime = '';
    this.toTime = '';
    this.terminalId = '';
    this.range = '';
    this.ist_inst_Id = '';
  }
  validateBeforeQuery(): boolean {
    CustomValidators.globals=this.globals;
    this.fromDate=CustomValidators.formatDateString(this.fromDate, this.globals.dateFormat);
    this.dateTo=CustomValidators.formatDateString(this.dateTo, this.globals.dateFormat);
    let result:boolean;

    if(this.type === 'Year')
      result = CustomValidators.isYearEmpty(this.year);
    else if(this.type === 'Month')
      result = CustomValidators.validateMonth(this.fromDate);
    else if(this.type === 'Custom')
      result = CustomValidators.validateTransDate(this.fromDate, this.dateTo, this.firstFocusField, this.toDateFocusField);
    else result = true
    if (StringUtil.isEmpty(this.ist_inst_Id)) {
      this.globals.setErrorMessage('ERR01');
      this.setFocusToFirstField();
      result = false;
    }

    if(result){
      result = CustomValidators.isTermIdEmpty(this.terminalId);
    }
  return result;
}

validateFromTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}
validateToTime(event: any) {
  CustomValidators.globals=this.globals;
  return CustomValidators.formatTimeField(event);
}

addLast10Years(base : number, curr : number){
  for(let i=this.currYear; i>= this.baseYear; i--){
    this.yearsListValues.push(i.toString());
  }
}

assignYearsList(values: string[]): void {
  this.yearsList.array = values.map((y: string): LabelAndValue => {
    return new LabelAndValue(y, y);
  });
}

 // called for data table pagination
 more(pageEvent: PageEvent): void {
  this.globals.showLoadingBar();
  this.criteria['type']=this.type;
  this.criteria['requestTypeId']=this.requestTypeId;
  this.criteria['collectionId']=this.collectionId;
  this.criteria['ist_page_ctrl'] = '' + ((pageEvent.pageIndex) + 1);
  this.criteria['ist_total'] = 'Y';
  this.clearErrorFlags();
  this.encryptCriteria();
  this.criteria['fromDate']=this.fromDate;
  this.criteria['toDate']=this.dateTo;
  this.criteria['fromTime']=this.fromTime;
  this.criteria['toTime']=this.toTime;
  this.retriveData();
}

}

