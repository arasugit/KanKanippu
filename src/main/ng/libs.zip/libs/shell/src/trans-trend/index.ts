export * from './trans-trend.module';
export * from './trans-trend.component';
