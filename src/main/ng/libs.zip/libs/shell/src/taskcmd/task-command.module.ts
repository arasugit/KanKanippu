import { NgModule } from '@angular/core';
import { ISTComponentModule } from '../ist-components/ist-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TaskCommandComponent } from './task-command.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MON_TOOL, MonitorComponentData } from '../monitor-components';

export const tskCmdData: MonitorComponentData = {
  title: 'Switch Task Command',
  icon: 'home',
  examples: {  
      'TSKCMD': {
          label: 'Task Commands List',
          title: 'Task Commands',
          description: 'Task Commands',
          rufId: 'mon_task_cmd',
          component: TaskCommandComponent
      }     
  },  
};

@NgModule({ 
    imports :[ 
    FormsModule,
    ReactiveFormsModule,  
    MatTableModule, 
    MatCardModule,    
    ISTComponentModule
  ], 
  declarations: [TaskCommandComponent],
  providers: [{ provide: MON_TOOL, useValue: tskCmdData }],
  exports:[],
})
export class TaskCommandModule {}
