import { Component, Injector, OnInit } from '@angular/core';
import { MKCPermission } from '../permission/mkcform.permission';
import { FormActionPermission } from '../permission/form.action.permission';
import {ListComponent} from '../components/base-list.component';


@Component({
  selector: 'task-cmd-app',
  templateUrl: './task-command.component.html'
 })
export class TaskCommandComponent extends ListComponent implements OnInit {
  constructor(injector: Injector) {
    super(injector);
  }
  FORM_TITLE = 'Task Command List';

   product = '';
   nodeId = '';
   taskName = '';
   istCommand = '';
   pId = '';

   queryPerm = new FormActionPermission('TSKCMD', 'Q');
   checkerPerm = new FormActionPermission('TSKCMD', 'C');
   mkcPerm = new MKCPermission('TSKCMD'); 
   

   ngOnInit() {

    super.ngOnInit();
    this.requestPerms.permsArr = [];
    this.requestPerms.permsArr.push(this.queryPerm);
    this.requestPerms.permsArr.push(this.mkcPerm);
    this.requestPerms.permsArr.push(this.checkerPerm);  
    this.requestPerms.getPermission(this.router.url); 
    this.setAutoRefreshSearch(true);
  }
 
  setT21Tags(): void {
    this.requestTypeId = 'TSKCMD';
    this.metaDataId = 'TSKCMD';
    this.tabId = 'TSKCMDTAB';
    this.sectionId = 'TSKCMDSEC';
    this.collectionId = 'TSKCMDCOL';
  } 
}

