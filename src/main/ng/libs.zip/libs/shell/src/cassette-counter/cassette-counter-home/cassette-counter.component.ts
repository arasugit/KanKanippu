import {Component,ViewEncapsulation,Injector} from '@angular/core';
import { ListComponent } from '../../components';
import { FormActionPermission, MKCPermission } from '../../permission';
import { StringUtil } from '../../common';

@Component({
  selector: 'cassette-counter-home',
  templateUrl: './cassette-counter.component.html',
  styleUrls: ['./cassette-counter.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CassetteCounterComponent extends ListComponent {

  constructor(private injector: Injector) {
    super(injector);
  }
  FORM_TITLE = 'ATM Cassette Counter';
  exportFileName = 'ATM Cassette Counter';
  pageCtrl = 'pageNum';
  mon_inst_id = '';
  mon_atm_grp_name = '';
  mon_atm_unit = '';
  setT21Tags(): void {
    this.requestTypeId = 'ATMCTE_REQ';
    this.metaDataId = 'ATMCTE_REQ';
    this.tabId = 'ATMCTE_TAB';
    this.sectionId = 'ATMCTE_SEC';
    this.collectionId = 'ATMCTE_COL';
  }
  adjustCriteria(): void {
  //  this.criteria['productId'] = 'ISTSWT';
  //  this.criteria['siteId'] = 'Site1';
  //  this.criteria['nodeId'] = 'node1';
    this.criteria['requestTypeId'] = this.requestTypeId;
    this.criteria['collectionId'] = this.collectionId;
    this.criteria['COMMAND'] = 'query';
  }
  
  getEntPermList(): any[] {
    this.entObjectId = 'ATM_CASSETTE_COUNTER';
    this.queryPerm = new FormActionPermission(this.entObjectId, 'Q');
    this.insertPerm = new FormActionPermission(this.entObjectId, 'I');
    this.updatePerm = new FormActionPermission(this.entObjectId, 'U');
    this.deletePerm = new FormActionPermission(this.entObjectId, 'D');
    this.checkerPerm = new FormActionPermission(this.entObjectId, 'C');
    this.mkcPerm = new MKCPermission(this.entObjectId);
    return new Array(this.queryPerm, this.insertPerm, this.updatePerm, this.deletePerm, this.mkcPerm, this.checkerPerm);
  }

  validateBeforeQuery(): boolean {
    this.globals.setErrorMessage('');
    if (StringUtil.isEmpty(this.mon_inst_id)) {
      this.globals.setErrorMessage('ERR01');
      this.setFocusToFirstField();
      return false;
    }
    return true;
  }
  openSearchList(winName) {}

  getModuleName() { return 'ATM-Monitoring'; }
  emitModuleReady() { this.msgService.sendMessage(this.getModuleName()); }
}

